import org.junit.Test;

public class Sample06Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark06(-0.0010036995349377391,-45.5288727193116,-3.26659265359206 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark06(-0.0013367359113590806,-2.220446049250313E-16,-55.14304477759582 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark06(-0.001539193622284002,-1.5707963267948966,-1.9452598913759927E-16 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark06(-0.001598556877455703,-1.5707963267948966,77.49568507647496 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark06(-0.0016426657289967935,-1.5707963267948963,-31.6065742629442 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark06(-0.0018299362463007711,-1.5707963267948966,50.84618639996822 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark06(-0.002015490771451335,-1.5704115739191111,-168.60774496789992 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark06(-0.002069258712399866,-2.220446049250313E-16,-37.71262162689106 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark06(-0.002292452610975959,-43.98274778136728,2.220446049250313E-16 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark06(-0.003004353239046929,-2.220446049250313E-16,-31.41592653589793 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark06(-0.0031598261507374496,-1.5707963267948966,-5.120445185078452 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark06(-0.0031681320693026497,-1.5707963267948966,18.856853802863874 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark06(-0.0034695871067994,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark06(-0.004243480092211784,-1.5513226986600412,0.0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark06(-0.004404455487522127,-1.5707963267949012,-1.5707963267948983 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark06(-0.004807902506642675,-1.5707963267948966,4.712633139437425 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark06(-0.004812148710941769,-45.27985163256634,-15.355955122860038 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark06(-0.0049491399690350345,-1.001915436311497,1.5707963267948966 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark06(-0.005062413118992426,-0.010869850342649605,-1.4597442740739155 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark06(-0.005295180668873911,-0.3929790899749612,8.565297671818527 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark06(-0.005417709128314907,-1.5707963267948966,-75.61854686956856 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark06(-0.005843559207450438,-95.64223756608968,-70.25512623493192 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark06(-0.005866289757816827,-1.5592419095955914,-14.430050746580953 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark06(-0.006113455323969674,-45.12647853207758,-61.02048022377997 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark06(-0.006118285995304531,-1.5707963267948966,43.10376741189641 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark06(-0.0063183830809937815,-1.5707963267948966,1.2295183959234408 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark06(-0.006606827111442146,-1.5707963267948966,-54.57349039556204 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark06(-0.0071387803211956855,-0.023976276734183344,31.417876468426925 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark06(-0.0075977496659194186,-1.5707963267948966,-1.646538707177708 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark06(-0.007857084609279155,-1.5707963267948966,-89.93287534216758 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark06(-0.008133981406219251,-0.6691766073995555,57.437761024157396 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark06(-0.008295495736662323,-1.5707963266092946,13.114994736754873 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark06(-0.008295756311764088,-1.5707963267948966,124.25943209708558 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark06(-0.008450176971648727,-31.426554035915526,-88.26872530817388 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark06(-0.008501534790937116,-1.1771638839681768,-75.4680030303901 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark06(-0.009150797468436086,-1.5707963267948948,-59.493745382778506 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark06(-0.009182076666280688,-1.5707963267948966,8.103981634453437 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark06(-0.009336745937595451,-1.5707963267948966,-55.59516877388077 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark06(-0.009743556358040818,-0.5796750791576073,49.73191994241377 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark06(-0.009839338403147227,-1.5707963267948966,-8.044300188215054 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark06(-0.010205817716039258,-0.6291100083112677,-44.26698908494837 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark06(-0.01030775097378787,-1.5707963267948966,38.90513470595309 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark06(-0.01054399429218908,0,0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark06(-0.010717968865878447,-44.52735744914421,-20.313287100047404 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark06(-0.010748241029420624,-1.5707963267948966,-97.57568061986896 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark06(-0.012009720682876718,0.0,30.343180512866596 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark06(-0.01217923042121452,-1.5707963267948966,4.714356583822483 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark06(-0.012277188875157483,2.0596337842826493E-15,0 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark06(-0.01234123649629204,-19.38575198549976,-71.79671280742508 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark06(-0.012468262958168478,-0.36270534693292034,-39.58993009228842 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark06(-0.012548552584669078,-0.873438896633678,-1.5707963267948961 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark06(-0.012788317099228952,-45.18527170426699,-45.86129420372947 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark06(-0.013026066208576593,-0.4708535956416961,3.142544357499322 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark06(-0.013225723315859904,-32.48607065146807,0.0 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark06(-0.013959246648797781,-0.19297104291192424,-1.5707963267948966 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark06(-0.014115812121231919,-45.42895991966879,-91.82436333441416 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark06(-0.015159473570479321,-1.5707963267948966,5.601044252884762 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark06(-0.015540062082881168,-1.5707963267948912,46.769993763346974 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark06(-0.015920883165826183,-0.18434853984443236,-72.66084893346529 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark06(-0.016396658027962946,0.0,0 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark06(-0.017018376687600312,-1.5707963267948966,-44.488068136687374 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark06(-0.01740814162277362,-1.5707963267948966,-9.037322217459527 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark06(-0.017411724942343495,-1.5707963267948966,23.506709480156573 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark06(-0.0177757965717737,-0.673468415383412,-4.712396778279671 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark06(-0.017855761517574037,-1.5707963267948966,13.90411567230537 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark06(-0.01825882068617192,-6.730163499972233E-16,1.5707963267949054 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark06(-0.018604614263170817,2.1684043449710089E-19,0.0 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark06(-0.018618016230107504,-0.16124834602169194,1.5707963267948966 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark06(-0.019023952637818677,-1.5707963267948966,8.103981635893765 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark06(-0.019131954610755786,-1.5707963267948966,43.29118589608327 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark06(-0.019258959563564187,-45.00835119270188,-88.3683801991038 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark06(-0.01977598682145848,-0.6804266377417405,0.0 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark06(-0.020258230085871028,-1.5562375658048042,97.39471048685525 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark06(-0.020555484796160352,6.712388980384698,-44.52241490225033 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark06(-0.020647502738006255,-1.5707963267948966,-37.68774723641507 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark06(-0.02092255115550512,-1.5707963267948966,-6.712388980888871 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark06(-0.021469054884812572,-0.10727564221142494,-27.852833259562445 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark06(-0.02156855850791418,-1.5707963267948966,49.88618104113864 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark06(-0.022359415095378914,-1.5707963267948966,20.711762284964852 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark06(-0.022426029385314492,-1.5707963267948966,-1.5707963267948912 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark06(-0.022525727250055402,-1.5707963267948966,4.712633332245609 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark06(-0.02322827345376354,0.0,0 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark06(-0.02347793226005508,-1.5707963267948966,-13.752066246078934 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark06(-0.023600782712193343,-0.8984013285869644,-7.444824125799653 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark06(-0.023804373883766276,-1.315138799464705,65.7511039142419 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark06(-0.024063290445674568,-1.5076228008101518,-36.12677464168552 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark06(-0.02414954008704422,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark06(-0.02433420393046284,-45.13489535325956,-8.831597898078599 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark06(-0.02447461700182291,-5.397605346934028E-79,58.97247011000059 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark06(-0.024657070346571608,-0.5509060226226833,-47.420772218846444 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark06(-0.024769277599020745,-0.5048254731173354,-3.1415939735939653 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark06(-0.025061178117583027,-1.5707963267948957,42.32602725151921 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark06(-0.026133780772274736,-1.5707963267948966,0.6554530344617635 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark06(-0.02623150468058827,-1.5707963267948966,-83.31576729183965 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark06(-0.026493231327254285,-1.5707963267948966,6.712388980385528 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark06(-0.026861986466547638,-0.5809406207428002,-6.712418099855583 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark06(-0.026912316085127362,-1.5707963267948966,-85.09976257322437 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark06(-0.02694804826684492,-1.5707963267948966,7.5657552564240424E-6 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark06(-0.02788508163623149,-27.094782433561534,-145.69147053597445 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark06(-0.02849190680905915,-1.55979712497318,88.34305380241673 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark06(-0.029574547116211165,-0.3510755462562163,0.08149716249276985 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark06(-0.029590007555091353,-1.5707963267948963,4.713435712332509 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark06(-0.029704678818084612,-1.5707963267948963,-62.851013794975245 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark06(-0.02974883813108332,-1.5707963267948966,24.0930612203218 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark06(-0.03075339197718866,-1.5707963267948966,95.36238185736664 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark06(-0.030785023972536685,-1.5707963267948966,71.03398089380778 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark06(-0.03088663938278846,-44.42815490688109,-67.09941136304157 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark06(-0.031348026484578004,-1.5707963267948966,-59.61709360340355 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark06(-0.032097640943627465,-1.5565499439253483,-53.66052683209109 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark06(-0.03288390651560036,-0.2749272476341518,88.59939427913139 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark06(-0.033583831345115576,-1.5707963267948966,87.27308791936107 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark06(-0.034501117198538545,-1.5707963267948966,23.95037323440323 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark06(-0.0345939109589872,-1.1582472894507423,1.5707963267948966 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark06(-0.03480289604969693,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark06(-0.03540911912168099,-1.5707963267948966,-51.605787818231754 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark06(-0.03548676277303442,-1.5707963267948966,52.49264102906014 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark06(-0.03558797339122846,-0.7074827520108715,-36.98787241798274 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark06(-0.03635462822217761,-1.436289144119844,-92.1973042973837 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark06(-0.03821852646237556,-1.5707963267949019,15.255923676469124 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark06(-0.03873196668091627,-1.0799189111059966,0.0 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark06(-0.0387940882124802,-0.13760702726947047,66.26610574492565 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark06(-0.039036606069357986,-2.7755575615628914E-17,0.0 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark06(-0.0390664071188871,-1.5707963267948966,17.590643218372904 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark06(-0.03949339519335332,-1.57078147152357,3.3881317890172014E-21 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark06(-0.03950333635389941,-0.8849089425025178,-92.68082142354697 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark06(-0.04019740283660522,-0.43292248665460864,55.97694431702747 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark06(-0.04019934474756012,-1.5707963267948966,90.76740878094554 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark06(-0.040242377978032096,-1.5707963267948966,43.04493675041001 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark06(-0.040367645086237816,-1.5453289821095082,28.52502581163011 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark06(-0.04045803707074902,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark06(-0.040754531201244504,-44.16240680473929,-1.5707963267948966 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark06(-0.04101630393736855,-1.5707963267948966,-33.68156660633963 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark06(-0.04123061305115808,-1.5707963267948966,15.480569090067872 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark06(-0.042276105490765215,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark06(-0.042582110647155336,-45.22076785358821,-9.458253478499053 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark06(-0.04280625808362659,-0.29466796601867395,51.58704592635064 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark06(-0.042823967219003806,-0.41264700643668517,-14.704341552650781 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark06(-0.043821877089926756,-37.91609545738,-1.5707963267948966 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark06(-0.043854578535428124,-1.5706907301207937,-279.60031271049223 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark06(-0.04405076156730381,-0.03400776672921468,-10.548548120595868 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark06(-0.044196578437599644,-0.0513097179348323,71.1063455943261 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark06(-0.04506301649174217,-3.552713678800501E-15,3.1415926535897967 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark06(-0.0454751405413889,-1.5707963267948966,28.274333882308138 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark06(-0.0458236276500628,-43.982304585596,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark06(-0.04598014501880687,-0.5102608100517962,-48.31807918792197 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark06(-0.046000124931547516,-19.34955592472641,-15.458612657133415 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark06(-0.04646862166787531,-32.92271206115974,-3.1415926535898007 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark06(-0.04692615525797186,-1.5707963267948966,-82.67086276278945 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark06(-0.04721281933413668,-6.271557296155279,0 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark06(-0.04726055408819203,-1.5707963267948966,4.837388980384694 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark06(-0.047288371165184806,-39.17237492426317,-60.194211256377514 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark06(-0.04736129990010121,-100.5450662616576,-19.393690241419968 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark06(-0.047448991407152086,-1.3677177249757944,0.154603940738395 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark06(-0.047875792056677025,-1.5707963267948983,49.39858061129982 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark06(-0.04789702317267508,-31.983081763210173,-45.52675764549477 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark06(-0.04846382318055782,-0.29932025498898707,38.821566131000736 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark06(-0.049489980007603414,6.712388980384703,-85.19841507942938 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark06(-0.04996371621932007,-44.088018545396764,-40.467024997208355 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark06(-0.05021066821582032,-1.0036849165035886,110.84414857873517 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark06(-0.05076199419778705,-1.5707963267948901,53.7882366955444 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark06(-0.051486326199782585,-1.1239100653957341,-4.714428867163351 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark06(-0.05189298481471675,-101.69591191822735,-1.5707963267948966 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark06(-0.05219460557832156,-1.5707963267948948,-80.64982808485584 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark06(-0.05240081445935818,-1.5707963267948966,38.77122539021207 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark06(-0.05279766740422809,-0.7427823180831941,-81.27072445009983 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark06(-0.05299891476871043,-0.17318713416957326,0.0 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark06(-0.053389082192709214,-95.70884477383937,-159.26008039700724 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark06(-0.0536193155800429,-0.0130603625644693,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark06(-0.054199952831511286,0.0,0 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark06(-0.05494417532921833,-44.25026482926806,4.868008493305304 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark06(-0.055510159740525214,-1.5707963267948966,5.999355061644536 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark06(-0.056301080789643576,-0.4121702752077931,63.12106257997149 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark06(-0.05741266110774723,-1.5707963267948966,-12.664678962635971 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark06(-0.05741695001820151,-1.5707963267948966,-50.26548245743669 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark06(-0.057805123891534194,-0.07519367603844496,624.4156460247164 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark06(-0.057883863990089775,-3.1415926535897944,-18.89694151703811 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark06(-0.05788943388071299,-1.5707963178331565,100.0 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark06(-0.05981032469250924,-39.016926601358286,-14.904366698937487 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark06(-0.06055186221290043,-0.48353729096786324,59.41162045188429 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark06(-0.06122323164649465,-32.42056341907325,-31.655760543036607 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark06(-0.06132250048200656,-1.5707963267948966,-90.170241429823 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark06(-0.06170844251121754,-0.14338187795829638,-15.274795177059339 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark06(-0.06209920051156501,-1.5707963267948966,-86.4317736972729 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark06(-0.06277533203108158,-1.5707963267948966,94.29264155269766 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark06(-0.06281207530111854,-0.7280277011252603,1.570736126988867 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark06(-0.06284317227346828,-1.5707963267948966,78.03372554742754 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark06(-0.06293701515568961,-221.44246279186774,28.703538652546612 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark06(-0.0631744883679594,-0.0964373688889961,-59.384721743895156 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark06(-0.0631843942284828,-0.024620534440757725,-3.141592653589793 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark06(-0.0636257109757443,-1.5707963267948946,55.55676317743391 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark06(-0.0653519746817213,-1.5707963267948968,88.04520296116696 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark06(-0.0686490219818516,-1.5707963267948966,15.478198907949007 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark06(-0.0687355772450153,-1.5645965657177179,-4.7143422917466875 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark06(-0.0704323662935959,-1.5707963267948966,-29.060322077744175 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark06(-0.07057385949281897,-44.07102500665441,-70.27909951048527 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark06(-0.07063365480894847,-32.58103494441959,4.712400936754097 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark06(-0.07137754879260938,-0.04038947468907414,-828.0866110794695 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark06(-0.07166249716947992,-1.5707963254000383,-15.59484576244477 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark06(-0.07212657056806245,-31.41592653589793,-1.5707963267948966 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark06(-0.07259662987951168,-2.730374320682562E-16,55.96557564696189 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark06(-0.07311372360301505,-1.5707963267948966,320.4397696251821 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark06(-0.0734005588693436,-1.254017302918577,39.51238499706028 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark06(-0.07351181669211601,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark06(-0.07353691271356938,-1.5707963264139737,28.247599610993365 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark06(-0.07362883581410307,-1.5479451758000708,-94.43796516583367 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark06(-0.07399395016028194,-31.743435755928147,-59.870231006914736 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark06(-0.07490123857852049,-1.5707963267948966,-62.308757050552686 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark06(-0.07504322220997284,-95.51350902719071,-3.184618968275923 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark06(-0.07615938216728324,-0.6084155030063982,31.984261015467496 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark06(-0.07624631429137388,-0.14327721806833654,55.021547076502216 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark06(-0.07625485414787098,-0.027740948230468902,-81.68314915962189 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark06(-0.076470046768914,-3.65755965210328E-99,-75.7536233505815 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark06(-0.0765403092666318,-1.4545738862247788,44.491124144669485 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark06(-0.07730072952760736,-1.5707963267948966,-66.80909674873061 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark06(-0.07761512162748122,-95.79834680808919,-111.27901900820581 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark06(-0.0776416201196473,-0.1424259853278053,63.327538328164216 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark06(-0.0777631136621222,-1.570796326794877,-135.44238500056684 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark06(-0.07783475152492228,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark06(-0.07784765202683364,-0.17695644208041883,88.8861079319691 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark06(-0.0778933906194943,-95.7604017141702,-1.5707963267948966 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark06(-0.07811330827487284,-1.5707963267948963,39.604988682039036 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark06(-0.07843824329673682,-1.5707965086198388,157.4693466795943 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark06(-0.07898486078426203,-94.37136841604487,-1.5707963267948966 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark06(-0.07972224240782283,-0.4692520418222732,100.0 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark06(-0.08035039943190703,-31.535766187765812,-56.69978246896987 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark06(-0.08051788613890398,-1.5707963267948957,1.5707963267948966 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark06(-0.08091184933022236,-1.4072321454656422,53.889087881735776 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark06(-0.08100829462640957,-1.5707963267948966,3.141592428599842 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark06(-0.08156387020543461,-0.31770405672206437,1.82877982605164E-99 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark06(-0.08162821593730807,-0.4727832691532954,-100.0 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark06(-0.08197611906395363,-1.5707963267948966,-84.1611207327968 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark06(-0.08208606648464789,-45.12514541788005,-1.5707963267948966 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark06(-0.08243159553800437,-1.5707963267948966,-85.69733243485084 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark06(-0.0824741508157932,0.0,0 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark06(-0.0826893663347894,-1.2037322440120306,24.342997538923456 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark06(-0.08308950333489967,-1.5707963267948966,-6.712394796901477 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark06(-0.0831706106614365,-1.5707963267948966,68.08444607170318 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark06(-0.0836110055556773,-101.71587408504021,-71.84671012459226 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark06(-0.08427654261032202,-0.645726258519391,11.249278140302764 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark06(-0.08479511971265707,-1.5707963267948966,-32.48880006496236 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark06(-0.08486743151904738,-95.36610256027022,-88.34059448046392 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark06(-0.08502380217165338,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark06(-0.08553521131044395,-0.05109425821986928,-51.78363301471974 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark06(-0.08583539893848968,-1.5707963267948966,-27.911491211163778 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark06(-0.08628522379981973,-32.68821649906313,-1.5707963267949054 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark06(-0.0865276659799226,-0.7452981836718895,-707.9163611585698 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark06(-0.08656372160532563,-1.4264539656160073,56.3550210352678 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark06(-0.0869202617806048,-0.5611517543619875,-37.74885068304144 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark06(-0.08782377767485626,-1.5707963267948966,0.3702772656686817 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark06(-0.08831486612133212,-1.5707963267948966,2.3408381773460992E-97 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark06(-0.08832479562656737,-88.12082044863465,-33.53299261215032 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark06(-0.08912157316467678,-1.5707963263678775,0.0 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark06(-0.08935444256074865,-43.982297150257104,-46.83709637395085 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark06(-0.08947835069303292,-1.5707963267948966,-72.76494639847596 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark06(-0.08949447751054064,-45.048455964601104,-1.5707963267948983 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark06(-0.09082456974659658,-1.552596229144124,-36.17345874775075 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark06(-0.09128421247076093,-1.5707963267948966,-7.853308910800958 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark06(-0.0923156886067602,-1.0999714453132547,89.5208608217822 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark06(-0.09267389737799725,-1.570796326794901,-63.892026548797126 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark06(-0.09297022417642539,-0.6338186043310021,0.6364135898324549 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark06(-0.09362341175187616,-1.0138939472888586,-97.48823384218626 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark06(-0.09417581968841995,-1.296454654945288,17.24765522139837 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark06(-0.09440321683498144,-31.415928288884636,-52.85981803528206 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark06(-0.09501336262503912,-1.5707963267948966,-35.320573169083666 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark06(-0.09516197222531281,-1.5707963267948957,100.0 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark06(-0.09535397888097752,0.0,0 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark06(-0.09590406554589581,-1.5707963248527148,54.460010801723826 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark06(-0.09622484053738845,-32.976103117428465,-90.07034924086163 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark06(-0.09718611358700459,-0.570795410806162,-37.94231143765974 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark06(-0.09720997872857322,-88.3106574653411,-10.259830226304416 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark06(-0.09801695281132891,0.0,86.18538526334957 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark06(-0.09804476370939194,-0.49731132815640877,19.349557550727155 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark06(-0.09813784975635353,-1.6940658945086007E-21,-27.003150513600872 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark06(-0.09843246838481612,-45.3570968956589,-3.1415926535898535 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark06(-0.09845153461424551,-1.5707963267948966,-3.1415795182306954 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark06(-0.09850362571063198,-94.26138754301218,-121.28394817275888 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark06(-0.09865970899997875,-1.5707963267948966,-3.14159366008383 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark06(-0.09882977361680909,-3.135722502054536E-15,-1.3552527156068805E-20 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark06(-0.09920569669119406,-213.87751546428896,-123.54843605551613 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark06(-0.09939227652872096,-1.143191932628604,0.0 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark06(-0.09953066505627187,-0.0666838900664945,-3.141592653589793 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark06(-0.10123248398429346,-1.5707963267948966,-45.021218724155624 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark06(-0.1019318191128515,-0.003954056495793092,46.67176717828018 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark06(-0.10271032627335284,-0.2556730508562967,-1.5707963267948966 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark06(-0.10279968509118474,-1.5707963267948966,2.21411726249967 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark06(-0.10320268394777643,-1.5707963267948966,3.903287054069878 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark06(-0.10449957789792336,-1.5707963267948966,1.5747025773624996 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark06(-0.10472680999177886,-1.148370168760314,-93.77838916660355 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark06(-0.10500208274490493,-0.7849811800649754,-27.49690391807036 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark06(-0.10512045095734836,-1.5707963239383407,-51.16514742445816 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark06(-0.10529070790347829,-2.1684043449710089E-19,-1.570796326794893 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark06(-0.10571389656519128,-1.4205879764476566,95.60917464141986 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark06(-0.10638867659812234,-44.07717804084768,-110.41106207994744 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark06(-0.1097513897098517,-1.5707963267948912,29.04023964598712 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark06(-0.1099024612831563,-0.42688985627733,696.6406906231138 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark06(-0.11008045470394823,-8.221052086542798,-65.19444237884328 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark06(-0.11076367828640332,-44.16434818789696,-109.3883470212979 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark06(-0.11086944440146641,-1.3938755430079914,-1.5707963267948966 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark06(-0.1109009974281,-1.3162178531655084,1.5707963267948963 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark06(-0.11118857070359356,1.3552527156068805E-20,31.44400792313573 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark06(-0.11203346940590045,-1.5707963267948966,6.71238940696918 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark06(-0.11245704217890681,-1.2368402938736311,-7.861794181855788 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark06(-0.11247614327222699,-8.881784197001252E-16,-1.3460611912572205 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark06(-0.11359413352121467,-1.5707963267948966,-59.08159410976406 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark06(-0.11382507091483694,-8.673617379884035E-19,38.02675585662584 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark06(-0.1143492018286802,-1.5707963267948966,27.8562097549068 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark06(-0.11478537609067464,4.0389678347315804E-28,-1.5707963267948974 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark06(-0.11585389916234634,-0.3697508047741701,-1.5707963267948966 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark06(-0.1164262652856735,-37.87511918030711,-39.750596854501154 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark06(-0.11707189327818668,-1.5707963267948966,17.011259834379082 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark06(-0.11720283151564752,-3.3881317890172014E-21,-1.5707963267948983 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark06(-0.11781043908018932,-89.77115202096009,-65.5912089356452 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark06(-0.11793315519976859,-0.5387244180503427,-1.5707963267948966 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark06(-0.11849096425686007,-38.84194584622515,-12.943539638270206 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark06(-0.11860685769907799,-1.344810711532157,-69.6000259937406 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark06(-0.11972701711893485,-0.1505419402304231,1.0959046745042015E-193 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark06(-0.11994483797855546,-1.7763568394002505E-15,4.837388985569994 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark06(-0.12120882458191379,-1.5707963267948966,72.25663150946035 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark06(-0.12129964677044072,-1.3070103095112522,-1.5707963267948963 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark06(-0.12150970156707075,-76.97976481684618,-45.23762594316872 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark06(-0.12168282831884536,-44.310936424082094,-72.45287221309472 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark06(-0.12224044599144623,1.570796326794897,0 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark06(-0.12266391072815165,-6.2565096724471904E-148,-19.565550306995263 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark06(-0.12282921416330073,-1.5707963267948966,-44.8080218329144 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark06(-0.12305986305108751,-1.5707963267948966,1.5707963267948968 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark06(-0.12323692689777524,-1.5707963267948966,-32.21250551403408 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark06(-0.1237063267574221,-0.16711697297740097,112.84176437638263 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark06(-0.1244488739270116,-0.49206006286716786,-7.692831299205232 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark06(-0.12450335980859212,-1.1975111732773769,0 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark06(-0.12488686099158253,-0.46133438453773934,-6.712397599715948 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark06(-0.12576953982984307,-7.867835011547456E-16,1.5707963267948966 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark06(-0.12595698878115869,-0.0825199827555752,92.46779511771845 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark06(-0.12664220842608456,-1.734723475976807E-18,-19.991747609720566 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark06(-0.12698772356869026,-1.5707963267948966,-31.74370496931825 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark06(-0.12723241789089634,-1.5707963267948966,-93.5961071044835 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark06(-0.12861634621367557,-1.5707963267948966,-36.96268666412888 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark06(-0.1293297898338448,-1.5707963267948966,-0.52641852138145 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark06(-0.1294042458184807,-1.5707963267948966,-4.744214177620753 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark06(-0.13057475868045687,-32.610752429240705,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark06(-0.1310290782892811,-1.5707963267948983,-776.2342304701867 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark06(-0.13107059642428032,-100.99669763891474,-1.5707963267948966 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark06(-0.1315351894617106,-1.5707963267948966,-62.62311943283893 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark06(-0.13262290696885004,-95.47907613766888,-35.23304701393185 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark06(-0.13274464681844964,-1.5707963267948966,115.61685051557856 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark06(-0.13324753284850802,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark06(-0.13350640401687344,-1.5707963267948966,-0.9253982768821548 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark06(-0.13421972935439122,-31.452820658798558,-79.1997100707942 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark06(-0.1348444163259292,-1.5707963267948963,-3.1415926604820354 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark06(-0.1362456781259856,-0.15090984322501022,-56.33643615896773 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark06(-0.13634880255220944,-0.16596092206317964,76.88239788817488 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark06(-0.1372533280208334,-1.5707963267948966,-33.924552431174334 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark06(-0.13739673245638562,-1.3430833152792863,166.76298811527698 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark06(-0.13765543486247325,-44.43714424186923,-77.27864354918661 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark06(-0.1381262227281338,-1.3002266873290347,3.141592653589793 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark06(-0.13871754564128336,-1.5707963267948966,728.0146386563573 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark06(-0.13891296449744245,-3.4730605460704336E-164,-1.5707963267948966 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark06(-0.1393303930847422,-95.56572593503849,-31.951907929727884 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark06(-0.13940335336771909,-44.99169495209952,-179.17826947593161 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark06(-0.13975369730203263,-0.8572518133615482,-2.57079632641701 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark06(-0.14005636646405084,-1.5707963267948966,16.236125775490024 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark06(-0.14105994895654286,-0.30808124619319566,-10.674206488643819 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark06(-0.1413009785140551,-3.1415926536734986,-97.66380167738683 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark06(-0.14188611416834995,0.0,0 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark06(-0.14223175778822755,-1.5707963267948966,-31.728339577443776 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark06(-0.143312870192618,-38.93478505560131,-16.46894522929311 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark06(-0.14356744938614985,-1.5707963267948966,-94.2477796076938 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark06(-0.14380998083362095,-1.5707963267948966,9.860761315262648E-32 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark06(-0.14426667578442356,-0.16792862048575147,3.1415926535897922 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark06(-0.14438941596560978,-1.097053932003429,1.5707963267948966 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark06(-0.14525778732688005,-0.22462673087098883,-100.0 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark06(-0.14570422769171232,-0.6036906773097588,100.0 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark06(-0.14570538889674445,-1.5707963267948966,35.51705773187181 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark06(-0.14630021327457143,-45.08379953975982,-498.57035865858376 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark06(-0.1465234297795821,9.871764782444434E-4,-15.089676698734664 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark06(-0.1466658487322675,-1.569135308514987,104.51974709449325 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark06(-0.14690877478443112,-19.349555922422173,-1.5707963267948966 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark06(-0.14837131515751917,-1.5707963267949034,954.3779832904961 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark06(-0.1489495689843825,-95.77155685840899,-78.9281345632587 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark06(-0.14908004834744462,-0.23218878578290705,-46.297622610103026 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark06(-0.1494213948571282,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark06(-0.15085845753842375,-32.75322884479222,-2.570353414465273 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark06(-0.15232696514491678,-1.5707963267948966,-89.28437754606757 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark06(-0.15243788229423919,-95.25537815632232,-1.6332981940419462 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark06(-0.15261718076157746,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark06(-0.1527009029574297,-1.0995712542231761,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark06(-0.15635653026509588,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark06(-0.1569379240585771,-1.5707963267948966,47.1238898038469 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark06(-0.15750772375154432,-1.5707963267948966,-13.236091795390164 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark06(-0.15770786082617327,-0.2741914904243179,1.5707963267948966 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark06(-0.1589696897619637,-2.220446049250313E-16,-50.38270131710196 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark06(-0.16092707621908617,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark06(-0.1633929908949776,-1.5707963267948966,61.73906999254435 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark06(-0.16353517737367332,-1.510600606644404,1.5870957711007343 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark06(-0.1640790516571945,-0.8410784956434585,-97.90862409167491 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark06(-0.16415368972379119,-0.8933246630848076,-53.9281804317083 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark06(-0.16474573032472772,-0.14014845807042842,-7.7310469401970465 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark06(-0.16598435742754203,-0.1520235949691735,7.853981622066072 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark06(-0.16606380762429573,-1.5707963267035,93.65359232741685 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark06(-0.1665895973621656,-1.4170198942778625,-54.30922999637098 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark06(-0.166932499157111,-0.5616564376535624,14.588720167046914 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark06(-0.16830908509305464,-1.5707963267934821,-123.87873493941554 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark06(-0.1690057342448803,-1.5707963267948966,77.4537368001883 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark06(-0.16915727677219056,-0.07536596416194463,41.730060021698534 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark06(-0.1694367914230952,-1.5707963267948966,-5.328084742572415 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark06(-0.16988903487601448,-0.2534276308002523,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark06(-0.17081496800918175,-1.5707963267948966,-36.76839739922422 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark06(-0.17089839705705484,-1.5707963267948966,43.5864146738665 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark06(-0.17094064620587268,-1.5707963267948966,-0.773809439957148 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark06(-0.17094123151116183,-1.2466388293948631,7.861922492028141 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark06(-0.1721411273211819,-3.552713678800501E-15,1.5707963267948966 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark06(-0.17251160692819067,-227.6924025543919,-64.38679763690598 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark06(-0.17267224196624,-1.402915344920438,-46.5432695423905 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark06(-0.17327983009994286,-1.5707963267948966,-45.020578387562935 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark06(-0.1738179895822446,-1.5707963267948966,59.60295012786659 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark06(-0.1742137082129062,-1.5707963267942588,-13.656718777909322 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark06(-0.17498290250677867,-1.5707963267948966,4.822079779437246 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark06(-0.17544021151694267,-45.522569968112975,-146.19425928165228 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark06(-0.17553169756888193,-1.5707963267948966,40.05901433914914 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark06(-0.1767391624092746,-1.82877982605164E-99,0.0 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark06(-0.17808537216541623,-1.375447977498446,-27.930533970659894 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark06(-0.1782813452181097,-0.7880073645304735,90.50773342849169 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark06(-0.17861698310660623,-0.2858129595390295,-1.5707963267948966 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark06(-0.1794844930043408,-1.17137292497444,-0.08498550769337498 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark06(-0.18037713929685853,-1.5707963267948966,-45.355613577229086 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark06(-0.18078533913931563,6.712388980384691,-7.330391288194517 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark06(-0.18174479856597647,-1.5707963267948966,-87.55200329017391 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark06(-0.18197574502094732,-31.95221569541028,-45.168566653688494 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark06(-0.18217456415309982,-1.5707963267948948,-6.119213231318413 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark06(-0.18349186165048784,6.712388980469959,-9.945474852363255 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark06(-0.18426727263773982,-1.5707963267948966,-57.341536090912754 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark06(-0.18430749611854624,-1.5707963267948966,57.994838110575444 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark06(-0.18463633358942458,-44.13065000069081,-403.50670043927613 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark06(-0.18551869961587877,-0.1992035396908271,48.8388591579631 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark06(-0.18606205545773336,-11.969249455850122,0 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark06(-0.18618651414089005,-1.5707963267948966,-26.627538080022973 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark06(-0.18629961326545919,-1.4930737642605294,-99.69620136571125 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark06(-0.18670997155127722,-1.570796326794972,147.28631084536107 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark06(-0.18768670375539193,-0.9439805292635307,-5.436076263970774 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark06(-0.18835892383873581,-1.5707963267948966,43.88019372443878 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark06(-0.18955987477552422,-0.7526946541696207,58.69397962041566 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark06(-0.1902269911190612,-1.5707963267948966,54.38027220937781 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark06(-0.19023752582009296,-1.5707963267948966,52.53794079355002 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark06(-0.1914797053681186,-1.5707963267948966,-80.47340983559084 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark06(-0.19172921571153267,-1.3591966066227523,-27.126867460528025 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark06(-0.19287783493900693,-1.1055593943521558,-43.02415162779567 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark06(-0.1933941764226248,2.465190328815662E-32,33.98083669058196 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark06(-0.19392776243217247,-1.5707963267948966,-34.861276793423734 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark06(-0.1940851400306936,-1.5707963267948966,-9.4422775287168 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark06(-0.1943237416585999,6.712388980384721,-2.4301052128291243 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark06(-0.19454073327129412,-1.5707963267948966,42.63755711310521 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark06(-0.19649168063469125,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark06(-0.19678144389510802,-1.5707963267948948,-77.29511079145679 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark06(-0.19804761182939412,-2.220446049250313E-16,-16.137178179676454 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark06(-0.1985980828603546,-1.3729158176478546,26.453657148250464 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark06(-0.19884950332544438,-3.522101828684134E-133,-32.51500356991052 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark06(-0.1988497595706975,-1.5577705187361837,-88.13141747008765 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark06(-0.19934363341870565,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark06(-0.19961147541876853,-31.740074187271404,-59.8080143009047 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark06(-0.19968469959280713,-1.5707963267948966,88.27493308970318 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark06(-0.19977343155800012,-3.141592653594456,-1.1088949532863832 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark06(-0.20030643467586673,-95.56060703169929,-28.01716520911658 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark06(-0.2007448292257139,-1.5707963267948912,24.983003424839083 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark06(-0.20129477377089555,-1.3140086039226642,-128.84911574292295 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark06(-0.20151052641386685,-1.5707963267948966,66.7458653541934 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark06(-0.20188043758560895,-1.5707963267948966,-21.21798910014825 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark06(-0.20214086905078868,-1.5707963267948966,-121.7484334924271 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark06(-0.20320588736063883,-1.1268873039784904,61.66863321279732 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark06(-0.20372113771411388,-1.5707963267948966,2.3647604758496326 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark06(-0.20454277651282116,-0.9425985886629871,-0.7956779940687744 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark06(-0.20685731683505595,-1.5707963267948966,56.47722607764672 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark06(-0.21127501135971016,-1.5707963267948966,25.5911996852293 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark06(-0.21132377492911816,-4.2351647362715017E-22,10.883861513779806 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark06(-0.21167505129173048,-1.3133431494124335,-62.03467354003791 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark06(-0.21218096791162602,-0.10238312450545517,-33.409092521231116 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark06(-0.21225318056892398,-1.3843542330550607,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark06(-0.21333145606577864,-1.5707963267948966,-74.9007901195634 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark06(-0.21347134175147425,-1.5707963267948966,-4.583088615089714 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark06(-0.21396868089954202,-0.8227857907089344,5.4785169915753045 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark06(-0.21564507505703845,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark06(-0.21597359810932487,-1.5707963267948974,-158.6487480035325 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark06(-0.21703294441727472,-8.881784197001252E-16,-79.52486418257476 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark06(-0.21813519777218252,-1.5707963267948966,-44.18608157406655 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark06(-0.21847283996091882,-3.141592653598418,-157.2077492371768 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark06(-0.21848509613777292,-45.18479237651208,-3.141592653589793 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark06(-0.2188769211363759,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark06(-0.22018374288125742,-1.5707963267948966,-32.70302855727178 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark06(-0.220302661656841,-95.61338416477585,-44.440949068385805 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark06(-0.22052112601420276,-0.9077126410851981,-53.75528675411208 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark06(-0.22059965447480595,-1.4173484484054013,-63.86847345689741 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark06(-0.22097934796582966,-1.5707963267948966,-1.5707963267948968 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark06(-0.22112678363829683,-1.5707963267948966,-58.42788429870138 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark06(-0.22166634155995235,0.0,100.0 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark06(-0.22237395098678628,-1.955159272639747E-149,36.79482159227966 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark06(-0.2239164183769924,-45.12010994772981,-1.5707963267948966 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark06(-0.22472886831123784,-1.5707963267948966,44.713549667554986 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark06(-0.22562553678647568,-1.5707963267948966,35.64429117528428 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark06(-0.22655228342057787,-157.4413008778683,-100.58512908297443 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark06(-0.2271827696323202,0.0,0 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark06(-0.22726516123219853,-0.23836868898938746,-90.76327938666728 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark06(-0.2280981378122391,-31.59995207826983,-113.28848989395756 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark06(-0.2281952953910126,-1.5707963246163528,1.4023589701769403 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark06(-0.22926072436450196,-1.5707963267878198,72.43704288426704 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark06(-0.22931463919354902,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark06(-0.22949254517004275,-1.4147686831863606,68.25951565192175 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark06(-0.2298613813249637,9.860761315262648E-32,0.0 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark06(-0.23080095198615863,-1.43470854724927,-62.153794667514696 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark06(-0.2309563235327563,-1.5707963267948966,-0.7142517477693531 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark06(-0.232565851626777,-0.06034316347061647,58.61167221627011 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark06(-0.23264752675886874,-1.5707963267948966,-12.780380194599616 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark06(-0.23274086799982907,-2.350988701644575E-38,88.28390487626623 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark06(-0.23359494913998732,-1.5707963267948966,-64.94502092517826 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark06(-0.23391729743100598,-0.7068288507392944,101.03330962312283 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark06(-0.23398786523844523,-0.985195332239245,-43.14183489760235 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark06(-0.234042213413856,-1.5707963267948966,5.9612893362694985E-15 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark06(-0.23461427827982553,-8.881784197001252E-16,2.0590230357872116E-84 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark06(-0.2347176141913827,-1.5707963267948966,44.186740836878215 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark06(-0.23530555123240227,-32.640124798713764,-9.248282728884178 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark06(-0.2359965595673101,-32.76414886801964,-3.141592653589794 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark06(-0.23657687567309685,-1.5707963267948966,39.11212455223053 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark06(-0.23694528766208478,-100.97065787495085,-3.2677115641217993 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark06(-0.23701263102871728,-1.5707963267948521,-78.60898559147829 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark06(-0.23770935380320868,-1.1948789150982457,-1.5707963267948983 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark06(-0.23792420630361022,-0.2373298965771104,-12.520608359404633 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark06(-0.23816319796022112,-0.1871905822524551,-83.48837437238045 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark06(-0.2391977705369135,-3.1415926535897936,-0.0759755576843757 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark06(-0.23939499018598723,-0.7405632579173071,0.0 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark06(-0.23950751954692473,-1.5707963264638638,-67.7172999209151 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark06(-0.24049114865017518,-1.561293714440077,0.0 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark06(-0.2411428266845681,-157.5834072508686,-1.5748842580428482 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark06(-0.24131173165544184,-0.7660076765557502,-37.70289046920547 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark06(-0.2423133625218277,-0.8280062106511124,65.84049512639504 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark06(-0.2428045937729273,-0.17173451925795824,-31.415926538952007 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark06(-0.24296175945997392,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark06(-0.24335023100123224,-1.135724485925679,1.5707963267948966 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark06(-0.24412608855074455,-1.5707963267948912,39.000840787308746 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark06(-0.2444895430840679,-88.44127438415867,-13.717441423052065 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark06(-0.2458818730423426,-1.2811715801405765,-1.5707963267948966 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark06(-0.24666428267144286,-88.30971819312607,-1.5707963267948966 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark06(-0.24790977852624962,-0.4434052289942348,21.825796170097597 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark06(-0.2480225313282134,-1.5707963267948966,52.87458984732217 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark06(-0.2488292959914344,-1.4303581704120365,95.0700408268644 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark06(-0.2490755029270887,-1.5707963267948966,88.26714399846244 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark06(-0.25029468958729545,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark06(-0.2507813748929295,-44.02895712264731,-94.94489213531841 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark06(-0.25078154547948683,-45.240919586478846,-2.5442226685002307 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark06(-0.2511113778382801,-4.815372679814004E-5,-102.34025687378617 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark06(-0.25130511716081366,-1.2431609144948605,53.46030428085945 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark06(-0.25237676689582217,-1.5707963267948966,-5.403227209783267E-225 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark06(-0.2530626643155425,-1.0677076007971036,-1.5707963267948963 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark06(-0.2538302391762661,-3.141592981491747,12.854688569962583 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark06(-0.2544138034453973,-31.648156246736605,-35.66567182347198 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark06(-0.2544341794062972,-1.57079632679489,0.49905618263811524 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark06(-0.2551750303898455,-1.5707963267948986,-0.5153764542293265 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark06(-0.25536227962657454,-0.2934371544411605,-74.41978271069168 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark06(-0.25566263981746334,-1.5707963267948966,36.24940471202282 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark06(-0.25731206849034644,1.6940658945086007E-21,-36.868957758297356 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark06(-0.257662598982065,-45.12465543488704,-532.0958823067638 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark06(-0.25780471519071213,-31.927591299387384,-73.34832890943669 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark06(-0.25999506199305844,-3.1415926537334222,100.0 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark06(-0.26020626360223914,-1.5707963267948966,17.48737972458086 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark06(-0.26089739598369704,-0.8981359583073413,-4.7436390159595225 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark06(-0.2611475453141452,-19.401345682088994,-67.4086808264577 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark06(-0.26365592281053846,-6.776263578034403E-21,-23.703701030993955 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark06(-0.26407672288790135,-1.5707963265884453,1.053498615642685 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark06(-0.26420100411511904,2.465190328815662E-32,43.88705284370377 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark06(-0.2649994095864768,-45.41865389319164,-1.5707963267948966 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark06(-0.2659743446311953,-88.08959729875218,-100.93350802242294 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark06(-0.26615851281004477,-1.5707963267948961,32.953292700173584 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark06(-0.266570913751275,-31.415926543751656,-13.754554591039932 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark06(-0.26705710074799177,-1.5707963267948966,8.891191569829388 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark06(-0.2670753258156646,-1.5707963267948966,-47.187806748588 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark06(-0.26771503843286837,-88.31734403400515,-2.48396545856761 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark06(-0.26855219693840227,0.0,0 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark06(-0.2688960685277606,-1.213162743170137,-1.4531986712100111 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark06(-0.2696094602689718,-38.877303222035785,-32.739195110531085 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark06(-0.27123632328165664,-1.5707963257906712,-27.293542774244692 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark06(-0.2716550864773329,-1.5707963267948948,0.0 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark06(-0.27308709457678076,-95.75781582783974,-14.236716653794574 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark06(-0.2735331914029621,-1.2882740942700714,-21.429568603297525 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark06(-0.274263482162396,-1.5707963267948966,82.30832202976046 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark06(-0.2742799746501452,-91.16244581551129,0 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark06(-0.2754768571213603,-44.17969187302565,-1.5707963267948977 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark06(-0.2766508639414673,-1.5707963267948966,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark06(-0.27682201384879,-1.5682666303355302,-1.5707963267948966 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark06(-0.27758735010257574,6.712388982697045,-23.129784038640317 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark06(-0.280086807969853,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark06(-0.2811070923157999,3.469446951953614E-18,-59.086691914850846 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark06(-0.2819383690508071,-1.5707963267948966,72.85362012443828 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark06(-0.28200134808628263,-31.4812667162506,-3.1415926580739577 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark06(-0.28339113865941806,-1.5707963267947485,-45.27114230292081 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark06(-0.2850706934524929,-0.980259922574849,-25.134646368212945 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark06(-0.2855610780241003,-1.5707963267948966,-344.4629437266044 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark06(-0.28569992937530464,-1.5631371581929863,36.323067505464046 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark06(-0.2863066375314949,-44.4376489960058,-6.8787719491948 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark06(-0.2863982856880057,-1.5707963267948966,-63.788214259969315 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark06(-0.28754224099450354,-3.141592653864399,0.5967550639801187 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark06(-0.287822100685182,-37.69911184307752,-1.5707963267948966 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark06(-0.28791991928517124,5.4241083589651955E-14,0 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark06(-0.28823650629994724,-0.6535974977063681,88.27164743769532 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark06(-0.2889485169981031,0.0,0 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark06(-0.28902225607907184,5.551115123125783E-17,1.0710461415675652 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark06(-0.28955715794639353,-0.059114922073982355,8.881784197001252E-16 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark06(-0.2902678215353428,-1.5707963267948966,-90.80910649548677 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark06(-0.2905435111140686,-1.5707963267948966,-11.861275606488803 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark06(-0.2918594445436273,-1.8367099231598242E-40,-23.075026264344803 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark06(-0.2920925100420993,-1.4537636017823958,6.554703089508649 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark06(-0.2921160118549405,-0.5280224910625615,22.06385860099725 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark06(-0.29256691718024475,-0.49204052258193254,-2.803407633211947 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark06(-0.29280480431297495,-0.7278795259924067,-93.79584965878716 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark06(-0.2928697006241503,-1.5707963267948966,72.05957609585698 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark06(-0.2937307198563508,-1.5707963267948966,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark06(-0.295247195411561,-0.9791010224320126,-66.45724959448049 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark06(-0.2953154364584367,-0.036136108966753566,17.99327249662521 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark06(-0.29568635732867404,1.3877787807814457E-17,88.16658609280962 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark06(-0.2959365727755257,-0.9557411089644603,-75.40779318918962 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark06(-0.2960399991739891,6.938893903907228E-18,1.5707963267948966 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark06(-0.29741449571330425,-1.5707963267948957,91.73126838138589 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark06(-0.2975470471419914,-0.2504847628736351,-16.352119808742557 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark06(-0.2978901177728517,-1.5707963267948966,-185.2187372077941 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark06(-0.2983730578470288,-1.5707963267949019,0.0 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark06(-0.29852950491740665,-37.81428905978977,-53.01243694805711 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark06(-0.2992733210543625,-95.43216014916396,-216.7440826825113 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark06(-0.29955898256146574,-1.5707963267948948,-0.5707468178868572 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark06(-0.30086617530875404,-31.425671923016864,-1.5707963267948983 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark06(-0.30129178917544347,0,0 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark06(-0.30163421314614064,-1.5707963267948966,15.18928494633087 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark06(-0.3020566775651332,-0.8057840177541695,-713.9925539428723 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark06(-0.3023150777999628,-1.2346365811679334,-86.2906218573361 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark06(-0.3033728489979168,-1.037493380229655,441.39453041168485 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark06(-0.3035452476555921,-1.5707963267948966,55.45406940221004 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark06(-0.3049432367409999,-1.1343321615640178,48.50708617769864 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark06(-0.3049561065984851,-0.6558607445009476,4.71238897828644 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark06(-0.305060909588452,-157.1527134805981,-34.035465243784586 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark06(-0.3051463808151106,-1.5707963267948966,-1.571772889298838 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark06(-0.30525115007633186,-45.16585332723348,-56.774422606644706 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark06(-0.30543593287744913,-0.4558310742505379,-52.249095851652775 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark06(-0.30546697010923013,-1.5707963267948963,-39.212911884032515 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark06(-0.3073840453864487,-0.3147352192578099,-80.27882510158575 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark06(-0.30959114609830163,-3.141592653744519,-70.05469659462712 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark06(-0.31018075106065846,-88.2029146312213,-83.85667564370091 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark06(-0.31023009100445814,-1.1914927437265543,91.64072306454226 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark06(-0.31049630452642973,-1.5707963267948966,-20.981575797835955 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark06(-0.3107214610956878,-0.35129674096386054,10.627313316527264 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark06(-0.3108983758575228,-1.5707963267948966,14.80091663235737 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark06(-0.3110342434152944,-0.045712534522715176,2.038670915076831 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark06(-0.3118626527090296,-1.5707963267948966,28.09902962640565 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark06(-0.3120646353817511,-1.5707963267948983,-89.84073855299644 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark06(-0.3121677596353667,-1.5707963267948966,16.34794887961496 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark06(-0.3128167724617187,1.0842021724855044E-19,10.601387609338568 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark06(-0.3129285386389172,-1.5672622124188096,58.83168056372115 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark06(-0.313404761032415,-1.5707963267948966,20.83337752074263 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark06(-0.31412376745882875,-1.5707963267948966,-79.94755059910563 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark06(-0.3141278694663574,-0.32532609413626573,-3.141601408287873 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark06(-0.31437618527273603,-1.5707963267948966,14.770223402010899 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark06(-0.31552021886168974,-1.1578107927058046,-20.505713160398503 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark06(-0.31661427552120197,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark06(-0.31710365000201035,-95.6733406357376,-1.5707963267948981 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark06(-0.3172654850725101,-1.570796325586084,-90.9914001453317 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark06(-0.3172792423719022,-88.31905783099434,-6.663504542891044 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark06(-0.3186148107462847,-32.630047152018044,-83.13638525242887 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark06(-0.3200656538864541,-94.2477796076938,-1.9298003528331549 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark06(-0.3203402956684662,-0.9576477662070333,72.78063396929993 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark06(-0.32101599252752955,-1.5707963267948966,-43.441355937878754 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark06(-0.3213090020810019,-1.3882041361434672,-71.64858700074885 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark06(-0.32189230992618806,-1.5707963267948966,-71.26778946670575 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark06(-0.32337110667099705,-4.150059579353189E-5,-27.822696353885075 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark06(-0.32421437035039635,-1.5123897084408864,1.5707963267948912 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark06(-0.32452619045034303,-44.444404680046375,0 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark06(-0.3245671075089498,-1.5707963267948966,-41.24914594009148 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark06(-0.32475815526789764,-1.5707963267948966,-71.8166890950385 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark06(-0.32497187365759383,-1.5707963267948963,44.54465936046381 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark06(-0.32556964596052207,-1.377688485764478,79.1818099741384 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark06(-0.3257331381182531,-0.6333731464827765,-1.5707203479962608 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark06(-0.32596631543649174,-1.5707963267948957,73.716112253895 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark06(-0.3261530009416785,-0.21535747662329052,53.779475753306045 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark06(-0.327077651591257,-0.1441505330325461,51.50703115688668 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark06(-0.32763202301954664,-102.10168629766748,-27.29624389289368 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark06(-0.3282647263299772,-2.2607522210049696E-16,77.63356539952119 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark06(-0.33052205649284616,-0.10610788141536576,-42.22983847105085 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark06(-0.33073740206735963,-1.5707963267948966,14.704708738328478 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark06(-0.33082648021753175,2.465190328815662E-32,-68.37972114370082 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark06(-0.33187986153336446,-32.517261454675534,-133.57872388909064 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark06(-0.3319653124570658,-1.5707963267948966,-10.995603094273399 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark06(-0.3324938812551389,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark06(-0.3328508311636498,-8.673617379884035E-19,-69.37873597480126 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark06(-0.3334744256567026,-1.5707963267948966,2.125697071077142 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark06(-0.3338155577359753,-21.679304491468017,-15.146366390975048 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark06(-0.33429142934999456,-1.5707963267948963,4.141593475830734 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark06(-0.33470438348335646,-101.93236905806637,-9.995594094730716 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark06(-0.3351179472154904,-1.5707963267948983,-3.578743840584849 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark06(-0.33640229485072193,-38.785663813207904,-42.288700353084074 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark06(-0.33647310403179415,-1.5707963267948912,-15.707963267948966 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark06(-0.33658838782430134,-1.242354337022019,5.776748613528146 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark06(-0.33712441957909434,-157.09672867368783,-20.423910733515854 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark06(-0.33776108218265954,-88.1094109477738,-103.1619589103303 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark06(-0.3377781253476866,-157.62230706130495,-1.5707863474828285 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark06(-0.33799142581030367,-1.5707963267948983,75.0651191193825 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark06(-0.3382221307185107,-0.8914879146109758,373.84926130321406 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark06(-0.33935517805099913,-1.5707963267948983,-163.73943731966654 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark06(-0.33958134684407426,1.6155871338926322E-27,91.40358711483461 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark06(-0.34031160916727654,0.0,0.0 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark06(-0.3409491200433852,-37.82131055562576,-97.87005140161102 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark06(-0.34164535429814924,-1.5707963267948966,-0.7550641005557122 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark06(-0.34219796587446516,-1.5703470165183235,-80.11101498099853 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark06(-0.34249590957032816,-94.32346083442563,-51.11980521822252 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark06(-0.3430555694978654,-1.5707963255543387,3.3189258056391253 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark06(-0.34401103094221996,-0.08209978593349293,9.687223725713977 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark06(-0.34459411457824135,-0.8958998858848656,-0.5583530847686333 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark06(-0.34483171902762927,-0.07776257656713507,-72.61190808018614 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark06(-0.3451305428378287,1.3234889800848443E-23,-0.9532456533791264 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark06(-0.34550976602007444,0.0,33.83133367106386 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark06(-0.3458735146990297,-101.99851769123097,6.712490712642093 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark06(-0.3468618676489427,-1.5707963267948963,-1.5707963267950107 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark06(-0.34715861807971393,-1.5707963267948963,1.5707963267948966 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark06(-0.3479058479644097,-1.5541146767938552,-3.1415927322812562 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark06(-0.3484466169010254,-1.5707963267948966,-32.78721930855023 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark06(-0.3487732838461053,-1.3874704506163447,-12.070799532601246 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark06(-0.3489790517786968,-1.5510307975705526,-24.26879283765453 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark06(-0.3498286625615912,-1.5707963267948966,10.505546828832095 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark06(-0.3499672106695577,-88.11987743637496,-31.644873096050155 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark06(-0.3511280731623727,-1.3516505661028384,4.743638998971856 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark06(-0.35116637120881006,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark06(-0.35169185172595446,-1.1064853138921462,-31.41592653589793 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark06(-0.35172662292077916,-0.7578466869843744,-84.57144594255584 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark06(-0.35252567962467474,-95.61417765047239,-2.2465617119745245 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark06(-0.3525614145364315,-1.5707963267948957,-65.66623892522789 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark06(-0.3526270990778706,-1.5647531641549435,1.5707963010818697 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark06(-0.35273679507405925,-1.5707963267948966,67.97654061982732 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark06(-0.35283344680473777,-0.9801786477994169,-0.5509622752401024 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark06(-0.3531857458755118,-31.887362534225808,-2.830337174881972 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark06(-0.3571957326275683,-31.415926624082225,-66.44210966595925 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark06(-0.3579615564353904,-32.69515957314174,-22.039582179850534 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark06(-0.35920517783012507,-32.47873047928928,-101.51666131420492 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark06(-0.35943602968716365,-1.5707963262978053,73.57414776819539 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark06(-0.3599938296504075,-95.29405646997442,-1.5707963267948974 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark06(-0.3601052788470791,-32.9481444323184,-1.5707963267948983 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark06(-0.3602669797920753,-1.5693761029933209,84.68640051676451 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark06(-0.3605917208356774,-0.39309364607281905,14.27516308742689 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark06(-0.36130784709097874,-1.5707963267948957,-90.86930264803726 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark06(-0.36159832166156836,-1.5707963267948966,26.826779362542425 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark06(-0.36187443128452124,-1.5707963267948966,-19.373618623402123 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark06(-0.36214828255371545,-1.5707963267948966,52.35386729254114 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark06(-0.3624703261749187,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark06(-0.3626499676766858,0.0,0 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark06(-0.36286154729829434,-0.15641913503743288,-216.7682154704077 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark06(-0.3631701415367202,-0.4797283487959181,-45.94226472139937 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark06(-0.36414579278112114,7.853981633690583,-45.1334520558399 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark06(-0.36458991574109234,-1.5707963267948966,20.188403227063205 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark06(-0.3658491849890133,-1.5707963267948983,-49.670230278174 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark06(-0.3666160730264274,-1.4914078133329518,1.6118514653187668 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark06(-0.36670087121629713,-1.5707963267948966,-4.31173476906595 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark06(-0.36696606547624816,-95.41540692349619,-64.41873396552502 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark06(-0.36863786841351887,-1.5707963267948966,-23.844754495730225 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark06(-0.36890310005085536,-1.0497932620886397,0.022435095831757956 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark06(-0.3696547102416694,-44.36880511443534,-15.380577028421058 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark06(-0.37052802206494295,-158.62693811202985,-26.08526488082444 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark06(-0.37118706125813006,-44.2709131068186,-46.010750498481656 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark06(-0.37186525664846215,-1.5707963267948948,-100.0 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark06(-0.3734411306266025,-1.5707963267948966,30.141513253269768 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark06(-0.37361591845367836,-1.5707963267948966,136.89566733442518 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark06(-0.3744401886113309,-28.469702870773858,0 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark06(-0.3760850997956815,-31.75135960854155,-1.5707963267948983 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark06(-0.37670034068084846,-0.10009849423831842,12.114866468554666 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark06(-0.3770955519238772,-1.5707963267948966,18.03506056552729 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark06(-0.3773345696320843,-7.516557023293925E-9,-8.206221110007377 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark06(-0.3783505887437633,-0.5010862675190676,15.707963267951344 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark06(-0.38008342871358275,-1.5446024898591983,2.020645577089411 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark06(-0.38067410528631096,-0.9822849769321879,80.77390931699878 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark06(-0.3815077275451248,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark06(-0.38157347071520453,-1.5707963267948966,34.29008762824058 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark06(-0.38164586570698034,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark06(-0.3825007249210637,-32.727415932383956,-45.359967759189196 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark06(-0.38273105117530726,-1.5707963267948966,11.862893974924985 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark06(-0.38339398817782455,-1.5707963267948966,55.398164355901514 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark06(-0.3850102539020752,-44.04587027820535,-38.933209589277844 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark06(-0.3851215304805691,-0.14513305513411723,-13.458044622656764 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark06(-0.38757043383937706,-1.5707963267948912,-24.436996129141917 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark06(-0.3881546922336504,-1.7763568394002505E-15,-88.25196895757786 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark06(-0.3887294943982601,3.3881317890172014E-21,-2.2033546668481137 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark06(-0.389459674258063,-0.9118824438915386,72.64557351609625 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark06(-0.3895280318631005,-1.4809012158027948,-6.043954072149912 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark06(-0.39028169029304516,-1.5707963267948966,33.723821277199605 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark06(-0.39079937232694567,-1.5707963267948966,-57.16589586027785 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark06(-0.3912738161233307,-1.4882043715921114,1.5707963267948966 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark06(-0.394342208461373,-1.5707963267948912,9.981860762468694 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark06(-0.39434298706882487,2.465190328815662E-32,55.251176894890875 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark06(-0.3944709587996089,-88.26114444836402,-10.891454777095083 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark06(-0.39621020228407783,-1.5707963267948912,-123.99763065480747 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark06(-0.39626662084774394,-1.5707963267948966,1.5707963267948963 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark06(-0.39748335498267395,-32.66602119600806,-10.740387529221339 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark06(-0.39805889973680075,-1.5707963267948912,26.161624818081307 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark06(-0.3981757900861888,5.551115123125783E-17,1.5707963267948948 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark06(-0.3984543057277323,-1.5707963267948966,-0.9425974435453113 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark06(-0.39916585017798023,-1.5707963267948966,94.31803543964205 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark06(-0.40000256558799946,-95.68641424698288,-10.86744093179905 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark06(-0.4011297652647745,-45.28702917750219,-2.393826426296985 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark06(-0.40130570374134095,-1.570796326794897,-298.45117961725373 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark06(-0.4018958107633464,-0.8270657497391126,67.15475255591076 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark06(-0.4023971484260384,-0.5545546861742248,34.652918528018496 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark06(-0.40281334267287433,-1.5707963267948912,-31.47667948084442 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark06(-0.4031457359185983,-157.63148929843476,-6.701865071957161E-5 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark06(-0.4036577978399747,-7.105427357601002E-15,-65.84312664943302 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark06(-0.4055886530466326,-1.5707963267948948,0.0 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark06(-0.405861899284086,-1.5707963267948966,36.3861453719752 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark06(-0.4066146610777366,-1.570796326794896,163.373775595587 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark06(-0.4074821695367383,-1.5707963267948983,-1.5707963267948957 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark06(-0.4128388461256091,-3.552713678800501E-15,-88.40903137491246 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark06(-0.41403828675304055,6.776263578034403E-21,-0.7774563936224577 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark06(-0.41441456532293003,-1.5707963267948966,31.7921831429953 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark06(-0.41454391789726364,-1.3189222127703095,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark06(-0.41515810564974176,6.712388985849349,-43.992497979734665 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark06(-0.41654287861284595,-1.5707963267948932,-100.0 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark06(-0.417040745586533,6.712388980384691,-72.62176515452242 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark06(-0.41769660808753883,-1.5707963267948966,36.03743380602001 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark06(-0.4189496500933356,-76.56386105237958,0 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark06(-0.42114989938414443,-83.33773524084276,-64.34460937849613 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark06(-0.42281397506950924,-1.5707963267948966,0.008658545053386868 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark06(-0.42668162426271455,-1.5707963267948966,84.557344412137 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark06(-0.42686365242207436,-1.5707963267948966,-90.02622026059039 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark06(-0.427756903100771,-1.5707963267948966,-14.42960615497168 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark06(-0.4280725405726743,-1.7763568394002505E-15,-70.73727972410626 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark06(-0.4281014957221536,-1.5707963267948966,-82.78866460927861 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark06(-0.4299978770486499,-1.5707963267948966,-56.13207399049277 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark06(-0.4304464043162281,-0.08995403025998898,-15.4938492352784 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark06(-0.4328919012804393,-0.5072109704401653,40.48029354889323 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark06(-0.43312562471145744,-2.220446049250313E-16,1.5707963267967393 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark06(-0.4333902520576507,-1.5707963267948966,-64.27745982959573 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark06(-0.4348644007487792,-0.4349468457695894,-1.5707963267948966 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark06(-0.43720688322723666,-1.5707963267948966,40.58761357824378 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark06(-0.43747099249687627,-1.5707963267948966,-37.518998108424235 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark06(-0.4374959465181547,-1.5707963234569053,2.570787631376446 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark06(-0.4384901827656761,-1.356039372348943,-0.261340091341166 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark06(-0.4437070998843451,8.673617379884035E-19,-37.952278255084366 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark06(-0.44590288873177997,-0.1976807228941916,0.0 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark06(-0.44596033585358374,-45.27235670613729,-21.128467003673634 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark06(-0.4462630405929342,-31.751807924216678,-79.90302233014192 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark06(-0.44663759204651143,0.0,0 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark06(-0.4477372985085691,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark06(-0.4480794812309083,-1.5707963267948966,-0.6286066651658826 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark06(-0.44828044666135214,-4.004166190366202E-146,32.91050963714195 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark06(-0.4498553948487789,-1.1346225546025372,-31.416172094254424 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark06(-0.4533262698850722,2.1175823681357508E-22,-19.399890401045134 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark06(-0.4536478414239582,-101.81478828691453,7.73584481937586 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark06(-0.4537496420720552,-1.5707963267948983,21.449667013199957 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark06(-0.4539485368720846,-0.03235401534162731,10.945748349015357 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark06(-0.4550571924184167,-88.31485035611104,-1.5922805540945772 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark06(-0.4553025256395238,-39.23089898195644,-54.29053652773509 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark06(-0.4562168771115587,-1.037322666849005,-59.88550550650349 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark06(-0.4569458549469049,-44.15863677972695,-72.45116301180005 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark06(-0.45697997556790537,-0.19632805077029758,112.85000618253235 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark06(-0.45818705197839754,-0.7057672652521914,1.570796267541843 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark06(-0.45824025377538685,-88.39836204933948,-1.5707963267948966 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark06(-0.45938923645918056,-1.5707963267948966,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark06(-0.4597037481601717,6.712388980384803,-1.5707963267948948 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark06(-0.46032153087919603,-1.5707963267948974,-796.6571179696285 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark06(-0.4604397825448543,-32.418913856762615,-66.06990638798547 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark06(-0.46112658957109987,-4.118046071574423E-84,-60.99471766073973 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark06(-0.4612745441490191,3.995182602206974E-4,-45.30111799640118 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark06(-0.46140706880387294,-38.92642198705808,0 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark06(-0.4622642359961192,-31.903847276125305,4.71238903105726 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark06(-0.463181197466533,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark06(-0.4635003531115556,-101.71089684444173,-29.603831441447724 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark06(-0.464062746437117,-0.02028580510386746,-358.1250566723723 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark06(-0.46567217162764063,-1.5707963267948966,3.266592672499173 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark06(-0.4674512041659682,-94.34592944437681,-52.08565876766471 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark06(-0.4675666730519657,1.0842021724855044E-19,16.925888421669583 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark06(-0.4684805588915619,-31.56422387758586,-141.08440577951876 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark06(-0.469133073285008,-1.5707963267948966,-1.5707963267420286 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark06(-0.4696627841978849,-31.747011371445133,-3.9668590620099407 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark06(-0.4698891006075146,-37.924476330918466,-35.68092729117143 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark06(-0.47052945005147695,-31.649815067247218,0.7083098893347998 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark06(-0.4707247429144561,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark06(-0.47129611334918914,-2.002083095183101E-146,3.3039537010124036 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark06(-0.47189947474668426,-3.141592653595598,10.63286526377546 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark06(-0.4722088054557298,-1.1472009589942374,-1.5708008058624117 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark06(-0.47238353883616835,-38.814450482388395,-3.141592719146141 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark06(-0.472712637266857,-88.1097134709573,-97.6086147409873 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark06(-0.47318863257122556,-1.5707963267948966,-7.505232753296681 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark06(-0.47338772960375275,-0.4244594334673135,72.0837945670827 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark06(-0.47443455976460314,-1.5707963267948966,-37.90906988939835 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark06(-0.474656164624037,-0.8917911999755941,272.69321737384803 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark06(-0.47672215093172987,-2.7755575615628914E-17,0.35613435194708465 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark06(-0.47764522585458735,-1.0882514611119887,-198.94070741322213 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark06(-0.47830159613583745,-1.5707963267948983,14.699445899605351 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark06(-0.4788007067440685,-0.3187009812292956,8.768389661080285 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark06(-0.47916183867965473,-1.3928489577553715,-72.24550666221838 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark06(-0.4797836274662002,-1.5707963267948966,-38.68761354510002 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark06(-0.48020903668487436,-1.5707963267948966,-1.356656403674092 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark06(-0.4807517959983602,-1.5707963267948966,1.570796326794898 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark06(-0.4809191245023494,-157.5576086884349,-37.70385141009419 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark06(-0.48143369169846384,-1.2450886741724227,93.42723033686052 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark06(-0.48221005210998796,-45.40913764558465,-10.413514575866497 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark06(-0.4829027977302438,-1.5707963267948966,-98.46449973879774 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark06(-0.48331345020740457,-1.5707963267948966,-71.86486566995058 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark06(-0.4848241540278861,-1.5707963267948966,32.45205544543787 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark06(-0.48499193195040374,-27.937304182721817,-39.85448346748174 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark06(-0.48517588012160195,-1.5707963267948841,-1.5707963267948966 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark06(-0.4856567081571329,6.712389044000943,-52.670709295033056 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark06(-0.4874397523295707,3.469446951953614E-18,-1.5707963267948966 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark06(-0.48775984475231077,-0.06677447952356987,1.5707963267948943 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark06(-0.48826455023695886,6.776263578034403E-21,-52.10032534747678 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark06(-0.48931987497710006,-1.5707963267948966,89.60054216870391 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark06(-0.4905129113077997,-1.5707963267948948,-29.2573313604219 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark06(-0.4907700299943749,-0.5564746383897065,859.2702859790138 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark06(-0.49093545195123234,-1.5707963267948966,-0.33622577864160164 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark06(-0.49101448595005825,-1.5707963267948966,76.36239233078436 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark06(-0.4910391361709688,-95.35703455519895,-90.52631658631748 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark06(-0.4912897713637685,-8.235373619051172,-66.85867415463734 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark06(-0.49129515299497895,-19.37884169148205,-16.665656973326175 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark06(-0.4930613650898472,-31.982324057465362,-78.53981633974483 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark06(-0.49433689176647116,-1.5564620946247532,1.570796327489145 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark06(-0.49709027135470524,-1.5707963267948966,6.712447610522787 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark06(-0.49717410897551817,6.712388980384691,-95.58335857259914 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark06(-0.49753794399827056,-1.5707963267948983,-1.5707963267948966 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark06(-0.49861949406479766,-0.25847852706448116,-7.853981603116128 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark06(-0.49870762627837695,-1.5707963267948966,14.499389333883187 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark06(-0.49938841206002255,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark06(-0.49973700167923263,-102.1017610452591,-172.23083827199343 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark06(-0.49979806246149394,-1.5707963267948966,-64.97546222709347 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark06(-0.5001906250054291,-1.5707963267948948,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark06(-0.5008994488175071,-2.220446049250313E-16,33.40461080287987 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark06(-0.5009189601474877,-1.3795217990190687,5.1977048828224496E-113 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark06(-0.5028050798722234,-1.5707963267948966,-95.74691093705574 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark06(-0.5053482412357462,-84.44677315879078,-1.5707963267948983 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark06(-0.5054613196790391,-1.5312109982975526,49.45257866608411 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark06(-0.5055485048369535,-0.34273482920624837,1.5707963267948966 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark06(-0.5056691324079736,-7.820637090558988E-149,1.5707963267948966 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark06(-0.5058651625148283,-32.581156504008646,-64.49539154184617 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark06(-0.5062259211287881,-2.220446049250313E-16,-54.810759448531996 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark06(-0.5063055492787578,-1.5707963267948966,25.801503288494217 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark06(-0.5075070021058814,-1.2079511654442971E-16,44.511335579437954 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark06(-0.5084904105978045,-1.5707963267948966,101.86843495970561 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark06(-0.5097116402028035,7.888609052210118E-31,-25.000121274303357 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark06(-0.5114427713695591,-45.5456934488801,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark06(-0.5115227545961292,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark06(-0.5119100725648333,-1.5707963267948806,55.383493364844185 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark06(-0.5125620265868926,-19.40590136457607,-1.5707963267948966 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark06(-0.5130276799034899,-1.4546295517400731,-3.141591879810881 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark06(-0.5133353419237567,-1.5707963267948966,35.477045409085434 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark06(-0.5159555384211516,-1.2556941067803986,-8.032214256356998 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark06(-0.5162485959314866,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark06(-0.5164916524642829,-1.5707963267948957,-49.94560930748763 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark06(-0.5174382783510012,-1.5707963267949019,12.732606936905269 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark06(-0.5176718991508629,-1.5707963267948961,-1.5710469800240239 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark06(-0.5180085624353723,-0.8810313044163848,69.88496446437534 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark06(-0.5186558627045388,-1.3779727823898043,14.314122882772267 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark06(-0.5187215668230345,-0.647924757351765,68.78893640880449 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark06(-0.5188198565674709,-1.5707963267948966,-3.1415927017786625 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark06(-0.5197996846593507,-1.5707963267948966,31.41592685668192 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark06(-0.5201817483954474,-1.5707963267948966,30.912540617589997 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark06(-0.5204792431522571,-0.0893194872587721,-4.18296762884122 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark06(-0.5206151397886438,8.673617379884035E-19,0.0 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark06(-0.5217498706927056,-1.5707963267948912,102.101395140108 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark06(-0.5242557804928785,-1.5707963267948912,-36.02587596682816 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark06(-0.524339777015538,-0.4094635653745599,67.20784513122825 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark06(-0.5243402933973389,-1.3803857464439968,-6.406665904585923E-145 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark06(-0.5246977379056688,-31.41592655797311,-2.630774662677677 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark06(-0.5251315017690295,-0.3014308873514602,23.780237988176438 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark06(-0.5252034198213943,-1.1019069429454043,1.5707962966559879 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark06(-0.5252085607330657,-0.2628786490453072,3.141592658221874 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark06(-0.5259846495816163,-1.4210854715202004E-14,-21.49745825293934 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark06(-0.5268318234132465,-1.467607693774392,-12.006935272693177 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark06(-0.5279736101626294,-1.5707963267948966,-26.385719273047663 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark06(-0.5285952530780688,-28.025161600732012,-2.0707964501507865 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark06(-0.5294876087402349,-0.04923846433890189,60.25117904776518 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark06(-0.529710395207398,-44.48233652793154,-53.9425092428574 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark06(-0.5306458291759175,-0.9576005354968995,0 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark06(-0.5312052533076657,-1.1647921206248892,40.07568262157014 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark06(-0.5320817006868611,-0.4911278825083733,29.656007491832632 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark06(-0.5322385173283428,-3.1415926550182047,11.111369035444781 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark06(-0.5325903467728307,-0.8983803283725496,-1.2945073957288522 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark06(-0.5328672388110606,-1.5707963267948966,-42.71868369814935 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark06(-0.532987063470454,-1.5707963267948966,-89.6322811887405 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark06(-0.5329986745399574,-38.54989177310397,0 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark06(-0.5365595792215938,-100.80417288837162,-35.28045643061657 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark06(-0.5382236262479378,-0.26150449134095183,86.81253571793883 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark06(-0.5388534018871403,-1.5707963267948963,64.8393145737955 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark06(-0.5388603588111194,-0.41394205122700256,45.09357480741137 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark06(-0.5391693073779564,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark06(-0.5393808436109437,-0.6346437471765342,1.5707963267948966 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark06(-0.5394898067448943,-0.7618739502385652,-1.57545905889277 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark06(-0.5411071265401461,-1.5707963267948966,0.007042320728362995 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark06(-0.5424313277829107,-1.5707963267948966,32.26632326331202 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark06(-0.543076476626017,-95.32281006813619,-39.23075459084815 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark06(-0.5437844669510836,-0.35919999931844515,2.559727736736625 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark06(-0.5442999624362483,-0.3354856560390691,81.983102819478 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark06(-0.5446917854250215,-31.41592713548256,-25.657471103178334 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark06(-0.5452095263187262,-8.988421259321484,0 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark06(-0.545932916556161,-32.93169945656584,-64.59227261271023 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark06(-0.5472118833817294,-1.5707963330655974,-17.27924790666272 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark06(-0.5488064214795259,6.712388980384698,-44.52372048435991 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark06(-0.548861231912765,-38.97369942522537,-58.427029947224284 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark06(-0.5490428486666517,-1.5707963267948966,70.88628438485875 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark06(-0.5492235931560954,-0.28909819658186775,-41.710278051196994 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark06(-0.5498783174226197,-164.93349173406588,-95.30195786928884 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark06(-0.5539143316615736,-95.49198275409395,-686.4206657598847 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark06(-0.5539865898545191,-1.5406584024320844,1.5707963267948961 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark06(-0.5562379599202507,6.712388980440902,-1.5707963267948966 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark06(-0.5576258379222381,-1.5707963267523575,-49.84109319340368 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark06(-0.5604741019117512,-1.5707963267948966,88.28281933004908 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark06(-0.5637543461127732,-1.5707963267948966,48.24020337687981 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark06(-0.564030751547956,-1.2969448450420629,-1.571299340383666 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark06(-0.5640434459872034,2.465190328815662E-32,33.2570051683229 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark06(-0.5655592492887387,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark06(-0.5661559142237235,-1.5707963267948948,-1.6472184286297693E-83 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark06(-0.5664005723942749,-2.220446049250313E-16,-6.712395564422649 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark06(-0.5666086951386688,-1.5707963267948966,97.20636980646806 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark06(-0.5667828311054888,-0.3753395870198434,-47.97572319681714 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark06(-0.5673824594143639,-95.61337246999572,-67.41714344423818 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark06(-0.5682555168817336,-32.73894499714672,-197.19247678886154 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark06(-0.5697812176674295,-0.15761746566367796,1.5707963267948966 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark06(-0.5703417505803803,-1.5688788432918523,-49.96925509952744 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark06(-0.5704342416104774,-31.41592654441533,-37.93104274534238 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark06(-0.5719129315081612,-0.7025073968039759,4.714342231427901 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark06(-0.5723885054532073,5.14159265365632,-1.5707963267949054 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark06(-0.5737424082538971,-1.5707963251754755,-1.5707963267948966 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark06(-0.5737488183436119,-94.30983879204979,-9.825695201419743 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark06(-0.5739355603490068,-0.7577747391627893,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark06(-0.5743300309692405,-0.24986473579964397,-58.136420336345715 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark06(-0.5745938847752039,-1.0176546076505923,77.9585547388893 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark06(-0.5754911298645213,-158.0843103643769,-1.5707963267948966 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark06(-0.5773450917878453,-44.38946003283347,-69.90438819297837 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark06(-0.5777208818365608,-0.608541461261173,-69.86480463974348 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark06(-0.5779884725846679,-1.5707963267948948,-32.462660451804396 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark06(-0.580256630934814,-1.5707963268716227,-156.69197218334725 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark06(-0.5805109298124194,-0.2880819094643629,-2.7485467898094527 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark06(-0.580732953651602,-1.5707963267948966,1.633296326880044 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark06(-0.5813122452012345,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark06(-0.5814015277920662,1.3234889800848443E-23,-0.6566400790859618 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark06(-0.5844470149555376,-1.5707963267948966,-65.68539811229861 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark06(-0.5850784677341276,-1.5707963267948966,-80.10810729217047 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark06(-0.5851876717787956,-1.5707963267948966,-44.826168678149386 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark06(-0.585299551740263,2.465190328815662E-32,25.773690620072205 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark06(-0.5856853624818129,-0.18560161394863317,98.92937984369905 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark06(-0.5863849907158425,-1.5707963267948915,37.11849026556848 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark06(-0.5881897739787989,-0.5642109842871005,0 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark06(-0.5884972634841041,-1.5642728505088033,8.104148298852147 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark06(-0.5885689695621811,-44.528997437813004,-1.5707963267948966 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark06(-0.5889436403090282,-1.2551190023608996,-57.92110130443848 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark06(-0.5894591612800659,6.712388980391516,-45.70372175055656 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark06(-0.5898779913362633,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark06(-0.5899252584490533,-43.99839849987654,-32.29458337823861 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark06(-0.5901236326750601,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark06(-0.5901969637490747,-1.5707963267948966,-53.926839218797994 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark06(-0.5903426208794748,-0.9319277918890568,39.72856365020736 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark06(-0.5914229990210143,-1.5707963267948983,27.441887949245917 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark06(-0.5917254588694671,-0.7999469939109818,33.75863309224653 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark06(-0.5923579907164158,4.930380657631324E-32,71.21869403897969 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark06(-0.5947222563092845,-44.26373278242552,-50.39895607957061 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark06(-0.5948711766805715,-44.369375452851486,-90.24752107972884 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark06(-0.5963904058381437,-1.570796044830223,6.714590912013217 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark06(-0.5968276106527695,-0.252142238702552,19.35860906491706 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark06(-0.5972290213386343,-0.41060119561260355,-514.139065703771 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark06(-0.59737797115329,1.3877787807814457E-17,37.12482929239337 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark06(-0.5974368621155788,-31.7975834017692,-3.1415937164567813 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark06(-0.5983704223043745,-0.8576412443525512,-9.997669647833689 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark06(-0.598762235528914,3.3881317890172014E-21,-90.63969626236322 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark06(-0.5990301308601664,-1.9040518271858276E-16,0.0 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark06(-0.5992844398428234,-1.5707963267948966,-49.40150318845164 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark06(-0.6018805044237538,-0.1581857957055687,-23.061278838315644 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark06(-0.602047405943288,-1.1102230246251565E-16,1.5707963267948983 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark06(-0.6022892168127567,-1.0810437573819383,3.209987679182234 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark06(-0.6026677686372146,-0.956451236542787,34.19579025786484 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark06(-0.6032249126391985,-44.50789533885187,-2.0707963650828463 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark06(-0.6033108868841642,4.3368086899420177E-19,-1.5707963267949125 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark06(-0.6033765730246191,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark06(-0.6036140749233676,-0.011036498055026855,-187.00651241869826 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark06(-0.6040100369212468,-1.5707963267948966,-1.5707963267948974 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark06(-0.6045010251354594,-1.270490483904132,31.892363761497055 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark06(-0.6050647654325072,-1.5707963267948966,1.4887422393970309 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark06(-0.6054024743934479,-3.1415926535897936,31.75129914564436 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark06(-0.6073022603941267,-1.0819584295278175,0.0 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark06(-0.6076883020767095,-1.5707963267948966,-3.141591388439629 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark06(-0.6079514783524922,-95.61496963946938,-164.91883658320248 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark06(-0.6080809822422157,-1.2828621817038377,-98.8250343394569 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark06(-0.6081862197534313,-4.1581639062579597E-112,-18.018383512203087 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark06(-0.6083036457564157,-95.65433287887087,-1.5707963267948966 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark06(-0.6083963183750767,-1.5707963267948966,-27.884264464161795 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark06(-0.6098601093412926,-1.3800679426531453,69.01907625201326 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark06(-0.6113355975507797,-1.5707963267948966,-19.388283351052394 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark06(-0.6126928379427437,-1.5707963267948966,2.465190328815662E-32 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark06(-0.6130379161828702,-1.5707963267948966,17.27925537750809 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark06(-0.613410212995787,-0.3484738502415856,43.68379759012843 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark06(-0.6142239117288276,-1.5707963267948966,-0.024044377422277788 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark06(-0.614614566064293,-1.5707963267948966,-3.141592693813786 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark06(-0.615469462603583,-1.5707963267948966,0.5297425072676857 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark06(-0.6155547191064679,-1.1601244190449247,1.5707963267948983 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark06(-0.6161144804066782,-0.590478519762911,96.78447689797503 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark06(-0.6172165956890057,-1.1115940015904044,45.540170077567026 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark06(-0.6176388883888402,-100.7414613173817,-1.5707963267948983 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark06(-0.618183718728022,-1.5707963267948966,-0.44082383378387746 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark06(-0.6188849064387618,-0.47286156937519164,-81.57244000348491 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark06(-0.6191890457024941,-0.5522463459955134,-94.07905092956968 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark06(-0.6196200746563117,-45.34906287271615,-78.11599162842106 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark06(-0.6211787213126547,-0.9024256987343051,1.3552527156068805E-20 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark06(-0.6244268803979818,-101.64956161216439,-1.570796326794894 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark06(-0.6247608234521445,-3.1415926535897967,1.730398915144848 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark06(-0.6250071160666056,-0.8222984192054159,3.1415926535897922 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark06(-0.6250403592032882,-1.5707963267948966,79.56489676999169 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark06(-0.6256455200215854,-1.5707963267948966,27.908502586159088 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark06(-0.6260145647774493,-1.5707963267948966,7.242401869457648 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark06(-0.6261791565885028,-1.5707963267948966,23.40239050620656 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark06(-0.6270169442635725,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark06(-0.6277580711621279,-3.14159265359128,-1.5707963267948966 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark06(-0.6279334288813914,-1.003021763027883,-214.05860206294403 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark06(-0.6284844776783479,-1.4923111067054442,0.0 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark06(-0.6287510613491087,-1.4775346973939065,-7.8539453755497 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark06(-0.6297327334269092,-1.5707963267948966,38.99144653661935 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark06(-0.6298984347962673,-0.002254756442240824,1.5707963267948966 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark06(-0.6308631193885788,-1.5707963267948966,30.63136228550057 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark06(-0.6309010460560931,-1.5707963267948966,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark06(-0.6315569577863842,-45.295942890032975,-145.01872648207657 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark06(-0.6317918545723686,-0.10531533465830112,41.41040693600414 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark06(-0.6320465894554705,-1.5707963267948966,-1.5707964460271715 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark06(-0.6325917257543212,-31.568323408336976,-1.6332963271847811 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark06(-0.6326639496318242,-1.5707963267948966,70.68985935264821 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark06(-0.6329255569971605,-1.5301214506269067,2215.403647385774 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark06(-0.6332750233376327,-1.5707963267948966,-1.5707963267950515 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark06(-0.6335107495247811,-1.5707963267948912,-26.071570225316947 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark06(-0.6376443579187229,-1.3552091361410703,-34.03011117902241 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark06(-0.6384628210492949,-0.9761890231623798,32.461855889629376 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark06(-0.6389233854575519,-1.5707963267948983,-1.5707963267948983 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark06(-0.6394927906916674,-1.5707963267948983,128.84309964974028 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark06(-0.6399326761817706,-0.33115445540437793,0.0 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark06(-0.6408731875328125,-1.5707963267948966,4.74363898153154 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark06(-0.6411857281358093,-44.43621457271629,-1.5707963267948968 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark06(-0.6416819645810925,-1.476911981105689,38.37280847223994 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark06(-0.642546151103908,-94.2477796076938,-1.5707963267948966 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark06(-0.645809545905258,-95.78022039035349,-53.89929886522002 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark06(-0.6461316402394855,-45.12884336043054,-155.0057217790973 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark06(-0.6469040826153427,-0.23912298507219504,4.69622303987083 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark06(-0.6470151701881477,-164.80063740087948,-67.05780651449197 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark06(-0.6478132912470089,3.1554436208840472E-30,-4.31855144023578 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark06(-0.6479872142229339,-0.46207167003456,2.0709089894398987 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark06(-0.6484459830845055,-1.240646848197127,-73.20871731336509 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark06(-0.6486345487066201,-1.5707963267948966,-14.429265214447732 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark06(-0.6492163131523085,-1.5707963267948966,89.6229131177563 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark06(-0.6505596928616952,-1.5707963267948966,0.5261090173669398 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark06(-0.6508893222536472,-32.96839645779118,-84.27987514392426 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark06(-0.6524870403424124,-19.360015267860632,-3.2156322961521084 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark06(-0.6534910313839087,-1.2586221617105469,-101.01701574067647 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark06(-0.6540321838006661,-1.515137604935911,-6.712388980747138 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark06(-0.6548004813501279,-1.5707963267948966,-45.63497519373531 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark06(-0.6549052352009763,-0.21060207629889138,58.06011520215744 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark06(-0.6555047367339224,-1.5707963267948948,10.239770352845966 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark06(-0.6565787979842106,-1.5707963267948966,-29.6981944004785 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark06(-0.6578021166115224,-0.8819639573845925,-41.26335674965995 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark06(-0.6603755771406119,-45.18841668072892,-27.753455246865695 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark06(-0.6610439579906995,-1.5707963267948966,33.23748172040051 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark06(-0.6616887418240616,-1.0839919227843953,-151.38339636989656 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark06(-0.6616974711375737,-37.75349155820301,-1.5707963267948966 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark06(-0.6636365215162252,-1.5707963267948966,747.70026521269 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark06(-0.6638364519178297,-1.5707963267948966,0.37788270292281556 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark06(-0.663959762362875,-1.5707963267948966,-88.51585684172109 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark06(-0.665094652855305,-38.83191196159684,-110.8993807896119 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark06(-0.6653336465327078,-45.33317654938918,-95.7147995166564 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark06(-0.6656713157096804,-32.985700157665256,10.283185309408843 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark06(-0.6656981271635389,-1.4585691678131558E-15,0.0 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark06(-0.6662965758077135,-0.5733379705597518,124.41585518032775 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark06(-0.6666431700813693,-1.5707963267948943,3.141592653589793 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark06(-0.6677698527882725,-158.48852994226854,-163.57369215855067 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark06(-0.668620093399541,-1.3623657133630003,-3.266592701157409 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark06(-0.6693845288984166,-88.30741014625187,-1.5707963267948966 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark06(-0.6696061964352636,-0.6518251935514294,5.551115123125783E-17 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark06(-0.6697699421869752,-1.5707963267948966,28.325709846173908 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark06(-0.6701313763662666,-31.56598913091394,-26.985981361290634 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark06(-0.6702754094191559,-88.3541853803752,-0.4930976575239277 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark06(-0.6704369950922864,-31.94609416213721,-1.5707963267948963 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark06(-0.6713356651449106,-1.2998573892598966,100.0 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark06(-0.6713577086607683,-1.5707963263958418,-31.5563430156977 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark06(-0.6732853971139312,-0.24350402468839483,4.770883879427544 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark06(-0.6744908341637409,-31.590087705440183,-38.243313676644746 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark06(-0.6747028256229193,-1.5707963267948983,-44.45878675214854 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark06(-0.6748927834398426,-1.3862840408939112,65.42348816066703 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark06(-0.6750004012100246,-0.7022088827045474,-14.205841910043702 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark06(-0.6752572214107269,-0.9063646139606394,8.77712084336357 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark06(-0.6753690002194587,-0.01023272312308221,0 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark06(-0.6754150048644599,-0.13886897940324194,-125.3692082780959 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark06(-0.6759403115311833,-0.09683470768644781,88.37092697815712 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark06(-0.6785980005200373,-1.509484721947345,-30.11245530007755 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark06(-0.6794329803434351,-0.546044077714088,-95.49763374813045 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark06(-0.6808347147361004,-31.610852723048335,-44.183145446656404 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark06(-0.6821611754838415,-1.4791895678081934,-58.62174257154751 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark06(-0.6840781393241866,-1.5707963267948966,3.2143203057635796 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark06(-0.6857891566531679,-38.99554015520777,-3.2188847872017163 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark06(-0.6866930515171185,-44.31162231994197,-73.1441105843346 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark06(-0.6871781606350744,-1.5707963267948966,-5.714936956411375E-101 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark06(-0.6880145578916539,-1.5707963267948966,0.752693246029366 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark06(-0.6882994645862226,-1.069667063180404,-7.3899711924416 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark06(-0.6884167973106597,-0.004932154944572026,-3.266594404661836 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark06(-0.6889522328217165,-0.024081435023628146,44.49438783581677 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark06(-0.6915085429582606,-0.007150867699704436,-59.33910019306672 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark06(-0.6919394600601283,-1.5707963267948912,-61.64451243705784 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark06(-0.6930251316548172,-1.4901787028908429,12.325979969042749 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark06(-0.6937487942017724,-1.5707963263546392,-95.36103665830551 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark06(-0.6943305696654463,-0.834181286091458,-63.19756178532285 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark06(-0.6947980641162103,-1.5707963254041937,-1.5707963267948966 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark06(-0.695380743989281,1.0842021724855044E-19,-19.36709370160449 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark06(-0.6954425977975666,-1.5707963267948963,89.60002740390603 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark06(-0.696137859256103,-1.5707963267948966,97.54110462493017 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark06(-0.6977292747849334,-31.66954640334754,-71.84385682565602 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark06(-0.6982725436828822,-1.5707963267948983,-31.416010550833125 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark06(-0.6985482705392706,-0.7653645035905361,-45.463053674641834 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark06(-0.7000893806786188,-1.5707963267948966,45.06186790916374 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark06(-0.7003571121181679,-1.5707963267948966,39.25518338700963 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark06(-0.7007494806386046,-37.86428490936746,-110.21200572500607 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark06(-0.701004253862146,-32.712013781851574,-1.5707963267948983 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark06(-0.7013191039606639,-1.5707963267948966,-95.46409828129084 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark06(-0.703735745327052,-1.5707963267948966,-51.9337739875602 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark06(-0.7038523604655791,-1.5707963267948966,15.29453110140031 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark06(-0.7040971865673724,-1.5707963267948966,-6.716956986719034 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark06(-0.7043016503489524,-39.08028121490818,-8.195320491170179 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark06(-0.7064991897964461,-1.5707963267948886,-30.696413032835366 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark06(-0.707466915484853,-0.980456887841255,-335.71517442270067 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark06(-0.707497479916038,-1.5707963267007872,-1.5707963267948948 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark06(-0.7077662296703685,-31.415926536590177,-73.31433746961524 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark06(-0.7081567290224002,-0.7873264113727602,-1.5707963267948966 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark06(-0.7081583631952559,-1.5707963267948948,-3.141592653589793 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark06(-0.708339904053505,-31.868330236209673,-47.13255453001108 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark06(-0.7087916748583041,-1.5707963267948948,-37.791546563978244 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark06(-0.7097125355576825,-1.3496874754022232,-58.908386674862285 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark06(-0.7098635761790935,-1.4806289889590782,-98.90554260647825 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark06(-0.7104014401912572,-0.32258789388309717,-4.7123892188032706 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark06(-0.713501841828248,-3.141592653589831,-65.45296748566872 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark06(-0.7150417971095046,-37.74988213289228,-67.22396229778629 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark06(-0.7180860316468788,6.7123890315070565,-160.57410554415324 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark06(-0.7197919178933614,-0.20503317724404746,-44.976972501823354 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark06(-0.7226492824678513,-95.7574502670402,-94.34581260705146 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark06(-0.7232158582430359,-1.5707963267948912,89.93095312713254 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark06(-0.7237541899678311,-1.5707963267948966,1.5793650827938261E-176 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark06(-0.7237547310034351,-1.3944605824918412,-45.52067919687999 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark06(-0.7239497984574914,-1.5707963267948966,-47.15059762618376 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark06(-0.7242591695091536,-0.14471390819695684,-3.1415926535897967 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark06(-0.7246473699573954,-31.431379394254535,-8.132388027586138 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark06(-0.7250416019049043,-1.5707963267948966,-18.84102433599419 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark06(-0.7254582726741783,-1.0346299221213346,15.147695552192518 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark06(-0.7263129402529955,-1.5707963267948912,-95.7992991368787 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark06(-0.7263610817208561,-1.5707963267948974,1.5707963267948948 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark06(-0.7276020294571183,-1.5707963267948966,-4.743638980876134 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark06(-0.7280788258171169,-1.5707963267948983,-561.3092624336325 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark06(-0.7288063523139248,-1.5707963267948966,-23.28328335296879 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark06(-0.7295441889050682,-45.05607259684671,-7.104435366985433 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark06(-0.7317624881949378,-1.570796326678436,-42.50190662044056 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark06(-0.732234867507034,-1.066578928964722,-110.52162016977526 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark06(-0.733829559274266,-1.466838583000889,1.5708268745985245 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark06(-0.734449161790751,-1.5707963267948966,80.23065368363152 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark06(-0.7351435373979797,-1.5707963267948966,0.31421570426680034 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark06(-0.7354132936676521,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark06(-0.7356789731910742,-0.14206447872158406,76.77790851150966 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark06(-0.7367124926272468,-0.003460213218875289,31.504976906647148 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark06(-0.7370218838835432,-45.01127318023329,-568.0521376234046 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark06(-0.7375524996724439,6.712388980397016,-1.5707963267948966 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark06(-0.7384402843694711,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark06(-0.7385228785086051,-0.10670682149824806,-72.49858801757019 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark06(-0.7394241835263715,-1.5707963267948966,18.508505506054057 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark06(-0.7395365820148956,-1.5707963267948966,-1.5707969527127426 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark06(-0.7398664692014632,-101.88016362000128,6.465264918896204 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark06(-0.7409112997975468,-0.1678583289741542,-9.61114840854166 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark06(-0.7411072487240862,-37.922136075884005,-14.580352514178161 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark06(-0.7416292862084235,-39.04500775789812,-33.994021841841914 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark06(-0.741862036066768,-2.220446049250313E-16,-10.240087444595734 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark06(-0.7433327619218318,25.132741228718363,-1.5707963267948957 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark06(-0.7439453393226141,-0.13222097322501708,-52.49025800121715 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark06(-0.7444265846569389,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark06(-0.7448698231376394,-1.54518139185963,0.0 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark06(-0.745122700678307,-1.1510720838542126,1.5707963267948966 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark06(-0.7456450140528748,-31.62721470470774,-9.995577352360964 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark06(-0.7476508636161725,-31.86187703754142,-45.43860038853067 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark06(-0.7478069306159163,-0.20300635314100535,-1.5717729496227983 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark06(-0.7486644087570252,-1.5707963267948961,-4.743638981418692 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark06(-0.7487458361010332,-1.5180184374028811,1.5707963267948966 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark06(-0.748760800291676,-26.863708939684216,-10.949402244776511 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark06(-0.7494688649580455,-1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark06(-0.7494688649580471,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark06(-0.7499754496052591,-1.5707963267948966,36.332267041058586 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark06(-0.750726365882466,-1.5707963267948966,83.06678636426835 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark06(-0.7516872224058702,-0.007838013102678747,50.4584981275506 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark06(-0.7518639382494109,-95.68044798954048,-73.18265651351801 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark06(-0.7549420634658686,-1.5443880506147103,73.55059436987725 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark06(-0.75712682738001,-1.5707963267948966,-31.08705777127367 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark06(-0.7574081067811919,-45.26545230466106,-70.89441528442718 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark06(-0.7580765047758823,-1.5707963267948966,51.850259307536895 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark06(-0.7582949122072595,-84.51042186755748,-44.32622763914506 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark06(-0.7589206535841915,-44.15071609794874,-134.53505014385294 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark06(-0.7591887525331842,-101.61264200545493,-2.465190328815662E-32 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark06(-0.7611521260253393,-94.28166731821072,-90.68950188916803 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark06(-0.7613207348930955,-1.5707963267948966,17.29270328214335 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark06(-0.7627246502028875,-28.03705902617781,-22.231741724452572 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark06(-0.7632816289234654,-1.5707963267948966,-70.82092589390784 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark06(-0.7648267583687793,-1.8546030753437107E-68,27.31212450903817 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark06(-0.765017920382128,-0.8734293211586461,-1.5707963267948966 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark06(-0.7651794639413082,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark06(-0.7662937011765741,-1.5707963267948963,-6.236773691364529E-8 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark06(-0.76751903545507,-45.41267752482055,-1.5707963267948966 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark06(-0.7677161763743747,-1.222780778655416,-30.758822258739713 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark06(-0.7683629547184334,-95.55322661693219,-153.96482829028736 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark06(-0.7693245551849728,-1.4625724050730076,1.5707963267948966 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark06(-0.769409676444154,-1.5707963267948966,1.5707963267948961 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark06(-0.7700133484528686,-1.5707963267948966,59.15838211586603 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark06(-0.7700355212208241,-1.5707963267948966,-53.19212970977125 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark06(-0.7703563245157472,-0.6944240607736027,815.1149242231453 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark06(-0.7703744356574528,-31.897600401274072,-16.762980918967678 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark06(0.7708543500290268,0.0,45.94469608863736 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark06(-0.7719288590243734,-1.5707963267948983,601.3269017099259 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark06(-0.7732056645181159,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark06(-0.7733110039450316,-1.5707963267948968,6.71238903954508 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark06(-0.7736219013557873,-1.5707963267948966,-50.13012274334562 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark06(-0.7739333063016471,-1.5662785537192891,39.262004559442566 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark06(-0.7750825646363781,-1.3877787807814457E-17,31.3240094122516 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark06(-0.7750884530156461,-0.03702112859592499,1.570796326794897 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark06(-0.7754206085255637,-0.38582649683214587,163.30968538634633 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark06(-0.7760033680931573,-45.07262390193932,-10.81095178096831 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark06(-0.7761446332670892,-0.17071196075007092,28.274334125435207 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark06(-0.7764910592794091,-1.1209083437403948,27.67224835287938 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark06(-0.7766879072017775,-0.6747627572675188,0.0 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark06(-0.777527257721033,-3.552713678800501E-15,-1.5707963267948983 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark06(-0.778965140788747,-37.83256408044511,-45.46019298817303 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark06(-0.7809798594185542,-1.5707963267948966,3.1415926535897936 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark06(-0.782010542205283,-1.5707963267948966,-237.9548592114735 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark06(-0.7821450053121792,-1.3672434001585374,-85.93509410200203 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark06(-0.7824000551771801,-0.9033874633132939,28.02348691692552 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark06(-0.7826436061082518,-31.5143296463657,-3.2665943613021513 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark06(-0.7842460286355717,-1.5707963267948966,-20.821246956852406 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark06(-0.784488994013892,-1.5707963267948966,3.217223493417518E-86 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark06(-0.7852870297979624,-1.5707963267948966,-39.73401759519669 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark06(-0.7853552176867626,-1.2254140887605818,43.982297150257104 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark06(-0.7853981633974492,-1.5707963267948963,90.29096057348856 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark06(-0.7870238143293591,-1.2146057032904736,-7.93687211126155 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark06(-0.7872473175623864,-1.5707963267948966,94.32854787519094 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark06(-0.7873496469228135,-0.5514269591407128,44.084321173191064 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark06(-0.7873949568122365,-1.5707963267948966,-74.1070424055564 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark06(-0.7874384701086135,-1.5707963267948966,-4.712633290750837 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark06(-0.7878215817113468,-1.1293755376729645E-16,1.5707963267948966 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark06(-0.7880475901402774,5.551115123125783E-17,-26.444349023611817 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark06(-0.7881009341500467,-1.5707963267948966,79.94574437379359 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark06(-0.7881083559932927,-32.582040680757174,-32.93378770788318 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark06(-0.78876218585164,-1.202608224758664,-14.054633590290592 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark06(-0.7904619086615516,-1.5707963267948966,-81.19620662293164 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark06(-0.7916939688387146,-1.5707963267948966,-44.94625165528241 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark06(-0.7936899754185088,-1.5707963267948966,89.4837723738529 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark06(-0.7938116212813582,-5.297463577666576,0 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark06(-0.7940654865441936,-1.5579743432502873,-403.1238562527802 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark06(-0.7943245740607949,-0.006048731483716803,-56.738297791394075 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark06(-0.7947107721180326,-1.0152077887669035,-57.26736902189198 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark06(-0.7951093848351954,-88.4286376333366,-3.2665933271082657 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark06(-0.7956830556721108,-38.91464089396752,-77.63544996684053 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark06(-0.7970923074479292,-1.5707963267948974,21.991148575128552 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark06(-0.7978914336872723,-1.5707963267948966,-1.5707963267948974 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark06(-0.8014042269738184,-1.5707963267948966,-2.0744675306948044 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark06(-0.8019334539413485,-45.05775987818914,-4.485907436681366 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark06(-0.8038495623062971,-0.7147260332751393,51.973784575665434 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark06(-0.8038674869282169,-1.5433930553871495,42.714303832825806 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark06(-0.8039636858387564,-32.905586273352554,-193.2071304369181 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark06(-0.8048532997582254,-1.5707963267948963,14.319137934240729 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark06(-0.8059795395540874,-19.369233358353256,-79.23538698011119 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark06(-0.8064308807190779,5.141595993380698,-184.766750332972 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark06(-0.8078359134743396,-1.5707963267948948,50.4520228773917 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark06(-0.8079235187918261,-0.7054875511741159,-48.607496122824706 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark06(-0.8085387289012346,-44.03258825186828,-94.75201128259182 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark06(-0.8101360736138745,-0.05622046364835469,4.388538937196362 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark06(-0.8104025928327167,-0.21346612712266205,-58.93047226193755 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark06(-0.811044847746119,-45.48151341291242,-1.5707963267948966 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark06(-0.8111209742782517,-0.5090564099094388,-1.2422350017759975 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark06(-0.8113657604813007,-0.2099570253888118,-78.16892343809485 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark06(-0.8124840122080732,-1.5707963267948966,55.834285017728575 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark06(-0.8130168913208164,-0.8707509663205126,100.0 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark06(-0.8132155867959585,-0.540331670472976,-2084.0153187902615 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark06(-0.8146023329060065,1.0842021724855044E-19,-67.28019929941985 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark06(-0.8158748600226327,-1.5707963267948966,4.71434211239726 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark06(-0.8161509830520544,-1.5707963267948966,-2421.0422975340007 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark06(-0.8165991906916957,-95.62131010758354,-17.153085833244162 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark06(-0.81708414837131,-1.5707963267948966,1.57082690317713 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark06(-0.8171550542124153,-31.865531779821495,-4.1417307621765485 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark06(-0.8176321627906304,-31.978575006141384,-142.58474661367885 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark06(-0.8193695402852512,-1.4591299683994166,0.39052099488500686 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark06(-0.8194031226029738,-95.43322298014583,-71.94292179265582 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark06(-0.8201862402767657,-8.881784197001252E-16,30.58273475056842 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark06(-0.8202732841987664,-1.5707963267948966,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark06(-0.8203976603196403,-1.5707963267948948,-1.5707963267948966 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark06(-0.8231403367827406,-0.40120619139705255,4.74369192495536 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark06(-0.8251214571850242,-88.1140090997279,-97.4869630152956 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark06(-0.8258980204160968,-95.37073946417603,-20.98828449236854 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark06(-0.8267544982777352,4.3368086899420177E-19,1.6668137611060274 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark06(-0.8269724681514066,-1.5707963267948963,94.37232263204865 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark06(-0.8297936332774557,-1.5707963267948966,13.141306793062805 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark06(-0.8300178228932169,-101.60434805454926,-22.399096227509347 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark06(-0.8303552398427847,-0.8309244986450022,44.546605134579266 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark06(-0.8308002669181981,-1.563838737701743,-3.141592653876162 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark06(-0.8334747988088536,-157.6418352599662,7.2686986457056975 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark06(-0.8346622485173915,-0.017000360481950614,-1.5707963267948966 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark06(-0.835003506536198,-1.5707963267948966,-40.03055472528321 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark06(-0.835241509951544,-1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark06(-0.8352526761562312,-95.33208190707514,-41.96640424945301 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark06(-0.835402264470984,-0.4664284914503236,32.790848150550204 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark06(-0.8355762592604232,-1.0502637605659175,67.42885819816863 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark06(-0.8374200839232205,-95.3024861417143,-90.49763138531445 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark06(-0.8382009964017623,-32.55003191692289,-1.5707963267948966 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark06(-0.8389400805576943,-1.5707963267948983,51.288685195120316 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark06(-0.8389691835866442,-0.18893919264477582,-6.713119321472381 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark06(-0.8398284447538297,-1.5707963267933422,-9.893524368198925 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark06(0.8399283592018776,0,0 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark06(-0.8400496454483833,-6.664600853951983E-14,-3.2218219661260354 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark06(-0.8402980636090017,-0.13739903077452587,-31.888821625432158 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark06(-0.8407133981033703,-1.5707963267948966,38.186463258587274 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark06(-0.8410076702367507,-157.33432623313192,-3.333278912186568 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark06(-0.8411418074504979,-1.5095302744413313,78.25006793135472 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark06(-0.8422134954421591,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark06(-0.8424080693913455,-1.5707963267948966,-30.731028909957047 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark06(-0.8442377400270558,-1.5707963267948966,1.5707963267948977 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark06(-0.8479169271110275,-7.105427357601002E-15,-101.73505518892784 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark06(-0.8488324772852396,-3.552713678800501E-15,-34.44443038748888 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark06(-0.8494965296462852,-1.5512310688563058,1.0867913842049162 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark06(-0.8497246053858399,-31.985871315132172,-40.27039188077646 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark06(-0.8504801150427852,-78.59295238084923,92.97195318701569 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark06(-0.850779010483592,-1.5707963267948957,1.5707963267948966 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark06(-0.8513214993248102,-32.887357679656645,-85.12695311127334 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark06(-0.8518308053295236,-31.56129058818438,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark06(-0.8536453661903394,-1.567255716998884,-36.26725015535473 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark06(-0.8539488682114743,-1.5707963267948966,25.734483674688303 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark06(-0.8542413684408225,-32.78278386758933,-1.5707963267948966 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark06(-0.8550074588002897,-0.4441630319573271,-1.5707963267949028 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark06(-0.8557676155547917,-1.5707963267948966,-35.423253638864566 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark06(-0.8579537023918508,-0.007939357349544906,-3.266592653591895 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark06(-0.8587402161849547,-3.1415926535897967,-45.548042609474095 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark06(-0.8592069025307382,-1.5707963267948966,48.03206350353973 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark06(-0.860670256461098,-19.356947918834937,-25.616574764395835 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark06(-0.8615374003478137,-38.907316875064296,-1.5707963267948966 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark06(-0.8631159868628991,-38.71875842269273,-35.63562820999765 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark06(-0.8634826639087123,-0.1590915920413316,33.59234680554363 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark06(-0.8639389773556228,-1.5042803562671063,164.86980060521725 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark06(-0.8641888667668773,-6.938893903907228E-18,-42.220094822419725 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark06(-0.8664268397949897,-1.2509523222735206,-94.32230454696007 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark06(-0.8675795524448011,-0.10233827366255333,98.87536412499136 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark06(-0.8683352867989941,-8.563150151552445E-11,101.63892989751375 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark06(-0.8686649854706746,-1.5707963267948966,-1.5707963267948948 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark06(-0.8694080003384613,-39.20767161343281,-46.62027157599529 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark06(-0.8700270536704451,-1.5707963267948966,46.024295483690956 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark06(-0.8700345401352234,-1.5707963267948966,39.1575071507455 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark06(-0.8704227253232254,-0.6947417472257102,-43.099540596877496 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark06(-0.8705483485015356,-0.011604261254335675,-45.87092595240492 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark06(-0.8705879113462015,-1.5707963267948966,-39.86979718486554 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark06(-0.8707105895003522,-1.1558748099978122,-89.81093108855922 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark06(-0.8712983258135403,25.132741370236257,-95.24939142026057 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark06(-0.8723975381737352,-1.5707963267948966,31.942128423058733 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark06(-0.8724567184605423,-1.7763568394002505E-15,72.5922106012692 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark06(-0.8728778895598062,-0.05544570895565293,36.396375343030314 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark06(-0.8730557304589155,-88.3913208244274,-996.685999417388 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark06(-0.873079380835895,-0.04515842818844762,1.5707963267948983 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark06(-0.8737226601684828,-1.5707963267948966,78.59221383443773 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark06(-0.8740965070290567,-0.6998802240528992,0.0 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark06(-0.8742438492692943,-163.3714103500269,-44.60643350556122 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark06(-0.8752893164720207,-1.5707963267948966,44.34729837845444 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark06(-0.8766171759688236,-45.08441353321201,-2.956192369326809 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark06(-0.8768770950340095,-45.226846296323046,-40.21716554714219 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark06(-0.8772594959678686,-1.5707963267948966,-71.07944760730376 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark06(-0.8786013464015007,-1.5707963267948966,-17.238337906202887 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark06(-0.8787759324335109,-27.043338503699445,-52.5131275851482 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark06(-0.8793166782160524,-1.5707963267948966,-95.83099043663088 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark06(-0.8803098903370549,-0.5575543943711949,182.15375766185718 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark06(-0.8806056992097815,-1.5707963267948966,43.8685004989663 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark06(-0.8815202790804246,-1.5707963267948966,-3.141592653589793 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark06(-0.8815304651530333,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark06(-0.8816230406920696,6.712388980385781,-1.5707963267948983 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark06(-0.8834779369663814,-1.5707963267948966,-3.141592653589793 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark06(-0.8842530454886769,-1.535442936635945,-3.2665927198847475 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark06(-0.8848858331220669,-0.2748829157110442,51.44078980503066 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark06(-0.8855994061105918,-1.5707963267948963,1.586799804715024 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark06(-0.8856125939499323,-31.646858595837628,-72.33181598605103 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark06(-0.8861187822740859,-1.5707963267948966,-59.15834881392752 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark06(-0.8864536651137326,-1.5707963267948966,1.5707963342529208 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark06(-0.887732028110761,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark06(-0.8882630019976836,-1.5707963267948966,-64.71070666927464 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark06(-0.8898047165183132,-1.3513658147168663,82.57771132678081 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark06(-0.8913219600241722,-44.04015483279039,-59.97578716556869 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark06(-0.8916150636702629,-1.5707963267948961,93.40233921245165 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark06(-0.8917600861559635,-0.7918926594806095,39.03678739211526 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark06(-0.8918009928969185,-1.5707963267948966,1.4790677633979923 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark06(-0.891916515030155,-1.5707963267948966,5.384230649403855 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark06(-0.8926798213305602,-95.7235306154595,-3.1415922932368825 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark06(-0.8929483774652298,-0.08401975795058814,3.141592653589794 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark06(-0.8932545556390713,6.71238965919033,-77.99837315656215 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark06(-0.8935692103190165,-5.770611636116085E-129,6.03759127934764 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark06(-0.8948883718313362,-45.341925791114605,-84.3943588122879 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark06(-0.8952180491793769,-44.52745609025929,-28.237239330097275 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark06(-0.8957297867636189,-0.46871368979742556,72.5581589929356 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark06(-0.8959657519954289,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark06(-0.8969735869914084,-4.0607069397050388E-115,84.47752449581216 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark06(-0.8976216832144258,5.141592653593566,-1.5707963267948966 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark06(-0.8979850579708704,-1.5707963267948966,58.62211486644066 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark06(-0.8985543197887509,-0.6125048658666141,31.913027914904205 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark06(-0.899257640811653,-1.5397983226242296,2.5707963266964486 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark06(-0.8999235894858089,-38.952317249353484,-86.20778956354181 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark06(-0.9006119361987942,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark06(-0.9009003135209651,-0.5669377348290962,-1.5707963267948966 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark06(-0.9009716298168564,-1.5707963267948966,-0.038842625083114486 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark06(-0.9021166895581622,-0.18347917854285445,-16.862768822853162 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark06(-0.9029791340864263,-1.568956239535686,-1.5707963267948966 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark06(-0.9052728114020129,-1.570796326794896,15.723589656028215 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark06(-0.9053653665290629,-1.5707963267948966,26.674024200318748 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark06(-0.9067649569932605,-1.5707963267948966,-83.07329428975841 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark06(-0.9084573293539734,-39.114590041809215,-85.14325783784173 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark06(-0.9090381918510761,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark06(-0.9096285133920006,-44.47603592852415,-163.45213313717449 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark06(-0.9101098517438466,-3.141592653773351,79.1182162950874 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark06(-0.9108256946730435,-1.5707963267948966,4.712388996980926 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark06(-0.9124572421076866,-1.5707963267948966,36.0868017892275 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark06(-0.912811861796549,-45.314767174488054,-67.46158091051974 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark06(-0.913928207519902,-1.2381713351289618,-8.342013974268099 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark06(-0.9162878779934722,-1.5707963267948966,-4.9500068128984545 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark06(-0.916289267284462,-1.0712126290901014,-227.74856513543645 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark06(-0.9172556918196193,-0.9122490413155954,-10.952435845876739 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark06(-0.9180038310004511,-1.5707963267948966,1.2393791675000618 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark06(-0.9181328144774756,-0.24021802749886934,1.5707963267948966 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark06(-0.9187198818053847,-0.8615132061702081,-81.4074287953662 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark06(-0.920746374551181,-1.0103009752263827,-10.781115495255694 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark06(-0.9221992062361768,-1.5707963267948966,76.9966460333219 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark06(-0.9224140201040943,-1.511216024530673,-34.12960558438922 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark06(-0.9234675767574756,-7.934023799330021E-25,-2.4085833506278265 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark06(-0.9236192893822727,-1.5707963267948966,-0.1447365379893962 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark06(-0.9241280363891544,-44.3088049221414,-127.10002483171317 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark06(-0.9241804802279816,-32.56433187120953,-39.397885148231396 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark06(-0.9246766676493795,1.3877787807814457E-17,-95.5322746227829 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark06(-0.9251195599005864,-1.5253567128401684,1.5707963267948966 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark06(-0.9263607750475791,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark06(-0.9283038713323575,-1.5707963267948966,-31.079126169559117 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark06(-0.9286549807180238,-0.23068072338714884,0.0 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark06(-0.9288043979212679,-1.5707963267948966,-43.982297150257104 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark06(-0.9288579020643548,-1.5707963267948966,-23.706362620381537 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark06(-0.9294844263172316,-1.570796326794897,-1.5707963036622803 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark06(-0.931626544302757,-1.5707963267949019,84.90971689880533 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark06(-0.9316794240237762,-0.10053077386619935,81.05633564036344 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark06(-0.9318943432389435,-1.5262149190438752,-38.75105537441884 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark06(-0.9326085456713971,-31.875999823680075,-142.79492840134787 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark06(-0.9343525092759237,-0.017701958117282646,-97.68491304440326 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark06(-0.9347877666069466,-0.036840782080957535,-34.518102092023724 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark06(-0.9360047771396367,-1.5707963267948966,-68.21138818149393 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark06(-0.9366734842701209,-44.29605995456254,-63.226358035807145 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark06(-0.9369913741815736,-1.5707963267948966,43.77185481661411 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark06(-0.9387260523951341,-1.5707963267948966,1.5707963267948977 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark06(-0.9391003019184627,-1.5707963267948966,-3.1415926537053687 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark06(-0.9394391150866103,-84.59697696487086,-4.14159267361231 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark06(-0.9397364139475708,-1.4583359109791978,53.92294151066392 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark06(-0.9414590230111616,-32.41807486726407,-31.423718145518265 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark06(-0.9424957704787011,-45.11943962447793,-89.79315108357889 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark06(-0.9433073706679719,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark06(-0.9442198774653552,-1.3004070096862639,1.5707963267948966 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark06(-0.9444946421649161,-0.06354798530741768,-157.36368977345603 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark06(-0.944754365042647,-1.5707963267948966,-1.5707963267949054 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark06(-0.9461910360920349,-8.09322360561805E-5,-27.987032684726376 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark06(-0.947568727274737,-43.98555097322292,-20.022009976966253 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark06(-0.9485013327732249,-1.4779773378084575,-50.11944151346916 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark06(-0.9487926455253288,-32.6725840676627,-91.27766758341453 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark06(-0.9493108911878573,-1.27182616393519,-18.294855674895565 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark06(-0.9496541166612076,-1.22518072710485,146.1048920810215 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark06(-0.9506443496256075,-1.0945882136424423,-100.0 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark06(-0.95091514487551,-1.5707963267948966,-54.012420081660096 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark06(-0.9516604878730428,-100.71038272817425,-28.14051149370993 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark06(-0.9523410452044349,-101.7416021857947,-78.75247722704219 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark06(-0.9532125434882772,-0.44964483089522234,-1.3576585742994847 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark06(-0.9547187716116947,-0.871140409322507,3.0882772087830146 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark06(-0.9559735795959199,-1.7763568394002505E-15,88.52181921675444 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark06(-0.9566155267475533,-37.94076554861251,-39.63004984305012 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark06(-0.9572013834920456,-1.3677643681865352,77.23697868110298 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark06(-0.9576232327133393,-5.028138874320437E-17,-1.5707963267948966 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark06(-0.9585086741534682,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark06(-0.9588427328377748,-0.4221158744097415,0.2728766567076944 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark06(-0.960028858180669,-0.5680650413171777,-2318.325911017796 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark06(-0.961225410272192,-32.845588683933485,-32.08410244764555 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark06(-0.9614972717137572,-1.5707963267948966,-49.622405618916446 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark06(-0.9618880779031805,-1.5707963267948966,-641.5085536870757 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark06(-0.9626938152701531,-1.5707963267948966,-99.28024741887421 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark06(-0.9627871923331278,-45.37632021608484,-6.283185307179603 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark06(-0.9647252914881183,6.712389135629666,-135.3638008798696 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark06(-0.9653856527780725,-0.011673179811540368,31.165854467759914 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark06(-0.9659020375889306,-1.5612746899622243,1.3367509828651412 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark06(-0.9660077971518739,-32.93084085974587,-40.378404970865006 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark06(-0.9665744404153116,-0.7328321544563607,9.748794031966074 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark06(-0.9667031456796172,-1.5707963267948966,20.453953911954585 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark06(-0.9669288498388842,-1.5707963267948983,26.9913127509126 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark06(-0.9708479704112387,-32.700564421147256,-9.879928344186606 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark06(-0.9709297821813839,-32.73368967310122,-3.141592653589793 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark06(-0.9719002864848209,-1.3620197912023626,39.22716947291755 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark06(0.9726911481499769,27.236110726491788,9.901713560234612 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark06(-0.9728571363293069,-1.5707963267948966,-55.715652242328 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark06(-0.9732781889719311,-1.5707963267948983,64.6756913063578 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark06(-0.9735276390155543,-3.1415926535900507,-59.26239246894577 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark06(-0.9739757449025077,-1.5707963267948966,-36.98640028573165 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark06(-0.9741356753856125,-1.2855277960564977,-1.5707963267948963 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark06(-0.9742035952061637,-1.5707963267948966,9.051859147306772 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark06(-0.976487049231459,-31.57482720515844,6.712398540414748 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark06(-0.9767046111098578,-1.5707952334933069,27.80117104445416 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark06(-0.9769231753966816,-1.5707963267948966,-4.743638990497581 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark06(-0.9770792878043804,-0.8912943561246938,-2.4584639750052872 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark06(-0.9772013076032495,-1.570796326794711,107.24535907658193 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark06(-0.9776175182553878,-0.9632197239005684,65.62226218139278 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark06(-0.9780141002537864,-0.22710068580708676,160.59682095524153 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark06(-0.9785223837327841,-32.681052440559974,-1.5707963267948912 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark06(-0.981873378494072,-0.3256182344230678,3.1415926535897967 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark06(-0.9821431681689031,0.1669927349538639,-1.5707963267948966 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark06(-0.9821870704766917,-1.5707963267948966,59.249057311426924 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark06(-0.9822462252983737,-1.5707963267948966,57.98432183987243 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark06(-0.9823664534192107,6.712389081914562,-38.85679498415994 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark06(-0.982861606229605,-31.453596220451477,-44.47088036073697 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark06(-0.9842550008866732,-44.11094114513109,-1.8798870138245762 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark06(-0.9846727978870053,-31.539582267208896,0.07885808475043467 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark06(-0.985018551533944,-1.5707963267948957,-40.58123976507024 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark06(-0.985874995403294,-1.5707963267948966,31.649696844363437 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark06(-0.9858805193438674,-44.46365309028818,-27.852855351309277 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark06(-0.9874491292545807,-1.5707963267948966,-95.78012402261037 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark06(-0.9881218154721164,-1.5707963267948966,2.220446049250313E-16 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark06(-0.9892458773739009,-0.6307963870060299,-33.73552116466627 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark06(-0.9894365846084461,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark06(-0.9894848016289068,-1.5707963267948966,18.205858037815386 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark06(-0.9897033235468612,-44.160486506962286,4.712456027493814 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark06(-0.9904256438227639,-3.141592653589794,-53.84368770353849 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark06(-0.9912190518955112,-1.5707963267948966,-57.85747873093631 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark06(-0.9918262645688976,-37.69911184456142,-61.107122852910166 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark06(-0.9927172798106394,-0.5215382288268186,-66.5086134888032 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark06(-0.992841833853193,-1.5707963267948966,-1.918247656677254 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark06(-0.9939020496803482,-37.69911184307752,-39.07772469943285 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark06(-0.994439785410792,-1.5707963267948966,-721.9082030607653 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark06(-0.9951991118102409,-0.6142201597133631,-1.3698808431302519E-194 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark06(-0.995522830384445,-1.058320359227252,1.5707963267949054 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark06(-0.9957483405286921,-1.5707963267948966,-45.278249480199705 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark06(-0.9968505572400375,-1.5707963267948948,-61.00265333132474 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark06(-0.9974567447677058,-1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark06(-0.9975251775592346,-19.373182243043036,-63.32546831038424 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark06(-0.9978593847137699,-1.5707963267948966,12.340226050115108 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark06(-0.9985153623166242,-1.1338374576831458,-45.913284872637064 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark06(-0.9989283518739578,-45.371559805272746,38.43509975411148 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark06(-0.9992328870436734,-1.6543612251060553E-24,63.64678991832796 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark06(-0.9993837979144837,-0.7326805177460709,3.1562054433489606 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark06(-1.0007208353926842,-0.821210656577561,1.5707963267948966 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark06(-1.0019076169904828,-0.5712467489177346,-317.61380280226837 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark06(-1.0025393656812889,-44.06366514744731,-39.24582063652586 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark06(-1.002607005768892,-19.378503955603207,-509.6463844107369 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark06(-1.0034873435612215,-32.89842633559054,-26.966778027039908 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark06(-1.0049450029055436,-95.40922930597648,-31.41592665635083 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark06(-1.0058662478194598,-1.5707963267948966,17.27924789202756 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark06(-1.0070546734726205,-32.80947740919881,-3.1415946028458364 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark06(-1.0070600450697804,-1.5707963267948968,-6.418567979635492 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark06(-1.007309108174607,-0.5604965540966569,89.63458028897105 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark06(-1.0078955210598295,-101.07842352292822,-60.44894466299708 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark06(-1.0079965969022495,-1.5707963267948966,1.404633588015684 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark06(-1.00995043277711,-1.5707963267948966,-4.7123889803919665 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark06(1.0103909445141629E-7,-100.9880852421217,-1.5707963267948912 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark06(-1.0106441513476705,-1.5707963267948966,-16.23844411946949 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark06(-1.0123152344171336,-1.3632230967396253,-1.5707963267948968 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark06(-1.012419554709993,-0.25464637815515423,-100.0 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark06(-1.0140351809591728,-1.5707963267948912,51.81248484125892 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark06(-1.0143159117531406,-0.561507275024572,-1.5707963267948966 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark06(-1.0152820429882068,-0.17416443413838809,-0.9932839998757137 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark06(-1.0169827236718825,-1.5707963267948968,0.0 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark06(-1.018291237557766,-1.5523332033955937,21.571638900359957 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark06(-1.0185755350589907,-1.5707963267948966,-34.275059437446615 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark06(-1.0199767442565257,-1.5707963267948966,2.3904989526338625 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark06(-1.0211369850465197,-1.5707963264988698,9.832555059029886 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark06(-1.021167366096074,-0.9119878228491827,-0.18219469692330034 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark06(-1.0212468202681918E-15,-1.5707963267948966,-43.650956141796925 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark06(-1.0215898146501983,-0.23812209887770297,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark06(-1.022488833422727,-3.2033329522929615E-145,78.24066397121516 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark06(-1.0246590976954406,-0.020112787848911375,-75.5685010413373 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark06(-1.0261342003245941E-289,-1.5707963267948966,-42.30019791923993 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark06(-1.0263627099033743,-1.9096494215373904E-10,-71.54770460232425 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark06(-1.02765144024877,-7.105427357601002E-15,-4.71434210538503 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark06(-1.0289302919073272E-17,-1.5707963267948966,72.25660932048538 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark06(-1.0310670608961436,-88.08959430052603,-32.56819837129727 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark06(-1.0320717372115908,-1.5707963267948966,3.1415926535897896 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark06(-1.032296716948637,-31.699330742496297,-60.290468126379594 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark06(-1.0325864932174404,-1.0150188710179295,2286.3366021826937 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark06(-1.033561179970825,-1.5707963267948966,82.05953525909885 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark06(-1.0343423559391667,-0.2907266032895204,-30.432862153798908 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark06(-1.0362653372363475,-84.55592442498947,-4.365152069207539 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark06(-1.0364846403295065,-1.5707963267948966,0.353232106868154 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark06(-1.0371812562377802,-0.09414074180741142,-40.187330122330806 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark06(-1.0376431820218406,-32.49677157573878,-3.141592653589793 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark06(-1.0379054957153813,-0.1326340962065251,-1.5707963381981633 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark06(-1.0412022880957916,-1.5707963267948966,-95.29641275323415 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark06(-1.0436855114695671,-1.5707963267948966,-80.06996123481555 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark06(-1.0438374968931168,-0.8853009559887037,4.714400828516314 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark06(-1.0439006613701087,-0.14785927869779353,1.9480143029956554 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark06(-1.045107452634042,-32.43278866247182,-57.61034699950722 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark06(-10.453292314595956,-75.92637295790783,-15.582415684573661 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark06(-1.0454275903657773,-4.731965206825376E-16,-51.907138295822776 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark06(-1.0456707684951896,-1.4486703720165197,40.956758122412964 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark06(-1.047527570635144,-3.1415926582211986,0.0 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark06(-1.0475620586887004,-1.5707963267948966,-11.324718763286768 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark06(-1.0488072783915978,-0.6034519342833523,-67.32333503811722 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark06(-1.0502939437564305,-1.5707963267948966,-44.7692330803256 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark06(-1.0508642140243312,-1.1507444051291242,-1.5707963267948966 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark06(-1.0509349297826216,-0.17851834291382812,284.28325323771253 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark06(-1.0518549904007832,-1.5707963267948966,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark06(-1.0523276865625473,-1.5707963267948948,-24.403996507514453 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark06(-1.0536787377824874,-1.5346132291258356,-144.5559163762324 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark06(-1.05381721769621,7.853980716870694,-1.5707963267948983 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark06(-1.053950318824983,-1.381721885142223,15.707963395152122 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark06(-1.0546688683489756,-0.9368104381521111,-77.46174018809056 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark06(-1.0551339470075023,-1.5707963267948966,25.777834341008763 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark06(1.055271246802377,-93.22635874572933,20.660090217241304 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark06(-1.05568899377457,-38.941606841530614,-821.3920604912533 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark06(10.559568432062363,85.09529497911808,80.08430296290021 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark06(-1.056823469010649,-95.72576202443288,-1.5707963267948966 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark06(-1.0570641254490731,-1.5707963267948966,253.89809278006942 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark06(-1.0586995386885043,-0.9627967397135203,7.2300861335021605 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark06(-1.0605190093892753,-0.7177321408790305,21.29482519087729 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark06(-1.062552126228611,-8.180868259513936,-1.5707963267948977 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark06(-1.0625737834412576,-0.6698005809863982,99.19710281515876 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark06(-1.0640103550452271,-4.440892098500626E-16,-0.6364966011357934 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark06(-1.0656106692001113,-0.4299137393049508,-48.013147890507796 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark06(-1.0657185894281502,-1.5707963267948966,4.743638980433411 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark06(-1.0659828722674713,-94.36043319347053,-19.349562864108506 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark06(-1.0676090686342228,-31.474043226491816,-163.39097609761802 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark06(-1.0687463312618173,-1.5707963267948966,1.5707963153389817 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark06(-1.068785233984643,-1.5707963267948966,66.31255194110865 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark06(-1.0699164295296981,-157.34348753110444,-57.8227279697841 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark06(-1.0702316838766772,-0.14991694145439133,4.258245413144039 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark06(-1.0718104040896181,-1.5707963267948966,7.378707733255874 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark06(-1.0720377513662172,-1.5707963267948966,-5.19468893786113 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark06(-1.0784446414872118,-0.895457381769016,-45.06300487979496 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark06(-1.079105041831794,-1.5707963267948966,7.853981625636778 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark06(-1.0791466125633375,-1.5408810295763105,-78.69006136116276 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark06(-1.079750496951254,-1.5707963267948966,-1.5711121528714154 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark06(-1.0819140036279749,-0.7486241508746487,-1.5707963267948966 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark06(-1.0824408421433134,-95.50824432983175,-50.77675578736514 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark06(-1.082709763671145,-1.5707963267948966,56.51764758125916 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark06(-1.0838987177917667,-1.5707963267948966,56.353774229124 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark06(-1.083899840114932,6.7123889803877255,-89.75379369388214 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark06(-1.0842021724855044E-19,-0.5742884904641875,-6.712478837768007 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark06(1.0842021724855044E-19,-0.8875843144128364,58.17263104769776 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark06(1.0842021724855044E-19,-1.232310660736633,-32.939444416203344 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark06(-1.0842021724855044E-19,-1.5707963267948966,-65.97344572538032 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark06(1.0842021724855044E-19,-1.5707963267948966,73.7565244493561 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark06(-1.0842021724855044E-19,-95.81857593113276,-58.098183435531176 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark06(-1.0866219812824056,-0.4163973005807176,-97.09573927388195 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark06(-1.0871629070088122,-0.02115537789482832,348.7162088559509 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark06(-1.0876144059533233,-1.5707963267948966,-24.273824970389533 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark06(-1.0892953059425499,-0.34159674471953233,11.120909778923915 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark06(-1.0893097540617347,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark06(-1.0894094282226519,-1.5707963267948948,37.115998144762926 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark06(-1.0908710335212897,-1.5707963267948966,10.767872199143532 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark06(-1.0914740629127686,-1.5707963267948983,2432.975016209941 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark06(-1.092313485798512,-32.61155177394273,-1.5707963267949054 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark06(-1.0925404553965858,-1.5707963267948966,77.83965955525301 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark06(-1.0940324035860933,-1.5707963267948966,47.86420707104463 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark06(-1.0944421234905646,-0.452351806412266,40.393246580663714 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark06(-1.0947644252537633E-47,-1.5707963267948966,-78.53981633974037 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark06(-1.0951350956398115E-13,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark06(-1.09628133989042,-1.5707963267948966,1.191582334809495 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark06(-1.096290759257962,-1.5707963267948966,65.31068620099299 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark06(-1.0967157259658347,6.712388980385997,-51.738054879738705 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark06(1.0971346755352353E-16,-1.5707963267948966,43.74686141956499 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark06(-1.0975685377668594,-1.4943977230870429,20.42300879880494 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark06(-1.0993308548222296,-0.07895828501450065,15.38121881166901 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark06(-1.0996688157205783,-0.6886682593262269,3.847882734397224 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark06(-1.1000375675138303,1.0842021724855044E-19,0.08837544206914345 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark06(-1.1005207775065482,-1.5707963267948966,33.38210466398302 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark06(-1.1007864955946047,-1.5707963267948966,133.86489415814776 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark06(-1.1007876326328947,-5.293955920339377E-23,-21.095586525839806 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark06(-1.1011500072010527,-1.5707963267948966,45.26245166804849 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark06(-1.1035999842055668,-1.5707963267932894,-3.141592653589793 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark06(-1.1056472229940448,-44.2028734090089,2.1684043449710089E-19 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark06(-1.1067211383086495,-2.2227587494850775E-162,-32.49098650201448 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark06(-1.1084648456544812,-32.83372959630943,-26.655017142799622 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark06(-1.108582493960003,-0.6637003583276743,65.08867308943094 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark06(-11.086133316609818,61.17453795728758,-12.907690467571413 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark06(-1.108638027226391,-1.5707963267948308,-71.92803453622099 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,0.0,0.0 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,0.0,2110.5225127896356 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,0.0,2454.2786716602645 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,0.0,67.12197931403793 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,1.4262998604604614E-16,0 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,-2.571915968272428,0 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark06(1.1102230246251565E-16,-88.24486856155188,-45.0782670224076 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark06(-1.110901637912633,-1.5707963267948966,-96.05864939778726 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark06(-1.1113362500684387,-1.5707963267948966,0.32091333225865365 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark06(-1.1134555915877316,-1.5707963267948966,4.932151073913775 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark06(-1.1161919087671266,-1.5685999110059603,3.1415904843768536 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark06(-1.1167789195883662,-1.5707963267948963,-1.5707972805368107 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark06(-1.116891042651892,-31.59333938525934,-81.80803825463603 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark06(-1.1170868901247717,-1.5707963267948966,8.649426727056806 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark06(-1.117165702785787,-1.5707963267948966,727.9821766688644 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark06(-1.1171665141141485,-0.03471049662661466,-127.87638692407273 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark06(-1.1176433303784299,-0.9878274768889046,-77.64591183898419 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark06(-1.1179358186831658,-1.5707963267948966,64.24408602583163 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark06(-11.179666698226413,-30.43358098199407,-92.4473039827231 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark06(-1.119006797890023,-24.022710035446977,0 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark06(-1.1193310145542845,-1.5707963267948966,-3.606632272572553E-130 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark06(-1.120804006964607,-31.750022379753048,-45.81959787407173 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark06(-1.1210262714711876,-158.6176805126871,-1.5707963267948983 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark06(-1.1219310340667807,-0.9311229720884886,100.61297187763635 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark06(-1.1222811085191267,-1.4104414485031065,-72.25663103256524 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark06(-1.1223462310246801,-1.5707963267948966,76.23689694857032 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark06(-1.1225431838020938,-1.5707963267948966,-42.10338999122083 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark06(-11.234074077192574,45.48130689908413,-22.756149629672876 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark06(-1.1236004358960516,-1.5707963266565452,-9.563364247023216 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark06(-1.124196111293541,-4.3368086899420177E-19,-78.2550110669179 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark06(-1.124492702161192,-1.5707963267948983,-15.253591943395765 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark06(-1.1249782738077527,-1.194271028855553,0.0 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark06(-1.1251966726691716,-1.5707963267948966,38.86141554343533 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark06(-1.1252239819829155,-1.5707963267948966,-96.47051945773532 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark06(-1.126471672171472,-84.51579185329813,-96.9136044274679 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark06(-1.1264841478592564,2.5959654636612544E-21,-1.5707963267948966 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark06(-1.1267720337621714,-1.308938653784963,35.253345361567625 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark06(-1.1277669634106398,-0.5170056024222645,186.92466581076678 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark06(-1.1288075863667493,-32.65925294754723,-1.5707963267948966 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark06(-1.1289008635425357,-1.5707963267948966,-49.106906339626235 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark06(-1.1301161616992963,-1.5707963267948966,116.09361368249037 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark06(-1.1301278053873745,-1.5707963267948966,93.11220229212037 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark06(-1.1313648619502916,-0.18516494615267737,-1.5707963267948983 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark06(-1.1315373634173678,6.712388989474373,-1.5707963267948966 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark06(-1.1325704269516117,-1.5707963267948966,-56.89670407120408 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark06(-1.1332123973639385,-0.17532613232917943,-1.5617306069335257 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark06(-1.133217886554601,-1.5707963267948966,-88.31801565870326 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark06(-1.133423517758199,-45.26894236795102,-88.97149018062287 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark06(-1.1355579199635344,-1.4033201492142693,-11.205830888252743 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark06(-1.1356547764319258,-101.80884000786891,-9.473134734193195 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark06(-1.1365778135913365,-45.0762848638007,-41.30168641174928 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark06(-1.137181052273337,-1.5707963267948966,55.3984052729993 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark06(-1.1372869547587925,-31.575917383444565,-38.3055581191735 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark06(-1.1374308068123524,-1.5707963267948966,-69.43736316770485 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark06(-1.137555673556675,-88.25837847947668,-1.5707963267948983 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark06(-1.139118255173685,-2.220446049250313E-16,-55.964655758206334 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark06(-1.1399819339314525,-1.5707963267948966,-135.374376295582 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark06(-1.140411309599855,-0.9944486134426876,-73.6532197878419 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark06(-1.1410962051502518,-31.415926597376036,-1.9737374544768045 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark06(-1.141402372751876,-1.5707963267948983,23.984866899509612 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark06(-1.1425357692290277,-1.231952124277266,-73.94694366285619 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark06(-1.142987391282275E-100,-1.5525753679784324,-1.5707963267948963 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark06(-1.1437339762350487,-45.048341557488534,-46.85911423238819 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark06(-1.1443583001917146,-1.5707963267948966,1.5710404822936266 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark06(-11.44932131227651,-73.18440507299763,-49.51443654513024 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark06(-1.1460416815941166,-1.5707963267948966,-70.79169073284703 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark06(-1.146456651350988,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark06(-1.1468433408279024,-0.22752327505574052,-78.11278204999128 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark06(-1.1485377631114224,-1.5707963267948961,-53.68994031249435 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark06(-1.148579046743638,-1.1876548580676087,73.49470433375298 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark06(-1.1487957237887145,-1.5707963267948897,83.48161971851013 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark06(-1.1493639508720084,-3.1415926535903833,-54.548519341739365 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark06(-1.1496613655504357,-1.5707963267948966,90.52320268601167 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark06(-1.1502599071556123,-1.570796324850089,1.5707963267948983 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark06(-1.1520558366187323,-44.310958612241166,-20.53512422127151 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark06(-1.1523574069393065,-1.5707963267948966,-82.66120077791052 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark06(-1.1525755990088467,-1.5707963267948983,-55.08583984314949 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark06(-1.1530521271037544,-102.03357698840692,-21.99114958673539 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark06(-1.1533106054049764,-1.5707963267948963,-68.57773066816146 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark06(-1.1535901749715447,-0.5038372060781068,1.5707963267948966 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark06(-1.154122327223217E-128,-1.0374988618984593,5.222082627377162 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark06(-1.1546703614115832,-1.5707963267948966,-1.570796326790795 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark06(-1.1546800201042045,-0.17662902180321824,-0.43146068142557775 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark06(-1.1555649219535984,-101.0939029537289,-31.509176911073418 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark06(-1.1564466767524175,-1.5707963267948966,-96.2996510470048 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark06(-1.1566121998379495,-0.1817186707652876,-1.5707963267948966 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark06(-1.1567044109735558,-1.5707963267948966,-2.570796326645423 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark06(-1.1570181290583892,-0.9057634141475436,-48.79316284184454 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark06(-1.1576743838919268,-0.2987240408911826,-9.42477796076938 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark06(-1.1577760191568423,-32.85546226294575,-1.5707963267948966 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark06(-1.1580248784254303,-1.5707963267948966,-9.782355377699275 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark06(-1.1621218064380174,-1.4222112380645757,-36.37860701818374 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark06(-1.1636541530803615,-1.0205339731506202,8.837411450685249 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark06(-1.1650897334532901,-1.5560058294835957,0.0 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark06(-1.1672125541366807,-0.4750715001329625,-63.12105180906367 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark06(-1.1688085621323367,-0.1596694221300996,3.2665926548417117 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark06(-1.1698806792829828,-1.5707963267948966,6.938893903907228E-18 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark06(-1.1706010086396994,-3.1415926535897953,88.70730996350869 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark06(-1.170968560241945,-38.89262589981844,-4.364371518672968 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark06(-1.172382942713265,-0.9816793188379629,0.5705901087167776 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark06(-1.17284179355049,-1.5707963267948912,-93.42800034291263 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark06(-1.1731552422332994,-1.5707963267948966,-85.39965833468852 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark06(-1.1751560488550838,-1.5707963267948966,1.5707963253289738 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark06(-1.1759468933862394,2.1684043449710089E-19,60.72841613493591 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark06(-1.1760426378393323,-1.5707963267948966,61.347493901429445 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark06(-1.1761773640483488,-1.5707963267948966,30.068176455990155 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark06(-1.176893073749076,-1.5707963267948917,45.17181337474041 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark06(-1.1774577700699138,-1.570796326794893,-99.47881832924142 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark06(-1.1777639371907753,-1.3793381090484798,51.578627022359846 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark06(-1.1781235258396354,-9.41656446700472E-10,-87.96459430051421 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark06(11.781903257442039,4.659012206612317,-52.775163011697735 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark06(-1.1794758920861586,-95.76774008152043,-71.1037228562126 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark06(-1.1795603891637294,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark06(-1.1804369890102901,6.7123889807509265,-70.82470992476415 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark06(-1.1806854148478507,-4.616489308892868E-128,-43.37368130890889 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark06(-1.1812386332492635,-8.881784197001252E-16,1.5707963267948843 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark06(-1.1824055070849753,-1.0827539420309233,-61.55548818011076 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark06(-1.1829283219516447,-1.0786092080331289,-6.784512709296884 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark06(-1.1836300457104736,-0.8990581860534427,0.8702251827781056 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark06(1.1843846243132248,-36.37434106272006,-13.649768861659169 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark06(-1.18451366873979,-1.5707963267948966,-25.534444401922098 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark06(-1.1854741922229257,-0.3513405953073477,20.849483035455886 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark06(-1.185571705627486,-0.13320122913184207,-3.1415926535897953 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark06(-1.1867239887206988,-0.9217342410286435,-942.3584533561663 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark06(-1.1883320262147725,-1.5707963267948966,-10.985924713451565 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark06(-1.188423717296707,-1.5707963267948966,5.708627612394043E-16 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark06(-1.1902622276343169,-1.5707963267948966,-62.146365683410785 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark06(-1.1902631017631145,-1.8033161362862765E-130,100.0 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark06(-1.1907986822510868,-1.5707963267948966,55.45161662370983 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark06(-1.190965913440542,-1.5707963267948966,7.967017044667875 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark06(-1.1915072145875982,-1.0039368689324526,1.6940658945086007E-21 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark06(-1.1934592936827706,-2.2227587494850775E-162,-1.5707963267948966 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark06(-1.1936950787301936,3.3881317890172014E-21,-60.59172750990973 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark06(-1.193740379164418,-1.5707963267948966,1.1634728779393684 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark06(-1.1944455882376535,-0.5477717332919305,68.65999817604789 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark06(-1.195066035755699,-1.2573342517041093,64.90949678013638 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark06(-1.1951170050279254,-1.0928119542564556,1.5707963267948966 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark06(-1.1959905226458465,-1.5707963264418072,-1.3359127022998019 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark06(-1.1960673813890779,-0.651858198956097,-46.88624666821306 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark06(-1.1962032684365107,-1.5707963267948966,55.56682061907342 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark06(-1.1964606976539391,-32.621254502010245,-44.11141462158934 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark06(-1.1978274013782269,-1.5707963267948966,55.56574204744882 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark06(-1.1989297181696168,-100.54644363918752,-26.768980842201003 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark06(-1.199504040167176,-44.25542998823805,-39.97465104028757 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark06(12.020997343610148,27.214503799998482,50.671420887071434 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark06(-1.2031442689902854,-0.6216361404838336,-86.73493531883018 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark06(-1.205023822647977,-38.848672179576646,-8.826188161412755 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark06(-1.2058907050740055,-1.5707961439064972,-1.5707963267948966 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark06(-1.206038394413813,-1.5707963267948966,-48.61917521408423 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark06(-1.206742279028978,8.480857743879096E-13,-158.4165459705935 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark06(-1.2078837009555907,-0.21460127329883916,0.0 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark06(-1.2081781387056159,-1.5707963267948966,-48.962284939573934 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark06(-1.2083346206565777,-45.11658695852048,-52.475434875751255 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark06(-1.2088848893782445,-1.5707963267948966,-1.2947397071716242 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark06(-1.2094567717112454,-1.5707963267948966,49.53031060403028 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark06(-1.2107558435922234,-1.734723475976807E-18,43.276602831378064 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark06(-1.2113172206676335,-1.570796326794894,-49.548457482940336 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark06(-1.2114234661528407,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark06(-1.2134924597507144,-32.85946882261126,-59.53481022253557 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark06(-1.2142132784866675,-100.78134865999536,-1.5707963267948934 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark06(-1.2151794632075583,-1.1667769259627134,0.0 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark06(-1.2153289811915453,-1.5707963267948966,-101.74633404709319 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark06(-1.2169025901352253,-1.5707963267948966,555.5098417591299 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark06(-1.2172054233976168,-0.6668088898130733,-1.5710406985810887 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark06(-1.2177664746488628,-0.24581029193727397,63.75341471171603 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark06(-1.2179145698409173,-1.5707963267948948,1.5707963267948968 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark06(-1.2187648599596056E-9,-95.81857325252244,-109.95570320803333 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark06(-1.2188433373406227,-1.5707963267948966,-3.141592653648001 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark06(-1.2191897345301013,-44.32121035103392,-169.73224371137178 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark06(-1.2201430078902848,-1.3228595659648814,-53.40707734921331 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark06(-1.2206731470356371,-1.5707963267948957,0.0 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark06(-1.220868511036652,4.930380657631324E-32,49.7548472678433 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark06(-1.2214259712458349,-1.5707963267948966,343.23803598805347 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark06(-1.2218073765861228,-1.5707963267948963,0.0 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark06(-1.221937741636103,-1.5707963267948966,-33.446405433462814 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark06(-1.222001535074786,-32.573575573887425,-485.7882061041179 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark06(-1.2220363164532344,3.3087224502121107E-24,82.11506314034276 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark06(-1.2230993103450318,-1.105240308174883,3.1415926552310456 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark06(-1.2235998185398143,-1.5707963267948966,-22.022408977874353 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark06(-1.2248194041394176,-1.5707963267948966,-45.89814835011631 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark06(-1.2253043897740088,-1.5707963265068798,1.5707963267948983 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark06(-1.2254575834260504,-1.2953984803430265,-15.157749706694787 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark06(-1.2255653666899973,-1.5707963267948966,-3.1415926619759693 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark06(-1.2260408566670862,-1.297026463153762,-0.37355371580415164 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark06(-1.226154965805227,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark06(-1.227979934981057,-0.7669820389920214,-8.464920367482009 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark06(-1.2280374649832482,-1.5707963267948983,49.712054914239346 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark06(-1.2287295200314945,-1.5707963267948963,-36.17682978077703 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark06(-1.2290054146442477,-1.5707963267948966,157.57776967736459 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark06(-1.2292758604412748,-1.5707963267948966,-64.80842677436402 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark06(-1.2301540695195872,-1.5445792580728128,33.37623134408164 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark06(-1.2334615647942933,-1.1591269220898192E-69,-15.362090264566561 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark06(-1.2338285436175145,-1.5707963267948966,-3.3165845184546625 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark06(-1.2341336169745145,-1.5707963267948966,227.7654567596182 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark06(-1.2346678354739995,-1.5707963267948983,-36.4795391555099 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark06(-1.2383031005637264,-32.788544680446854,-1.5707963267950107 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark06(-1.2383973966961384E-10,-1.5707963267948966,-3.237597298652576E-12 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark06(-1.2388791231556169,-88.26399052864909,5.551115123125783E-17 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark06(-1.2399796119363689,-1.5707963267948966,-7.880860428658586 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark06(-1.2400475577344872,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark06(-1.2400628475009459,-1.4072951003366503,-53.21098214991356 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark06(-1.2405225311012178,-38.72338868944712,-85.6111725989173 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark06(-1.2410434804339388,-44.99446412732636,-3.1415926535899494 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark06(-1.2421952487996286,-1.5707963267948966,-99.60572054426922 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark06(-1.2428094247697785,-8.849617037251878E-14,-181.91933750591656 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark06(-1.2446664660159619,-1.5707963267948966,67.77043179049994 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark06(-1.2453199936409143,-1.5641274181117976E-148,0.6308115118476474 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark06(-1.2465050843601122,-44.1319121326911,-2.332289745986941 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark06(-1.2476512019297417,-1.5707963267948966,-45.53517632566047 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark06(-1.2480462463567659,-1.5707963267948966,-67.60194569006673 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark06(-1.2485717747731893,-1.5516739371113049,52.34881345302851 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark06(-1.2487176742567092,-0.2938957439865963,36.24544585798878 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark06(-1.2493718064564463,-32.46715701258787,5.293955920339377E-23 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark06(-1.2495125981961392,-44.196958721542494,-1.5707963267948966 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark06(-1.2499733520197402,-1.5707963267948963,1.5707963267948966 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark06(-1.2503564951478803,-45.079827110698375,-192.80146806213116 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark06(-1.2505909139691846,-44.55186560832804,-129.95112042089886 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark06(-1.2507084273816318,-31.71107605251396,-69.11511172749591 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark06(-1.2510943383421524,-1.778206999588062E-161,-4.231664986582838 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark06(-1.25170093628207,-1.5707963267948966,95.31537429476651 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark06(-1.2521687763636706,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark06(-1.2524708914247944,-1.4155890254891892,-32.92307707547715 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark06(-1.2526737941072592,-157.3345614873808,-17.100182015527594 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark06(-1.252778654951535,-1.5311330955135816,-57.62893392279112 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark06(-1.2548711645951576,6.712389427589083,-10.858477724314591 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark06(-1.256352043852611,-1.5707963267948948,-21.590822922952903 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark06(-1.2566061561563764,-1.0517868424577599,0.9010878732575722 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark06(-1.2573301608694578,-1.5707963267948966,12.466233217841605 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark06(-1.2578622296755877,-95.34047918495607,-4.141592653589795 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark06(-1.2582421893286015,-1.5707963267948966,93.84968467060878 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark06(-1.2600131911993042,-1.5707963267948966,-64.40398670882908 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark06(-1.2602013680647177,-1.5707963267948963,-55.84185912073069 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark06(-1.261001409612484,-1.5707963267948966,-45.06696729876022 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark06(-1.2612802113414507,-1.0851172435803393,-42.630737455751245 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark06(-1.2616518230170861,-0.07937756963821258,-66.04840796901284 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark06(-1.263118921349872,-1.5628244373307416,-1.5707963266027234 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark06(-1.2634920662350609E-175,-1.5707963267948966,-95.2804921910501 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark06(-1.2636956700936852,-95.54939712117869,-15.442197285066634 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark06(-1.2638958341362848E-9,-1.5707963267948966,-15.707879376746202 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark06(-1.2645843190502184,-1.5006746434271678,98.96016859054316 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark06(-1.2646630779939476,-0.9642416111290473,8.658460246836404 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark06(-1.265027525911195E-13,3.944304526105059E-31,-66.64726263924672 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark06(-1.2650679936100588,-1.5707963267872072,1.5707963267949725 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark06(-1.2651271217127988,-3.1415926710503763,84.54731665495686 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark06(-1.2652765423803891E-14,-0.03454797098006068,88.74541747770785 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark06(-1.2667806482588684,-38.97940491019323,-7.770193856515573 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark06(-1.2674418708044342,-1.5707963267948966,-85.39885471375715 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark06(-1.2685871390337837,-1.4087581116762011,3.141592653589794 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark06(-1.2689378198358752,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark06(-1.2689709186578246E-116,-1.5707963267948966,0.5190362588291648 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark06(-1.269025819699408,-0.36715162621569064,-95.78235890828896 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark06(-1.2694029191681537,-0.6437023265111491,17.9820240103479 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark06(-1.269544562941402,-1.484209990366476,57.53071817314942 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark06(-1.2712724738978796,-43.98407225246347,-46.6671007237167 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark06(-1.27319802777129,-0.042110660654054,-52.189948351435284 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark06(-1.2748793525815885,-0.11713076468786565,108.14305846839981 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark06(-1.2753931653126327,-32.9464770197475,-38.8155205346226 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark06(-12.757354682159857,-73.44239902592034,5.691968755736653 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark06(-1.2762036454964136,-0.5958133780808714,-27.077263812690916 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark06(-1.2768726202891534,-1.5707963267948948,-63.348673321496406 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark06(-1.2770617220889633,-95.74673402785075,-179.53193026327497 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark06(-1.2771744302602128,-39.05457889043804,-67.26223578567668 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark06(-1.277508246187791,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark06(-1.2782827626795021,-1.5707963257215363,-39.93998315980329 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark06(-1.2789365068743537,-1.5707963267948966,-29.206966023088327 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark06(-1.279869464643049,-1.5707963267948966,-1.570796326794877 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark06(-1.2805988053046748,-2.0303534698525194E-115,3.240633649109151 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark06(-1.2810559343066292,1.6317635198363878E-7,103.01604484343265 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark06(-1.2812039364453636,-0.8769162616852202,-44.80980675876719 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark06(-1.2849256305245418,-1.4384112017264636,-68.99696962848775 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark06(-1.2865964007932418,-88.34033413714795,-1.3034609441088196 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark06(-1.2868893973670072E-85,-0.2265202328762044,1.5707963267948983 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark06(-1.2885273043046863,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark06(-1.2892221853552008,1.1102230246251565E-16,-1.5707963267948966 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark06(-1.290311991871775,-0.44125105681685994,3.7209255373264156 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark06(-1.2908853143670576,-0.41586103034242683,74.51061762116706 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark06(-1.291420566660301,-32.479050507171095,-65.62302092138405 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark06(-1.291592685049043,-27.104782469287358,-45.28796893957025 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark06(-1.291996154839799,-1.4174174501918004,1016.1335494887641 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark06(-1.2924697071141057E-26,-1.5707963267948966,70.6858345048784 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark06(-1.2929865670128144,-0.16238843242385492,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark06(-1.2930496276004886,-1.5707963267948983,70.15568218179342 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark06(-1.2933189600829582,-38.722518910272484,-1.5707963267948966 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark06(-1.294025514711094,-0.5200925323528285,28.64434389967375 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark06(-1.2946751672641916,-0.00577743158618896,-13.403929482509213 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark06(-1.2972708141468543,-1.5707963267948966,-54.2700420790742 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark06(-1.299250277002083,-1.5707963267948966,0.7898632298235846 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark06(-1.3005091764913326,2.710505431213761E-20,-79.7604996771555 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark06(-1.3011019710053322,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark06(-1.3034144672343597,-94.24777960769379,-88.28438849735498 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark06(-1.3042823026677952,-1.3089103948766336,0 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark06(-1.3047488867336625,-1.5707963267948966,1.2813331809171846E-144 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark06(-1.305612336963673,-1.5707963267949039,157.64628633714884 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark06(-1.3064042100400788,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark06(-1.306914689858501,-1.5707963267948966,5.134765310875108 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark06(-1.30696791343849,-45.2263044055872,-101.65176693223722 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark06(-13.070481863325313,-55.597273163977356,-35.47286632398523 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark06(-1.3081578680532275,-44.49255866501647,-44.999241448585316 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark06(-1.3093574315208505,-1.5707963267948966,70.9718719825832 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark06(-1.3112186265439658,-1.1289603575756288,-70.68945938956539 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark06(-1.3123634028420916,-45.157227691048206,-1.5707963267948966 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark06(13.13083441283915,-96.00660250380338,-66.4512770634194 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark06(-1.3131319027839585,-0.16415936996902758,-1.5707963267945952 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark06(-1.3138855651269177,-1.5707963267948966,-489.1613701613409 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark06(-1.3140051365643095,-1.2227324246613365,68.53652902822475 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark06(-1.314499069615605,-0.37478858919072167,-66.92629344953832 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark06(-1.3146168224193708,-1.5707963267948966,-65.12309600888096 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark06(-1.314980650423541,-1.5707963267948966,35.787137240777646 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark06(-1.3153242137759396,-1.5012543494419717,156.33578776478282 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark06(-1.3156010886813345,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark06(-1.3158131619961092E-15,5.421010862427522E-20,10.548657176703903 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark06(-1.3165792049930882,-2.220446049250313E-16,-53.890536910719014 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark06(-1.316911154234596,-1.5707963267948966,74.32102730050096 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark06(-1.3172205223302478,-1.5707963267948966,85.74814116697613 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark06(-1.3173517275206972,-38.87478747750323,-4.2351647362715017E-22 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark06(-1.317884529591548,-0.13089129075046282,501.86958640940907 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark06(-1.3181438750970687,-31.77691834525416,-71.87175894506994 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark06(-1.318392703393121,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark06(-1.3191420034291348,-1.5707963267948966,3.1415926535897936 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark06(-1.3204163957873905,-1.5707963267948961,-2.4534932610589504 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark06(-13.222175651979612,75.88012304502669,27.920941995863586 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark06(-1.3227370299787167,-1.5707963267948966,39.16828157065426 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark06(1.3234889800848443E-23,-0.4569917418964396,-48.56549090842493 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark06(1.3234889800848443E-23,-32.98162606628399,-6.505224665669842 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark06(-1.324594852204138E-15,2.220446049250313E-16,71.51804134421809 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark06(-1.3249411072770434,-1.5707963267948966,-24.655905146067923 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark06(-1.32495936177838,-31.415926535897945,-45.869868442080616 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark06(-1.3252453164032743,-0.1192778733301243,-1.5707963267948983 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark06(-1.3252984099289926,-32.52222212348774,-1.5707963267948966 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark06(-1.32556408157844,-1.5340868202576579,56.25760174515793 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark06(-1.3273807668864377,-0.036348496736303894,-3.2665944283946065 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark06(-1.3275024391281764,-1.043882224793382,1.5707963267948966 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark06(-1.3275796079123268,1.3877787807814457E-17,-88.63638821337854 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark06(-1.3276805545472823,-1.0224258420444685,-0.7930407127607442 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark06(-1.3285578033524201,-3.552713678800501E-15,-202.89722638134913 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark06(-1.3292510510447946,-88.47356683975524,-58.93679372694518 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark06(-1.3297161949950795,-1.249856503413957,51.51717972103006 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark06(-1.3301211555252362E-15,-1.5707963267948966,45.122984627434164 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark06(-1.331089354030846,-0.15723515711626912,-77.95053145684193 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark06(-1.3317161586166666,-1.5707963267948966,6.877670006017427E-24 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark06(-1.332293587809142,-1.5707963267948966,-26.965003635880603 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark06(-1.332330173722454,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark06(-13.342473908160073,53.4824441982982,-70.18739301516746 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark06(-1.3357676703054882,-1.5707963267948966,-6.283243249456846 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark06(-1.3380147687583035,-1.5707963267948963,0.19509703832809108 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark06(-1.3380302865695481,-1.5508266881697894,-1.5707963267948966 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark06(-1.3381077760525244,-1.5707963263788918,0.0 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark06(-1.3383269967658957,-1.4705810225213718,-66.09061243562729 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark06(-1.3407040089497158,-1.5707963267948966,1.5708003300780866 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark06(-1.3407647198793413,-1.5707963267948966,37.69911184307752 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark06(-1.3418791297429982,-95.73856634164045,-69.43323528056271 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark06(-1.3421202361634232,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark06(-1.342120564867212,-1.1102230246251565E-16,-44.96556767367416 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark06(-1.34344993490081,-1.5707963267948966,1.5710416135261067 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark06(-1.3439293513505708,-32.64984755607921,-57.80930985668047 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark06(-1.3456452390968179,-1.5707963267948966,1.5707963267949054 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark06(-1.347411896254051,-0.06353483764707177,5.23775333708147 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark06(-1.3475778184342935,-0.4017846834356029,3.2666737888741215 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark06(-1.3480944003881823,-1.1716552600861694,28.013897069613062 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark06(-1.3485752629378371,-88.3408443119727,-61.10018224827989 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark06(-1.349777918388902,-1.5707963267948966,52.59273121288848 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark06(-1.3504623418274884,-1.5707963267948966,38.806709996146765 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark06(-1.3508068024458167E-225,-1.5707963267948966,-12.073574718348794 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark06(-1.350937893510262,-39.08430364588678,-45.44888112229816 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark06(-1.35115470551648,-7.105427357601002E-15,-68.42034050733126 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark06(-1.3523443680641143,-1.5707963267948966,3.1415926548295565 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark06(-1.3524219021176385,-1.5707963267948948,4.680762370464976 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark06(-1.353348085321109,-1.2925207713497533,56.08859848802679 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark06(-1.353518293154314,-0.43510700898655846,53.88490325568755 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark06(-1.3537272074764355,2.465190328815662E-32,1.5707963267948966 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark06(-1.353773900123296,-1.5611569703729886,68.45737042557064 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark06(-1.3540549707879337,-1.5707963267948473,17.69919162321895 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark06(-1.3543454205693288,6.712388990336212,-10.82467031192501 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark06(-1.3545531380070837,-31.445022185987746,-78.20911076047861 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark06(1.3552527156068805E-20,-1.244391650349411,11.044241542339442 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark06(-1.3552527156068805E-20,-1.5707963267948966,-39.269641354771835 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark06(-1.3556150222201113,-1.5707963267948966,-98.62003396224327 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark06(-1.3563161831193016,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark06(-1.3595450917121206,7.853981621537681,-1.5707963267948966 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark06(-1.3599436182449332,-1.5707963267948966,-88.50343556775995 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark06(-1.3599549933740245,-1.5707963267948966,-1.2182919002490487 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark06(-1.3608321201621363,-1.5707963267948966,32.52753007941692 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark06(-1.3610909145305659,-0.026619292443769378,1.633296333509809 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark06(-1.3612386144177218,-1.3337778300455203E-14,1.5707963267948966 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark06(-1.3630814555857187,-95.34762878274297,-39.05138130704324 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark06(-1.3632468292850302,1.3234889800848443E-23,10.837228998867127 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark06(-1.3634490559654076,-0.20109325693957725,-64.5468919627308 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark06(-1.3641304785353734,-6.938893903907228E-18,-42.1494736108321 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark06(-1.3648388974082482,-0.8541934837431595,-29.510708592457064 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark06(-13.650849117192124,10.235072455947417,-9.013229783249656 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark06(-1.3651485197457156,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark06(-13.655603691172487,0,0 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark06(-1.3661425391872053,-0.5864944548292715,-3.1415926527303397 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark06(-1.3664111348625871,-1.2468877575245518,0.13094269133585396 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark06(-1.3683166046244135,-1.761050914342067E-133,-1.5707963267948957 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark06(-1.3688332428230008,-0.658506048196935,100.0 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark06(-1.3692621762688233,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark06(-1.3693158648712538,-1.5707963267948966,36.145600692748644 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark06(-1.3698808431302519E-194,-1.5707963267948832,-1.5707963267948966 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark06(-1.370059465498044,-95.49540386315059,-52.06786748365361 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark06(-1.3702927273048704,-1.5707963267948966,-2.6852403084443415 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark06(-1.370508471354802,-1.5654798335009443,-79.57077155187314 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark06(-1.373518879115829,-95.81779020633228,6.938893903907228E-18 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark06(-1.3737210034242526,-278.0203082191485,-142.2567436791923 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark06(-1.3737363243034957,-0.3447400393964106,-100.0 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark06(-1.375522503480937,-1.5707963267948966,-55.96786720878275 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark06(-1.3768830963618606,-1.5707963267948963,-40.84070449666732 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark06(-1.3772457230322055,-0.14338535383722487,3.1415926540682504 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark06(13.774887697958519,-81.14392202797329,-19.57101741948361 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark06(-1.377607531451743,-1.5707963267948966,7.888609052210118E-31 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark06(-1.3776657509129182E-8,-1.5707963267948966,110.03986205693157 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark06(-1.377962880513865,-0.4013777884050758,-27.707132526903095 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark06(-1.3780016224955667,-1.5707963267948966,34.89112865370046 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark06(13.786062327407535,-9.944215818448043,-40.06595995784266 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark06(-1.3788110389449422,2.465190328815662E-32,18.286441344665946 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark06(-13.80054598701983,0,0 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark06(-1.380692229537952,-1.570796326794895,-6.712388989098005 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark06(-1.380916097324445,-2.5379418373156492E-116,-1.1946092267829904 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark06(-1.3810670862762322,-1.5707963267948983,26.828820067476432 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark06(-1.381357854491557,-45.48848324189906,6.718265196331498 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark06(-1.3813828674757496,-0.009458321352077782,11.011007226024262 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark06(-1.3819371230414026,-44.0724241589971,-3.141592653589793 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark06(-1.3819842601974932,-2.1178720448174484E-15,37.485902344757164 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark06(-1.3823878477686442,-0.10017911171139696,-100.0 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark06(-1.3825290251340967,-31.751089837962404,-7.331168062332934E-4 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark06(-1.3828760390731667,-1.5707963267948966,16.992929040373838 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark06(-1.383051009341366,-0.8702162569122378,70.461854343551 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark06(-1.3832261657045163E-222,-0.6120430360427436,-1.5707963267948966 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark06(-1.3847343602372462,-1.5707963267948966,-95.42468575944751 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark06(-1.3848062830633867,-0.8791986708395143,80.60270552302572 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark06(-1.3859275484214575,-44.45738706800134,-3.141592653589794 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark06(-1.3859487046671592,-88.18843111638975,-1.5707963267948966 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark06(-1.3864160354964774,2.1684043449710089E-19,0.0 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark06(-1.3874768023029287,-1.5707963267948966,-11.822641934435865 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark06(1.3877787807814457E-17,-0.006483948435060456,-67.20446858998545 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark06(1.3877787807814457E-17,-0.12641667207800644,1.5707963267948966 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark06(-1.3877787807814457E-17,-0.6383527150543142,56.54899190635583 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark06(1.3877787807814457E-17,-1.5707963267948966,0.2374389480393521 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark06(-1.3877787807814457E-17,-1.5707963267948966,-3.1415926535897967 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark06(-1.3877787807814457E-17,-44.292701284589896,-10.941830900112954 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark06(1.3877787807814457E-17,-45.21444210020068,-1.3395403415526987 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark06(-1.388717601631356,-1.5707963267948966,-63.335315554414194 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark06(-1.3894960004093573,-0.1365304999684022,-9.390132216312368 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark06(-1.3895588528058447,-1.1519319238770374,-4.372014083956072 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark06(-1.3902312739769545,-0.029102509513259177,-67.23925599129258 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark06(-1.3906818162211623,-31.508753725875764,-1.5707963267948968 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark06(-1.3910953455357504,-1.5707963267948966,-99.77192670830833 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark06(-1.3912822340016886,-9.86732352472096E-4,70.7324004261248 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark06(-1.3920462181665232,-0.20726184283737914,-21.535442242359572 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark06(-1.3931261164518687,-3.1415926535956804,90.76873470651586 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark06(-1.393182467509113,-0.736319610379411,34.94963141061996 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark06(-1.3941203880642346,-1.5707963267948966,6.205751001317459 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark06(-1.3945542583392565,-1.5707963267949003,29.95794799322556 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark06(-1.3947268023052082,-1.2062591235759295,-3.2665926654571047 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark06(-1.3963664760808827,-1.5707963267948966,99.99999999999999 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark06(-1.3964054317979555,-1.1276967052256726,-7.266778567858193 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark06(-1.3967485350314064,-1.5707963267948963,40.740238388526635 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark06(-1.3968178513863063,-45.40682755888919,-97.55657548721025 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark06(-1.3973930138094364,-0.30427512161997883,63.370361651726995 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark06(-1.397638489710077,-1.417557414895769,80.64209865209561 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark06(-1.3978223269885173,-0.036602853312555084,0.0 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark06(-1.3979486926227098,-1.5707963267948966,-50.521874144645466 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark06(-1.39819266993646,-1.5707963267948966,1.5041779604740613 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark06(-1.399076077632734,-31.598262129735062,-19.369650057568755 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark06(-1.3990996834501692,-32.89856142434916,-33.0751752026895 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark06(-1.3993213278088423,0.6644993302366177,-44.39813349615959 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark06(-1.399583609632359,-2.191809349008403E-193,-61.67970020862536 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark06(13.995930037063985,83.3379654624955,35.02173795514125 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark06(-1.400140104794229,-1.5707963267948966,17.182973778573484 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark06(-1.4003389215762467,-0.9859220386959382,-91.39878995087423 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark06(-1.401092418285997,-1.399599802663426,-49.212686820385215 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark06(-1.4027360313999682,-0.21201448513078613,57.2730911989965 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark06(-1.4037143576752134,-1.4940464470533648,-44.3393871008736 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark06(-1.4038642004382564,-1.421584611523906,-4.712877736707396 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark06(-1.4047133933598988,-32.496846022637875,-84.82300164692441 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark06(-1.4050231723110176,-3.14159265358994,-56.24144175827927 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark06(-1.4065565035112815,-39.11404885152736,-1.5707963267948966 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark06(-1.4068038043495434,-31.41592653589793,-4.634168297900734 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark06(-1.407150921261634,-1.5707963267948966,1.5707963267948877 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark06(-1.4077770963402656,-1.5707963267948966,-1.5707963220492862 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark06(-1.4078518527239137,-0.6045920606059233,90.46037871626693 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark06(-1.408582366071076,-0.16232176184689928,78.19601336883434 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark06(-1.409690171844709,-45.55309347478319,-73.28067181783533 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark06(-1.4127428853640858,-1.5707963267948966,-23.902997891223425 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark06(-1.4127590715709835,-1.5707963267948966,0.46165509453372733 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark06(-1.413287882306768,-158.6115750301555,0.06188647488335741 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark06(-1.4139522875965032,-1.3056673020114196,88.22579475668884 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark06(-1.4144251493940232,-45.47703563315798,-50.56856236104108 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark06(-1.4146307452021156,-1.5707963267948966,-79.01943896250532 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark06(-1.4147149774959953,-163.470422981607,9.436287907885246 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark06(-1.4151613754349668,-1.5707963267948966,-82.56840964018316 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark06(-1.415236821644236,-0.0013670187850000394,-129.84518745055243 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark06(-1.415420223755321,-1.254977500953767,-21.222873085190557 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark06(-1.4164080801770103,-45.50445520502194,-96.34415054290584 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark06(-1.4166664973446088,-1.5707963267948966,88.53274944676886 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark06(-1.4170199389537355,-1.5707963267948966,-33.56039976499513 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark06(-1.4173080859460792,-1.5707963267948966,-1.5707963267948977 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark06(-1.4174756837912579,-1.5707963267948966,1.8349142009006165 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark06(-1.4177922239364522,-102.07524274293985,-26.138266773668377 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark06(-1.4180675505235558,-1.5707963267948966,-11.495062718423178 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark06(-1.4184435816979408,-1.5707963267948966,39.66852804534977 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark06(-1.418881987334184,-0.2409225364046243,-45.27692963619404 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark06(-1.4194393313318467,-1.5707963229800905,-63.00966207730909 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark06(-1.4197309404835234,-1.5707963267948966,-10.995574284528178 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark06(-1.420514432177165,-94.24784348545353,-111.13453180899623 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark06(-1.4210854715202004E-14,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark06(-1.421282891373751,-0.020483149750110816,-32.15513488445758 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark06(-1.4223107839380393,-1.5707963267948966,-58.56314068149222 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark06(-1.4225655996704496E-160,-1.5707963267948966,-30.559786093941344 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark06(-1.422669852853684,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark06(-1.4227590924648936,-1.5707963267948966,4.712633121069046 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark06(-1.4229311059109673,-1.5707963267948966,-56.13521825607462 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark06(-1.4233801875874827,-1.5707963267948966,-49.497148048505935 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark06(-1.4234179023724454,-32.870032322309314,-27.17975153075767 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark06(-1.4236177138310433,-1.5707963267948752,-1.3048404835055039 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark06(-1.4237011344720576,-1.5707963267948966,-14.986323753513975 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark06(-1.424024244882124,-0.004646287091726599,-1.5707963014384723 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark06(-1.4245097252887655,-0.10145540871832948,-64.73936003770055 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark06(-1.4252853595930979,-1.5653573571214865,-68.82502069294995 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark06(-1.4263091978298519,-88.51227931620022,-126.37272865545101 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark06(-1.4269328120306617,-3.1415926536872165,1.5707963267948966 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark06(-1.4286825475598202,-1.226230923163257,-6.6174449004242214E-24 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark06(-1.430496380975693,-1.5707963267948963,-28.479588881584576 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark06(-1.4317049406719922,-1.2946282137485086,43.883665627257926 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark06(-1.4320511101576896,-8.881784197001252E-16,0.07170813290886002 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark06(-1.432169433459862,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark06(-1.4322852709523195,-1.5707963267948966,91.93733117236874 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark06(-1.4330413562669908,-0.004194425203745409,0.23557713136630293 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark06(-1.4332179334360315,-100.53156067781808,-45.45842687632121 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark06(-1.4332662654604174,8.673617379884035E-19,-28.17725645780177 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark06(-1.4332995029084536,-44.042917842583705,-1.5707963267948983 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark06(-1.433803773022989,-0.15701448841784005,-91.09037054202534 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark06(-1.4344126703061753,-1.5506785279481978,-44.86971902407012 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark06(-1.4349100754361437,-1.5707963267948966,27.733767223048986 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark06(-1.4352821630751944,-1.5707963267948966,-53.374626736135525 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark06(-1.4353070507443024,-1.5707963267948966,88.656931309854 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark06(-1.4356869157118488,-1.5707963267948966,76.50667215666132 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark06(-1.4364080929067937,-0.1660412835152137,45.06853363365316 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark06(-1.4368634770493203,-88.21816725141068,-1.5707963267948966 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark06(-1.4375683691748833,-1.3581884402794966,-1.0316938497601102 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark06(-1.437683387953114,-95.80817093267258,-91.91491272065649 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark06(-1.4382280828637757,-1.2519696411144707,0.0 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark06(-1.4382566111942885,-32.524276885717136,-89.2689724179458 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark06(-1.4382781611287596,-0.17903546875955645,-22.460873090192393 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark06(-1.4393941950894513,18.84955593248736,-75.4018975393213 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark06(-1.4401165366017104,-1.5707963267948966,94.15488588184351 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark06(-1.4403096039581835,-43.982297150257104,-19.402248394526236 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark06(-1.4406769162876556,-0.02520471285765018,3.2665926537399455 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark06(-1.4409373615832906,-0.7154588947489434,45.20867118181913 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark06(-1.441160209329697,-44.52937294393096,-4.472125472504061 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark06(-1.4414248455340146,-7.105427357601002E-15,77.97471621978957 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark06(-1.4415909121998363,-45.33995421559718,-752.0572732006464 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark06(-1.4421004124291934,-0.0827000749092584,-1.5707963267948974 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark06(-1.4423613492908007,-0.4450812307638503,-67.99104246876354 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark06(-1.4429370737823803,-1.5707963267948966,1.5707963284032025 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark06(14.429828318115149,72.70965055201324,0 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark06(14.431387922553,0.0,-86.01037889129739 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark06(-1.4432845744365084,-1.5707963267948966,-7.83753193769452 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark06(-1.4436041297133158,-1.5707963267948966,-37.160751239818325 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark06(-1.4437605045708564,-19.323859813865866,0 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark06(-1.4437849392767501,-0.09569406979754358,73.41841828434154 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark06(-1.4438433646942532,-0.524409013029782,10.016707183153812 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark06(-1.4442963703434941,-0.19655646269350702,1.5707963267948948 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark06(-1.4453824300124154,-32.58691663321418,-32.65131814523566 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark06(-1.445867844847012,-0.18718656260165978,-45.0836572136888 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark06(-1.4464545910605793,-1.5707963267948974,53.68271813459387 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark06(-1.4467186704741022,-8.436034604428874E-4,-56.98126125820792 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark06(-1.4470444959327506,-1.4496488626890895,3.266592656245937 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark06(-1.4472872779974943,-1.5707963267948957,12.491729388674734 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark06(-1.4479548472914727,-43.99164073846824,-2362.8250134566924 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark06(-1.4483728075676363,-1.5707963267948966,-1.4709615395836408 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark06(-1.4488990315112584,-1.5707963267948966,-60.483850701457165 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark06(-1.4493954995762575,6.714585042975199,-1.5707963267948966 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark06(-1.450290439311698,-0.5349647399530981,4.8373889885989785 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark06(-1.4510567197830113,0,0 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark06(-1.4511727809137478,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark06(-1.4522451355218817,-1.5707963267948961,-8.331722534764108 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark06(-1.4529293380663668,-1.5707963267948966,89.34717348659362 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark06(-1.4535670227099495,-1.28886751106845,-4.712397483686202 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark06(-1.4536656594138349,-1.5707963263277507,-49.406668934800656 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark06(-1.4541424635292153,6.938893903907228E-18,32.90655869326463 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark06(-1.456121613071391,-26.7507133963775,-64.4275552378841 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark06(-1.456599538218604,-1.5707963267948966,-64.57816823593456 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark06(-1.457234264163328,-1.5707963267948983,-460.40346638283825 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark06(-1.4576766477806555,-1.6859716772830294E-16,-1.5707963267948966 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark06(-1.4582367603918103,-1.5707963267948966,-93.46347195206886 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark06(-1.4585065796344325,1.0842021724855044E-19,-100.0 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark06(-1.4586485004661651,-1.5707963267948966,7.493025468524458 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark06(-1.4590103610352598,-0.4427050841015458,-4.744092705884387 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark06(-1.4591906266930708,-1.5707963267948966,37.03012363327204 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark06(-1.4596847959906247,-0.6698429177426695,-1.5707963267948912 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark06(-1.4600535536710326,-1.5707963267948966,-62.144241157104226 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark06(-1.4614668969609765,-1.5707963267948966,39.82479170796938 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark06(-1.461474232059377,-1.5707963267948966,-1.5707963267948983 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark06(-1.46150144801272,-1.5707963267948966,-9.424778001554623 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark06(-1.4615588138194383E-16,-1.5707963267948957,59.020185544142684 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark06(-1.462291351931059,-0.7679649057406827,3.141592653589793 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark06(-1.4625573123760762,-1.5707963267948966,-44.2975454525699 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark06(-1.4630206411659836,-0.8178380153270254,-1.5707963267948966 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark06(-1.463023860841312E-98,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark06(-1.4630539973546342,-1.5707963267948966,17.87019691796522 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark06(-1.4633474586003858,-0.29291793556470214,-10.976016106194407 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark06(-1.4639265300260944,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark06(-1.4639512055464576,-0.19941600640102308,23.294779125492965 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark06(-1.4643652757923367,-1.5707963267948966,71.23460735671912 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark06(-1.4646809226470952,-1.4852832755904133,5.366774203744621 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark06(-1.4648884855835307,-1.5707963267948966,-0.21468129886276266 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark06(-1.4664060372461796,-0.10262724510691325,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark06(-1.4675971580382168,-1.2907948245505647,-76.86698736163507 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark06(-1.4684777127644928,-95.24835839122512,-12.908854966552596 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark06(-1.4686671155482074,-32.74761798732721,-1.5786955437952868 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark06(-1.4689963093329808,-0.22071248939971766,-1.5707963267948966 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark06(-1.4690150249755192,-31.466591817655395,-75.61589713358532 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark06(-1.4693679385278594E-39,-45.54234017640442,-10.69336061525885 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark06(-1.469594830943356,-94.26529320129066,-40.73050591901788 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark06(-1.469872607899866,-0.8186958151217518,-1.5718700644281411 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark06(-1.4707007130060032,-44.334023218874236,-72.43846711404558 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark06(-1.471140647339767,-1.5707963267948912,335.57588097363276 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark06(-1.47118679336666,-1.5707963267948966,-1.1457789982841144 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark06(-1.471866962484532,-1.5707963267948966,-91.27762711537028 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark06(-1.4733553581064573,-31.78323568976625,-21.489994663907865 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark06(-1.4737674556020224,-1.5707963267948966,11.726573393660416 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark06(-1.4742462803693024,-0.14320714821648234,-0.8615137018460957 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark06(-1.474253316779798,-44.3788565443563,-59.016515981656504 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark06(-1.4746459134243604,-1.5707963267948966,90.23060012083843 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark06(-1.4748940171931257,-3.1415926535897936,-1.5707963267948966 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark06(-1.475541353380661,-95.31946721141767,-3.141592653589793 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark06(-1.4763792466518504,-1.5707963267948966,-43.12504723520136 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark06(-1.476619643344772,-1.3877787807814457E-17,11.861087831938022 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark06(-1.4772765788457177E-126,-2.1895288505075267E-47,28.43307573914032 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark06(-1.4775717565254296,-6.908934844075556E-77,24.805039060092724 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark06(-1.477964128687433,-0.19369517663061625,36.696704863714004 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark06(-1.478167284554779,-1.5707963267948966,15.707963267948966 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark06(-1.4787375316902338,-1.5707963267948963,-4.743638983218618 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark06(-1.4789028045730346,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark06(-1.4796992749993239,-44.18343461469163,-58.2495348636581 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark06(-1.4808930435459344,-1.5707963267948966,1.0842021724855044E-19 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark06(-1.481435030452699,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark06(-1.4818607964019657,-95.36269006810704,-1.5707963267948974 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark06(-1.482722242086236,-1.5707963267948966,3.266594904898487 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark06(-1.4828868041813654,-1.007050194656771,-2244.3125873611953 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark06(-1.483210449545656,-1.4589957037261856,55.58006198815185 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark06(-1.4834353869397972,-0.1766933045767809,-31.41592653589793 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark06(-1.4835510340518747,6.712389903434176,-98.93913566578331 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark06(-1.4836138249623023,-1.5707963267948966,38.96811053522973 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark06(-1.4838016591189764,-1.5707963267948983,54.697059172658044 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark06(-1.4840669421055268,-44.436825443566796,-6.283185307179586 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark06(-1.4843067614721628,-1.5707963267948966,-576.482227030742 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark06(-1.4853494576817519,-1.5707963267948966,85.82182376700511 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark06(-1.4863705156872307,4.3368086899420177E-19,100.0 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark06(-1.486890581551794,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark06(-1.4869012831653665,-1.5707963267948963,4.34107238318581 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark06(-1.4869659851076682,-1.5707963267948912,4.727251037346748 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark06(-1.4879703875631049E-15,-1.5707963267948966,22.584169656395222 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark06(-1.488402466688752,-45.195563974079576,-3.1416831964623375 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark06(-1.4884642686867555,-37.798488584788146,2.465190328815662E-32 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark06(14.887254612268634,-17.589906577901587,5.813364358946387 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark06(-1.4891103272146784,-1.5707963267948966,43.226792117897446 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark06(-1.4899818618038796,6.712388980395084,-1.5707963267948966 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark06(-1.490829059798341,-1.5707963267948966,44.05073039856262 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark06(-1.4914570902525415,-1.5707963267948966,-30.18470834668226 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark06(-1.491478468234147,-0.26238489369388085,3.1857739346827376 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark06(-1.4918700717642788,-0.17327281118093407,-1.5707963267948966 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark06(-1.492059767767267,1.0587911840678754E-22,50.91834200528925 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark06(-1.4921956796141436,-1.1547098374743887,-38.843941705039896 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark06(-1.4941531444104155,-1.5707963267948966,-31.415969659587105 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark06(-1.4945771595825963,-1.5707963267948966,-21.56295661108213 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark06(-1.4946233086710699,-45.07233259386871,-3.1415927194151663 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark06(-1.4946896641854284,-1.5707963267948966,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark06(-1.4952266876598443,-31.72952913887174,-102.10169008742713 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark06(-1.4956013120567329,-0.7197364259937099,-20.53323471125907 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark06(-1.495968920534402,-0.007274858575264054,39.041373440580735 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark06(-1.4975162259461205,-31.92885515407834,-66.00994372209328 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark06(-1.4999441655153194,-0.3265641060337994,4.712955980407932 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark06(-1.5008355575012182,-37.8632158937161,-4.551244389397167 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark06(-1.501002756917387,-3.14159265370408,0.0 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark06(-1.5010653814422181,-1.1296722408213582,-39.17915177723684 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark06(-1.5011356394957538,-0.2856183237053108,-58.85889501340363 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark06(-1.5015188935055945E-10,-1.5707963267948966,9.494107596574928E-16 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark06(-1.5021103459970202,-1.4676459475530526,59.307136452577225 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark06(-1.5028966961701171,-5.954501590902191E-7,-56.030121825725296 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark06(-1.5029642984576714,-1.0301354016788193,1.5707963267948966 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark06(-1.503227410744596,-1.5707963267948966,210.55835211524158 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark06(-1.5033957983594632,-1.5707963267948966,51.072881936865244 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark06(-1.5034064242871106,-1.5707963267948966,-60.315945790392895 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark06(-1.5036645225137208,-1.5707963267948966,12.420609822781014 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark06(-1.5041467929561705,-1.5707963267948966,62.07481136899356 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark06(-1.5046539154133456,-2.220446049250313E-16,-55.72173271691378 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark06(-1.5048807505264425,-44.35500661869748,-1.5707963267948966 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark06(-1.5053303554210051,-1.5707963267948966,-1.5707963267949019 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark06(-1.5055607550881795,-1.5707963267948966,73.89474400178372 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark06(-1.506101590781378,-1.5707963267948966,-96.58356375892694 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark06(-1.506484115776695,-1.2919360859288123,-3.152637566901957 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark06(-1.5065290432076983,-45.329514195147176,5.141592653608382 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark06(-1.5069512763303339,-44.05208037380478,-1.5707963267948966 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark06(-1.506963227261545,-1.5707963267948966,-1.5707963264890739 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark06(-1.5070406831377003,-1.5707963267948966,-6.879964870173438 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark06(-1.5075943309586788,-44.177164349594534,-9.771932321106485 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark06(-1.507597130109948,-1.5707963267948948,-2.0707963352400043 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark06(-1.5080207582647485,-0.43883453912761716,77.99057908513761 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark06(-1.509102093906794E-14,-1.5707963267948966,-12.214194432787206 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark06(-1.5093566574986028,-1.5707963267948966,37.59716441182082 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark06(-1.5097093909312014,-1.5707963267948966,-57.70092023419746 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark06(-1.5100015375825702,-157.479651418137,-1.5787299408877788 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark06(-1.5101527557602872,-0.001739610335914181,4.141592654779003 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark06(-1.5105589083729027,-0.7121887736347949,2.4834327153629263 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark06(-1.510887534777108,-164.79961165937567,-95.61726048802883 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark06(-1.5132951784753608,-1.5707963267948966,-23.9864555030441 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark06(-1.5136004925931528,-1.5707963267948937,1.5707963267948968 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark06(-1.5137981068121817,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2476() {
    coral.tests.JPFBenchmark.benchmark06(-1.5140133068431991,-0.7650768124040818,88.7205788081 ) ;
  }

  @Test
  public void test2477() {
    coral.tests.JPFBenchmark.benchmark06(-1.5141714818158913,-1.5250029725312504,-57.38622716748414 ) ;
  }

  @Test
  public void test2478() {
    coral.tests.JPFBenchmark.benchmark06(-1.5141818611969047,-1.5707963267948966,37.69944456297695 ) ;
  }

  @Test
  public void test2479() {
    coral.tests.JPFBenchmark.benchmark06(-1.5149926868023413,-1.0522895959961183,32.64148541777208 ) ;
  }

  @Test
  public void test2480() {
    coral.tests.JPFBenchmark.benchmark06(-1.5154547081004788,-1.5707963267948966,-88.05304884734666 ) ;
  }

  @Test
  public void test2481() {
    coral.tests.JPFBenchmark.benchmark06(-1.5174971656482699,-0.36189719130356934,-7.409140667427948 ) ;
  }

  @Test
  public void test2482() {
    coral.tests.JPFBenchmark.benchmark06(-1.5175130078506738,-1.5707963267948966,15.582232114845695 ) ;
  }

  @Test
  public void test2483() {
    coral.tests.JPFBenchmark.benchmark06(-1.517579066695889,-1.1647940460635011,3.2643368308190333 ) ;
  }

  @Test
  public void test2484() {
    coral.tests.JPFBenchmark.benchmark06(-1.5178787530726652,-1.5707963267948966,3.4391175114369714 ) ;
  }

  @Test
  public void test2485() {
    coral.tests.JPFBenchmark.benchmark06(-1.519426107954181,-0.5059400616635881,-1.5707963267948966 ) ;
  }

  @Test
  public void test2486() {
    coral.tests.JPFBenchmark.benchmark06(-1.5197721336073835,-1.5707963267948963,54.33901475173744 ) ;
  }

  @Test
  public void test2487() {
    coral.tests.JPFBenchmark.benchmark06(-1.5198024946880604,-1.5707963267948966,-51.925800626741186 ) ;
  }

  @Test
  public void test2488() {
    coral.tests.JPFBenchmark.benchmark06(-1.5203562383383011,-0.24822445410792293,100.0 ) ;
  }

  @Test
  public void test2489() {
    coral.tests.JPFBenchmark.benchmark06(-1.5208732530361279E-210,-1.4453489726188467,0.0 ) ;
  }

  @Test
  public void test2490() {
    coral.tests.JPFBenchmark.benchmark06(-1.5210884124062019,-0.3921827993121424,-53.70580003664128 ) ;
  }

  @Test
  public void test2491() {
    coral.tests.JPFBenchmark.benchmark06(-1.5212700765018177,-95.3512498611512,-3.1415926535898047 ) ;
  }

  @Test
  public void test2492() {
    coral.tests.JPFBenchmark.benchmark06(-1.5213393536809117,-0.056821827362396604,18.89351801459617 ) ;
  }

  @Test
  public void test2493() {
    coral.tests.JPFBenchmark.benchmark06(-1.5217611846961319,-1.5707963267948912,49.74467901075218 ) ;
  }

  @Test
  public void test2494() {
    coral.tests.JPFBenchmark.benchmark06(-1.5218587896841155E-15,-1.3813536018244599,1.363232823764134 ) ;
  }

  @Test
  public void test2495() {
    coral.tests.JPFBenchmark.benchmark06(-1.5224721198594509,-1.0552785775625781,-32.616347975160906 ) ;
  }

  @Test
  public void test2496() {
    coral.tests.JPFBenchmark.benchmark06(-1.5230268443277604,-1.5707963267948966,79.37081797969904 ) ;
  }

  @Test
  public void test2497() {
    coral.tests.JPFBenchmark.benchmark06(-1.5233856182212904,-44.07944080659356,-1.5707963267948983 ) ;
  }

  @Test
  public void test2498() {
    coral.tests.JPFBenchmark.benchmark06(-1.5259429713786261,-1.5707963267948966,-73.51362567755339 ) ;
  }

  @Test
  public void test2499() {
    coral.tests.JPFBenchmark.benchmark06(-1.5266251546312988,-1.5707963267948966,-43.420742872296294 ) ;
  }

  @Test
  public void test2500() {
    coral.tests.JPFBenchmark.benchmark06(-1.5267940358643755,-1.1102230246251565E-16,6.123220244805491 ) ;
  }

  @Test
  public void test2501() {
    coral.tests.JPFBenchmark.benchmark06(-1.527178318047727,-1.3924989523100892,-60.76635113525938 ) ;
  }

  @Test
  public void test2502() {
    coral.tests.JPFBenchmark.benchmark06(-1.5275590056053343,-0.30755036805211095,110.53784387010343 ) ;
  }

  @Test
  public void test2503() {
    coral.tests.JPFBenchmark.benchmark06(-1.5277043600131817,-1.5707963267948966,85.03350569481175 ) ;
  }

  @Test
  public void test2504() {
    coral.tests.JPFBenchmark.benchmark06(-1.5284820290846226,-1.3494531872193312,3.266620328955811 ) ;
  }

  @Test
  public void test2505() {
    coral.tests.JPFBenchmark.benchmark06(-1.5287255417329426,-1.5707963267948966,-1075.4141100076624 ) ;
  }

  @Test
  public void test2506() {
    coral.tests.JPFBenchmark.benchmark06(-1.5292143864515022,-1.5707963267948966,32.6833175917331 ) ;
  }

  @Test
  public void test2507() {
    coral.tests.JPFBenchmark.benchmark06(-1.5296725000272504,-3.1415926536066494,-100.0 ) ;
  }

  @Test
  public void test2508() {
    coral.tests.JPFBenchmark.benchmark06(-1.5304381525974833,-44.38552847693939,-83.7037872349892 ) ;
  }

  @Test
  public void test2509() {
    coral.tests.JPFBenchmark.benchmark06(-1.530710728075541,-1.4268708166374655,97.63819556146818 ) ;
  }

  @Test
  public void test2510() {
    coral.tests.JPFBenchmark.benchmark06(-1.5309480665623227,-3.1415926535897936,-100.0 ) ;
  }

  @Test
  public void test2511() {
    coral.tests.JPFBenchmark.benchmark06(-1.5319719000759335,-1.5707963267948966,60.821171283093975 ) ;
  }

  @Test
  public void test2512() {
    coral.tests.JPFBenchmark.benchmark06(-1.5320902945887214,-0.304171456434512,-53.67489780665042 ) ;
  }

  @Test
  public void test2513() {
    coral.tests.JPFBenchmark.benchmark06(-1.532607770043738E-7,-45.55308744714876,-47.12386678317654 ) ;
  }

  @Test
  public void test2514() {
    coral.tests.JPFBenchmark.benchmark06(-1.5329717170315396,-1.5707963267948966,-7.776562583345688 ) ;
  }

  @Test
  public void test2515() {
    coral.tests.JPFBenchmark.benchmark06(-1.5330893808172252,-0.5106326104899302,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test2516() {
    coral.tests.JPFBenchmark.benchmark06(-1.533109542550497,-1.5707963267948963,9.424791868089033 ) ;
  }

  @Test
  public void test2517() {
    coral.tests.JPFBenchmark.benchmark06(-1.5334694598188021,-0.042018711252522954,73.88972725770861 ) ;
  }

  @Test
  public void test2518() {
    coral.tests.JPFBenchmark.benchmark06(-1.5336457828295416,-1.5707963267948966,-56.485355256371065 ) ;
  }

  @Test
  public void test2519() {
    coral.tests.JPFBenchmark.benchmark06(-1.53372753417625,-1.5707963267948966,96.69460492933055 ) ;
  }

  @Test
  public void test2520() {
    coral.tests.JPFBenchmark.benchmark06(-1.5338296836722294,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2521() {
    coral.tests.JPFBenchmark.benchmark06(-1.5339544771095646,-1.5707963267948966,-36.15028222039355 ) ;
  }

  @Test
  public void test2522() {
    coral.tests.JPFBenchmark.benchmark06(-1.5339758355348925,-1.540631840319069,-1.5707963267949054 ) ;
  }

  @Test
  public void test2523() {
    coral.tests.JPFBenchmark.benchmark06(-1.5347834450926159,-1.5707963267948966,-1.5707963267948948 ) ;
  }

  @Test
  public void test2524() {
    coral.tests.JPFBenchmark.benchmark06(-1.5348535751375016,-45.094965592132525,-101.73908617394775 ) ;
  }

  @Test
  public void test2525() {
    coral.tests.JPFBenchmark.benchmark06(-1.5353371441473498,-3.552713678800501E-15,-1.5707963267948966 ) ;
  }

  @Test
  public void test2526() {
    coral.tests.JPFBenchmark.benchmark06(-1.5353680879068334,-95.28901021060604,-77.97570855499724 ) ;
  }

  @Test
  public void test2527() {
    coral.tests.JPFBenchmark.benchmark06(-1.5356895374291261E-238,-0.1268291502056728,1.5707963267948966 ) ;
  }

  @Test
  public void test2528() {
    coral.tests.JPFBenchmark.benchmark06(-1.5359209667590301,-1.5647202437330907,38.483538339621546 ) ;
  }

  @Test
  public void test2529() {
    coral.tests.JPFBenchmark.benchmark06(-1.5365446890114376,-88.13347711633621,-47.64090172424378 ) ;
  }

  @Test
  public void test2530() {
    coral.tests.JPFBenchmark.benchmark06(-1.536559925062533,-1.3681277792331492,-70.28087058841724 ) ;
  }

  @Test
  public void test2531() {
    coral.tests.JPFBenchmark.benchmark06(-1.5366675547556126,-0.14247963346613646,7.124048332647144 ) ;
  }

  @Test
  public void test2532() {
    coral.tests.JPFBenchmark.benchmark06(-1.537659362464531,-1.0749219014512732,-38.90532835971348 ) ;
  }

  @Test
  public void test2533() {
    coral.tests.JPFBenchmark.benchmark06(-1.5377266864665107,-3.141592653594463,1.5707963267948983 ) ;
  }

  @Test
  public void test2534() {
    coral.tests.JPFBenchmark.benchmark06(-1.5378658740125346,-1.5627004994767582,53.40707511102649 ) ;
  }

  @Test
  public void test2535() {
    coral.tests.JPFBenchmark.benchmark06(-1.537892323561454,-1.5707963267948966,-61.91892457904325 ) ;
  }

  @Test
  public void test2536() {
    coral.tests.JPFBenchmark.benchmark06(-1.5381206111838277,-37.71345089779573,-1.5707963267948966 ) ;
  }

  @Test
  public void test2537() {
    coral.tests.JPFBenchmark.benchmark06(-1.538307660466323,-1.5707963267948957,-16.097002359808712 ) ;
  }

  @Test
  public void test2538() {
    coral.tests.JPFBenchmark.benchmark06(-1.5385359721085237,-1.5707963267948966,39.848262161898354 ) ;
  }

  @Test
  public void test2539() {
    coral.tests.JPFBenchmark.benchmark06(-1.5387056864201407,-1.5521945882036525,-99.73821012545943 ) ;
  }

  @Test
  public void test2540() {
    coral.tests.JPFBenchmark.benchmark06(-1.538826702183927,-1.3413330911498642,-100.0 ) ;
  }

  @Test
  public void test2541() {
    coral.tests.JPFBenchmark.benchmark06(-1.5394285866531143,-84.68799575426539,-1.5707963267948966 ) ;
  }

  @Test
  public void test2542() {
    coral.tests.JPFBenchmark.benchmark06(-1.5399972415848773,-1.5707963267948966,33.88173807243666 ) ;
  }

  @Test
  public void test2543() {
    coral.tests.JPFBenchmark.benchmark06(-1.5402412068802243,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2544() {
    coral.tests.JPFBenchmark.benchmark06(-1.5407439555097887E-33,-1.5707963267948966,1.57484331847894 ) ;
  }

  @Test
  public void test2545() {
    coral.tests.JPFBenchmark.benchmark06(-1.5413187644655395,-0.005827138641496145,3.2665926540659584 ) ;
  }

  @Test
  public void test2546() {
    coral.tests.JPFBenchmark.benchmark06(-1.5418427977766604,-1.489456919784082,-25.8296069259776 ) ;
  }

  @Test
  public void test2547() {
    coral.tests.JPFBenchmark.benchmark06(-1.542117394160364,-0.12091590385208079,-397.4114675273263 ) ;
  }

  @Test
  public void test2548() {
    coral.tests.JPFBenchmark.benchmark06(-1.5425672419844463,-0.7663124104724668,28.224875726654403 ) ;
  }

  @Test
  public void test2549() {
    coral.tests.JPFBenchmark.benchmark06(-1.542692267952846,-1.0276337526101913,804.7609496133811 ) ;
  }

  @Test
  public void test2550() {
    coral.tests.JPFBenchmark.benchmark06(-1.5435043483982802,-1.5707963267948966,99.7683800989956 ) ;
  }

  @Test
  public void test2551() {
    coral.tests.JPFBenchmark.benchmark06(-1.5439579867033824,-1.5707963267948966,-74.51552441340982 ) ;
  }

  @Test
  public void test2552() {
    coral.tests.JPFBenchmark.benchmark06(-1.5448312837762885,-1.5707963267948966,2.0707967359625297 ) ;
  }

  @Test
  public void test2553() {
    coral.tests.JPFBenchmark.benchmark06(-1.545164651299664,2.465190328815662E-32,1.812778453302144 ) ;
  }

  @Test
  public void test2554() {
    coral.tests.JPFBenchmark.benchmark06(-1.5458571270033163,-1.5707963267948948,8.817835789527265 ) ;
  }

  @Test
  public void test2555() {
    coral.tests.JPFBenchmark.benchmark06(-1.5458853528774386,2.465190328815662E-32,-1.570796326794899 ) ;
  }

  @Test
  public void test2556() {
    coral.tests.JPFBenchmark.benchmark06(-1.5458933206868242,-1.5707963267948966,-74.06092474066486 ) ;
  }

  @Test
  public void test2557() {
    coral.tests.JPFBenchmark.benchmark06(-1.5459290051431323,-1.5707963267948966,4.3368086899420177E-19 ) ;
  }

  @Test
  public void test2558() {
    coral.tests.JPFBenchmark.benchmark06(-1.5463965045027077,-1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test2559() {
    coral.tests.JPFBenchmark.benchmark06(-1.546760471801803,-0.9952958417330229,59.00159945020218 ) ;
  }

  @Test
  public void test2560() {
    coral.tests.JPFBenchmark.benchmark06(-1.5470096754095601,-1.5707963267948966,-57.31839664065112 ) ;
  }

  @Test
  public void test2561() {
    coral.tests.JPFBenchmark.benchmark06(-1.5473324420145658,-0.27581938953297563,-1.5707963267948966 ) ;
  }

  @Test
  public void test2562() {
    coral.tests.JPFBenchmark.benchmark06(-1.54736218097072,-0.5323190210145334,-29.54986126118275 ) ;
  }

  @Test
  public void test2563() {
    coral.tests.JPFBenchmark.benchmark06(-1.547365495596722,-1.3356975397010502,-53.8431183975536 ) ;
  }

  @Test
  public void test2564() {
    coral.tests.JPFBenchmark.benchmark06(-1.547395852747846,-1.5707963267948966,-96.49816196072511 ) ;
  }

  @Test
  public void test2565() {
    coral.tests.JPFBenchmark.benchmark06(-1.5479876006722504,-88.1311912387512,-65.41053079016383 ) ;
  }

  @Test
  public void test2566() {
    coral.tests.JPFBenchmark.benchmark06(-1.5482060407484242,-9.871031767461413E-178,-67.08279720693709 ) ;
  }

  @Test
  public void test2567() {
    coral.tests.JPFBenchmark.benchmark06(-1.5483683547927478,-164.86175506816724,-4.141592653872286 ) ;
  }

  @Test
  public void test2568() {
    coral.tests.JPFBenchmark.benchmark06(-1.5484968599869604,-0.9554730582473285,-136.18056822690775 ) ;
  }

  @Test
  public void test2569() {
    coral.tests.JPFBenchmark.benchmark06(-1.5486237440184507,-1.5707963267948961,-73.31487113250583 ) ;
  }

  @Test
  public void test2570() {
    coral.tests.JPFBenchmark.benchmark06(-1.5486968642876133,-1.5707963267948966,-95.46478618641127 ) ;
  }

  @Test
  public void test2571() {
    coral.tests.JPFBenchmark.benchmark06(-1.5487796620468366,-1.5707963267948966,80.35804481969976 ) ;
  }

  @Test
  public void test2572() {
    coral.tests.JPFBenchmark.benchmark06(-1.5492402977191715,-8.29836711058869E-16,0.0 ) ;
  }

  @Test
  public void test2573() {
    coral.tests.JPFBenchmark.benchmark06(-1.5493328670481552,-1.5707963267948966,1.5707963267948968 ) ;
  }

  @Test
  public void test2574() {
    coral.tests.JPFBenchmark.benchmark06(-1.5493457004073803,-1.4638527776796877,-118.8174550516443 ) ;
  }

  @Test
  public void test2575() {
    coral.tests.JPFBenchmark.benchmark06(-1.549625539645755,-1.5707963267948966,-77.99760847518695 ) ;
  }

  @Test
  public void test2576() {
    coral.tests.JPFBenchmark.benchmark06(-1.5497664124759896,-45.483640664249094,-51.18271580414554 ) ;
  }

  @Test
  public void test2577() {
    coral.tests.JPFBenchmark.benchmark06(-1.5499735262629948,-4.362746816321816E-15,1.2638757585648623 ) ;
  }

  @Test
  public void test2578() {
    coral.tests.JPFBenchmark.benchmark06(-1.5502514658663602,-1.5707963267948966,-0.527227083083323 ) ;
  }

  @Test
  public void test2579() {
    coral.tests.JPFBenchmark.benchmark06(-1.551972204244435,-1.5707963267948966,-3.141592653589793 ) ;
  }

  @Test
  public void test2580() {
    coral.tests.JPFBenchmark.benchmark06(-1.5520285756674874,-1.5707963267948966,36.394425716162566 ) ;
  }

  @Test
  public void test2581() {
    coral.tests.JPFBenchmark.benchmark06(-1.5520398837336493,-1.3600161967330906,15.626653928422586 ) ;
  }

  @Test
  public void test2582() {
    coral.tests.JPFBenchmark.benchmark06(-1.5525607746961676,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2583() {
    coral.tests.JPFBenchmark.benchmark06(-1.5526015412776544,-1.164548014295901,51.405013201886774 ) ;
  }

  @Test
  public void test2584() {
    coral.tests.JPFBenchmark.benchmark06(-1.5528551462772344,-0.5499652591917509,1.5707963267948966 ) ;
  }

  @Test
  public void test2585() {
    coral.tests.JPFBenchmark.benchmark06(-1.5528831761851447,-0.4165419703238506,-634.0695670992919 ) ;
  }

  @Test
  public void test2586() {
    coral.tests.JPFBenchmark.benchmark06(-1.5529166616331964,-1.5707963267948966,88.74191744494797 ) ;
  }

  @Test
  public void test2587() {
    coral.tests.JPFBenchmark.benchmark06(-1.5535908193063748,-1.5707963267948966,1.5707963267948968 ) ;
  }

  @Test
  public void test2588() {
    coral.tests.JPFBenchmark.benchmark06(-1.5538539076718023,-1.5707963267948966,5.636732889549269 ) ;
  }

  @Test
  public void test2589() {
    coral.tests.JPFBenchmark.benchmark06(-1.5540147167976608,-1.5707963267948963,53.839176608507394 ) ;
  }

  @Test
  public void test2590() {
    coral.tests.JPFBenchmark.benchmark06(-1.5547415798638462,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2591() {
    coral.tests.JPFBenchmark.benchmark06(-1.555095314933085,-1.5707963267948966,39.79398111682469 ) ;
  }

  @Test
  public void test2592() {
    coral.tests.JPFBenchmark.benchmark06(-1.5553722587350374,-1.5707963267948961,-59.69032326319174 ) ;
  }

  @Test
  public void test2593() {
    coral.tests.JPFBenchmark.benchmark06(-1.555666790186477,-1.5707963265892557,100.0 ) ;
  }

  @Test
  public void test2594() {
    coral.tests.JPFBenchmark.benchmark06(-1.555731967183881,-0.602895199749725,2.1663219083485643 ) ;
  }

  @Test
  public void test2595() {
    coral.tests.JPFBenchmark.benchmark06(-1.5563605047893934,-0.026543705327053857,-14.192753213557845 ) ;
  }

  @Test
  public void test2596() {
    coral.tests.JPFBenchmark.benchmark06(-1.5568423957071602,-3.3881317890172014E-21,-94.25405843506019 ) ;
  }

  @Test
  public void test2597() {
    coral.tests.JPFBenchmark.benchmark06(-1.5568644207296491,-1.5707963267948983,1.5707963267948966 ) ;
  }

  @Test
  public void test2598() {
    coral.tests.JPFBenchmark.benchmark06(-1.5569972676575023,-1.5707963267948966,57.747536322535176 ) ;
  }

  @Test
  public void test2599() {
    coral.tests.JPFBenchmark.benchmark06(-1.5571606483989349,-38.93341661820972,-4.191356732216789 ) ;
  }

  @Test
  public void test2600() {
    coral.tests.JPFBenchmark.benchmark06(-1.557374211108995E-207,-1.5707963267948966,-24.96603078948432 ) ;
  }

  @Test
  public void test2601() {
    coral.tests.JPFBenchmark.benchmark06(-1.5576224993578687,-1.5707963267948966,55.82070511699891 ) ;
  }

  @Test
  public void test2602() {
    coral.tests.JPFBenchmark.benchmark06(-1.5577461929188088,-88.21758230243375,-88.43998127891703 ) ;
  }

  @Test
  public void test2603() {
    coral.tests.JPFBenchmark.benchmark06(-1.5579602273155886,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2604() {
    coral.tests.JPFBenchmark.benchmark06(-1.558450415543263,-1.5707835764996398,-163.39258505449433 ) ;
  }

  @Test
  public void test2605() {
    coral.tests.JPFBenchmark.benchmark06(-1.5585219632104856,-0.8877859697111818,20.0213075172302 ) ;
  }

  @Test
  public void test2606() {
    coral.tests.JPFBenchmark.benchmark06(-1.5585784763958999,-0.7225946476468142,-62.38146624516355 ) ;
  }

  @Test
  public void test2607() {
    coral.tests.JPFBenchmark.benchmark06(-1.5585918436268436,-88.523700159331,-64.5998973530677 ) ;
  }

  @Test
  public void test2608() {
    coral.tests.JPFBenchmark.benchmark06(-1.5586029985969958,5.551115123125783E-17,1.272376408072849 ) ;
  }

  @Test
  public void test2609() {
    coral.tests.JPFBenchmark.benchmark06(-1.558758474749598,-213.97552736883037,-1.5707963267948966 ) ;
  }

  @Test
  public void test2610() {
    coral.tests.JPFBenchmark.benchmark06(-1.5587599565000545,-1.5477054843634,0.0 ) ;
  }

  @Test
  public void test2611() {
    coral.tests.JPFBenchmark.benchmark06(-1.5588842451026819,-3.1415926579394937,100.0 ) ;
  }

  @Test
  public void test2612() {
    coral.tests.JPFBenchmark.benchmark06(-1.5590865042145003,6.712388980384907,-13.079306098151726 ) ;
  }

  @Test
  public void test2613() {
    coral.tests.JPFBenchmark.benchmark06(-1.559325882566545,-1.4744255512581497,30.362168920169474 ) ;
  }

  @Test
  public void test2614() {
    coral.tests.JPFBenchmark.benchmark06(-1.5593960739333794,-2.220446049250313E-16,1.5707963267948966 ) ;
  }

  @Test
  public void test2615() {
    coral.tests.JPFBenchmark.benchmark06(-1.559748571684704,2.465190328815662E-32,-18.109480806848495 ) ;
  }

  @Test
  public void test2616() {
    coral.tests.JPFBenchmark.benchmark06(-1.5597711021514795,-214.19819064339927,-66.49920393203233 ) ;
  }

  @Test
  public void test2617() {
    coral.tests.JPFBenchmark.benchmark06(-1.559786005868053,-1.5707963267948966,-2.1753825819048846 ) ;
  }

  @Test
  public void test2618() {
    coral.tests.JPFBenchmark.benchmark06(-1.5599140024371914,-1.0726998322384529,-40.52014435398539 ) ;
  }

  @Test
  public void test2619() {
    coral.tests.JPFBenchmark.benchmark06(-1.5601234785501663,-0.47819608146437786,-731.3851893264489 ) ;
  }

  @Test
  public void test2620() {
    coral.tests.JPFBenchmark.benchmark06(-1.5601682195273887,-1.5707963267948966,-5.55398583227415 ) ;
  }

  @Test
  public void test2621() {
    coral.tests.JPFBenchmark.benchmark06(-1.5608247434408602,-1.5707963267948966,-4.7126331213075945 ) ;
  }

  @Test
  public void test2622() {
    coral.tests.JPFBenchmark.benchmark06(-1.5610932184136264,-32.98660074841961,-151.55425999127218 ) ;
  }

  @Test
  public void test2623() {
    coral.tests.JPFBenchmark.benchmark06(-1.5611207320977238,-1.5707963267948966,-3.141592653589793 ) ;
  }

  @Test
  public void test2624() {
    coral.tests.JPFBenchmark.benchmark06(-1.562029044926595,-1.5601523562236705,-100.0 ) ;
  }

  @Test
  public void test2625() {
    coral.tests.JPFBenchmark.benchmark06(-1.562098118522179,-19.34955863122026,-1.5707963267948966 ) ;
  }

  @Test
  public void test2626() {
    coral.tests.JPFBenchmark.benchmark06(-1.5622019926042618,-1.5707963267948966,-8.103981633974767 ) ;
  }

  @Test
  public void test2627() {
    coral.tests.JPFBenchmark.benchmark06(-1.5626417668229198,-4.150923074439571E-15,70.789879788299 ) ;
  }

  @Test
  public void test2628() {
    coral.tests.JPFBenchmark.benchmark06(-1.5630028169169068,-1.3432313955847675,-1.5707963267948966 ) ;
  }

  @Test
  public void test2629() {
    coral.tests.JPFBenchmark.benchmark06(-1.5631454930343096,-0.5280469201446905,-122.54702076034228 ) ;
  }

  @Test
  public void test2630() {
    coral.tests.JPFBenchmark.benchmark06(-1.5633630808421566,-1.5707963267948966,-3.141592653589796 ) ;
  }

  @Test
  public void test2631() {
    coral.tests.JPFBenchmark.benchmark06(-1.56390496305588,-1.5707963267948966,3.2665926575247224 ) ;
  }

  @Test
  public void test2632() {
    coral.tests.JPFBenchmark.benchmark06(-1.5642549908312422,-1.0280802350701588,1100.2915869224544 ) ;
  }

  @Test
  public void test2633() {
    coral.tests.JPFBenchmark.benchmark06(-1.564378330463114,-1.5707963267948966,1.1563611805102325 ) ;
  }

  @Test
  public void test2634() {
    coral.tests.JPFBenchmark.benchmark06(-1.5644928596012115,-1.5707963267948966,-1.5864230702672735 ) ;
  }

  @Test
  public void test2635() {
    coral.tests.JPFBenchmark.benchmark06(-1.5647772994866735,-39.101132747691864,-1.5707963267948966 ) ;
  }

  @Test
  public void test2636() {
    coral.tests.JPFBenchmark.benchmark06(-1.5647856136450804,-44.990815876356805,-123.00616035272299 ) ;
  }

  @Test
  public void test2637() {
    coral.tests.JPFBenchmark.benchmark06(-1.564951687573167,-88.27950732610907,-0.19404901952001552 ) ;
  }

  @Test
  public void test2638() {
    coral.tests.JPFBenchmark.benchmark06(-1.5652025028055194,-1.5707963267948966,1.5707963267948963 ) ;
  }

  @Test
  public void test2639() {
    coral.tests.JPFBenchmark.benchmark06(-1.5656701192237625,-1.5707963267948966,4.743639265975461 ) ;
  }

  @Test
  public void test2640() {
    coral.tests.JPFBenchmark.benchmark06(-1.5656932968936548,-0.35188986645921716,83.9574392020227 ) ;
  }

  @Test
  public void test2641() {
    coral.tests.JPFBenchmark.benchmark06(-1.5657231190515621,-1.5707963267948966,-1.0254310897639192 ) ;
  }

  @Test
  public void test2642() {
    coral.tests.JPFBenchmark.benchmark06(-1.566071094382422,-1.5707963267948966,-8.140999157390837 ) ;
  }

  @Test
  public void test2643() {
    coral.tests.JPFBenchmark.benchmark06(-1.5660906785054238,-38.93215197200481,-3.266592656957311 ) ;
  }

  @Test
  public void test2644() {
    coral.tests.JPFBenchmark.benchmark06(-1.5661113535469866,-31.696036481220926,-41.89134549136655 ) ;
  }

  @Test
  public void test2645() {
    coral.tests.JPFBenchmark.benchmark06(-1.5663294445771778,-1.5707963267948966,-4.712670107256616 ) ;
  }

  @Test
  public void test2646() {
    coral.tests.JPFBenchmark.benchmark06(-1.5663370750370877,-2.2541451703578456E-131,1.5707963267948966 ) ;
  }

  @Test
  public void test2647() {
    coral.tests.JPFBenchmark.benchmark06(-1.566458298181165,-1.565074652159196,81.56329577298834 ) ;
  }

  @Test
  public void test2648() {
    coral.tests.JPFBenchmark.benchmark06(-1.566567655579252,-1.5707963267948966,-27.32171915842057 ) ;
  }

  @Test
  public void test2649() {
    coral.tests.JPFBenchmark.benchmark06(-1.5666739391107363,-0.6364459543183687,88.42815421822024 ) ;
  }

  @Test
  public void test2650() {
    coral.tests.JPFBenchmark.benchmark06(-1.566766717047582,-1.5707963267948966,45.3953595702865 ) ;
  }

  @Test
  public void test2651() {
    coral.tests.JPFBenchmark.benchmark06(-1.5671204374771373,-3.1415926704598056,0.025682517337304908 ) ;
  }

  @Test
  public void test2652() {
    coral.tests.JPFBenchmark.benchmark06(-1.567287207604841,-88.12185258283907,-1.5707963267948974 ) ;
  }

  @Test
  public void test2653() {
    coral.tests.JPFBenchmark.benchmark06(-1.5673206685071666,-1.5707963267948912,-44.10933871489333 ) ;
  }

  @Test
  public void test2654() {
    coral.tests.JPFBenchmark.benchmark06(-1.567851453769825,-1.5707963267948966,65.53938600574656 ) ;
  }

  @Test
  public void test2655() {
    coral.tests.JPFBenchmark.benchmark06(-1.567884080718015,-0.7519384729804377,1.5707963267948974 ) ;
  }

  @Test
  public void test2656() {
    coral.tests.JPFBenchmark.benchmark06(-1.568191032968524,-1.5707963267948966,-112.34565749738015 ) ;
  }

  @Test
  public void test2657() {
    coral.tests.JPFBenchmark.benchmark06(-1.5682712191060777,-39.1105722298948,-3.141592653589793 ) ;
  }

  @Test
  public void test2658() {
    coral.tests.JPFBenchmark.benchmark06(-1.56830035214089,-1.5692592479153753,-112.3444466636144 ) ;
  }

  @Test
  public void test2659() {
    coral.tests.JPFBenchmark.benchmark06(-1.5683957346677948,-1.5707963267948963,88.27964839753173 ) ;
  }

  @Test
  public void test2660() {
    coral.tests.JPFBenchmark.benchmark06(-1.568471843207107,-1.5707963267948966,4.743639404903044 ) ;
  }

  @Test
  public void test2661() {
    coral.tests.JPFBenchmark.benchmark06(-1.5687454184898584,-1.5707963267948966,-76.66443850234506 ) ;
  }

  @Test
  public void test2662() {
    coral.tests.JPFBenchmark.benchmark06(-1.56885214400278,-32.71502705307581,-1.5707963267948966 ) ;
  }

  @Test
  public void test2663() {
    coral.tests.JPFBenchmark.benchmark06(-1.5688625095186983,-43.98320378595867,-34.48111332543335 ) ;
  }

  @Test
  public void test2664() {
    coral.tests.JPFBenchmark.benchmark06(-1.5688847059306354,-1.5707963267948966,1.5707963219913115 ) ;
  }

  @Test
  public void test2665() {
    coral.tests.JPFBenchmark.benchmark06(-1.5688994168253605,-2.7755575615628914E-17,85.39570313485747 ) ;
  }

  @Test
  public void test2666() {
    coral.tests.JPFBenchmark.benchmark06(-1.568953581357397,-0.8494142960924513,2.9492401059238936E-17 ) ;
  }

  @Test
  public void test2667() {
    coral.tests.JPFBenchmark.benchmark06(-1.569091415863621,-1.5707621002101941,-112.34137919562271 ) ;
  }

  @Test
  public void test2668() {
    coral.tests.JPFBenchmark.benchmark06(-1.569294194953912,-95.26073302709777,-1.57081685342768 ) ;
  }

  @Test
  public void test2669() {
    coral.tests.JPFBenchmark.benchmark06(-1.5693904610028513,-1.5707963267948966,99.95593008267976 ) ;
  }

  @Test
  public void test2670() {
    coral.tests.JPFBenchmark.benchmark06(-1.5694398748078249,-1.570468825313411,75.39577569601302 ) ;
  }

  @Test
  public void test2671() {
    coral.tests.JPFBenchmark.benchmark06(-1.5694715318484396,-32.797246258286364,-9.845142356565878 ) ;
  }

  @Test
  public void test2672() {
    coral.tests.JPFBenchmark.benchmark06(-1.5695553443580628,7.853981633969556,-95.60092458918847 ) ;
  }

  @Test
  public void test2673() {
    coral.tests.JPFBenchmark.benchmark06(-1.5696653213479836,-1.5707963267948966,-53.10748553388903 ) ;
  }

  @Test
  public void test2674() {
    coral.tests.JPFBenchmark.benchmark06(-1.5698527572631065,-31.625822422158592,-10.481286001492919 ) ;
  }

  @Test
  public void test2675() {
    coral.tests.JPFBenchmark.benchmark06(-1.569879432698928,-1.5707963267948966,43.50725633435957 ) ;
  }

  @Test
  public void test2676() {
    coral.tests.JPFBenchmark.benchmark06(-1.569954599431944,-1.5707963267948966,-17.280262282487918 ) ;
  }

  @Test
  public void test2677() {
    coral.tests.JPFBenchmark.benchmark06(-1.5700212612014675,-1.5707963267948966,34.55751918948772 ) ;
  }

  @Test
  public void test2678() {
    coral.tests.JPFBenchmark.benchmark06(-1.570320319661905,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2679() {
    coral.tests.JPFBenchmark.benchmark06(-1.570378960231313,-0.4902430813898557,-37.32379518803117 ) ;
  }

  @Test
  public void test2680() {
    coral.tests.JPFBenchmark.benchmark06(-1.5705194701685299,-32.94349004334107,-57.01767192500234 ) ;
  }

  @Test
  public void test2681() {
    coral.tests.JPFBenchmark.benchmark06(-1.570616658900574,-31.624933729728063,-3.3638234422703097 ) ;
  }

  @Test
  public void test2682() {
    coral.tests.JPFBenchmark.benchmark06(-1.570648461041449,-1.3552527156068805E-20,9.424961993222361 ) ;
  }

  @Test
  public void test2683() {
    coral.tests.JPFBenchmark.benchmark06(-1.5706503200630126,-1.5707963267948966,100.53070390701141 ) ;
  }

  @Test
  public void test2684() {
    coral.tests.JPFBenchmark.benchmark06(-1.570673090396034,-1.5707963267948966,6.287091595762255 ) ;
  }

  @Test
  public void test2685() {
    coral.tests.JPFBenchmark.benchmark06(-1.57068255343056,-0.09874524101792126,-97.19547362352827 ) ;
  }

  @Test
  public void test2686() {
    coral.tests.JPFBenchmark.benchmark06(-1.5706907577769276,-5.551115123125783E-17,-53.32651364932645 ) ;
  }

  @Test
  public void test2687() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707058102599598,-94.36399549130178,-40.25980972045023 ) ;
  }

  @Test
  public void test2688() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707151231999132,-2.103146720144975E-5,83.23988420072118 ) ;
  }

  @Test
  public void test2689() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707168512403724,-8.470329472543003E-22,47.120807971273706 ) ;
  }

  @Test
  public void test2690() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707169039818505,-8.673617379884035E-19,-78.53978352654066 ) ;
  }

  @Test
  public void test2691() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707226611023448,-44.089752871889004,-25.298604342173444 ) ;
  }

  @Test
  public void test2692() {
    coral.tests.JPFBenchmark.benchmark06(-1.570739020420996,-31.42040305791688,-71.53110782580953 ) ;
  }

  @Test
  public void test2693() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707400594476522,-1.5707963267948966,6.284316602774835 ) ;
  }

  @Test
  public void test2694() {
    coral.tests.JPFBenchmark.benchmark06(-1.570742676066441,-43.98233539974149,-34.55813469391836 ) ;
  }

  @Test
  public void test2695() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707516388169722,-1.2711924426432204,-86.77093109897098 ) ;
  }

  @Test
  public void test2696() {
    coral.tests.JPFBenchmark.benchmark06(-1.570763107209899,-1.5705303127109362,43.23257467475342 ) ;
  }

  @Test
  public void test2697() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707654465892595,-4.3368086899420177E-19,21.9911261740911 ) ;
  }

  @Test
  public void test2698() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707711012209578,-1.5707963267948966,-4.712633125353207 ) ;
  }

  @Test
  public void test2699() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707721723733754,-1.5707963267948912,-112.5265468410326 ) ;
  }

  @Test
  public void test2700() {
    coral.tests.JPFBenchmark.benchmark06(-1.570774072630368,-1.570794673695394,-56.54839937377685 ) ;
  }

  @Test
  public void test2701() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707805885552417,-1.5790441224895302E-9,-17.341281359233985 ) ;
  }

  @Test
  public void test2702() {
    coral.tests.JPFBenchmark.benchmark06(-1.570788521461753,-8.59410024049225E-6,-91.10422813604917 ) ;
  }

  @Test
  public void test2703() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707887602415178,-1.5707963267948966,-31.882936757954425 ) ;
  }

  @Test
  public void test2704() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707895432011403,-1.5707807036921033,-37.72434647829007 ) ;
  }

  @Test
  public void test2705() {
    coral.tests.JPFBenchmark.benchmark06(-1.570791371562033,-1.5707963267948966,-188.50212226212574 ) ;
  }

  @Test
  public void test2706() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707919883636654,-1.5695883196519784,56.64315937691032 ) ;
  }

  @Test
  public void test2707() {
    coral.tests.JPFBenchmark.benchmark06(-1.570792038611261,-1.3189064782536628,3.141592653589793 ) ;
  }

  @Test
  public void test2708() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707924858919238,-1.5707963267948966,-94.24772448462186 ) ;
  }

  @Test
  public void test2709() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707930725221826,-1.5707963267948966,25.13239298813135 ) ;
  }

  @Test
  public void test2710() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707931008034273,-1.7705945816539794E-9,45.5514127381348 ) ;
  }

  @Test
  public void test2711() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707931085031115,-1.570796090813532,-75.42413343415639 ) ;
  }

  @Test
  public void test2712() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707932868369265,-2.446009866640991E-22,-3.141224330042768 ) ;
  }

  @Test
  public void test2713() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707933087337929,-1.5707963267948966,-88.08959732108735 ) ;
  }

  @Test
  public void test2714() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707937906915355,-1.5707963267948966,100.50865367554377 ) ;
  }

  @Test
  public void test2715() {
    coral.tests.JPFBenchmark.benchmark06(-1.570794881198178,-1.4451516768951271,2.5084346486194486 ) ;
  }

  @Test
  public void test2716() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707948874612885,-1.0587911840678754E-22,47.12697038571249 ) ;
  }

  @Test
  public void test2717() {
    coral.tests.JPFBenchmark.benchmark06(-1.570795322759778,-1.5707957028041715,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test2718() {
    coral.tests.JPFBenchmark.benchmark06(-1.570795341290819,-1.5707963267948966,55.79919806450672 ) ;
  }

  @Test
  public void test2719() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707953562172492,-95.5297192164708,-71.60960197845321 ) ;
  }

  @Test
  public void test2720() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707954125994754,-1.5707963267948966,-43.97391729217553 ) ;
  }

  @Test
  public void test2721() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707956100627816,-1.570794131842833,100.0 ) ;
  }

  @Test
  public void test2722() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707958177675723,-95.81628528890529,-69.14628976473671 ) ;
  }

  @Test
  public void test2723() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707958406016933,-8.673617379884035E-19,72.19380316279187 ) ;
  }

  @Test
  public void test2724() {
    coral.tests.JPFBenchmark.benchmark06(-1.570795862909614,-1.5707963267948966,75.39819881856766 ) ;
  }

  @Test
  public void test2725() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707959374098033,-157.37744216666462,-38.95018226000142 ) ;
  }

  @Test
  public void test2726() {
    coral.tests.JPFBenchmark.benchmark06(-1.570795939707247,-1.5399957083918716,16.167091530662564 ) ;
  }

  @Test
  public void test2727() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796004966748,-157.0971053037605,-58.11942953731406 ) ;
  }

  @Test
  public void test2728() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707960708438675,-1.9343126529188102E-10,-153.93801895829583 ) ;
  }

  @Test
  public void test2729() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707960763266102,-1.5707963267948966,-31.681851432430953 ) ;
  }

  @Test
  public void test2730() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707961065573537,-1.5706876770693565,55.799106631803426 ) ;
  }

  @Test
  public void test2731() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707961516320323,-1.4984266212876417E-15,-3.141592653589793 ) ;
  }

  @Test
  public void test2732() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707961565971635,-1.5707910214661656,-18.837655085639145 ) ;
  }

  @Test
  public void test2733() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707962032133789,-1.5707963267948948,-1.5707963267247689 ) ;
  }

  @Test
  public void test2734() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707962209092559,-8.881784197001252E-16,-67.54817150678609 ) ;
  }

  @Test
  public void test2735() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707962347467772,-1.5707963267948983,-32.18125034087255 ) ;
  }

  @Test
  public void test2736() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796258547544,-1.5707963267948966,-62.8095564073905 ) ;
  }

  @Test
  public void test2737() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707962628949597,-1.5707963267948966,-131.91663732161118 ) ;
  }

  @Test
  public void test2738() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707962671801476,-4.440892098500626E-16,88.32181354009361 ) ;
  }

  @Test
  public void test2739() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707962764827021,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2740() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707962818972188,-0.8098594478449539,18.301002594394934 ) ;
  }

  @Test
  public void test2741() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707962826760804,-6.938893903907228E-18,85.07657840043576 ) ;
  }

  @Test
  public void test2742() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796284979392,-1.691529259589872E-10,-40.84005542864219 ) ;
  }

  @Test
  public void test2743() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707962868829264,-1.5707963267948966,99.96011695145681 ) ;
  }

  @Test
  public void test2744() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707962881637143,-0.7808547489003064,4.3071237547683483E-16 ) ;
  }

  @Test
  public void test2745() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707962908032616,-1.5707963267948966,81.68152206778738 ) ;
  }

  @Test
  public void test2746() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707962911602038,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2747() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707962933567128,-1.5707963267948966,44.04479888362765 ) ;
  }

  @Test
  public void test2748() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707962967295257,-1.5707963267948966,-31.415712578669293 ) ;
  }

  @Test
  public void test2749() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707962989238853,-0.042901660605020486,-100.0 ) ;
  }

  @Test
  public void test2750() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707962990701951,-1.5707963267948966,74.98262759319388 ) ;
  }

  @Test
  public void test2751() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707962992485052,-1.5707963267948966,0.854965068086424 ) ;
  }

  @Test
  public void test2752() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963013742847,-1.5707963267948966,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test2753() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796304286351,-1.5707963267948966,-96.83612189683335 ) ;
  }

  @Test
  public void test2754() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963042990616,-1.5707963267948966,123.77380607766428 ) ;
  }

  @Test
  public void test2755() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963045495645,-1.5707963267948966,-12.566371716599635 ) ;
  }

  @Test
  public void test2756() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796305858455,-1.5707963267949019,61.88420278799629 ) ;
  }

  @Test
  public void test2757() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963069786353,-1.5707963267948906,0.0 ) ;
  }

  @Test
  public void test2758() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963101468754,-0.9832436871530523,-1.5707963267948983 ) ;
  }

  @Test
  public void test2759() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796313170247,-1.5707963267948966,31.447279181807453 ) ;
  }

  @Test
  public void test2760() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963161513927,-1.5707963267948966,4.392449730399779 ) ;
  }

  @Test
  public void test2761() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963161983365,-1.5707963267948966,-7.86179413397645 ) ;
  }

  @Test
  public void test2762() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963177747746,-1.2173186012643953,-135.30289588199346 ) ;
  }

  @Test
  public void test2763() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963179856774,-1.2327757297285595,-92.17329809086505 ) ;
  }

  @Test
  public void test2764() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963202942445,-88.31454824281295,-1.5707963267949054 ) ;
  }

  @Test
  public void test2765() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796320641655,-1.5707963267948966,-56.54843267036926 ) ;
  }

  @Test
  public void test2766() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796320995781,-1.5707963267948963,0.677076818202341 ) ;
  }

  @Test
  public void test2767() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963217688852,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2768() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796321972304,-31.447697915924778,-1.5707963267948966 ) ;
  }

  @Test
  public void test2769() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963220792465,-2.220446049250313E-16,-91.1075526655117 ) ;
  }

  @Test
  public void test2770() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963222148063,-1.5707963267948966,-84.56006862447141 ) ;
  }

  @Test
  public void test2771() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796322712092,-5.646723564925244E-4,-227.7111776362875 ) ;
  }

  @Test
  public void test2772() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963227121289,-1.0057979485164195E-9,-3.1415926535897913 ) ;
  }

  @Test
  public void test2773() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796322919795,-45.41192694069759,-67.06581289096904 ) ;
  }

  @Test
  public void test2774() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963232434188,-0.6627299832988042,0.0 ) ;
  }

  @Test
  public void test2775() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963235039468,-1.5707963267948917,-100.0 ) ;
  }

  @Test
  public void test2776() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796323731415,-9.344320211803607E-11,61.263011121206496 ) ;
  }

  @Test
  public void test2777() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963237949791,-1.5707789516199369,-43.98226488882476 ) ;
  }

  @Test
  public void test2778() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963244709702,-0.2956109998125105,-95.32744409203094 ) ;
  }

  @Test
  public void test2779() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963248183265,-1.5707963267948273,100.51699503609603 ) ;
  }

  @Test
  public void test2780() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963253579824,-1.5707963267948966,-5.686818212481825 ) ;
  }

  @Test
  public void test2781() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963253597403,-1.5707963267948961,-0.01271448666707737 ) ;
  }

  @Test
  public void test2782() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963254250044,-0.9576629720948401,-1.5707963267948983 ) ;
  }

  @Test
  public void test2783() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963254808086,-0.615641815254604,23.83907096931394 ) ;
  }

  @Test
  public void test2784() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963255032562,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2785() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963255912447,-1.0862383584553257,1.5707963267948961 ) ;
  }

  @Test
  public void test2786() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963256278674,-0.31859162454808954,7.295861577723541 ) ;
  }

  @Test
  public void test2787() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796325677465,-1.570761382870237,-84.74000521000919 ) ;
  }

  @Test
  public void test2788() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796325731909,-0.5613929283074695,28.638298692870364 ) ;
  }

  @Test
  public void test2789() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963258642328,-32.87506592844164,-1.5707963267949054 ) ;
  }

  @Test
  public void test2790() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963258913042,-0.6696449887541154,0.6382813323469488 ) ;
  }

  @Test
  public void test2791() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963259051878,-2.9629805452929814E-4,-57.84717806278062 ) ;
  }

  @Test
  public void test2792() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963259700355,-32.43866469854735,-35.277658408444054 ) ;
  }

  @Test
  public void test2793() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963260505908,-1.5707963267948966,24.24170507009633 ) ;
  }

  @Test
  public void test2794() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963260954827,-1.5707963267948966,138.22603944676638 ) ;
  }

  @Test
  public void test2795() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326281961,-1.2240267325107288,-35.464562005032036 ) ;
  }

  @Test
  public void test2796() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963262829452,-1.5707963267948966,-29.38481857272166 ) ;
  }

  @Test
  public void test2797() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963262846754,-0.6651680633810902,-4.496340848180949 ) ;
  }

  @Test
  public void test2798() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963262912017,-1.5707963267948966,42.08823591303395 ) ;
  }

  @Test
  public void test2799() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963262918303,-1.5707963267948912,1.5707963267948983 ) ;
  }

  @Test
  public void test2800() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963263063718,-0.28827541788493183,-84.77607952389337 ) ;
  }

  @Test
  public void test2801() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963263090994,-0.9243215636137614,77.38024227801841 ) ;
  }

  @Test
  public void test2802() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963263159435,-1.5707963267948966,-7.906706678767371 ) ;
  }

  @Test
  public void test2803() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963263355351,-1.5198363683774168,-7.389004646923134 ) ;
  }

  @Test
  public void test2804() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963263658535,-1.0917538209567803,40.28465053513219 ) ;
  }

  @Test
  public void test2805() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963263673674,-44.99570609502024,-56.75833112302273 ) ;
  }

  @Test
  public void test2806() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963263698668,-1.5707963267948948,100.0 ) ;
  }

  @Test
  public void test2807() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963263708176,-0.4434221839672586,33.08029037904562 ) ;
  }

  @Test
  public void test2808() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963263854225,-0.13915712625840398,-95.2982960600192 ) ;
  }

  @Test
  public void test2809() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326404985,-1.5707963267948966,63.17021249701746 ) ;
  }

  @Test
  public void test2810() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963264178666,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2811() {
    coral.tests.JPFBenchmark.benchmark06(-1.57079632642485,-1.5707963267948966,-1.5707963267948948 ) ;
  }

  @Test
  public void test2812() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963264384546,-45.050798830742195,-71.20838257497344 ) ;
  }

  @Test
  public void test2813() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326441787,-44.09795267188325,-1.5707963267948966 ) ;
  }

  @Test
  public void test2814() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326457978,-1.0317509897463066,-1.5707963267948966 ) ;
  }

  @Test
  public void test2815() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963264641198,-0.7135133853501376,164.82419975745387 ) ;
  }

  @Test
  public void test2816() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963264756946,-1.1446923456073108,-1.5707963267948966 ) ;
  }

  @Test
  public void test2817() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963265024198,-1.5707963267948966,-112.1446451046481 ) ;
  }

  @Test
  public void test2818() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963265135028,-1.053223178656336,100.0 ) ;
  }

  @Test
  public void test2819() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963265147091,-0.574714233002041,0.0 ) ;
  }

  @Test
  public void test2820() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963265246057,-1.5707963267948963,64.16693310911354 ) ;
  }

  @Test
  public void test2821() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963265290406,-0.3848591587155064,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test2822() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963265333116,-0.07105279950321196,-30.33812217999715 ) ;
  }

  @Test
  public void test2823() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326552448,-101.99525992429075,-89.61957781797427 ) ;
  }

  @Test
  public void test2824() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963265539815,-0.17161593528560495,73.48898921424914 ) ;
  }

  @Test
  public void test2825() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963265606306,-31.974038399717372,-32.607612477623064 ) ;
  }

  @Test
  public void test2826() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963265641163,-31.702665946143274,-29.380466738976786 ) ;
  }

  @Test
  public void test2827() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963265666864,-1.5707963267948966,2.762137876958816 ) ;
  }

  @Test
  public void test2828() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963265993239,-1.5707963267948966,-2.842714065158418 ) ;
  }

  @Test
  public void test2829() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963265994953,-0.19337000018225284,42.76155453434087 ) ;
  }

  @Test
  public void test2830() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326600987,-1.5707963267948966,-7.05667391489407 ) ;
  }

  @Test
  public void test2831() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963266182112,-1.2045792698902906,84.38978336736488 ) ;
  }

  @Test
  public void test2832() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963266196285,-1.5707963267918903,0.0 ) ;
  }

  @Test
  public void test2833() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326632576,-1.5707963267948966,91.88616781228043 ) ;
  }

  @Test
  public void test2834() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326640681,-0.3354508502950521,-17.36473769441734 ) ;
  }

  @Test
  public void test2835() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963266411216,-0.3225759852091521,1.5707963267948948 ) ;
  }

  @Test
  public void test2836() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963266525833,-1.5707963267949014,43.390063346655296 ) ;
  }

  @Test
  public void test2837() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963266633809,-0.6683826659059678,-100.0 ) ;
  }

  @Test
  public void test2838() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326663607,-1.0132500914595628,-0.0771877597776466 ) ;
  }

  @Test
  public void test2839() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963266875258,-31.7408269119753,-35.00345770790121 ) ;
  }

  @Test
  public void test2840() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963266939418,-1.5707963267948966,-56.5355681067274 ) ;
  }

  @Test
  public void test2841() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326700312,-1.5707963267948966,-1.0291221122700998 ) ;
  }

  @Test
  public void test2842() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267074045,-1.5707963267948966,3.552713678800501E-15 ) ;
  }

  @Test
  public void test2843() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267131315,-1.5707963267948966,44.32980524118611 ) ;
  }

  @Test
  public void test2844() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267405665,-38.946250870683734,-45.96482356579575 ) ;
  }

  @Test
  public void test2845() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267409315,-1.5707963267948966,46.16202340264109 ) ;
  }

  @Test
  public void test2846() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267436866,-1.5707963267948966,-9.46585955671784 ) ;
  }

  @Test
  public void test2847() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267509466,-0.6887865505240115,30.12379130942124 ) ;
  }

  @Test
  public void test2848() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267602867,-1.5707963267948966,-75.4435353815896 ) ;
  }

  @Test
  public void test2849() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267603609,-1.3129655613598161,-1.2614496665384063 ) ;
  }

  @Test
  public void test2850() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267623601,-0.45070540872032216,167.89174821760034 ) ;
  }

  @Test
  public void test2851() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267653795,-1.5707963267948966,-0.28039759142311216 ) ;
  }

  @Test
  public void test2852() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267711458,-1.570796326588353,-62.89436739560549 ) ;
  }

  @Test
  public void test2853() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267731362,-1.5707963267948954,-46.10949530677227 ) ;
  }

  @Test
  public void test2854() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267774707,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2855() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326784671,-1.5707963267948966,-70.60470827532146 ) ;
  }

  @Test
  public void test2856() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267856406,-0.6189619387150964,21.300095561699887 ) ;
  }

  @Test
  public void test2857() {
    coral.tests.JPFBenchmark.benchmark06(-1.57079632678992,-1.5707963267948966,34.97032933927068 ) ;
  }

  @Test
  public void test2858() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267904292,-0.25384785960777767,-65.9570793622214 ) ;
  }

  @Test
  public void test2859() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267908056,-1.5707963267948966,-97.13634433134365 ) ;
  }

  @Test
  public void test2860() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267911076,-95.59732282860409,-35.560325668122864 ) ;
  }

  @Test
  public void test2861() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267917329,-1.5707963267948966,-83.1324193697337 ) ;
  }

  @Test
  public void test2862() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267929301,-78.4880404118424,0 ) ;
  }

  @Test
  public void test2863() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326793155,-4.3368086899420177E-19,22.095992124033998 ) ;
  }

  @Test
  public void test2864() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267937455,-1.5707963267948966,13.512217099449138 ) ;
  }

  @Test
  public void test2865() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326793804,-1.5707963267948966,-1.5707963267950322 ) ;
  }

  @Test
  public void test2866() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267942924,-1.5707963267948966,-68.86835257263378 ) ;
  }

  @Test
  public void test2867() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267943903,-88.09796858237013,-10.701092175298541 ) ;
  }

  @Test
  public void test2868() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267944436,-1.5707963267948966,-50.3954066509215 ) ;
  }

  @Test
  public void test2869() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267944542,-0.4497459381798823,-100.0 ) ;
  }

  @Test
  public void test2870() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267944798,-1.5707963267948966,-1.5707963267948972 ) ;
  }

  @Test
  public void test2871() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267945295,-8.094842208213314E-10,-34.557548375807414 ) ;
  }

  @Test
  public void test2872() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267945608,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2873() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267945713,-1.5707963267948948,-43.892850742650744 ) ;
  }

  @Test
  public void test2874() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267946026,-0.0017449525769683838,1.634071483187779 ) ;
  }

  @Test
  public void test2875() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267946146,-95.31885454647353,-6.295658776865011 ) ;
  }

  @Test
  public void test2876() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267946152,-1.5707963267948948,10.542791145281935 ) ;
  }

  @Test
  public void test2877() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267946419,-1.5707963267948966,91.10592745608984 ) ;
  }

  @Test
  public void test2878() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267946639,-0.4859916595230337,58.39200575787154 ) ;
  }

  @Test
  public void test2879() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267946852,4.3368086899420177E-19,-55.07367609540262 ) ;
  }

  @Test
  public void test2880() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267947243,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2881() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794742,-1.5707963267948912,-6.054470560301276E-16 ) ;
  }

  @Test
  public void test2882() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267947669,-3.552713678800501E-15,-87.0740934977202 ) ;
  }

  @Test
  public void test2883() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267947704,-1.2413812268020967,25.957814529931042 ) ;
  }

  @Test
  public void test2884() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267947707,-1.5707963267948966,-6.233897936646423 ) ;
  }

  @Test
  public void test2885() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267947762,-1.5707963267948966,71.34315308625973 ) ;
  }

  @Test
  public void test2886() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267947775,-1.5707963267948912,1.5707963267948966 ) ;
  }

  @Test
  public void test2887() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267947846,-1.174228143801691,78.19213470526404 ) ;
  }

  @Test
  public void test2888() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267947882,-1.5707963267948966,26.259401669366625 ) ;
  }

  @Test
  public void test2889() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267947913,-0.1968356283967052,64.54218288581862 ) ;
  }

  @Test
  public void test2890() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794802,-0.5191677739124139,100.0 ) ;
  }

  @Test
  public void test2891() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794808,-1.5707963267948966,1.5717729800770006 ) ;
  }

  @Test
  public void test2892() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948133,-45.04254077941294,-51.60666844144435 ) ;
  }

  @Test
  public void test2893() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948226,-0.9463297074870474,-100.0 ) ;
  }

  @Test
  public void test2894() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948273,-0.044391911304013654,29.88248991650515 ) ;
  }

  @Test
  public void test2895() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948306,-1.4875244648072954,16.350286936113648 ) ;
  }

  @Test
  public void test2896() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948375,-1.5565047322318166,1.5707963267949467 ) ;
  }

  @Test
  public void test2897() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948406,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2898() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948544,2.465190328815662E-32,-0.9348880837507753 ) ;
  }

  @Test
  public void test2899() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948566,-0.036980891288191264,-52.62401776657682 ) ;
  }

  @Test
  public void test2900() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948593,-1.5707963267948983,94.56693692649873 ) ;
  }

  @Test
  public void test2901() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948637,-1.5707637147391917,43.98722572171853 ) ;
  }

  @Test
  public void test2902() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948664,-4.4026272858551673E-134,4.311887944384279 ) ;
  }

  @Test
  public void test2903() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948666,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test2904() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794871,-1.5707963267948974,-127.74361151811564 ) ;
  }

  @Test
  public void test2905() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948755,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2906() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948764,-1.1211530421272398,-45.14867598724393 ) ;
  }

  @Test
  public void test2907() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948768,-0.5101083287830768,97.41695143681385 ) ;
  }

  @Test
  public void test2908() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948768,-3.3087224502121107E-24,0.5855765176531861 ) ;
  }

  @Test
  public void test2909() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794877,-1.460116199958204,-37.82516858080307 ) ;
  }

  @Test
  public void test2910() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794877,-1.5707963267948966,19.83208324057098 ) ;
  }

  @Test
  public void test2911() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794877,-1.5707963267948966,22.23722791791363 ) ;
  }

  @Test
  public void test2912() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794877,-1.5707963267948966,-59.949877932280124 ) ;
  }

  @Test
  public void test2913() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948806,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test2914() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794881,-1.5707963267948966,-42.36245268791841 ) ;
  }

  @Test
  public void test2915() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948817,-1.5707963267948966,88.39731262899771 ) ;
  }

  @Test
  public void test2916() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948823,-1.5707963267948966,40.68113311890674 ) ;
  }

  @Test
  public void test2917() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948837,-1.5707963267948966,-10.668695572799507 ) ;
  }

  @Test
  public void test2918() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948841,-100.93240523799008,-110.89390757126212 ) ;
  }

  @Test
  public void test2919() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948841,-1.4716347613570402,-0.9952999246940948 ) ;
  }

  @Test
  public void test2920() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948841,-1.5707963267948966,-58.208759983535366 ) ;
  }

  @Test
  public void test2921() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948841,-38.98865392742546,-78.4954252796942 ) ;
  }

  @Test
  public void test2922() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948861,-1.5707963267948966,0.07795104631806 ) ;
  }

  @Test
  public void test2923() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948877,-0.7299180570010098,-58.419954662840865 ) ;
  }

  @Test
  public void test2924() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948877,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2925() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948877,-3.1415926535897953,22.448820945831002 ) ;
  }

  @Test
  public void test2926() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948877,-38.82893365801296,-3.266592655200008 ) ;
  }

  @Test
  public void test2927() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948877,-95.52044113412569,-31.475644036770007 ) ;
  }

  @Test
  public void test2928() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948881,-1.5707963267948966,2.5707963222130195 ) ;
  }

  @Test
  public void test2929() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948883,-0.7600983450708041,1.5707963267948966 ) ;
  }

  @Test
  public void test2930() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948883,-1.5707963267948948,1.5692294774078321 ) ;
  }

  @Test
  public void test2931() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948888,-1.5707963267948966,101.06874752901015 ) ;
  }

  @Test
  public void test2932() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948888,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2933() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948888,-1.5707963267948966,-52.8578330223626 ) ;
  }

  @Test
  public void test2934() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948892,-1.0010415475915505E-146,35.70478722257101 ) ;
  }

  @Test
  public void test2935() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948892,-1.5707963267948948,31.340266211730096 ) ;
  }

  @Test
  public void test2936() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948895,-1.5707963267948966,1.5707963267948972 ) ;
  }

  @Test
  public void test2937() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948895,-1.5707963267948966,-7.665221265042239E-15 ) ;
  }

  @Test
  public void test2938() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948895,-1.7763568394002505E-15,3.1415926535897967 ) ;
  }

  @Test
  public void test2939() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948897,-31.534015159000845,-3.266592653594608 ) ;
  }

  @Test
  public void test2940() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794891,-1.5707963267948963,-92.05378892383361 ) ;
  }

  @Test
  public void test2941() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794891,-1.5707963267948966,-3.1415926535897953 ) ;
  }

  @Test
  public void test2942() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794891,-1.5707963267948966,-86.65531206753785 ) ;
  }

  @Test
  public void test2943() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.0031294320400145625,53.170139226788166 ) ;
  }

  @Test
  public void test2944() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.027953172568160767,-0.5602549543525234 ) ;
  }

  @Test
  public void test2945() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.04827874633491547,-43.62598913435349 ) ;
  }

  @Test
  public void test2946() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.051268014263781136,-67.28123549995826 ) ;
  }

  @Test
  public void test2947() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.07685394321095781,-95.54941062939481 ) ;
  }

  @Test
  public void test2948() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.11340367418138189,-112.6574434773756 ) ;
  }

  @Test
  public void test2949() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.12533633655350618,99.3917615853536 ) ;
  }

  @Test
  public void test2950() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.18995357655753686,-1.5707963267948966 ) ;
  }

  @Test
  public void test2951() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.1958490979111757,-93.89913165999023 ) ;
  }

  @Test
  public void test2952() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.20474147090068628,-46.37127526375649 ) ;
  }

  @Test
  public void test2953() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.2585921794685029,-96.83752995560113 ) ;
  }

  @Test
  public void test2954() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.5236994657359668,-3.4118940795267747 ) ;
  }

  @Test
  public void test2955() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.5426945137439816,9.516486055215568 ) ;
  }

  @Test
  public void test2956() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.5462163716118815,25.590049987186433 ) ;
  }

  @Test
  public void test2957() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.6218356476426408,35.55658553166998 ) ;
  }

  @Test
  public void test2958() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.6539708089534866,-89.71391453454942 ) ;
  }

  @Test
  public void test2959() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.7095619175433128,89.58071226020652 ) ;
  }

  @Test
  public void test2960() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.7408142089734255,-48.96083448684752 ) ;
  }

  @Test
  public void test2961() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.7574658662676348,-31.90086485668968 ) ;
  }

  @Test
  public void test2962() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.8421924611391809,99.27864082511101 ) ;
  }

  @Test
  public void test2963() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.9499737984987164,49.12998647132878 ) ;
  }

  @Test
  public void test2964() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.956217478965462,85.58214161280068 ) ;
  }

  @Test
  public void test2965() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.9630967011348753,-51.46627810968032 ) ;
  }

  @Test
  public void test2966() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.9824159651370701,77.69164477658012 ) ;
  }

  @Test
  public void test2967() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-101.95443953082783,-45.26971992427234 ) ;
  }

  @Test
  public void test2968() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-102.10175497619487,-23.392049843232414 ) ;
  }

  @Test
  public void test2969() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.026680073463515,116.03856391063846 ) ;
  }

  @Test
  public void test2970() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.1715061632163137,27.830767751070383 ) ;
  }

  @Test
  public void test2971() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.2104682648017129,-45.36156962573224 ) ;
  }

  @Test
  public void test2972() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.2789831750844354,-85.7546612178719 ) ;
  }

  @Test
  public void test2973() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.2834373990301933,-69.46413385318301 ) ;
  }

  @Test
  public void test2974() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.2887345893557032,29.97219483485121 ) ;
  }

  @Test
  public void test2975() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.2940221958479359,-10.617024485813857 ) ;
  }

  @Test
  public void test2976() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.3321779206914552,-0.009881520026984725 ) ;
  }

  @Test
  public void test2977() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.3755312857630073,4.842251794555317 ) ;
  }

  @Test
  public void test2978() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.397134942311438,50.05943538412461 ) ;
  }

  @Test
  public void test2979() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.400911017477665,-4.7123966451296395 ) ;
  }

  @Test
  public void test2980() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.440987556671475,66.4761796147539 ) ;
  }

  @Test
  public void test2981() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,14.451458908979085,477.2793886129841 ) ;
  }

  @Test
  public void test2982() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.4724625718561706,-50.65535090058919 ) ;
  }

  @Test
  public void test2983() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.479277766104346,-5.633819724061013 ) ;
  }

  @Test
  public void test2984() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5335305186180057,1.5707963267948966 ) ;
  }

  @Test
  public void test2985() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.570796326794671,11.752086775974007 ) ;
  }

  @Test
  public void test2986() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948912,-4.369549607760078 ) ;
  }

  @Test
  public void test2987() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948912,45.55309347686422 ) ;
  }

  @Test
  public void test2988() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948912,67.44138892982664 ) ;
  }

  @Test
  public void test2989() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948912,-96.57720234461709 ) ;
  }

  @Test
  public void test2990() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948948,10.541803747747359 ) ;
  }

  @Test
  public void test2991() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948948,-17.387056057445477 ) ;
  }

  @Test
  public void test2992() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948948,41.81319050515148 ) ;
  }

  @Test
  public void test2993() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948948,-70.18187612980849 ) ;
  }

  @Test
  public void test2994() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948948,-7.42919730953669 ) ;
  }

  @Test
  public void test2995() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948948,92.05486185544525 ) ;
  }

  @Test
  public void test2996() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948961,85.3361281197412 ) ;
  }

  @Test
  public void test2997() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2998() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test2999() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-11.08375867423701 ) ;
  }

  @Test
  public void test3000() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,123.92403434641668 ) ;
  }

  @Test
  public void test3001() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,12.732820935066712 ) ;
  }

  @Test
  public void test3002() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,15.061576702484047 ) ;
  }

  @Test
  public void test3003() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-15.184714566970186 ) ;
  }

  @Test
  public void test3004() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-1.5707963267948957 ) ;
  }

  @Test
  public void test3005() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3006() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-1.5711387607062195 ) ;
  }

  @Test
  public void test3007() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-17.278759598469158 ) ;
  }

  @Test
  public void test3008() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-20.498361327834413 ) ;
  }

  @Test
  public void test3009() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,25.848405774613667 ) ;
  }

  @Test
  public void test3010() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-30.818793596065035 ) ;
  }

  @Test
  public void test3011() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-3.1415926536234333 ) ;
  }

  @Test
  public void test3012() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,31.416436791585337 ) ;
  }

  @Test
  public void test3013() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,32.83332204158785 ) ;
  }

  @Test
  public void test3014() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,39.192414127636994 ) ;
  }

  @Test
  public void test3015() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-40.90969654817103 ) ;
  }

  @Test
  public void test3016() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,41.137347218008806 ) ;
  }

  @Test
  public void test3017() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,42.260619605758905 ) ;
  }

  @Test
  public void test3018() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-45.32572791613409 ) ;
  }

  @Test
  public void test3019() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-45.41845218528759 ) ;
  }

  @Test
  public void test3020() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,461.77516740074594 ) ;
  }

  @Test
  public void test3021() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,46.75566825276211 ) ;
  }

  @Test
  public void test3022() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,47.06350612699498 ) ;
  }

  @Test
  public void test3023() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-51.5669378691388 ) ;
  }

  @Test
  public void test3024() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-54.32580836551735 ) ;
  }

  @Test
  public void test3025() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,59.46315635207818 ) ;
  }

  @Test
  public void test3026() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,64.49744504092553 ) ;
  }

  @Test
  public void test3027() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,66.19317681495649 ) ;
  }

  @Test
  public void test3028() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,69.80530484212971 ) ;
  }

  @Test
  public void test3029() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,74.12121595037215 ) ;
  }

  @Test
  public void test3030() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-74.57300986234819 ) ;
  }

  @Test
  public void test3031() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,77.10568002352755 ) ;
  }

  @Test
  public void test3032() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,78.91361353546893 ) ;
  }

  @Test
  public void test3033() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-84.53456249206327 ) ;
  }

  @Test
  public void test3034() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-95.81857593424503 ) ;
  }

  @Test
  public void test3035() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948983,-158.4611853564701 ) ;
  }

  @Test
  public void test3036() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948983,-47.905158306156245 ) ;
  }

  @Test
  public void test3037() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267949019,39.089673851715936 ) ;
  }

  @Test
  public void test3038() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-164.44021127138015,-35.906957084846454 ) ;
  }

  @Test
  public void test3039() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,1.734723475976807E-18,59.51097331800697 ) ;
  }

  @Test
  public void test3040() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-2.7755575615628914E-17,21.923477861868484 ) ;
  }

  @Test
  public void test3041() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-2.7755575615628914E-17,-2.5707963267913145 ) ;
  }

  @Test
  public void test3042() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-31.525876256806043,-3.028295915224291 ) ;
  }

  @Test
  public void test3043() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-31.855671149392407,-10.900006125621857 ) ;
  }

  @Test
  public void test3044() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-32.73553677481793,-135.57759208998937 ) ;
  }

  @Test
  public void test3045() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-32.7889580647526,-48.209572872923204 ) ;
  }

  @Test
  public void test3046() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-3.552713678800501E-15,-54.84327358693548 ) ;
  }

  @Test
  public void test3047() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-3.552713678800501E-15,55.94640798647143 ) ;
  }

  @Test
  public void test3048() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-37.82931372337963,-1.5707963267948966 ) ;
  }

  @Test
  public void test3049() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-3.789634620059709E-15,-3.141592653589793 ) ;
  }

  @Test
  public void test3050() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-38.85317643408586,-1.576402192143202 ) ;
  }

  @Test
  public void test3051() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-39.198020177034266,-92.379675286104 ) ;
  }

  @Test
  public void test3052() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-39.26507266892163,-66.88108935303097 ) ;
  }

  @Test
  public void test3053() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,4.3368086899420177E-19,43.36834998139249 ) ;
  }

  @Test
  public void test3054() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-44.181880977642095,-1.5707963267948966 ) ;
  }

  @Test
  public void test3055() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-44.20148707863305,-45.59896514853432 ) ;
  }

  @Test
  public void test3056() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-44.278069988985294,-3.6545924405633485 ) ;
  }

  @Test
  public void test3057() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-44.4270823586179,-64.09903069433132 ) ;
  }

  @Test
  public void test3058() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-44.54836274968771,8.470329472543003E-22 ) ;
  }

  @Test
  public void test3059() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-45.55309347629758,-90.7633769075223 ) ;
  }

  @Test
  public void test3060() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,4.930380657631324E-32,1.5707963267948966 ) ;
  }

  @Test
  public void test3061() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-5.852095443365248E-98,13.900265494588341 ) ;
  }

  @Test
  public void test3062() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-7.105427357601002E-15,-9.568604581296654 ) ;
  }

  @Test
  public void test3063() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-84.6457287871368,-1.5707963267948974 ) ;
  }

  @Test
  public void test3064() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-88.333655085534,-98.14494289715208 ) ;
  }

  @Test
  public void test3065() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-88.52270255046597,-3.2665967559625715 ) ;
  }

  @Test
  public void test3066() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-8.881784197001252E-16,-44.274710681662285 ) ;
  }

  @Test
  public void test3067() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-8.881784197001252E-16,80.2303196728435 ) ;
  }

  @Test
  public void test3068() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-95.36388841982138,-58.26098764085559 ) ;
  }

  @Test
  public void test3069() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-95.43696827414487,-92.53749673249538 ) ;
  }

  @Test
  public void test3070() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948915,-1.5707963267948966,55.647601525974665 ) ;
  }

  @Test
  public void test3071() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948921,-1.5707963267948966,4.3368086899420177E-19 ) ;
  }

  @Test
  public void test3072() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948921,-1.5707963267948974,44.27815154384287 ) ;
  }

  @Test
  public void test3073() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794892,-1.5707963267659926,100.0 ) ;
  }

  @Test
  public void test3074() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794892,-1.5707963267948966,-64.71016391985751 ) ;
  }

  @Test
  public void test3075() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948923,-1.5707963267948966,16.85459514663029 ) ;
  }

  @Test
  public void test3076() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794892,-39.08990350407178,-1.5707963267948966 ) ;
  }

  @Test
  public void test3077() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794893,-0.0482175444327555,67.11804712267141 ) ;
  }

  @Test
  public void test3078() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794893,-1.5707963267948966,-37.73890870886811 ) ;
  }

  @Test
  public void test3079() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794893,-19.350469076699987,-1.5707963267948966 ) ;
  }

  @Test
  public void test3080() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948932,-45.27016839116189,-1.5707963267948966 ) ;
  }

  @Test
  public void test3081() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794893,-31.41592653589923,-44.24082062742438 ) ;
  }

  @Test
  public void test3082() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948934,-1.3384060400300424,99.07788036764794 ) ;
  }

  @Test
  public void test3083() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948934,-3.2991918056533097E-15,8.881784197001252E-16 ) ;
  }

  @Test
  public void test3084() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794893,-44.45690393770656,-83.47837312822098 ) ;
  }

  @Test
  public void test3085() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948941,-1.5707963267948966,1.1172606670742773 ) ;
  }

  @Test
  public void test3086() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948941,-2.19881106711995E-22,-65.97344572383994 ) ;
  }

  @Test
  public void test3087() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794894,-1.5707963267948966,3.3642318277009498 ) ;
  }

  @Test
  public void test3088() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948943,-1.5707963267948966,19.06204506356923 ) ;
  }

  @Test
  public void test3089() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948943,-1.5707963267948966,33.11298752636112 ) ;
  }

  @Test
  public void test3090() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948943,-1.5707963267948966,-77.43178940522266 ) ;
  }

  @Test
  public void test3091() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948946,-1.5707963267948966,44.49320236123069 ) ;
  }

  @Test
  public void test3092() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948946,-1.5707963267948966,-67.79755467957415 ) ;
  }

  @Test
  public void test3093() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948946,-1.5707963267948983,-1.5707963267949125 ) ;
  }

  @Test
  public void test3094() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948946,-2.4862716600253798E-15,1.3336819620186966 ) ;
  }

  @Test
  public void test3095() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.03217880510445249,45.60119536674375 ) ;
  }

  @Test
  public void test3096() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.045266553534504705,-74.87766254931728 ) ;
  }

  @Test
  public void test3097() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.04625959574593779,-100.0 ) ;
  }

  @Test
  public void test3098() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.09080699600206976,-0.47813163115267204 ) ;
  }

  @Test
  public void test3099() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.1531954566102639,-85.4929096246367 ) ;
  }

  @Test
  public void test3100() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.19685904269335922,1.5707963267948966 ) ;
  }

  @Test
  public void test3101() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.386346248672748,31.617593522750607 ) ;
  }

  @Test
  public void test3102() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.39129060996184917,1.5707963267948948 ) ;
  }

  @Test
  public void test3103() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.4371259676456888,1.5707963267948966 ) ;
  }

  @Test
  public void test3104() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.6034075607659222,68.46413148694182 ) ;
  }

  @Test
  public void test3105() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.770681167053933,-7.112827998352248E-161 ) ;
  }

  @Test
  public void test3106() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.8400763718418691,19.545393869527917 ) ;
  }

  @Test
  public void test3107() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.9038760179086379,1.4998614259697818 ) ;
  }

  @Test
  public void test3108() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-101.65724422692705,-1.5707963267948963 ) ;
  }

  @Test
  public void test3109() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-101.86171158272604,-59.791891918835056 ) ;
  }

  @Test
  public void test3110() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.161200623483657,10.81097197853892 ) ;
  }

  @Test
  public void test3111() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.2185029129390101,-59.613547053583744 ) ;
  }

  @Test
  public void test3112() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.218678434824875,-73.29317661098409 ) ;
  }

  @Test
  public void test3113() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.358497648246854,30.744053961538523 ) ;
  }

  @Test
  public void test3114() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.4092460003616398,-44.873305092302836 ) ;
  }

  @Test
  public void test3115() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-141.16127369934597,-66.36445812000004 ) ;
  }

  @Test
  public void test3116() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.4412291713940877,-36.58499399865893 ) ;
  }

  @Test
  public void test3117() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5469683900927553,-62.17237987901372 ) ;
  }

  @Test
  public void test3118() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5675207590567712,69.2910023310781 ) ;
  }

  @Test
  public void test3119() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948202,-46.46875116104512 ) ;
  }

  @Test
  public void test3120() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.570796326794861,-7.669866678262964E-11 ) ;
  }

  @Test
  public void test3121() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948852,61.82542242434883 ) ;
  }

  @Test
  public void test3122() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948912,71.31334322838171 ) ;
  }

  @Test
  public void test3123() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948912,89.87889588176253 ) ;
  }

  @Test
  public void test3124() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.570796326794893,45.25881074416852 ) ;
  }

  @Test
  public void test3125() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948957,2.4382025171814905E-16 ) ;
  }

  @Test
  public void test3126() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948957,3.1415926535897936 ) ;
  }

  @Test
  public void test3127() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948957,-72.6003435897874 ) ;
  }

  @Test
  public void test3128() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948957,72.7601459119021 ) ;
  }

  @Test
  public void test3129() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948961,0.43222971745898775 ) ;
  }

  @Test
  public void test3130() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948961,58.79115782053517 ) ;
  }

  @Test
  public void test3131() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,0.21308090967191617 ) ;
  }

  @Test
  public void test3132() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,-0.38067403951356443 ) ;
  }

  @Test
  public void test3133() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,0.7768201578552929 ) ;
  }

  @Test
  public void test3134() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,0.8932521794574819 ) ;
  }

  @Test
  public void test3135() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,0.9888094151345286 ) ;
  }

  @Test
  public void test3136() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test3137() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,13.478086660583294 ) ;
  }

  @Test
  public void test3138() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,-13.76086400832308 ) ;
  }

  @Test
  public void test3139() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,13.861629586968705 ) ;
  }

  @Test
  public void test3140() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,1.497233171221034 ) ;
  }

  @Test
  public void test3141() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3142() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3143() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,-1.5707963267948983 ) ;
  }

  @Test
  public void test3144() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,-19.302798614296137 ) ;
  }

  @Test
  public void test3145() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,28.061489906957945 ) ;
  }

  @Test
  public void test3146() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,-32.42307834471255 ) ;
  }

  @Test
  public void test3147() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,35.24230490507989 ) ;
  }

  @Test
  public void test3148() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,-37.699355351924595 ) ;
  }

  @Test
  public void test3149() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,40.74724660665055 ) ;
  }

  @Test
  public void test3150() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,58.05796977441162 ) ;
  }

  @Test
  public void test3151() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,-59.57265929611408 ) ;
  }

  @Test
  public void test3152() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,-6.156803255711367 ) ;
  }

  @Test
  public void test3153() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,70.20431031208203 ) ;
  }

  @Test
  public void test3154() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,94.28953897698247 ) ;
  }

  @Test
  public void test3155() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test3156() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948983,129.7287399215856 ) ;
  }

  @Test
  public void test3157() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948983,-2359.35542561314 ) ;
  }

  @Test
  public void test3158() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948983,-27.039658852839842 ) ;
  }

  @Test
  public void test3159() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948983,422.39148601387717 ) ;
  }

  @Test
  public void test3160() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-31.661897735611447,-28.6500781195829 ) ;
  }

  @Test
  public void test3161() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-31.759251222997452,-1.5707963267948917 ) ;
  }

  @Test
  public void test3162() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-32.48724953747491,-4.331901131473452 ) ;
  }

  @Test
  public void test3163() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-32.579549982253276,-66.47010225067514 ) ;
  }

  @Test
  public void test3164() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-32.646427556105095,-3.1415926535900582 ) ;
  }

  @Test
  public void test3165() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-32.71069310339435,-45.209252054888616 ) ;
  }

  @Test
  public void test3166() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-32.96329933770133,-57.51698364124535 ) ;
  }

  @Test
  public void test3167() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,3.469446951953614E-18,-6.12699440681169 ) ;
  }

  @Test
  public void test3168() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-39.07294649306536,-9.247579929081013 ) ;
  }

  @Test
  public void test3169() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,4.368824226788374E-17,12.723947602101383 ) ;
  }

  @Test
  public void test3170() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-44.37641849807085,-1.5707963267948966 ) ;
  }

  @Test
  public void test3171() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-45.508266213660086,-341.3628029143474 ) ;
  }

  @Test
  public void test3172() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-5.551115123125783E-17,-1.5707963267948966 ) ;
  }

  @Test
  public void test3173() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,6.938893903907228E-18,-74.69862352197114 ) ;
  }

  @Test
  public void test3174() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-84.52800407279699,-88.22420366932789 ) ;
  }

  @Test
  public void test3175() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-8.881784197001252E-16,-91.26639255688562 ) ;
  }

  @Test
  public void test3176() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-9.333163420998241E-4,0.0 ) ;
  }

  @Test
  public void test3177() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-95.47243010849613,-59.381897674326126 ) ;
  }

  @Test
  public void test3178() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-95.60588682106011,-3.2665927928368332 ) ;
  }

  @Test
  public void test3179() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794895,-1.3326778949375122,4.71434521824827 ) ;
  }

  @Test
  public void test3180() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794895,-1.5707963267948912,-21.257873073783756 ) ;
  }

  @Test
  public void test3181() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794895,-1.5707963267948966,-95.56549218891308 ) ;
  }

  @Test
  public void test3182() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948952,-1.4442721998243344,-90.14553877309228 ) ;
  }

  @Test
  public void test3183() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948952,-1.5707963267948966,-88.41890056994 ) ;
  }

  @Test
  public void test3184() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948952,-8.881784197001252E-16,2.465190328815662E-32 ) ;
  }

  @Test
  public void test3185() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794895,-4.081252294111857E-8,-15.707841099762387 ) ;
  }

  @Test
  public void test3186() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948954,-1.4349424670448647,-1.1265414462383287E-4 ) ;
  }

  @Test
  public void test3187() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948954,-1.559424069468342,-20.143578542684033 ) ;
  }

  @Test
  public void test3188() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948954,-1.5707963267948966,53.75236692695484 ) ;
  }

  @Test
  public void test3189() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-0.03654465312346658,59.17942801289749 ) ;
  }

  @Test
  public void test3190() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-0.0760282411520534,82.67476021673164 ) ;
  }

  @Test
  public void test3191() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-0.2481150520774203,-83.86532258373403 ) ;
  }

  @Test
  public void test3192() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-0.5677545440458043,59.21962052012801 ) ;
  }

  @Test
  public void test3193() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-0.664787902382519,-1.5707963267948983 ) ;
  }

  @Test
  public void test3194() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-0.6852735525232401,65.74443022240409 ) ;
  }

  @Test
  public void test3195() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-0.8654205911710859,-86.9997290528078 ) ;
  }

  @Test
  public void test3196() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-0.9792509029940154,63.426437609831 ) ;
  }

  @Test
  public void test3197() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.1879251688304262,1.5725000423368118 ) ;
  }

  @Test
  public void test3198() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.1895907686830537E-116,63.0801962034688 ) ;
  }

  @Test
  public void test3199() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.219777324942346,-62.30069494442041 ) ;
  }

  @Test
  public void test3200() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.4532365945505064,57.434533897644826 ) ;
  }

  @Test
  public void test3201() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.4974381028308499,-30.76030516945218 ) ;
  }

  @Test
  public void test3202() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5115969393276294,2.1175823681357508E-22 ) ;
  }

  @Test
  public void test3203() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5678300454659597,-36.7004810798407 ) ;
  }

  @Test
  public void test3204() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5682450136552648,68.09389581226108 ) ;
  }

  @Test
  public void test3205() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963267948912,1.5707963267948966 ) ;
  }

  @Test
  public void test3206() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963267948963,-10.739358332209276 ) ;
  }

  @Test
  public void test3207() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963267948963,19.782017253574423 ) ;
  }

  @Test
  public void test3208() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963267948966,-0.24054360669248753 ) ;
  }

  @Test
  public void test3209() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3210() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963267948966,3.2665926552096596 ) ;
  }

  @Test
  public void test3211() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963267948966,-79.75003270626718 ) ;
  }

  @Test
  public void test3212() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963267948966,8.066127137224717 ) ;
  }

  @Test
  public void test3213() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963267948966,95.89513403637827 ) ;
  }

  @Test
  public void test3214() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,2.220446049250313E-16,-57.24973160775323 ) ;
  }

  @Test
  public void test3215() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-2556.852147643713,0 ) ;
  }

  @Test
  public void test3216() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-44.202343375036804,-14.232921439311724 ) ;
  }

  @Test
  public void test3217() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-44.33563902369491,-3.1415926535897953 ) ;
  }

  @Test
  public void test3218() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-47.809859495751816,0 ) ;
  }

  @Test
  public void test3219() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-94.32570170055152,-88.24642448956736 ) ;
  }

  @Test
  public void test3220() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-95.59286302716785,-71.8891104223123 ) ;
  }

  @Test
  public void test3221() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794896,-0.03517236540429004,1.5707963267948948 ) ;
  }

  @Test
  public void test3222() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-0.10958525470682293,4.712396609779226 ) ;
  }

  @Test
  public void test3223() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-0.15729244648389112,-75.39824914845855 ) ;
  }

  @Test
  public void test3224() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-0.16422765174359766,-1.5707963267948966 ) ;
  }

  @Test
  public void test3225() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-0.19706910081525547,79.22735186149843 ) ;
  }

  @Test
  public void test3226() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-0.5220307360313363,1.5707963267948966 ) ;
  }

  @Test
  public void test3227() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-0.5398560664049498,-77.57792203603151 ) ;
  }

  @Test
  public void test3228() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-0.9027990489228073,96.9614836019139 ) ;
  }

  @Test
  public void test3229() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.043598721352418,-1.5707963267948974 ) ;
  }

  @Test
  public void test3230() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.0471975511965979,-10.954329458197208 ) ;
  }

  @Test
  public void test3231() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.1484635523251057,-6.7123889984672855 ) ;
  }

  @Test
  public void test3232() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.255995195226793,6.7123891013798 ) ;
  }

  @Test
  public void test3233() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.4149100194633237,1.1158498517551546E-16 ) ;
  }

  @Test
  public void test3234() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948948,-53.63764712452215 ) ;
  }

  @Test
  public void test3235() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948954,0.0 ) ;
  }

  @Test
  public void test3236() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3237() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test3238() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,-23.565025606823006 ) ;
  }

  @Test
  public void test3239() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,-31.807031879379988 ) ;
  }

  @Test
  public void test3240() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,-4.064307413145931 ) ;
  }

  @Test
  public void test3241() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,42.85074272042421 ) ;
  }

  @Test
  public void test3242() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,4.440892098500626E-16 ) ;
  }

  @Test
  public void test3243() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,52.53889868097392 ) ;
  }

  @Test
  public void test3244() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,5.421010862427522E-20 ) ;
  }

  @Test
  public void test3245() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,-68.44447166300311 ) ;
  }

  @Test
  public void test3246() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,77.35153588880658 ) ;
  }

  @Test
  public void test3247() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,-90.69564503598707 ) ;
  }

  @Test
  public void test3248() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,2.4414935945462033,-84.86547454199167 ) ;
  }

  @Test
  public void test3249() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-2545.8839577441904,0 ) ;
  }

  @Test
  public void test3250() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-3.1415926535917325,11.615106584033114 ) ;
  }

  @Test
  public void test3251() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-31.688019376487322,-66.68808478105012 ) ;
  }

  @Test
  public void test3252() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,3.469446951953614E-18,100.0 ) ;
  }

  @Test
  public void test3253() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794896,-1.5705906606714777,32.431870369115785 ) ;
  }

  @Test
  public void test3254() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794896,-1.570796164985976,-25.136963521794332 ) ;
  }

  @Test
  public void test3255() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794896,-1.5707963267948966,-0.7833893730184677 ) ;
  }

  @Test
  public void test3256() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794896,-1.5707963267948966,-1.9721522630525295E-31 ) ;
  }

  @Test
  public void test3257() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794896,-1.5707963267948966,-31.50546764438829 ) ;
  }

  @Test
  public void test3258() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794896,-1.5707963267948966,76.99152537396279 ) ;
  }

  @Test
  public void test3259() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-6.162975822039155E-33,-3.1415926535898184 ) ;
  }

  @Test
  public void test3260() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-8.881784197001252E-16,-1.5186056557492271 ) ;
  }

  @Test
  public void test3261() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.013545809684933222,-73.97458040521228 ) ;
  }

  @Test
  public void test3262() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.015267216566587607,-38.500164446182396 ) ;
  }

  @Test
  public void test3263() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.07056138880735141,120.07823990351127 ) ;
  }

  @Test
  public void test3264() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.10272793832589523,-94.29722322329066 ) ;
  }

  @Test
  public void test3265() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.21990942814707726,65.17564726429909 ) ;
  }

  @Test
  public void test3266() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.3172842668804068,57.57062970972916 ) ;
  }

  @Test
  public void test3267() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.3202234428828587,64.80912427031443 ) ;
  }

  @Test
  public void test3268() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.3384706332620939,-94.22350385089848 ) ;
  }

  @Test
  public void test3269() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,0.3788316872436205,-1.2528840288358233E-4 ) ;
  }

  @Test
  public void test3270() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.4852273633482545,0.0 ) ;
  }

  @Test
  public void test3271() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.6411591721301528,-4.712450017552401 ) ;
  }

  @Test
  public void test3272() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.6551498908721132,45.06584743477049 ) ;
  }

  @Test
  public void test3273() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.8991673214058129,-100.0 ) ;
  }

  @Test
  public void test3274() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.9564401534477946,-45.54982674226591 ) ;
  }

  @Test
  public void test3275() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.9665642566416146,-44.21161800629364 ) ;
  }

  @Test
  public void test3276() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.0900261284811277,3.9691620782147172 ) ;
  }

  @Test
  public void test3277() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.1102230246251565E-16,-6.257566825826651 ) ;
  }

  @Test
  public void test3278() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.1187218883040275,1.5707963267948963 ) ;
  }

  @Test
  public void test3279() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.2021893326057986,92.38074561078909 ) ;
  }

  @Test
  public void test3280() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.2110306111818667,3.141592665356912 ) ;
  }

  @Test
  public void test3281() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.2241259041550534,-61.76734143825031 ) ;
  }

  @Test
  public void test3282() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.2553083514181136,-3.1415926535897936 ) ;
  }

  @Test
  public void test3283() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.4659062662203572,53.40707561326492 ) ;
  }

  @Test
  public void test3284() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.528097263405913,95.30836573761101 ) ;
  }

  @Test
  public void test3285() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5429733159145516,-0.5660978806429884 ) ;
  }

  @Test
  public void test3286() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.548512820103579,3.141592653589793 ) ;
  }

  @Test
  public void test3287() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5682995423709842,-1.5707963267949125 ) ;
  }

  @Test
  public void test3288() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.570796326321619,68.34272954816649 ) ;
  }

  @Test
  public void test3289() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963265968712,-97.81015295268692 ) ;
  }

  @Test
  public void test3290() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963266920226,62.82717092070807 ) ;
  }

  @Test
  public void test3291() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.570796326794886,0.0 ) ;
  }

  @Test
  public void test3292() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.570796326794895,-6.712404326739244 ) ;
  }

  @Test
  public void test3293() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948957,0.9709266863471655 ) ;
  }

  @Test
  public void test3294() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.570796326794896,-3.1418084712892176 ) ;
  }

  @Test
  public void test3295() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3296() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,0.02180396501748289 ) ;
  }

  @Test
  public void test3297() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,-0.6648769949141098 ) ;
  }

  @Test
  public void test3298() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,0.7920687880975525 ) ;
  }

  @Test
  public void test3299() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test3300() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3301() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test3302() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,-16.270658045309617 ) ;
  }

  @Test
  public void test3303() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,-22.98500455504066 ) ;
  }

  @Test
  public void test3304() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,2336.7858845229607 ) ;
  }

  @Test
  public void test3305() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,27.33739296556547 ) ;
  }

  @Test
  public void test3306() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,3.2665926546094957 ) ;
  }

  @Test
  public void test3307() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,37.79138488055184 ) ;
  }

  @Test
  public void test3308() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,41.45937174881764 ) ;
  }

  @Test
  public void test3309() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,43.06287590072544 ) ;
  }

  @Test
  public void test3310() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,-43.98229715025597 ) ;
  }

  @Test
  public void test3311() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,-45.21354031991957 ) ;
  }

  @Test
  public void test3312() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,-65.35579160599865 ) ;
  }

  @Test
  public void test3313() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,66.2799920986982 ) ;
  }

  @Test
  public void test3314() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,-9.264297772044827 ) ;
  }

  @Test
  public void test3315() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-31.41592653697429,-78.60447697440128 ) ;
  }

  @Test
  public void test3316() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-3.1415926544506263,-86.41669091612331 ) ;
  }

  @Test
  public void test3317() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-3.141592654874249,1.5707963267948966 ) ;
  }

  @Test
  public void test3318() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-3.1415926713266176,-34.24342041713163 ) ;
  }

  @Test
  public void test3319() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-31.884002171333453,-12.578853719771146 ) ;
  }

  @Test
  public void test3320() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-37.872487600329826,-1.570796326794897 ) ;
  }

  @Test
  public void test3321() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,3.8133463830625423,89.01550360576749 ) ;
  }

  @Test
  public void test3322() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-38.83214677475804,-21.43402205676425 ) ;
  }

  @Test
  public void test3323() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-39.11684400777979,-1.5707963267948966 ) ;
  }

  @Test
  public void test3324() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-44.04479715707067,-97.37127870081035 ) ;
  }

  @Test
  public void test3325() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-44.51797810158727,-1.571040467928498 ) ;
  }

  @Test
  public void test3326() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-45.1351800871806,-72.52780194311845 ) ;
  }

  @Test
  public void test3327() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794896,-38.847128516223684,-1.5707963267948966 ) ;
  }

  @Test
  public void test3328() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-94.24777960769379,-1.5707963267948966 ) ;
  }

  @Test
  public void test3329() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-95.81854957301941,-106.82618528605592 ) ;
  }

  @Test
  public void test3330() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794896,-45.545765392903405,-73.43568271765294 ) ;
  }

  @Test
  public void test3331() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test3332() {
    coral.tests.JPFBenchmark.benchmark06(-1.5713965066590702E-4,-1.0471975511965113,1.5707963267948977 ) ;
  }

  @Test
  public void test3333() {
    coral.tests.JPFBenchmark.benchmark06(15.732977512568482,62.465855036000306,55.97797964858515 ) ;
  }

  @Test
  public void test3334() {
    coral.tests.JPFBenchmark.benchmark06(1.5777218104420236E-30,-1.5707963267948966,12.032778578538398 ) ;
  }

  @Test
  public void test3335() {
    coral.tests.JPFBenchmark.benchmark06(1.5777218104420236E-30,-88.39741980776107,-2.1147724681240536 ) ;
  }

  @Test
  public void test3336() {
    coral.tests.JPFBenchmark.benchmark06(15.826473339440867,28.899273675315214,57.53860954846857 ) ;
  }

  @Test
  public void test3337() {
    coral.tests.JPFBenchmark.benchmark06(-1.5920457948720638E-15,-45.259287167969894,-1.5707963267949638 ) ;
  }

  @Test
  public void test3338() {
    coral.tests.JPFBenchmark.benchmark06(-1.6003269602098647E-17,-1.5707963267948966,97.1688911106893 ) ;
  }

  @Test
  public void test3339() {
    coral.tests.JPFBenchmark.benchmark06(-1.6016664761464807E-145,-0.13578992076519775,-30.065283974392905 ) ;
  }

  @Test
  public void test3340() {
    coral.tests.JPFBenchmark.benchmark06(-1.6016664761464807E-145,-0.8153446750060694,48.499512355319524 ) ;
  }

  @Test
  public void test3341() {
    coral.tests.JPFBenchmark.benchmark06(-1.6016664761464807E-145,-1.5707963267948966,15.665592900747107 ) ;
  }

  @Test
  public void test3342() {
    coral.tests.JPFBenchmark.benchmark06(-1.6100502169960983E-15,-1.5707963267948966,-46.69959863447994 ) ;
  }

  @Test
  public void test3343() {
    coral.tests.JPFBenchmark.benchmark06(-1.6309907817798778E-5,-95.59325087410068,-57.53239081153356 ) ;
  }

  @Test
  public void test3344() {
    coral.tests.JPFBenchmark.benchmark06(-1.6395142927658816E-14,-1.5707963267948966,1.5820835152080452 ) ;
  }

  @Test
  public void test3345() {
    coral.tests.JPFBenchmark.benchmark06(16.406994591155538,89.86088533254343,-30.56672066993265 ) ;
  }

  @Test
  public void test3346() {
    coral.tests.JPFBenchmark.benchmark06(1.6543612251060553E-24,-0.15661185135312583,-0.021410704371034428 ) ;
  }

  @Test
  public void test3347() {
    coral.tests.JPFBenchmark.benchmark06(1.6543612251060553E-24,-45.3105353466958,-66.9815016595629 ) ;
  }

  @Test
  public void test3348() {
    coral.tests.JPFBenchmark.benchmark06(-1.6619789639090863E-14,-1.5707963267948912,-1.5707963267948966 ) ;
  }

  @Test
  public void test3349() {
    coral.tests.JPFBenchmark.benchmark06(-1.6663978154273495E-19,-5.551115123125783E-17,0.0 ) ;
  }

  @Test
  public void test3350() {
    coral.tests.JPFBenchmark.benchmark06(-1.6741151709400784E-12,-1.5707963267948957,84.82294143444592 ) ;
  }

  @Test
  public void test3351() {
    coral.tests.JPFBenchmark.benchmark06(16.793669300725497,-49.8116653453474,84.2983438871785 ) ;
  }

  @Test
  public void test3352() {
    coral.tests.JPFBenchmark.benchmark06(-1.6848462336911694E-11,-1.5392744415829784,96.68383857852264 ) ;
  }

  @Test
  public void test3353() {
    coral.tests.JPFBenchmark.benchmark06(-1.688508503057271E-226,-1.5707963267948966,1.03696995597573 ) ;
  }

  @Test
  public void test3354() {
    coral.tests.JPFBenchmark.benchmark06(-1.6940658945086007E-21,-1.5707963267948966,-14.137166696460827 ) ;
  }

  @Test
  public void test3355() {
    coral.tests.JPFBenchmark.benchmark06(1.6940658945086007E-21,-1.5707963267948966,-58.49349553141874 ) ;
  }

  @Test
  public void test3356() {
    coral.tests.JPFBenchmark.benchmark06(17.02419039043906,-0.8780759317291,-82.74817448835967 ) ;
  }

  @Test
  public void test3357() {
    coral.tests.JPFBenchmark.benchmark06(-17.070482260138874,-45.69388135103307,-18.32407579257466 ) ;
  }

  @Test
  public void test3358() {
    coral.tests.JPFBenchmark.benchmark06(-1.7194745403486138,38.94870507789409,4.146409453916689 ) ;
  }

  @Test
  public void test3359() {
    coral.tests.JPFBenchmark.benchmark06(-1.7319133573203266E-17,-1.5707963267948966,97.3893722612836 ) ;
  }

  @Test
  public void test3360() {
    coral.tests.JPFBenchmark.benchmark06(1.734723475976807E-18,-0.22200560901425476,-64.2126051278723 ) ;
  }

  @Test
  public void test3361() {
    coral.tests.JPFBenchmark.benchmark06(1.734723475976807E-18,-0.5573323451752639,88.20307016879715 ) ;
  }

  @Test
  public void test3362() {
    coral.tests.JPFBenchmark.benchmark06(1.734723475976807E-18,-1.5707963267948912,-53.65212942020532 ) ;
  }

  @Test
  public void test3363() {
    coral.tests.JPFBenchmark.benchmark06(1.734723475976807E-18,-1.5707963267948966,0.3632594245099653 ) ;
  }

  @Test
  public void test3364() {
    coral.tests.JPFBenchmark.benchmark06(1.734723475976807E-18,-1.5707963267948966,16.124880257939967 ) ;
  }

  @Test
  public void test3365() {
    coral.tests.JPFBenchmark.benchmark06(-1.7365302730352168E-164,-1.066536969533317,1.135972634209328 ) ;
  }

  @Test
  public void test3366() {
    coral.tests.JPFBenchmark.benchmark06(-1.7365302730352168E-164,-31.513481849989347,-1.5707963267948966 ) ;
  }

  @Test
  public void test3367() {
    coral.tests.JPFBenchmark.benchmark06(-1.752168966508581E-13,-1.5707963267948966,-1.5707963267948974 ) ;
  }

  @Test
  public void test3368() {
    coral.tests.JPFBenchmark.benchmark06(-17.56853491468779,70.24150443196572,-75.79231200794669 ) ;
  }

  @Test
  public void test3369() {
    coral.tests.JPFBenchmark.benchmark06(17.750871339581224,97.18099912776748,-91.35135748590008 ) ;
  }

  @Test
  public void test3370() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-0.8820595254804706,0.10220066167839148 ) ;
  }

  @Test
  public void test3371() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-0.9068985662305251,-37.21445146526499 ) ;
  }

  @Test
  public void test3372() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-1.3071010190050774,0.8148309093180899 ) ;
  }

  @Test
  public void test3373() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-1.4218638833915382,55.91445152459529 ) ;
  }

  @Test
  public void test3374() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-1.570796322176063,-1.5707963267948966 ) ;
  }

  @Test
  public void test3375() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-1.5707963267948912,-53.71189592872756 ) ;
  }

  @Test
  public void test3376() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-1.5707963267948948,-22.330439454437993 ) ;
  }

  @Test
  public void test3377() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-1.5707963267948966,-44.40958588959598 ) ;
  }

  @Test
  public void test3378() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-43.982297150257104,-35.80515408257432 ) ;
  }

  @Test
  public void test3379() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-95.75641932894843,-33.94137257665935 ) ;
  }

  @Test
  public void test3380() {
    coral.tests.JPFBenchmark.benchmark06(-1.8033161362862765E-130,-1.5331833273662858,-99.87381713411943 ) ;
  }

  @Test
  public void test3381() {
    coral.tests.JPFBenchmark.benchmark06(-1.8248569297688955E-4,-32.98616980196681,-122.89114769419173 ) ;
  }

  @Test
  public void test3382() {
    coral.tests.JPFBenchmark.benchmark06(18.273316021528757,24.152433127212845,-75.69930611144748 ) ;
  }

  @Test
  public void test3383() {
    coral.tests.JPFBenchmark.benchmark06(-1.8316289367208397E-13,-1.5707963267948966,-12.584955251512824 ) ;
  }

  @Test
  public void test3384() {
    coral.tests.JPFBenchmark.benchmark06(-18.329693301588804,0,0 ) ;
  }

  @Test
  public void test3385() {
    coral.tests.JPFBenchmark.benchmark06(-1.8465957235571472E-127,-1.5707963267948966,-63.21087595216593 ) ;
  }

  @Test
  public void test3386() {
    coral.tests.JPFBenchmark.benchmark06(-1.88079096131566E-37,-1.0926749976537011,71.97900146060911 ) ;
  }

  @Test
  public void test3387() {
    coral.tests.JPFBenchmark.benchmark06(-1.8850255559046966E-7,-1.5707513877739006,59.686277322787866 ) ;
  }

  @Test
  public void test3388() {
    coral.tests.JPFBenchmark.benchmark06(-19.160370072934768,-63.249640727494594,25.64246394839371 ) ;
  }

  @Test
  public void test3389() {
    coral.tests.JPFBenchmark.benchmark06(19.19901182752129,-79.99215631265758,40.89718277608998 ) ;
  }

  @Test
  public void test3390() {
    coral.tests.JPFBenchmark.benchmark06(-19.203878473164025,26.30494104244687,93.94267223019969 ) ;
  }

  @Test
  public void test3391() {
    coral.tests.JPFBenchmark.benchmark06(-1.93973044288078E-15,-0.10735247657063385,-20.20949443581435 ) ;
  }

  @Test
  public void test3392() {
    coral.tests.JPFBenchmark.benchmark06(19.421608327586128,-63.52214511666008,-96.71268169524868 ) ;
  }

  @Test
  public void test3393() {
    coral.tests.JPFBenchmark.benchmark06(-1.9567784623591962,45.102699384462596,-54.68486195035578 ) ;
  }

  @Test
  public void test3394() {
    coral.tests.JPFBenchmark.benchmark06(-1.9619304689009836E-6,-1.570793585707539,20.362896948919623 ) ;
  }

  @Test
  public void test3395() {
    coral.tests.JPFBenchmark.benchmark06(1.9692005861649875,-66.76149118436301,13.44492014885094 ) ;
  }

  @Test
  public void test3396() {
    coral.tests.JPFBenchmark.benchmark06(-1.9693445495728124E-13,-1.5707963267948966,-37.684625465733056 ) ;
  }

  @Test
  public void test3397() {
    coral.tests.JPFBenchmark.benchmark06(1.9721522630525295E-31,-0.7309335035397936,38.80536444343258 ) ;
  }

  @Test
  public void test3398() {
    coral.tests.JPFBenchmark.benchmark06(-1.9721522630525295E-31,-1.1961494176112728,3.1415926535922356 ) ;
  }

  @Test
  public void test3399() {
    coral.tests.JPFBenchmark.benchmark06(1.9721522630525295E-31,-1.5707963267948912,-76.50600263012916 ) ;
  }

  @Test
  public void test3400() {
    coral.tests.JPFBenchmark.benchmark06(1.9721522630525295E-31,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3401() {
    coral.tests.JPFBenchmark.benchmark06(1.9721522630525295E-31,-4.446949288202601E-15,1.0477758733795768 ) ;
  }

  @Test
  public void test3402() {
    coral.tests.JPFBenchmark.benchmark06(-1.9724868051125204E-15,-1.5707963267948966,-32.587179676265194 ) ;
  }

  @Test
  public void test3403() {
    coral.tests.JPFBenchmark.benchmark06(-2.002083095183101E-146,-1.5707963267948966,-14.914717182314064 ) ;
  }

  @Test
  public void test3404() {
    coral.tests.JPFBenchmark.benchmark06(-2.0303534698525194E-115,-1.3332525154832444,-79.14885771504937 ) ;
  }

  @Test
  public void test3405() {
    coral.tests.JPFBenchmark.benchmark06(-2.0909036408050545E-4,-1.5707963267948966,62.02528342094995 ) ;
  }

  @Test
  public void test3406() {
    coral.tests.JPFBenchmark.benchmark06(-20.995683901378584,59.193777689827755,-35.351104914676526 ) ;
  }

  @Test
  public void test3407() {
    coral.tests.JPFBenchmark.benchmark06(-21.073406985660753,37.81750838145081,-64.90481562129484 ) ;
  }

  @Test
  public void test3408() {
    coral.tests.JPFBenchmark.benchmark06(21.086869008927664,25.35339433678662,-52.35780292536391 ) ;
  }

  @Test
  public void test3409() {
    coral.tests.JPFBenchmark.benchmark06(2.1175823681357508E-22,-1.5682705720978078,37.580863056008134 ) ;
  }

  @Test
  public void test3410() {
    coral.tests.JPFBenchmark.benchmark06(21.436580707547776,53.96809212703195,33.69305313305935 ) ;
  }

  @Test
  public void test3411() {
    coral.tests.JPFBenchmark.benchmark06(-2.1521659615663458E-13,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3412() {
    coral.tests.JPFBenchmark.benchmark06(21.53414641476455,-0.5507888974537423,-55.843139306284215 ) ;
  }

  @Test
  public void test3413() {
    coral.tests.JPFBenchmark.benchmark06(-2.1684043449710089E-19,-1.570791806473929,-3.141592653589794 ) ;
  }

  @Test
  public void test3414() {
    coral.tests.JPFBenchmark.benchmark06(-2.1684043449710089E-19,-1.5707963267948966,-3.141156693067385 ) ;
  }

  @Test
  public void test3415() {
    coral.tests.JPFBenchmark.benchmark06(-2.1684043449710089E-19,-1.5707963267948966,97.38934413731201 ) ;
  }

  @Test
  public void test3416() {
    coral.tests.JPFBenchmark.benchmark06(2.1684043449710089E-19,-2.220446049250313E-16,-10.794926798273407 ) ;
  }

  @Test
  public void test3417() {
    coral.tests.JPFBenchmark.benchmark06(21.751757976260365,26.728485388275928,79.41714730791088 ) ;
  }

  @Test
  public void test3418() {
    coral.tests.JPFBenchmark.benchmark06(2.1793895560379264E-4,-1.5712837953328689,100.87451064549626 ) ;
  }

  @Test
  public void test3419() {
    coral.tests.JPFBenchmark.benchmark06(-2.2013136429275836E-134,-1.5707963267948957,100.0 ) ;
  }

  @Test
  public void test3420() {
    coral.tests.JPFBenchmark.benchmark06(-2.2013136429275836E-134,-88.36406451567949,-1.5707963267948926 ) ;
  }

  @Test
  public void test3421() {
    coral.tests.JPFBenchmark.benchmark06(-2.2131618651272261E-221,-1.5707963267948966,-0.3283298599960318 ) ;
  }

  @Test
  public void test3422() {
    coral.tests.JPFBenchmark.benchmark06(-2.220237747807377E-16,-1.5707963267948966,-28.274333882285934 ) ;
  }

  @Test
  public void test3423() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-0.003495099453884154,6.712388983688715 ) ;
  }

  @Test
  public void test3424() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-0.006812308962665187,-16.735216040663243 ) ;
  }

  @Test
  public void test3425() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-0.09785013202366308,-9.835720458127165 ) ;
  }

  @Test
  public void test3426() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-0.09831605340999872,-1.5707963267948977 ) ;
  }

  @Test
  public void test3427() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-0.1715884003712782,1.5707963267948983 ) ;
  }

  @Test
  public void test3428() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-0.25066929572503516,81.3712502657731 ) ;
  }

  @Test
  public void test3429() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-0.8516173733014802,49.23450316791246 ) ;
  }

  @Test
  public void test3430() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-0.9475097934744643,-42.25056646198553 ) ;
  }

  @Test
  public void test3431() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-1.1410989896942425,-23.97454698233012 ) ;
  }

  @Test
  public void test3432() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-1.5654511236585893,0.0 ) ;
  }

  @Test
  public void test3433() {
    coral.tests.JPFBenchmark.benchmark06(2.220446049250313E-16,-1.5677469837558127,124.07971163938024 ) ;
  }

  @Test
  public void test3434() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-1.5707963267948912,192.83465074114008 ) ;
  }

  @Test
  public void test3435() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-1.5707963267948961,-1.5547034193156928 ) ;
  }

  @Test
  public void test3436() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-1.5707963267948963,-31.76922174676003 ) ;
  }

  @Test
  public void test3437() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-1.5707963267948966,-1.3552527156068805E-20 ) ;
  }

  @Test
  public void test3438() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3439() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-1.5707963267948966,-64.84176074961205 ) ;
  }

  @Test
  public void test3440() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-1.5707963267948966,-88.44948689778931 ) ;
  }

  @Test
  public void test3441() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-3.141592660210338,102.0032129069549 ) ;
  }

  @Test
  public void test3442() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-32.87394086993479,17.279248544643053 ) ;
  }

  @Test
  public void test3443() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-45.4949980052451,-2408.4257448049134 ) ;
  }

  @Test
  public void test3444() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,6.71238898049287,-3.180257231477278 ) ;
  }

  @Test
  public void test3445() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,6.712389064554785,-77.79164026582012 ) ;
  }

  @Test
  public void test3446() {
    coral.tests.JPFBenchmark.benchmark06(-2.2204460492612285E-16,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3447() {
    coral.tests.JPFBenchmark.benchmark06(-2.2227587494850775E-162,-1.5707963267948966,53.91233076932991 ) ;
  }

  @Test
  public void test3448() {
    coral.tests.JPFBenchmark.benchmark06(-2.2227587494850775E-162,-1.5707963267948966,-57.722323017441184 ) ;
  }

  @Test
  public void test3449() {
    coral.tests.JPFBenchmark.benchmark06(-2.223208015283913E-15,-1.509137243241779,-1.0531472771662083 ) ;
  }

  @Test
  public void test3450() {
    coral.tests.JPFBenchmark.benchmark06(-2.2234851578457128E-14,-1.5707963267948966,-3.141592679770002 ) ;
  }

  @Test
  public void test3451() {
    coral.tests.JPFBenchmark.benchmark06(-2.2411112160841333E-16,-1.5707963267948966,36.128316331350966 ) ;
  }

  @Test
  public void test3452() {
    coral.tests.JPFBenchmark.benchmark06(-2.2462165656024587E-17,-1.5707963267948966,38.949593744969036 ) ;
  }

  @Test
  public void test3453() {
    coral.tests.JPFBenchmark.benchmark06(-2.2541451703578456E-131,-1.1498419759791785,-1.5707963267948983 ) ;
  }

  @Test
  public void test3454() {
    coral.tests.JPFBenchmark.benchmark06(-2.2922197529281555E-16,-1.5707963267948966,79.24704180754863 ) ;
  }

  @Test
  public void test3455() {
    coral.tests.JPFBenchmark.benchmark06(-2.30597433839764E-16,-1.5707963267948966,-3.141592653347957 ) ;
  }

  @Test
  public void test3456() {
    coral.tests.JPFBenchmark.benchmark06(-23.30594769554631,-55.64600675491431,-16.74828383061589 ) ;
  }

  @Test
  public void test3457() {
    coral.tests.JPFBenchmark.benchmark06(2.3310346708438344E-19,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test3458() {
    coral.tests.JPFBenchmark.benchmark06(-2.3408381773460992E-97,-0.5943115975586961,19.66612740966619 ) ;
  }

  @Test
  public void test3459() {
    coral.tests.JPFBenchmark.benchmark06(23.494825750429115,60.60568108253861,-98.57552151923379 ) ;
  }

  @Test
  public void test3460() {
    coral.tests.JPFBenchmark.benchmark06(23.57031898046577,-43.73460195389056,-90.99440622474077 ) ;
  }

  @Test
  public void test3461() {
    coral.tests.JPFBenchmark.benchmark06(23.629863799998503,-67.73159960018063,-31.430060598493583 ) ;
  }

  @Test
  public void test3462() {
    coral.tests.JPFBenchmark.benchmark06(-2.387592176025933,49.45805464789396,-92.07834197572195 ) ;
  }

  @Test
  public void test3463() {
    coral.tests.JPFBenchmark.benchmark06(-2.3941714683784374E-16,-1.5707963267948966,-4.712396875894928 ) ;
  }

  @Test
  public void test3464() {
    coral.tests.JPFBenchmark.benchmark06(-23.96615443725439,84.588242035087,0.8728557384183375 ) ;
  }

  @Test
  public void test3465() {
    coral.tests.JPFBenchmark.benchmark06(23.983610450165813,63.84664779893322,-72.19306474087523 ) ;
  }

  @Test
  public void test3466() {
    coral.tests.JPFBenchmark.benchmark06(-2.3995149022330095E-240,-1.5707963267948966,43.0163012717756 ) ;
  }

  @Test
  public void test3467() {
    coral.tests.JPFBenchmark.benchmark06(-24.142681078840496,-67.99564959082878,-44.707750071635964 ) ;
  }

  @Test
  public void test3468() {
    coral.tests.JPFBenchmark.benchmark06(-2.4333972048578046E-209,-1.5707963267948966,-0.11795579022366492 ) ;
  }

  @Test
  public void test3469() {
    coral.tests.JPFBenchmark.benchmark06(-2.4333972048578046E-209,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3470() {
    coral.tests.JPFBenchmark.benchmark06(24.3849107373308,-96.75348347300252,-69.66676447986642 ) ;
  }

  @Test
  public void test3471() {
    coral.tests.JPFBenchmark.benchmark06(24.412734511900624,-16.55087898693948,22.539371412532503 ) ;
  }

  @Test
  public void test3472() {
    coral.tests.JPFBenchmark.benchmark06(-2.4439490907996837E-150,-1.5707963267948966,72.98525615928916 ) ;
  }

  @Test
  public void test3473() {
    coral.tests.JPFBenchmark.benchmark06(2.4527906936025516,-87.05360682151515,4.132566120529361 ) ;
  }

  @Test
  public void test3474() {
    coral.tests.JPFBenchmark.benchmark06(2.465190328815662E-32,-1.0406050991957614,-18.03667157156361 ) ;
  }

  @Test
  public void test3475() {
    coral.tests.JPFBenchmark.benchmark06(2.465190328815662E-32,-1.5707963267948948,20.95141350639342 ) ;
  }

  @Test
  public void test3476() {
    coral.tests.JPFBenchmark.benchmark06(2.465190328815662E-32,-1.5707963267948966,0.17610926838617624 ) ;
  }

  @Test
  public void test3477() {
    coral.tests.JPFBenchmark.benchmark06(2.465190328815662E-32,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3478() {
    coral.tests.JPFBenchmark.benchmark06(-2.465190328815662E-32,-1.5707963267948966,19.349555927119535 ) ;
  }

  @Test
  public void test3479() {
    coral.tests.JPFBenchmark.benchmark06(2.465190328815662E-32,-1.5707963267948966,27.5162769950541 ) ;
  }

  @Test
  public void test3480() {
    coral.tests.JPFBenchmark.benchmark06(2.465190328815662E-32,-1.5707963267948966,-77.10628824181605 ) ;
  }

  @Test
  public void test3481() {
    coral.tests.JPFBenchmark.benchmark06(2.465190328815662E-32,-1.5707963267948966,97.14676674576647 ) ;
  }

  @Test
  public void test3482() {
    coral.tests.JPFBenchmark.benchmark06(2.465190328815662E-32,-31.924723472716344,-66.69849005729553 ) ;
  }

  @Test
  public void test3483() {
    coral.tests.JPFBenchmark.benchmark06(2.465190328815662E-32,-7.10983349047687E-15,22.985865828718175 ) ;
  }

  @Test
  public void test3484() {
    coral.tests.JPFBenchmark.benchmark06(-2.4677579418653533E-178,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test3485() {
    coral.tests.JPFBenchmark.benchmark06(-2.481572920741452E-16,2.1684043449710089E-19,88.25989261478026 ) ;
  }

  @Test
  public void test3486() {
    coral.tests.JPFBenchmark.benchmark06(-24.85107601963034,-21.043121862509892,-44.4986637489641 ) ;
  }

  @Test
  public void test3487() {
    coral.tests.JPFBenchmark.benchmark06(-2.556516755191031,-101.86497236222863,-3.145617384181496 ) ;
  }

  @Test
  public void test3488() {
    coral.tests.JPFBenchmark.benchmark06(-2.5579179097257603E-15,-1.051514548354455,-3.226402735592412 ) ;
  }

  @Test
  public void test3489() {
    coral.tests.JPFBenchmark.benchmark06(-2.5759913618806583E-4,1.1102230246251565E-16,28.66581736147403 ) ;
  }

  @Test
  public void test3490() {
    coral.tests.JPFBenchmark.benchmark06(25.791670623193497,-73.69258196025908,52.980305972127525 ) ;
  }

  @Test
  public void test3491() {
    coral.tests.JPFBenchmark.benchmark06(26.32528754395463,-32.09845265818801,-21.36038129185833 ) ;
  }

  @Test
  public void test3492() {
    coral.tests.JPFBenchmark.benchmark06(-2635.133537282325,0,0 ) ;
  }

  @Test
  public void test3493() {
    coral.tests.JPFBenchmark.benchmark06(26.409829448317495,66.67557676179496,-74.89555501097433 ) ;
  }

  @Test
  public void test3494() {
    coral.tests.JPFBenchmark.benchmark06(26.448638154259598,-64.59631391647994,11.867919749732579 ) ;
  }

  @Test
  public void test3495() {
    coral.tests.JPFBenchmark.benchmark06(2.6469779601696886E-23,-0.6555720268103759,-39.06732852090822 ) ;
  }

  @Test
  public void test3496() {
    coral.tests.JPFBenchmark.benchmark06(-2.6589687658768453E-17,-1.5707963267948966,-46.25693671382082 ) ;
  }

  @Test
  public void test3497() {
    coral.tests.JPFBenchmark.benchmark06(-2.6615699819834813E-128,-3.8518598887744717E-34,-4.520678401242731 ) ;
  }

  @Test
  public void test3498() {
    coral.tests.JPFBenchmark.benchmark06(26.927420031556764,50.770879385873315,34.734969030948264 ) ;
  }

  @Test
  public void test3499() {
    coral.tests.JPFBenchmark.benchmark06(-2.698802673467014E-79,-88.25379341378867,-14.622798153611198 ) ;
  }

  @Test
  public void test3500() {
    coral.tests.JPFBenchmark.benchmark06(2.710505431213761E-20,-1.4918401577953366,32.19451034980358 ) ;
  }

  @Test
  public void test3501() {
    coral.tests.JPFBenchmark.benchmark06(2.710505431213761E-20,-1.5707963267948966,-52.666585573129495 ) ;
  }

  @Test
  public void test3502() {
    coral.tests.JPFBenchmark.benchmark06(-2.710505431213761E-20,-1.5707963267948966,95.81855044208636 ) ;
  }

  @Test
  public void test3503() {
    coral.tests.JPFBenchmark.benchmark06(-2.710505431213761E-20,-95.81840580612962,-21.992685621205883 ) ;
  }

  @Test
  public void test3504() {
    coral.tests.JPFBenchmark.benchmark06(-2717.5772904456767,0,0 ) ;
  }

  @Test
  public void test3505() {
    coral.tests.JPFBenchmark.benchmark06(-2.7397616862605038E-194,-1.5707963267948966,71.5427772346557 ) ;
  }

  @Test
  public void test3506() {
    coral.tests.JPFBenchmark.benchmark06(-27.591575651065043,41.772567510221506,7.319013405978197 ) ;
  }

  @Test
  public void test3507() {
    coral.tests.JPFBenchmark.benchmark06(2.7755575615628914E-17,-0.009938958314770891,-2.7748638813359037 ) ;
  }

  @Test
  public void test3508() {
    coral.tests.JPFBenchmark.benchmark06(-2.7755575615628914E-17,-0.032691038263856,14.419226084227404 ) ;
  }

  @Test
  public void test3509() {
    coral.tests.JPFBenchmark.benchmark06(-2.7755575615628914E-17,-1.3581478154477822,6.712403989195456 ) ;
  }

  @Test
  public void test3510() {
    coral.tests.JPFBenchmark.benchmark06(-2.7755575615628914E-17,-1.5707963267948966,-1.5707963267948912 ) ;
  }

  @Test
  public void test3511() {
    coral.tests.JPFBenchmark.benchmark06(2.7755575615628914E-17,-1.5707963267948966,-36.70299571417219 ) ;
  }

  @Test
  public void test3512() {
    coral.tests.JPFBenchmark.benchmark06(-2.7755575615628914E-17,-1.5707963267948966,59.68910983449072 ) ;
  }

  @Test
  public void test3513() {
    coral.tests.JPFBenchmark.benchmark06(2.7755575615628914E-17,-31.606025081026704,-98.1515885599528 ) ;
  }

  @Test
  public void test3514() {
    coral.tests.JPFBenchmark.benchmark06(-2.7755575615628914E-17,54.95821081980327,0 ) ;
  }

  @Test
  public void test3515() {
    coral.tests.JPFBenchmark.benchmark06(-2.778448436856347E-163,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3516() {
    coral.tests.JPFBenchmark.benchmark06(-2.778448436856347E-163,-1.5707963267948966,-3.141592653589793 ) ;
  }

  @Test
  public void test3517() {
    coral.tests.JPFBenchmark.benchmark06(-2.7838444215621685E-15,-1.273043202765982,-4.712389040262362 ) ;
  }

  @Test
  public void test3518() {
    coral.tests.JPFBenchmark.benchmark06(-27.87404465774128,-55.13570729953903,-72.31175006297646 ) ;
  }

  @Test
  public void test3519() {
    coral.tests.JPFBenchmark.benchmark06(-2.7904965607477417E-104,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3520() {
    coral.tests.JPFBenchmark.benchmark06(-27.976716721160216,-44.182649298951326,49.58031055788027 ) ;
  }

  @Test
  public void test3521() {
    coral.tests.JPFBenchmark.benchmark06(2.8340286918403024,7.427505509637129,25.137040903549362 ) ;
  }

  @Test
  public void test3522() {
    coral.tests.JPFBenchmark.benchmark06(-28.428180879799086,54.445733183183364,68.4751939411353 ) ;
  }

  @Test
  public void test3523() {
    coral.tests.JPFBenchmark.benchmark06(28.429149286126318,53.68365304730304,73.29875333700966 ) ;
  }

  @Test
  public void test3524() {
    coral.tests.JPFBenchmark.benchmark06(28.471381566177286,35.19455860209038,-98.90369077956629 ) ;
  }

  @Test
  public void test3525() {
    coral.tests.JPFBenchmark.benchmark06(-2.8560539139709187E-15,-1.5707963267948983,94.37527180732147 ) ;
  }

  @Test
  public void test3526() {
    coral.tests.JPFBenchmark.benchmark06(-2.863185012630134E-14,-9.016580681431383E-131,0.0 ) ;
  }

  @Test
  public void test3527() {
    coral.tests.JPFBenchmark.benchmark06(28.665444720998977,77.39536551825466,51.39670635672087 ) ;
  }

  @Test
  public void test3528() {
    coral.tests.JPFBenchmark.benchmark06(28.713999861296912,67.03096767908477,61.2314941908603 ) ;
  }

  @Test
  public void test3529() {
    coral.tests.JPFBenchmark.benchmark06(29.37228335927159,-38.948645426463166,-11.005825002209974 ) ;
  }

  @Test
  public void test3530() {
    coral.tests.JPFBenchmark.benchmark06(-2.9432912327539396E-10,-1.5707959601318893,21.99870278660822 ) ;
  }

  @Test
  public void test3531() {
    coral.tests.JPFBenchmark.benchmark06(-2.94660101347676E-10,-0.025669654033176413,77.53828867385695 ) ;
  }

  @Test
  public void test3532() {
    coral.tests.JPFBenchmark.benchmark06(29.51174952891418,78.01951303716177,35.98669747950353 ) ;
  }

  @Test
  public void test3533() {
    coral.tests.JPFBenchmark.benchmark06(-29.677458420701825,-33.73972497621165,60.10806839406442 ) ;
  }

  @Test
  public void test3534() {
    coral.tests.JPFBenchmark.benchmark06(-29.79322114232714,96.32934097798329,-98.25811835012004 ) ;
  }

  @Test
  public void test3535() {
    coral.tests.JPFBenchmark.benchmark06(29.909199757697593,21.214040477859157,-28.942782365401825 ) ;
  }

  @Test
  public void test3536() {
    coral.tests.JPFBenchmark.benchmark06(-29.93315903844838,22.610900734701048,64.84437973500084 ) ;
  }

  @Test
  public void test3537() {
    coral.tests.JPFBenchmark.benchmark06(3.006369334435547,-38.20396187655668,-20.68448652098334 ) ;
  }

  @Test
  public void test3538() {
    coral.tests.JPFBenchmark.benchmark06(-30.067037102229378,-85.8104483781045,-75.77938549015082 ) ;
  }

  @Test
  public void test3539() {
    coral.tests.JPFBenchmark.benchmark06(3.0227148821353444,0.0,0.0 ) ;
  }

  @Test
  public void test3540() {
    coral.tests.JPFBenchmark.benchmark06(31.170456472620458,23.944856466152828,-90.18109972924849 ) ;
  }

  @Test
  public void test3541() {
    coral.tests.JPFBenchmark.benchmark06(-3.130732226457525,0.45213341097951343,-77.70962436646111 ) ;
  }

  @Test
  public void test3542() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-0.22690923639197358,1.5707963267948912 ) ;
  }

  @Test
  public void test3543() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-1.117548072320464,93.8646759954544 ) ;
  }

  @Test
  public void test3544() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-1.5651639030818305,8.913174482485502 ) ;
  }

  @Test
  public void test3545() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3546() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-1.5707963267948966,-0.006458030251906123 ) ;
  }

  @Test
  public void test3547() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-1.5707963267948966,0.6712518293028739 ) ;
  }

  @Test
  public void test3548() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3549() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3550() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-1.5707963267948966,27.957423579163176 ) ;
  }

  @Test
  public void test3551() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-1.5707963267948966,39.25912742564188 ) ;
  }

  @Test
  public void test3552() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-1.5707963267948966,-41.897238157851405 ) ;
  }

  @Test
  public void test3553() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-1.5707963267948966,98.20274170437966 ) ;
  }

  @Test
  public void test3554() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-45.263678091550275,-44.19605976431936 ) ;
  }

  @Test
  public void test3555() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-45.44667996895371,-10.809597799619338 ) ;
  }

  @Test
  public void test3556() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653589794,-0.0216408054855393,-1.5707963267948948 ) ;
  }

  @Test
  public void test3557() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897944,-0.624437555935957,-1.5707963267949197 ) ;
  }

  @Test
  public void test3558() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897944,-1.5707963267948966,33.149075485130474 ) ;
  }

  @Test
  public void test3559() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897953,-0.6819208655793476,45.20709636783519 ) ;
  }

  @Test
  public void test3560() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897953,-31.86700602915841,-77.62967211124229 ) ;
  }

  @Test
  public void test3561() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653589796,-1.2999577395018371,0.0 ) ;
  }

  @Test
  public void test3562() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897962,-0.25567772138594336,1.5707963267948966 ) ;
  }

  @Test
  public void test3563() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897967,-0.22194017950693024,56.40363162321976 ) ;
  }

  @Test
  public void test3564() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897967,-1.5707963267948966,-15.05873728344286 ) ;
  }

  @Test
  public void test3565() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653589797,-2.220446049250313E-16,-88.38739204051839 ) ;
  }

  @Test
  public void test3566() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653589802,-0.2616774626036112,-1.5707963267948966 ) ;
  }

  @Test
  public void test3567() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653589803,-31.669988427629164,-2.541262012078647 ) ;
  }

  @Test
  public void test3568() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653589818,-0.39031312361008097,71.62294203562622 ) ;
  }

  @Test
  public void test3569() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653589841,-1.5155260064000575,47.56074334008841 ) ;
  }

  @Test
  public void test3570() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653589856,-32.67661163020031,-44.97280666008098 ) ;
  }

  @Test
  public void test3571() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653589965,-1.5707963267948966,36.912058525533126 ) ;
  }

  @Test
  public void test3572() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535900147,-1.1018899178098271,-63.3935972680571 ) ;
  }

  @Test
  public void test3573() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535900462,-1.4620724008492783,-100.0 ) ;
  }

  @Test
  public void test3574() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535901306,-1.5707963267948983,100.0 ) ;
  }

  @Test
  public void test3575() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535901435,-0.9180111071692929,69.61158601495492 ) ;
  }

  @Test
  public void test3576() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535901852,-1.5707963267948966,-82.89249994658606 ) ;
  }

  @Test
  public void test3577() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535972574,-1.5707963267948912,-65.0708575579542 ) ;
  }

  @Test
  public void test3578() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926536005365,-6.973469585183376E-5,-72.95679414971185 ) ;
  }

  @Test
  public void test3579() {
    coral.tests.JPFBenchmark.benchmark06(-3.14159265360611,-1.5033419583994225,-9.818085745469993 ) ;
  }

  @Test
  public void test3580() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653606186,-1.5707963267948966,94.6234067521986 ) ;
  }

  @Test
  public void test3581() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926536076326,-1.5707963267948966,-37.792767474184174 ) ;
  }

  @Test
  public void test3582() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653613364,-1.5707963267948966,-130.841539435698 ) ;
  }

  @Test
  public void test3583() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653649256,-1.5707963267948966,-1.5707963267949339 ) ;
  }

  @Test
  public void test3584() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926537721894,-32.4826872430789,-15.724315170580907 ) ;
  }

  @Test
  public void test3585() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926549289077,-45.367269262417736,-1.5707963267948966 ) ;
  }

  @Test
  public void test3586() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926556211824,-0.6058509341985368,-11.499122748840739 ) ;
  }

  @Test
  public void test3587() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592663210635,-1.1845809803041578,67.2950862266733 ) ;
  }

  @Test
  public void test3588() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415936355545555,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test3589() {
    coral.tests.JPFBenchmark.benchmark06(-3.1418419553912025,-1.5707957163543151,122.98944306304588 ) ;
  }

  @Test
  public void test3590() {
    coral.tests.JPFBenchmark.benchmark06(-31.43020852560518,5.2919766915357656,-16.430830198080116 ) ;
  }

  @Test
  public void test3591() {
    coral.tests.JPFBenchmark.benchmark06(-3.1554436208840472E-30,-1.5707963267948966,-3.141592653589793 ) ;
  }

  @Test
  public void test3592() {
    coral.tests.JPFBenchmark.benchmark06(-31.80182074416369,64.45880559758808,18.523037584760587 ) ;
  }

  @Test
  public void test3593() {
    coral.tests.JPFBenchmark.benchmark06(-3.195715749812414E-7,-1.5707963267948966,84.82172609050922 ) ;
  }

  @Test
  public void test3594() {
    coral.tests.JPFBenchmark.benchmark06(-3.2033329522929615E-145,-1.2345329695578964,-1.4600644462857901 ) ;
  }

  @Test
  public void test3595() {
    coral.tests.JPFBenchmark.benchmark06(3.2311742677852644E-27,-1.5707963267948966,2.6015821216051034 ) ;
  }

  @Test
  public void test3596() {
    coral.tests.JPFBenchmark.benchmark06(-32.472030998510235,30.20587433537088,-26.047263325351395 ) ;
  }

  @Test
  public void test3597() {
    coral.tests.JPFBenchmark.benchmark06(-3.248565551764031E-114,-1.570792295052182,1.5707963267948966 ) ;
  }

  @Test
  public void test3598() {
    coral.tests.JPFBenchmark.benchmark06(-32.507430858704,94.12391956826423,-22.37532365364831 ) ;
  }

  @Test
  public void test3599() {
    coral.tests.JPFBenchmark.benchmark06(-32.62162260473403,85.42177409335247,-25.01424950009445 ) ;
  }

  @Test
  public void test3600() {
    coral.tests.JPFBenchmark.benchmark06(-32.81661961905455,-64.17721140642085,21.94389155483026 ) ;
  }

  @Test
  public void test3601() {
    coral.tests.JPFBenchmark.benchmark06(-3.2944368572595385E-83,-0.5553397379964957,-90.31314526147642 ) ;
  }

  @Test
  public void test3602() {
    coral.tests.JPFBenchmark.benchmark06(3.3087224502121107E-24,-5.551115123125783E-17,-58.14879813474367 ) ;
  }

  @Test
  public void test3603() {
    coral.tests.JPFBenchmark.benchmark06(-3.3175918336840057E-15,-37.69911184307752,-1.5707963267948966 ) ;
  }

  @Test
  public void test3604() {
    coral.tests.JPFBenchmark.benchmark06(-33.205268908246794,26.44327607831815,64.04838818076192 ) ;
  }

  @Test
  public void test3605() {
    coral.tests.JPFBenchmark.benchmark06(3.3340569709726395,68.89004390958328,8.176413527097566 ) ;
  }

  @Test
  public void test3606() {
    coral.tests.JPFBenchmark.benchmark06(-3.352319300189077E-16,-1.5707963267948966,43.67987790760969 ) ;
  }

  @Test
  public void test3607() {
    coral.tests.JPFBenchmark.benchmark06(-33.533915776081784,64.24566405247845,-26.770058376296717 ) ;
  }

  @Test
  public void test3608() {
    coral.tests.JPFBenchmark.benchmark06(-3.377017006114542E-226,-1.5707963267948966,-39.701582683522815 ) ;
  }

  @Test
  public void test3609() {
    coral.tests.JPFBenchmark.benchmark06(-33.78942936725386,-24.48538421780154,12.446907107049498 ) ;
  }

  @Test
  public void test3610() {
    coral.tests.JPFBenchmark.benchmark06(3.3881317890172014E-21,-0.43954098247902257,12.615934733470901 ) ;
  }

  @Test
  public void test3611() {
    coral.tests.JPFBenchmark.benchmark06(-3.3881317890172014E-21,-1.5707455872791984,-40.84133915799749 ) ;
  }

  @Test
  public void test3612() {
    coral.tests.JPFBenchmark.benchmark06(-3.3881317890172014E-21,-1.570793871348655,9.422657754696337 ) ;
  }

  @Test
  public void test3613() {
    coral.tests.JPFBenchmark.benchmark06(-3.3881317890172014E-21,-1.5707963265411764,-53.69121447676951 ) ;
  }

  @Test
  public void test3614() {
    coral.tests.JPFBenchmark.benchmark06(3.3881317890172014E-21,-88.195102870745,-1.5707963267948983 ) ;
  }

  @Test
  public void test3615() {
    coral.tests.JPFBenchmark.benchmark06(33.943973734794696,83.75268503093798,62.14618912212234 ) ;
  }

  @Test
  public void test3616() {
    coral.tests.JPFBenchmark.benchmark06(-33.94836482920152,-96.6793947007025,-85.47298096219498 ) ;
  }

  @Test
  public void test3617() {
    coral.tests.JPFBenchmark.benchmark06(34.02718040160099,81.88331418037035,5.460544093485311 ) ;
  }

  @Test
  public void test3618() {
    coral.tests.JPFBenchmark.benchmark06(-3.425947326086888E-17,-44.439267796819024,-1.5707963267948966 ) ;
  }

  @Test
  public void test3619() {
    coral.tests.JPFBenchmark.benchmark06(-3.4360324788340243E-35,-1.5707963267948966,-40.840704496711325 ) ;
  }

  @Test
  public void test3620() {
    coral.tests.JPFBenchmark.benchmark06(-3.458065414261291E-223,-1.5707963267948966,88.39565645461212 ) ;
  }

  @Test
  public void test3621() {
    coral.tests.JPFBenchmark.benchmark06(-34.65117263273507,9.951019643708435,-23.968954688695575 ) ;
  }

  @Test
  public void test3622() {
    coral.tests.JPFBenchmark.benchmark06(3.469446951953614E-18,-1.2070128028394946,-5.138493106556027 ) ;
  }

  @Test
  public void test3623() {
    coral.tests.JPFBenchmark.benchmark06(-3.469446951953614E-18,-1.563803008568836,1.5707963267950105 ) ;
  }

  @Test
  public void test3624() {
    coral.tests.JPFBenchmark.benchmark06(-3.469446951953614E-18,-1.570796227517018,-51.82249574727007 ) ;
  }

  @Test
  public void test3625() {
    coral.tests.JPFBenchmark.benchmark06(3.469446951953614E-18,-1.5707963267948966,-30.792784284558252 ) ;
  }

  @Test
  public void test3626() {
    coral.tests.JPFBenchmark.benchmark06(3.469446951953614E-18,-1.5707963267948966,-95.67228834387251 ) ;
  }

  @Test
  public void test3627() {
    coral.tests.JPFBenchmark.benchmark06(-3.4770945765329605E-10,-1.5707963264488731,73.8278854523514 ) ;
  }

  @Test
  public void test3628() {
    coral.tests.JPFBenchmark.benchmark06(-3.4842848866177587E-17,-1.5707963267948966,-66.35873324308992 ) ;
  }

  @Test
  public void test3629() {
    coral.tests.JPFBenchmark.benchmark06(35.08300109102919,-48.645982773402,5.1715871318853885 ) ;
  }

  @Test
  public void test3630() {
    coral.tests.JPFBenchmark.benchmark06(-35.08388942309951,-70.68195405743505,-55.702339074619985 ) ;
  }

  @Test
  public void test3631() {
    coral.tests.JPFBenchmark.benchmark06(35.29296067543106,78.09154327663958,46.98025174764044 ) ;
  }

  @Test
  public void test3632() {
    coral.tests.JPFBenchmark.benchmark06(-3.5373746401666845E-74,-19.358969984545283,-9.943724682815926 ) ;
  }

  @Test
  public void test3633() {
    coral.tests.JPFBenchmark.benchmark06(-35.40169354674137,57.00459716854351,26.74705042771039 ) ;
  }

  @Test
  public void test3634() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,-0.03011209181171637,53.44960887841344 ) ;
  }

  @Test
  public void test3635() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,-101.91690908119163,-45.27979104332672 ) ;
  }

  @Test
  public void test3636() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,-1.5707963267948926,53.706309408064314 ) ;
  }

  @Test
  public void test3637() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3638() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,-1.5707963267948966,-1.5856303344925884 ) ;
  }

  @Test
  public void test3639() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,-1.5707963267948966,-46.11125582072182 ) ;
  }

  @Test
  public void test3640() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,-1.5707963267948966,-6.7123889803846915 ) ;
  }

  @Test
  public void test3641() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,-32.552791234393666,-72.70427010883694 ) ;
  }

  @Test
  public void test3642() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,-38.739024256137384,-1.5707963267948983 ) ;
  }

  @Test
  public void test3643() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,-44.367085451540376,-83.27218547550771 ) ;
  }

  @Test
  public void test3644() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,-44.511753049112905,-84.62084128454968 ) ;
  }

  @Test
  public void test3645() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,-45.39990719967424,-91.14689480114401 ) ;
  }

  @Test
  public void test3646() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,-9.55233201031627E-15,-23.134494598124178 ) ;
  }

  @Test
  public void test3647() {
    coral.tests.JPFBenchmark.benchmark06(-3.562997919675521E-15,3.469446951953614E-18,-1.5707963267948966 ) ;
  }

  @Test
  public void test3648() {
    coral.tests.JPFBenchmark.benchmark06(-3.5718355977571093E-102,-1.5707963267948966,-68.07008416807473 ) ;
  }

  @Test
  public void test3649() {
    coral.tests.JPFBenchmark.benchmark06(-35.749602237402115,-18.07744110282559,-24.64769008113292 ) ;
  }

  @Test
  public void test3650() {
    coral.tests.JPFBenchmark.benchmark06(-35.809946555431,47.29357590320825,90.69327260664676 ) ;
  }

  @Test
  public void test3651() {
    coral.tests.JPFBenchmark.benchmark06(-3.6111999267244405E-15,-1.5707963267948915,3.141592653589793 ) ;
  }

  @Test
  public void test3652() {
    coral.tests.JPFBenchmark.benchmark06(-3.6139460187578685E-15,-38.995772322250644,-1.5707963267948966 ) ;
  }

  @Test
  public void test3653() {
    coral.tests.JPFBenchmark.benchmark06(36.235768195062406,-24.740056953986468,17.748529320723037 ) ;
  }

  @Test
  public void test3654() {
    coral.tests.JPFBenchmark.benchmark06(-3.640617643651196E-9,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3655() {
    coral.tests.JPFBenchmark.benchmark06(36.571982282267555,14.538179142685777,26.323250866849037 ) ;
  }

  @Test
  public void test3656() {
    coral.tests.JPFBenchmark.benchmark06(-3.65755965210328E-99,-88.53530033485788,-88.24116251574014 ) ;
  }

  @Test
  public void test3657() {
    coral.tests.JPFBenchmark.benchmark06(-3.667423711767873E-15,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3658() {
    coral.tests.JPFBenchmark.benchmark06(-3.6931914471142943E-127,-1.5707963267948948,-50.596478495881996 ) ;
  }

  @Test
  public void test3659() {
    coral.tests.JPFBenchmark.benchmark06(37.25333566824318,-6.69160893582152,-34.159493146319164 ) ;
  }

  @Test
  public void test3660() {
    coral.tests.JPFBenchmark.benchmark06(-37.36960908431677,76.57890290842451,-65.29101964590402 ) ;
  }

  @Test
  public void test3661() {
    coral.tests.JPFBenchmark.benchmark06(-3.748930547335608E-17,-1.5707963267948966,34.557519189488026 ) ;
  }

  @Test
  public void test3662() {
    coral.tests.JPFBenchmark.benchmark06(-37.81891272528712,0,0 ) ;
  }

  @Test
  public void test3663() {
    coral.tests.JPFBenchmark.benchmark06(37.908474119174286,-65.34282655043187,44.38026878101752 ) ;
  }

  @Test
  public void test3664() {
    coral.tests.JPFBenchmark.benchmark06(-3.8021831325903196E-211,-1.5707963267948966,49.71695988975321 ) ;
  }

  @Test
  public void test3665() {
    coral.tests.JPFBenchmark.benchmark06(-3.8021831325903196E-211,-32.65154645617403,-1.5707963267948966 ) ;
  }

  @Test
  public void test3666() {
    coral.tests.JPFBenchmark.benchmark06(38.10616199930453,58.767533418300275,-10.572561699282474 ) ;
  }

  @Test
  public void test3667() {
    coral.tests.JPFBenchmark.benchmark06(-3.8661919429124426E-19,-1.5707963267948966,-53.40707499942022 ) ;
  }

  @Test
  public void test3668() {
    coral.tests.JPFBenchmark.benchmark06(-38.9581652467764,-20.171075309146985,27.698654886850903 ) ;
  }

  @Test
  public void test3669() {
    coral.tests.JPFBenchmark.benchmark06(3.907596076894038E-9,-1.5707963267948966,257.5510993305285 ) ;
  }

  @Test
  public void test3670() {
    coral.tests.JPFBenchmark.benchmark06(3.944304526105059E-31,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3671() {
    coral.tests.JPFBenchmark.benchmark06(-39.889672211571,-5.991352515917043,25.608921773998333 ) ;
  }

  @Test
  public void test3672() {
    coral.tests.JPFBenchmark.benchmark06(-40.01569207454894,-63.98175955555325,75.28152009884559 ) ;
  }

  @Test
  public void test3673() {
    coral.tests.JPFBenchmark.benchmark06(-4.004166190366202E-146,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3674() {
    coral.tests.JPFBenchmark.benchmark06(-4.004166190366202E-146,-37.809748434194326,-8.356925559105918 ) ;
  }

  @Test
  public void test3675() {
    coral.tests.JPFBenchmark.benchmark06(40.098514844317094,17.34935141032085,-91.28270860219531 ) ;
  }

  @Test
  public void test3676() {
    coral.tests.JPFBenchmark.benchmark06(-40.292771089428506,65.21480982122068,-82.38645724412785 ) ;
  }

  @Test
  public void test3677() {
    coral.tests.JPFBenchmark.benchmark06(40.386660547604976,-74.89418322229635,89.93156429382611 ) ;
  }

  @Test
  public void test3678() {
    coral.tests.JPFBenchmark.benchmark06(4.0389678347315804E-28,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3679() {
    coral.tests.JPFBenchmark.benchmark06(-40.42114444715046,-55.346688521935114,99.11124384448715 ) ;
  }

  @Test
  public void test3680() {
    coral.tests.JPFBenchmark.benchmark06(40.492002088952006,99.37309300603303,-79.4807180988879 ) ;
  }

  @Test
  public void test3681() {
    coral.tests.JPFBenchmark.benchmark06(40.66035516125427,-90.96245848390735,70.27530775669149 ) ;
  }

  @Test
  public void test3682() {
    coral.tests.JPFBenchmark.benchmark06(40.715739626952484,-43.55814232870521,-52.44595648113566 ) ;
  }

  @Test
  public void test3683() {
    coral.tests.JPFBenchmark.benchmark06(40.92947806288993,27.72305182355406,63.181665424073145 ) ;
  }

  @Test
  public void test3684() {
    coral.tests.JPFBenchmark.benchmark06(41.04555965027171,-99.53701965611548,-67.53401630601294 ) ;
  }

  @Test
  public void test3685() {
    coral.tests.JPFBenchmark.benchmark06(-4.107463376355549E-16,-1.5707963267948966,6.20834770865039 ) ;
  }

  @Test
  public void test3686() {
    coral.tests.JPFBenchmark.benchmark06(-41.12046489788162,8.041542844706441,-30.137874336790787 ) ;
  }

  @Test
  public void test3687() {
    coral.tests.JPFBenchmark.benchmark06(-41.126250458731036,50.365099175937644,-79.74919874319353 ) ;
  }

  @Test
  public void test3688() {
    coral.tests.JPFBenchmark.benchmark06(41.15721903174608,-41.61682810284337,46.84173944083528 ) ;
  }

  @Test
  public void test3689() {
    coral.tests.JPFBenchmark.benchmark06(-4.118046071574423E-84,-1.4403654776313055,-0.18191710081336965 ) ;
  }

  @Test
  public void test3690() {
    coral.tests.JPFBenchmark.benchmark06(41.34269713468203,-29.52976029691837,-47.221423033526364 ) ;
  }

  @Test
  public void test3691() {
    coral.tests.JPFBenchmark.benchmark06(4.1359030627651384E-25,-1.5707963267948966,60.73134978630805 ) ;
  }

  @Test
  public void test3692() {
    coral.tests.JPFBenchmark.benchmark06(-4.152373599953194,-17.45827024562729,-34.29249138729955 ) ;
  }

  @Test
  public void test3693() {
    coral.tests.JPFBenchmark.benchmark06(-4.1761948595190557E-53,-1.510583925920204,-87.32903452104009 ) ;
  }

  @Test
  public void test3694() {
    coral.tests.JPFBenchmark.benchmark06(-4.1893853824251717E-4,-1.5707963267948966,68.57440952516217 ) ;
  }

  @Test
  public void test3695() {
    coral.tests.JPFBenchmark.benchmark06(41.988109498297064,23.14208253341208,-22.536963425747956 ) ;
  }

  @Test
  public void test3696() {
    coral.tests.JPFBenchmark.benchmark06(-4.2168791772922093E-81,-0.31100814683376976,78.15473035450049 ) ;
  }

  @Test
  public void test3697() {
    coral.tests.JPFBenchmark.benchmark06(-4.2351647362715017E-22,-45.55220067012214,-84.25220530888974 ) ;
  }

  @Test
  public void test3698() {
    coral.tests.JPFBenchmark.benchmark06(42.5181451106682,-3.564268237833204,59.251879720294085 ) ;
  }

  @Test
  public void test3699() {
    coral.tests.JPFBenchmark.benchmark06(-42.60169045723246,89.24339231870121,24.078810281184488 ) ;
  }

  @Test
  public void test3700() {
    coral.tests.JPFBenchmark.benchmark06(-4.274684842137975E-5,-0.5470977155072951,-101.07956192262195 ) ;
  }

  @Test
  public void test3701() {
    coral.tests.JPFBenchmark.benchmark06(-42.758530579724166,-86.72278252058247,17.780852533383836 ) ;
  }

  @Test
  public void test3702() {
    coral.tests.JPFBenchmark.benchmark06(-43.106908722278604,16.575309491055748,-76.67543175069454 ) ;
  }

  @Test
  public void test3703() {
    coral.tests.JPFBenchmark.benchmark06(-4.319375227515149E-10,-1.5707963196895223,-53.407109646046244 ) ;
  }

  @Test
  public void test3704() {
    coral.tests.JPFBenchmark.benchmark06(-43.24842127254953,96.24020051527808,70.91516818291973 ) ;
  }

  @Test
  public void test3705() {
    coral.tests.JPFBenchmark.benchmark06(-43.35039868902726,-50.10509871555031,59.75719041246268 ) ;
  }

  @Test
  public void test3706() {
    coral.tests.JPFBenchmark.benchmark06(-4.3367963151895612E-19,-1.5707963267948966,72.25662837153872 ) ;
  }

  @Test
  public void test3707() {
    coral.tests.JPFBenchmark.benchmark06(4.3368086899420177E-19,-0.2951426603609053,3.7189187727964983 ) ;
  }

  @Test
  public void test3708() {
    coral.tests.JPFBenchmark.benchmark06(4.3368086899420177E-19,-1.358616210640359,-2.3551723524399364 ) ;
  }

  @Test
  public void test3709() {
    coral.tests.JPFBenchmark.benchmark06(-4.3368086899420177E-19,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3710() {
    coral.tests.JPFBenchmark.benchmark06(4.3368086899420177E-19,-1.5707963267948966,7.015678967593804 ) ;
  }

  @Test
  public void test3711() {
    coral.tests.JPFBenchmark.benchmark06(-4.34334630299476,13.4717506608865,-72.81771454667964 ) ;
  }

  @Test
  public void test3712() {
    coral.tests.JPFBenchmark.benchmark06(43.58437988947588,91.27912508547377,-77.76414448419409 ) ;
  }

  @Test
  public void test3713() {
    coral.tests.JPFBenchmark.benchmark06(-4.383618698016806E-193,-95.30479119191347,-53.04796015305806 ) ;
  }

  @Test
  public void test3714() {
    coral.tests.JPFBenchmark.benchmark06(4.400782344943323,94.99619533279139,26.924395847079523 ) ;
  }

  @Test
  public void test3715() {
    coral.tests.JPFBenchmark.benchmark06(-4.4026272858551673E-134,-0.49043581300391836,-39.70609863270298 ) ;
  }

  @Test
  public void test3716() {
    coral.tests.JPFBenchmark.benchmark06(-44.04718772018903,-8.915955997499324,-71.74494526996133 ) ;
  }

  @Test
  public void test3717() {
    coral.tests.JPFBenchmark.benchmark06(44.134279874697484,-96.96514860106804,-18.7224201136368 ) ;
  }

  @Test
  public void test3718() {
    coral.tests.JPFBenchmark.benchmark06(44.13641101684996,-89.18679277013734,-31.69742708592807 ) ;
  }

  @Test
  public void test3719() {
    coral.tests.JPFBenchmark.benchmark06(-44.245785998974796,-72.81634891504049,82.13386307398346 ) ;
  }

  @Test
  public void test3720() {
    coral.tests.JPFBenchmark.benchmark06(-44.257248530838766,89.22340911314794,-42.841877564504614 ) ;
  }

  @Test
  public void test3721() {
    coral.tests.JPFBenchmark.benchmark06(-4.4263237302544523E-221,-1.5707963267948966,-66.42311145215652 ) ;
  }

  @Test
  public void test3722() {
    coral.tests.JPFBenchmark.benchmark06(-4.440892098500626E-16,-0.5202584308149223,1.5707963267948966 ) ;
  }

  @Test
  public void test3723() {
    coral.tests.JPFBenchmark.benchmark06(-4.440892098500626E-16,-1.4062803809906463,100.0 ) ;
  }

  @Test
  public void test3724() {
    coral.tests.JPFBenchmark.benchmark06(-4.440892098500626E-16,-1.5707963267948961,-1.471340310964758 ) ;
  }

  @Test
  public void test3725() {
    coral.tests.JPFBenchmark.benchmark06(-4.440892098500626E-16,-1.5707963267948966,-3.1415926535897936 ) ;
  }

  @Test
  public void test3726() {
    coral.tests.JPFBenchmark.benchmark06(-4.440892098500626E-16,-1.5707963267948966,-31.98245090219693 ) ;
  }

  @Test
  public void test3727() {
    coral.tests.JPFBenchmark.benchmark06(-4.440892098500626E-16,-1.5707963267948966,35.57941097555155 ) ;
  }

  @Test
  public void test3728() {
    coral.tests.JPFBenchmark.benchmark06(-4.440892098500626E-16,-1.5707963267948966,-80.92159163580091 ) ;
  }

  @Test
  public void test3729() {
    coral.tests.JPFBenchmark.benchmark06(-4.440892098500626E-16,-1.5707963267948966,86.21982078218454 ) ;
  }

  @Test
  public void test3730() {
    coral.tests.JPFBenchmark.benchmark06(-4.440892098500626E-16,-1.5707963267948983,1.5707963267948912 ) ;
  }

  @Test
  public void test3731() {
    coral.tests.JPFBenchmark.benchmark06(-4.440892098500626E-16,4.3368086899420177E-19,1.5707963267948966 ) ;
  }

  @Test
  public void test3732() {
    coral.tests.JPFBenchmark.benchmark06(-4.440892098500626E-16,-4.440892098500626E-16,-0.3757849637948154 ) ;
  }

  @Test
  public void test3733() {
    coral.tests.JPFBenchmark.benchmark06(-4.445517498970155E-162,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3734() {
    coral.tests.JPFBenchmark.benchmark06(-4.445517498970155E-162,-1.5707963267948966,60.840565217152474 ) ;
  }

  @Test
  public void test3735() {
    coral.tests.JPFBenchmark.benchmark06(44.572757065814926,-75.16857206620853,-10.780078011816798 ) ;
  }

  @Test
  public void test3736() {
    coral.tests.JPFBenchmark.benchmark06(-44.676888720228966,4.017347506336861,-41.07900442491932 ) ;
  }

  @Test
  public void test3737() {
    coral.tests.JPFBenchmark.benchmark06(-4.491419719779884,0,0 ) ;
  }

  @Test
  public void test3738() {
    coral.tests.JPFBenchmark.benchmark06(45.059682695146336,-86.8380696175774,60.285927915383525 ) ;
  }

  @Test
  public void test3739() {
    coral.tests.JPFBenchmark.benchmark06(-4.510201478469106E-16,-0.5096056962453162,43.982297150257104 ) ;
  }

  @Test
  public void test3740() {
    coral.tests.JPFBenchmark.benchmark06(-4.5577888268020415E-25,-1.5707963267948966,-7.8545495444763625E-90 ) ;
  }

  @Test
  public void test3741() {
    coral.tests.JPFBenchmark.benchmark06(45.67480475002975,-4.112417248962046,-95.13022732567717 ) ;
  }

  @Test
  public void test3742() {
    coral.tests.JPFBenchmark.benchmark06(-4.5719495651291E-100,-0.6858216132397521,24.138806738353864 ) ;
  }

  @Test
  public void test3743() {
    coral.tests.JPFBenchmark.benchmark06(-4.5719495651291E-100,-1.5707963267948966,30.859133918640033 ) ;
  }

  @Test
  public void test3744() {
    coral.tests.JPFBenchmark.benchmark06(-4.5719495651291E-100,-37.71157259426238,-60.05375611401134 ) ;
  }

  @Test
  public void test3745() {
    coral.tests.JPFBenchmark.benchmark06(-45.7545484275752,-28.06256305099832,26.994726347900453 ) ;
  }

  @Test
  public void test3746() {
    coral.tests.JPFBenchmark.benchmark06(46.07612312661402,42.13009027155789,52.847221873117064 ) ;
  }

  @Test
  public void test3747() {
    coral.tests.JPFBenchmark.benchmark06(4.618443157473032E-5,-1.5707948744721176,135.50937009041203 ) ;
  }

  @Test
  public void test3748() {
    coral.tests.JPFBenchmark.benchmark06(46.34281804435918,0,0 ) ;
  }

  @Test
  public void test3749() {
    coral.tests.JPFBenchmark.benchmark06(-4.650832351459998E-6,-45.55307762295589,-97.43035133179882 ) ;
  }

  @Test
  public void test3750() {
    coral.tests.JPFBenchmark.benchmark06(-4.692685745873826E-17,-1.5707963267948966,-97.76726659759834 ) ;
  }

  @Test
  public void test3751() {
    coral.tests.JPFBenchmark.benchmark06(-4.695350914734694E-6,-0.7962054429457806,2.8740348793107844E-10 ) ;
  }

  @Test
  public void test3752() {
    coral.tests.JPFBenchmark.benchmark06(-4.697793533197246E-16,-1.5707963267948966,-52.24551809676947 ) ;
  }

  @Test
  public void test3753() {
    coral.tests.JPFBenchmark.benchmark06(47.1538032624926,82.03770566872845,2.6046201228069776 ) ;
  }

  @Test
  public void test3754() {
    coral.tests.JPFBenchmark.benchmark06(4.7395143397133933E-32,-0.14456617692429335,-1.5707963267948966 ) ;
  }

  @Test
  public void test3755() {
    coral.tests.JPFBenchmark.benchmark06(4.741041809474694E-17,-1.5707963267948486,51.84346811693814 ) ;
  }

  @Test
  public void test3756() {
    coral.tests.JPFBenchmark.benchmark06(-47.65219668336198,44.1522115210426,-21.830709494504646 ) ;
  }

  @Test
  public void test3757() {
    coral.tests.JPFBenchmark.benchmark06(-4.779605329465555E-16,-1.5707963267948948,-72.80568059190631 ) ;
  }

  @Test
  public void test3758() {
    coral.tests.JPFBenchmark.benchmark06(-48.3861418436641,-78.62755000720989,-54.601932862335126 ) ;
  }

  @Test
  public void test3759() {
    coral.tests.JPFBenchmark.benchmark06(48.59170470066664,76.65685948508855,-18.986474649381435 ) ;
  }

  @Test
  public void test3760() {
    coral.tests.JPFBenchmark.benchmark06(-48.890745946117306,-26.55474977798356,-61.88199876643454 ) ;
  }

  @Test
  public void test3761() {
    coral.tests.JPFBenchmark.benchmark06(-4.893930880412192E-8,-45.55161018628842,-59.67171509321327 ) ;
  }

  @Test
  public void test3762() {
    coral.tests.JPFBenchmark.benchmark06(4.930380657631324E-32,-0.20677573795394694,0.0 ) ;
  }

  @Test
  public void test3763() {
    coral.tests.JPFBenchmark.benchmark06(4.930380657631324E-32,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3764() {
    coral.tests.JPFBenchmark.benchmark06(4.930380657631324E-32,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test3765() {
    coral.tests.JPFBenchmark.benchmark06(-4.9355158837307067E-178,-1.5707963267948966,77.05955230253474 ) ;
  }

  @Test
  public void test3766() {
    coral.tests.JPFBenchmark.benchmark06(-4.9355158837307067E-178,-37.77131997941472,-85.48353209779582 ) ;
  }

  @Test
  public void test3767() {
    coral.tests.JPFBenchmark.benchmark06(-49.58518344417724,0.06431483373026481,-85.31406773326616 ) ;
  }

  @Test
  public void test3768() {
    coral.tests.JPFBenchmark.benchmark06(-5.0052077379577523E-147,-4.440892098500626E-16,-92.92341695101058 ) ;
  }

  @Test
  public void test3769() {
    coral.tests.JPFBenchmark.benchmark06(50.08758260973599,-94.58820128677566,-20.834956712335284 ) ;
  }

  @Test
  public void test3770() {
    coral.tests.JPFBenchmark.benchmark06(-5.019890507973237E-18,-1.5707963267948966,9.424776121132158 ) ;
  }

  @Test
  public void test3771() {
    coral.tests.JPFBenchmark.benchmark06(-50.28569000678003,-82.99479071934101,-9.923310322739923 ) ;
  }

  @Test
  public void test3772() {
    coral.tests.JPFBenchmark.benchmark06(-5.030785672482742E-16,-0.10319938406939697,-25.506488487979894 ) ;
  }

  @Test
  public void test3773() {
    coral.tests.JPFBenchmark.benchmark06(-5.049097799806759,10.617733246349914,84.74854889789938 ) ;
  }

  @Test
  public void test3774() {
    coral.tests.JPFBenchmark.benchmark06(-5.0539682649402436E-175,-0.8137674348033431,53.9435230526199 ) ;
  }

  @Test
  public void test3775() {
    coral.tests.JPFBenchmark.benchmark06(-50.57692045372255,-63.04428913151614,54.461870665942115 ) ;
  }

  @Test
  public void test3776() {
    coral.tests.JPFBenchmark.benchmark06(-5.0758836746312984E-116,-1.5707963267948966,94.84537136564838 ) ;
  }

  @Test
  public void test3777() {
    coral.tests.JPFBenchmark.benchmark06(-5.0758836746312984E-116,-31.88091704434073,-1.5521949180327241 ) ;
  }

  @Test
  public void test3778() {
    coral.tests.JPFBenchmark.benchmark06(-50.85586573214253,-38.02797251419092,0 ) ;
  }

  @Test
  public void test3779() {
    coral.tests.JPFBenchmark.benchmark06(51.410539685091834,74.86359336146927,61.94855037717127 ) ;
  }

  @Test
  public void test3780() {
    coral.tests.JPFBenchmark.benchmark06(51.73043160106667,82.23241697654586,42.320723043427336 ) ;
  }

  @Test
  public void test3781() {
    coral.tests.JPFBenchmark.benchmark06(-52.10129678934421,-69.86563210045347,-95.00493527680467 ) ;
  }

  @Test
  public void test3782() {
    coral.tests.JPFBenchmark.benchmark06(-52.44448417339787,-14.308048492470334,-82.796755381814 ) ;
  }

  @Test
  public void test3783() {
    coral.tests.JPFBenchmark.benchmark06(52.69460194637787,36.368310237421696,58.916085892412525 ) ;
  }

  @Test
  public void test3784() {
    coral.tests.JPFBenchmark.benchmark06(52.71435308830087,-29.525609302573102,41.8899433032191 ) ;
  }

  @Test
  public void test3785() {
    coral.tests.JPFBenchmark.benchmark06(-5.279764790151011E-6,-32.985997025256715,-85.17567035340464 ) ;
  }

  @Test
  public void test3786() {
    coral.tests.JPFBenchmark.benchmark06(5.293955920339377E-23,-1.5707963267948966,19.443944264305987 ) ;
  }

  @Test
  public void test3787() {
    coral.tests.JPFBenchmark.benchmark06(-5.293955920339377E-23,-1.5707963267948966,-2.570759522715978 ) ;
  }

  @Test
  public void test3788() {
    coral.tests.JPFBenchmark.benchmark06(-5.310037398759253E-7,-32.51155717409406,-3.1415926535897913 ) ;
  }

  @Test
  public void test3789() {
    coral.tests.JPFBenchmark.benchmark06(-5.314773967126824E-15,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test3790() {
    coral.tests.JPFBenchmark.benchmark06(-5.3224498000101884E-110,-1.5707963267948966,-96.15354341228841 ) ;
  }

  @Test
  public void test3791() {
    coral.tests.JPFBenchmark.benchmark06(-5.381414998284302E-17,-1.39002962987938,3.1415926535897953 ) ;
  }

  @Test
  public void test3792() {
    coral.tests.JPFBenchmark.benchmark06(54.16998289607514,35.068772857322784,13.61230734666215 ) ;
  }

  @Test
  public void test3793() {
    coral.tests.JPFBenchmark.benchmark06(5.421010862427522E-20,-0.008433622502473098,-58.43011274391523 ) ;
  }

  @Test
  public void test3794() {
    coral.tests.JPFBenchmark.benchmark06(5.421010862427522E-20,-0.6766795704624686,-0.356761921803162 ) ;
  }

  @Test
  public void test3795() {
    coral.tests.JPFBenchmark.benchmark06(5.421010862427522E-20,-1.5707963267948966,34.24159373982152 ) ;
  }

  @Test
  public void test3796() {
    coral.tests.JPFBenchmark.benchmark06(-54.690942197733825,59.51750927919781,44.54957543414352 ) ;
  }

  @Test
  public void test3797() {
    coral.tests.JPFBenchmark.benchmark06(-5.4795233725210076E-194,-0.04914987196420779,-4.6434013026432694 ) ;
  }

  @Test
  public void test3798() {
    coral.tests.JPFBenchmark.benchmark06(-5.4795233725210076E-194,-1.5707963267948966,57.85992274511245 ) ;
  }

  @Test
  public void test3799() {
    coral.tests.JPFBenchmark.benchmark06(-54.80145188327143,-94.42159205605863,26.176775478019138 ) ;
  }

  @Test
  public void test3800() {
    coral.tests.JPFBenchmark.benchmark06(-55.34188026849021,-71.88384338713341,-1.8106883035926131 ) ;
  }

  @Test
  public void test3801() {
    coral.tests.JPFBenchmark.benchmark06(-5.551115123125783E-17,-1.5674082604362207,-65.89628634353934 ) ;
  }

  @Test
  public void test3802() {
    coral.tests.JPFBenchmark.benchmark06(-5.551115123125783E-17,-1.5707963267948966,-41.88596412976263 ) ;
  }

  @Test
  public void test3803() {
    coral.tests.JPFBenchmark.benchmark06(5.551115123125783E-17,-1.5707963267948966,-62.591082354609235 ) ;
  }

  @Test
  public void test3804() {
    coral.tests.JPFBenchmark.benchmark06(5.551115123125783E-17,-38.863653855178505,-39.219945130484106 ) ;
  }

  @Test
  public void test3805() {
    coral.tests.JPFBenchmark.benchmark06(-5.551115123125783E-17,-94.31924637189614,-100.9381303009425 ) ;
  }

  @Test
  public void test3806() {
    coral.tests.JPFBenchmark.benchmark06(-5.556775670960728E-11,-1.5707963267948966,63.396818592054856 ) ;
  }

  @Test
  public void test3807() {
    coral.tests.JPFBenchmark.benchmark06(-55.89633827113669,51.48394373846554,74.44044061578049 ) ;
  }

  @Test
  public void test3808() {
    coral.tests.JPFBenchmark.benchmark06(56.14870700542488,-66.43878724070827,-12.943064802736075 ) ;
  }

  @Test
  public void test3809() {
    coral.tests.JPFBenchmark.benchmark06(5.6282130908076E-10,-37.83003048085205,-147.06209628344612 ) ;
  }

  @Test
  public void test3810() {
    coral.tests.JPFBenchmark.benchmark06(-56.39967583496248,0,0 ) ;
  }

  @Test
  public void test3811() {
    coral.tests.JPFBenchmark.benchmark06(56.57589964253626,-13.270467567296322,0 ) ;
  }

  @Test
  public void test3812() {
    coral.tests.JPFBenchmark.benchmark06(56.72686707491334,-36.210653211494346,-47.68269970663592 ) ;
  }

  @Test
  public void test3813() {
    coral.tests.JPFBenchmark.benchmark06(-56.96389572526128,26.610614508212606,45.480521472064254 ) ;
  }

  @Test
  public void test3814() {
    coral.tests.JPFBenchmark.benchmark06(57.18445496636636,38.410414776870255,-1.9244035117494747 ) ;
  }

  @Test
  public void test3815() {
    coral.tests.JPFBenchmark.benchmark06(-5.770611636116085E-129,-39.10239986179721,-58.97093189674591 ) ;
  }

  @Test
  public void test3816() {
    coral.tests.JPFBenchmark.benchmark06(58.2173035570238,-69.2102561244168,-55.33041897154733 ) ;
  }

  @Test
  public void test3817() {
    coral.tests.JPFBenchmark.benchmark06(-5.8574673205347E-16,-1.5707963267948966,45.50222137855792 ) ;
  }

  @Test
  public void test3818() {
    coral.tests.JPFBenchmark.benchmark06(-59.37923268999259,94.63398850308877,69.80092563942856 ) ;
  }

  @Test
  public void test3819() {
    coral.tests.JPFBenchmark.benchmark06(-5.988360992172006E-15,-31.613851472003887,-1.5707963267948968 ) ;
  }

  @Test
  public void test3820() {
    coral.tests.JPFBenchmark.benchmark06(-5.99855536008854E-18,-2.8574684782056875E-101,-8.749134456221839 ) ;
  }

  @Test
  public void test3821() {
    coral.tests.JPFBenchmark.benchmark06(60.325177129218446,87.64785343454969,32.11987533560389 ) ;
  }

  @Test
  public void test3822() {
    coral.tests.JPFBenchmark.benchmark06(-6.045770011850319E-13,-19.380208075684834,-3.944304526105059E-31 ) ;
  }

  @Test
  public void test3823() {
    coral.tests.JPFBenchmark.benchmark06(-60.494714452920476,-3.9204862912393708,9.30903352816921 ) ;
  }

  @Test
  public void test3824() {
    coral.tests.JPFBenchmark.benchmark06(-60.600306192842204,70.462811612135,9.441114739410025 ) ;
  }

  @Test
  public void test3825() {
    coral.tests.JPFBenchmark.benchmark06(-6.0901463708569565,-62.889050770274515,83.67833191870645 ) ;
  }

  @Test
  public void test3826() {
    coral.tests.JPFBenchmark.benchmark06(60.914012779526786,-8.806345017768294,-47.62447411302369 ) ;
  }

  @Test
  public void test3827() {
    coral.tests.JPFBenchmark.benchmark06(60.91662994845788,16.32508717561234,-78.3546322134194 ) ;
  }

  @Test
  public void test3828() {
    coral.tests.JPFBenchmark.benchmark06(-6.11176385056449E-17,-1.5707963267948966,74.91372461460813 ) ;
  }

  @Test
  public void test3829() {
    coral.tests.JPFBenchmark.benchmark06(-6.1339464842467075E-16,-1.5707963267948966,2.0042380421155332 ) ;
  }

  @Test
  public void test3830() {
    coral.tests.JPFBenchmark.benchmark06(6.139215683014228,84.34083960028232,98.21406509405884 ) ;
  }

  @Test
  public void test3831() {
    coral.tests.JPFBenchmark.benchmark06(-6.1519215156298586E-15,-1.5707963267948966,4.322046374435047 ) ;
  }

  @Test
  public void test3832() {
    coral.tests.JPFBenchmark.benchmark06(-6.162975822039155E-33,-1.5707963267948963,58.11946333354425 ) ;
  }

  @Test
  public void test3833() {
    coral.tests.JPFBenchmark.benchmark06(-61.80576726571285,-57.69329957483378,-20.009855687587574 ) ;
  }

  @Test
  public void test3834() {
    coral.tests.JPFBenchmark.benchmark06(61.972280309997274,-32.40480573871697,-3.7464613589452966 ) ;
  }

  @Test
  public void test3835() {
    coral.tests.JPFBenchmark.benchmark06(-62.11472735752002,12.818741792845813,74.52087045672678 ) ;
  }

  @Test
  public void test3836() {
    coral.tests.JPFBenchmark.benchmark06(-62.429611712204,-47.80821499719712,7.483005699248906 ) ;
  }

  @Test
  public void test3837() {
    coral.tests.JPFBenchmark.benchmark06(-6.270565152126255E-42,-1.5707963267948966,-3.1415926535897967 ) ;
  }

  @Test
  public void test3838() {
    coral.tests.JPFBenchmark.benchmark06(-6.3108872417680944E-30,-1.277037011017711,68.91953220373051 ) ;
  }

  @Test
  public void test3839() {
    coral.tests.JPFBenchmark.benchmark06(-63.183409102182786,5.583309637479189,-77.9177160590334 ) ;
  }

  @Test
  public void test3840() {
    coral.tests.JPFBenchmark.benchmark06(63.477108491556834,45.19851839108705,-27.72827575349058 ) ;
  }

  @Test
  public void test3841() {
    coral.tests.JPFBenchmark.benchmark06(63.90899695855012,60.51180131201755,0 ) ;
  }

  @Test
  public void test3842() {
    coral.tests.JPFBenchmark.benchmark06(-63.962964595097894,95.06374158066129,33.74534246368788 ) ;
  }

  @Test
  public void test3843() {
    coral.tests.JPFBenchmark.benchmark06(-63.98856456572493,-87.84691941820337,34.61945853620227 ) ;
  }

  @Test
  public void test3844() {
    coral.tests.JPFBenchmark.benchmark06(-6.406665904585923E-145,-1.5707963267948966,73.35327179853098 ) ;
  }

  @Test
  public void test3845() {
    coral.tests.JPFBenchmark.benchmark06(64.53198500935687,81.0938809350221,0 ) ;
  }

  @Test
  public void test3846() {
    coral.tests.JPFBenchmark.benchmark06(-6.462348535570529E-27,-1.5707963267948966,-1.5707963267937104 ) ;
  }

  @Test
  public void test3847() {
    coral.tests.JPFBenchmark.benchmark06(-64.76591925819127,91.76467453931963,-28.67137838495924 ) ;
  }

  @Test
  public void test3848() {
    coral.tests.JPFBenchmark.benchmark06(64.8794139868817,-71.30304153786591,-5.083005621245903 ) ;
  }

  @Test
  public void test3849() {
    coral.tests.JPFBenchmark.benchmark06(-6.497131103528062E-114,-1.4420062977691277,-48.29904344665537 ) ;
  }

  @Test
  public void test3850() {
    coral.tests.JPFBenchmark.benchmark06(64.9762920778808,92.67893785706863,99.32666509847806 ) ;
  }

  @Test
  public void test3851() {
    coral.tests.JPFBenchmark.benchmark06(-65.27771890592713,72.40145867161635,-56.402772750944585 ) ;
  }

  @Test
  public void test3852() {
    coral.tests.JPFBenchmark.benchmark06(65.32682039101957,-45.22929107901863,-59.3074996277535 ) ;
  }

  @Test
  public void test3853() {
    coral.tests.JPFBenchmark.benchmark06(6.559871718286105,-21.838750923173592,0 ) ;
  }

  @Test
  public void test3854() {
    coral.tests.JPFBenchmark.benchmark06(65.76411280664189,-56.98473637824642,54.18947698247888 ) ;
  }

  @Test
  public void test3855() {
    coral.tests.JPFBenchmark.benchmark06(-6.582583488006961,90.75173317540188,-97.29631899660578 ) ;
  }

  @Test
  public void test3856() {
    coral.tests.JPFBenchmark.benchmark06(6.584911479716226,-79.71051583362686,-0.7432164648927682 ) ;
  }

  @Test
  public void test3857() {
    coral.tests.JPFBenchmark.benchmark06(66.32743138040144,-63.76125527612413,26.10558682917589 ) ;
  }

  @Test
  public void test3858() {
    coral.tests.JPFBenchmark.benchmark06(-66.35289545931099,1.2224043205992814,78.26788097709269 ) ;
  }

  @Test
  public void test3859() {
    coral.tests.JPFBenchmark.benchmark06(-66.63009266617439,-67.78827061869734,-48.04729433360278 ) ;
  }

  @Test
  public void test3860() {
    coral.tests.JPFBenchmark.benchmark06(-6.6663344508844204,-88.61103987869387,51.447615269415394 ) ;
  }

  @Test
  public void test3861() {
    coral.tests.JPFBenchmark.benchmark06(-66.81009239496373,-95.15494788957277,-35.3054754687155 ) ;
  }

  @Test
  public void test3862() {
    coral.tests.JPFBenchmark.benchmark06(-6.681911775230489E-52,-3.9443040132600615E-31,53.805106014150425 ) ;
  }

  @Test
  public void test3863() {
    coral.tests.JPFBenchmark.benchmark06(-66.93323987393305,-49.6294129966921,97.04755263360957 ) ;
  }

  @Test
  public void test3864() {
    coral.tests.JPFBenchmark.benchmark06(6.713820969125746E-17,-0.5370225885827487,53.95127108106867 ) ;
  }

  @Test
  public void test3865() {
    coral.tests.JPFBenchmark.benchmark06(-67.39216235495621,-95.38528499964787,-35.119904604221716 ) ;
  }

  @Test
  public void test3866() {
    coral.tests.JPFBenchmark.benchmark06(-6.754034012229084E-226,-1.57079632679488,-88.63233194453926 ) ;
  }

  @Test
  public void test3867() {
    coral.tests.JPFBenchmark.benchmark06(6.776263578034403E-21,-0.04492300080422407,37.101488968705844 ) ;
  }

  @Test
  public void test3868() {
    coral.tests.JPFBenchmark.benchmark06(-6.776263578034403E-21,-1.5707963267948966,-78.5282614426346 ) ;
  }

  @Test
  public void test3869() {
    coral.tests.JPFBenchmark.benchmark06(6.776263578034403E-21,-19.41105817024321,-78.14810657537632 ) ;
  }

  @Test
  public void test3870() {
    coral.tests.JPFBenchmark.benchmark06(-6.812735744013041E-108,-0.8458624633728673,-0.3832142196926137 ) ;
  }

  @Test
  public void test3871() {
    coral.tests.JPFBenchmark.benchmark06(-68.33314606621359,-68.34382897616244,-94.2405497767538 ) ;
  }

  @Test
  public void test3872() {
    coral.tests.JPFBenchmark.benchmark06(68.36995182664148,-73.00601265313378,-34.150487603617876 ) ;
  }

  @Test
  public void test3873() {
    coral.tests.JPFBenchmark.benchmark06(-68.49498283870956,53.948331209178804,-27.20561838108108 ) ;
  }

  @Test
  public void test3874() {
    coral.tests.JPFBenchmark.benchmark06(-69.04324059471145,5.459615339248529,-64.34530645836054 ) ;
  }

  @Test
  public void test3875() {
    coral.tests.JPFBenchmark.benchmark06(-6.916130828522582E-223,-1.570796326794893,0.7315822096955831 ) ;
  }

  @Test
  public void test3876() {
    coral.tests.JPFBenchmark.benchmark06(6.938893903907228E-18,-0.06461721321328004,-61.809561951148986 ) ;
  }

  @Test
  public void test3877() {
    coral.tests.JPFBenchmark.benchmark06(-6.938893903907228E-18,-0.14860171152164714,143.19246563232696 ) ;
  }

  @Test
  public void test3878() {
    coral.tests.JPFBenchmark.benchmark06(6.938893903907228E-18,-1.2405731573884151,-1.2366151059944526 ) ;
  }

  @Test
  public void test3879() {
    coral.tests.JPFBenchmark.benchmark06(6.938893903907228E-18,-1.493685449210713,2.220446049250313E-16 ) ;
  }

  @Test
  public void test3880() {
    coral.tests.JPFBenchmark.benchmark06(-6.938893903907228E-18,-1.5707946128882755,-92.7409957076878 ) ;
  }

  @Test
  public void test3881() {
    coral.tests.JPFBenchmark.benchmark06(-6.938893903907228E-18,-1.5707961945447713,9.42526328527382 ) ;
  }

  @Test
  public void test3882() {
    coral.tests.JPFBenchmark.benchmark06(6.938893903907228E-18,-1.5707963267948912,-1.5707963267948966 ) ;
  }

  @Test
  public void test3883() {
    coral.tests.JPFBenchmark.benchmark06(-6.938893903907228E-18,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test3884() {
    coral.tests.JPFBenchmark.benchmark06(6.938893903907228E-18,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3885() {
    coral.tests.JPFBenchmark.benchmark06(-6.938893903907228E-18,-32.986722834065574,-9.424779752954459 ) ;
  }

  @Test
  public void test3886() {
    coral.tests.JPFBenchmark.benchmark06(6.938893903907228E-18,-38.93260438740753,-0.0011619848295546702 ) ;
  }

  @Test
  public void test3887() {
    coral.tests.JPFBenchmark.benchmark06(69.54515899961169,-5.925023196962442,0 ) ;
  }

  @Test
  public void test3888() {
    coral.tests.JPFBenchmark.benchmark06(69.65650266937385,42.887987886916875,0 ) ;
  }

  @Test
  public void test3889() {
    coral.tests.JPFBenchmark.benchmark06(-70.0011069755895,84.46233579010826,48.345310759934705 ) ;
  }

  @Test
  public void test3890() {
    coral.tests.JPFBenchmark.benchmark06(70.30517771181391,94.30396209472539,-14.626862111099697 ) ;
  }

  @Test
  public void test3891() {
    coral.tests.JPFBenchmark.benchmark06(-70.33742938827871,43.6144941060312,78.94391773792998 ) ;
  }

  @Test
  public void test3892() {
    coral.tests.JPFBenchmark.benchmark06(-7.044203657368268E-133,-1.5707963267948966,14.7149050673534 ) ;
  }

  @Test
  public void test3893() {
    coral.tests.JPFBenchmark.benchmark06(-7.044203657368268E-133,-1.5707963267948966,31.577814699281838 ) ;
  }

  @Test
  public void test3894() {
    coral.tests.JPFBenchmark.benchmark06(-7.044203657368268E-133,-88.45058909332096,-25.200203706191722 ) ;
  }

  @Test
  public void test3895() {
    coral.tests.JPFBenchmark.benchmark06(-70.52326276174114,-30.084410001528255,-10.212633967514122 ) ;
  }

  @Test
  public void test3896() {
    coral.tests.JPFBenchmark.benchmark06(-7.105427357601002E-15,-0.06293073502848887,-96.72577167926454 ) ;
  }

  @Test
  public void test3897() {
    coral.tests.JPFBenchmark.benchmark06(-7.105427357601002E-15,-0.26979824424678345,-34.92434255206827 ) ;
  }

  @Test
  public void test3898() {
    coral.tests.JPFBenchmark.benchmark06(-7.105427357601002E-15,-0.3499440675555315,0.0 ) ;
  }

  @Test
  public void test3899() {
    coral.tests.JPFBenchmark.benchmark06(-7.105427357601002E-15,-0.484859096684767,33.44234956575934 ) ;
  }

  @Test
  public void test3900() {
    coral.tests.JPFBenchmark.benchmark06(-7.105427357601002E-15,-0.697964868221101,-79.42439411808313 ) ;
  }

  @Test
  public void test3901() {
    coral.tests.JPFBenchmark.benchmark06(-7.105427357601002E-15,-0.9921235847338011,1.1151480014335107 ) ;
  }

  @Test
  public void test3902() {
    coral.tests.JPFBenchmark.benchmark06(-7.105427357601002E-15,-1.17222973053957,25.263151754977173 ) ;
  }

  @Test
  public void test3903() {
    coral.tests.JPFBenchmark.benchmark06(-7.105427357601002E-15,-1.4997869904121828,77.68480418904673 ) ;
  }

  @Test
  public void test3904() {
    coral.tests.JPFBenchmark.benchmark06(-7.105427357601002E-15,-1.5707963267948966,-0.19412757126793828 ) ;
  }

  @Test
  public void test3905() {
    coral.tests.JPFBenchmark.benchmark06(-7.105427357601002E-15,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test3906() {
    coral.tests.JPFBenchmark.benchmark06(-7.105427357601002E-15,-1.5707963267948966,-34.04861406771022 ) ;
  }

  @Test
  public void test3907() {
    coral.tests.JPFBenchmark.benchmark06(-7.105427357601002E-15,-1.5707963267948966,34.68647316445093 ) ;
  }

  @Test
  public void test3908() {
    coral.tests.JPFBenchmark.benchmark06(-7.105427357601002E-15,-1.5707963267948966,86.11109895975112 ) ;
  }

  @Test
  public void test3909() {
    coral.tests.JPFBenchmark.benchmark06(-7.105427357601002E-15,-3.141592653589795,-34.33965260023675 ) ;
  }

  @Test
  public void test3910() {
    coral.tests.JPFBenchmark.benchmark06(-7.105427357601002E-15,-31.784355329758046,-45.50347069369609 ) ;
  }

  @Test
  public void test3911() {
    coral.tests.JPFBenchmark.benchmark06(-7.105427357601002E-15,-88.18068855303841,-42.25028347826252 ) ;
  }

  @Test
  public void test3912() {
    coral.tests.JPFBenchmark.benchmark06(7.105427357601002E-15,-88.3443152982746,-9.520066698703928 ) ;
  }

  @Test
  public void test3913() {
    coral.tests.JPFBenchmark.benchmark06(-7.105427357601002E-15,-9.871031767461413E-178,1.1186924846179274 ) ;
  }

  @Test
  public void test3914() {
    coral.tests.JPFBenchmark.benchmark06(71.32564714990679,23.944630548478017,-87.0559780030324 ) ;
  }

  @Test
  public void test3915() {
    coral.tests.JPFBenchmark.benchmark06(-71.53051446629345,94.68914754559322,30.185018477981572 ) ;
  }

  @Test
  public void test3916() {
    coral.tests.JPFBenchmark.benchmark06(-7.166949076651259E-6,-1.5696577167971448,-2.561839259922335 ) ;
  }

  @Test
  public void test3917() {
    coral.tests.JPFBenchmark.benchmark06(-72.04977162784067,46.66421491961199,60.044883542018056 ) ;
  }

  @Test
  public void test3918() {
    coral.tests.JPFBenchmark.benchmark06(72.14865870317718,78.35268002494232,-0.5750684501778238 ) ;
  }

  @Test
  public void test3919() {
    coral.tests.JPFBenchmark.benchmark06(72.50128281346761,36.84520053839873,52.10195506144376 ) ;
  }

  @Test
  public void test3920() {
    coral.tests.JPFBenchmark.benchmark06(72.58478701867762,-73.91499555289613,61.60630548479705 ) ;
  }

  @Test
  public void test3921() {
    coral.tests.JPFBenchmark.benchmark06(-72.58700730687065,28.491414554329566,0.5560237877930518 ) ;
  }

  @Test
  public void test3922() {
    coral.tests.JPFBenchmark.benchmark06(7.258831376541165E-17,-1.5707963267948966,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test3923() {
    coral.tests.JPFBenchmark.benchmark06(72.73037964130054,-74.61224066011818,-93.8970431832542 ) ;
  }

  @Test
  public void test3924() {
    coral.tests.JPFBenchmark.benchmark06(7.292961121457182,-99.81775398327035,-49.30243568240533 ) ;
  }

  @Test
  public void test3925() {
    coral.tests.JPFBenchmark.benchmark06(-7.308371176884783E-15,-1.5707963267948966,-97.37074042589005 ) ;
  }

  @Test
  public void test3926() {
    coral.tests.JPFBenchmark.benchmark06(-7.323083464821309,-99.3015537818064,15.866608138979686 ) ;
  }

  @Test
  public void test3927() {
    coral.tests.JPFBenchmark.benchmark06(-7.346839692639297E-40,-3.000280543020917E-15,31.786357992290675 ) ;
  }

  @Test
  public void test3928() {
    coral.tests.JPFBenchmark.benchmark06(-7.352446046364092E-4,-1.57078549907611,72.24827924509215 ) ;
  }

  @Test
  public void test3929() {
    coral.tests.JPFBenchmark.benchmark06(73.98000491882476,-46.392444344481774,-87.77582033148622 ) ;
  }

  @Test
  public void test3930() {
    coral.tests.JPFBenchmark.benchmark06(74.0576536930835,-99.12157864554531,-12.69062038827407 ) ;
  }

  @Test
  public void test3931() {
    coral.tests.JPFBenchmark.benchmark06(-74.06985391376807,0,0 ) ;
  }

  @Test
  public void test3932() {
    coral.tests.JPFBenchmark.benchmark06(74.34269593816859,52.34584372274432,-63.427345250025624 ) ;
  }

  @Test
  public void test3933() {
    coral.tests.JPFBenchmark.benchmark06(-7.458188331973091,72.11798415617434,-0.5687805291870518 ) ;
  }

  @Test
  public void test3934() {
    coral.tests.JPFBenchmark.benchmark06(74.5867164944307,-7.838643567798641,-8.364274278330754 ) ;
  }

  @Test
  public void test3935() {
    coral.tests.JPFBenchmark.benchmark06(74.8937491396691,-39.214854636951024,-10.927903642538524 ) ;
  }

  @Test
  public void test3936() {
    coral.tests.JPFBenchmark.benchmark06(-75.15177930183299,-99.42437951719873,-31.78574549699806 ) ;
  }

  @Test
  public void test3937() {
    coral.tests.JPFBenchmark.benchmark06(7.552412253611365E-6,-214.12621366735613,-7.354888998248981 ) ;
  }

  @Test
  public void test3938() {
    coral.tests.JPFBenchmark.benchmark06(75.68841710074523,36.143010396825645,16.657670444900646 ) ;
  }

  @Test
  public void test3939() {
    coral.tests.JPFBenchmark.benchmark06(-75.75791818481648,-56.05019271597376,49.392390770026935 ) ;
  }

  @Test
  public void test3940() {
    coral.tests.JPFBenchmark.benchmark06(-76.38831184813372,-20.708584601206567,17.88611336746486 ) ;
  }

  @Test
  public void test3941() {
    coral.tests.JPFBenchmark.benchmark06(76.60563676992143,-92.10002717675667,-99.95949604797147 ) ;
  }

  @Test
  public void test3942() {
    coral.tests.JPFBenchmark.benchmark06(-7.677869258628789E-4,-1.5707963267948966,40.11772342362886 ) ;
  }

  @Test
  public void test3943() {
    coral.tests.JPFBenchmark.benchmark06(76.79791327848363,51.82472256073632,44.245949304007155 ) ;
  }

  @Test
  public void test3944() {
    coral.tests.JPFBenchmark.benchmark06(-76.88093588511484,-43.72331189206984,45.81438788563065 ) ;
  }

  @Test
  public void test3945() {
    coral.tests.JPFBenchmark.benchmark06(-7.703719777548943E-34,-1.5707963267948966,-40.84070449665193 ) ;
  }

  @Test
  public void test3946() {
    coral.tests.JPFBenchmark.benchmark06(-7.74944334466754,-37.848361001273155,37.37299073348376 ) ;
  }

  @Test
  public void test3947() {
    coral.tests.JPFBenchmark.benchmark06(-77.55029138523331,24.910937107803207,45.3024596909608 ) ;
  }

  @Test
  public void test3948() {
    coral.tests.JPFBenchmark.benchmark06(77.84953150329031,-56.46908074316881,-63.23071684523804 ) ;
  }

  @Test
  public void test3949() {
    coral.tests.JPFBenchmark.benchmark06(-78.69590700148086,77.02323593268204,-45.81017070120539 ) ;
  }

  @Test
  public void test3950() {
    coral.tests.JPFBenchmark.benchmark06(7.888609052210118E-31,-1.5707963267948966,-56.64348969352742 ) ;
  }

  @Test
  public void test3951() {
    coral.tests.JPFBenchmark.benchmark06(-7.888609052210118E-31,-7.69999617913302E-15,-77.49951863080913 ) ;
  }

  @Test
  public void test3952() {
    coral.tests.JPFBenchmark.benchmark06(7.888609052210118E-31,-95.43137589133978,-1.5707963267948966 ) ;
  }

  @Test
  public void test3953() {
    coral.tests.JPFBenchmark.benchmark06(-78.91465493947969,-27.05780355622764,-25.358779653983902 ) ;
  }

  @Test
  public void test3954() {
    coral.tests.JPFBenchmark.benchmark06(-7.896825413969131E-177,-1.4763349382706905,46.837701242372034 ) ;
  }

  @Test
  public void test3955() {
    coral.tests.JPFBenchmark.benchmark06(79.12197950985231,-42.49398385729029,48.41148658790652 ) ;
  }

  @Test
  public void test3956() {
    coral.tests.JPFBenchmark.benchmark06(-7.931068241611404E-118,-1.2972444872594466,-27.752680125185407 ) ;
  }

  @Test
  public void test3957() {
    coral.tests.JPFBenchmark.benchmark06(-7.978510452908593E-5,-1.4128899264001915,39.84317101525235 ) ;
  }

  @Test
  public void test3958() {
    coral.tests.JPFBenchmark.benchmark06(79.7939436282418,71.11952864818434,59.35514192521387 ) ;
  }

  @Test
  public void test3959() {
    coral.tests.JPFBenchmark.benchmark06(79.9063740404616,92.98352669982478,3.0553907049998514 ) ;
  }

  @Test
  public void test3960() {
    coral.tests.JPFBenchmark.benchmark06(79.92111656439107,76.131557221342,13.350896243790672 ) ;
  }

  @Test
  public void test3961() {
    coral.tests.JPFBenchmark.benchmark06(-8.008332380732404E-146,-1.2313073081779384,0.0 ) ;
  }

  @Test
  public void test3962() {
    coral.tests.JPFBenchmark.benchmark06(80.14954783348486,-34.879841197733214,23.306384928564555 ) ;
  }

  @Test
  public void test3963() {
    coral.tests.JPFBenchmark.benchmark06(-8.017441300462561E-10,-1.570796326794893,-78.54058838871272 ) ;
  }

  @Test
  public void test3964() {
    coral.tests.JPFBenchmark.benchmark06(80.1898073787643,-30.63898299292471,-17.063872045473772 ) ;
  }

  @Test
  public void test3965() {
    coral.tests.JPFBenchmark.benchmark06(80.35895970209947,38.6395738347704,45.16128307363553 ) ;
  }

  @Test
  public void test3966() {
    coral.tests.JPFBenchmark.benchmark06(-80.52659226937351,76.6679754063282,69.64109368825427 ) ;
  }

  @Test
  public void test3967() {
    coral.tests.JPFBenchmark.benchmark06(-81.40082205158565,-86.89831045242747,82.00546518945805 ) ;
  }

  @Test
  public void test3968() {
    coral.tests.JPFBenchmark.benchmark06(81.41163506052374,-74.23443796498901,97.5767037385188 ) ;
  }

  @Test
  public void test3969() {
    coral.tests.JPFBenchmark.benchmark06(82.36693830718929,68.95138058491173,-95.39877579351754 ) ;
  }

  @Test
  public void test3970() {
    coral.tests.JPFBenchmark.benchmark06(-8.257068739243912E-13,-1.5707963267948966,-40.84070499233832 ) ;
  }

  @Test
  public void test3971() {
    coral.tests.JPFBenchmark.benchmark06(82.81286463494394,-96.23269522157747,53.64644995598195 ) ;
  }

  @Test
  public void test3972() {
    coral.tests.JPFBenchmark.benchmark06(-82.83540134739589,-54.19739979988212,-68.66153648036892 ) ;
  }

  @Test
  public void test3973() {
    coral.tests.JPFBenchmark.benchmark06(-82.90443229520417,69.1000043702067,-66.64077131903227 ) ;
  }

  @Test
  public void test3974() {
    coral.tests.JPFBenchmark.benchmark06(82.94751964261462,5.0671796523885035,49.52197248749499 ) ;
  }

  @Test
  public void test3975() {
    coral.tests.JPFBenchmark.benchmark06(83.00936118312563,-11.588248497385734,-24.635854712883102 ) ;
  }

  @Test
  public void test3976() {
    coral.tests.JPFBenchmark.benchmark06(8.33414196601943,88.32433667683168,84.11319805126058 ) ;
  }

  @Test
  public void test3977() {
    coral.tests.JPFBenchmark.benchmark06(83.38177321605548,18.48248972327717,4.970019901826376 ) ;
  }

  @Test
  public void test3978() {
    coral.tests.JPFBenchmark.benchmark06(-83.61296086724926,-60.993665611249504,-78.23478570791096 ) ;
  }

  @Test
  public void test3979() {
    coral.tests.JPFBenchmark.benchmark06(-8.411666516263775E-12,-1.5707963267948966,39.29779470372265 ) ;
  }

  @Test
  public void test3980() {
    coral.tests.JPFBenchmark.benchmark06(-84.30300960193142,-12.445378900130748,34.400443437880654 ) ;
  }

  @Test
  public void test3981() {
    coral.tests.JPFBenchmark.benchmark06(84.33689814823225,44.010804938810764,8.248887707292567 ) ;
  }

  @Test
  public void test3982() {
    coral.tests.JPFBenchmark.benchmark06(-84.61127242608875,89.71623577096298,5.636471511270486 ) ;
  }

  @Test
  public void test3983() {
    coral.tests.JPFBenchmark.benchmark06(8.470329472543003E-22,-0.5779749558460019,-5.291358339817428 ) ;
  }

  @Test
  public void test3984() {
    coral.tests.JPFBenchmark.benchmark06(-84.76394807211878,52.95076162842008,58.251686405817736 ) ;
  }

  @Test
  public void test3985() {
    coral.tests.JPFBenchmark.benchmark06(-8.490303963827069E-16,-1.5707963267948966,63.61980019323368 ) ;
  }

  @Test
  public void test3986() {
    coral.tests.JPFBenchmark.benchmark06(84.95031491321436,38.10922624312448,27.72458472049439 ) ;
  }

  @Test
  public void test3987() {
    coral.tests.JPFBenchmark.benchmark06(-8.52478941564886E-255,-38.93484119744868,-63.39993293582047 ) ;
  }

  @Test
  public void test3988() {
    coral.tests.JPFBenchmark.benchmark06(-8.542606190752409E-14,-1.5707963267948966,-31.888308250880787 ) ;
  }

  @Test
  public void test3989() {
    coral.tests.JPFBenchmark.benchmark06(85.6405462979121,27.91975771861415,-50.95261604555217 ) ;
  }

  @Test
  public void test3990() {
    coral.tests.JPFBenchmark.benchmark06(86.10160167432184,-32.45381944572043,-28.57339053449772 ) ;
  }

  @Test
  public void test3991() {
    coral.tests.JPFBenchmark.benchmark06(86.4299152078928,-94.49235317777038,5.3068298722077 ) ;
  }

  @Test
  public void test3992() {
    coral.tests.JPFBenchmark.benchmark06(86.45572000586847,-99.24033738731737,-79.54675751675053 ) ;
  }

  @Test
  public void test3993() {
    coral.tests.JPFBenchmark.benchmark06(86.48245945560058,6.334414202950711,34.555183058307506 ) ;
  }

  @Test
  public void test3994() {
    coral.tests.JPFBenchmark.benchmark06(-8.648516740343426E-16,-2.6355494858076308E-82,-11.499615013704414 ) ;
  }

  @Test
  public void test3995() {
    coral.tests.JPFBenchmark.benchmark06(-8.670506867651255,0,0 ) ;
  }

  @Test
  public void test3996() {
    coral.tests.JPFBenchmark.benchmark06(8.673617379884035E-19,-1.5707963267948528,1.5707963267948966 ) ;
  }

  @Test
  public void test3997() {
    coral.tests.JPFBenchmark.benchmark06(8.673617379884035E-19,-1.5707963267948963,-0.39216233448734633 ) ;
  }

  @Test
  public void test3998() {
    coral.tests.JPFBenchmark.benchmark06(-8.673617379884035E-19,-1.5707963267948966,0.008324233072022888 ) ;
  }

  @Test
  public void test3999() {
    coral.tests.JPFBenchmark.benchmark06(8.673617379884035E-19,-1.5707963267948966,-1.5707963267948948 ) ;
  }

  @Test
  public void test4000() {
    coral.tests.JPFBenchmark.benchmark06(8.673617379884035E-19,-1.5707963267948966,-16.553289987772892 ) ;
  }

  @Test
  public void test4001() {
    coral.tests.JPFBenchmark.benchmark06(-8.673617379884035E-19,-1.5707963267948966,-2.5707963260655533 ) ;
  }

  @Test
  public void test4002() {
    coral.tests.JPFBenchmark.benchmark06(8.673617379884035E-19,-1.5707963267948966,44.40783392949942 ) ;
  }

  @Test
  public void test4003() {
    coral.tests.JPFBenchmark.benchmark06(8.673617379884035E-19,-1.5707963267948966,-45.40212559412193 ) ;
  }

  @Test
  public void test4004() {
    coral.tests.JPFBenchmark.benchmark06(8.673617379884035E-19,-1.5707963267948966,-75.7785103969582 ) ;
  }

  @Test
  public void test4005() {
    coral.tests.JPFBenchmark.benchmark06(87.09958618237891,-21.50226627401048,-95.91670503331997 ) ;
  }

  @Test
  public void test4006() {
    coral.tests.JPFBenchmark.benchmark06(-8.726367194098959E-16,-1.5707963267948966,-40.557672354683845 ) ;
  }

  @Test
  public void test4007() {
    coral.tests.JPFBenchmark.benchmark06(-88.38230492903058,47.84286286694072,-32.36408094395887 ) ;
  }

  @Test
  public void test4008() {
    coral.tests.JPFBenchmark.benchmark06(88.61040450181446,-0.9084535241100866,80.20198051269196 ) ;
  }

  @Test
  public void test4009() {
    coral.tests.JPFBenchmark.benchmark06(-88.61095941548547,-93.0387246421307,-21.17510904630406 ) ;
  }

  @Test
  public void test4010() {
    coral.tests.JPFBenchmark.benchmark06(-8.881784197001252E-16,0,0 ) ;
  }

  @Test
  public void test4011() {
    coral.tests.JPFBenchmark.benchmark06(-8.881784197001252E-16,-0.2677451606553305,31.447319062366972 ) ;
  }

  @Test
  public void test4012() {
    coral.tests.JPFBenchmark.benchmark06(-8.881784197001252E-16,-0.7919550745234158,73.80172781090629 ) ;
  }

  @Test
  public void test4013() {
    coral.tests.JPFBenchmark.benchmark06(-8.881784197001252E-16,-1.5707963262790887,-2.2766261896336957 ) ;
  }

  @Test
  public void test4014() {
    coral.tests.JPFBenchmark.benchmark06(-8.881784197001252E-16,-1.5707963267948966,172.78759596853328 ) ;
  }

  @Test
  public void test4015() {
    coral.tests.JPFBenchmark.benchmark06(-8.881784197001252E-16,-1.5707963267948966,-33.47836624483014 ) ;
  }

  @Test
  public void test4016() {
    coral.tests.JPFBenchmark.benchmark06(-8.881784197001252E-16,-1.5707963267948966,34.12987187016273 ) ;
  }

  @Test
  public void test4017() {
    coral.tests.JPFBenchmark.benchmark06(-8.881784197001252E-16,-1.5707963267948966,-66.32424305906412 ) ;
  }

  @Test
  public void test4018() {
    coral.tests.JPFBenchmark.benchmark06(-8.881784197001252E-16,-1.5707963267948983,100.0 ) ;
  }

  @Test
  public void test4019() {
    coral.tests.JPFBenchmark.benchmark06(-8.881784197001252E-16,-38.72718506457397,-1.5707963267948977 ) ;
  }

  @Test
  public void test4020() {
    coral.tests.JPFBenchmark.benchmark06(-8.881784197001252E-16,-76.17409343942835,0 ) ;
  }

  @Test
  public void test4021() {
    coral.tests.JPFBenchmark.benchmark06(88.85160223800003,82.12432338508177,53.25614458441282 ) ;
  }

  @Test
  public void test4022() {
    coral.tests.JPFBenchmark.benchmark06(-8.887837244833872E-16,3.944304526105059E-31,-34.97371389971431 ) ;
  }

  @Test
  public void test4023() {
    coral.tests.JPFBenchmark.benchmark06(-8.889151509157497E-18,-0.9501855700003348,-1.5707963267948983 ) ;
  }

  @Test
  public void test4024() {
    coral.tests.JPFBenchmark.benchmark06(-89.06422431076358,-19.635790753211225,-40.65901294145806 ) ;
  }

  @Test
  public void test4025() {
    coral.tests.JPFBenchmark.benchmark06(-89.6405328469657,-55.935173771538025,80.23302684922672 ) ;
  }

  @Test
  public void test4026() {
    coral.tests.JPFBenchmark.benchmark06(-8.977492651650722E-6,-32.98672278323768,-9.420891677364358 ) ;
  }

  @Test
  public void test4027() {
    coral.tests.JPFBenchmark.benchmark06(-89.78451938269514,-24.623024197713832,-77.04344537756798 ) ;
  }

  @Test
  public void test4028() {
    coral.tests.JPFBenchmark.benchmark06(90.03059285138443,25.573038887196844,-94.89131193880263 ) ;
  }

  @Test
  public void test4029() {
    coral.tests.JPFBenchmark.benchmark06(90.18469434290054,-62.07262986560536,8.529530855014485 ) ;
  }

  @Test
  public void test4030() {
    coral.tests.JPFBenchmark.benchmark06(90.29637513115466,33.22882349915341,-23.182432022826262 ) ;
  }

  @Test
  public void test4031() {
    coral.tests.JPFBenchmark.benchmark06(90.38631598127117,49.587846094464,36.960691390724605 ) ;
  }

  @Test
  public void test4032() {
    coral.tests.JPFBenchmark.benchmark06(-90.4256347196747,23.834364987916203,-97.88349232204077 ) ;
  }

  @Test
  public void test4033() {
    coral.tests.JPFBenchmark.benchmark06(90.62486153716887,29.860458962843637,73.79791346126265 ) ;
  }

  @Test
  public void test4034() {
    coral.tests.JPFBenchmark.benchmark06(90.76110409835377,10.533703178726924,-55.67615994003019 ) ;
  }

  @Test
  public void test4035() {
    coral.tests.JPFBenchmark.benchmark06(-91.14847806436661,0,0 ) ;
  }

  @Test
  public void test4036() {
    coral.tests.JPFBenchmark.benchmark06(91.30342312337243,-27.828189877418282,1.8206181746397476 ) ;
  }

  @Test
  public void test4037() {
    coral.tests.JPFBenchmark.benchmark06(-91.43358388073479,64.73266595152128,-94.80877968108065 ) ;
  }

  @Test
  public void test4038() {
    coral.tests.JPFBenchmark.benchmark06(-9.1438991302582E-100,-1.5707963267948966,-65.65450688306159 ) ;
  }

  @Test
  public void test4039() {
    coral.tests.JPFBenchmark.benchmark06(-9.147809681869614E-15,-164.92849263153568,-1.5707963267948966 ) ;
  }

  @Test
  public void test4040() {
    coral.tests.JPFBenchmark.benchmark06(91.53250389599225,-66.56330993116369,-88.55795758580331 ) ;
  }

  @Test
  public void test4041() {
    coral.tests.JPFBenchmark.benchmark06(91.84170561862334,51.08963633097642,46.7182161029738 ) ;
  }

  @Test
  public void test4042() {
    coral.tests.JPFBenchmark.benchmark06(-92.210902590744,-24.940178548236844,21.185841395902997 ) ;
  }

  @Test
  public void test4043() {
    coral.tests.JPFBenchmark.benchmark06(-92.67181320203066,26.230287635283545,94.1822876088155 ) ;
  }

  @Test
  public void test4044() {
    coral.tests.JPFBenchmark.benchmark06(-9.273015376718553E-69,-0.7489544956206539,63.922651062162004 ) ;
  }

  @Test
  public void test4045() {
    coral.tests.JPFBenchmark.benchmark06(-92.73302295267108,97.41513231734186,2.5949535190067365 ) ;
  }

  @Test
  public void test4046() {
    coral.tests.JPFBenchmark.benchmark06(-93.37646032076667,87.49587202086673,9.632367389265426 ) ;
  }

  @Test
  public void test4047() {
    coral.tests.JPFBenchmark.benchmark06(-93.51048300290425,-97.5142772237581,-18.42782548481732 ) ;
  }

  @Test
  public void test4048() {
    coral.tests.JPFBenchmark.benchmark06(-93.72686971990119,-1.5095237468207188,93.70191081734194 ) ;
  }

  @Test
  public void test4049() {
    coral.tests.JPFBenchmark.benchmark06(-93.78998247672648,-57.88198951741725,-4.138667318272056 ) ;
  }

  @Test
  public void test4050() {
    coral.tests.JPFBenchmark.benchmark06(93.82672943357218,46.908918975108946,-1.9584596637449891 ) ;
  }

  @Test
  public void test4051() {
    coral.tests.JPFBenchmark.benchmark06(-9.455854017283955E-5,-1.5707963267948966,-116.19165585827203 ) ;
  }

  @Test
  public void test4052() {
    coral.tests.JPFBenchmark.benchmark06(94.73742644128521,68.02830453956969,37.721303420980206 ) ;
  }

  @Test
  public void test4053() {
    coral.tests.JPFBenchmark.benchmark06(-94.90529145047529,88.19169556795288,-42.56588083823285 ) ;
  }

  @Test
  public void test4054() {
    coral.tests.JPFBenchmark.benchmark06(-9.495567745759799E-66,-1.5707963267948966,-45.369818868668915 ) ;
  }

  @Test
  public void test4055() {
    coral.tests.JPFBenchmark.benchmark06(-95.06683027334606,-87.55900667682015,24.062533590863993 ) ;
  }

  @Test
  public void test4056() {
    coral.tests.JPFBenchmark.benchmark06(9.508667585243582E-17,-0.692292701874886,24.811967888860842 ) ;
  }

  @Test
  public void test4057() {
    coral.tests.JPFBenchmark.benchmark06(9.513673074991519E-17,-0.3446485274961688,1.9148520172307035 ) ;
  }

  @Test
  public void test4058() {
    coral.tests.JPFBenchmark.benchmark06(-95.69425127298518,32.14994245049917,55.136064807849465 ) ;
  }

  @Test
  public void test4059() {
    coral.tests.JPFBenchmark.benchmark06(95.72937700958983,-67.59213043449131,99.15283779507965 ) ;
  }

  @Test
  public void test4060() {
    coral.tests.JPFBenchmark.benchmark06(95.81026820094672,74.7774426599627,-2.606914029229074 ) ;
  }

  @Test
  public void test4061() {
    coral.tests.JPFBenchmark.benchmark06(-96.09097013583943,49.87852701445951,-97.23480183524961 ) ;
  }

  @Test
  public void test4062() {
    coral.tests.JPFBenchmark.benchmark06(9.625080753398611E-17,-0.8027230144040608,0.0 ) ;
  }

  @Test
  public void test4063() {
    coral.tests.JPFBenchmark.benchmark06(-9.661643796883866E-14,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test4064() {
    coral.tests.JPFBenchmark.benchmark06(-97.21395770915528,62.48863375677587,-22.394916892353535 ) ;
  }

  @Test
  public void test4065() {
    coral.tests.JPFBenchmark.benchmark06(-9.7328303810303E-18,-0.08474468048721873,-1.5707963267948966 ) ;
  }

  @Test
  public void test4066() {
    coral.tests.JPFBenchmark.benchmark06(-9.746296227149618E-14,-1.5707963267948966,-31.79808550496653 ) ;
  }

  @Test
  public void test4067() {
    coral.tests.JPFBenchmark.benchmark06(-9.775796363198735E-150,-1.4926486293615844,-39.06414874442642 ) ;
  }

  @Test
  public void test4068() {
    coral.tests.JPFBenchmark.benchmark06(98.17263505181978,-65.12312283853319,93.90784303523628 ) ;
  }

  @Test
  public void test4069() {
    coral.tests.JPFBenchmark.benchmark06(9.860761315262648E-32,-1.5707963267948966,-26.88714212439921 ) ;
  }

  @Test
  public void test4070() {
    coral.tests.JPFBenchmark.benchmark06(9.860761315262648E-32,-1.5707963267948966,-79.2423608611576 ) ;
  }

  @Test
  public void test4071() {
    coral.tests.JPFBenchmark.benchmark06(-98.71637443522286,72.38324141814209,-99.89364502329059 ) ;
  }

  @Test
  public void test4072() {
    coral.tests.JPFBenchmark.benchmark06(-98.74887214680498,2.9647555486720876,-22.88097369473114 ) ;
  }

  @Test
  public void test4073() {
    coral.tests.JPFBenchmark.benchmark06(-9.976849812414318E-5,-95.30382754304541,-164.46043568783404 ) ;
  }
}
