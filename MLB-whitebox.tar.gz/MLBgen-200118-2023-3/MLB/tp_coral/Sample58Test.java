import org.junit.Test;

public class Sample58Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-1.0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark58(0.0,100.0,-1.0,0.3089852781660577,-4.134236643835735 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-1.0,0.042974368405089614,-36.551935143945705 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-1.0,-0.5556075985286384,3.944304526105059E-31 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-1.0,11.831818719183676,-15.054388919409075 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-1.0,-1347.134195863469,1161.5910482207855 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-1.0,-1375.203533888285,1170.953407719011 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-1.0,-17.880336782041564,0.08785048883265745 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-1.0,22.433952659256846,-30.169099992548784 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-1.0,-24.45815946180015,3.410001453038916 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-1.0,30.608040091614498,-42.76163698891204 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-10.333136878684485,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-1.0,3.679688961394247E-15,0.0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-1.0,44.2381670619061,-65.29836420045069 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-1.0,51.83838161977269,-20.568188591292003 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-1.0,56.13488282856737,-74.4654792119361 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-1.0,-70.99967929474539,18.20337110472437 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-1.0,-8.252507453749135E-171,1.4772765788457177E-126 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-1.0,-97.8141047254739,-54.02399978724478 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-2.4088667013288045,0,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-2441.1662271954924,0,0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-5.551115123125783E-17,0,0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark58(0,0,58.65143927248329,41.95277375041189,-8.081196386541905 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-586.5218140905293,0,0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-63.89255870392054,0,0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-6.61750051600913,0,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark58(0,0,77.85008080543449,-22.123039219273565,-50.72238637721034 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-85.63002882775423,0,0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark58(0,0,86.16185993142099,0,0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-95.9784316333067,0,0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-9.725851282962196,0,0 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark58(0,100.0,-0.9999999999999999,43.14367264264001,-44.6360800968389 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark58(0,100.0,-1.0,-0.8499991173470669,0.01084839961028601 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark58(0,-100.0,-1.0,-13.460262946497231,0.02189085131037757 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark58(0,100.0,-1.0,14.356214108898115,-15.856214108898115 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark58(0,-100.0,-1.0,-1.564251592933075,0.06425159293307482 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark58(0,100.0,-1.0,-2.3978137039003697,-0.7457320842060584 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark58(0,-100.0,-1.0,-79.76550375612972,0.01969267732072945 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark58(0,-12.004788392846145,-1.0,-42.34577576140674,4.689582056016661E-13 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark58(0,13.226531283307978,-1.0,-1.5637876504062973,1.0044818594051297 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark58(0,-133.6848025319805,-1.0,8.171241461241152E-14,-2316.3099395327936 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark58(0,-13.453314581266724,90.07944448881392,-73.54363178629558,6.229144752588951 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark58(0,-19.090946340405324,-1.0,0.10900921980707778,-14.409756620355914 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark58(0,-19.716390765884512,-1.0,-2.299984774579592,0.5985266528163005 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark58(0,2.4482752368162704,-1.0,0.018617061067877243,-75.00115706112729 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark58(0,-25.047440887705182,-1.0,-33.29241874559949,0.0037720861582490883 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark58(0,-25.32594211315303,-1.0,-4.823829439846602,3.253033113051705 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark58(0,-31.170711969692757,-1.0,3.469446951953614E-18,-393.98015401914915 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark58(0,-32.119744236884586,-1.0,-1.6158899459152911,1.4349200751643298 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark58(0,-34.37195172436577,-1.0,0.018010662461216853,-26.49007054510362 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark58(0,34.63410318098644,-1.0,0.021306535507340407,-73.7236856857246 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark58(0,-35.667540473585134,-1.0,-49.873017681297895,-0.3216684493439016 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark58(0,-38.22687448464265,-1.0,-0.8383855243587179,0.8383855243587179 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark58(0,-43.25454656663232,-1.0,0.020545805346087853,-76.45338307918861 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark58(0,-44.92586542754239,-1.0,-3.4090019281081645,1.9090019281081647 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark58(0,45.837880514938384,-1.0,-16.67474023003273,3.552713678800501E-15 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark58(0,46.393726040742266,-1.0,-2.259916713708344,0.6891203869134476 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark58(0,58.113584102114125,-1.0,3.8869679088196934E-17,-3.3161255394084037 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark58(0,59.09442754733681,-79.62063653600038,-74.73698681385765,-25.698784177648434 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark58(0,-59.32810099886509,-1.0,-1.6727440817393928,0.9123235534157701 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark58(0,-60.425607209802706,-1.0,-0.3208056237468959,4.8964114420703595 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark58(0,69.71841931051978,-1.0,0.4432650427057483,-2.014061369500645 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark58(0,70.22265233503673,-1.0,0.27221028589861795,-1.8430066126935145 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark58(0,70.60866340898345,-1.0,-4.572688009654729,4.5726880100207765 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark58(0,-73.63132818848051,-1.0,0.02453860294771637,-64.01327451858872 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark58(0,82.2091636402632,-1.0,4.056988413476574,-4.056988415091301 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark58(0,-83.12598208835703,-1.0,-84.29354967043582,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark58(0,-85.18955349115456,-0.9999999999999997,-16.30967963828403,0.09631067940217078 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark58(0,9.081601247913909,-1.0,-83.49271960335568,0.018813572419933033 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark58(0,-92.16259887889358,-1.0,14.830101303626963,-16.400481458769896 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark58(0,-93.04684697719875,-1.0,-0.028331266204413435,52.16402135729432 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark58(0,-9.868329244966233,-1.0,0.3541955287912373,-4.43482822088545 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark58(-100.0,0.03812626281296616,-1.0,5.521736324972025E-16,-15.723782635560553 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark58(-100.0,-100.0,-1.0,-6.652770895759201,0.05555909440789297 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark58(-100.0,-100.0,-1.0,-73.16306007534688,0.02146980081440475 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark58(-100.0,11.020015299711972,-1.0,-16.649042909260842,0.09434754510249377 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark58(-100.0,-19.458212083702904,-1.0,0.35125909112275666,-3.7356352147741454 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark58(-100.0,-47.06771019926863,-1.0,-4.448593134706134,0.051519418312815896 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark58(-100.0,-87.97675006939019,-1.0,0.2089672654706594,-7.2407781488985465 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark58(-1.0058931711578813,-53.78209666795364,-1.0,-79.05156834758805,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark58(-12.11252904481428,-2.203529769063124,-85.63256813227285,-17.62249011543291,-61.709463143687856 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark58(-1.4210854715202004E-14,100.0,-1.0,0.037216365765616155,-42.20713910346772 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark58(-17.191577920279805,-4.537755693907574,-1.0,0.04073285208963279,-23.1471209909599 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark58(-176.75528343282735,100.0,-1.0,0.1417171957169493,-6.64883008712883 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark58(-18.50183752496705,27.61476495357494,-1.0,0.022490173570790084,-69.8436729201148 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark58(-21.65554158553719,48.906908038211256,-1.0,-4.3646584680709815,0.14214203760939426 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark58(-26.358919743320644,-4.564697377019391,-1.0,-32.06806796501142,1.3983374795304886E-6 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark58(-27.611215916954606,-31.99997774431378,-1.0,-35.77878608019303,0.04390300786823431 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark58(-2.9180749513874855,-26.660660978459568,-1.0,-22.901507009884153,0.06845024370218097 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark58(-31.51754165713348,62.906743495875254,-1.0,-3.7123232715221377,0.25358136997233327 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark58(-32.2208115210245,97.20130537302501,-1.0,0.4012837649783529,-3.8721729281814206 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark58(-32.24160777334822,-75.06720599524475,-1.0,-13.683755627225473,0.09253163091516498 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark58(-34.27655918365956,-9.597790964044354,-0.9999999999999982,-78.61250916306882,0.019981506041697017 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark58(-3.50741115616553,-10.958156754848735,-1.0,8.881784197001252E-16,-10.629549216149549 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark58(-3.837073080190784E-36,-77.76834317018154,-1.0,0.045145414991171195,-13.838162793624912 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark58(-41.43910998772999,0.12627710055498653,-1.0,-4.398042827279322,0.07491361017069642 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark58(-4.173855652925271,18.550628098847692,-1.0,6.938893903907228E-18,-57.70374306003219 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark58(4.402817797305871,-1.5826040863360609,-1.0,-23.223344645295317,0.044930261011160155 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark58(-44.81476411485114,-31.61297066863924,-1.0,-4.420785182809522,0.18713726030034716 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark58(-4.489107959945919,44.459688053195755,-1.0,0.02631739153846878,-16.305686047378494 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark58(-47.0129777030588,83.39214403425403,-1.0,-57.45065150705972,0.0251849197437527 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark58(-47.777073471129796,-90.24426216818402,-1.0,-7.546767946154656,0.1251464143241976 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark58(-47.842467383479196,22.673071239346385,-1.0,-7.567730572056856,1.3872866447884834E-16 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark58(-51.7551711561847,-38.634173831880275,-1.0,-23.30177584122083,0.05942569820555173 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark58(-5.64698438580417,-52.48168884743607,-1.0,5.743057914946151E-5,-7.418742991748942 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark58(-56.98395840190025,66.95099761542338,-1.0,0.07813018199014365,-20.104859438226264 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark58(63.75920880166617,47.655221277626325,-1.0,-45.51476304442714,0.03451179840838972 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark58(-71.1135504803129,-33.419747044719216,-1.0,-7.276540205234246,0.15896480780533367 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark58(-7.169107144981197,-18.772154727454158,-1.0,0.23101099148465096,-6.762678628419325 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark58(72.52344838284321,34.126686875680775,-17.858291386245483,75.14373848895565,6.749862167751502 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark58(-75.80675942243823,-39.987909162463936,-1.0,-4.644384878157296,0.2071171322832668 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark58(-7.888609052210118E-31,-100.0,-1.0,-4.13222747932477,2.289910014946395E-43 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark58(80.8700807448754,-92.62325216244433,-1.0,-4.4875305596808035,0.055085835695796836 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark58(81.97997372586366,55.13748036951602,-1.0,-3.328832802855306,0.019398171825802397 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark58(-83.90853958337671,100.0,-1.0,-4.236806354955801,0.317386701173491 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark58(-87.99497014242637,-51.875297794053644,-1.0,-7.428027403676076,0.21146883841832897 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark58(-89.00687729457337,-68.2536145271729,-1.0,0.34347408122952316,-4.573260145778569 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark58(-92.090594594969,14.649100403951634,-1.0,0.3181993897715707,-4.936515836571971 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark58(-92.58334438839998,-72.32537915189215,-1.0,0.0330812879464959,-15.80632260654258 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark58(-99.98443881076822,-80.46105531804957,-1.0,5.551115123125783E-17,-6.826762890978889 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark58(-99.99999272588869,-99.99999076605818,-1.0,-3.782638814470394,0.20443678687597558 ) ;
  }
}
