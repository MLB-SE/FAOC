import org.junit.Test;

public class Sample53Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.0015474998778631894,0.28110540642475357 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.005970355939180827,1.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.007931713360411331,-1.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.013623368214079208,0.3637064425318669 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.015100909157780841,-0.6696904237610566 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.016058114712004863,-14.195644794959284 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.02192289456587121,1.0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.023117455776147544,-1.0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.023943572323572256,89.0655144074961 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.024786945820692186,-0.2362044173870217 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.0827041585416412,-1.3354145230485863 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.09417435676627717,0.02323377677580653 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.17205941982374656,1.0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.27881067083862043,-0.7691240248035509 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.2946205937910757,-0.05168631376160365 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.31057204998428717,-5.398940542304857 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.3432387259310826,-0.9999999932721896 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark53(0.0036354311019526422,-1.5321535039864413,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.39720068680140586,-0.9747564444423356 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.4050889836930346,-8.498924840076166 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.4139449414594491,-4.2212712576431773E-227 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.4313181196184315,-1.0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.4539447788469367,-2339.9640646963476 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.46842009234168436,44.13806644394893 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.47083089466253014,-1.0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.5124160931608657,1.0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.5162117791084325,-1.0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.5233236624274151,-81.81405446397639 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.5282379493596048,1.7859177988785547E-102 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.5466579269105694,-0.009716121659103833 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.5468849127353654,-1.0 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.5470181652350272,-1.0 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.5675112940625411,-82.80662321608978 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.5873387379736141,-0.9999999999999982 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.6219493353804119,1.0 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.6257412654218489,0.34512195182401056 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.6439103262755168,66.2150010533704 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.6699445883083779,-58.40410734276871 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.6764518717374681,-15.763000289264154 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.7097079120366803,1.0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.7133744379957345,0.0 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.7643566320201187,0.1758132025740764 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.771466069842792,-1.0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.7824792307690202,0.5881237776327692 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.7959343494080922,0.0 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.837919779472372,1.0 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.8429744308626798,-1.0 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.9251168923262656,-2.1026977209495925 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.9571866635854598,-8.178928010583906E-16 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.9798203065366884,0 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.9962178390140126,11.900176701314157 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.9969544321425214,-2.264166609534886 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.0104983806148014,28.498353129376675 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.0191116111608025,-66.88791206212369 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.0223893103191921,1627.1624655897228 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.0224386034183794,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.0286335042535264,4.108231545055726E-16 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.0622266415109938,-44.38425138925499 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.0726980261464103,100.0 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.0944763567867577,1.0 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.1256171368120529,-1.0 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.1291561449645644,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.170621455937723,9.860761315262648E-32 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.1770184958619154,-23.780511854540517 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.218319445563326,-0.9998882713981443 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.2682406182225905,-0.035865090443041585 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.2918575979335651,-1.0000000063384258 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.3262478276664984,-4.2427959310118334E-16 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.327991821910027,0 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.3433603636027078,1.0 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.35486995406096,-0.013569653915930324 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.359030085337581,0.8691760358702179 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.360900188383346,4.622792873190454 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.3879996361411377,12.414860790778022 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.4127704265175107,0.04449590873236846 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.429474966882858,1.0 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.4309840784137653,0.8786595098073596 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.4470102636916724,-1.0 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.4544335180689814,0.054109366184569324 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.4762712451710933,1.0000000000000004 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.4990347225543472,-0.038446214796997946 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5007691236888647,54.14671423724883 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5185308308474226,-1.0 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5365429856925563,1.0 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5429499544901881,57.05791002389722 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5506762411427686,57.41108951227346 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5613454448614055,-1.000000000000013 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5618246245378606,19.861969717018525 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.562498302109758,0.8966466196691439 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.564579055136102,1.0 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5648518600697305,-1.0 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.568916070384786,-1878.9804501918702 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.570796167611229,1.0000000007989243 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5707963267893823,-18.04321222167434 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5707963267946,-0.15149246999031585 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5707963267946623,-0.9999999999999971 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.570796326794778,0.5946166812306608 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5707963267948921,0.9999999999999972 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5707963267948948,-0.4499118941141361 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5707963267948948,0.6224454984384697 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5707963267948948,-1.0 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5707963267948948,-96.93064022996808 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5707963267948957,-0.9946888484981629 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5707963267948957,1.0 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5707963267948961,0.3579653537548133 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5707963267948961,-0.6523930424732842 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5707963267948961,-0.9874703080124876 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5707963267948961,38.3158086651944 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5707963267948963,1.0 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5707963267948963,1.6940658945086007E-21 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5707963267948963,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark53(0,-0.1628020708480875,0 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.6520077040712068E-15,0.8385885462968303 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.6974484861525032E-9,-1.0 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.7763568394002505E-15,1465.2051931411586 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.874935677187402E-6,1.0000000000000002 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.9777894136200245E-9,1.4596459385098883 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-2.220446049250313E-16,0.06255254544543934 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-2.220446049250313E-16,27.104661297557538 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark53(0.0,2.465190328815662E-32,0 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-2.674660536091526E-10,1.0 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-2.716154612436E-312,0 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark53(0.0305928127159234,-1.266499237808489,0 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-3.101408944320927E-12,1.0 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-3.569993855628769E-5,-64.2880362420202 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark53(0,-0.38145648518666064,0 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark53(0,-0.6380718837309445,0 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark53(0,-0.6927851255386734,0 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-7.00939849756248E-4,-85.17408742459203 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-7.264153259117387E-16,52.798612182366256 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-7.433982542680269E-15,-0.032406882975938966 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark53(0,-0.8545948186017887,0 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark53(0,-0.8586551692219615,0 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-8.881784197001252E-16,6.2200193570868265 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark53(0,-1.0341240762868895,0 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark53(0.11081311211439981,-0.8717747663506543,0 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark53(0,-1.2059119194820835,0 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark53(0.1279832867508147,-0.026875202747591424,0 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark53(0.1322265381558716,-5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark53(0.1334691675406101,-0.6504882515737634,0 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark53(0,-1.3567293002531389,0 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark53(0,-1.3877787807814457E-17,0 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark53(0,-1.3891650094589352,0 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark53(0,-1.4056439621150218,0 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark53(0.144311859442532,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark53(0,-1.5,0 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark53(-0.15151039025499557,-0.11591895434543645,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark53(0,-15.387372941562447,0 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark53(0,-1.5546541925267832,0 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark53(0.15679009891861995,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark53(0,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark53(0,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark53(0.1637419170468113,-0.40987284650727956,0 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark53(0.18692124326035997,-0.142494465756203,0 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark53(0,-19.1479509863359,0 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark53(0.19241990465381442,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark53(0.2487040376388686,-1.1079404637396149,0 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark53(0.25818973656642186,-1.1693760362471863,0 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark53(0,-2630.1961173070417,0 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark53(0,-2733.14599401261,0 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark53(0,-2.828605071514147,0 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark53(0.3247914151367166,-1.4157962831015407,0 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark53(0.3284644320182223,-9.538075757083787E-8,0 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark53(0.3292670559794386,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark53(0.329481052559629,-0.27992168133221373,0 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark53(0.3655489239485914,-1.92140722542874E-5,0 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark53(0.3786274209897016,-3.909643296711634E-5,0 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark53(0.43739450417628056,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark53(0.45802694664662624,-0.6891872705566175,0 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark53(0,4.599857087817556E-17,0 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark53(0.46698449056532354,-0.09578252629355921,0 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark53(0.46943667780426945,-0.10709339579186405,0 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark53(0.4784443553924662,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark53(0,-4.9E-324,0 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark53(0,52.254384044454525,0 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark53(0.5289198919457547,-1.5707963267948912,0 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark53(0,5.295321894686069,0 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark53(0.5670978157868944,-0.34972974319390104,0 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark53(0.5759337112323237,-1.5707963267948843,0 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark53(0,-62.24217511436756,0 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark53(-0.6235010212011737,-1.7646352906192405E-5,0.7660052842219933 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark53(0.6361425105169989,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark53(0.6647571670705048,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark53(0.6678273261864263,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark53(0.681790950933519,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark53(-0.6856379009081195,-0.2893737807863619,-1.0 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark53(0.6917056036496234,-0.4420631324309575,0 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark53(0.6938937917058141,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark53(0.7313737895179413,-0.02169193898591626,0 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark53(0.7536545745063258,-1.1273746515437253,0 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark53(0.7695241284694799,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark53(0,-80.8491088328548,0 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark53(0,-81.7380830613241,0 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark53(0,-84.4882097429194,0 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark53(0,-8.49097219591863,0 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark53(0.8570820363052292,-1.492110459704722,0 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark53(0.8651295634972129,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark53(0.9090601772843598,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark53(0.9183117848236009,-1.171044377529324,0 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark53(0,-92.03461604771176,0 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark53(0.9284023827762939,-0.5944249254146605,0 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark53(0,-94.8979217445772,0 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark53(0.9583262976712934,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark53(0,-96.8069474643432,0 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark53(0.9771519432874669,-0.7809585904809185,0 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.003623807106180457,0 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.006675320139569189,0 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.014327524457550948,0 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.03028868984208244,0 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.03641871827638932,0 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.05741943077994516,0 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.08021324795376822,0 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.09176376108676831,0 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.09848356263245472,0 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.12731846212525738,0 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-0.15200970593861773,-1.2689709186578246E-116 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.1724797494571062,0 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.2450235608385481,0 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.25685818746995603,0 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.2588382113876806,0 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.2634859579302429,0 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.28540810399317595,0 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.34611962711271665,0 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.3844098745006093,0 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.39287067051635977,0 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.3971479376495589,0 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.41701320523227214,0 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.43127261428308117,0 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.43950998795036705,0 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.44797599986789405,0 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.4792231898560988,0 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.5228313134242573,0 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.5292388949927629,0 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.6033697537202295,0 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.6568124435254347,0 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.7186478884156804,0 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.8082237163749346,0 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.8485909278658778,0 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.8521958066430821,0 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.8643716051898043,0 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.8785750121912456,0 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.9087959312835947,0 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.9380624367740095,0 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.978690673582039,0 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.9854890270833048,0 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-1.1132739762861241,-1.0 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.122588512621913E-6,0 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.1512219453940486E-6,0 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.1652822405917315E-7,0 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.293926191612363,0 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.3023418464144112E-4,0 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-1.3030246422090026,-1.0 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.3258308345828314,0 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-1.3601363037000812E-8,-0.9999999785358236 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.3816152947644724,0 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.4144695866069434,0 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.4171901779593385,0 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.4181358846827082E-9,0 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-1.4327061014426912,0.6200297685291258 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.443884003998495,0 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.4714960601225722,0 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.47582401982692,0 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-1.4860819557254488,1.0 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.4958632058760477E-9,0 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.5520807615960655,0 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.5523310363642573,0 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.5707963147338935,0 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.5707963267308669,0 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.5707963267948273,0 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.57079632679487,0 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.5707963267948726,0 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.570796326794882,0 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.5707963267948877,0 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.5707963267948895,0 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.5707963267948912,0 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.570796326794893,0 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-1.5707963267948957,-0.1682170576236146 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.7712177539582202E-6,0 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-2.0491476731800843E-10,1.0003823613833254 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-2.220446049250313E-16,1.0 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-2.257501175957292E-9,0 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-2.425863810352223E-16,0 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-2.7486375670836617E-7,0 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-2.9403295056528367E-9,0 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-4.0124005141592455E-4,0 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-5.271430761502126E-16,0 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-5.341840952298958E-9,0 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-5.795743502340947E-10,0 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-5.865107030685785E-9,0 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-6.440345314693146E-10,0 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-6.831587960980904E-9,0 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-7.038906131235868E-6,0 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-7.710115897525485E-16,0 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark53(10.00875519877815,-0.08626090051734747,0 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-8.763469035522797E-7,0 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-8.881784197001252E-16,100.0 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-9.10930587071366E-6,0 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-9.275127443543357E-10,0 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark53(10.014343775107521,-0.00793489406277359,0 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark53(10.040152177173823,-0.9936946277364149,0 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark53(10.095351151602546,-1.570796326794814,0 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark53(1.0101191103470635E-22,-9.452134362977883E-7,26.799313037349503 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark53(10.153945793986278,-2.4477332197597507E-5,0 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark53(10.170552242418026,-0.14012238784250997,0 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark53(1.018680833023776,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark53(10.205196174013281,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark53(10.209444306987223,-0.5569513285921399,0 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark53(1.034459200738013,-0.5465201657426857,0 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark53(10.356731284910836,-1.2848200415991045,0 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark53(10.36172746302924,-2.867990858034926E-9,0 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark53(10.368647924363511,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark53(10.425615205652402,-7.379445940559531E-10,0 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark53(10.513245243916623,-3.6155001520743984E-9,0 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark53(10.531164358662522,-0.24670511672636053,0 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark53(10.553453361862239,-1.5681124447247503,0 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark53(1.0631311440628508,-0.3102389060375157,0 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark53(10.684074946343046,-1.001499254561434,0 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark53(10.71976263527587,-0.12964363591354644,0 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark53(10.76069897878051,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark53(10.763076649113048,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark53(10.837404702440299,-1.078420640188848,0 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark53(10.848018854193626,-0.22435491505830196,0 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark53(10.852027892580216,-0.9151637250808022,0 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark53(10.8824531686045,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark53(10.942556554185472,-0.41469385871009834,0 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark53(10.945950847914517,-0.583429258356938,0 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark53(10.947157942652254,-0.9178771271092248,0 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark53(10.967886580722876,-0.39083664803862916,0 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark53(-10.978611780609544,-1.5707963267948961,-1.0 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark53(10.988176321459578,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark53(11.041232640167593,-0.4678643977917858,0 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark53(11.043556463992301,-1.5688386576266282,0 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark53(11.096214512540087,-1.4986303622719372,0 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark53(1.1102230246251565E-16,-0.8164061016792843,0 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark53(11.110149101751858,-0.7462824731670299,0 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark53(11.166285029118818,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark53(11.317346209815257,-7.285625459767971E-9,0 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark53(11.318879890996644,-0.8682277041154074,0 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark53(11.33124748314189,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark53(11.378299248177772,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark53(-11.409303953481052,-9.716813360915956E-7,1.0 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark53(11.464975992747341,-1.3319330122321915,0 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark53(11.58213516012465,-1.4728760717068388,0 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark53(11.608809780451086,-8.59977479507093E-10,0 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark53(11.619169095658677,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark53(11.647779772047315,-0.2596261080171656,0 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark53(11.670213924615908,-0.9459196493693582,0 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark53(11.67653646756933,-1.5707963267947793,0 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark53(11.690895265939474,-1.3782136622074734,0 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark53(11.782242586735496,-1.7518816957485018E-9,0 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark53(11.891944458432377,-0.06677586570279814,0 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark53(11.901479126867876,-0.6064242187812513,0 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark53(11.93536901171578,-1.4896473521195364,0 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark53(12.028662341746553,-0.029339933060122725,0 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark53(1.2047315973585393,-5.009695834064644E-7,0 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark53(12.072984965941133,-1.5707963267829324,0 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark53(1.214748160120262,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark53(12.181033549325043,-2.323788706340184E-16,0 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark53(12.198943173829193,-1.367641225885067,0 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark53(12.23089048417647,-0.576810743069732,0 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark53(12.3124510929905,-0.6330604537533304,0 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark53(12.318692769278599,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark53(12.34330960197505,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark53(12.401731941524949,-1.1708269285407864,0 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark53(12.448237270479211,-1.5008113631379274,0 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark53(12.461494531029743,-0.1668168447718239,0 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark53(12.463360336639354,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark53(12.510409216637283,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark53(12.548150046994436,-0.3807323456734369,0 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark53(12.582823530386001,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark53(1.2621774483536189E-29,-0.16498448875437613,0 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark53(12.636873900758445,-0.3740979421222992,0 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark53(12.665439752297416,-0.10898929895971321,0 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark53(12.677586586339102,-0.8629578612859313,0 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark53(1.2684071056125568,-1.2271753568486226,0 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark53(12.744423405666467,-0.3093843924184325,0 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark53(1.275170143153892,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark53(12.793236607311204,-0.05469899454847678,0 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark53(12.843321441802644,-0.3688312401488152,0 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark53(12.849617412708,-1.570796326794893,0 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark53(12.869793211340365,-1.0287943848379673,0 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark53(12.919680623863755,-0.6263320569212851,0 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark53(12.936148091424698,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark53(1.2957360488366039,-0.0047742699851909265,0 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark53(13.006051370204432,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark53(13.046854892355014,-0.1561138614087838,0 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark53(-13.051217350451964,-0.15973404698293336,-57.978198020539985 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark53(13.081593803245156,-1.570796326794893,0 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark53(13.142153848869583,-1.2155335100773526,0 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark53(13.148373455962385,-1.5390915734060968,0 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark53(13.151702830026224,-1.570796326794877,0 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark53(13.18789858742977,-0.3972230623762526,0 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark53(13.245609639414948,-0.295484703786817,0 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark53(1.3248249363876141,-0.9253430865526155,0 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark53(-13.332781466030758,-1.1200055841674497,0.05784690760437658 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark53(-1.3346620773280227,-1.5707963267948881,-0.28223869924951983 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark53(13.34823627708456,-0.7766087013818388,0 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark53(13.369630269077362,-0.28475631291111125,0 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark53(13.449079263658732,-1.5707963267948326,0 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark53(13.509563387249049,-0.8030623462869153,0 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark53(13.566896062833848,-0.21062090394037603,0 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark53(13.590644682978663,-0.7441447730618874,0 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark53(1.3606100926132285,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark53(13.620652144193594,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark53(13.689441591514406,-0.056576188580181264,0 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark53(13.696971009860578,-1.1615703419698,0 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark53(1.37711398771701,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark53(13.826562041717636,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark53(13.836361958448745,-0.4974979214365838,0 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark53(13.872186505459666,-1.5038251562415872,0 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark53(1.3895935640727708,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark53(13.904968139772933,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark53(13.981262204781501,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark53(14.0140537554031,-0.5086552777194147,0 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark53(14.080454775929667,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark53(14.093098527999999,-1.570796326794893,0 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark53(1.4167882635969098,-2.558381790004936E-8,0 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark53(14.191885962679578,-0.5903129162174103,0 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark53(-1.4210854715202004E-14,-0.22430560870663033,0.0 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark53(-1.4210854715202004E-14,-1.0120665607501773,0.06255252611331652 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark53(-14.30015716495194,-0.9286624098098883,-66.19879625572844 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark53(14.327573091695896,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark53(14.341621384484814,-0.3447201331803751,0 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark53(14.38466571532883,-0.022890522953288788,0 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark53(14.462030062519233,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark53(14.50073444123447,-0.2008733103457132,0 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark53(14.52741299477293,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark53(14.597481998797647,-0.04699516451217267,0 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark53(1.4644455881799985,-0.1626732397459989,0 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark53(14.692199117970294,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark53(14.744025185553008,-1.0283822738074573,0 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark53(14.8164232968711,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark53(1.4818213441545538,-1.406548776691829,0 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark53(14.876191157210277,-8.975569421743249E-10,0 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark53(14.882297643997486,-0.2353490715932144,0 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark53(1.4917454157140355,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark53(14.930194519904376,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark53(14.950151292576308,-1.4122524950113306E-5,0 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark53(14.957106113079943,-1.778070862522879E-8,0 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark53(15.025385661624611,-0.1079295618745375,0 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark53(15.062428641163972,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark53(1.5088588635437912,-0.28383667053142636,0 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark53(15.102690527395053,-0.6882330245613133,0 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark53(15.118601494970065,-5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark53(15.16387533143837,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark53(15.169947915087988,-0.19565120440102768,0 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark53(15.181895245361282,-0.9861724618709004,0 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark53(15.218445732873718,-0.6523852043129494,0 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark53(15.320895626673176,-1.2671873758604808,0 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark53(15.325432692292477,-1.4294725190891477,0 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark53(1.541345042396756,-0.8610704665795215,0 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark53(1.5417755103628252,-1.3833324214819933,0 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark53(15.448819823344493,-1.504163243962834,0 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark53(-1.5521854483888065E-12,-1.5707914578430142,-0.06255431421229174 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark53(-15.545546642946235,-0.7636204598557859,52.854250616671806 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark53(15.549979973383238,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark53(15.607233161584901,-1.3897477083502479,0 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark53(15.618624697644591,-0.9507543003873753,0 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark53(15.623212877981203,-0.4916622182842605,0 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark53(1.5645931732890261,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark53(15.646113547381248,-8.210490811533023E-9,0 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark53(-15.66443964558084,-1.5706376526071262,1.0 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark53(15.726360356549087,-1.1831206685930873,0 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark53(15.752989977967692,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark53(15.941003021563624,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark53(15.954313237015128,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark53(1.5971919441759432,-0.9905645638913763,0 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark53(-1.5E-323,-0.24487987496214847,0 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark53(16.005498526503786,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark53(16.017193410653377,-0.20915242255296462,0 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark53(16.039739827557312,-0.7028705283951173,0 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark53(16.066024280319894,-7.342644166847784E-7,0 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark53(16.07211116335057,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark53(16.086278368356552,-0.0942791217346669,0 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark53(16.107587246384256,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark53(16.20347996071439,-1.2162278702123253,0 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark53(16.218886194772992,-0.8496777193963325,0 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark53(16.23211526544479,-1.379737658011999,0 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark53(16.23845698519682,-1.562900186091448E-8,0 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark53(16.33255291546774,-1.5707963267001022,0 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark53(16.35198576497349,-0.0049517684664408534,0 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark53(16.353145141506232,-1.5480385799915481,0 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark53(16.442705990045425,-0.9296619375283515,0 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark53(16.522588484112195,-1.570796326794262,0 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark53(16.59062553396972,-0.20132935625756998,0 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark53(16.662599417317125,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark53(16.70198376052125,-0.08807858071821872,0 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark53(16.7272505336864,-1.3760250446226476,0 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark53(16.74991800205177,-1.3737921260589037,0 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark53(16.752707323532654,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark53(16.814552725255183,-0.11005799883954615,0 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark53(16.859825643894446,-0.1965591632966886,0 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark53(16.863845813072412,-0.5445298351680857,0 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark53(16.864898490132795,-0.021604832590051335,0 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark53(16.90749951221106,-0.1606802118171049,0 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark53(1.692318635775254,-5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark53(16.928104443604212,-0.6855180315917977,0 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark53(16.93838327075055,-1.410601712584807,0 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark53(17.045417340797258,-1.2244922382004688,0 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark53(17.070078403562476,-0.253832997267466,0 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark53(1.7078083682907736,-0.4538774796071161,0 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark53(17.083082370262982,-0.40667834710599293,0 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark53(17.090317388671775,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark53(17.11415418333549,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark53(17.118615278814616,-0.09249592228769998,0 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark53(17.12431881781073,-7.991203361527551E-7,0 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark53(17.14983762250324,-1.41479345486339,0 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark53(17.172498918081033,-0.22842149197100048,0 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark53(17.19567936918581,-0.2912558784918984,0 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark53(1.7386859755320785,-0.8834442570213099,0 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark53(17.390258687291777,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark53(17.393542354137807,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark53(17.41327651330632,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark53(1.743390045366752,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark53(17.45342627477244,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark53(17.458688760910775,-0.07309551372381407,0 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark53(17.459789502028983,-0.9993334407294949,0 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark53(1.748940532668418,-0.14918054541143944,0 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark53(17.494695017033443,-0.5097454991118935,0 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark53(17.50564764398257,-0.16572077482077407,0 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark53(-1.7509227510373222,-29.960273821595322,55.852336519787116 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark53(17.514126320811258,-1.3445177932387509,0 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark53(17.54702939644613,-1.5707963267948843,0 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark53(17.602720350993067,-0.5660748561669919,0 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark53(17.609498228291784,-92.10364812116292,2.632604049860717 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark53(17.624809609173894,-1.0260506351733163,0 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark53(17.65102205235964,-1.5707963267941916,0 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark53(1.767243212273506,-0.842533058637926,0 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark53(17.706036006675546,-0.3979372591804946,0 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark53(17.70753751311713,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark53(17.717502662816457,-0.7096546349241777,0 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark53(17.742627459865528,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark53(17.748618991415327,-0.7702567866039516,0 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark53(1.7763568394002505E-15,-0.47800085312762053,0 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark53(1.7780655967154226,-2.633187928369737E-4,0 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark53(17.835771902850468,-0.8809755385262363,0 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark53(-17.845851953769852,-4.0667960159446204E-10,-0.36209269481641837 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark53(17.8496829492686,-0.42699224903978683,0 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark53(17.856715581754514,-0.24761265233030372,0 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark53(1.8033738065507499,-0.776749357481774,0 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark53(18.04658814967948,-5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark53(18.065422886187804,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark53(1.8069229914879656,-1.2793791710522808,0 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark53(18.073796289944383,-1.2223061641508437,0 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark53(18.12776041135538,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark53(18.131078174303966,-0.734243379417828,0 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark53(18.143973037952875,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark53(18.165948604639624,-0.7210254754311607,0 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark53(18.181145674693667,-0.5032662547286932,0 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark53(18.206961535403792,-1.3665940675952442,0 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark53(18.227249010895054,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark53(18.258381371655872,-1.5104458332541526,0 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark53(18.26421804938505,-0.3783060851502995,0 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark53(18.36071490102158,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark53(18.428297395306856,-4.792394408397893E-7,0 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark53(18.4307486397486,-0.7797398977941583,0 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark53(18.5115316583244,-1.4625571890076197,0 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark53(1.851467671906093,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark53(18.535678741954474,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark53(18.613237644261936,-1.570796326794679,0 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark53(1.868137771018283,-1.570796326794893,0 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark53(18.72005705169816,-0.9963141989330531,0 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark53(1.873474988871763,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark53(18.763244000107093,-0.5912863056035036,0 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark53(18.822348381796086,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark53(18.84746060008229,-0.148104497521508,0 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark53(18.85387284370475,-0.38414248569227993,0 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark53(18.894260217647695,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark53(18.899773747887266,-0.6764846841401919,0 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark53(1.8975740910272112,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark53(18.998758247989556,-3.496944743865461E-4,0 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark53(19.033839375817365,-1.7381644914169714E-9,0 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark53(19.04837497390588,-1.3906057634738005,0 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark53(19.077777852219157,-1.0432601574370914,0 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark53(19.105656997402548,-1.4410038051755407,0 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark53(19.116420278511768,-0.9359848538113118,0 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark53(19.129667673472895,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark53(19.182985710192654,-1.0445502023118074,0 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark53(19.263625653667194,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark53(19.302890316909924,-1.457135603843227,0 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark53(19.30865886642681,-0.26765227130850633,0 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark53(19.347189145058934,-1.1971118874824214,0 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark53(1.936157065423755,-1.5087521152957555,0 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark53(19.39239721042481,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark53(19.482323751679658,-0.6706878566202619,0 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark53(19.48579797964919,-1.3349209326260414E-9,0 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark53(19.531893217307868,-0.9545465363881211,0 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark53(19.54500943612291,-0.9410388926729922,0 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark53(19.58547671824374,-0.7794711028834627,0 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark53(19.599044932571857,-1.1650675983063246,0 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark53(19.59910525363648,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark53(19.678636014477874,-0.28139362671225054,0 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark53(19.80779277056629,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark53(19.812499672433475,-0.26400988521082525,0 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark53(19.827708649189276,-1.4574817793554045,0 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark53(19.82922155222155,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark53(19.84058730777521,-1.259016804245931,0 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark53(19.856280000701233,-1.250022705049453,0 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark53(1.987439604158883,-0.39592247987835094,0 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark53(19.937899190952606,-0.901032651809178,0 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark53(19.943359054245533,-0.291645589372326,0 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark53(19.954479352878536,-0.16716986835338232,0 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark53(19.963481535964974,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark53(20.013732173724033,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark53(20.03959147316116,-1.0992292544490296,0 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark53(20.07487563437816,-1.2961856710553832,0 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark53(20.079109171549216,-0.7190845626676223,0 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark53(20.086324371809965,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark53(20.100427692569255,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark53(-20.108460446489126,-0.4204154788400446,-1.0 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark53(20.112227124766044,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark53(20.15656976350391,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark53(20.218558175835483,-0.24898742051598965,0 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark53(-20.24397700666013,-0.18077789441594008,1.0 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark53(20.247885519672113,-1.10081426208207E-9,0 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark53(20.27354729670759,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark53(20.29548953553042,-0.10040827241001282,0 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark53(2.0354710523998563,-1.5707963267948921,0 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark53(20.355017310480747,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark53(20.38686845582744,-1.5059912453973396,0 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark53(20.446069875894594,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark53(20.489848584374393,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark53(-2.0548748447329844E-17,-0.9431401220192523,1.0 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark53(20.562807358208033,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark53(20.567924229721314,-0.9337518999085921,0 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark53(20.616558315640063,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark53(20.62673767947245,-1.5707963267948857,0 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark53(20.6811622204649,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark53(20.686150561506864,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark53(20.70148796276036,-0.9558666033414038,0 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark53(20.729190574359862,-0.32270136779628444,0 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark53(20.729701686342366,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark53(20.75671404822279,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark53(20.760960012325995,-1.1452045896304783,0 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark53(20.77004526494568,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark53(20.801448694938827,-1.4973428727053992,0 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark53(20.842062372424557,-1.444976087091636,0 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark53(20.85084928448231,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark53(20.863498032554926,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark53(20.906861450136915,-1.5707963267948308,0 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark53(20.918154902272107,-0.3733962994124673,0 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark53(20.92985603430624,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark53(20.968668704954638,-0.956636023445185,0 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark53(20.985698590288877,-0.8549234179496352,0 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark53(21.002558902249163,-1.434090907431551,0 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark53(-2.1013427269303193,-0.5406973098281193,63.74087775894296 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark53(21.019951015517563,-0.8355225597637173,0 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark53(21.048391703465285,-0.7291195280424603,0 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark53(21.083639103206053,-0.10703831602832281,0 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark53(21.086559034043503,-1.1677322162097994,0 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark53(21.090675537121157,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark53(2.114175651958035,-0.2455157542861396,0 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark53(21.148510998647524,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark53(2.1240244953974012,-1.1637857269996772,0 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark53(21.259238043500616,-0.09984342266883406,0 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark53(21.30643082485875,-0.9799710199962988,0 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark53(21.324063931577058,-0.40705783399566586,0 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark53(21.34724577003911,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark53(21.399082603072575,-0.4308108212092794,0 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark53(2.1420148433132127,-1.1861010470358084,0 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark53(21.428441227753623,-0.3574864094979533,0 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark53(21.46719467197302,-0.7539051470611469,0 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark53(21.500252773383988,-1.5706728657261335,0 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark53(21.501224595014264,-0.13465626247661078,0 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark53(21.507031936098087,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark53(21.569128383369932,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark53(2.1607652984157397,-0.7788159557785697,0 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark53(21.630425735427846,-0.06748643675958554,0 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark53(21.63909416875154,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark53(21.68537982034175,-1.5707963267948912,0 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark53(21.70664237572508,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark53(-21.743925826012656,-1.286483510529557,-10.28331087850161 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark53(21.793456422700814,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark53(2.17E-322,-1.181387426530454,0 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark53(21.804676631558806,-0.16915261915801239,0 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark53(21.850952807558357,-1.3265353130937712,0 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark53(21.87394393868432,-1.3823882166140342,0 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark53(21.927589785120432,-0.8541965819478099,0 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark53(22.003355179537294,-0.5196685468920919,0 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark53(2.203814201759741,-0.8161491960271832,0 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark53(-22.051358934585068,-0.4002451399628342,-1.0 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark53(22.079469529873734,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark53(22.17364908278934,-0.4208448688728339,0 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark53(2.220446049250313E-16,-0.6662049691035836,0 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark53(22.240293910492653,-1.0904270940360306,0 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark53(22.243098807378118,-0.8460885698467848,0 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark53(22.253654757107228,-0.00867445329038219,0 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark53(22.25639651260059,-0.30555967468595924,0 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark53(2.2317994939890156,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark53(22.319880376432703,-0.8562079590050837,0 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark53(22.338879805656802,-1.3682870667236626,0 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark53(22.347439350668434,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark53(22.350932224141467,-0.9239196978223152,0 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark53(22.371657513251762,-0.12339836035713514,0 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark53(22.373601995799824,-2.211600123028564E-8,0 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark53(22.410217988212636,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark53(22.410435484385438,-1.4534552948888022,0 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark53(22.4410921124024,-1.5707963267948895,0 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark53(22.463633154064127,-0.05563699378994613,0 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark53(2.2482964847890474,-0.7885060303757633,0 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark53(22.48416176596774,-1.5707963267948877,0 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark53(22.51184483034369,-0.09468060695909486,0 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark53(22.526744224521238,-0.9419055969131591,0 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark53(22.570586906673256,-1.570796326794893,0 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark53(22.624041405755516,-1.5707054759886314,0 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark53(2.262945261064231,-0.7906555438786982,0 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark53(22.670857620449176,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark53(22.68764213218141,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark53(22.78719137946632,-0.7743738492291214,0 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark53(22.820825870116963,-0.6384918263158248,0 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark53(22.899607789851643,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark53(22.920412444143814,-0.9218016319015403,0 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark53(22.97711074854149,-0.440096834091217,0 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark53(22.996674622240135,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark53(23.030467946915703,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark53(23.042455054793592,-1.1514293496928758,0 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark53(23.059165771753726,-0.8995830874198152,0 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark53(23.064627185617994,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark53(23.078346847803758,-0.8188677183558809,0 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark53(-2.3081346233449533,-1.5707963267948963,1.0 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark53(23.179542338955855,-0.6443577201918839,0 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark53(23.19277399050752,-1.4957876328184305,0 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark53(2.3215204894272987,-7.260748879808763E-6,0 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark53(23.216048715795623,-0.7332033452897395,0 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark53(23.21950822287484,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark53(23.26298206550578,-0.16598785508528846,0 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark53(23.288059742474587,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark53(23.29726642649797,-0.06616050805545726,0 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark53(23.329625220542766,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark53(23.33120279415624,-1.5707963267948521,0 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark53(23.373601362832773,-1.2846464726750053,0 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark53(23.377713702756036,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark53(23.3908850858938,-1.165405972998625,0 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark53(23.39122791552694,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark53(23.416360942897455,-1.0549903883354668,0 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark53(23.453396528059358,-1.0101279406255264,0 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark53(23.48037831071683,-0.07136231248050251,0 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark53(23.487477932886193,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark53(23.564455962206726,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark53(23.62945418085991,-1.0231274543744462,0 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark53(23.630022772626532,-1.0540715615082945,0 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark53(23.73416342684287,-0.9884258227157652,0 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark53(23.837750905500243,-0.4549547638398366,0 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark53(23.846777233835752,-1.9854801370575315E-9,0 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark53(-23.850653050754616,-1.570796326794385,-15.369872061767282 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark53(2.3864702841313203,-0.9995895191743944,0 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark53(23.86765494837349,-0.03679751522594188,0 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark53(23.964909256668008,-1.3252000193154565,0 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark53(24.01148979925925,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark53(24.013887829376067,-4.1686286317823855E-10,0 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark53(24.121880335894723,-0.4034262589077816,0 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark53(24.13852669114152,-0.3770054282720281,0 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark53(24.138983957489344,-1.2466942181526888,0 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark53(-24.158439298225993,-1.3501899950056295,1.000000000014435 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark53(24.17737282220504,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark53(2.4189515215016075,-0.8056728045017193,0 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark53(24.225690040574506,-1.2924416341701317,0 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark53(24.285703231810672,-0.4604703565237287,0 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark53(24.324970472618574,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark53(-24.376738166225948,-1.7763568394002505E-15,0.0 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark53(-24.475086195648757,-0.23243687212772102,93.89849526663266 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark53(24.50838939204803,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark53(2.4567805267924996,-0.17136281399427844,0 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark53(24.572793402708655,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark53(24.59941477647058,-1.520812098522761,0 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark53(24.631570352295917,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark53(24.648872367200937,-0.7069656908678059,0 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark53(2.465190328815662E-32,-0.0341519663282403,0 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark53(24.67362417513786,-0.4667079331351687,0 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark53(24.67676756213625,-0.8055205013260345,0 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark53(24.68679430572591,-0.3249087656822085,0 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark53(24.704267745012203,-0.7488260358634236,0 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark53(24.713640344682858,-0.555789041900816,0 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark53(24.730507236226117,-1.570796326794607,0 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark53(2.4746985611540993,-0.736086352135672,0 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark53(24.77292326903866,-0.23610968179405845,0 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark53(24.783534686671345,-1.0921311656495458,0 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark53(24.809839917430963,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark53(2.4824426132765574,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark53(24.8361857369118,-1.5707963267948895,0 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark53(-24.85547389174551,-1.5140216175675496,1.0 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark53(24.884581092340174,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark53(24.894678153763294,-1.2348253708514463,0 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark53(24.90837793320854,-1.570796326794592,0 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark53(24.93765624534099,-0.9001877730314092,0 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark53(24.939604972593408,-1.4049498248045884,0 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark53(2.4943903032577186,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark53(24.950318874164125,-0.42382839090323365,0 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark53(24.96323397895754,-4.3993316991464983E-4,0 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark53(24.99875550689267,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark53(25.00415031756029,-0.871226309457878,0 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark53(25.05545997418072,-0.8378073087392934,0 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark53(25.13699273584995,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark53(25.14133011634118,-1.217596393634107,0 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark53(-25.163145556837122,-1.5707963267948948,-93.97839855347074 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark53(25.178878097858984,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark53(25.19927759044262,-0.49714715930689124,0 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark53(25.24382067775018,-1.5544098225006955E-6,0 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark53(25.258199947019406,-39.7011408053457,-11.550224516464567 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark53(25.262729330669657,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark53(25.264183724235686,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark53(25.286532345107872,-0.5738793138170304,0 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark53(25.292539963198024,-0.7645893607927405,0 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark53(25.341490323719487,-1.420351543730036,0 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark53(-25.35214445979493,-1.5687416172274387,1.0 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark53(25.367753283979383,-0.36227307085994465,0 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark53(25.38320079964418,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark53(25.406933214979105,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark53(25.469742638502836,-1.5707963267948903,0 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark53(25.495699982773324,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark53(25.512726301073272,-0.28275413248633896,0 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark53(25.539228129068064,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark53(2.559365599543682,-0.09723930631000144,0 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark53(2.561083973883522,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark53(25.619674959236008,-0.014091783087616605,0 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark53(25.64783039440354,-0.2023127058863229,0 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark53(25.737546878581288,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark53(25.73867435075227,-0.16834783270287418,0 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark53(25.766844225549804,-1.2145954834260149,0 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark53(25.81956273390817,-1.2566260578551216,0 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark53(25.858530591963465,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark53(25.908619359081598,-0.1787432674941165,0 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark53(25.91250962794166,-3.5738589568234104E-6,0 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark53(25.93191373760822,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark53(26.005472130686197,-0.14804663996031486,0 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark53(26.033122669182802,-1.5707963267948886,0 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark53(2.604503981153252,-4.502959325460095E-9,0 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark53(26.047703513840403,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark53(2.609062345222931,-9.223796789568531E-4,0 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark53(26.105596759505687,-0.17646270973068567,0 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark53(26.15520114406567,-1.5707963267930263,0 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark53(26.1773112965696,-0.13067136682180472,0 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark53(26.18706643366599,-0.6820822170982694,0 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark53(26.20653535441957,-1.0419090974902474,0 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark53(26.290035410696163,-1.5511115658602819,0 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark53(-26.29347140630297,-0.1147081958608438,0.41853376689499555 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark53(26.298258278019688,-0.6120492732385987,0 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark53(26.299512621367974,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark53(26.3243751392486,-3.4125730477689597E-4,0 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark53(26.325499647948845,-0.6156250182109012,0 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark53(26.370437442112475,-1.0847023423942659,0 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark53(26.408375986074628,-0.6255279257389992,0 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark53(26.45817827193624,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark53(26.46012843729504,-0.32592729677804755,0 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark53(26.543245607227206,-0.28648233170325454,0 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark53(26.55525024848035,-1.570796326794894,0 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark53(26.59154693765015,-0.5225588809321065,0 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark53(2.659493921824435,-0.23266676151807308,0 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark53(2.659645620858143,-1.4736698412918052,0 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark53(26.605274988926112,-1.4888423747363075,0 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark53(26.609152195385423,-1.3709428908015364,0 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark53(26.617059378479276,-1.336686811155285,0 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark53(26.70188710279741,-6.816246257683327E-8,0 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark53(2.6706908234868934,-1.0641151116960543,0 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark53(26.929265893789424,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark53(26.9343597051053,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark53(-2.6942748728186814,96.12817474717022,32.04651564594238 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark53(27.05000208664694,-0.6478213659831,0 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark53(27.10343455795264,-0.18479624626539248,0 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark53(27.10587754182734,-1.4738511445363116,0 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark53(27.203104716004127,-1.0389072444379917,0 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark53(27.211930722788807,-3.063176835128119E-9,0 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark53(27.228207363265643,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark53(27.23371028616863,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark53(-27.304615009201644,-0.1276644031074407,-0.9999999999999998 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark53(27.340182401118355,-0.6861811950786808,0 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark53(27.366950371590995,-0.37481423359485655,0 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark53(27.41734326320452,-0.7205778161784167,0 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark53(27.47750736466179,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark53(27.591958129244194,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark53(27.610130341423854,-0.45578173104026654,0 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark53(27.64243758901874,-0.7740922980601581,0 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark53(27.643212194146713,-0.5019854313131056,0 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark53(27.649219207302608,-0.8603891159669104,0 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark53(27.66916632800178,-0.731122059653643,0 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark53(27.79411719258063,-1.3915015270221196,0 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark53(27.833454194891875,-1.933540445616278E-8,0 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark53(27.850636614350748,-0.9741812390820002,0 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark53(27.950714334084537,-0.48523719087491557,0 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark53(2.79998917280156,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark53(28.01224312806113,-0.7586508250080688,0 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark53(28.017140923869555,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark53(28.02234774489284,-0.8842329943198792,0 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark53(28.032111814834387,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark53(2.809310595064596,-0.0010996025863458454,0 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark53(28.095517125902127,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark53(28.12994649359976,-0.28441060306387556,0 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark53(28.230682729411427,-5.482411859990399E-10,0 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark53(28.274103522813135,-1.5707963267948664,0 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark53(-28.292962114105865,-1.2538043354534467,5.421010862427522E-20 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark53(28.311469272394277,-1.0155944258791982,0 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark53(28.316376683965842,-1.5707963267948521,0 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark53(28.336632938206918,-1.0114200418793402,0 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark53(28.343256178465094,-0.5026140689358352,0 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark53(28.37179160763904,-0.632045724190708,0 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark53(28.37367548619946,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark53(28.395532754981954,-0.49301960411931045,0 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark53(28.40646851061577,-0.004257071128096974,0 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark53(28.501248297164377,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark53(28.546981110409053,-0.5113961705905012,0 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark53(28.569557106731224,-0.73742505190204,0 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark53(28.61031084532323,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark53(2.863416451229938,-1.1052014771592982,0 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark53(28.704721525297053,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark53(-28.777763192592573,-0.35273933374206373,-60.141990456877664 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark53(2.880007684241039,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark53(-28.82400749592631,-0.2598651964295514,0.04256303459520991 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark53(28.84194125601894,-1.4790506529437977,0 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark53(28.88143242227354,-1.4385058240187514,0 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark53(28.88335242202359,-1.2607125523422855,0 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark53(-28.950755025457067,-1.3199396842666182,0.3620939595747005 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark53(29.076908704760218,-0.6933654691095539,0 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark53(29.101071440251474,-0.864681525492762,0 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark53(29.14589957580091,-1.355518581552026,0 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark53(29.174232126538385,-0.22773202255954184,0 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark53(29.188950055914166,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark53(29.200608793089366,-0.005033583607851874,0 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark53(29.250617477283686,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark53(29.265362985176722,-1.2602524057156756,0 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark53(29.280297121734975,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark53(29.30271262972761,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark53(29.387686570927173,-1.2941497269434876,0 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark53(29.398330121962715,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark53(29.418665459880295,-9.702609256199849E-8,0 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark53(29.452663393159867,-0.2888611174829805,0 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark53(29.470248020474056,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark53(29.47798315831027,-4.0552712922893566E-10,0 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark53(29.48583683792282,-6.897803314083571E-6,0 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark53(29.564115392253086,-0.13092280182642213,0 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark53(29.579450569933528,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark53(29.606165836704037,-1.4493668329596314,0 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark53(29.630579402264733,-1.5639621906448125,0 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark53(29.697186960341014,-0.04906816679655134,0 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark53(29.721771849491887,-1.0392958123609928,0 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark53(29.730523190967773,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark53(29.734842372705984,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark53(29.74270892029405,-0.9012420983368887,0 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark53(29.753406688873497,-1.495247710300115,0 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark53(29.779945415372225,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark53(29.786739284345053,-1.8014863976514171E-9,0 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark53(29.81879371111043,-0.33550598583545366,0 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark53(29.831361573720123,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark53(29.88293354802228,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark53(29.90355992693457,-1.0218791679666172E-8,0 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark53(-29.906327250464653,-4.684426524791953E-5,48.09487626099645 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark53(29.92192200747718,-1.359998767488372,0 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark53(30.01130475801287,-1.5583514440178305,0 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark53(30.039162376035108,-1.0535116703734706,0 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark53(3.0075512648380283,-0.29960527908667633,0 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark53(30.103906621097366,-0.20179655404554242,0 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark53(30.194313821962595,-1.570796326794893,0 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark53(30.225494734026512,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark53(30.25421392171407,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark53(30.258451724056318,-0.47396974188184604,0 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark53(30.304391696491216,-0.11014909382983884,0 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark53(30.306424786992494,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark53(30.353824498348473,-0.8246064008897207,0 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark53(30.359008722669714,-0.9671680575131634,0 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark53(30.38971944246279,-1.570796326794893,0 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark53(30.39682686192367,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark53(30.396898181330954,-1.5707963267948877,0 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark53(3.0409290726825873,-0.5196944690003005,0 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark53(30.428517881762048,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark53(30.51329973802777,-0.4838197279188843,0 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark53(30.516757684947553,-9.068107390113912E-5,0 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark53(30.65523281419369,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark53(3.0657567823889877,-0.07556541137334705,0 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark53(30.713655160396456,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark53(3.078013093246821,-0.6366827844286609,0 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark53(30.832715814180172,-0.5799477489812368,0 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark53(30.869729683123097,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark53(30.887896808650538,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark53(30.909707904278577,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark53(30.93113374612043,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark53(30.958936533714194,-1.5707963267948912,0 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark53(31.03328352344292,-0.8516342667714634,0 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark53(31.07763350716874,-0.2614929866287552,0 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark53(3.108900728404592,-1.5707963267948557,0 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark53(31.09995459372435,-0.3015861991816151,0 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark53(31.120387345626224,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark53(31.17591070968908,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark53(31.23600863465201,-0.6365393640228305,0 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark53(3.1289029994608537,-0.5398859285641322,0 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark53(31.362573663022914,-1.1382968296230835,0 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark53(3.137167997699791,-1.5707963267894542,0 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark53(31.380744540075234,-1.570796326794896,0 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark53(3.1411498867584324,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark53(-31.556063023492847,-7.39916011116949E-7,68.24279824028358 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark53(31.603096445195433,-1.5260430462788057,0 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark53(31.61563759376324,-0.9529646430285599,0 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark53(31.64930446119959,-1.570796326794893,0 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark53(31.67492999463488,30.812083446749682,18.9527337829075 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark53(31.710467354883832,-0.20011979273969072,0 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark53(31.71901573747022,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark53(31.76102070203629,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark53(31.799163479615373,-0.34117261276323063,0 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark53(3.1826868370729144,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark53(31.83293902824994,-0.015955735628139678,0 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark53(31.840419979947285,-0.09686819710798034,0 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark53(31.844285810683687,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark53(31.891186713161495,-1.2105258003892025,0 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark53(31.900352784574007,-4.5779918172700145E-9,0 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark53(-3.1915783044881208E-15,-0.47278282914282777,-38.80064394810956 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark53(31.932627154692682,-0.8905736972169844,0 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark53(31.980284371969162,-0.17288854519589858,0 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark53(32.0086714219763,-0.7161784376355431,0 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark53(32.020655189366856,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark53(32.0405446693781,-0.38378686549920316,0 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark53(32.118763654028534,-1.5707963267151823,0 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark53(32.19977522896676,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark53(32.20021175509122,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark53(32.20438829889048,-0.8703240804438934,0 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark53(3.221117068834104,-0.3185531489084976,0 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark53(32.214257389370495,-1.3986719102729808,0 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark53(32.24002512116542,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark53(32.26466056615159,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark53(32.297108915336736,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark53(32.29908953577623,-0.01176742906994832,0 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark53(32.304377621961116,-5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark53(3.236408140001018,-0.7609392009912215,0 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark53(32.36994278916724,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark53(-32.44721759060997,-0.016772046344283562,0.6686898900477383 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark53(32.46039795995236,-1.570796326794893,0 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark53(3.247103992381014,-0.9610877309574333,0 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark53(-32.477322645423754,-0.01172210257821682,-100.0 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark53(32.516423446679,-1.1719275495606283,0 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark53(32.52779090694901,-1.5707963267948317,0 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark53(32.542011488614634,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark53(32.57578745712195,-1.2269519628528627,0 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark53(32.58399351834447,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark53(32.590914527955995,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark53(32.64013477021061,-0.7940647572234912,0 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark53(32.67568387959313,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark53(32.67630113572161,-1.107098515895422,0 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark53(32.68728129805067,-0.4605348244395313,0 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark53(32.71768470410683,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark53(32.726306329016865,-1.5707963267922211,0 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark53(3.2733299119638133,-0.39407495784416513,0 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark53(3.2784630644021604,-0.3065704566613272,0 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark53(32.83517157850861,-1.2820432481584199,0 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark53(32.85065104937246,-0.8265626998191888,0 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark53(32.86794331899813,-0.646931156191723,0 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark53(3.288480751715653,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark53(-32.915045427972615,-0.027287093017995905,-1.0 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark53(32.93823719758484,-0.8266953093565466,0 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark53(32.97242767549577,-0.20684289020078075,0 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark53(33.0687993161581,-0.8697378149463815,0 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark53(33.07977440689252,-1.5707963267702814,0 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark53(33.17625201720864,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark53(33.21193337564361,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark53(3.3243661354324168,-1.5707963267948912,0 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark53(33.25398726527581,-1.233368531427837,0 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark53(33.271033124162074,-0.8558522617124282,0 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark53(33.280405422436004,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark53(3.3299958654878358E-257,-0.016047191854203113,0 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark53(33.32880378833681,-1.5707963267948717,0 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark53(33.348552846999326,-1.5707963267948273,0 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark53(33.36352146390695,-0.4568508912457774,0 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark53(3.337848264052141,-0.4045376968825547,0 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark53(33.3945804015726,-1.2580368683647407,0 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark53(33.459560207937756,-1.1238045548721107,0 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark53(33.48026698758645,-5.501152882659341E-10,0 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark53(33.52363151631933,-0.6198952104436533,0 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark53(33.5354472066588,-1.459400375952157,0 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark53(33.70451717853328,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark53(33.73150477239412,-1.5100861890062691,0 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark53(33.736111662907554,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark53(33.765501621658274,-0.43613386052629943,0 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark53(33.789625558283205,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark53(33.81789729309449,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark53(33.87655412917451,-1.3215424191818212,0 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark53(3.3881317890172014E-21,-1.550028731770344,-1.0 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark53(33.88577390128493,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark53(33.94182599915388,-1.2453911544251217,0 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark53(33.94871555059706,-6.936919455644399E-10,0 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark53(33.98876448759589,-1.5640840256368487,0 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark53(33.99669560448103,-0.984789023994983,0 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark53(34.008590845620034,-1.4230256744800727,0 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark53(-34.04948757512105,-0.009547655777013752,0.7922337418439308 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark53(34.08283612373532,-0.8896303125985412,0 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark53(34.0887927769146,-0.5414623351606908,0 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark53(34.08920308249063,-0.43329699119831466,0 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark53(34.14952326638152,-0.9857378911217789,0 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark53(34.159498618265275,-1.3902058769280217,0 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark53(3.420738079887812,-1.5707963267938183,0 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark53(-3.4239426707155474,-1.5707963267948615,1.3698808431302519E-194 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark53(34.2432747184524,-1.5392314420833038,0 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark53(34.30705833450245,-1.4083872539141122,0 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark53(34.331551191429945,-0.15701348751288435,0 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark53(34.33763630164947,-1.5091927398076752,0 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark53(34.35706607026222,-1.3410360886673036,0 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark53(34.390004788786236,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark53(3.441572891269587,-0.888904621941645,0 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark53(34.44896338439557,-1.347829589988148,0 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark53(34.54340285526709,-1.5418850963946267,0 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark53(34.54649415828372,-1.570796326794893,0 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark53(34.54809322407624,-0.1772930195396949,0 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark53(34.556267163228455,-1.480759973735476,0 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark53(34.562434072821745,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark53(34.564090139264835,-1.5707963267948166,0 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark53(34.57337436941887,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark53(34.59608491200305,-1.245245767243408,0 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark53(34.597492244700646,-0.5961564097876071,0 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark53(34.599819725791605,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark53(34.64082590936533,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark53(34.700665835123615,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark53(3.491079110726858,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark53(-34.99288631129777,-1.174135994919447,-0.5698893903364717 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark53(35.00918997419572,-0.4481884186492735,0 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark53(35.02059449664911,-0.6936783765849421,0 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark53(35.083428613627746,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark53(35.10404157388896,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark53(35.108978261149105,-0.06904764151359188,0 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark53(35.11562409263277,-0.9706557435734737,0 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark53(35.15950747040134,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark53(35.169903635232494,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark53(35.21048545480596,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark53(35.27853696595838,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark53(35.30231627030872,-1.188701802389991,0 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark53(35.30318151692654,-1.5097333242653415,0 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark53(35.32583385448862,-9.493542335916209E-9,0 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark53(35.334755955485846,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark53(-35.34322910115651,-0.29884024872152704,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark53(35.35689467158676,-0.2739404217655448,0 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark53(35.427634722764026,-0.16516110903598502,0 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark53(35.48841078953026,-0.9036602846337467,0 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark53(35.521360546868436,-1.3763136759708345,0 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark53(35.54591718103032,-1.4787803263558885,0 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark53(35.556862530837364,-0.9287037492111287,0 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark53(35.57829568045126,-0.7111211738002821,0 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark53(35.58395948306388,-0.9106119784995368,0 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark53(35.587348767403725,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark53(35.64067419336415,-0.07553863060560828,0 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark53(35.65500755161204,-1.123285083633648,0 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark53(35.754572499835845,-1.5675007869146778,0 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark53(35.81740903898191,-0.07690053942777636,0 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark53(3.58315193310335,-2.7164300955658594E-8,0 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark53(35.869208564915965,-0.8231366404201814,0 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark53(35.88577195310473,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark53(-35.89984198085688,-0.9929006114874497,0.5388052534389596 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark53(35.934865623592984,-1.0781837713266533,0 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark53(36.00345097722115,-1.1900098115973314,0 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark53(36.00380397217228,-1.0005552135855993,0 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark53(36.02764038359648,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark53(36.04326693789034,-0.1941850243286969,0 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark53(36.050613881742606,-0.13056125245188355,0 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark53(36.07026536184567,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark53(36.115961763221456,-1.199723069359626,0 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark53(36.118785050742076,-0.237406084212286,0 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark53(36.20624761338922,-1.2140358419963668,0 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark53(36.21976442339448,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark53(3.6275342845067655,-0.4874687542492069,0 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark53(-36.288817054066925,-0.15009841566770657,-0.9999999999999954 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark53(36.30859663469272,-0.4838730010497283,0 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark53(3.63246145330084,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark53(36.383616810188556,-0.060351266677766524,0 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark53(36.46653632000021,-0.14788579250748413,0 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark53(36.54101762568837,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark53(3.6572940445320112,-3.0587794787309906E-9,0 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark53(36.601679713714645,-1.5707963260481272,0 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark53(36.613067815226316,-1.4805765009137133,0 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark53(-36.686229730112366,-1.5707963267948957,1.0 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark53(36.76433131676878,-1.3747428420229286,0 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark53(36.78333716242611,-0.10131672230940904,0 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark53(36.80882915963029,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark53(36.811435606514806,-0.35070929727638145,0 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark53(36.84337515469355,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark53(36.92247426552518,-0.5245762435277224,0 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark53(36.93459199599701,-0.8943791913098948,0 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark53(36.966588100669945,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark53(37.063038818764284,-1.3661643205304443,0 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark53(37.080063114021584,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark53(37.08047893385381,-0.4496260850604674,0 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark53(37.15823634135586,-1.2327202979613006,0 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark53(37.16716715429899,-1.570796326794893,0 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark53(37.29681387484723,-0.6909542132446802,0 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark53(37.34160893834479,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark53(37.357555150148414,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark53(37.36107609491201,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark53(37.3996423676171,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark53(37.441053163864865,-1.3824729342322266,0 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark53(37.45529962570259,-0.6717855123746759,0 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark53(37.493187919649245,-1.346042221729931,0 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark53(37.526040056098395,-0.8613990012297279,0 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark53(37.6128390320481,-0.4012369492288528,0 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark53(37.663604942337116,-1.0938010116307737,0 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark53(37.67415425538175,-0.9789796442080183,0 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark53(37.712631888992576,-0.7771222817175252,0 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark53(37.73762431614483,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark53(37.75323573007208,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark53(37.80276095317242,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark53(3.7855290726626656,-0.6166079177746013,0 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark53(37.86265971931374,-0.5482029914487541,0 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark53(37.86778088321458,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark53(37.87670156640846,-0.9841605635551929,0 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark53(3.7889329225576622,-1.3992202682311253E-8,0 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark53(37.89595203226642,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark53(37.95149978354749,-0.5030096319991788,0 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark53(37.95558263874142,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark53(38.02048571894037,-0.23388161163220111,0 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark53(38.09367820416342,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark53(38.10529588970897,-0.9524454856141094,0 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark53(3.8120379766292274,-1.0266169716356448,0 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark53(38.12272181853399,-0.1778332089316755,0 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark53(38.17990661303702,-0.3021671406681037,0 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark53(38.239631395061906,-0.14602777194994587,0 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark53(38.247215511322736,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark53(38.2483201849692,-0.7293817587477598,0 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark53(38.2526757783923,-0.09846573298736594,0 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark53(38.30013524101733,-6.743121190149087E-7,0 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark53(38.30708612329916,-0.28596174721139356,0 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark53(3.8308395420387313,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark53(-38.31379611624421,-0.9760187386915615,-50.67200009706099 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark53(-38.348016982196455,-0.5208046839517025,0 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark53(38.39634088075005,-0.5713264741191022,0 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark53(38.398404068812965,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark53(38.42169146579466,-0.8339307765939337,0 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark53(38.42957130727075,-0.023736554393472165,0 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark53(38.52216940744019,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark53(38.57280497476842,-0.47723449573619803,0 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark53(38.62493544828399,-1.0225343598695815,0 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark53(38.62503954250999,-0.8383028179499228,0 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark53(38.63236215314862,-0.6561307598771862,0 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark53(38.67083320657153,-0.9850108727162592,0 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark53(38.67415960239765,-0.5767345162631659,0 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark53(38.678372224237826,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark53(38.76934004913991,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark53(38.77722118575446,-0.06958945516507942,0 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark53(38.84810899690993,-1.5707963267948841,0 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark53(38.883083270965955,-0.2134745815028083,0 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark53(3.8889154636534755,-1.0176234526947434,0 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark53(38.93565793356922,-4.842887049204054E-10,0 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark53(38.97995662330652,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark53(39.01680559178354,-0.10019967290261889,0 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark53(39.01849453576068,-1.1287949034192764,0 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark53(39.09968538437378,-1.5398348476833517,0 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark53(39.13879685014504,-0.8038589947668271,0 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark53(-3.919838088834659,-2.220446049250313E-16,-30.682229938865735 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark53(39.19976756334819,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark53(39.21963950628174,-1.4333429469767156,0 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark53(3.9231511279199225,-0.5406517543431022,0 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark53(39.242290761610164,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark53(39.28316889303923,-0.16955908013370213,0 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark53(39.32537691572605,-1.4706679319944795,0 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark53(39.3354571190425,-1.570796326794893,0 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark53(39.37287186658535,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark53(39.43488339389987,-0.05213595540328875,0 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark53(39.43699854593281,-0.5149718134365857,0 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark53(39.458930718340724,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark53(39.46120861294922,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark53(39.497555444188464,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark53(39.509118178316314,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark53(39.55329134936892,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark53(39.56848220837762,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark53(3.959776296255002,-1.2539010293800836,0 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark53(39.64481130879102,-0.043115416131866424,0 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark53(39.66472898957215,-0.8953236782321881,0 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark53(39.70459998514142,-1.5707963262592881,0 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark53(39.78765131090887,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark53(-39.813698795548945,-0.0618642495681118,1.0 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark53(39.81584930265285,-0.11873228255051327,0 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark53(39.84187831144277,-0.601504197938481,0 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark53(39.84491790306605,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark53(-39.855445980087474,-0.8532379977714701,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark53(39.88059739250827,-1.5558844386443146E-8,0 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark53(39.88106735359602,-1.5707962922027652,0 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark53(39.943061530520566,-0.5451552947329787,0 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark53(39.95062003137261,-0.4344231842998383,0 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark53(40.03401731987792,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark53(40.03666557627252,-1.570796326794893,0 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark53(4.0050081248226945,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark53(40.086729065997986,-9.574541814753331E-7,0 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark53(40.08807258706776,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark53(40.10408814598972,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark53(40.107943115837884,-0.9656605152488424,0 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark53(-40.21589279580085,-0.6211305029064391,-27.92272033768306 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark53(40.23132566876322,-0.7062679708486381,0 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark53(40.24288931601933,-0.9880354855354136,0 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark53(40.27599599069194,-0.6990363724235422,0 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark53(40.27947808724676,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark53(40.28551260678276,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark53(40.33450793254744,-1.570796326794893,0 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark53(40.33487529668852,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark53(40.346007436735476,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark53(40.38858750302896,-0.5096365989934517,0 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark53(40.4143789833541,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark53(40.41807223909322,-0.86089741658947,0 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark53(40.430713285051326,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark53(40.457763709095445,-0.20220729534030113,0 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark53(40.51280052059524,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark53(40.59846129280939,-0.18205239370240278,0 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark53(40.68828355536641,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark53(40.74823186882409,-1.2845282880302573,0 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark53(40.75450252991214,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark53(40.83560978697068,-0.6823370747605679,0 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark53(4.091202258757994,-0.13886337834445228,0 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark53(40.95892596365218,-1.5060294282377993,0 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark53(40.98298851114055,-0.38348981887008904,0 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark53(41.02520819875953,-1.570781521861541,0 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark53(41.195950293439466,-1.2711390271472993,0 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark53(41.24233800145285,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark53(41.2503936687408,-1.2509169825356992,0 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark53(41.28293727120905,-1.1850690605730403,0 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark53(4.130485183724801,-0.018548380643078177,0 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark53(41.367251961954196,-0.534033557465027,0 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark53(41.454051134950404,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark53(41.4729111644686,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark53(-41.52006690201674,-1.570796326794867,-0.10224860204797853 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark53(41.52901358206978,-0.06960329977704784,0 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark53(41.54547637585259,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark53(41.55311515965613,-0.835375929587812,0 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark53(41.56517578300175,-1.0534172968592981E-4,0 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark53(41.650139276022,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark53(-41.718127806082244,-0.7351807273748823,-0.8074505054355843 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark53(41.73344516104748,-0.23078738182513447,0 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark53(-41.75741769759378,-1.7191215860892973E-9,-1.0 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark53(41.85895323814742,-4.164926463304752E-10,0 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark53(41.918830939213166,-0.19300820323894552,0 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark53(42.04416287721182,-0.4983627503544329,0 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark53(42.08939382692279,-2.5391186828839765E-6,0 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark53(42.10051286728019,-1.660572871634307E-7,0 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark53(42.11960967498288,-1.094229344168351,0 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark53(42.16056334693285,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark53(42.168632706340304,-0.36965850003129186,0 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark53(42.18694039811626,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark53(42.33406596063642,-0.9175592715982077,0 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark53(42.47520133256231,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark53(42.47649803157761,-3.322947124244689E-6,0 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark53(42.62098140990749,-0.001398746566183199,0 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark53(42.64328008305037,-0.8534429512462935,0 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark53(42.68417362073219,-2.013813306784405E-8,0 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark53(-42.701126962960856,-1.3722955049043093,38.30826517469381 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark53(4.285040390077199,-0.8687455230137289,0 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark53(42.95168921077763,-0.33460289586907166,0 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark53(42.98043700148915,-0.6450942913323109,0 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark53(42.982726940499745,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark53(42.983627988031415,-3.7690795470513184E-8,0 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark53(43.022740107268106,-0.21509453419187619,0 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark53(4.303470116368821,-0.26576793630459683,0 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark53(43.083094797004115,-1.3733373475844548,0 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark53(4.313399903079684,-0.5947937541293928,0 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark53(-43.13970501132971,-3.552713678800501E-15,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark53(-43.15477349221077,-0.9646752521721779,0 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark53(43.19918416201048,-0.5629989305711218,0 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark53(43.241093578653846,-0.046742774840652146,0 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark53(43.24688910796934,-0.9118679748205949,0 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark53(43.278099697131864,-0.2792144462340609,0 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark53(43.28568386424257,-1.3530357496379395,0 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark53(43.30376549095135,-1.3694421666448093,0 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark53(-43.309932074947774,-0.0873883453285047,73.27830969678473 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark53(43.5350907949377,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark53(4.354114357201629,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark53(4.35552807483005,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark53(43.56719037988367,-1.2493454019195043,0 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark53(43.567688947541455,-1.2934783931733194,0 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark53(43.56847690523168,-1.4340328987203346,0 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark53(43.57158902430601,-0.010334666461225496,0 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark53(43.57187558490705,-4.567418939816081E-10,0 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark53(43.59872087251907,-1.2461496284792988,0 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark53(43.649428561117304,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark53(43.66438162861717,-1.5707963267948877,0 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark53(43.67381246191374,-0.8079929937470496,0 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark53(43.698100669587134,-1.1456958747366555,0 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark53(43.72588666621066,-1.053832642907889E-7,0 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark53(43.741069036169186,-0.5319582237654092,0 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark53(4.378839397501627,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark53(4.385926776517522,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark53(43.925753422689986,-0.07754253214875916,0 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark53(43.93027944144504,-0.5485302588872258,0 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark53(43.98356408222796,-1.57023094353169,0 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark53(4.403959922775215,-1.2305354727570248,0 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark53(44.04761905721924,-1.0530024632737138,0 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark53(-44.10688978791353,-1.5707963267948784,-44.532687484343214 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark53(44.11318458932601,-0.24715376201960026,0 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark53(44.122781458594964,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark53(4.424735556036103,-1.1363743622602824,0 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark53(44.36055792002912,-0.5608647287603323,0 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark53(44.394774095551,-1.4031637444519145,0 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark53(44.39888402785182,-0.7092857720483036,0 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark53(4.440892098500626E-16,-0.03708846720676595,0 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark53(44.484997830710356,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark53(-44.538661292395396,-6.9392708909187005E-9,-1.0 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark53(44.562806674990185,-1.1346536889022474,0 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark53(44.569334117540876,-4.923942681164538E-6,0 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark53(-44.575519652507566,6.559319171389262,30.70531331226428 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark53(44.58625125498381,-1.4565084732137308,0 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark53(44.59365305157368,-0.9412710540249183,0 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark53(44.60297803334291,-1.2441823278880126,0 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark53(44.68403340308341,-0.1492453833625751,0 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark53(44.69481913112281,-0.9206832137264369,0 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark53(44.70017626842476,-9.72661708851699E-9,0 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark53(44.71765082877827,-0.3085209553564156,0 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark53(44.726038255994126,-1.5426197291595551,0 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark53(4.472694468278931,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark53(4.477531346847378,-0.08751624678227587,0 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark53(44.82533355577917,-0.5277639798937228,0 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark53(44.843575334143495,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark53(44.88863030208327,-0.8643599271323792,0 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark53(44.90849899866055,-0.1786517822993261,0 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark53(44.91720600615665,-1.5610616401506388,0 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark53(44.93479507977733,-0.33509689421649114,0 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark53(44.93861066815501,-1.2482215852441667,0 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark53(45.010556592196224,-0.9574065317536111,0 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark53(45.14866499740074,-1.5707963267948912,0 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark53(45.16021566507234,-0.7720716391733395,0 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark53(45.20904418236222,-1.570796326794877,0 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark53(45.318498406223284,-0.34310959437738564,0 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark53(45.35078372234696,-0.45752370854735336,0 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark53(45.353698868561146,-1.5695186423371212,0 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark53(45.40266770731188,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark53(4.540889833905908,-0.2833930632495445,0 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark53(45.44786245345503,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark53(45.501230750254976,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark53(45.51551606811131,-1.5539539936841587,0 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark53(45.546217541208875,-1.570796326794893,0 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark53(4.556243166769704,-0.5289486391422109,0 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark53(45.64235682335487,-0.3628020758644235,0 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark53(45.755746022050246,-1.4562892294287053,0 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark53(45.80503828092978,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark53(45.81819030615313,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark53(45.83311811728504,-0.7968626188908199,0 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark53(45.83805186223478,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark53(45.87270163992534,-1.5707963267948921,0 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark53(45.89630956774144,-1.4180009791029438,0 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark53(4.590851854593751,-0.6195176496241874,0 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark53(46.08857888986734,-0.5310679151506198,0 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark53(46.09165565651537,-1.536366976470985,0 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark53(46.109194346191885,-0.07260956590171475,0 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark53(46.18260045897577,-7.916407003235288E-4,0 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark53(46.195981137583885,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark53(46.241740219604196,-1.570796326794893,0 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark53(46.24285238813653,-0.7972306590739411,0 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark53(4.626035950733225,-1.3142307362740837,0 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark53(46.26772524205708,-1.2245652936510965,0 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark53(46.314545078587685,-0.11810002719596291,0 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark53(46.44283823856269,-0.1462202424029151,0 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark53(46.48837733100475,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark53(4.655640825594574,-0.8740203330092939,0 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark53(46.607610160039314,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark53(46.64045820986071,-1.1211719873715398,0 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark53(46.68518695581287,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark53(46.69303261569925,-0.8223999325782643,0 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark53(46.72723821224588,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark53(46.73300738814987,-1.4524883196191931,0 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark53(46.81830221098332,-0.4637163323093604,0 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark53(46.825786701319004,-0.9462244537690063,0 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark53(4.685603202207162,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark53(46.88215133982021,-1.425363957067077,0 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark53(46.89440493372527,-0.6793917350427527,0 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark53(46.89694904716594,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark53(46.90122637178387,-5.7595964535702756E-6,0 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark53(46.912634744255136,-1.0438795328664705,0 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark53(46.94582541198408,-1.5707963267942493,0 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark53(46.99549544138522,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark53(47.03527697936259,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark53(47.05208483226443,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark53(47.056320784863416,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark53(47.06699484315345,-1.123058058548338,0 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark53(47.084077936370136,-1.493344090487227,0 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark53(-47.184191400077445,-0.6921751741988796,-0.4135682146645614 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark53(47.20469629240751,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark53(47.20524274408476,-0.018820247528728018,0 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark53(47.20634515544862,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark53(47.22758495432977,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark53(4.726272497109349,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark53(47.263832503870596,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark53(47.32051104139515,-0.5785745393605879,0 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark53(47.33618225566144,-1.4334602196685484,0 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark53(4.735750399583466,-0.09860821374798512,0 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark53(-47.37139227123941,-8.881784197001252E-16,91.77398224870282 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark53(47.38063972460108,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark53(4.7447556207051065,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark53(47.46562394016948,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark53(47.473426139174826,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark53(47.4806197776002,-0.5671953937641891,0 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark53(47.48791501178472,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark53(47.53059504918181,-0.17636013176112897,0 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark53(47.54045348074022,-2.8155575845516736E-8,0 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark53(47.58257342551992,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark53(-4.76763017108948,-0.2224353257007126,0.9367790091214128 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark53(4.770962632779316,-1.304893658917295,0 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark53(47.72169815079411,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark53(47.72502916869922,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark53(47.75157640173259,-1.5086217742584722,0 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark53(47.754473792563175,-1.4163071807960108,0 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark53(47.770834134028746,-0.7632841603657425,0 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark53(47.79746610517225,-1.2718529927943945,0 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark53(47.80145634031595,-1.369878746021759,0 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark53(-47.901240536243684,-0.006753910550434804,1.0 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark53(47.96751152059985,-5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark53(47.97045418166561,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark53(47.99857843926307,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark53(48.02691075497091,-2.859448718109035E-6,0 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark53(48.06534490015363,-1.0274979932596433,0 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark53(48.06916544738428,-0.3394509141981277,0 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark53(-48.14990184913262,-2.4142431650271793E-8,-1.0 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark53(48.17269536681761,-1.020680783363412,0 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark53(48.17293188461674,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark53(48.180496351816885,-1.5707963267948912,0 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark53(48.21308338767737,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark53(48.27574772127464,-0.4707899611641575,0 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark53(48.28949118010161,-1.4668188636879336,0 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark53(-4.829910645554806,-9.359821063719505E-8,-1.0000000002016534 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark53(48.30015103925028,-0.5457063544551337,0 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark53(48.30092773579796,-2.326806666913354E-9,0 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark53(48.33585528041237,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark53(-48.35876954688581,-1.5707963267948961,0.0 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark53(48.36038110979869,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark53(48.37300276995049,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark53(48.403583037530495,-0.8801912903007834,0 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark53(48.40847602499892,-0.7673280477482989,0 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark53(48.467897688993986,-1.1881139608288933,0 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark53(48.47745899172854,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark53(48.49382765283573,-1.4625361856621168,0 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark53(48.49416416710619,-1.0432825556835326,0 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark53(48.53221237454372,-0.4162850398787108,0 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark53(48.554512045026485,-0.48860679363422044,0 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark53(48.57317996914355,-1.4780610157414702,0 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark53(48.62564360513428,-0.54574861720716,0 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark53(48.721557790994204,-3.1351688905015484E-8,0 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark53(4.88360780965084,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark53(48.85891799557399,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark53(48.878980861813005,-1.5707963267948912,0 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark53(48.923034706959044,-0.39825582312477437,0 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark53(48.92454918353519,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark53(-48.94871769374845,-3.58864317535604E-6,9.85216829365345 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark53(48.98394489248423,-0.3600957774724045,0 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark53(49.00994481575683,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark53(49.03768495101522,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark53(49.21019911506633,-0.20532266185300208,0 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark53(49.30013978579304,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark53(49.3015995282526,-1.8416000977323749E-6,0 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark53(49.42777758341426,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark53(49.45325977409092,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark53(49.4588083171011,-1.1417602823032524,0 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark53(49.53289044488284,-1.548972199171125E-5,0 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark53(49.54706643560954,-1.0467546826627308,0 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark53(49.55623188765152,-0.044461373092626266,0 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark53(49.564281982529565,-0.5963487008595791,0 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark53(49.57660295926044,-0.381028721923272,0 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark53(49.58043600751864,-1.5707963267948946,0 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark53(49.59046238937802,-0.2595520185712843,0 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark53(49.633513386376926,-0.7549002981012574,0 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark53(49.66746955522129,-0.545743130814731,0 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark53(4.972479487987229,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark53(49.72847677527648,-0.1720649683711798,0 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark53(49.73557973522295,-0.533849174429966,0 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark53(4.978392341995914,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark53(49.80364583010456,-1.475909776661271,0 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark53(49.80794372375607,-1.5707963267948823,0 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark53(49.808471245962025,-1.570796326794893,0 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark53(-4.984500244793949,-0.3336167384025117,-0.7905654009872031 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark53(49.9674127971835,-0.20576310860886915,0 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark53(49.999055712580216,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark53(50.01163139838536,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark53(50.0236396927225,-3.978228783458393E-5,0 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark53(50.060470641896345,-0.19024647768532377,0 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark53(50.09007582720321,-0.6882892843195823,0 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark53(-50.22422787508272,-0.46149108812614814,-1.0 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark53(50.23402696215763,-0.11660076669920905,0 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark53(50.23712195026252,-0.21516082215584476,0 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark53(50.24440454957055,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark53(50.29021416037588,-0.585087156193838,0 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark53(50.32870515210304,-0.0648350760960601,0 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark53(50.38489733893772,-1.1646200306681322,0 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark53(50.43108092033427,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark53(50.45076183708974,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark53(-50.51672828361449,-0.757617338327221,1.0 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark53(50.519398930650794,-1.0928534222839232,0 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark53(50.56332303665249,-1.0579400803271017,0 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark53(50.56717698290799,-1.0979425988253444,0 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark53(50.583768939076776,-0.37886493675971966,0 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark53(50.62497047805839,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark53(50.647900267185754,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark53(5.071217504055198,-0.1903791170425566,0 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark53(5.07240137633878,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark53(50.769778751800295,-0.6405502479375385,0 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark53(5.077435227821468,-1.3236586626197209,0 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark53(50.77798546180395,-1.5707963267948912,0 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark53(50.837805622510274,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark53(50.87051601003978,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark53(-50.9386594485666,-0.0045298493102353754,-71.82482453163988 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark53(50.96852150780114,-0.4448309360442977,0 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark53(51.046327075102994,-1.5140062903829516,0 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark53(51.055854306074416,-2.0336059486044726E-9,0 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark53(5.107480509528031,-0.5060705357671265,0 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark53(51.12598152153751,-0.11880483053719057,0 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark53(51.14179388279953,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark53(51.14436021219278,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark53(51.18033700879715,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark53(51.223135554210444,-1.0397876495825376,0 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark53(51.25137938617213,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark53(51.32230765793136,-0.14516441810448244,0 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark53(51.33912634034675,-0.9324197413604036,0 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark53(51.356899821809606,-75.07301096815067,-65.43680507329887 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark53(51.386636252031934,-1.3483317687192198,0 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark53(51.477550393742746,-0.35734045592939445,0 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark53(5.16451207986843,-1.5666804508582628,0 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark53(51.64877773288788,-1.1505080171389084,0 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark53(51.662260211487336,-98.74374516626901,0 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark53(51.66786395819647,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark53(5.1670602943378725,-0.5002167757222971,0 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark53(51.673889435477534,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark53(51.75545177843976,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark53(51.85575954513326,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark53(51.973278144566436,-0.7258183800045783,0 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark53(51.97666098123737,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark53(51.988619666320005,-1.2688509696608379,0 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark53(52.034803342537856,-0.7692473762738801,0 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark53(52.128158382259485,-0.44854236030191785,0 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark53(52.15684395025649,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark53(52.19120967292417,-1.5707961640251797,0 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark53(52.29543088683033,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark53(52.3103536635939,-0.8515272095216204,0 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark53(52.32112420146561,-1.5243121029718747,0 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark53(52.363384601029026,-0.5862263441896896,0 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark53(52.4265238489815,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark53(52.46082738892562,-0.36184095909253955,0 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark53(52.52076204569721,-0.2055795839651533,0 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark53(52.52937507778134,-1.5707963267838743,0 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark53(52.535877148439965,-0.007008353837612447,0 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark53(52.57667009105322,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark53(52.58700491649196,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark53(52.60622217704031,-1.1586189153514717,0 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark53(5.2617580980851955,-1.4754143954374115,0 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark53(52.62482602570702,-0.20318025990434396,0 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark53(52.645971247933744,-0.3221295302334901,0 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark53(52.657590663485934,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark53(52.701202326619836,-0.0829017348307608,0 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark53(52.73971108275415,-0.2146433799270734,0 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark53(52.75100096585127,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark53(52.75884715687823,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark53(5.2788426612603985,-1.206233848894044,0 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark53(5.283714288952974,-0.7087886425166864,0 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark53(52.94472404076089,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark53(53.00560378570992,-1.3863060362534134,0 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark53(5.304501217719434,-1.0008499463924494,0 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark53(53.06326866722833,-0.16994823547896032,0 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark53(53.08741911185518,-0.5708215613800149,0 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark53(53.10527639861367,-0.8711059385388484,0 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark53(53.11228971448766,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark53(53.12769740415706,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark53(53.13929180326366,-1.5707963267948841,0 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark53(5.316729949756741,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark53(53.196767610296575,-1.5707963267948832,0 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark53(53.25722592783757,-0.3429886444222774,0 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark53(53.26092247897445,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark53(53.272408112769924,-0.5333609266260906,0 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark53(5.329135345331707,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark53(53.312163812097225,-0.03435232457480808,0 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark53(5.333058359654814,-0.05703937541997073,0 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark53(53.37513434566927,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark53(53.39235392914833,-1.4318487807357165,0 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark53(53.39886109011379,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark53(53.47850162211364,-0.1855595161124537,0 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark53(53.486956858891325,-0.9102536510532944,0 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark53(53.525362512786245,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark53(53.56938647747589,-0.5647707825726371,0 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark53(53.5803444531941,-1.2742052254950869,0 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark53(-53.60605902103315,-0.8726865250559571,0.02255027103404339 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark53(53.663155190387414,-1.4954930209662178,0 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark53(5.3689103788597095,-1.570796326794893,0 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark53(53.69189457213511,-0.30431756130406296,0 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark53(53.699674532528036,-1.003387712839313,0 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark53(53.70537770265975,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark53(53.8635296793008,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark53(53.869200115439924,-1.4780798250922942,0 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark53(53.93362758014763,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark53(53.945029318907736,-5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark53(53.9527945197543,-1.5707962756559088,0 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark53(53.99030730052303,-0.9266118741021074,0 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark53(54.023262605470855,-1.8329553148109952E-9,0 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark53(54.05746287868635,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark53(54.08595478828215,-0.044212757632359705,0 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark53(54.08679372032732,-4.0975188151887034E-10,0 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark53(54.11136575627529,-0.18380776879637148,0 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark53(54.1428768600478,-0.6052738304191342,0 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark53(54.2084370973203,-1.4499862837754494,0 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark53(-5.421010862427522E-20,-1.8426721099810932E-8,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark53(54.2603033658921,-0.18523069495095257,0 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark53(54.26591000841185,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark53(54.28862753512163,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark53(54.31987356261533,-0.29352554054277746,0 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark53(5.433295778054955,-1.0162018515151487,0 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark53(54.357576268279416,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark53(54.4438504595063,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark53(54.48157207614006,-1.169889823321932,0 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark53(54.55773764895545,-0.006318886868102336,0 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark53(54.64708534716118,-1.454860510240124,0 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark53(54.66925960883685,-1.0111443493613717,0 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark53(54.74604249430203,-1.410415687629217,0 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark53(54.75011755330556,-0.2739136751994202,0 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark53(54.76124339449743,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark53(54.810286544675876,-1.2620229831817449,0 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark53(54.824954668158654,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark53(5.482984709152987,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark53(54.83664983459525,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark53(54.88940251644332,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark53(54.978334487219264,-1.250159769215863,0 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark53(54.9809963940356,-1.1500720927047468,0 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark53(55.02630044208536,-1.5618870281830022,0 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark53(55.05116019480002,-0.19947585140049284,0 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark53(55.112314470584835,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark53(5.5147558141581593E-8,-0.3540727331166888,0 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark53(55.17364486404452,-0.5940438075837875,0 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark53(55.20232531246842,-0.4969966835116395,0 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark53(55.234730368164634,-1.1239788718101176,0 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark53(55.244149552324494,-1.5456022033477492,0 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark53(55.28791605924354,-0.6827698278215673,0 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark53(55.302556818184655,-1.5707963267948735,0 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark53(55.30971460928765,-0.6019510652410317,0 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark53(55.3838698042959,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark53(55.49686612181134,-1.3487627344730683E-5,0 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark53(-5.551115123125783E-17,-1.4334869139296125,-6.329051100441532 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark53(55.51320370337647,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark53(-55.53591379028543,-0.13302259499707508,-0.9731910244670953 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark53(55.6124026901644,-1.1342779290118548,0 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark53(5.562684646268003E-309,-1.5706789969927464,0 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark53(55.65147170680456,-0.5505782954857595,0 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark53(55.6721041202473,-0.2355079201762198,0 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark53(5.5842276518967395,-0.06581633934294473,0 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark53(55.862343923800466,-0.9950264185108466,0 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark53(55.86549874372431,-3.865034719637715E-8,0 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark53(55.871480982698934,-0.2803980415271199,0 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark53(-55.872425187146256,-0.5853343135498585,-30.796927099156115 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark53(55.88440199406023,-1.097876406308532,0 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark53(55.903934484152806,-1.2486431828723283,0 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark53(55.9774638450734,-0.5520547291062181,0 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark53(55.99904822763201,-0.6697635813739565,0 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark53(56.00742390178928,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark53(56.06554979743075,-0.15673405967209675,0 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark53(56.076244886071684,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark53(56.08033037803875,-1.1826166773321525,0 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark53(56.08699773156775,-0.3154547232318894,0 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark53(56.161471120038584,-1.5707963267829257,0 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark53(5.626511394832278,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark53(56.26530799942947,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark53(56.440247013292705,-8.708301945446859E-10,0 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark53(56.51744846230511,-0.15747125036287457,0 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark53(56.63999457035101,-1.43507571387687,0 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark53(56.6448657685749,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark53(56.68600979246164,-1.15304629460233E-5,0 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark53(56.722559067168845,-0.2662892574612181,0 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark53(56.74149448529977,-0.8490721029329347,0 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark53(56.79295257174987,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark53(5.683738718590524,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark53(-56.88472604515396,-0.1584991933960264,-1.0 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark53(56.89349328386241,-2.0268716714579864E-8,0 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark53(56.90384467854824,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark53(56.970320351096234,-0.6787034933819688,0 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark53(56.974060016165026,-0.36029209903909987,0 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark53(56.988503024936655,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark53(57.09867941222885,-0.1857109343866199,0 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark53(57.105595188322184,-0.8689728323122665,0 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark53(57.10837045135711,-0.2871892541815071,0 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark53(57.25218169173684,-0.998753013074781,0 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark53(5.725601089018639,-0.5749498387501828,0 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark53(57.298345874370824,-1.2977709315146662,0 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark53(57.36955244910638,-1.570796326794893,0 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark53(-57.3846481791504,-1.4698202805138474,1.0 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark53(57.38898397430046,-0.14539125033042222,0 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark53(57.40425495704713,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark53(57.42665814375464,-0.03956562227279564,0 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark53(57.44742397862788,-0.10897690792163656,0 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark53(57.480811887983435,-1.0875431904295967,0 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark53(57.49043800888401,-0.1729408327994495,0 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark53(57.50624729146286,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark53(57.51770686379666,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark53(57.55671458577888,-1.00847154683556,0 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark53(57.6044157439197,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark53(57.63642561721471,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark53(5.7647482670212025,-0.053618338765479834,0 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark53(57.69777796153209,-1.4066337800735722,0 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark53(57.72409360590376,-0.5613949233989166,0 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark53(57.7254832621457,-1.150979786690185,0 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark53(57.73044475765508,-1.2973562620319612,0 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark53(57.73859726121299,-0.5406394860538342,0 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark53(5.774622038864919,-0.995592566820541,0 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark53(57.801411474079856,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark53(57.80475200192473,-1.010297818167687,0 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark53(57.94068894488083,-1.5707963267948761,0 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark53(57.94389105871829,-1.5707963267948952,0 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark53(5.794482134598541,-1.570796326794893,0 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark53(57.95965769450453,-0.6451777438172925,0 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark53(57.97838975215029,-1.2857319832224907,0 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark53(57.98843773136322,-1.3933837828133022,0 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark53(58.07482387187724,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark53(58.16576505482928,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark53(58.21532675590106,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark53(58.2287223770208,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark53(58.28208620968977,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark53(58.32688439282728,-1.5631990262320556,0 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark53(58.33142290818472,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark53(-58.39308899759577,-0.2184728180232432,0.0 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark53(58.453346270558036,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark53(58.45458912561192,-0.012706645842326003,0 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark53(58.50588960548339,-0.6796205614040444,0 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark53(58.52791475761969,-2.963301375502989E-5,0 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark53(58.57622881012833,-1.570796326794893,0 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark53(58.60860547600042,-0.727805711672973,0 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark53(58.63786095017454,-1.5366353624608053,0 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark53(58.67129757686925,-1.0226456147150742,0 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark53(58.70422909027678,-0.8137300851693048,0 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark53(58.704903393303624,-0.8405188048825769,0 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark53(58.70875429665946,-0.6650926858991086,0 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark53(58.860973583408594,-0.1811990840871136,0 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark53(58.87039443500612,-1.3048049655612912,0 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark53(58.89750704738651,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark53(58.93885134924943,-1.890259808815429E-8,0 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark53(58.95030532913805,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark53(58.961654173866236,-1.5707963267948912,0 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark53(58.97034064434154,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark53(59.008614476137865,-0.2146433325979864,0 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark53(59.017601293706775,-1.570796326794893,0 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark53(59.01847028168986,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark53(5.902836678174268,-1.5707963267948895,0 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark53(59.052229410170185,-1.166697115370937,0 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark53(-59.068884359870985,-1.570796326794893,-1.0 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark53(59.08330811658655,-0.03922281979638775,0 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark53(59.09050057760786,-0.008202529541523583,0 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark53(59.11020136844101,-0.3621919721561988,0 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark53(59.1314052165624,-0.3617317123946747,0 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark53(59.147451229406215,-1.1924227538689252,0 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark53(59.15422976689502,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark53(59.15714184865778,-1.0966648558570611E-7,0 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark53(59.208039177542105,-0.7611954932882528,0 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark53(-5.9230998550615634,-1.0176956552038403,-0.06255325511224041 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark53(59.30766604848026,-0.39288527126930683,0 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark53(59.33570153941227,-1.4256931935312984,0 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark53(59.423598821246486,-0.7778897954162023,0 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark53(59.51664014768729,-3.0988674956209717E-9,0 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark53(5.952734212603048,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark53(5.957269518203928,-1.0128029010928634,0 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark53(59.613225541122404,-0.22470127327224437,0 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark53(59.63782283164051,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark53(59.66199951637088,-0.1587719940355543,0 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark53(59.68387628124796,-0.8294533633627026,0 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark53(5.968714249880689,-1.3433095355479594,0 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark53(59.728442885290434,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark53(59.835518816768996,-0.31632885489978996,0 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark53(59.91205254433163,-4.3403131349528683E-10,0 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark53(-60.036874660792236,-1.570499932771454,-0.5235084687959842 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark53(60.04086408125323,-1.4429239991996834,0 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark53(60.065271197077635,-1.1921473441637351,0 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark53(-60.06740151464294,-71.99408928208032,64.49515340257733 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark53(60.075697290053625,-0.9188824273755367,0 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark53(60.100814849175286,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark53(-60.101590789352315,-1.3696983838930087E-9,37.73701129398418 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark53(60.11114573676218,-0.19234996501921398,0 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark53(60.1690674319168,-0.3996128781726913,0 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark53(-60.19153909260186,-1.7763568394002505E-15,-20.72304747259162 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark53(60.2862986735521,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark53(60.3057213992536,-1.372413583773735,0 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark53(60.348453444367806,-2.175894875253798E-4,0 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark53(60.35892167356472,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark53(60.37469419236519,-0.6322743336282481,0 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark53(60.42038038704146,-0.3543479175497394,0 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark53(6.0451061192294295,-0.8317525685764844,0 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark53(60.50327096214275,-0.9098350753733655,0 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark53(60.50998476228179,-0.9847066084761877,0 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark53(60.53777326996649,-0.4810749367751477,0 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark53(60.58802749460122,-0.12822924959949233,0 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark53(60.59691932295607,-0.9756029413701448,0 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark53(60.716735448200694,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark53(60.77509893085013,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark53(-60.7880217763461,-1.5707963267948961,-1.0 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark53(60.80581355992305,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark53(60.8104466825929,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark53(60.82316959494031,-1.504497729138068,0 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark53(60.84011536361072,-0.009228941064691298,0 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark53(60.869877932554886,-92.42956655036652,95.81596688335742 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark53(60.89337391668802,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark53(6.091543795480163,-1.2566481561438145E-9,0 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark53(61.0430055546927,-0.10562129148357571,0 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark53(61.08433226457578,-0.6416565792686126,0 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark53(61.10029773202554,-5.796124401412015E-10,0 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark53(61.11809109023968,-5.914662493122247E-10,0 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark53(61.155676780990234,-0.9477463589309973,0 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark53(61.18524146969245,-0.27149268265160426,0 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark53(61.250069078899195,-2.929160836808519E-8,0 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark53(6.125450994797376,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark53(61.26289371810685,-5.815324184410459E-5,0 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark53(61.27928421996165,-0.41922557372416236,0 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark53(61.319052604851464,-0.870605372304297,0 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark53(61.32629291702142,-1.570796326794742,0 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark53(61.338181181907714,-0.04862146741098172,0 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark53(61.357637701465706,-1.570796326794894,0 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark53(61.36694464169331,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark53(61.376949236026874,-0.27477814966469616,0 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark53(61.403999029032605,-1.1607150715385592,0 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark53(6.1406800660462295,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark53(61.49605047139188,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark53(61.583141464706614,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark53(61.64270289121061,-0.008594092101993356,0 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark53(61.6430131739721,-1.5484926329088813,0 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark53(61.75244188345846,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark53(61.76036678460687,-0.7746336122631376,0 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark53(61.77074285401454,-0.6446722437904012,0 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark53(61.774228643418375,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark53(61.809983944279736,-1.3237216687533646,0 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark53(61.825507569058146,-0.6632454891857362,0 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark53(61.863546282759586,-0.7686765190340292,0 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark53(61.93171737480998,-0.3378363783138252,0 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark53(61.98849679716449,-0.4423044171395065,0 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark53(62.00194607724663,-0.4088516174187049,0 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark53(62.00685515225669,-1.224584291972036,0 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark53(62.02790799017694,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark53(6.202973283869026,-1.3768471183143456,0 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark53(62.03396908160494,-0.5956607432963725,0 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark53(62.03642048613317,-5.761777616087375E-10,0 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark53(62.0720513852705,-1.4538047509882652,0 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark53(62.14373102276858,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark53(62.17493314238004,-0.10364558238914157,0 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark53(62.21169101409808,-1.1037142467096714,0 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark53(62.22771260883488,-0.026550074768023235,0 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark53(62.3589479497756,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark53(62.380126260146554,-0.4186830819366122,0 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark53(62.38348502042865,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark53(6.241964850126434,-0.10972275608309556,0 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark53(-6.24458959777658,-1.5707963267948957,0.03558049790604745 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark53(62.53291548567802,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark53(62.55302798842777,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark53(62.58148626719493,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark53(-62.592280677227954,-0.2085325428150743,37.09423668019261 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark53(62.62034601485423,-0.6454187160261325,0 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark53(62.63999188713909,-0.6465666702407766,0 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark53(62.69655210750679,-0.5788468263433428,0 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark53(-62.707876955627626,-1.5937788007169655E-7,-1.070324073763357 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark53(62.74045693379402,-0.7758131672519402,0 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark53(62.75730160910621,-1.2402480392788426,0 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark53(62.777940449468815,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark53(62.78316285379822,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark53(62.80013886516356,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark53(62.815230953768406,-0.12509823270462248,0 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark53(62.81752861394642,-3.947061659595249E-9,0 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark53(62.87312557108162,-1.554793015755859,0 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark53(62.881773480992706,-0.849997886353762,0 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark53(62.92179504960447,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark53(62.95899200809879,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark53(62.989262431634025,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark53(-63.084051029728656,-2.623383369154021E-9,-2364.3263440529213 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark53(63.11795838037817,-5.150969092761114E-7,0 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark53(63.11833072943648,-0.05127844897113221,0 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark53(63.2262661902019,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark53(63.2633887652955,-0.5596762502085735,0 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark53(63.26622790207617,-0.8539629969372307,0 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark53(63.322441286095966,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark53(63.36758123168923,-1.3654552622037102,0 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark53(-63.39724078082575,-0.506615317851415,0 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark53(6.345609358664035,-0.08770387396862311,0 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark53(63.56151660424962,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark53(63.56853711092484,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark53(63.637685534351675,-1.3128737458508795,0 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark53(6.366380706637315,-0.6787335513612858,0 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark53(63.68469269011547,-1.458371860850491,0 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark53(63.69429540802067,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark53(63.72155219695898,-0.25356253554787145,0 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark53(63.72901027054857,-0.7980981010372447,0 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark53(63.85956393939264,-0.015458289401328429,0 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark53(63.901832544400484,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark53(64.03055772337892,-0.8906855586260249,0 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark53(64.06129006601668,-0.15392469799910252,0 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark53(64.06751010664658,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark53(64.1507402743673,-0.5442960015670663,0 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark53(64.17153826185131,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark53(64.17590751364745,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark53(64.20793758601883,-0.14792896381034382,0 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark53(64.24556557801642,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark53(64.26652704072279,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark53(64.2679918470927,-0.6828916975001178,0 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark53(64.28776985500899,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark53(64.29136306176133,-4.0552624105051596E-10,0 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark53(64.29406018069938,-1.5707963267948886,0 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark53(64.39303533699211,-0.5075433163715246,0 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark53(6.439986808553311,-1.570796326794517,0 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark53(64.49520803788027,-0.48607819844832534,0 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark53(64.50638028187268,-0.7399498043330068,0 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark53(64.51812774784196,-0.12197468507021736,0 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark53(-64.5609389315743,-1.5707963267948895,65.25902154817734 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark53(64.58161565407724,-1.4142871447764485,0 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark53(64.5980045448938,-0.992373511144919,0 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark53(64.61534068588705,-0.5837117000144547,0 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark53(64.64622866173198,-0.929073140229667,0 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark53(64.65778983770821,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark53(64.70494992334406,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark53(64.7211300033511,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark53(64.78686559805209,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark53(64.79034613052136,-0.16901483443914778,0 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark53(64.80984417734243,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark53(64.82644788703325,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark53(65.0406090682985,-0.026448027845589195,0 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark53(65.06019926297813,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark53(65.08508153959525,-0.011712089402465153,0 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark53(65.16048870131367,-0.2491252956876755,0 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark53(65.17187307375403,-0.6202185729233278,0 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark53(65.19141113376641,-1.1768907375356417,0 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark53(65.1974447013821,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark53(65.20201276092646,-1.160557869457306,0 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark53(65.23103284189312,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark53(65.29872392310247,-1.035364936696653,0 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark53(65.31335293445227,-0.6129011788141128,0 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark53(65.37970089717656,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark53(65.40191263188049,-1.4964783947855267,0 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark53(65.41267960072756,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark53(65.42564723762354,-0.6961255051961608,0 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark53(65.45026915393217,-0.21715056037801972,0 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark53(-65.54606275368246,-1.5707963267948948,1.0000000032670309 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark53(65.57166126706409,-1.2364495182646331,0 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark53(65.60633348989067,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark53(65.61777852471053,-0.9960859353157492,0 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark53(65.7262441729178,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark53(65.80396214703447,-1.357111640960504,0 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark53(65.81089441741187,-0.502293869015972,0 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark53(65.8934776968266,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark53(65.94450593178453,-0.44141303421991207,0 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark53(6.600051133285504,-0.33664850076175146,0 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark53(66.0005433148807,-0.17957607583793145,0 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark53(66.05983540098549,-1.2515203013199256,0 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark53(66.15771321688393,-1.2545968207578815,0 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark53(66.16494227716504,-1.4464924955972007,0 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark53(66.21646622396034,-0.6895423037517361,0 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark53(-66.21764407136052,-0.49336681699951357,1.0 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark53(66.2612108455423,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark53(66.34249132504628,-1.445265098991436,0 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark53(66.39623449715367,-1.570796326794893,0 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark53(66.40700520419145,-0.6548111855887532,0 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark53(66.43365607136187,-0.11834139528004561,0 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark53(66.47180740921277,-0.4150363680092344,0 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark53(66.50348464877847,-4.883165928869081E-7,0 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark53(66.53069867306512,-1.1779567185287885,0 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark53(66.55026172401816,-0.13226703193174405,0 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark53(66.58390977688404,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark53(66.59915693509583,-0.7133148804160072,0 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark53(66.62576970177227,-0.4518650610574926,0 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark53(-66.65904029303783,-1.5707930305181994,0.043674677011005164 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark53(66.66887540514868,-1.2703453586005016,0 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark53(66.68249506114637,-0.6121371360313503,0 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark53(66.72177903819502,-1.5108023843517135,0 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark53(66.736582235301,-0.0205415793905388,0 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark53(66.79502740562587,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark53(66.81355445978716,-1.570796326794894,0 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark53(6.689902867104642,-1.4463001704358924,0 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark53(66.96194297081213,-0.9295550230792203,0 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark53(66.98346779111236,-0.5394100274740907,0 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark53(67.01217352488388,-0.5837944636397736,0 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark53(6.705909223504108,-0.9483734347516872,0 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark53(67.06219563792081,-4.1424133765363316E-10,0 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark53(67.08338284896357,-0.6210253330215068,0 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark53(67.15002823577214,-0.7483675175466424,0 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark53(6.71863231931558,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark53(67.21818695106887,-1.4789497366837523,0 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark53(67.25345557663934,-0.7057262281302079,0 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark53(67.26755477065633,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark53(67.27196497645761,-0.017667128390825404,0 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark53(67.3323112574401,-0.32417725513546625,0 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark53(67.3553921474844,-1.1703948843940502,0 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark53(67.3579830522865,-0.5613717698496483,0 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark53(67.43155598410448,-1.538906624636644,0 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark53(67.48311577117258,-1.1748204354742848E-5,0 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark53(67.50079764704924,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark53(67.51776255679141,-0.2702524903692112,0 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark53(67.57500531508022,-1.3482956804912605,0 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark53(67.57661061390144,-1.5630701628612371,0 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark53(67.59217517778112,-0.25595923895427075,0 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark53(67.60967922428252,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark53(-67.61330461931128,-0.7421885859784023,-1.0268766775554116E-16 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark53(67.65574121551566,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark53(67.6676463807524,-0.9035376856712894,0 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark53(67.67276888238865,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark53(67.70057074336785,-0.8734041228314888,0 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark53(6.7715123815139435,-1.2902926535741415,0 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark53(6.773938468847106,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark53(-6.776263578034403E-21,-0.3535295876220478,0 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark53(67.81917802543376,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark53(67.90421555980151,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark53(67.93864414348496,-0.6454002358731934,0 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark53(67.95260978211911,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark53(-67.96719139268838,-3.552713678800501E-15,-0.9999999999999982 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark53(68.00059462992834,-1.4734540730133148,0 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark53(6.801890708487377,-1.20295694289943,0 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark53(68.08543763313429,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark53(68.27269056581272,-0.42993579457413933,0 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark53(68.27682399928636,-0.5541260205636362,0 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark53(-68.30510403208088,-0.014044592970676308,0.37889013915480607 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark53(6.831828638092377,-1.4798892380692181,0 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark53(68.34086311754791,-1.4146115604686784,0 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark53(68.34789627747216,-0.4349203961167518,0 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark53(68.35832165460272,-2.8914039762719188E-8,0 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark53(68.369443491346,-0.07964354371252114,0 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark53(68.3740954981854,-1.2535497156667788,0 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark53(68.3915395342216,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark53(-68.39843683965256,-0.24934022635510178,0.18095176299626292 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark53(68.40188716105823,-5.033260826034464E-10,0 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark53(68.41880600175601,-1.5177381489067042E-9,0 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark53(68.42277938937008,-0.6297544453080377,0 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark53(68.48392523279728,-1.201540424544392,0 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark53(68.48637472523772,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark53(68.49099397159034,-0.5138694254900571,0 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark53(68.54838242773047,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark53(68.55321114347467,-5.869791669008926E-8,0 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark53(68.59542099666825,-1.428204779853587,0 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark53(-68.60525677216923,-1.5707963267948948,-1.0 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark53(68.60582126029246,-2.1298474628485605E-9,0 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark53(68.63112033350697,-1.5707963267948912,0 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark53(68.63589062994194,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark53(68.63917497083413,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark53(68.65359348597795,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark53(68.69904745299996,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark53(68.78231039887649,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark53(68.78418056084405,-0.18925945802351762,0 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark53(68.81516533594483,-1.5556590663266743,0 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark53(68.85745419720759,-1.2574367723650113,0 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark53(68.8605687404408,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark53(68.86067876288254,-1.174488665864165,0 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark53(68.87342936056478,-0.9949668266437897,0 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark53(68.90300930467822,-1.2971383764733417,0 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark53(68.91909967137255,-0.8919083945754469,0 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark53(68.92752291273656,-2.516820478944702E-7,0 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark53(68.94808203750452,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark53(68.95131371776833,-0.41122950122668556,0 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark53(68.9605231139405,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark53(68.97414280809613,-0.10120817348170874,0 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark53(68.98783886932992,-1.3586968143029168,0 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark53(6.899406647701284,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark53(69.05672146863046,-1.5696966166552526,0 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark53(69.06140001376241,-0.7235035861676602,0 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark53(-69.08715180164336,-0.9372159570262255,-7.143607923729405 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark53(69.09487530542782,-0.2316098251645773,0 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark53(6.912679109421475,-0.68883902849295,0 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark53(69.20988046571881,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark53(69.31129673280634,-2.2130876069496123E-4,0 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark53(69.38828929571615,-0.9453151372827477,0 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark53(6.944896959082271,-0.6571054770111844,0 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark53(69.53934103704887,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark53(69.54932218780765,-1.3957910861746647,0 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark53(6.958618994084434,-1.570796326794888,0 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark53(69.58742647288209,-0.9852917450675488,0 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark53(69.58877656909135,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark53(69.59277233064026,-1.570796326794893,0 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark53(69.66769330752152,-0.7746795502710171,0 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark53(69.69840302672995,-8.014701795973278E-4,0 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark53(69.72397928319096,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark53(69.77023638310874,-1.2977919096389192,0 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark53(69.77409558644521,-0.2048119062809359,0 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark53(6.981297316138878,-0.4294039164761472,0 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark53(69.84578816045658,-0.9675650781152427,0 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark53(69.87643385397249,-0.001910771116155329,0 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark53(69.87809290090186,-0.8354402654861008,0 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark53(6.9878130820145685,-1.201289124694359,0 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark53(69.92916801867582,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark53(69.93149583235184,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark53(7.000559952831987,-0.07438105666781092,0 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark53(70.05587288779898,-0.9369678903846683,0 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark53(70.07278364000703,-0.5766969472073853,0 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark53(7.009417067835557,-1.41715689117776,0 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark53(70.1404034214865,-0.9624330128748682,0 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark53(70.14227058030804,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark53(70.16418826246291,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark53(70.1770524509493,-0.4341639940346198,0 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark53(70.19755289799113,-0.7945831115043944,0 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark53(70.20726228828218,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark53(70.26103890769446,-0.8168586261818835,0 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark53(70.32003213324543,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark53(70.36109081016565,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark53(70.3785331404361,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark53(70.43817126948085,-1.2121310023750436,0 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark53(70.47490931120143,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark53(70.49152862600687,-1.4968839090011812,0 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark53(70.53119702298588,-1.1988274346379555,0 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark53(70.54306776369971,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark53(70.5550095933896,-0.10881558037524641,0 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark53(70.57409432574778,-0.09350629040489666,0 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark53(70.61308547940158,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark53(70.64921420653587,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark53(70.65930242699318,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark53(70.66916848656075,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark53(-70.68660292555376,-8.728937132764921E-10,-100.0 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark53(70.72298253723969,-1.4500020957442066,0 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark53(70.78121991421685,-1.132671065983331,0 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark53(70.87735307950999,-1.4300150594155403,0 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark53(70.88110431199098,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark53(70.88791668988947,-0.5310876098537634,0 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark53(70.89242280293357,-1.4125739020201245,0 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark53(70.93048106176099,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark53(70.96129557129757,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark53(71.03153455346137,-1.5306034678942293,0 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark53(71.03893783784143,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark53(71.06801683080053,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark53(71.10300462931502,-0.3491309211489835,0 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark53(71.1171482799,-0.4594254628051202,0 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark53(71.14317910673486,-6.0589442111757366E-5,0 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark53(7.115488637388026,-1.285267486786907,0 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark53(7.1157212706553254,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark53(71.159050778199,-4.061982338813982E-8,0 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark53(71.23816779166071,-0.39543835379609094,0 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark53(71.4696713561435,-0.21429440097288466,0 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark53(71.47015004566816,-1.4247128697135452,0 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark53(71.48121755263455,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark53(71.49904901725915,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark53(71.51784254646321,-1.0495527246319956,0 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark53(71.55120920112344,-1.1993845092966353,0 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark53(71.55307921511718,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark53(71.56133067914053,-1.5707963267948024,0 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark53(7.159808642020408,-1.1435141919039,0 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark53(-71.62603558601775,-1.0897565350709635,-0.015440899398076047 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark53(71.62868294687331,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark53(71.65255622523448,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark53(71.7279367565072,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark53(71.76325185968261,-1.307219009491977,0 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark53(71.79512596131616,-1.9266171109334917E-5,0 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark53(7.18179332440414,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark53(71.84344713709899,-0.6936424787192834,0 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark53(-71.86943226527033,-0.4121613215633111,-1.0 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark53(7.187943412162582,-0.7162203770971747,0 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark53(7.189779030533135,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark53(71.9052642787099,-1.4802384903759105,0 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark53(71.91578978184982,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark53(71.93800974673711,-0.9121630753853134,0 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark53(7.196432310772493,-1.1907084001860553,0 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark53(71.98968192359433,-1.5707963267948628,0 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark53(71.99169623343263,-1.5707963267948664,0 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark53(7.2061706004787,-1.290257440787741,0 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark53(72.08790954744094,-8.554694114496667E-9,0 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark53(72.11177411966924,-0.797918925758653,0 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark53(72.13565659730457,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark53(72.17234304969696,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark53(72.18069377123504,-1.5707963267947953,0 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark53(-72.19030757970202,-1.3049816291872292,86.1672173559802 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark53(72.20559173858612,-0.41692700379727654,0 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark53(72.21439292923611,-1.3007915180310037,0 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark53(72.21925773854038,-0.7813444336992461,0 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark53(7.230971846774656,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark53(72.34642341105771,-0.2347867461828277,0 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark53(72.35018418142403,-1.4078706356691226,0 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark53(72.36598031499081,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark53(72.38069312218244,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark53(72.44145795448404,-1.2527469538019833,0 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark53(72.4535987582145,-0.6389194915653107,0 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark53(72.46616690313522,-1.4387633723745665,0 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark53(-72.47859651425745,-64.61505771128947,-64.35404968678726 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark53(72.5168481310047,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark53(72.53160249189716,-0.1551738506436422,0 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark53(7.253645582719132,-0.9227561872756667,0 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark53(72.55340900352684,-1.2564223494665745,0 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark53(72.70484591917054,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark53(72.72998180461023,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark53(7.276001490869432,-6.696485333272865E-8,0 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark53(-72.79943636163269,-6.0873628440878E-8,13.891889062364575 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark53(7.2826320707781065,-0.0757604770742688,0 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark53(72.85576292510578,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark53(72.87461136949658,-0.3112892695228595,0 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark53(72.92100456001874,-0.9455692537043063,0 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark53(72.93834793605512,-1.287391392958341,0 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark53(72.94511140108534,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark53(73.00358561550443,-1.023856190087162E-8,0 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark53(73.06535753525483,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark53(73.08019703196844,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark53(73.10137108638185,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark53(73.10948602957365,-0.05045690901051714,0 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark53(73.12080073897528,-1.3901254122580857,0 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark53(73.12646572257991,-1.4375157148180155,0 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark53(7.315062034201308,-0.29933461314434634,0 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark53(73.17729624004008,-1.1671282481408991E-8,0 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark53(73.24728440989253,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark53(73.24851750159482,-0.8657860723314279,0 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark53(73.29707930835858,-1.2314615423468922,0 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark53(-73.29713085573569,-1.3546618183408734,0.6006742333868474 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark53(73.3067544214249,-4.663678241612276E-10,0 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark53(73.30827416044984,-0.5500199691378925,0 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark53(73.30922359229112,-1.2776438919286894,0 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark53(73.36812850139611,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark53(7.338429164963941,-0.5223191759210344,0 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark53(73.39111538035601,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark53(7.34175284883203,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark53(7.345623894391679,-0.18857956396735265,0 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark53(73.54044778826841,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark53(73.58414110861767,-1.2025648005698528,0 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark53(73.59170401328872,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark53(73.64750538582544,-1.1056646493437379,0 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark53(73.64760893505135,-0.3012184527016999,0 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark53(73.67513627523249,-0.416499275121482,0 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark53(73.67646692042419,-0.46122865850440964,0 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark53(73.72869117230044,-1.074146803343183,0 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark53(73.77736932581033,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark53(73.78873901194468,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark53(73.80063449948818,-0.26593910293081535,0 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark53(73.82529244706146,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark53(-73.84251795716257,-1.4011715706158527,-7.600004245398625 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark53(7.384408007658223,-1.0047575412582157,0 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark53(73.88448503884561,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark53(73.98673733536683,-0.3596142340966878,0 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark53(7.402740982490258,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark53(74.08323620185429,-0.3284071807873141,0 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark53(74.10920712911258,-0.09374471986661526,0 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark53(74.18127422794169,-1.120388129212742,0 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark53(74.23056416325397,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark53(74.27442503384721,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark53(74.3759701233073,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark53(74.40797306837757,-0.8065680288223565,0 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark53(74.42084415451532,-0.27768795706658755,0 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark53(74.42583959698618,-0.6845783798819409,0 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark53(74.43740051332037,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark53(74.5150570632027,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark53(-74.52079986962451,-1.5015930695719888,-1.000000056094281 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark53(7.457944162898826,-1.0580244337317737,0 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark53(-74.69580898791213,-0.18121189119155703,-1.0 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark53(74.72640969288251,-2.1681932358506774E-5,0 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark53(74.80852604703682,-1.529832515539519,0 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark53(74.82199900159893,-0.10047713871815489,0 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark53(75.02217224374971,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark53(-7.503750289436335,-1.2831866394927323,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark53(75.11747537898927,-0.6785128915621748,0 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark53(75.14405062681081,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark53(75.2046419548343,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark53(75.24192452207444,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark53(75.26479825271616,-0.5657957754263094,0 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark53(75.26941051050763,-0.25163677058711953,0 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark53(75.36123846284687,-0.35642922166111757,0 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark53(75.36212415782585,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark53(75.42742736403001,-1.498273008564926,0 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark53(75.43748859177461,-0.15319664570501956,0 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark53(75.44549891707405,-1.570796326794894,0 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark53(75.45666835004053,-0.1352967731776875,0 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark53(75.48138706966483,-0.6592260755965729,0 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark53(75.52569585589502,-1.5105388121388046,0 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark53(75.5931039846867,-0.5503611811815685,0 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark53(-75.67315224383384,16.33157078681134,18.15134073313729 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark53(7.571346554742917,7.829171903328373,-83.37346978956023 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark53(75.75261430873442,-1.3805949469691194,0 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark53(75.77448704576221,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark53(75.78661840759908,-0.6302034919732957,0 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark53(75.79158733908238,-0.5585205846741559,0 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark53(75.86242933350772,-1.0192139136221832,0 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark53(75.89738749426496,-0.3232708719676034,0 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark53(75.94168843632345,-0.11419973644963544,0 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark53(76.04055351266183,-2.0336624449542025E-5,0 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark53(76.04133537200002,-0.07740912017909074,0 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark53(76.04446378432857,-1.5428081353599419,0 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark53(76.05322850996262,-1.0552803839576512,0 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark53(-7.609399589967366,-1.4790053082528567,-0.6849839404073501 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark53(76.16258431035529,-1.1040955917187398E-7,0 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark53(76.18110632496285,-0.3781067421860591,0 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark53(76.26786723659075,-0.6708191011052194,0 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark53(76.2859142326831,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark53(76.30525559682515,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark53(76.33669727137098,-0.19829219391779151,0 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark53(76.34135538204038,-0.6954853268455308,0 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark53(76.39228546291125,-0.016413061977416987,0 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark53(76.45027279484228,-1.5707963267948841,0 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark53(76.45207633015875,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark53(76.55418319181072,-1.3651810198312688,0 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark53(76.56583520585765,-0.6968914846332059,0 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark53(76.60711341254077,-0.5893785660515665,0 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark53(76.66676643324132,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark53(76.67464533812318,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark53(76.73466767016565,-1.1724090131683909,0 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark53(7.676945644516849,-1.570267307009047,0 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark53(76.79147170395905,-1.4457798361091871,0 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark53(76.80642492770195,-0.9829305601523535,0 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark53(76.81274247484387,-1.4989953058381644,0 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark53(76.84502511765834,-0.6861137562518884,0 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark53(76.8802841074178,-0.9017415177702555,0 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark53(76.88272795474592,-1.2071584850946793,0 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark53(76.93562236077557,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark53(76.93887004830856,-1.5707963267948912,0 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark53(76.95188939789335,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark53(76.96368305062833,-0.0841703282250208,0 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark53(76.97785924238423,-0.42990111894718197,0 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark53(76.99767459205779,-1.023781864993476,0 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark53(77.00139011252958,-1.004507568888684,0 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark53(77.05091793849596,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark53(77.05432140472738,-0.4794913869188262,0 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark53(77.0596500447258,-0.38325739051113406,0 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark53(-77.07875347688895,-1.5207904350203219,29.967671941464005 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark53(77.11425542949364,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark53(77.16014143530393,-0.10653710737722122,0 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark53(77.2349454052849,-0.8533088638998496,0 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark53(77.32088316947502,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark53(77.35122159168071,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark53(77.36404620776683,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark53(77.52732341694093,-0.31647121890474245,0 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark53(77.55744594607052,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark53(77.59853294232445,-1.5707963267948877,0 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark53(77.647246083289,-0.09892741567101382,0 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark53(77.67184852196971,-0.7056473944250286,0 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark53(77.75552802441048,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark53(77.7624566734001,-0.5309075297148098,0 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark53(77.77256015528806,-1.5707963267948877,0 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark53(77.77516663205824,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark53(77.78029650015372,-0.9162610902204875,0 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark53(77.81311577295119,-1.4573124349842035,0 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark53(77.95557441594464,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark53(77.96875116624611,-0.5818470837050648,0 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark53(77.9812850779195,-0.20856182278538427,0 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark53(78.06208441827107,-1.5357278247922337,0 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark53(78.17448967397169,-0.9792616556727012,0 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark53(78.27510059687464,-0.012297453058417673,0 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark53(78.29509470973457,-1.4792116752662476,0 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark53(78.37135552129229,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark53(78.38963900543979,-0.7501330809145266,0 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark53(78.45675831676203,-0.19469574831360603,0 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark53(78.47530025798932,-1.570796326794893,0 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark53(78.48951805392952,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark53(78.55289534506171,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark53(78.57707910835596,-5.111906382062515E-10,0 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark53(78.66440890723888,-1.016300602442336,0 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark53(78.70673826745102,-0.6063648820788643,0 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark53(78.72456266109798,-0.30841943952164885,0 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark53(78.73908242179465,-0.10575431321095996,0 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark53(7.880356360318835,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark53(7.88536437467711,-1.5703982716691023,0 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark53(78.88825758827934,-1.570796326794893,0 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark53(78.9301421560612,-0.28100716774329015,0 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark53(78.98162696965723,-0.8304401798017742,0 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark53(79.0517066121977,-1.5704073879142089,0 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark53(79.06621008431136,-1.3415095322096657,0 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark53(79.07305452645173,96.6881425209624,-37.34960120855744 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark53(79.09230052184415,-0.22812307648604513,0 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark53(79.15281302649431,-0.6722875878941772,0 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark53(7.924697140759216,-0.5733154139323045,0 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark53(79.24759710577666,-0.7250967139024447,0 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark53(-79.35310918596099,-3.552713678800501E-15,7.719417531851917 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark53(79.39373890588425,-0.08204107052176113,0 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark53(79.41776557210969,-0.9646009519934085,0 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark53(79.42353986427422,-4.750011433508534E-10,0 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark53(79.43564031988569,-0.20922690737752703,0 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark53(79.45883792917945,-0.07041526047082769,0 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark53(79.47831190218892,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark53(79.59280872903076,-0.5860466693545163,0 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark53(79.61374020148509,-0.6682996061295441,0 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark53(79.63664108097062,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark53(79.65810388454557,-0.08748906813301005,0 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark53(79.66101026319578,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark53(79.68362655193471,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark53(79.7231472624137,-1.1484972025305495,0 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark53(79.7373261715654,-0.8180315099347553,0 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark53(79.83917990897362,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark53(79.84610043919066,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark53(79.84751258330525,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark53(7.9934659498565,-0.1595858941193281,0 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark53(79.9387648003395,-1.3113439785802639,0 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark53(79.95263890817628,-0.3082689395276967,0 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark53(7.997918838657461E-16,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark53(80.01224689879245,-0.9192901379894778,0 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark53(80.01805896737045,-0.7446988105473853,0 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark53(8.004459357593014,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark53(8.005541152588407,-1.2716057568080288,0 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark53(80.06103560977863,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark53(80.09542081475809,-0.054625661199869224,0 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark53(80.15256014263957,-1.0613221189901756,0 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark53(80.2330340930063,-0.06173380207574772,0 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark53(80.2575595821242,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark53(80.29186613062635,-1.57079632679489,0 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark53(80.301594859061,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark53(80.31941852493384,-0.2567088217514595,0 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark53(80.33157762554796,-0.12574848328842414,0 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark53(8.038085378528677,-1.5707963267947989,0 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark53(80.58535904387173,-0.39457422418838206,0 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark53(80.60079805962928,-0.8027800594940739,0 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark53(80.6204239562995,-1.1580676598747557,0 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark53(80.67057586535296,-0.37354252757392037,0 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark53(80.68172701156149,-0.13887059688375558,0 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark53(80.72249504555245,-0.8165461010285044,0 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark53(80.86473430375366,-0.5652475046620259,0 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark53(8.086669564170887,-1.141985366125855,0 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark53(80.90249721088603,-0.8513975096762181,0 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark53(80.9196406152088,-1.1320973970669002,0 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark53(81.01349871037277,-0.07991390701973629,0 ) ;
  }

  @Test
  public void test2476() {
    coral.tests.JPFBenchmark.benchmark53(81.06372335711544,-0.9795248919012005,0 ) ;
  }

  @Test
  public void test2477() {
    coral.tests.JPFBenchmark.benchmark53(81.08907472067582,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2478() {
    coral.tests.JPFBenchmark.benchmark53(81.14992650173832,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2479() {
    coral.tests.JPFBenchmark.benchmark53(81.19160406216795,-1.176183477899741,0 ) ;
  }

  @Test
  public void test2480() {
    coral.tests.JPFBenchmark.benchmark53(81.22251211810415,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2481() {
    coral.tests.JPFBenchmark.benchmark53(81.22856352566735,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2482() {
    coral.tests.JPFBenchmark.benchmark53(81.2547897137622,-1.2606204021791596,0 ) ;
  }

  @Test
  public void test2483() {
    coral.tests.JPFBenchmark.benchmark53(81.25700236643183,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2484() {
    coral.tests.JPFBenchmark.benchmark53(8.12704372186461,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2485() {
    coral.tests.JPFBenchmark.benchmark53(8.13024417037779,-0.4075657620319797,0 ) ;
  }

  @Test
  public void test2486() {
    coral.tests.JPFBenchmark.benchmark53(81.35530480599235,-1.570796326794893,0 ) ;
  }

  @Test
  public void test2487() {
    coral.tests.JPFBenchmark.benchmark53(81.45437358770438,-1.5707963267948803,0 ) ;
  }

  @Test
  public void test2488() {
    coral.tests.JPFBenchmark.benchmark53(8.14770237233347,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2489() {
    coral.tests.JPFBenchmark.benchmark53(81.49581724518106,-1.0167933970540588,0 ) ;
  }

  @Test
  public void test2490() {
    coral.tests.JPFBenchmark.benchmark53(81.53392756076107,-1.5020531032303204,0 ) ;
  }

  @Test
  public void test2491() {
    coral.tests.JPFBenchmark.benchmark53(81.57037538063675,-1.2990147240331975,0 ) ;
  }

  @Test
  public void test2492() {
    coral.tests.JPFBenchmark.benchmark53(81.61895940421421,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test2493() {
    coral.tests.JPFBenchmark.benchmark53(81.62533416259708,-0.6496625132909344,0 ) ;
  }

  @Test
  public void test2494() {
    coral.tests.JPFBenchmark.benchmark53(81.62806311405679,-0.13271914116972586,0 ) ;
  }

  @Test
  public void test2495() {
    coral.tests.JPFBenchmark.benchmark53(8.165940269331642,-0.39523978433532747,0 ) ;
  }

  @Test
  public void test2496() {
    coral.tests.JPFBenchmark.benchmark53(81.75806533562215,-1.2257096767744846E-15,0 ) ;
  }

  @Test
  public void test2497() {
    coral.tests.JPFBenchmark.benchmark53(81.78195905567064,-0.12711993831385948,0 ) ;
  }

  @Test
  public void test2498() {
    coral.tests.JPFBenchmark.benchmark53(81.80963115451493,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2499() {
    coral.tests.JPFBenchmark.benchmark53(81.81643748861839,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2500() {
    coral.tests.JPFBenchmark.benchmark53(8.190843384829876,-1.519525203792395,0 ) ;
  }

  @Test
  public void test2501() {
    coral.tests.JPFBenchmark.benchmark53(81.96164398644959,-0.13794972524153692,0 ) ;
  }

  @Test
  public void test2502() {
    coral.tests.JPFBenchmark.benchmark53(81.96901119152668,-0.8177002218499219,0 ) ;
  }

  @Test
  public void test2503() {
    coral.tests.JPFBenchmark.benchmark53(8.204335044138679,-2.490766321297581E-16,0 ) ;
  }

  @Test
  public void test2504() {
    coral.tests.JPFBenchmark.benchmark53(82.06952721512718,-1.4506287187338747,0 ) ;
  }

  @Test
  public void test2505() {
    coral.tests.JPFBenchmark.benchmark53(82.07705545005507,-0.29808355082421456,0 ) ;
  }

  @Test
  public void test2506() {
    coral.tests.JPFBenchmark.benchmark53(82.09739454514309,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2507() {
    coral.tests.JPFBenchmark.benchmark53(82.13229759031927,-0.49925600739130305,0 ) ;
  }

  @Test
  public void test2508() {
    coral.tests.JPFBenchmark.benchmark53(82.15026912619584,-1.362592196926311,0 ) ;
  }

  @Test
  public void test2509() {
    coral.tests.JPFBenchmark.benchmark53(82.16738860004324,-0.29730398337526087,0 ) ;
  }

  @Test
  public void test2510() {
    coral.tests.JPFBenchmark.benchmark53(82.19972884796428,-1.4952636909695842,0 ) ;
  }

  @Test
  public void test2511() {
    coral.tests.JPFBenchmark.benchmark53(82.25729518779752,-0.7515305981831268,0 ) ;
  }

  @Test
  public void test2512() {
    coral.tests.JPFBenchmark.benchmark53(82.31603222154331,-1.099935874676398,0 ) ;
  }

  @Test
  public void test2513() {
    coral.tests.JPFBenchmark.benchmark53(8.245234902390663,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2514() {
    coral.tests.JPFBenchmark.benchmark53(82.53682553249313,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2515() {
    coral.tests.JPFBenchmark.benchmark53(82.58542410999212,-1.5707963267946994,0 ) ;
  }

  @Test
  public void test2516() {
    coral.tests.JPFBenchmark.benchmark53(82.58663265394631,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2517() {
    coral.tests.JPFBenchmark.benchmark53(82.59180845467077,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2518() {
    coral.tests.JPFBenchmark.benchmark53(-82.71558778336467,-1.4168225142955542,0.16587670236581475 ) ;
  }

  @Test
  public void test2519() {
    coral.tests.JPFBenchmark.benchmark53(82.71737204351248,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2520() {
    coral.tests.JPFBenchmark.benchmark53(82.734444359885,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2521() {
    coral.tests.JPFBenchmark.benchmark53(82.76070404466066,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2522() {
    coral.tests.JPFBenchmark.benchmark53(82.80207456145223,-0.4726936574189322,0 ) ;
  }

  @Test
  public void test2523() {
    coral.tests.JPFBenchmark.benchmark53(82.89966586980685,-0.7650502853461489,0 ) ;
  }

  @Test
  public void test2524() {
    coral.tests.JPFBenchmark.benchmark53(82.93211586209804,-0.7841687929835786,0 ) ;
  }

  @Test
  public void test2525() {
    coral.tests.JPFBenchmark.benchmark53(83.00205766964802,-0.00945142298392554,0 ) ;
  }

  @Test
  public void test2526() {
    coral.tests.JPFBenchmark.benchmark53(83.02060018123376,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2527() {
    coral.tests.JPFBenchmark.benchmark53(83.0548692544819,-0.9663832199687032,0 ) ;
  }

  @Test
  public void test2528() {
    coral.tests.JPFBenchmark.benchmark53(-83.15507918385153,-0.8390983100238145,-2355.2006097546264 ) ;
  }

  @Test
  public void test2529() {
    coral.tests.JPFBenchmark.benchmark53(83.20245788612465,-0.921242635349941,0 ) ;
  }

  @Test
  public void test2530() {
    coral.tests.JPFBenchmark.benchmark53(83.22672946622511,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2531() {
    coral.tests.JPFBenchmark.benchmark53(83.29499816206805,-0.5868732944918325,0 ) ;
  }

  @Test
  public void test2532() {
    coral.tests.JPFBenchmark.benchmark53(83.30858499755922,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2533() {
    coral.tests.JPFBenchmark.benchmark53(-83.33695534977188,-1.4869185399537086,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test2534() {
    coral.tests.JPFBenchmark.benchmark53(83.36564104358382,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2535() {
    coral.tests.JPFBenchmark.benchmark53(-83.3933673682956,-0.4079233018636072,2406.850257284527 ) ;
  }

  @Test
  public void test2536() {
    coral.tests.JPFBenchmark.benchmark53(83.40874216205029,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2537() {
    coral.tests.JPFBenchmark.benchmark53(83.4146221608315,-0.26774738205840287,0 ) ;
  }

  @Test
  public void test2538() {
    coral.tests.JPFBenchmark.benchmark53(83.59702262852372,-1.5707963267947318,0 ) ;
  }

  @Test
  public void test2539() {
    coral.tests.JPFBenchmark.benchmark53(83.62095372418838,-0.629711091962875,0 ) ;
  }

  @Test
  public void test2540() {
    coral.tests.JPFBenchmark.benchmark53(83.63648094953425,-0.418528652397514,0 ) ;
  }

  @Test
  public void test2541() {
    coral.tests.JPFBenchmark.benchmark53(83.7032916845962,-0.975076892024759,0 ) ;
  }

  @Test
  public void test2542() {
    coral.tests.JPFBenchmark.benchmark53(83.72281535308338,-0.39263394992164535,0 ) ;
  }

  @Test
  public void test2543() {
    coral.tests.JPFBenchmark.benchmark53(8.374576273421198,-1.3828422309143302,0 ) ;
  }

  @Test
  public void test2544() {
    coral.tests.JPFBenchmark.benchmark53(8.376075589667337,-0.9907262321707626,0 ) ;
  }

  @Test
  public void test2545() {
    coral.tests.JPFBenchmark.benchmark53(83.7957754736477,-0.9787268019981674,0 ) ;
  }

  @Test
  public void test2546() {
    coral.tests.JPFBenchmark.benchmark53(-8.384305676313925,-0.9862279493886252,-0.9737329806079384 ) ;
  }

  @Test
  public void test2547() {
    coral.tests.JPFBenchmark.benchmark53(83.87968249744021,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2548() {
    coral.tests.JPFBenchmark.benchmark53(84.0205588235525,-1.5707963267948397,0 ) ;
  }

  @Test
  public void test2549() {
    coral.tests.JPFBenchmark.benchmark53(84.0444501479985,-0.8144822321364047,0 ) ;
  }

  @Test
  public void test2550() {
    coral.tests.JPFBenchmark.benchmark53(84.04924014586985,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2551() {
    coral.tests.JPFBenchmark.benchmark53(84.05080837265035,-0.5644745945306617,0 ) ;
  }

  @Test
  public void test2552() {
    coral.tests.JPFBenchmark.benchmark53(84.05780070848462,-0.4382603309006696,0 ) ;
  }

  @Test
  public void test2553() {
    coral.tests.JPFBenchmark.benchmark53(84.0963949838993,-1.4064733730312797,0 ) ;
  }

  @Test
  public void test2554() {
    coral.tests.JPFBenchmark.benchmark53(84.11730414008586,-0.22999311043855303,0 ) ;
  }

  @Test
  public void test2555() {
    coral.tests.JPFBenchmark.benchmark53(84.1581005829222,-1.5707963267945964,0 ) ;
  }

  @Test
  public void test2556() {
    coral.tests.JPFBenchmark.benchmark53(84.23464046179072,-0.6903865988821456,0 ) ;
  }

  @Test
  public void test2557() {
    coral.tests.JPFBenchmark.benchmark53(84.2664556391572,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2558() {
    coral.tests.JPFBenchmark.benchmark53(84.30110312430783,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test2559() {
    coral.tests.JPFBenchmark.benchmark53(84.30997451889124,-0.5754193226180382,0 ) ;
  }

  @Test
  public void test2560() {
    coral.tests.JPFBenchmark.benchmark53(8.431259823971164,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2561() {
    coral.tests.JPFBenchmark.benchmark53(84.42435202970142,-1.430636725705865,0 ) ;
  }

  @Test
  public void test2562() {
    coral.tests.JPFBenchmark.benchmark53(84.48909741134258,-1.5174869500294936,0 ) ;
  }

  @Test
  public void test2563() {
    coral.tests.JPFBenchmark.benchmark53(84.54869260996719,-0.8547870954050438,0 ) ;
  }

  @Test
  public void test2564() {
    coral.tests.JPFBenchmark.benchmark53(84.55698748748102,-0.08353560979565988,0 ) ;
  }

  @Test
  public void test2565() {
    coral.tests.JPFBenchmark.benchmark53(84.5795316330425,-0.06906462767737764,0 ) ;
  }

  @Test
  public void test2566() {
    coral.tests.JPFBenchmark.benchmark53(-84.6348959292377,-1.229481202312737,-31.905286709157693 ) ;
  }

  @Test
  public void test2567() {
    coral.tests.JPFBenchmark.benchmark53(84.64568683305492,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2568() {
    coral.tests.JPFBenchmark.benchmark53(84.68524149402543,-0.9253292417623697,0 ) ;
  }

  @Test
  public void test2569() {
    coral.tests.JPFBenchmark.benchmark53(84.79017112407541,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2570() {
    coral.tests.JPFBenchmark.benchmark53(84.79464442729619,-1.5707963267948912,0 ) ;
  }

  @Test
  public void test2571() {
    coral.tests.JPFBenchmark.benchmark53(84.93746179391871,-0.05533940648440705,0 ) ;
  }

  @Test
  public void test2572() {
    coral.tests.JPFBenchmark.benchmark53(-84.9458358282476,-1.445072083382879,0.03528033847535898 ) ;
  }

  @Test
  public void test2573() {
    coral.tests.JPFBenchmark.benchmark53(8.495775755342542,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test2574() {
    coral.tests.JPFBenchmark.benchmark53(84.9798455183653,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2575() {
    coral.tests.JPFBenchmark.benchmark53(8.499076471793716,-3.826839816935486E-7,0 ) ;
  }

  @Test
  public void test2576() {
    coral.tests.JPFBenchmark.benchmark53(85.00413792251945,-0.4678806330224553,0 ) ;
  }

  @Test
  public void test2577() {
    coral.tests.JPFBenchmark.benchmark53(85.00838962515729,-0.45038235134518345,0 ) ;
  }

  @Test
  public void test2578() {
    coral.tests.JPFBenchmark.benchmark53(85.02026814637364,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2579() {
    coral.tests.JPFBenchmark.benchmark53(85.0326875606632,-4.170561285472614E-4,0 ) ;
  }

  @Test
  public void test2580() {
    coral.tests.JPFBenchmark.benchmark53(85.03936129325544,-0.4095763304277993,0 ) ;
  }

  @Test
  public void test2581() {
    coral.tests.JPFBenchmark.benchmark53(85.05550655040207,-1.4349989284754288,0 ) ;
  }

  @Test
  public void test2582() {
    coral.tests.JPFBenchmark.benchmark53(85.06421588356879,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2583() {
    coral.tests.JPFBenchmark.benchmark53(85.0722193473232,-0.45726245423969303,0 ) ;
  }

  @Test
  public void test2584() {
    coral.tests.JPFBenchmark.benchmark53(85.10891477511788,-0.7888342726348583,0 ) ;
  }

  @Test
  public void test2585() {
    coral.tests.JPFBenchmark.benchmark53(85.17349411796567,-0.22377365166826202,0 ) ;
  }

  @Test
  public void test2586() {
    coral.tests.JPFBenchmark.benchmark53(85.18746891838879,-0.18158367507685602,0 ) ;
  }

  @Test
  public void test2587() {
    coral.tests.JPFBenchmark.benchmark53(8.518878819192555,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2588() {
    coral.tests.JPFBenchmark.benchmark53(85.23228875091385,-0.7960223885513358,0 ) ;
  }

  @Test
  public void test2589() {
    coral.tests.JPFBenchmark.benchmark53(-85.24072932866326,-0.12360848734467286,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test2590() {
    coral.tests.JPFBenchmark.benchmark53(8.534450498464423,-0.12085676810635171,0 ) ;
  }

  @Test
  public void test2591() {
    coral.tests.JPFBenchmark.benchmark53(85.3773089945004,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2592() {
    coral.tests.JPFBenchmark.benchmark53(85.38979118929905,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2593() {
    coral.tests.JPFBenchmark.benchmark53(85.39238653249039,-1.1549176644638626,0 ) ;
  }

  @Test
  public void test2594() {
    coral.tests.JPFBenchmark.benchmark53(85.43729504515136,-1.050522955005382,0 ) ;
  }

  @Test
  public void test2595() {
    coral.tests.JPFBenchmark.benchmark53(85.45678146380963,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2596() {
    coral.tests.JPFBenchmark.benchmark53(85.4973690185171,-0.5170887980216605,0 ) ;
  }

  @Test
  public void test2597() {
    coral.tests.JPFBenchmark.benchmark53(85.54546778433456,-1.3604593208399756,0 ) ;
  }

  @Test
  public void test2598() {
    coral.tests.JPFBenchmark.benchmark53(85.58457235338452,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2599() {
    coral.tests.JPFBenchmark.benchmark53(85.65656790551489,-0.22385970781902254,0 ) ;
  }

  @Test
  public void test2600() {
    coral.tests.JPFBenchmark.benchmark53(8.565683627203128,-1.1326970250163448,0 ) ;
  }

  @Test
  public void test2601() {
    coral.tests.JPFBenchmark.benchmark53(85.67571807074562,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2602() {
    coral.tests.JPFBenchmark.benchmark53(85.67815152567516,-0.14698301836985372,0 ) ;
  }

  @Test
  public void test2603() {
    coral.tests.JPFBenchmark.benchmark53(85.72521922961963,-1.2826142497976312,0 ) ;
  }

  @Test
  public void test2604() {
    coral.tests.JPFBenchmark.benchmark53(85.7654237868307,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2605() {
    coral.tests.JPFBenchmark.benchmark53(85.77508876772826,-5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test2606() {
    coral.tests.JPFBenchmark.benchmark53(85.786637457538,-0.5182857099664986,0 ) ;
  }

  @Test
  public void test2607() {
    coral.tests.JPFBenchmark.benchmark53(85.81743054965006,-0.1670380693694824,0 ) ;
  }

  @Test
  public void test2608() {
    coral.tests.JPFBenchmark.benchmark53(85.87753511304419,-0.25307157777372424,0 ) ;
  }

  @Test
  public void test2609() {
    coral.tests.JPFBenchmark.benchmark53(85.94152085189967,-0.3501102685041104,0 ) ;
  }

  @Test
  public void test2610() {
    coral.tests.JPFBenchmark.benchmark53(86.03775648490549,-0.366984736247836,0 ) ;
  }

  @Test
  public void test2611() {
    coral.tests.JPFBenchmark.benchmark53(86.08718380005712,-1.088410024941366,0 ) ;
  }

  @Test
  public void test2612() {
    coral.tests.JPFBenchmark.benchmark53(86.16520363457695,-24.73401817811471,33.90272592556093 ) ;
  }

  @Test
  public void test2613() {
    coral.tests.JPFBenchmark.benchmark53(86.18751040743732,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2614() {
    coral.tests.JPFBenchmark.benchmark53(86.19305171665093,-1.1778030773562658,0 ) ;
  }

  @Test
  public void test2615() {
    coral.tests.JPFBenchmark.benchmark53(86.25384586247019,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2616() {
    coral.tests.JPFBenchmark.benchmark53(-86.28664005832539,-19.636396798557115,0 ) ;
  }

  @Test
  public void test2617() {
    coral.tests.JPFBenchmark.benchmark53(86.29647717137806,-1.2454323188215985,0 ) ;
  }

  @Test
  public void test2618() {
    coral.tests.JPFBenchmark.benchmark53(86.30896645983616,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2619() {
    coral.tests.JPFBenchmark.benchmark53(86.42654724863932,-0.15820288166904106,0 ) ;
  }

  @Test
  public void test2620() {
    coral.tests.JPFBenchmark.benchmark53(86.52567922027856,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test2621() {
    coral.tests.JPFBenchmark.benchmark53(86.56725200420036,-1.2962813443982224,0 ) ;
  }

  @Test
  public void test2622() {
    coral.tests.JPFBenchmark.benchmark53(-86.61251069263722,-1.57079632679488,1.0 ) ;
  }

  @Test
  public void test2623() {
    coral.tests.JPFBenchmark.benchmark53(86.61729506915142,-0.38785433504531275,0 ) ;
  }

  @Test
  public void test2624() {
    coral.tests.JPFBenchmark.benchmark53(86.63760532978068,-0.4770152097580258,0 ) ;
  }

  @Test
  public void test2625() {
    coral.tests.JPFBenchmark.benchmark53(86.66806316169317,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2626() {
    coral.tests.JPFBenchmark.benchmark53(86.68785061380021,-0.33275332599506413,0 ) ;
  }

  @Test
  public void test2627() {
    coral.tests.JPFBenchmark.benchmark53(86.73422832631829,-1.5707963267948912,0 ) ;
  }

  @Test
  public void test2628() {
    coral.tests.JPFBenchmark.benchmark53(8.673617379884035E-19,-0.8231561987279382,0 ) ;
  }

  @Test
  public void test2629() {
    coral.tests.JPFBenchmark.benchmark53(86.77878699826955,-1.485682559388416,0 ) ;
  }

  @Test
  public void test2630() {
    coral.tests.JPFBenchmark.benchmark53(86.79071642284103,-1.2562142010996826,0 ) ;
  }

  @Test
  public void test2631() {
    coral.tests.JPFBenchmark.benchmark53(86.80821610769385,-0.8207570119162022,0 ) ;
  }

  @Test
  public void test2632() {
    coral.tests.JPFBenchmark.benchmark53(8.684194368925404,-0.7889551051086421,0 ) ;
  }

  @Test
  public void test2633() {
    coral.tests.JPFBenchmark.benchmark53(86.8465336652134,-0.41675021253420885,0 ) ;
  }

  @Test
  public void test2634() {
    coral.tests.JPFBenchmark.benchmark53(86.87344582312616,-1.5707963267948903,0 ) ;
  }

  @Test
  public void test2635() {
    coral.tests.JPFBenchmark.benchmark53(86.88335647203661,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2636() {
    coral.tests.JPFBenchmark.benchmark53(87.01264356933808,-1.570796326794893,0 ) ;
  }

  @Test
  public void test2637() {
    coral.tests.JPFBenchmark.benchmark53(8.70279373896166,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2638() {
    coral.tests.JPFBenchmark.benchmark53(87.02812243391949,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2639() {
    coral.tests.JPFBenchmark.benchmark53(87.08119575472287,-1.4929897395698533,0 ) ;
  }

  @Test
  public void test2640() {
    coral.tests.JPFBenchmark.benchmark53(87.09607870621704,-0.7588832514041606,0 ) ;
  }

  @Test
  public void test2641() {
    coral.tests.JPFBenchmark.benchmark53(87.10409580564146,-1.5324527944097561,0 ) ;
  }

  @Test
  public void test2642() {
    coral.tests.JPFBenchmark.benchmark53(87.1249851298972,-1.1414529306589554,0 ) ;
  }

  @Test
  public void test2643() {
    coral.tests.JPFBenchmark.benchmark53(87.15228246261358,-0.8516975409953673,0 ) ;
  }

  @Test
  public void test2644() {
    coral.tests.JPFBenchmark.benchmark53(87.20702073062466,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2645() {
    coral.tests.JPFBenchmark.benchmark53(87.21156518746,-0.7331953528993949,0 ) ;
  }

  @Test
  public void test2646() {
    coral.tests.JPFBenchmark.benchmark53(-87.27479259034081,-1.5328349050339303,93.93030940328825 ) ;
  }

  @Test
  public void test2647() {
    coral.tests.JPFBenchmark.benchmark53(8.727971827184746,-1.570796326794742,0 ) ;
  }

  @Test
  public void test2648() {
    coral.tests.JPFBenchmark.benchmark53(8.737275118582176,-1.570796326794894,0 ) ;
  }

  @Test
  public void test2649() {
    coral.tests.JPFBenchmark.benchmark53(87.37276103019664,-0.05006973192641406,0 ) ;
  }

  @Test
  public void test2650() {
    coral.tests.JPFBenchmark.benchmark53(87.37753486895605,-0.5591707433039588,0 ) ;
  }

  @Test
  public void test2651() {
    coral.tests.JPFBenchmark.benchmark53(87.4239909485491,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2652() {
    coral.tests.JPFBenchmark.benchmark53(87.56689488459244,-0.6090612755280489,0 ) ;
  }

  @Test
  public void test2653() {
    coral.tests.JPFBenchmark.benchmark53(87.57831498413864,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2654() {
    coral.tests.JPFBenchmark.benchmark53(8.760602193834039,-1.570796326759943,0 ) ;
  }

  @Test
  public void test2655() {
    coral.tests.JPFBenchmark.benchmark53(87.67262320059682,-0.524956264679229,0 ) ;
  }

  @Test
  public void test2656() {
    coral.tests.JPFBenchmark.benchmark53(87.70852530532375,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2657() {
    coral.tests.JPFBenchmark.benchmark53(87.87549286885402,-0.5731053286864238,0 ) ;
  }

  @Test
  public void test2658() {
    coral.tests.JPFBenchmark.benchmark53(87.99562897166636,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test2659() {
    coral.tests.JPFBenchmark.benchmark53(88.01312133344854,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2660() {
    coral.tests.JPFBenchmark.benchmark53(88.03122069884296,-0.9375387555128143,0 ) ;
  }

  @Test
  public void test2661() {
    coral.tests.JPFBenchmark.benchmark53(88.07447831695526,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2662() {
    coral.tests.JPFBenchmark.benchmark53(88.14069217931805,-1.2536104941341817,0 ) ;
  }

  @Test
  public void test2663() {
    coral.tests.JPFBenchmark.benchmark53(8.814577178711176,-0.5810122366346053,0 ) ;
  }

  @Test
  public void test2664() {
    coral.tests.JPFBenchmark.benchmark53(88.19854457183055,-1.0365754265913596,0 ) ;
  }

  @Test
  public void test2665() {
    coral.tests.JPFBenchmark.benchmark53(88.26022004762297,-0.5513899382464731,0 ) ;
  }

  @Test
  public void test2666() {
    coral.tests.JPFBenchmark.benchmark53(88.27700742280423,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2667() {
    coral.tests.JPFBenchmark.benchmark53(88.29781331845237,-1.5707963267946212,0 ) ;
  }

  @Test
  public void test2668() {
    coral.tests.JPFBenchmark.benchmark53(8.832020678692897,-1.0075949089673706,0 ) ;
  }

  @Test
  public void test2669() {
    coral.tests.JPFBenchmark.benchmark53(88.4790606475124,-1.548687272820519,0 ) ;
  }

  @Test
  public void test2670() {
    coral.tests.JPFBenchmark.benchmark53(88.5399057123916,-1.4087956700675353,0 ) ;
  }

  @Test
  public void test2671() {
    coral.tests.JPFBenchmark.benchmark53(88.55356165715017,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2672() {
    coral.tests.JPFBenchmark.benchmark53(88.62365182520176,-9.700264807916642E-9,0 ) ;
  }

  @Test
  public void test2673() {
    coral.tests.JPFBenchmark.benchmark53(88.62531736526546,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2674() {
    coral.tests.JPFBenchmark.benchmark53(88.68380908432616,-1.5661196254756002,0 ) ;
  }

  @Test
  public void test2675() {
    coral.tests.JPFBenchmark.benchmark53(88.69157110801365,-1.139487023157133,0 ) ;
  }

  @Test
  public void test2676() {
    coral.tests.JPFBenchmark.benchmark53(88.76193375086652,-0.9245920610638185,0 ) ;
  }

  @Test
  public void test2677() {
    coral.tests.JPFBenchmark.benchmark53(88.7986393062065,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2678() {
    coral.tests.JPFBenchmark.benchmark53(88.80467116384531,-1.2942306192658801,0 ) ;
  }

  @Test
  public void test2679() {
    coral.tests.JPFBenchmark.benchmark53(8.881784197001252E-16,-0.07230341220651154,0 ) ;
  }

  @Test
  public void test2680() {
    coral.tests.JPFBenchmark.benchmark53(8.881784197001252E-16,-1.3663248193366266,0 ) ;
  }

  @Test
  public void test2681() {
    coral.tests.JPFBenchmark.benchmark53(88.88870039447434,-1.2829404269602174,0 ) ;
  }

  @Test
  public void test2682() {
    coral.tests.JPFBenchmark.benchmark53(88.90086376535828,-1.5707963267948952,0 ) ;
  }

  @Test
  public void test2683() {
    coral.tests.JPFBenchmark.benchmark53(88.93525753326797,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2684() {
    coral.tests.JPFBenchmark.benchmark53(88.94281391102322,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2685() {
    coral.tests.JPFBenchmark.benchmark53(88.99010692073969,-0.6238500134361828,0 ) ;
  }

  @Test
  public void test2686() {
    coral.tests.JPFBenchmark.benchmark53(89.04888153652243,-1.516435370462112,0 ) ;
  }

  @Test
  public void test2687() {
    coral.tests.JPFBenchmark.benchmark53(89.13667546673145,-0.009891385900843375,0 ) ;
  }

  @Test
  public void test2688() {
    coral.tests.JPFBenchmark.benchmark53(89.2304552520617,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2689() {
    coral.tests.JPFBenchmark.benchmark53(89.2625626477587,-0.8410006650390542,0 ) ;
  }

  @Test
  public void test2690() {
    coral.tests.JPFBenchmark.benchmark53(89.2737658553467,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2691() {
    coral.tests.JPFBenchmark.benchmark53(-89.27726582709776,-0.6140625802465134,-0.2125358026366817 ) ;
  }

  @Test
  public void test2692() {
    coral.tests.JPFBenchmark.benchmark53(-89.29110214304514,-1.5707963267948948,45.204657157478124 ) ;
  }

  @Test
  public void test2693() {
    coral.tests.JPFBenchmark.benchmark53(89.3526130396419,-6.854620972054687E-6,0 ) ;
  }

  @Test
  public void test2694() {
    coral.tests.JPFBenchmark.benchmark53(89.3687977381974,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2695() {
    coral.tests.JPFBenchmark.benchmark53(89.38074330263578,-0.09737772744405182,0 ) ;
  }

  @Test
  public void test2696() {
    coral.tests.JPFBenchmark.benchmark53(89.38716476559205,-0.9416813488026375,0 ) ;
  }

  @Test
  public void test2697() {
    coral.tests.JPFBenchmark.benchmark53(89.43799476059084,-1.331756470423386,0 ) ;
  }

  @Test
  public void test2698() {
    coral.tests.JPFBenchmark.benchmark53(-89.47255361064927,-0.3881139235008657,2305.3088393203025 ) ;
  }

  @Test
  public void test2699() {
    coral.tests.JPFBenchmark.benchmark53(-89.49327470743887,-1.2399615698026025,0.7834169376374689 ) ;
  }

  @Test
  public void test2700() {
    coral.tests.JPFBenchmark.benchmark53(89.54234732352566,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2701() {
    coral.tests.JPFBenchmark.benchmark53(-89.65240199903998,-1.5707963267948957,-1.0 ) ;
  }

  @Test
  public void test2702() {
    coral.tests.JPFBenchmark.benchmark53(89.66145995820608,-0.27204950823895047,0 ) ;
  }

  @Test
  public void test2703() {
    coral.tests.JPFBenchmark.benchmark53(89.67084928025321,-1.1932183796339286,0 ) ;
  }

  @Test
  public void test2704() {
    coral.tests.JPFBenchmark.benchmark53(89.68628886510871,-1.4985619735950877,0 ) ;
  }

  @Test
  public void test2705() {
    coral.tests.JPFBenchmark.benchmark53(89.75364887119179,-0.9427297986589694,0 ) ;
  }

  @Test
  public void test2706() {
    coral.tests.JPFBenchmark.benchmark53(89.86719881090356,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2707() {
    coral.tests.JPFBenchmark.benchmark53(89.88295579385118,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2708() {
    coral.tests.JPFBenchmark.benchmark53(8.996047679148328,-0.24300872770243998,0 ) ;
  }

  @Test
  public void test2709() {
    coral.tests.JPFBenchmark.benchmark53(89.97788633914452,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2710() {
    coral.tests.JPFBenchmark.benchmark53(89.98771478048269,-0.2241412372854228,0 ) ;
  }

  @Test
  public void test2711() {
    coral.tests.JPFBenchmark.benchmark53(89.99907870723999,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2712() {
    coral.tests.JPFBenchmark.benchmark53(90.04857901009154,-0.5866212755155598,0 ) ;
  }

  @Test
  public void test2713() {
    coral.tests.JPFBenchmark.benchmark53(90.07847884188541,-0.6840522318541041,0 ) ;
  }

  @Test
  public void test2714() {
    coral.tests.JPFBenchmark.benchmark53(90.08299366469336,-1.1725841979024563,0 ) ;
  }

  @Test
  public void test2715() {
    coral.tests.JPFBenchmark.benchmark53(90.17590307783348,-1.234542025415644,0 ) ;
  }

  @Test
  public void test2716() {
    coral.tests.JPFBenchmark.benchmark53(90.18566790133927,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2717() {
    coral.tests.JPFBenchmark.benchmark53(-90.23466272259401,-0.39627784325100635,0.9523136882258855 ) ;
  }

  @Test
  public void test2718() {
    coral.tests.JPFBenchmark.benchmark53(90.23661288863164,-1.0422722415138117,0 ) ;
  }

  @Test
  public void test2719() {
    coral.tests.JPFBenchmark.benchmark53(9.024737244128403,-0.08151517799948005,0 ) ;
  }

  @Test
  public void test2720() {
    coral.tests.JPFBenchmark.benchmark53(90.30856989391523,-0.8656787886666921,0 ) ;
  }

  @Test
  public void test2721() {
    coral.tests.JPFBenchmark.benchmark53(90.32772775276281,-0.30735256578652187,0 ) ;
  }

  @Test
  public void test2722() {
    coral.tests.JPFBenchmark.benchmark53(90.38965536492017,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2723() {
    coral.tests.JPFBenchmark.benchmark53(90.39877665078993,-1.4374976752776045,0 ) ;
  }

  @Test
  public void test2724() {
    coral.tests.JPFBenchmark.benchmark53(90.42641421061026,-0.803774778057341,0 ) ;
  }

  @Test
  public void test2725() {
    coral.tests.JPFBenchmark.benchmark53(90.50028050228184,-1.570796326794893,0 ) ;
  }

  @Test
  public void test2726() {
    coral.tests.JPFBenchmark.benchmark53(90.51663437163458,-1.1969379271452572,0 ) ;
  }

  @Test
  public void test2727() {
    coral.tests.JPFBenchmark.benchmark53(90.54622297255165,-1.5707963267948877,0 ) ;
  }

  @Test
  public void test2728() {
    coral.tests.JPFBenchmark.benchmark53(9.062179939491372,-1.5972532217416215E-8,0 ) ;
  }

  @Test
  public void test2729() {
    coral.tests.JPFBenchmark.benchmark53(9.06422640283338,-1.5501558008138798,0 ) ;
  }

  @Test
  public void test2730() {
    coral.tests.JPFBenchmark.benchmark53(90.68343149113858,-1.2595463855182527,0 ) ;
  }

  @Test
  public void test2731() {
    coral.tests.JPFBenchmark.benchmark53(90.74135056589748,-0.08693716596679976,0 ) ;
  }

  @Test
  public void test2732() {
    coral.tests.JPFBenchmark.benchmark53(90.75522476933384,-0.6744600796998563,0 ) ;
  }

  @Test
  public void test2733() {
    coral.tests.JPFBenchmark.benchmark53(90.88300393980839,-0.8840911885569289,0 ) ;
  }

  @Test
  public void test2734() {
    coral.tests.JPFBenchmark.benchmark53(90.88524451838668,-1.0940953103585542,0 ) ;
  }

  @Test
  public void test2735() {
    coral.tests.JPFBenchmark.benchmark53(90.91025923905457,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2736() {
    coral.tests.JPFBenchmark.benchmark53(90.92048211619911,-0.25769731143447605,0 ) ;
  }

  @Test
  public void test2737() {
    coral.tests.JPFBenchmark.benchmark53(9.093201998678548,-0.015270868501884749,0 ) ;
  }

  @Test
  public void test2738() {
    coral.tests.JPFBenchmark.benchmark53(90.94877298316388,-1.2333632725263897,0 ) ;
  }

  @Test
  public void test2739() {
    coral.tests.JPFBenchmark.benchmark53(90.95016423758611,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2740() {
    coral.tests.JPFBenchmark.benchmark53(90.95736491780738,-0.38788476204433664,0 ) ;
  }

  @Test
  public void test2741() {
    coral.tests.JPFBenchmark.benchmark53(90.9613216672362,-1.4414485697022723,0 ) ;
  }

  @Test
  public void test2742() {
    coral.tests.JPFBenchmark.benchmark53(90.97965753221092,-1.468125429185942,0 ) ;
  }

  @Test
  public void test2743() {
    coral.tests.JPFBenchmark.benchmark53(91.05941096002564,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2744() {
    coral.tests.JPFBenchmark.benchmark53(91.06015107156023,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2745() {
    coral.tests.JPFBenchmark.benchmark53(91.07302208829674,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2746() {
    coral.tests.JPFBenchmark.benchmark53(-91.07304170727828,30.711406825655928,-80.37716846806184 ) ;
  }

  @Test
  public void test2747() {
    coral.tests.JPFBenchmark.benchmark53(91.11071528904264,-1.0303483090306997,0 ) ;
  }

  @Test
  public void test2748() {
    coral.tests.JPFBenchmark.benchmark53(9.120238991286829E-16,-0.7741212847512173,-0.49220165703465335 ) ;
  }

  @Test
  public void test2749() {
    coral.tests.JPFBenchmark.benchmark53(91.21017059406628,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2750() {
    coral.tests.JPFBenchmark.benchmark53(91.21427326870565,-1.2725271402937988,0 ) ;
  }

  @Test
  public void test2751() {
    coral.tests.JPFBenchmark.benchmark53(91.29968215039281,-0.14839340791091296,0 ) ;
  }

  @Test
  public void test2752() {
    coral.tests.JPFBenchmark.benchmark53(91.30784985769685,-1.0747730578135162,0 ) ;
  }

  @Test
  public void test2753() {
    coral.tests.JPFBenchmark.benchmark53(91.31067182021107,-0.005645254429410329,0 ) ;
  }

  @Test
  public void test2754() {
    coral.tests.JPFBenchmark.benchmark53(91.31595347495536,-1.1274532624110676,0 ) ;
  }

  @Test
  public void test2755() {
    coral.tests.JPFBenchmark.benchmark53(91.35213010151989,-1.5707963267947171,0 ) ;
  }

  @Test
  public void test2756() {
    coral.tests.JPFBenchmark.benchmark53(91.4325949029834,-0.7969957440382043,0 ) ;
  }

  @Test
  public void test2757() {
    coral.tests.JPFBenchmark.benchmark53(91.45767576577353,-0.0894274163641029,0 ) ;
  }

  @Test
  public void test2758() {
    coral.tests.JPFBenchmark.benchmark53(91.48503495586218,-0.995989402319239,0 ) ;
  }

  @Test
  public void test2759() {
    coral.tests.JPFBenchmark.benchmark53(91.49400003333156,-0.6366604490816652,0 ) ;
  }

  @Test
  public void test2760() {
    coral.tests.JPFBenchmark.benchmark53(91.5009719453425,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test2761() {
    coral.tests.JPFBenchmark.benchmark53(91.52360236240384,-1.366219426065105,0 ) ;
  }

  @Test
  public void test2762() {
    coral.tests.JPFBenchmark.benchmark53(91.57112065651646,-1.390118814156608,0 ) ;
  }

  @Test
  public void test2763() {
    coral.tests.JPFBenchmark.benchmark53(91.58125742889096,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2764() {
    coral.tests.JPFBenchmark.benchmark53(91.68730036536115,-0.060741153838847595,0 ) ;
  }

  @Test
  public void test2765() {
    coral.tests.JPFBenchmark.benchmark53(91.76344962812601,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2766() {
    coral.tests.JPFBenchmark.benchmark53(91.92431692618362,-0.14939297111624228,0 ) ;
  }

  @Test
  public void test2767() {
    coral.tests.JPFBenchmark.benchmark53(91.97887343013252,-0.9120949586727072,0 ) ;
  }

  @Test
  public void test2768() {
    coral.tests.JPFBenchmark.benchmark53(9.212039156121788,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2769() {
    coral.tests.JPFBenchmark.benchmark53(92.43215132293354,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2770() {
    coral.tests.JPFBenchmark.benchmark53(92.43634297070966,-0.06150898078277689,0 ) ;
  }

  @Test
  public void test2771() {
    coral.tests.JPFBenchmark.benchmark53(92.50005240023938,-0.39480118143513876,0 ) ;
  }

  @Test
  public void test2772() {
    coral.tests.JPFBenchmark.benchmark53(9.25059511051048,-1.2293097004124616,0 ) ;
  }

  @Test
  public void test2773() {
    coral.tests.JPFBenchmark.benchmark53(92.62136519491736,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2774() {
    coral.tests.JPFBenchmark.benchmark53(92.70688376938867,-0.9269244181366059,0 ) ;
  }

  @Test
  public void test2775() {
    coral.tests.JPFBenchmark.benchmark53(92.74972567520348,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2776() {
    coral.tests.JPFBenchmark.benchmark53(92.7560008075945,-0.6589680717231872,0 ) ;
  }

  @Test
  public void test2777() {
    coral.tests.JPFBenchmark.benchmark53(-92.81730158778306,-0.6638720988751238,0.9290475231434142 ) ;
  }

  @Test
  public void test2778() {
    coral.tests.JPFBenchmark.benchmark53(92.82039563055369,-0.13990066328365214,0 ) ;
  }

  @Test
  public void test2779() {
    coral.tests.JPFBenchmark.benchmark53(92.94696959923466,-1.5537368284695456E-18,0 ) ;
  }

  @Test
  public void test2780() {
    coral.tests.JPFBenchmark.benchmark53(9.298389236498423,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2781() {
    coral.tests.JPFBenchmark.benchmark53(92.99082542366041,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2782() {
    coral.tests.JPFBenchmark.benchmark53(93.01571735251972,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2783() {
    coral.tests.JPFBenchmark.benchmark53(-93.02613324076843,-0.1751194189935369,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test2784() {
    coral.tests.JPFBenchmark.benchmark53(93.03539825406614,-0.9059044263136542,0 ) ;
  }

  @Test
  public void test2785() {
    coral.tests.JPFBenchmark.benchmark53(93.04326576017495,-0.9862288558860994,0 ) ;
  }

  @Test
  public void test2786() {
    coral.tests.JPFBenchmark.benchmark53(93.07459921219194,-0.23426288301338616,0 ) ;
  }

  @Test
  public void test2787() {
    coral.tests.JPFBenchmark.benchmark53(93.09136252390147,-1.3770865115391417,0 ) ;
  }

  @Test
  public void test2788() {
    coral.tests.JPFBenchmark.benchmark53(93.09619093959554,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2789() {
    coral.tests.JPFBenchmark.benchmark53(93.13215479092446,-1.069906752035994,0 ) ;
  }

  @Test
  public void test2790() {
    coral.tests.JPFBenchmark.benchmark53(93.16504950551223,-0.022035182804600595,0 ) ;
  }

  @Test
  public void test2791() {
    coral.tests.JPFBenchmark.benchmark53(93.2193046934097,-0.0049159599157571066,0 ) ;
  }

  @Test
  public void test2792() {
    coral.tests.JPFBenchmark.benchmark53(93.24056475934567,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test2793() {
    coral.tests.JPFBenchmark.benchmark53(-93.24424731108581,-1.5187609363020496,1.0 ) ;
  }

  @Test
  public void test2794() {
    coral.tests.JPFBenchmark.benchmark53(93.2925726124582,-0.458245406343579,0 ) ;
  }

  @Test
  public void test2795() {
    coral.tests.JPFBenchmark.benchmark53(93.29802396298388,-0.12940993946805723,0 ) ;
  }

  @Test
  public void test2796() {
    coral.tests.JPFBenchmark.benchmark53(93.35515163432089,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2797() {
    coral.tests.JPFBenchmark.benchmark53(93.3615787581141,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2798() {
    coral.tests.JPFBenchmark.benchmark53(93.38565700074511,-1.3042187533131668,0 ) ;
  }

  @Test
  public void test2799() {
    coral.tests.JPFBenchmark.benchmark53(93.4007688140516,-1.3449217824923552,0 ) ;
  }

  @Test
  public void test2800() {
    coral.tests.JPFBenchmark.benchmark53(93.43440158332496,-1.320607424837478,0 ) ;
  }

  @Test
  public void test2801() {
    coral.tests.JPFBenchmark.benchmark53(93.50348774865802,-1.5707963267947314,0 ) ;
  }

  @Test
  public void test2802() {
    coral.tests.JPFBenchmark.benchmark53(93.52732175507002,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2803() {
    coral.tests.JPFBenchmark.benchmark53(93.63538608451313,-0.13020617767000786,0 ) ;
  }

  @Test
  public void test2804() {
    coral.tests.JPFBenchmark.benchmark53(93.72058030175822,-0.6207187016655065,0 ) ;
  }

  @Test
  public void test2805() {
    coral.tests.JPFBenchmark.benchmark53(9.373304728218628,-0.3873304240689747,0 ) ;
  }

  @Test
  public void test2806() {
    coral.tests.JPFBenchmark.benchmark53(93.76821769758226,-0.56275220042126,0 ) ;
  }

  @Test
  public void test2807() {
    coral.tests.JPFBenchmark.benchmark53(93.8629346464489,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2808() {
    coral.tests.JPFBenchmark.benchmark53(93.90409437865279,-0.03871457754588903,0 ) ;
  }

  @Test
  public void test2809() {
    coral.tests.JPFBenchmark.benchmark53(93.91140088714184,-0.47403291119823976,0 ) ;
  }

  @Test
  public void test2810() {
    coral.tests.JPFBenchmark.benchmark53(93.93191824066065,-0.25838150362157997,0 ) ;
  }

  @Test
  public void test2811() {
    coral.tests.JPFBenchmark.benchmark53(93.94401413212805,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2812() {
    coral.tests.JPFBenchmark.benchmark53(94.22754061207027,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2813() {
    coral.tests.JPFBenchmark.benchmark53(94.26044321541667,-0.15000556254696562,0 ) ;
  }

  @Test
  public void test2814() {
    coral.tests.JPFBenchmark.benchmark53(94.27297226109934,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2815() {
    coral.tests.JPFBenchmark.benchmark53(94.36641264825883,-0.952175823754889,0 ) ;
  }

  @Test
  public void test2816() {
    coral.tests.JPFBenchmark.benchmark53(94.43441037545395,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2817() {
    coral.tests.JPFBenchmark.benchmark53(94.48009213528677,-0.06578658502428247,0 ) ;
  }

  @Test
  public void test2818() {
    coral.tests.JPFBenchmark.benchmark53(9.458100689564711,-0.6959970420679884,0 ) ;
  }

  @Test
  public void test2819() {
    coral.tests.JPFBenchmark.benchmark53(-94.64395025131387,-6.6736965024919E-16,1.0 ) ;
  }

  @Test
  public void test2820() {
    coral.tests.JPFBenchmark.benchmark53(94.77994464431961,-0.36290813333064176,0 ) ;
  }

  @Test
  public void test2821() {
    coral.tests.JPFBenchmark.benchmark53(94.78216359896183,-0.3991147118691849,0 ) ;
  }

  @Test
  public void test2822() {
    coral.tests.JPFBenchmark.benchmark53(94.84583802339733,-1.570796326794896,0 ) ;
  }

  @Test
  public void test2823() {
    coral.tests.JPFBenchmark.benchmark53(94.89159943292877,-1.5707963267948877,0 ) ;
  }

  @Test
  public void test2824() {
    coral.tests.JPFBenchmark.benchmark53(94.9344455629518,-0.06994724561239707,0 ) ;
  }

  @Test
  public void test2825() {
    coral.tests.JPFBenchmark.benchmark53(94.97390761762975,-0.21528618740032357,0 ) ;
  }

  @Test
  public void test2826() {
    coral.tests.JPFBenchmark.benchmark53(9.503165614951214,-1.5707963267948415,0 ) ;
  }

  @Test
  public void test2827() {
    coral.tests.JPFBenchmark.benchmark53(9.503294599695668,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2828() {
    coral.tests.JPFBenchmark.benchmark53(95.1092422682205,-0.5645544517832704,0 ) ;
  }

  @Test
  public void test2829() {
    coral.tests.JPFBenchmark.benchmark53(9.524200322016682,-1.043725843226812E-9,0 ) ;
  }

  @Test
  public void test2830() {
    coral.tests.JPFBenchmark.benchmark53(9.529740936027755,-0.5117320730418087,0 ) ;
  }

  @Test
  public void test2831() {
    coral.tests.JPFBenchmark.benchmark53(95.29983283766285,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test2832() {
    coral.tests.JPFBenchmark.benchmark53(95.32004666406984,-0.11592559322981799,0 ) ;
  }

  @Test
  public void test2833() {
    coral.tests.JPFBenchmark.benchmark53(9.535591796242656,-0.22241919827448697,0 ) ;
  }

  @Test
  public void test2834() {
    coral.tests.JPFBenchmark.benchmark53(95.43685033596807,-1.2873872797384206E-8,0 ) ;
  }

  @Test
  public void test2835() {
    coral.tests.JPFBenchmark.benchmark53(9.544516019818431,-1.0404426868010148,0 ) ;
  }

  @Test
  public void test2836() {
    coral.tests.JPFBenchmark.benchmark53(95.48378395025847,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2837() {
    coral.tests.JPFBenchmark.benchmark53(-95.51427911937806,-0.6521993198286947,0 ) ;
  }

  @Test
  public void test2838() {
    coral.tests.JPFBenchmark.benchmark53(95.51440843455839,-0.7601149716447493,0 ) ;
  }

  @Test
  public void test2839() {
    coral.tests.JPFBenchmark.benchmark53(95.60940315795861,-2.137541877742296E-9,0 ) ;
  }

  @Test
  public void test2840() {
    coral.tests.JPFBenchmark.benchmark53(95.62486422176508,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2841() {
    coral.tests.JPFBenchmark.benchmark53(95.63888177423684,-1.326219741654569,0 ) ;
  }

  @Test
  public void test2842() {
    coral.tests.JPFBenchmark.benchmark53(95.68982763014941,-0.7678415534682124,0 ) ;
  }

  @Test
  public void test2843() {
    coral.tests.JPFBenchmark.benchmark53(95.80122987439131,-1.3998226759373722,0 ) ;
  }

  @Test
  public void test2844() {
    coral.tests.JPFBenchmark.benchmark53(-95.87797491599363,-1.5707963267948963,-0.03152115645091407 ) ;
  }

  @Test
  public void test2845() {
    coral.tests.JPFBenchmark.benchmark53(9.588082412091234,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2846() {
    coral.tests.JPFBenchmark.benchmark53(-95.90143766146215,-6.863846962650183E-5,32.46953876878728 ) ;
  }

  @Test
  public void test2847() {
    coral.tests.JPFBenchmark.benchmark53(95.94758584839201,-0.9194147170285039,0 ) ;
  }

  @Test
  public void test2848() {
    coral.tests.JPFBenchmark.benchmark53(96.00494805771561,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2849() {
    coral.tests.JPFBenchmark.benchmark53(-96.01619684783053,-1.570796325196345,-46.69600619250163 ) ;
  }

  @Test
  public void test2850() {
    coral.tests.JPFBenchmark.benchmark53(96.08975609961051,-1.1175099652476845,0 ) ;
  }

  @Test
  public void test2851() {
    coral.tests.JPFBenchmark.benchmark53(96.10432010192321,-0.056204948975576485,0 ) ;
  }

  @Test
  public void test2852() {
    coral.tests.JPFBenchmark.benchmark53(96.13305641960207,-1.447412138109966,0 ) ;
  }

  @Test
  public void test2853() {
    coral.tests.JPFBenchmark.benchmark53(96.16034808645105,-0.7452610007754714,0 ) ;
  }

  @Test
  public void test2854() {
    coral.tests.JPFBenchmark.benchmark53(96.21546445465182,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2855() {
    coral.tests.JPFBenchmark.benchmark53(96.24213971428887,-0.0215065006616868,0 ) ;
  }

  @Test
  public void test2856() {
    coral.tests.JPFBenchmark.benchmark53(96.30237672976517,-0.5192731820367076,0 ) ;
  }

  @Test
  public void test2857() {
    coral.tests.JPFBenchmark.benchmark53(96.3270183847288,-0.19201535422680482,0 ) ;
  }

  @Test
  public void test2858() {
    coral.tests.JPFBenchmark.benchmark53(96.33697421482917,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2859() {
    coral.tests.JPFBenchmark.benchmark53(96.34917853775363,-1.4066313422225392,0 ) ;
  }

  @Test
  public void test2860() {
    coral.tests.JPFBenchmark.benchmark53(9.63787309601365,-1.0824669326909344,0 ) ;
  }

  @Test
  public void test2861() {
    coral.tests.JPFBenchmark.benchmark53(96.39364573433059,-0.884221091768465,0 ) ;
  }

  @Test
  public void test2862() {
    coral.tests.JPFBenchmark.benchmark53(96.42728974621178,-1.1410019033296313,0 ) ;
  }

  @Test
  public void test2863() {
    coral.tests.JPFBenchmark.benchmark53(96.44681348777027,-0.44230886445519957,0 ) ;
  }

  @Test
  public void test2864() {
    coral.tests.JPFBenchmark.benchmark53(96.4471521239808,-0.6955462281334182,0 ) ;
  }

  @Test
  public void test2865() {
    coral.tests.JPFBenchmark.benchmark53(96.50866481622523,-1.5707963267945573,0 ) ;
  }

  @Test
  public void test2866() {
    coral.tests.JPFBenchmark.benchmark53(96.51137562196969,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2867() {
    coral.tests.JPFBenchmark.benchmark53(96.62414184381325,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2868() {
    coral.tests.JPFBenchmark.benchmark53(96.6457117519682,-0.34240691216908115,0 ) ;
  }

  @Test
  public void test2869() {
    coral.tests.JPFBenchmark.benchmark53(96.66262983072937,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2870() {
    coral.tests.JPFBenchmark.benchmark53(96.69202033847341,-1.4759513455955897,0 ) ;
  }

  @Test
  public void test2871() {
    coral.tests.JPFBenchmark.benchmark53(96.73809715173044,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2872() {
    coral.tests.JPFBenchmark.benchmark53(96.74813723956908,-0.10854290290666135,0 ) ;
  }

  @Test
  public void test2873() {
    coral.tests.JPFBenchmark.benchmark53(96.79984032138034,-1.33498061461313,0 ) ;
  }

  @Test
  public void test2874() {
    coral.tests.JPFBenchmark.benchmark53(96.80138824836811,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2875() {
    coral.tests.JPFBenchmark.benchmark53(96.91398124212267,-1.5373477570769722,0 ) ;
  }

  @Test
  public void test2876() {
    coral.tests.JPFBenchmark.benchmark53(96.97759441531164,-0.8856338211457029,0 ) ;
  }

  @Test
  public void test2877() {
    coral.tests.JPFBenchmark.benchmark53(97.02263856775548,-1.5548297037732746,0 ) ;
  }

  @Test
  public void test2878() {
    coral.tests.JPFBenchmark.benchmark53(97.02995193410295,-0.531329056318639,0 ) ;
  }

  @Test
  public void test2879() {
    coral.tests.JPFBenchmark.benchmark53(97.10731952075957,-0.206645152484585,0 ) ;
  }

  @Test
  public void test2880() {
    coral.tests.JPFBenchmark.benchmark53(97.13308395054428,-1.5180435522210234,0 ) ;
  }

  @Test
  public void test2881() {
    coral.tests.JPFBenchmark.benchmark53(97.15298510237173,-0.6362934547618133,0 ) ;
  }

  @Test
  public void test2882() {
    coral.tests.JPFBenchmark.benchmark53(97.21459453458678,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2883() {
    coral.tests.JPFBenchmark.benchmark53(97.23111799099799,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2884() {
    coral.tests.JPFBenchmark.benchmark53(97.24260477893466,-0.35440050413566815,0 ) ;
  }

  @Test
  public void test2885() {
    coral.tests.JPFBenchmark.benchmark53(97.2963508082,-1.570796326794893,0 ) ;
  }

  @Test
  public void test2886() {
    coral.tests.JPFBenchmark.benchmark53(97.33156858140617,-0.9273103085517604,0 ) ;
  }

  @Test
  public void test2887() {
    coral.tests.JPFBenchmark.benchmark53(97.35245976385599,-10.89958103915005,-93.08141559229124 ) ;
  }

  @Test
  public void test2888() {
    coral.tests.JPFBenchmark.benchmark53(97.36476387956895,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2889() {
    coral.tests.JPFBenchmark.benchmark53(97.40980406802174,-1.5707963267948095,0 ) ;
  }

  @Test
  public void test2890() {
    coral.tests.JPFBenchmark.benchmark53(97.46799609539633,-2.8374265551452034E-7,0 ) ;
  }

  @Test
  public void test2891() {
    coral.tests.JPFBenchmark.benchmark53(97.48607607270435,-0.47996329287820805,0 ) ;
  }

  @Test
  public void test2892() {
    coral.tests.JPFBenchmark.benchmark53(97.49222461269582,-1.065346758991581,0 ) ;
  }

  @Test
  public void test2893() {
    coral.tests.JPFBenchmark.benchmark53(9.750506915434443,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2894() {
    coral.tests.JPFBenchmark.benchmark53(9.75434793004586,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2895() {
    coral.tests.JPFBenchmark.benchmark53(97.55333069153157,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2896() {
    coral.tests.JPFBenchmark.benchmark53(97.62856828800366,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2897() {
    coral.tests.JPFBenchmark.benchmark53(-97.65768641267316,-1.5707963267948963,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test2898() {
    coral.tests.JPFBenchmark.benchmark53(97.6604826402382,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2899() {
    coral.tests.JPFBenchmark.benchmark53(97.67826596469084,-1.5707963267948273,0 ) ;
  }

  @Test
  public void test2900() {
    coral.tests.JPFBenchmark.benchmark53(97.75517051043101,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2901() {
    coral.tests.JPFBenchmark.benchmark53(97.80848425332894,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2902() {
    coral.tests.JPFBenchmark.benchmark53(97.83523648695152,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2903() {
    coral.tests.JPFBenchmark.benchmark53(97.96140952412134,-1.054620597358186,0 ) ;
  }

  @Test
  public void test2904() {
    coral.tests.JPFBenchmark.benchmark53(98.00560560927153,-1.5707963267948912,0 ) ;
  }

  @Test
  public void test2905() {
    coral.tests.JPFBenchmark.benchmark53(98.0088257471686,-0.28022993269069296,0 ) ;
  }

  @Test
  public void test2906() {
    coral.tests.JPFBenchmark.benchmark53(98.01506007022763,-1.087601975854625,0 ) ;
  }

  @Test
  public void test2907() {
    coral.tests.JPFBenchmark.benchmark53(98.02861700269477,-0.2200908260382448,0 ) ;
  }

  @Test
  public void test2908() {
    coral.tests.JPFBenchmark.benchmark53(-98.03081160152954,-1.7763568394002505E-15,0.8345236836793635 ) ;
  }

  @Test
  public void test2909() {
    coral.tests.JPFBenchmark.benchmark53(98.0479732744825,-0.12369304975622697,0 ) ;
  }

  @Test
  public void test2910() {
    coral.tests.JPFBenchmark.benchmark53(98.08232099112547,-0.6479192415540354,0 ) ;
  }

  @Test
  public void test2911() {
    coral.tests.JPFBenchmark.benchmark53(98.08243731419904,-1.4565154371882567,0 ) ;
  }

  @Test
  public void test2912() {
    coral.tests.JPFBenchmark.benchmark53(98.0964389789057,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2913() {
    coral.tests.JPFBenchmark.benchmark53(98.12968552930244,-1.284960694496613,0 ) ;
  }

  @Test
  public void test2914() {
    coral.tests.JPFBenchmark.benchmark53(98.13640259283719,-9.95703157685848E-4,0 ) ;
  }

  @Test
  public void test2915() {
    coral.tests.JPFBenchmark.benchmark53(98.19824612318604,-1.5707963267948912,0 ) ;
  }

  @Test
  public void test2916() {
    coral.tests.JPFBenchmark.benchmark53(98.22065505206726,-0.3921966188560546,0 ) ;
  }

  @Test
  public void test2917() {
    coral.tests.JPFBenchmark.benchmark53(98.26188401918984,-0.6959489165676658,0 ) ;
  }

  @Test
  public void test2918() {
    coral.tests.JPFBenchmark.benchmark53(9.82713715980608,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2919() {
    coral.tests.JPFBenchmark.benchmark53(98.3519905761506,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2920() {
    coral.tests.JPFBenchmark.benchmark53(-98.37513907172699,-0.825808269213828,0.680034773217816 ) ;
  }

  @Test
  public void test2921() {
    coral.tests.JPFBenchmark.benchmark53(98.43614396994826,-0.48829871178179785,0 ) ;
  }

  @Test
  public void test2922() {
    coral.tests.JPFBenchmark.benchmark53(98.45725089090132,-0.20321784486115746,0 ) ;
  }

  @Test
  public void test2923() {
    coral.tests.JPFBenchmark.benchmark53(98.60841945535236,-1.0197389621845616,0 ) ;
  }

  @Test
  public void test2924() {
    coral.tests.JPFBenchmark.benchmark53(98.61037601897795,-1.278924832897161,0 ) ;
  }

  @Test
  public void test2925() {
    coral.tests.JPFBenchmark.benchmark53(9.867546261744067,-1.0984184487534492,0 ) ;
  }

  @Test
  public void test2926() {
    coral.tests.JPFBenchmark.benchmark53(98.70545166641321,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2927() {
    coral.tests.JPFBenchmark.benchmark53(98.71579493426094,-0.9243410201656701,0 ) ;
  }

  @Test
  public void test2928() {
    coral.tests.JPFBenchmark.benchmark53(98.74892366065063,-0.30108857156905344,0 ) ;
  }

  @Test
  public void test2929() {
    coral.tests.JPFBenchmark.benchmark53(98.79131917108631,-1.515160921800998,0 ) ;
  }

  @Test
  public void test2930() {
    coral.tests.JPFBenchmark.benchmark53(98.81385822349276,-0.3260645751407447,0 ) ;
  }

  @Test
  public void test2931() {
    coral.tests.JPFBenchmark.benchmark53(98.83093055781222,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2932() {
    coral.tests.JPFBenchmark.benchmark53(98.89097270807571,-0.07563554399138184,0 ) ;
  }

  @Test
  public void test2933() {
    coral.tests.JPFBenchmark.benchmark53(98.95197825894584,-0.8136168978358889,0 ) ;
  }

  @Test
  public void test2934() {
    coral.tests.JPFBenchmark.benchmark53(-98.95805426123312,-1.5707963267948948,-4.866817183866186 ) ;
  }

  @Test
  public void test2935() {
    coral.tests.JPFBenchmark.benchmark53(98.97367224700366,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2936() {
    coral.tests.JPFBenchmark.benchmark53(99.06302528598191,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test2937() {
    coral.tests.JPFBenchmark.benchmark53(99.16086516351206,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2938() {
    coral.tests.JPFBenchmark.benchmark53(-99.18915897892018,-1.5707963267948957,-100.0 ) ;
  }

  @Test
  public void test2939() {
    coral.tests.JPFBenchmark.benchmark53(99.33134719856645,-0.4000299343469047,0 ) ;
  }

  @Test
  public void test2940() {
    coral.tests.JPFBenchmark.benchmark53(-99.38362300081891,-11.381813024771944,48.279176618308924 ) ;
  }

  @Test
  public void test2941() {
    coral.tests.JPFBenchmark.benchmark53(99.38514833532271,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2942() {
    coral.tests.JPFBenchmark.benchmark53(99.42037049417749,-1.47173137406162,0 ) ;
  }

  @Test
  public void test2943() {
    coral.tests.JPFBenchmark.benchmark53(99.49955872075219,-0.9401698035023167,0 ) ;
  }

  @Test
  public void test2944() {
    coral.tests.JPFBenchmark.benchmark53(99.51796147625265,-1.5707963267948681,0 ) ;
  }

  @Test
  public void test2945() {
    coral.tests.JPFBenchmark.benchmark53(-99.565086148946,-0.2896687523536934,-0.988619551026804 ) ;
  }

  @Test
  public void test2946() {
    coral.tests.JPFBenchmark.benchmark53(99.5789735913055,-3.5096346709619364E-6,0 ) ;
  }

  @Test
  public void test2947() {
    coral.tests.JPFBenchmark.benchmark53(99.61067384852015,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2948() {
    coral.tests.JPFBenchmark.benchmark53(99.61281367881688,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2949() {
    coral.tests.JPFBenchmark.benchmark53(99.63152589189977,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2950() {
    coral.tests.JPFBenchmark.benchmark53(99.65329885056718,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2951() {
    coral.tests.JPFBenchmark.benchmark53(99.70889280570493,-0.46195783457739026,0 ) ;
  }

  @Test
  public void test2952() {
    coral.tests.JPFBenchmark.benchmark53(99.87137923026344,-1.0636717401694398,0 ) ;
  }

  @Test
  public void test2953() {
    coral.tests.JPFBenchmark.benchmark53(9.987812781559231,-1.5707963267948961,0 ) ;
  }
}
