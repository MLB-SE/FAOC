import org.junit.Test;

public class Sample41Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark41(-0.9999999999999999,2.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark41(-0.9999999999999999,2.0000000000000067 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,1.9999999999999998 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,2.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,2.0000000000000004 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark41(1.1303135998411311,0.1472952341446856 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark41(1.197525878609893,0.23654235133050316 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark41(3.500036175822127E-36,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark41(-3.5276391052116686E-36,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark41(-4.20632514779615,22.374047809053 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark41(6.0196625480713655E-5,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark41(-6.327998365565624E-9,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark41(66.36386057780018,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark41(-72.27772038219906,0.384860942434301 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark41(7.3540946669568825,46.728613703606776 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark41(77.34592841563145,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark41(-8.509717521927878E-24,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark41(8.843812714634633E-9,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark41(-9.27996288587275,95.39767404904846 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark41(96.46557534913237,0 ) ;
  }
}
