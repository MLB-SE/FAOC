import org.junit.Test;

public class Sample28Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark28(-0.03493164601418641 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark28(-0.038264614902701055 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark28(-0.0404878948507843 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark28(-0.0798298904552297 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark28(-0.12313771260559747 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark28(-0.13307202548458008 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark28(-0.15475962707031954 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark28(-0.2697982618845316 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark28(-0.3002585044943089 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark28(-0.3172758653984431 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark28(-0.3197131615349349 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark28(-0.34817408989040644 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark28(-0.3579564153374264 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark28(-0.4297686448659306 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark28(-0.4307994281112144 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark28(-0.45178534387567026 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark28(-0.46936559182699966 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark28(-0.5096792827969239 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark28(-0.5552305254623633 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark28(-0.7001092029063472 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark28(-0.7060707585951178 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark28(-0.7280745299347018 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark28(-0.7367723787201896 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark28(-0.7779127394456964 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark28(-0.7927468663403374 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark28(-0.8108662831007649 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark28(-0.918264387296162 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark28(-0.9311870004098779 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark28(-10.006907733464374 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark28(-10.054964163168293 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark28(-10.072750785692563 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark28(-10.094058678858104 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark28(-10.123148435418486 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark28(-10.140644732591284 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark28(-10.183625465954421 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark28(-10.209394779660158 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark28(-10.211910295346144 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark28(-10.272009329978587 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark28(-10.27695930200126 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark28(-10.282280709758723 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark28(-10.329996071764413 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark28(-10.344868607842812 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark28(-10.346474820721866 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark28(-10.376621926272406 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark28(-10.385147410319817 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark28(-10.455400310358783 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark28(-10.45638925733381 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark28(-10.492389443855217 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark28(-10.537820458657436 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark28(-10.539722374178666 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark28(-10.582246179851907 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark28(-10.583565723496278 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark28(-10.596772857996072 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark28(-10.600734679177506 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark28(-1.0657857437334854 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark28(-10.693694030858225 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark28(-10.710664488448572 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark28(-10.816174826816479 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark28(-10.840774796207313 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark28(-10.861109489432707 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark28(10.980971046275442 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark28(-10.990757621499597 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark28(-11.050560312982086 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark28(-11.055265212762876 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark28(-1.1169780158939489 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark28(-11.185417177279945 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark28(-11.210050682950595 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark28(-11.230039260174053 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark28(-11.230557941163369 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark28(-11.255949859929103 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark28(-11.26652477959638 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark28(-11.298543303185667 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark28(-11.299614889509229 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark28(-11.332665364646516 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark28(-1.1412334923456768 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark28(-11.510694184717636 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark28(-11.547096388877918 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark28(-11.593528832586003 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark28(-11.69027541097627 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark28(-11.706208380447094 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark28(-11.729831774294254 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark28(-11.805018492220327 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark28(-11.806151094778983 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark28(-11.837130399468435 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark28(-11.945517755742088 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark28(-11.973887615493027 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark28(-11.98476438303868 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark28(-12.046641002957315 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark28(-1.2119224468602567 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark28(-12.121824275709557 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark28(-12.129906898618174 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark28(-1.2140630281191562 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark28(-12.189807093516492 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark28(-12.212566640595938 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark28(-12.486432545603023 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark28(-12.568591257262128 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark28(-12.581494925923906 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark28(-12.718239635320174 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark28(-12.771395540430035 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark28(-12.774464946923445 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark28(-12.820467658840798 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark28(-12.824830875562725 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark28(-12.842375680039737 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark28(-12.935083731527783 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark28(-12.948319159715524 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark28(1.298676671344424 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark28(-13.020891209669784 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark28(-13.03216026084118 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark28(-13.053282702100404 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark28(-1.3075069480724864 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark28(-13.151334449491543 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark28(-13.191256257958557 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark28(-13.201563739518775 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark28(-13.219117065054391 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark28(-1.322790616416384 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark28(-13.231042874315179 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark28(-13.322782004063939 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark28(-13.349112517376199 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark28(-13.364846591379376 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark28(-13.369504706464895 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark28(-13.381911775670801 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark28(-13.51641029695567 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark28(-13.554414668434589 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark28(-13.563368241896256 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark28(-13.600522690248212 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark28(-13.647501540341864 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark28(-13.697524852700994 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark28(-13.707927478257716 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark28(-13.800301521814944 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark28(-13.824173949166223 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark28(-1.4008277896283943 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark28(-14.026509731273578 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark28(-14.062297744137325 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark28(-14.086851177905174 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark28(-14.087678504394674 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark28(-14.088291383700707 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark28(-14.110391412561384 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark28(-1.4141012163157711 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark28(-14.18818760953549 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark28(-14.189222977742517 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark28(-14.226044909574597 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark28(-14.259642930612287 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark28(-14.281622315721393 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark28(-14.363692973269664 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark28(-14.41115518873228 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark28(-14.458712413351662 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark28(-14.535827331992238 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark28(-14.563426069204482 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark28(-14.56867357258325 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark28(-14.582626787468442 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark28(-14.664828065825787 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark28(-14.683482354948055 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark28(-14.694614169588107 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark28(-14.706225892525666 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark28(-14.73502142277367 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark28(-14.790654915580049 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark28(-14.89877795510482 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark28(-14.912273805401327 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark28(-14.955283323969098 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark28(-14.969267799409906 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark28(-14.978892279554486 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark28(-14.987055464090432 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark28(-15.079047826340414 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark28(-15.102994768794574 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark28(-15.154052186613214 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark28(-15.156912059110425 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark28(-15.22991865957286 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark28(-15.251369344452655 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark28(-15.260034928997783 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark28(-15.279631500691494 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark28(-15.303989006972785 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark28(-15.328200968142454 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark28(-15.386646455130276 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark28(-15.444513917148711 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark28(-15.470955206663191 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark28(-15.494672901123323 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark28(-1.5510144659764933 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark28(-15.51138845268325 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark28(-15.667080371954839 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark28(-15.689039875073192 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark28(-15.711918746031756 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark28(-15.7140533573628 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark28(-15.775926677858607 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark28(-15.784466659251223 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark28(-15.801575405630828 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark28(-15.86424335817182 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark28(-15.872035292260733 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark28(-15.90195808768982 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark28(-1.600404289868834 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark28(-16.0374725495368 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark28(-16.059202858034155 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark28(-16.069795911993822 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark28(-16.07996947851393 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark28(-16.09330659899699 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark28(-16.135538015756936 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark28(-1.6138206891776292 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark28(-16.155581353367296 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark28(-16.17234664679104 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark28(-16.206585448477725 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark28(-16.234550315820016 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark28(-16.239295624280388 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark28(-16.264045802846866 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark28(-16.28146123242395 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark28(-16.345120127577076 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark28(-16.44061743210669 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark28(-16.45085707068607 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark28(-16.45779414277935 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark28(-16.48093184345916 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark28(-16.533065738363234 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark28(-16.55000912528004 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark28(-16.61992239951485 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark28(-16.630156941840497 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark28(-16.632958573849038 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark28(-16.653918514378347 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark28(-16.72766223606537 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark28(-16.750865256824852 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark28(-16.756656422230947 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark28(-16.85829857976624 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark28(-16.900452487769428 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark28(-16.949638999482048 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark28(-1.7017133268785187 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark28(-17.07225099521051 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark28(-17.086310912599288 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark28(-17.10495531061349 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark28(-17.158555240056643 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark28(-17.224040509261258 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark28(-17.273231354841045 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark28(-17.273620398432428 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark28(-17.28965120773647 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark28(-17.290601670656386 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark28(-17.330989040751803 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark28(-1.733637220008461 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark28(-17.344392145166026 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark28(-17.348502457273824 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark28(-17.362169049159377 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark28(-17.399454915751818 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark28(-17.45379375803327 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark28(-17.484349337329604 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark28(-17.496222749939562 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark28(-17.502392099452322 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark28(-17.50539746282152 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark28(-17.553184506206463 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark28(-17.56104848934457 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark28(-17.61625680585952 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark28(-17.62245902514239 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark28(-17.65591342531394 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark28(-17.665647116903102 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark28(-17.670265531817165 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark28(-17.706047307040507 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark28(-17.757966644930747 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark28(-17.84391527252521 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark28(-17.856132315896332 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark28(-17.895384978828048 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark28(-17.98113206756709 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark28(-18.01013715515272 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark28(-18.017046649345374 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark28(-18.0273553467258 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark28(-18.03380403324391 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark28(-18.035244565925822 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark28(-18.04457581149086 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark28(-1.8106657784325222 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark28(-1.8111900008714485 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark28(-18.19344919096521 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark28(-18.198479284355187 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark28(-18.198828890913404 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark28(-1.8199725721638202 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark28(-18.229150545421675 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark28(-18.269381383475462 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark28(-18.28045201585924 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark28(-18.30148308055108 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark28(-18.35562452680324 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark28(-18.38204932318655 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark28(-18.389266117171204 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark28(-18.38967591026011 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark28(-18.484680252298475 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark28(-18.494347070680206 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark28(-18.50186828861567 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark28(-18.526517951465763 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark28(-18.531421830239253 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark28(-18.586009965689556 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark28(-18.589899724840777 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark28(-18.655068170721847 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark28(-1.866118670190886 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark28(-18.74909446019366 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark28(-18.774908625958673 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark28(-18.80674436286192 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark28(-18.819334787870773 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark28(-18.86090608539152 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark28(-18.867994954507168 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark28(-18.92326618636963 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark28(-18.92358300514894 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark28(-18.979687265504225 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark28(-19.003250490523712 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark28(-19.03440692339767 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark28(-19.06500999995697 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark28(-19.16166597816901 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark28(-19.19402031239339 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark28(-19.194358975187328 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark28(-19.217781716944344 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark28(-19.2657313606486 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark28(-19.279186772448483 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark28(-19.28612701928924 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark28(-19.301983507526543 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark28(-19.305125850787675 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark28(-1.9324468378443527 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark28(-1.9336502203155987 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark28(-1.9377354538695784 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark28(-19.39388901953862 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark28(-19.432123683117396 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark28(-1.9433309106872798 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark28(-19.45042724942934 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark28(-19.46540974078404 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark28(-19.5382956060689 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark28(-19.54058163806988 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark28(-1.954069309445174 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark28(-19.6022549301329 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark28(-19.605419057424385 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark28(-19.619170477460358 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark28(-19.69063104082214 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark28(-19.78919459001918 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark28(-19.80630844228142 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark28(-19.815652564181747 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark28(-19.816258328629303 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark28(-19.9139896402057 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark28(-19.957167436853922 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark28(-20.039241217869204 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark28(-20.04926775754312 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark28(-20.058016410680352 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark28(-20.162303920918404 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark28(-20.17537394427231 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark28(-20.18594329451446 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark28(-20.197178852477563 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark28(-20.228266287279453 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark28(-20.246465412657912 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark28(-20.251089863645348 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark28(-20.267829202847352 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark28(-20.322911686151485 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark28(-20.33012591711234 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark28(-2.034611771956321 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark28(-20.3969414095927 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark28(-20.42424352956283 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark28(-20.47916203547227 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark28(-20.48052189469513 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark28(-20.480578456395662 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark28(-20.495707926510647 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark28(-20.497411952054676 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark28(-20.63450937163809 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark28(-20.64524667906464 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark28(-20.699772086903124 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark28(-20.742026643136796 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark28(-20.74695517453864 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark28(-20.767792119459585 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark28(-2.077074654611806 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark28(-20.805477704116072 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark28(-20.806439908300092 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark28(-20.853905429768304 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark28(-20.96708396319478 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark28(-21.150040103130536 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark28(-21.167796222699934 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark28(-21.229287580791564 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark28(-21.24219259913309 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark28(-21.25679913713421 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark28(-21.296288550935245 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark28(-21.3331969907548 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark28(-21.33943301626762 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark28(-21.363501042808593 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark28(-2.1382117680737565E-50 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark28(-21.414150921768794 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark28(-21.419288780189746 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark28(-21.438643959194323 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark28(-21.47332343447647 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark28(-21.48895124787633 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark28(-21.559551843298365 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark28(-21.562634607687897 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark28(-21.62021334598127 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark28(-21.621013047889747 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark28(-21.623401951860387 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark28(-2.168221659000565 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark28(-21.712827526630377 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark28(-21.77762002229396 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark28(-21.89753860153803 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark28(-21.976452936637727 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark28(-21.98444186130952 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark28(-21.999902475069533 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark28(-22.01057424909152 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark28(-22.01286889938936 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark28(-22.094763819956853 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark28(-22.1196722947374 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark28(-22.13647502062406 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark28(-2.213958879914273 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark28(-22.206209616190947 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark28(-22.212999408019726 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark28(-22.22010882051741 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark28(-22.24272878169127 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark28(-22.274349789665877 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark28(-22.28446762022361 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark28(-22.390722933206277 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark28(-2.239736419594635 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark28(-22.398975351241063 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark28(-22.43445794710415 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark28(-22.47737937476775 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark28(-22.518757466640253 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark28(-22.523034060603962 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark28(-22.552178788529957 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark28(-22.553811978734643 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark28(-22.574046169255823 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark28(-22.62517347020632 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark28(-22.63466923243287 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark28(-2.2663210561761673 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark28(-22.671901588243372 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark28(-22.67340176550003 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark28(-22.673655218472533 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark28(-22.6784426494375 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark28(-2.272244428727703 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark28(-2.2751307456583874 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark28(-22.751732537600986 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark28(-2.276630720072774 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark28(-22.798489904877712 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark28(-22.79880883843171 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark28(-22.800920294491704 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark28(-22.863871376434616 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark28(-22.874419208901813 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark28(-22.924310374566105 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark28(-22.987589237301705 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark28(-23.007062025804004 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark28(-23.014363732260534 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark28(-23.05777039379086 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark28(-23.124997541095553 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark28(-23.188540484415142 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark28(-23.195996642903907 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark28(-2.3206411511663276 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark28(-23.227539960708413 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark28(-23.277839459673828 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark28(-2.330331295982006 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark28(-23.324840641166958 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark28(-23.36341477634845 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark28(-23.42076695522084 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark28(-23.456206602092237 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark28(-23.460822276436204 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark28(-23.53386395898775 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark28(-23.54529834330519 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark28(-23.556294220225496 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark28(-23.591661238255284 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark28(-23.594560613536245 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark28(-23.600295441973202 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark28(-23.61342999371064 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark28(-23.618078152557274 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark28(-23.632279384491255 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark28(-23.687612384462327 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark28(-2.371245143220662 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark28(-2.3811948085068195 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark28(-23.874281490025766 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark28(-23.91425768946172 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark28(-23.949085212136993 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark28(-24.06786518071739 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark28(-24.10638228776918 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark28(-24.116051612034866 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark28(-24.24434914521582 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark28(-24.287167345348976 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark28(-24.344974249912312 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark28(-24.348169499826895 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark28(-24.386012933414108 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark28(-24.399868222631056 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark28(-24.41492145907415 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark28(-24.428411547890022 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark28(-24.450798954576626 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark28(-24.470128594469003 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark28(-24.47539998813548 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark28(-24.480002528726914 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark28(-2.4482834023314126 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark28(-24.48324810858989 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark28(-24.48912726194527 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark28(-24.490910720088905 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark28(-24.500701258658665 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark28(-24.51726399185557 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark28(-24.53851566437592 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark28(-24.581400814081462 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark28(-24.610805913217064 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark28(-24.65071417661622 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark28(-24.694497987699535 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark28(-24.705722993724606 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark28(-24.74689561092957 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark28(-24.801242611320646 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark28(-24.855743993170364 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark28(-24.900542363456253 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark28(-24.905513682568014 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark28(-24.90740054102541 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark28(-24.9617925241225 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark28(-24.977414258978172 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark28(-24.99279493257241 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark28(-25.008284761156446 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark28(-2.5009950855234564 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark28(-25.028194416239074 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark28(-25.11560164489734 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark28(-25.12701224512466 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark28(-25.130625016199332 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark28(-25.14044629163685 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark28(-2.520227403204146 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark28(-2.5221832478375745 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark28(-25.298809349760205 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark28(-25.32728334050549 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark28(-25.361856067273948 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark28(-25.369475379650325 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark28(-25.456627385965504 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark28(-25.560006070167063 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark28(-25.573703403051056 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark28(-25.61013421046748 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark28(-25.61610181494561 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark28(-25.69531079360938 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark28(-25.702535875354982 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark28(-25.714871505492283 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark28(-25.72232195130637 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark28(-25.747418517244142 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark28(-25.792357576717293 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark28(-2.5815253128120332 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark28(-25.83752120915628 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark28(-25.85110913031528 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark28(-25.864104323670546 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark28(-25.867651929587026 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark28(-25.889247843206846 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark28(-25.892708716775843 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark28(-25.898584414376046 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark28(-25.94120969550049 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark28(-25.941435887702752 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark28(-25.957295805763152 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark28(-25.957870207953107 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark28(-25.969055234660573 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark28(-25.99471315687414 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark28(-26.0410295939638 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark28(-26.042929318534817 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark28(-26.068656574845093 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark28(-26.086135682959437 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark28(-26.111679168964457 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark28(-26.12370785925262 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark28(-2.6150830039621837 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark28(-26.1739295261918 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark28(-26.188929574920493 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark28(-26.21602171702662 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark28(-26.23532848959384 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark28(-26.272504925014758 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark28(-26.28723570417381 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark28(-26.382428664480415 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark28(-26.388916733863084 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark28(-26.41631019705774 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark28(-26.42969642083324 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark28(-2.6511317963100396 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark28(-26.560747661309094 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark28(-26.563110036403742 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark28(-26.596603715735426 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark28(-26.616001869383908 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark28(-26.62342785961181 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark28(-26.660582897331196 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark28(-26.665725943050944 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark28(-26.731370926097625 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark28(-26.78362247793258 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark28(-26.80987168065218 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark28(-26.868576205726 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark28(-26.916878174214858 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark28(-26.935973493270353 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark28(-26.952935062726894 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark28(-2.6994195084601955 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark28(-26.99924779519867 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark28(-27.060747699101114 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark28(-27.093005486078496 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark28(-27.10457782680622 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark28(-27.151777837448293 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark28(-27.212108399865826 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark28(-27.244958655482108 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark28(-27.25360931577481 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark28(-2.7285185272700545 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark28(-27.38814087414643 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark28(-27.400084610065065 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark28(-27.43310923271713 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark28(-27.489342585292945 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark28(-27.49315782810629 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark28(-2.7613607144452317 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark28(-2.762835084838372 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark28(-27.696686335482326 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark28(-2.7725914589593685 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark28(-27.77123965708155 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark28(-27.81175759995591 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark28(-27.84200037805249 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark28(-27.848880470022635 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark28(-27.853775839042697 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark28(-27.894813429025007 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark28(-27.896377105028947 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark28(-27.98473694817025 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark28(-2.80508493380583 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark28(-28.057569832080276 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark28(-28.086040650493317 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark28(-28.092603918677767 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark28(-28.099089084646536 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark28(-28.136416158570142 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark28(-28.157828423098124 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark28(-28.216189346185416 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark28(-28.22911008976419 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark28(-28.308250349216465 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark28(-28.377882543198425 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark28(-28.390639142886954 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark28(-28.402708200779173 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark28(-28.40392089916419 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark28(-28.451808755067916 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark28(-28.515510805443213 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark28(-28.542940509179516 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark28(-28.565366510398732 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark28(-28.66601157324888 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark28(-28.67340620032219 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark28(-28.682642550116967 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark28(-28.768160848924936 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark28(-28.768796709819483 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark28(-28.769194901993572 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark28(-28.871985111473904 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark28(-28.874756778232083 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark28(-28.927741138742007 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark28(-28.9399930085126 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark28(-28.98827275728908 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark28(-29.10106604054306 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark28(-2.9202370907920567 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark28(-29.232468985006548 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark28(-29.24970585727806 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark28(-29.2517346356353 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark28(-29.284851268595943 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark28(-29.287398531738162 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark28(-29.28940077467803 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark28(-29.291014029850885 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark28(-29.31266420705201 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark28(-29.31738054142714 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark28(-2.932769073748645 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark28(-2.933587619914718 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark28(-2.933767829842452 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark28(-2.934297282376704 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark28(-29.45444928261651 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark28(-29.485339944972353 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark28(-29.506623389850347 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark28(-29.552912242843973 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark28(-29.5853101326269 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark28(-29.590758748524237 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark28(-29.598513817555954 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark28(-29.65946316606383 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark28(-2.967764077245022 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark28(-29.778287965020226 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark28(-29.821860075498023 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark28(-29.882575842085117 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark28(-29.89614783051438 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark28(-2.993962208221987 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark28(-30.03379963106913 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark28(-30.0356216549484 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark28(-30.04747232916911 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark28(-30.052966252334016 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark28(-30.1778945226568 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark28(-3.0197451447158414 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark28(-30.24402090746338 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark28(-30.302251372049938 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark28(-30.311925233946013 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark28(-30.379785432237654 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark28(-30.418620839467977 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark28(-30.419657500765098 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark28(-30.4301851775667 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark28(-30.458490927750532 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark28(-30.47063595752371 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark28(-30.520695741798278 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark28(-30.52212482189387 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark28(-30.527248800345646 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark28(-3.055136186070712 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark28(-30.576101759916384 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark28(-30.583256707134467 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark28(-30.6129638800396 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark28(-30.62851317874447 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark28(-30.72598555927057 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark28(-30.754540634598044 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark28(-30.76806823925793 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark28(-30.77552840520063 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark28(-30.785702852544645 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark28(-30.80346805161416 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark28(-30.816713542397096 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark28(-3.0835825913421644 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark28(-30.846638026201447 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark28(-30.870599404887827 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark28(-30.875373760306914 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark28(-30.892787192785605 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark28(-30.910312323209027 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark28(-30.915329747415882 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark28(-30.93577996659637 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark28(-31.088778753056445 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark28(-31.095209793800535 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark28(-31.120526643413854 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark28(-31.12258839398106 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark28(-31.16533214909731 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark28(-31.265384960817258 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark28(-31.310770445284234 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark28(-31.313234512390494 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark28(-3.1352608831557376 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark28(-31.363929605390737 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark28(-31.37648533088229 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark28(-31.483646019800588 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark28(-3.1527409415768943 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark28(-31.575246224377665 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark28(-31.57764667797464 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark28(-31.620354138318447 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark28(-31.674104549952048 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark28(-31.762776772538558 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark28(-31.764120194684395 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark28(-31.764616092440562 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark28(-31.805821471160513 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark28(-31.80979836110056 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark28(-31.821554758566492 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark28(-31.85434501146713 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark28(-3.193164495768258 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark28(-31.937282234596992 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark28(-31.943490010021264 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark28(-31.94989426246471 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark28(-31.950891083542615 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark28(-31.983728027211058 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark28(-32.00020571132339 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark28(-32.020839703183725 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark28(-32.05280281077437 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark28(-32.11917746925741 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark28(-32.13926556442391 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark28(-32.14099270202577 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark28(-32.15588790504941 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark28(-32.17672926806512 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark28(-32.18710387743977 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark28(-32.21839548458318 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark28(-32.25779080911944 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark28(-32.268541908441705 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark28(-32.39083771977273 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark28(-32.47686198635307 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark28(-32.51792981733601 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark28(-32.5206346641276 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark28(-32.57331042857605 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark28(-32.58290115092896 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark28(-32.58519492753828 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark28(-32.60645343968562 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark28(-32.61503264691166 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark28(-32.67264600987912 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark28(-32.713891157338225 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark28(-32.74602499171773 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark28(-32.762171879357254 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark28(-32.83373822949285 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark28(-32.846055526125966 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark28(-32.85746304620656 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark28(-3.286684624277882 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark28(-32.88074711346947 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark28(-32.95955663935743 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark28(-33.00257707999705 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark28(-33.01656853806412 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark28(-33.03000705242154 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark28(-33.03660486252029 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark28(-33.037867846233766 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark28(-33.05621683718425 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark28(-33.117618786854536 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark28(-33.132358903477694 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark28(-33.21249261450667 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark28(-33.2626282908911 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark28(-33.30640086955742 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark28(-33.34924523967334 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark28(-3.335646397319337 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark28(-33.37234982827886 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark28(-33.402912573854266 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark28(-3.34693585583004 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark28(-33.51459212453996 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark28(-33.5272543826501 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark28(-33.535545905185614 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark28(-33.53809577551196 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark28(-33.55194168089726 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark28(-33.55881891382997 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark28(-33.603348646530165 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark28(-33.61863444439041 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark28(-33.62053882519514 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark28(-3.3692544305140615 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark28(-33.700166747312 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark28(-33.75296524828788 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark28(-33.815803082261425 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark28(-33.84860645646481 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark28(-33.86679193843132 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark28(-3.395226030466006 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark28(-33.95963588395044 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark28(-33.985578268720616 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark28(-34.017113770282165 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark28(-34.03677003633479 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark28(-34.0539717996744 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark28(-34.059258682603485 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark28(-34.07882593953859 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark28(-34.09614041725327 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark28(-34.12534071243738 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark28(-34.17902241667959 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark28(-34.19948703450724 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark28(-34.20843288157664 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark28(-34.265892702937805 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark28(-34.32650519556081 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark28(-3.436273583572273 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark28(-3.439140377285071 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark28(-34.49883868405024 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark28(-34.50984055166306 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark28(-34.55508690173002 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark28(-34.561408982051105 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark28(-34.57318341612765 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark28(-34.68440644386959 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark28(-34.78438059546143 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark28(-34.799367019132106 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark28(-34.85574994422767 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark28(-34.93805338140706 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark28(-3.493983439266117 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark28(-34.96845394579209 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark28(-34.979293591232846 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark28(-3.501348003684896 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark28(-35.065672764241015 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark28(-35.106560798878704 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark28(-35.12108152510794 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark28(-35.12469808213348 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark28(-35.132672551823745 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark28(-35.133046433610886 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark28(-35.15750744147499 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark28(-35.21711914088223 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark28(-3.5246796564768204 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark28(-35.252617460225835 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark28(-35.253481183975865 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark28(-35.306346741910005 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark28(-35.3105317653072 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark28(-35.393335133145726 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark28(-35.40175755254211 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark28(-35.43771436337238 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark28(-35.45378727803474 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark28(-35.47017378192159 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark28(-35.472490763980005 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark28(-35.53689937158349 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark28(-35.5449120446261 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark28(-35.57964968044398 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark28(-35.58792789088284 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark28(-35.597714324758115 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark28(-35.605942280816436 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark28(-35.60711897245395 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark28(-35.62951229743054 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark28(-35.64711331056094 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark28(-35.6473047855508 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark28(-35.716999250842946 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark28(-35.73788389586652 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark28(-35.83880614390675 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark28(-3.5853826902279735 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark28(-35.866664024475654 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark28(-35.87277078102528 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark28(-35.8789864638903 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark28(-35.92266790894243 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark28(-35.924525610913776 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark28(-35.98694511718874 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark28(-36.08030851368089 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark28(-36.08593595802603 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark28(-36.10408332391424 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark28(-3.615289337484896 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark28(-3.616452507558847 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark28(-36.1705439275513 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark28(-36.18579606160699 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark28(-36.18725863170875 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark28(-36.20263458107693 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark28(-36.21601648786681 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark28(-36.217385466513804 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark28(-36.34204759024022 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark28(-36.360043839253464 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark28(-36.42679057026685 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark28(-36.43690017102115 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark28(-3.6439251394606345 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark28(-36.48028186813801 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark28(-36.50478608815113 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark28(-36.53916592222426 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark28(-36.541367394843526 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark28(-36.561200114890255 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark28(-36.57625777737081 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark28(-36.57778934168472 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark28(-36.627491818981504 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark28(-36.66262964153961 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark28(-3.666727773625638 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark28(-3.666900816347237 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark28(-36.68110359564978 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark28(-36.703161039536546 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark28(-36.75384490746967 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark28(-36.77207721485451 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark28(-36.78004160543029 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark28(-36.78466025962561 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark28(-36.79787148098428 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark28(-36.849564663107515 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark28(-36.852775854423726 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark28(-36.96116312508977 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark28(-37.064666890700025 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark28(-37.08565394953123 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark28(-37.08712367181719 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark28(-37.08982954062272 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark28(-37.09073650091883 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark28(-37.10956743394534 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark28(-3.7117415295656855 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark28(-37.17966567857582 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark28(-37.249993578149045 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark28(-37.29304346922966 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark28(-37.361429885748024 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark28(-37.4209333280908 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark28(-37.45019667548015 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark28(-37.451475538122445 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark28(-37.470012953378486 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark28(-37.481172671218154 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark28(-3.75700140968884 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark28(-37.623045730058635 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark28(-37.66315500053257 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark28(-37.68383487443481 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark28(-37.69794834371254 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark28(-37.77894636672039 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark28(-37.809368899421344 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark28(-37.868731213716615 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark28(-37.886504711797464 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark28(-37.91574154580133 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark28(-37.95826535682052 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark28(-37.99699961099427 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark28(-38.001916184545045 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark28(-38.04661273491976 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark28(-38.085991416105536 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark28(-3.809894920264668 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark28(-38.11260913002521 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark28(-38.16170446148877 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark28(-38.176142337479945 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark28(-38.221258764156474 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark28(-38.22489464075027 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark28(-38.27672037215481 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark28(-38.32207636437004 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark28(-38.37080138063382 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark28(-38.39996523675997 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark28(-38.46235454811659 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark28(-38.48177627904521 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark28(-38.48224277230905 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark28(-38.49302256782832 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark28(-38.5036932004738 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark28(-38.514691379387656 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark28(-38.57178867741591 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark28(-38.57775069500053 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark28(-38.5822513035198 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark28(-38.597354254883996 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark28(-38.6010453152394 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark28(-38.616853003055 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark28(-3.8647934984496572 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark28(-38.715802695922584 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark28(-38.72947811711367 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark28(-38.751466133798054 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark28(-38.752745495557164 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark28(-38.79733914381853 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark28(-38.879425180772074 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark28(-3.8906502525408087 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark28(-3.898211608531625 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark28(-39.008458104829515 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark28(-3.906071296055643 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark28(-39.092086020831054 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark28(-39.1377240037855 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark28(-3.913799115507956 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark28(-39.28282939885437 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark28(-39.29629309785649 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark28(-39.30453087671726 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark28(-39.3415614475227 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark28(-3.9373890289470523 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark28(-39.39215040890449 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark28(-39.39938814878092 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark28(-39.41109996265586 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark28(-39.43979460995393 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark28(-39.44085851249846 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark28(-39.512336609002354 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark28(-39.51454857045715 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark28(-39.52349515366009 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark28(-39.610032672246184 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark28(-39.61864199509533 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark28(-39.67661814487968 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark28(-39.67859821763051 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark28(-39.68020285676226 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark28(-39.70590367722588 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark28(-39.72675343315688 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark28(-39.799014096810794 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark28(-39.840420687873326 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark28(-39.86791704533361 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark28(-39.88194400177958 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark28(-39.902731034957895 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark28(-39.930598799825276 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark28(-39.95331155110862 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark28(-40.0249858905167 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark28(-40.03757129084118 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark28(-40.07101952104071 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark28(-40.10242024332702 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark28(-4.0129594369086306 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark28(-4.013119881793912 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark28(-40.14539959164658 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark28(-40.1649573228126 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark28(-40.216689976147954 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark28(-40.24127029236233 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark28(-40.2473219578702 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark28(-40.266150855098594 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark28(-40.28735229750451 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark28(-40.33971354509236 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark28(-40.38077356374807 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark28(-4.044092642813439 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark28(-40.56918783171524 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark28(-40.614959217881655 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark28(-40.65166105494822 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark28(-40.67484723904744 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark28(-40.68647620917256 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark28(-40.779719334411 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark28(-40.782654285835676 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark28(-40.808463052053234 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark28(-40.82489648116845 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark28(-40.87373132399823 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark28(-40.90279064872917 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark28(-40.912766529837356 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark28(-40.96305365566633 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark28(-40.99274696072626 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark28(-41.00293664273957 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark28(-41.031049559230624 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark28(-41.102518232598584 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark28(-41.11054748352172 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark28(-4.118363393331066 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark28(-41.21677742879466 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark28(-41.2455875479897 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark28(-41.26482182593676 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark28(-41.36730689885866 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark28(-41.39878918636357 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark28(-41.40257217841929 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark28(-41.41364346478784 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark28(-41.4261485567609 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark28(-41.43551310065292 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark28(-41.46916916563808 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark28(-41.47714592752851 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark28(-41.49003183070676 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark28(-41.61407521982956 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark28(-41.633294340025564 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark28(-41.66742205493485 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark28(-41.66869202488424 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark28(-41.67925948878997 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark28(-41.70672498218815 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark28(-41.79850833691647 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark28(-41.84045409244208 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark28(-41.87202207902776 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark28(-41.876993003793174 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark28(-41.887136708561144 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark28(-41.89807117365254 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark28(-41.91083502112751 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark28(-41.94651631415611 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark28(-4.1974474031159446 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark28(-42.0084082734435 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark28(-42.05389795424826 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark28(-42.063151476696106 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark28(-42.163979154483464 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark28(-42.16506349459637 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark28(-42.205924761149724 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark28(-42.2129566204668 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark28(-4.225204286821608 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark28(-42.25736497061669 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark28(-42.260875502004595 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark28(-4.233002434596983 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark28(-42.36796271567602 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark28(-42.446797760711675 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark28(-42.461731043892634 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark28(-4.2494691075720965 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark28(-42.508178721895206 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark28(-42.589409761665586 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark28(-42.638041027184315 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark28(-42.638616013260574 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark28(-42.651443148526184 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark28(-42.667265064948644 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark28(-42.67413272823863 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark28(-42.76463070919696 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark28(-42.79345005635995 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark28(-42.80795976513725 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark28(-42.84587156455804 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark28(-42.863803759586204 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark28(-42.86808267996487 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark28(-42.8790172017476 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark28(-42.89407863678103 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark28(-42.89701254077571 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark28(-42.90417563627618 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark28(-42.90566693378379 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark28(-42.9241233310524 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark28(-43.0178439188295 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark28(-4.304117780492135 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark28(-43.066836466279845 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark28(-43.075928029701146 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark28(-43.11338128217057 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark28(-43.305714422433425 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark28(-43.32073706839663 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark28(-43.32486472449239 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark28(-43.45420085273548 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark28(-43.50502962058045 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark28(-43.623804151877145 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark28(-43.668559892746984 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark28(-4.369545682119224 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark28(-43.709034351806444 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark28(-4.377620136698496 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark28(-43.78664463023134 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark28(-43.830161356903034 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark28(-43.83444284599474 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark28(-43.91434305135202 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark28(-43.92451155001362 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark28(-43.97136811321589 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark28(-43.98861712748923 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark28(-43.995800400369745 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark28(-44.12264224288609 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark28(-44.15527589573873 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark28(-44.17005677064796 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark28(-44.17931057852926 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark28(-44.204991526036316 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark28(-44.213808486759156 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark28(-44.22281994903025 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark28(-44.225669421714755 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark28(-44.26624275718907 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark28(-44.35475566526952 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark28(-44.38106201862115 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark28(-44.40339492732126 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark28(-44.41137011273244 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark28(-44.4133171095894 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark28(-44.422583693506134 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark28(-44.48650989301688 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark28(-44.50362000574699 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark28(-44.515615906101445 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark28(-44.52927756119143 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark28(-44.61052238134844 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark28(-44.62882100228482 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark28(-44.63155733500028 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark28(-44.63640043949848 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark28(-44.64779301129791 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark28(-44.67653058821106 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark28(-44.77886343657258 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark28(-44.786997521902826 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark28(-44.881095686340224 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark28(-44.92428056689701 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark28(-44.9628374302697 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark28(-44.96805980992144 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark28(-45.00426919068361 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark28(-45.083894387125056 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark28(-45.08749282712454 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark28(-45.16942267919954 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark28(-45.17285126193833 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark28(-45.311460071410934 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark28(-4.532883554482154 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark28(-45.35596102691424 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark28(-45.56049569751019 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark28(-45.56380426289206 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark28(-45.592007997179465 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark28(-45.59663803848657 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark28(-45.603234391457484 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark28(-45.69023557692042 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark28(-45.69646773364475 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark28(-45.87751585004438 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark28(-45.88173376668712 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark28(-45.884055238058366 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark28(-45.909799174851564 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark28(-45.92391028218867 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark28(-45.95311179204153 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark28(-45.96077658315141 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark28(-45.964601310173016 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark28(-4.599501162410988 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark28(-46.02289880912651 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark28(-4.604565883864751 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark28(-46.0472461954365 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark28(-46.05968727665213 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark28(-46.069277778574815 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark28(-4.607368200925734 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark28(-46.1142063120652 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark28(-4.618953412292328 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark28(-46.2640450679612 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark28(-46.27119455704622 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark28(-46.28709939053357 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark28(-46.29387732442147 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark28(-46.31262080356993 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark28(-46.38691862655513 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark28(-46.41456258116716 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark28(-46.43599586175113 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark28(-46.48906466432044 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark28(-46.49782649670882 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark28(-46.52458590357909 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark28(-46.59779817607088 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark28(-46.60584119551612 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark28(-46.642595607990486 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark28(-46.64823352467123 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark28(-46.66715418533318 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark28(-46.6725976973557 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark28(-46.70974750394252 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark28(-46.777886992357786 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark28(-4.683685397560211 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark28(-46.87775401695606 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark28(-46.966463042424955 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark28(-47.02054303832086 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark28(-47.022612181385725 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark28(-47.03153080956628 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark28(-47.05270221749029 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark28(-47.07615530393683 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark28(-47.139854017999916 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark28(-47.15820222838762 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark28(-4.718787158362943 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark28(-47.22249120562487 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark28(-47.257992004581226 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark28(-47.26423461296003 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark28(-47.27976013102415 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark28(-47.29030499229596 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark28(-47.307116281427184 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark28(-47.33246392097976 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark28(-47.34198438082438 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark28(-47.34556169838229 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark28(-47.35225238996785 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark28(-47.42560958476534 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark28(-47.432194728065504 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark28(-47.593164341027986 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark28(-47.66795180912604 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark28(-47.72605319239318 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark28(-47.777350366199656 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark28(-47.802059688388844 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark28(-47.84504469816413 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark28(-47.85540508426185 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark28(-4.785849865904979 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark28(-47.87507529877957 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark28(-47.96211083538871 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark28(-47.98704470405606 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark28(-48.02152591424205 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark28(-48.040587674644364 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark28(-48.07589939785739 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark28(-48.07668221656789 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark28(-48.0974017150563 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark28(-48.108659668121014 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark28(-4.813050966037366 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark28(-48.16867825469608 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark28(-48.17093104181447 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark28(-48.2381554318672 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark28(-48.241289962168345 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark28(-48.311212834629494 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark28(-48.331325236731246 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark28(-48.36680795786856 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark28(-48.402737017646594 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark28(-48.45229772786155 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark28(-48.55449061292032 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark28(-48.56894867123573 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark28(-48.62330210373036 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark28(-48.626663491804 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark28(-48.64783809344431 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark28(-48.68422856482788 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark28(-48.731801971646924 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark28(-48.765158405049625 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark28(-48.78083644729361 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark28(-48.811959329789765 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark28(-48.84469537805967 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark28(-48.864287918810724 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark28(-48.874743334134905 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark28(-4.889881185951836 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark28(-48.98908528028776 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark28(-49.133662830116286 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark28(-49.180096580776244 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark28(-49.181042368342155 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark28(-49.18925457618146 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark28(-49.208795676628284 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark28(-49.2867939675729 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark28(4.930380657631324E-32 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark28(-49.32193716304225 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark28(-49.32949283674437 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark28(-49.35096915895476 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark28(-49.40361035006244 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark28(-49.41699365144083 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark28(-49.426595573947665 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark28(-4.945620676533039 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark28(-49.47571254136107 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark28(-49.483878747362 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark28(-49.48500565325868 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark28(-4.956621768219321 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark28(-49.583117255899786 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark28(-4.9672033013918195 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark28(-49.69092085934157 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark28(-49.69585198825119 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark28(-49.72022269927068 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark28(-49.77821053087408 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark28(-49.80344857622987 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark28(-49.80446653724917 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark28(-49.81883014269217 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark28(-49.84412073717006 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark28(-49.86587251655228 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark28(-49.94255108168033 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark28(-50.139690732517316 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark28(-50.16724390261089 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark28(-50.16901812946026 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark28(-50.20008977486512 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark28(-50.23157695638456 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark28(-50.28921523725334 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark28(-50.312904535854905 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark28(-50.404941734991546 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark28(-50.462735066977075 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark28(-50.52380333779689 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark28(-50.55192107051452 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark28(-50.564913543828524 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark28(-50.619410179232325 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark28(-5.0623432634598515 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark28(-50.69921297730424 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark28(-50.713655237123476 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark28(-50.79766705636424 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark28(-50.85759219384771 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark28(-50.87129882952124 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark28(-5.088382704856144 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark28(-50.93822814181539 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark28(-51.00972363003999 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark28(-51.01064443192453 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark28(-51.0713554048851 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark28(-51.072840027375776 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark28(-51.08243141993276 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark28(-51.1113584193851 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark28(-5.1149364022930826 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark28(-5.117144585052742 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark28(-51.182512667930965 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark28(-51.19524314928903 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark28(-5.120335373847013 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark28(-51.218269017953055 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark28(-51.24492352717813 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark28(-51.24988636268686 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark28(-51.264095414044306 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark28(-51.32535426500431 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark28(-51.37762543407618 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark28(-51.38862090846017 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark28(-51.39189945757283 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark28(-51.39384746038016 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark28(-51.4085828851855 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark28(-51.436485632089735 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark28(-51.567865978228845 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark28(-51.598642154056876 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark28(-5.160349515998448 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark28(-51.64840854276971 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark28(-51.660891014043116 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark28(-51.661563757934445 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark28(-51.695894807786466 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark28(-51.69913167374693 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark28(-51.71079547416944 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark28(-51.72063137930785 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark28(-51.73189011380723 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark28(-51.73502105858834 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark28(-51.80030758862908 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark28(-5.184630752060244 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark28(-51.865262950816124 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark28(-51.90747138581895 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark28(-51.946898671439314 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark28(-51.953996773063714 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark28(-51.97466851491799 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark28(-51.981331830033284 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark28(-52.0218336354277 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark28(-52.06436252295068 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark28(-52.094997367539484 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark28(-52.12407097411776 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark28(-52.13767500186417 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark28(-52.175360372529276 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark28(-52.29762658655368 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark28(-5.229882226655775 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark28(-52.348224953581024 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark28(-52.36253677305442 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark28(-52.39559312891595 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark28(-52.45147183186742 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark28(-52.47538153119504 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark28(-52.515250212168894 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark28(-52.52477986362862 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark28(-52.558638452300954 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark28(-52.567841586907505 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark28(-52.59637993936561 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark28(-52.638559985414716 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark28(-5.267185464959994 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark28(-52.6894019568016 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark28(-52.740753062131375 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark28(-52.78430898440016 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark28(-52.812539846382855 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark28(-52.81327000613476 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark28(-52.85158345239831 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark28(-52.869011561654425 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark28(-52.87264094559032 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark28(-52.88412613400051 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark28(-52.900818186009026 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark28(-52.948716265704675 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark28(-52.985690841437204 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark28(-5.300609299043813 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark28(-53.024908625064725 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark28(-53.03271220376051 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark28(-53.03398409283773 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark28(-53.05950536146935 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark28(-53.17500363391907 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark28(-53.187183673878245 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark28(-53.24382208741631 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark28(-53.273848899784056 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark28(-53.282138306655845 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark28(-53.353632637551726 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark28(-53.39423765870856 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark28(-53.43062945063755 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark28(-53.43191362169672 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark28(-53.4555728848545 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark28(-53.474289553006216 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark28(-53.48070658243185 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark28(-53.515104331586194 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark28(-5.354499436529764 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark28(-53.55076157663701 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark28(-53.553833251692716 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark28(-53.64486396199142 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark28(-53.65757252487968 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark28(-5.371207916618374 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark28(-53.75191358605109 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark28(-53.77603279750931 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark28(-53.81068324632896 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark28(-53.837467714158294 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark28(-53.86819272206418 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark28(-53.886968162136164 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark28(-53.93496453951303 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark28(-53.94978729555919 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark28(-53.98630897714087 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark28(-54.01775444239394 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark28(-54.04543109434139 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark28(-54.04712876728324 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark28(-54.113533850440575 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark28(-54.13527548784809 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark28(-54.191769131581346 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark28(-54.249168890375145 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark28(-5.426166069382148 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark28(-54.33199898277952 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark28(-54.33958386577251 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark28(-54.358325403428644 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark28(-54.383332182132136 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark28(-5.438663664523773 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark28(-54.38976471739587 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark28(-54.39976558546522 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark28(-54.41222807801929 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark28(-54.41905232703499 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark28(-5.442340730074704 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark28(-54.429893419686096 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark28(-5.448785723875972 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark28(-54.62045008204477 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark28(-54.64376884147357 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark28(-54.66575200323087 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark28(-54.71774046408691 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark28(-54.73830183236461 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark28(-54.74474704036793 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark28(-54.75037319993636 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark28(-5.47667045961218 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark28(-54.777587875639135 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark28(-54.77902513877344 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark28(-54.78062662515091 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark28(-54.85229300754029 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark28(-54.85236599856045 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark28(-54.90382043384423 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark28(-5.490875504100941 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark28(-54.908870862693135 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark28(-54.91772839401685 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark28(-54.92592261603695 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark28(-54.933879862788594 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark28(-54.9718066162181 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark28(-54.98664905153581 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark28(-55.039314462677694 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark28(-55.0710063780816 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark28(-55.1761587642245 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark28(-55.190603356161574 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark28(-55.20139271909732 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark28(-55.25500134753125 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark28(-55.31787445022793 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark28(-55.3449928872956 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark28(-5.535819456285651 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark28(-55.3641174714937 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark28(-55.37606714131551 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark28(-55.381208141712705 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark28(-55.42882042768855 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark28(-55.441511504238235 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark28(-55.50604528666181 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark28(-55.56135168223386 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark28(-55.58018280384598 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark28(-55.581036185912794 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark28(-55.58842056209088 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark28(-55.60702243149591 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark28(-55.61436164609328 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark28(-5.562465259228901 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark28(-55.64504909941026 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark28(-55.66310441543227 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark28(-55.67525174716936 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark28(-55.71049094102569 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark28(-55.75821372968986 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark28(-55.79823657769325 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark28(-55.839077235968794 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark28(-55.85924749051316 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark28(-5.598886642446388 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark28(-56.02380997084326 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark28(-56.03015150064336 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark28(-56.035821745057014 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark28(-56.04983586322258 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark28(-56.05125780285461 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark28(-56.07960349641641 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark28(-56.113120032662 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark28(-56.13218933466288 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark28(-56.15966601507629 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark28(-56.18636944683813 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark28(-56.206757559696705 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark28(-56.22528944188605 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark28(-56.227086062143286 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark28(-56.250451172435945 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark28(-56.26652978484374 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark28(-56.26726999917744 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark28(-56.27876858292527 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark28(-56.28475167054914 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark28(-56.307683124486815 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark28(-56.32457312213739 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark28(-56.33734661892471 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark28(-56.35905596338559 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark28(-56.37267266662411 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark28(-56.38993334546161 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark28(-56.46115068117752 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark28(-56.47075250948226 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark28(-56.4752168333186 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark28(-56.50021419587075 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark28(-56.507688786154645 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark28(-56.64866573361906 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark28(-5.67215334297579 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark28(-5.6783767583255695 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark28(-56.86782965406869 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark28(-56.881965872568394 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark28(-5.6935697861019605 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark28(-56.98716882499131 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark28(-56.98968160091302 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark28(-57.03235677329723 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark28(-57.035270791257474 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark28(-57.03843570950087 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark28(-57.06978801121807 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark28(-57.09962994057356 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark28(-57.332030902825 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark28(-57.366028512794884 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark28(-57.39311548807555 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark28(-57.418087448017815 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark28(-57.438411791363976 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark28(-57.44203808501012 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark28(-57.47625409358417 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark28(-57.52042246088169 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark28(-57.59302986006154 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark28(-57.609228341628096 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark28(-57.62232961365523 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark28(-57.630877943709756 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark28(-57.65756884315421 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark28(-57.687875642693974 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark28(-57.72688345782051 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark28(-57.756701293846625 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark28(-57.76483772586547 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark28(-57.844856131666546 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark28(-57.88999450886898 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark28(-57.92214693102997 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark28(-57.985595758351 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark28(-5.798907890069344 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark28(-58.084033867048255 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark28(-58.088562544953184 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark28(-58.095207566968824 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark28(-58.118230576028026 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark28(-58.12286838643364 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark28(-58.18397265594963 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark28(-58.19376916782784 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark28(-58.253278363214456 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark28(-58.28487735774481 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark28(-58.32074124768787 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark28(-58.37418189559109 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark28(-58.463074809346494 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark28(-58.484165663345934 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark28(-58.531724979893895 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark28(-58.53767100920544 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark28(-58.57994921874467 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark28(-58.59519937266213 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark28(-58.612137522443874 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark28(-58.670687644952515 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark28(-58.68846870193132 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark28(-58.695537074207095 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark28(-58.73695006717301 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark28(-58.74659445376695 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark28(-58.77782031586855 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark28(-58.806845298297986 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark28(-58.85262747273066 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark28(-58.92404870541756 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark28(-58.96588988228957 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark28(-58.9803118122088 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark28(-5.898083537029876 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark28(-59.010169241596635 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark28(-59.067351963011916 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark28(-59.0694067666836 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark28(-59.248770839902434 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark28(-59.260945859665995 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark28(-59.27442862317829 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark28(-5.929920407070995 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark28(-59.330868507107425 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark28(-5.933090117424484 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark28(-59.42967712324789 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark28(-59.46819105386607 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark28(-59.4730769043162 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark28(-59.487451219366385 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark28(-59.49615305866423 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark28(-59.5421554470765 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark28(-59.556105868612995 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark28(-59.593933379299415 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark28(-59.62663710859599 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark28(-59.62891120242708 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark28(-59.64001683477169 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark28(-59.65295410057641 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark28(-5.969448509321836 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark28(-59.76342350553032 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark28(-59.794115576586336 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark28(-59.812835824835545 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark28(-5.983140634378572 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark28(-59.840044616431534 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark28(-5.985445931172009 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark28(-59.91268116221371 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark28(-59.91424849605978 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark28(-59.924273553380836 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark28(-59.98828094213222 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark28(-60.01751190410505 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark28(-60.032362077516254 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark28(-60.076167200541185 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark28(-60.17174937711462 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark28(-60.20784724831187 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark28(-60.23247129795195 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark28(-6.026479199218883 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark28(-60.269305355021615 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark28(-60.293941454154876 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark28(-60.32207568563137 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark28(-60.35784451539386 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark28(-6.038735045588808 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark28(-60.40736181187989 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark28(-6.041839416545173 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark28(-60.42734535974705 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark28(-60.44153825805007 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark28(-60.467956312178714 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark28(-60.469340960450914 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark28(-60.475456900688165 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark28(-60.49411318968294 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark28(-60.538528420200755 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark28(-60.54136860083468 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark28(-60.62601226744402 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark28(-60.62944722520922 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark28(-60.633233483308935 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark28(-60.647728985802885 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark28(-60.66801250553928 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark28(-60.66979362265392 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark28(-60.67741312901993 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark28(-60.70616054822715 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark28(-6.076507091787775 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark28(-60.831546465655116 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark28(-60.83744645455273 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark28(-60.8415231736962 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark28(-60.859839790007 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark28(-60.86296871471253 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark28(-60.864730343064785 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark28(-60.868745232558254 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark28(-60.933484079615674 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark28(-60.941946499860265 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark28(-60.989625473796075 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark28(-61.16881902309827 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark28(-61.17502987583245 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark28(-61.240340630821535 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark28(-6.130215689528313 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark28(-61.354197246889775 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark28(-61.39699518145625 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark28(-61.492418376117584 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark28(-61.50810445853578 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark28(-61.51253516103565 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark28(-61.52938801903443 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark28(-61.5566696720558 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark28(-61.57722839132613 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark28(-61.5813429026794 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark28(-61.5843488253977 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark28(-6.161429542598569 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark28(-61.615121095158145 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark28(-61.634849753889775 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark28(-61.65336917229334 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark28(-61.66521610254483 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark28(-61.698936496491676 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark28(-61.711811774316885 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark28(-61.73502225662067 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark28(-61.744401203357356 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark28(-61.77251344398667 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark28(-61.810948865422134 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark28(-61.87988941385398 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark28(-61.90343495084327 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark28(-61.90612917231757 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark28(-61.93158550915059 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark28(-62.01682688628396 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark28(-62.04632655999753 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark28(-62.070382017848935 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark28(-62.08037287903956 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark28(-62.08531194140103 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark28(-6.209738472479231 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark28(-62.11039264167286 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark28(-62.15577808516646 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark28(-62.164004220012316 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark28(-62.23303605776147 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark28(-62.26100608682516 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark28(-62.36118320861894 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark28(-62.401356717804404 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark28(-62.426865966979086 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark28(-6.254899934930577 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark28(-62.575161039255065 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark28(-62.578319923985816 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark28(-62.58620505731356 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark28(-62.59547504470013 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark28(-62.612195347410534 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark28(-62.62475564841268 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark28(-62.67009471275238 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark28(-6.2681819216170425 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark28(-6.284138710288275 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark28(-6.293267266963269 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark28(-62.93653540412725 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark28(-62.942368749108326 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark28(-62.9768526854114 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark28(-63.042875297793714 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark28(-63.058682430359745 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark28(-63.0677952975202 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark28(-63.07368084211753 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark28(-63.1267679316404 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark28(-6.323464974510088 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark28(-63.274145069503064 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark28(-63.31573182816732 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark28(-63.35768102225394 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark28(-63.3735577841773 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark28(-63.41149963782875 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark28(-63.50833982884132 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark28(-63.5099999373204 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark28(-63.520427988835614 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark28(-63.53369016727366 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark28(-63.545053305290764 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark28(-6.357059167354407 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark28(-63.59636812643477 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark28(-63.609650676451324 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark28(-63.64290994510604 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark28(-63.65808799335744 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark28(-63.67668509513944 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark28(-63.7223905268477 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark28(-63.76448328794331 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark28(-63.850713272772055 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark28(-63.86816383429732 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark28(-63.869891267217895 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark28(-63.93100172862691 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark28(-63.9347042588847 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark28(-63.9748693795271 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark28(-63.98924186573729 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark28(-64.01595594616691 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark28(-64.03756816522588 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark28(-64.1070139449513 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark28(-64.14956657617967 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark28(-64.15021255629281 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark28(-64.18816378268417 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark28(-64.19418117944338 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark28(-64.23448571874842 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark28(-64.25318907019579 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark28(-64.25806625591471 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark28(-64.32360290155887 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark28(-6.4353919287898975 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark28(-64.38659396616734 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark28(-64.39319361666756 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark28(-64.41124398266498 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark28(-64.4226676814036 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark28(-64.4502973442861 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark28(-6.452021373129014 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark28(-64.57344749635159 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark28(-64.61432515259364 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark28(-64.70459755113816 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark28(-64.72833190603012 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark28(-64.77994283525427 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark28(-6.479537670433459 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark28(-64.8183347819717 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark28(-64.82868271475596 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark28(-64.83769228908915 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark28(-64.92029710658909 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark28(-64.96936977315737 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark28(-6.496987846090562 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark28(-65.00680418883071 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark28(-65.04729964458699 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark28(-65.1183009888372 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark28(-65.14958131192725 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark28(-65.15603049382719 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark28(-65.19937878231309 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark28(-65.25188522969779 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark28(-65.25189109972143 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark28(-65.26364054269737 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark28(-65.28194109393948 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark28(-65.29004370627638 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark28(-65.3448108561492 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark28(-65.37867599339722 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark28(-65.3941157613238 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark28(-65.3954630820976 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark28(-65.40819927847235 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark28(-65.40840138738346 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark28(-65.4249901040123 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark28(-65.4366316845189 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark28(-65.46141408092782 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark28(-65.46402367869882 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark28(-65.4990232712686 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark28(-65.50823984979584 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark28(-65.54912674244645 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark28(-65.55650542884953 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark28(-65.6166312352766 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark28(-65.62710226941758 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark28(-6.564336249394543 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark28(-65.64403003379557 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark28(-65.64621429162972 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark28(-65.69035959947524 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark28(-65.69441367410528 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark28(-65.75500117789946 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark28(-65.75719682207182 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark28(-65.7575194716533 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark28(-65.89541711373903 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark28(-65.93422946260844 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark28(-65.97357497621951 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark28(-65.98861254178911 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark28(-66.03696565412312 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark28(-66.04927145856254 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark28(-66.06708731473461 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark28(-6.609518752447485 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark28(-66.11717297803672 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark28(-66.12752362016849 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark28(66.15430282595602 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark28(-66.15888972690642 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark28(-66.16872751811428 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark28(-66.198407681019 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark28(-66.2425745659022 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark28(-66.27919608877284 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark28(-6.63173676771504 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark28(-66.36258901584564 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark28(-66.39216665658168 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark28(-66.40257337547337 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark28(-66.50618982877236 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark28(-66.50869205071709 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark28(-66.52652112480922 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark28(-66.54865944845696 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark28(-66.59345463317099 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark28(-66.61103902366507 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark28(-66.67167308649917 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark28(-66.7003091564176 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark28(-66.7339679811011 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark28(-66.80575967956594 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark28(-66.83487516864753 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark28(-66.83879622770996 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark28(-6.684857531398578 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark28(-66.86002052771107 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark28(-66.89122792202069 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark28(-66.89149496245773 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark28(-66.97720777526636 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark28(-66.99589384718858 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark28(-6.700994574896853 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark28(-67.06086783521235 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark28(-67.07815279799811 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark28(-67.11428794896781 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark28(-6.713219929454169 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark28(-67.23789421299827 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark28(-67.29521400713539 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark28(-67.32142179095004 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark28(-6.734759257710053 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark28(-67.36950123388583 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark28(-67.37140161103237 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark28(-67.38664795501772 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark28(-67.4258666839107 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark28(-67.43617994723476 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark28(-67.45721029009832 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark28(-67.53892407678342 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark28(-67.54546683971361 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark28(-67.55459086458913 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark28(-67.66232706890906 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark28(-67.67144805678083 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark28(-67.70521211602511 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark28(-6.771114591401869 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark28(-67.714322883249 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark28(-67.71976778742801 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark28(-67.72566951600152 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark28(-67.7591739372384 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark28(-67.77998375720975 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark28(-67.78328415885473 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark28(-6.778844688227309 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark28(-6.7800344147051135 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark28(-67.83557009148129 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark28(-67.87043213861699 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark28(-67.8884119835192 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark28(-67.89384507890364 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark28(-67.90650727007107 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark28(-67.91420317817264 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark28(-67.92639690820934 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark28(-67.99912434640169 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark28(-68.00936347688025 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark28(-68.05981502548735 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark28(-68.10340316793034 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark28(-68.16817114892537 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark28(-68.20719427250386 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark28(-68.21746584579401 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark28(-68.23227194263424 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark28(-68.23918924839617 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark28(-68.28923896563876 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark28(-68.29307428462769 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark28(-68.30681640520882 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark28(-6.844462154498515 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark28(-68.45750766077019 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark28(-68.47405782928595 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark28(-6.860015213339921 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark28(-68.66228659149004 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark28(-68.72236655044506 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark28(-68.74196609106322 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark28(-68.80314553646956 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark28(-68.81039850311173 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark28(-68.82663838328871 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark28(-68.86261274452355 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark28(-69.02947734932776 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark28(-69.05990182102492 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark28(-6.910923564979441 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark28(-69.14216411059498 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark28(-69.20558103763793 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark28(-69.21279455098971 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark28(-6.922057255715245 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark28(-69.2231056056962 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark28(-69.27145806863489 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark28(-69.29045600994903 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark28(-69.31885552144522 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark28(-69.33597805724183 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark28(-69.37077508000837 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark28(-69.37450293892866 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark28(-69.38454298003796 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark28(-69.41071750904382 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark28(-69.4121837297843 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark28(-69.42980552373504 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark28(-69.44088194084246 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark28(-69.46041940157856 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark28(-6.957578003519174 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark28(-69.6246978079746 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark28(-69.66742219387581 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark28(-69.68750773687707 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark28(-69.69856098721453 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark28(-69.77998776953538 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark28(-69.80322295022316 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark28(-69.81205687017359 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark28(-69.84758609830813 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark28(-69.90653480788404 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark28(-69.94562714040731 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark28(-69.97344172215243 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark28(-70.00246472956707 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark28(-70.027719770136 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark28(-70.24685306439704 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark28(-70.26431060155977 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark28(-70.31641254435127 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark28(-70.33962647643084 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark28(-70.34669115894734 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark28(-70.35499146595328 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark28(-70.43285697869639 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark28(-70.48555093343899 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark28(-70.50677144085095 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark28(-7.0576868361511345 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark28(-70.64385495632904 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark28(-70.72351164887012 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark28(-70.7333139892514 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark28(-70.74738170868153 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark28(-70.86046352714149 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark28(-70.87053348689281 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark28(-70.88159979720179 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark28(-70.90197220174075 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark28(-70.95827749340995 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark28(-70.96882866837876 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark28(-70.97774762611434 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark28(-71.02957477861747 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark28(-7.10387422197887 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark28(-71.05824391576516 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark28(-71.06520382949715 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark28(-7.107239424230755 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark28(-71.10260655339164 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark28(-71.10534339953685 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark28(-71.18030234312937 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark28(-71.18345452387183 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark28(-71.23978327477153 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark28(-71.26660649537114 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark28(-71.2743760870205 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark28(-71.27569450319234 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark28(-7.140510429519082 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark28(-7.141022461866029 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark28(-71.44545481899085 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark28(-71.55460480925073 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark28(-71.6048363124089 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark28(-71.61492543493478 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark28(-71.66308250653277 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark28(-71.67395992599161 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark28(-71.67593889097196 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark28(-71.70082307926747 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark28(-71.70581880907667 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark28(-71.71236473287783 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark28(-71.78844034647129 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark28(-71.8038749449631 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark28(-71.84106037742126 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark28(-71.90146583958281 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark28(-71.91788533642031 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark28(-71.92641359046902 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark28(-71.98854022201735 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark28(-71.99097470229923 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark28(-72.02018639863046 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark28(-72.04181824178444 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark28(-72.09379394640926 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark28(-72.10147762080383 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark28(-72.12393120687786 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark28(-72.13482445087965 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark28(-72.14335961446318 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark28(-72.20100065325725 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark28(-72.20828067122822 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark28(-7.227166097765263 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark28(-72.36314434417307 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark28(-72.37094383009743 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark28(-72.39042733780124 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark28(-72.48220032823033 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark28(-72.49391077837245 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark28(-72.53179059186166 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark28(-72.55618961655483 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark28(-72.61741587000692 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark28(-72.66511455132616 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark28(-72.6910850585117 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark28(-72.72854777259957 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark28(-72.75830923027036 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark28(-72.79825575333535 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark28(-72.80724541899414 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark28(-72.81867196820922 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark28(-7.285300652821675 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark28(-72.8874675293819 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark28(-72.90650619766883 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark28(-72.9636263800412 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark28(-72.98896999571289 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark28(-72.99561263404345 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark28(-72.99832193900882 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark28(-73.02064581803715 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark28(-73.02524591958817 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark28(-73.0865953999161 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark28(-73.11795236069932 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark28(-73.13634145586786 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark28(-73.17995314526122 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark28(-73.18671710092738 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark28(-73.21687102609636 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark28(-73.22914168798198 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark28(-73.3085596152883 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark28(-73.42965043105774 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark28(-73.44038880105468 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark28(-73.46836115820199 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark28(-73.47155370619609 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark28(-73.4993921385863 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark28(-73.50782103912503 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark28(-73.5386274433831 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark28(-73.60038512824043 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark28(-73.65252996234906 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark28(-73.6722510496464 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark28(-73.74442734427802 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark28(-73.80095580066445 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark28(-73.80159507361753 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark28(-7.3831520411095966 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark28(-73.88250816560864 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark28(-73.88286488007873 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark28(-73.90688308437797 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark28(-73.92252750675104 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark28(-73.93064545031041 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark28(-73.94186871072124 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark28(-7.398076653035801 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark28(-74.06932305154058 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark28(-74.09613002698 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark28(-74.11003265826197 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark28(-74.1291856549143 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark28(-7.41629713285208 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark28(-74.1939649081285 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark28(-74.216787281337 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark28(-74.23214443887875 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark28(-7.423833766651924 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark28(-74.26565604422841 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark28(-74.2805618867459 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark28(-74.36297103993823 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark28(-74.40932091160005 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark28(-74.44019960216255 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark28(-74.52013659578216 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark28(-74.52239752825008 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark28(-74.53448194006356 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark28(-74.55025903676231 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark28(-74.57127999209807 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark28(-74.58474796692713 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark28(-74.61995209562303 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark28(-74.62201464002038 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark28(-74.66031238053985 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark28(-74.73788602921012 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark28(-7.474659553876492 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark28(-74.77840380031704 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark28(-74.80019968707354 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark28(-74.81070885266901 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark28(-74.83572109939121 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark28(-74.86735615929796 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark28(-74.88970132590123 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark28(-74.9045749705757 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark28(-74.96803279478817 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark28(-74.98910976793928 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark28(-74.99960675128077 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark28(-7.500862706052416 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark28(-75.03769384384229 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark28(-75.0777954140961 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark28(-75.08259195127482 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark28(-75.19068657917629 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark28(-75.23223720815659 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark28(-75.29232145715648 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark28(-75.29955073799147 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark28(-75.33633540264057 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark28(-75.37681654463992 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark28(-75.3863736156772 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark28(-75.43054120892378 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark28(-75.4850734388218 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark28(-75.50187685188487 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark28(-75.52117595908928 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark28(-75.52516409639071 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark28(-75.55640966783348 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark28(-75.56273887882598 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark28(-75.6083899127755 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark28(-75.65137642649695 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark28(-75.65483525143073 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark28(-75.66258935089671 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark28(-7.570198966986382 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark28(-75.72901872389288 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark28(-75.7661030690139 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark28(-75.80164096503547 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark28(-75.81116527579583 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark28(-75.84572822129158 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark28(-75.85870310620042 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark28(-75.90342147974347 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark28(-75.93150734253031 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark28(-75.94430825900984 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark28(-75.97385808336037 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark28(-76.0205925528812 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark28(-76.04233563250517 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark28(-76.05250856219891 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark28(-76.07579835121972 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark28(-76.14988975400647 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark28(-76.21758119714038 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark28(-7.626140502751525 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark28(-76.26423234365316 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark28(-76.36238279286437 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark28(-76.36667308705634 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark28(-76.41827089704252 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark28(-76.54396183473722 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark28(-76.55046173143933 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark28(-76.56256814031826 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark28(-76.57988271550468 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark28(-76.60736402577194 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark28(-76.63611070681881 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark28(-7.6679743177210185 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark28(-76.6896748856762 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark28(-76.7153434610676 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark28(-76.7286859718596 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark28(-76.7862425124832 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark28(-76.78786434069468 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark28(-76.91937316153013 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark28(-76.95657783330586 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark28(-77.0060456824246 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark28(-77.05125539906261 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark28(-77.06307056326811 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark28(-77.09078359269085 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark28(-77.10080986022454 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark28(-7.71241181593345 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark28(-77.12466005191112 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark28(-77.16197230988493 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark28(-7.725315589803941 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark28(-77.30672324383418 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark28(-77.32731768133678 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark28(-77.35567512711464 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark28(-77.40331402733334 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark28(-77.42138475134004 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark28(-77.44080592194318 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark28(-7.745842544734913 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark28(-77.46100323341219 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark28(-77.49935972422371 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark28(-77.53873423031652 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark28(-77.64703537594819 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark28(-77.65006565321337 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark28(-77.6881111647424 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark28(-77.70388231779106 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark28(-77.72327472743368 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark28(-7.778183336315124 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark28(-77.86171708958467 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark28(-77.90111174428864 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark28(-77.95024308470724 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark28(-77.97666437150852 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark28(-78.0007738388945 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark28(-78.0306916288172 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark28(-78.07523144189766 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark28(-78.10077835474388 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark28(-78.1099298930913 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark28(-78.12529373269533 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark28(-78.13890566809397 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark28(-7.815381744777696 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark28(-78.21233644709304 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark28(-78.22334691735043 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark28(-78.33170967856248 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark28(-78.35826655944989 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark28(-78.47779371518398 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark28(-78.49829698184159 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark28(-7.8515041499654075 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark28(-78.53932344709544 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark28(-78.55181759293717 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark28(-78.56936708076516 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark28(-78.58672033361391 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark28(-78.63143884849819 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark28(-78.64578475505586 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark28(-78.6527373958634 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark28(-78.72603049341825 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark28(-78.75958618751709 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark28(-78.76196006708125 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark28(-78.76661536752286 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark28(-78.77605131045307 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark28(-78.81786049525874 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark28(-78.84384173706376 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark28(-78.84528144422929 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark28(-78.84939522532548 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark28(-78.9263267077168 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark28(-78.92934733838722 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark28(-78.94844695765606 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark28(-78.9530699421492 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark28(-78.96391571559553 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark28(-79.05329634023133 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark28(-79.0912194939965 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark28(-79.09764878331487 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark28(-79.17808438218003 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark28(-79.19656409496365 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark28(-79.23381560939289 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark28(-79.28705575650577 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark28(-79.32983853785858 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark28(-79.38108211925127 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark28(-79.46971962500857 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark28(-79.59391628227088 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark28(-79.6006540962299 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark28(-79.62582611709472 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark28(-7.97139300741398 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark28(-79.74558200892703 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark28(-79.79407981807273 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark28(-79.79526189034544 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark28(-79.82192943196857 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark28(-7.98258375595185 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark28(-79.88032711176676 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark28(-79.93194891146824 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark28(-79.9512804250935 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark28(-79.95412654792841 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark28(-80.0633929960039 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark28(-80.07117475355548 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark28(-80.090295960574 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark28(-80.10059190119878 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark28(-80.13639182743432 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark28(-80.14189074787691 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark28(-80.20970551807227 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark28(-80.22019521513377 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark28(-80.26327626498677 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark28(-80.27964849422847 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark28(-80.2905522573777 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark28(-80.29175375022793 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark28(-80.3107625787799 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark28(-8.038659053112667 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark28(-80.40622250453897 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark28(-8.04437187801416 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark28(-80.48109688655738 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark28(-80.57619557286857 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark28(-80.6013327277737 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark28(-80.71412658607919 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark28(-80.71748348766286 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark28(-80.72291807332645 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark28(-80.73695086464001 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark28(-80.75105736899565 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark28(-80.87892891110059 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark28(-80.88714608064521 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark28(-80.91433045823864 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark28(-80.98146077643221 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark28(-81.0078416820883 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark28(-81.02576512546818 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark28(-81.14555092184877 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark28(-81.15746531268817 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark28(-81.16624590954642 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark28(-81.16996562401613 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark28(-81.19094663127086 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark28(-81.19651091532316 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark28(-81.24418847338583 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark28(-81.32775350828996 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark28(-81.33869643099948 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark28(-81.3548650551694 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark28(-8.140853995251888 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark28(-81.43678178554214 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark28(-81.44236015990538 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark28(-8.145946435188705 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark28(-81.46635145740703 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark28(-81.4679220063386 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark28(-81.50190698864783 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark28(-81.53452192076557 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark28(-81.56464098939635 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark28(-81.59970008530789 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark28(-81.65346758154209 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark28(-81.65569241663968 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark28(-81.66332979468763 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark28(-81.67058879284185 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark28(-81.67612137941728 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark28(-81.75939403475176 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark28(-81.77988089056674 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark28(-8.17907526900376 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark28(-81.80271551484304 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark28(-81.81585993079673 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark28(-81.81757315726308 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark28(-81.82663512857255 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark28(-81.84406176174839 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark28(-8.184594397358964 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark28(-81.88499011880366 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark28(-81.94834713571373 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark28(-82.01481170245452 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark28(-82.02741161550651 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark28(-82.029688374063 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark28(-82.0463832171037 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark28(-82.08236978419028 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark28(-82.08334243930004 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark28(-82.0988002680748 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark28(-82.1848272721742 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark28(-82.21828404600815 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark28(-82.24669993712325 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark28(-82.25015305703226 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark28(-82.2640799166003 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark28(-82.28684578269723 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark28(-8.229923987603868 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark28(-82.30268659172226 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark28(-8.230571332474398 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark28(-82.30621015488461 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark28(-82.30726690844479 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark28(-82.31424482517573 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark28(-82.31477611355433 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark28(-82.39586029024511 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark28(-82.48528831136552 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark28(-82.51814043515839 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark28(-82.605485055889 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark28(-82.605526460532 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark28(-82.66866485214577 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark28(-82.7340005021285 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark28(-82.79622760718146 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark28(-82.79881825367046 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark28(-82.80135779159576 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark28(-82.83740627331787 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark28(-82.87493372326458 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark28(-82.91585622978563 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark28(-82.91591485291032 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark28(-8.302153624506431 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark28(-83.0613067743995 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark28(-83.08003633629906 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark28(-83.12677267919004 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark28(-83.12893581979259 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark28(-83.17540483641213 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark28(-83.17928124468756 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark28(-83.19603235795223 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark28(-8.322924369739752 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark28(-83.25264293110111 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark28(-83.34096626231708 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark28(-83.37652588968795 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark28(-83.4345578577304 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark28(-83.44831694499197 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark28(-83.5354559981462 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark28(-83.53719130473216 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark28(-83.60322749019322 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark28(-83.62516134691371 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark28(-8.364655140388848 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark28(-83.67260922346394 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark28(-83.68517867079868 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark28(-8.370458657563631 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark28(-83.72180926910475 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark28(-83.78258558080391 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark28(-83.80624556263412 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark28(-83.87132619580893 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark28(-83.87457035169199 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark28(-83.88568765069178 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark28(-83.90927492071434 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark28(-83.9482315104531 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark28(-83.95793572752888 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark28(-84.01378176432685 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark28(-84.04278930137585 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark28(-84.06378122582407 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark28(-84.11327873968119 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark28(-84.12890663897122 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark28(-84.12998720415435 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark28(-84.13856526854985 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark28(-84.14933352661755 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark28(-84.15238201634168 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark28(-84.17774051558445 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark28(-8.42143286191643 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark28(-84.23123598513376 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark28(-84.24700716782894 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark28(-84.32256500694453 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark28(-84.35152849347882 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark28(-84.37129858998469 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark28(-84.4011028568022 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark28(-84.42838249589946 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark28(-84.44448328645495 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark28(-8.45165354571651 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark28(-84.51945505562146 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark28(-84.52991629314847 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark28(-84.58199101425868 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark28(-84.64161709087814 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark28(-84.64848035532391 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark28(-8.466976381152122 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark28(-84.7026049786153 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark28(-84.84247903208183 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark28(-84.89441209102574 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark28(-84.92465179325932 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark28(-84.9448625531819 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark28(-84.954755270924 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark28(-84.9722001223965 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark28(-84.97630846918669 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark28(-84.98361915372266 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark28(-85.01345333636408 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark28(-85.03126224725423 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark28(-85.06028182413483 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark28(-8.516329057900677 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark28(-85.21087919137182 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark28(-85.22100077410168 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark28(-85.25175317822853 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark28(-85.27133506530313 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark28(-85.32410854667076 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark28(-85.39356941488465 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark28(-85.39364247903268 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark28(-85.4470122363445 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark28(-85.47059531119567 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark28(-85.5082223530959 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark28(-85.52861712996591 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark28(-85.55196776936151 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark28(-85.55897290557375 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark28(-85.60214805180146 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark28(-85.60933344608203 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark28(-85.61441885665562 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark28(-85.61555973079047 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark28(-85.61658241057745 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark28(-85.63487768470574 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark28(-85.67007716264867 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark28(-85.67280399081278 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark28(-85.68152566652111 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark28(-8.568156620536541 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark28(-85.7430397864215 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark28(-85.76628251808462 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark28(-85.77331708343775 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark28(-85.80740659977965 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark28(-85.82764326109135 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark28(-85.82792399817585 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark28(-85.85338886638564 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark28(-85.86781976537492 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark28(-85.89025535446508 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark28(-85.89191049864809 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark28(-85.9229482657854 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark28(-85.94760174821812 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark28(-85.9630515948012 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark28(-85.97291563209018 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark28(-8.602187467031229 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark28(-86.09787031367608 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark28(-86.13240516253705 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark28(-86.13861557576345 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark28(-86.18322640490477 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark28(-86.18830512874156 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark28(-86.20425076395257 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark28(-86.24423606635338 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark28(-8.62690861053052 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark28(-8.631607866402163 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark28(-86.43022565142088 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark28(-86.43181141794116 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark28(-86.45871715916529 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark28(-86.47573894952896 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark28(-86.57346056571976 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark28(-86.58599868787734 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark28(-86.70391713828175 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark28(-86.7086213715627 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark28(-86.73234237607784 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark28(-86.73640141069363 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark28(-86.74055024195835 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark28(-86.76311658408676 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark28(-86.77084839774538 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark28(-86.78667348552555 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark28(-86.80896107270561 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark28(-86.81324412837694 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark28(-86.83448396516688 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark28(-86.85025620655773 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark28(-86.89934388406644 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark28(-86.9187841491639 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark28(-86.92888321618977 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark28(-8.692914257038638 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark28(-86.93862484747592 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark28(-86.98275705514185 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark28(-86.99792429673808 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark28(-87.16924986619443 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark28(-87.18508280805639 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark28(-87.19994701788683 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark28(-87.31377069682382 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark28(-87.40670808518898 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark28(-87.46416293120336 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark28(-8.749491967872558 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark28(-87.5174188145313 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark28(-87.52615689431526 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark28(-87.56443688467577 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark28(-87.58667169284551 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark28(-87.59040127928357 ) ;
  }

  @Test
  public void test2476() {
    coral.tests.JPFBenchmark.benchmark28(-87.61169483817778 ) ;
  }

  @Test
  public void test2477() {
    coral.tests.JPFBenchmark.benchmark28(-87.68274073123044 ) ;
  }

  @Test
  public void test2478() {
    coral.tests.JPFBenchmark.benchmark28(-87.70651958701967 ) ;
  }

  @Test
  public void test2479() {
    coral.tests.JPFBenchmark.benchmark28(-8.77134003626199 ) ;
  }

  @Test
  public void test2480() {
    coral.tests.JPFBenchmark.benchmark28(-87.76226032439828 ) ;
  }

  @Test
  public void test2481() {
    coral.tests.JPFBenchmark.benchmark28(-87.79173651813686 ) ;
  }

  @Test
  public void test2482() {
    coral.tests.JPFBenchmark.benchmark28(-87.80812699992258 ) ;
  }

  @Test
  public void test2483() {
    coral.tests.JPFBenchmark.benchmark28(-87.82053245977235 ) ;
  }

  @Test
  public void test2484() {
    coral.tests.JPFBenchmark.benchmark28(-87.82143996395968 ) ;
  }

  @Test
  public void test2485() {
    coral.tests.JPFBenchmark.benchmark28(-87.86280799906403 ) ;
  }

  @Test
  public void test2486() {
    coral.tests.JPFBenchmark.benchmark28(-87.86654778464668 ) ;
  }

  @Test
  public void test2487() {
    coral.tests.JPFBenchmark.benchmark28(-87.90935166319372 ) ;
  }

  @Test
  public void test2488() {
    coral.tests.JPFBenchmark.benchmark28(-87.93610278113455 ) ;
  }

  @Test
  public void test2489() {
    coral.tests.JPFBenchmark.benchmark28(-87.95508711166372 ) ;
  }

  @Test
  public void test2490() {
    coral.tests.JPFBenchmark.benchmark28(-88.04687390080036 ) ;
  }

  @Test
  public void test2491() {
    coral.tests.JPFBenchmark.benchmark28(-88.06545106605579 ) ;
  }

  @Test
  public void test2492() {
    coral.tests.JPFBenchmark.benchmark28(-88.10306058854044 ) ;
  }

  @Test
  public void test2493() {
    coral.tests.JPFBenchmark.benchmark28(-88.1829092884334 ) ;
  }

  @Test
  public void test2494() {
    coral.tests.JPFBenchmark.benchmark28(-88.21630733277377 ) ;
  }

  @Test
  public void test2495() {
    coral.tests.JPFBenchmark.benchmark28(-88.2488912989163 ) ;
  }

  @Test
  public void test2496() {
    coral.tests.JPFBenchmark.benchmark28(-88.27838339927403 ) ;
  }

  @Test
  public void test2497() {
    coral.tests.JPFBenchmark.benchmark28(-88.36391322199997 ) ;
  }

  @Test
  public void test2498() {
    coral.tests.JPFBenchmark.benchmark28(-88.37972424645584 ) ;
  }

  @Test
  public void test2499() {
    coral.tests.JPFBenchmark.benchmark28(-88.46110288724624 ) ;
  }

  @Test
  public void test2500() {
    coral.tests.JPFBenchmark.benchmark28(-88.48865785453191 ) ;
  }

  @Test
  public void test2501() {
    coral.tests.JPFBenchmark.benchmark28(-88.60814524963934 ) ;
  }

  @Test
  public void test2502() {
    coral.tests.JPFBenchmark.benchmark28(-8.861049783583553 ) ;
  }

  @Test
  public void test2503() {
    coral.tests.JPFBenchmark.benchmark28(-88.61706854797073 ) ;
  }

  @Test
  public void test2504() {
    coral.tests.JPFBenchmark.benchmark28(-88.61930523169895 ) ;
  }

  @Test
  public void test2505() {
    coral.tests.JPFBenchmark.benchmark28(-88.67523975227772 ) ;
  }

  @Test
  public void test2506() {
    coral.tests.JPFBenchmark.benchmark28(-8.86760237638049 ) ;
  }

  @Test
  public void test2507() {
    coral.tests.JPFBenchmark.benchmark28(-8.86895456909322 ) ;
  }

  @Test
  public void test2508() {
    coral.tests.JPFBenchmark.benchmark28(-88.78831367852464 ) ;
  }

  @Test
  public void test2509() {
    coral.tests.JPFBenchmark.benchmark28(-88.79397539143467 ) ;
  }

  @Test
  public void test2510() {
    coral.tests.JPFBenchmark.benchmark28(-88.8124675081702 ) ;
  }

  @Test
  public void test2511() {
    coral.tests.JPFBenchmark.benchmark28(-88.84508100805999 ) ;
  }

  @Test
  public void test2512() {
    coral.tests.JPFBenchmark.benchmark28(-8.887277923260271 ) ;
  }

  @Test
  public void test2513() {
    coral.tests.JPFBenchmark.benchmark28(-88.88335844683209 ) ;
  }

  @Test
  public void test2514() {
    coral.tests.JPFBenchmark.benchmark28(-88.93991620524748 ) ;
  }

  @Test
  public void test2515() {
    coral.tests.JPFBenchmark.benchmark28(-89.02851434704975 ) ;
  }

  @Test
  public void test2516() {
    coral.tests.JPFBenchmark.benchmark28(-89.13113477130625 ) ;
  }

  @Test
  public void test2517() {
    coral.tests.JPFBenchmark.benchmark28(-89.14435161855963 ) ;
  }

  @Test
  public void test2518() {
    coral.tests.JPFBenchmark.benchmark28(-89.15107405283086 ) ;
  }

  @Test
  public void test2519() {
    coral.tests.JPFBenchmark.benchmark28(-89.17660506915087 ) ;
  }

  @Test
  public void test2520() {
    coral.tests.JPFBenchmark.benchmark28(-89.19601936493255 ) ;
  }

  @Test
  public void test2521() {
    coral.tests.JPFBenchmark.benchmark28(-89.2232053083085 ) ;
  }

  @Test
  public void test2522() {
    coral.tests.JPFBenchmark.benchmark28(-89.22496131583091 ) ;
  }

  @Test
  public void test2523() {
    coral.tests.JPFBenchmark.benchmark28(-89.22518099015369 ) ;
  }

  @Test
  public void test2524() {
    coral.tests.JPFBenchmark.benchmark28(-8.923246833909104 ) ;
  }

  @Test
  public void test2525() {
    coral.tests.JPFBenchmark.benchmark28(-8.925318080149978 ) ;
  }

  @Test
  public void test2526() {
    coral.tests.JPFBenchmark.benchmark28(-89.28727872642774 ) ;
  }

  @Test
  public void test2527() {
    coral.tests.JPFBenchmark.benchmark28(-89.30398952135994 ) ;
  }

  @Test
  public void test2528() {
    coral.tests.JPFBenchmark.benchmark28(-89.31318730373903 ) ;
  }

  @Test
  public void test2529() {
    coral.tests.JPFBenchmark.benchmark28(-89.32411738614208 ) ;
  }

  @Test
  public void test2530() {
    coral.tests.JPFBenchmark.benchmark28(-89.33085956521325 ) ;
  }

  @Test
  public void test2531() {
    coral.tests.JPFBenchmark.benchmark28(-89.36575524197596 ) ;
  }

  @Test
  public void test2532() {
    coral.tests.JPFBenchmark.benchmark28(-89.40792036589285 ) ;
  }

  @Test
  public void test2533() {
    coral.tests.JPFBenchmark.benchmark28(-89.49294352020851 ) ;
  }

  @Test
  public void test2534() {
    coral.tests.JPFBenchmark.benchmark28(-89.53078623400602 ) ;
  }

  @Test
  public void test2535() {
    coral.tests.JPFBenchmark.benchmark28(-89.54834991297507 ) ;
  }

  @Test
  public void test2536() {
    coral.tests.JPFBenchmark.benchmark28(-89.5709191142955 ) ;
  }

  @Test
  public void test2537() {
    coral.tests.JPFBenchmark.benchmark28(-8.95931281192037 ) ;
  }

  @Test
  public void test2538() {
    coral.tests.JPFBenchmark.benchmark28(-89.622280888152 ) ;
  }

  @Test
  public void test2539() {
    coral.tests.JPFBenchmark.benchmark28(-89.67425408153935 ) ;
  }

  @Test
  public void test2540() {
    coral.tests.JPFBenchmark.benchmark28(-89.68114568431955 ) ;
  }

  @Test
  public void test2541() {
    coral.tests.JPFBenchmark.benchmark28(-89.72406252669938 ) ;
  }

  @Test
  public void test2542() {
    coral.tests.JPFBenchmark.benchmark28(-89.73269319931529 ) ;
  }

  @Test
  public void test2543() {
    coral.tests.JPFBenchmark.benchmark28(-89.75993846957584 ) ;
  }

  @Test
  public void test2544() {
    coral.tests.JPFBenchmark.benchmark28(-89.8739483039732 ) ;
  }

  @Test
  public void test2545() {
    coral.tests.JPFBenchmark.benchmark28(-89.88062957760923 ) ;
  }

  @Test
  public void test2546() {
    coral.tests.JPFBenchmark.benchmark28(-89.89861481744708 ) ;
  }

  @Test
  public void test2547() {
    coral.tests.JPFBenchmark.benchmark28(-89.89957786072284 ) ;
  }

  @Test
  public void test2548() {
    coral.tests.JPFBenchmark.benchmark28(-89.90430334206177 ) ;
  }

  @Test
  public void test2549() {
    coral.tests.JPFBenchmark.benchmark28(-89.94921234430035 ) ;
  }

  @Test
  public void test2550() {
    coral.tests.JPFBenchmark.benchmark28(-89.99383309259895 ) ;
  }

  @Test
  public void test2551() {
    coral.tests.JPFBenchmark.benchmark28(-89.99433536364415 ) ;
  }

  @Test
  public void test2552() {
    coral.tests.JPFBenchmark.benchmark28(-90.01064206804712 ) ;
  }

  @Test
  public void test2553() {
    coral.tests.JPFBenchmark.benchmark28(-90.04528237905807 ) ;
  }

  @Test
  public void test2554() {
    coral.tests.JPFBenchmark.benchmark28(-90.04659880010627 ) ;
  }

  @Test
  public void test2555() {
    coral.tests.JPFBenchmark.benchmark28(-90.06850929668812 ) ;
  }

  @Test
  public void test2556() {
    coral.tests.JPFBenchmark.benchmark28(-90.07336149521153 ) ;
  }

  @Test
  public void test2557() {
    coral.tests.JPFBenchmark.benchmark28(-90.11644385775533 ) ;
  }

  @Test
  public void test2558() {
    coral.tests.JPFBenchmark.benchmark28(-90.12233933993643 ) ;
  }

  @Test
  public void test2559() {
    coral.tests.JPFBenchmark.benchmark28(-90.13415812942125 ) ;
  }

  @Test
  public void test2560() {
    coral.tests.JPFBenchmark.benchmark28(-90.20593248341315 ) ;
  }

  @Test
  public void test2561() {
    coral.tests.JPFBenchmark.benchmark28(-9.022326950497302 ) ;
  }

  @Test
  public void test2562() {
    coral.tests.JPFBenchmark.benchmark28(-90.26238626416153 ) ;
  }

  @Test
  public void test2563() {
    coral.tests.JPFBenchmark.benchmark28(-90.26241650153165 ) ;
  }

  @Test
  public void test2564() {
    coral.tests.JPFBenchmark.benchmark28(-90.29241984919574 ) ;
  }

  @Test
  public void test2565() {
    coral.tests.JPFBenchmark.benchmark28(-9.030959888566727 ) ;
  }

  @Test
  public void test2566() {
    coral.tests.JPFBenchmark.benchmark28(-90.32263747289373 ) ;
  }

  @Test
  public void test2567() {
    coral.tests.JPFBenchmark.benchmark28(-90.32773206978138 ) ;
  }

  @Test
  public void test2568() {
    coral.tests.JPFBenchmark.benchmark28(-90.37828143385644 ) ;
  }

  @Test
  public void test2569() {
    coral.tests.JPFBenchmark.benchmark28(-90.3923153951551 ) ;
  }

  @Test
  public void test2570() {
    coral.tests.JPFBenchmark.benchmark28(-9.040461129238679 ) ;
  }

  @Test
  public void test2571() {
    coral.tests.JPFBenchmark.benchmark28(-90.41661885627474 ) ;
  }

  @Test
  public void test2572() {
    coral.tests.JPFBenchmark.benchmark28(-90.43129305656797 ) ;
  }

  @Test
  public void test2573() {
    coral.tests.JPFBenchmark.benchmark28(-90.50060754636411 ) ;
  }

  @Test
  public void test2574() {
    coral.tests.JPFBenchmark.benchmark28(-90.54614482373493 ) ;
  }

  @Test
  public void test2575() {
    coral.tests.JPFBenchmark.benchmark28(-90.57724089126127 ) ;
  }

  @Test
  public void test2576() {
    coral.tests.JPFBenchmark.benchmark28(-90.628837945228 ) ;
  }

  @Test
  public void test2577() {
    coral.tests.JPFBenchmark.benchmark28(-90.63751158688899 ) ;
  }

  @Test
  public void test2578() {
    coral.tests.JPFBenchmark.benchmark28(-90.65466873519854 ) ;
  }

  @Test
  public void test2579() {
    coral.tests.JPFBenchmark.benchmark28(-90.65940841882639 ) ;
  }

  @Test
  public void test2580() {
    coral.tests.JPFBenchmark.benchmark28(-90.73907263084338 ) ;
  }

  @Test
  public void test2581() {
    coral.tests.JPFBenchmark.benchmark28(-90.78657710921189 ) ;
  }

  @Test
  public void test2582() {
    coral.tests.JPFBenchmark.benchmark28(-90.78946262865838 ) ;
  }

  @Test
  public void test2583() {
    coral.tests.JPFBenchmark.benchmark28(-90.79009689758803 ) ;
  }

  @Test
  public void test2584() {
    coral.tests.JPFBenchmark.benchmark28(-90.83562282311215 ) ;
  }

  @Test
  public void test2585() {
    coral.tests.JPFBenchmark.benchmark28(-90.8493594127305 ) ;
  }

  @Test
  public void test2586() {
    coral.tests.JPFBenchmark.benchmark28(-90.86552069080294 ) ;
  }

  @Test
  public void test2587() {
    coral.tests.JPFBenchmark.benchmark28(-90.9501196449245 ) ;
  }

  @Test
  public void test2588() {
    coral.tests.JPFBenchmark.benchmark28(-91.05562531161979 ) ;
  }

  @Test
  public void test2589() {
    coral.tests.JPFBenchmark.benchmark28(-91.06083588163041 ) ;
  }

  @Test
  public void test2590() {
    coral.tests.JPFBenchmark.benchmark28(-91.07757933893402 ) ;
  }

  @Test
  public void test2591() {
    coral.tests.JPFBenchmark.benchmark28(-91.12582093320776 ) ;
  }

  @Test
  public void test2592() {
    coral.tests.JPFBenchmark.benchmark28(-91.14278995921883 ) ;
  }

  @Test
  public void test2593() {
    coral.tests.JPFBenchmark.benchmark28(-91.21371384967951 ) ;
  }

  @Test
  public void test2594() {
    coral.tests.JPFBenchmark.benchmark28(-91.21871451489551 ) ;
  }

  @Test
  public void test2595() {
    coral.tests.JPFBenchmark.benchmark28(-91.27923002147924 ) ;
  }

  @Test
  public void test2596() {
    coral.tests.JPFBenchmark.benchmark28(-91.3795015350378 ) ;
  }

  @Test
  public void test2597() {
    coral.tests.JPFBenchmark.benchmark28(-91.40809800179441 ) ;
  }

  @Test
  public void test2598() {
    coral.tests.JPFBenchmark.benchmark28(-91.46288688533421 ) ;
  }

  @Test
  public void test2599() {
    coral.tests.JPFBenchmark.benchmark28(-91.5090014927595 ) ;
  }

  @Test
  public void test2600() {
    coral.tests.JPFBenchmark.benchmark28(-91.51500736525291 ) ;
  }

  @Test
  public void test2601() {
    coral.tests.JPFBenchmark.benchmark28(-91.53410706707233 ) ;
  }

  @Test
  public void test2602() {
    coral.tests.JPFBenchmark.benchmark28(-91.62133672356556 ) ;
  }

  @Test
  public void test2603() {
    coral.tests.JPFBenchmark.benchmark28(-91.69825087018468 ) ;
  }

  @Test
  public void test2604() {
    coral.tests.JPFBenchmark.benchmark28(-91.7621266783527 ) ;
  }

  @Test
  public void test2605() {
    coral.tests.JPFBenchmark.benchmark28(-91.77411824780175 ) ;
  }

  @Test
  public void test2606() {
    coral.tests.JPFBenchmark.benchmark28(-91.77863945980923 ) ;
  }

  @Test
  public void test2607() {
    coral.tests.JPFBenchmark.benchmark28(-9.188416481009426 ) ;
  }

  @Test
  public void test2608() {
    coral.tests.JPFBenchmark.benchmark28(-91.90064623394458 ) ;
  }

  @Test
  public void test2609() {
    coral.tests.JPFBenchmark.benchmark28(-91.9141431356195 ) ;
  }

  @Test
  public void test2610() {
    coral.tests.JPFBenchmark.benchmark28(-91.96833645052504 ) ;
  }

  @Test
  public void test2611() {
    coral.tests.JPFBenchmark.benchmark28(-91.97491172900966 ) ;
  }

  @Test
  public void test2612() {
    coral.tests.JPFBenchmark.benchmark28(-92.00223131912341 ) ;
  }

  @Test
  public void test2613() {
    coral.tests.JPFBenchmark.benchmark28(-92.03315512013917 ) ;
  }

  @Test
  public void test2614() {
    coral.tests.JPFBenchmark.benchmark28(-92.05047604305203 ) ;
  }

  @Test
  public void test2615() {
    coral.tests.JPFBenchmark.benchmark28(-92.07008292925273 ) ;
  }

  @Test
  public void test2616() {
    coral.tests.JPFBenchmark.benchmark28(-92.08815493642936 ) ;
  }

  @Test
  public void test2617() {
    coral.tests.JPFBenchmark.benchmark28(-92.09870061903177 ) ;
  }

  @Test
  public void test2618() {
    coral.tests.JPFBenchmark.benchmark28(-92.12897789257907 ) ;
  }

  @Test
  public void test2619() {
    coral.tests.JPFBenchmark.benchmark28(-92.15779733155117 ) ;
  }

  @Test
  public void test2620() {
    coral.tests.JPFBenchmark.benchmark28(-9.217846524040013 ) ;
  }

  @Test
  public void test2621() {
    coral.tests.JPFBenchmark.benchmark28(-92.18830234087048 ) ;
  }

  @Test
  public void test2622() {
    coral.tests.JPFBenchmark.benchmark28(-92.22647018096761 ) ;
  }

  @Test
  public void test2623() {
    coral.tests.JPFBenchmark.benchmark28(-92.22822142853246 ) ;
  }

  @Test
  public void test2624() {
    coral.tests.JPFBenchmark.benchmark28(-92.23259168303247 ) ;
  }

  @Test
  public void test2625() {
    coral.tests.JPFBenchmark.benchmark28(-92.23717906342563 ) ;
  }

  @Test
  public void test2626() {
    coral.tests.JPFBenchmark.benchmark28(-92.26838392066328 ) ;
  }

  @Test
  public void test2627() {
    coral.tests.JPFBenchmark.benchmark28(-92.31616688093607 ) ;
  }

  @Test
  public void test2628() {
    coral.tests.JPFBenchmark.benchmark28(-92.3185678814939 ) ;
  }

  @Test
  public void test2629() {
    coral.tests.JPFBenchmark.benchmark28(-92.31900116333374 ) ;
  }

  @Test
  public void test2630() {
    coral.tests.JPFBenchmark.benchmark28(-92.38348895638764 ) ;
  }

  @Test
  public void test2631() {
    coral.tests.JPFBenchmark.benchmark28(-92.40925470514732 ) ;
  }

  @Test
  public void test2632() {
    coral.tests.JPFBenchmark.benchmark28(-92.43863731302804 ) ;
  }

  @Test
  public void test2633() {
    coral.tests.JPFBenchmark.benchmark28(-92.5643196530808 ) ;
  }

  @Test
  public void test2634() {
    coral.tests.JPFBenchmark.benchmark28(-92.64833812432371 ) ;
  }

  @Test
  public void test2635() {
    coral.tests.JPFBenchmark.benchmark28(-92.68878130799555 ) ;
  }

  @Test
  public void test2636() {
    coral.tests.JPFBenchmark.benchmark28(-92.71829124013541 ) ;
  }

  @Test
  public void test2637() {
    coral.tests.JPFBenchmark.benchmark28(-92.72168463052593 ) ;
  }

  @Test
  public void test2638() {
    coral.tests.JPFBenchmark.benchmark28(-92.74473466311915 ) ;
  }

  @Test
  public void test2639() {
    coral.tests.JPFBenchmark.benchmark28(-92.7472201237963 ) ;
  }

  @Test
  public void test2640() {
    coral.tests.JPFBenchmark.benchmark28(-92.76025139096251 ) ;
  }

  @Test
  public void test2641() {
    coral.tests.JPFBenchmark.benchmark28(-92.76522055230015 ) ;
  }

  @Test
  public void test2642() {
    coral.tests.JPFBenchmark.benchmark28(-9.277921258451372 ) ;
  }

  @Test
  public void test2643() {
    coral.tests.JPFBenchmark.benchmark28(-9.27892583127749 ) ;
  }

  @Test
  public void test2644() {
    coral.tests.JPFBenchmark.benchmark28(-92.80885207767106 ) ;
  }

  @Test
  public void test2645() {
    coral.tests.JPFBenchmark.benchmark28(-92.82092521476426 ) ;
  }

  @Test
  public void test2646() {
    coral.tests.JPFBenchmark.benchmark28(-92.85942947672116 ) ;
  }

  @Test
  public void test2647() {
    coral.tests.JPFBenchmark.benchmark28(-92.96238670290357 ) ;
  }

  @Test
  public void test2648() {
    coral.tests.JPFBenchmark.benchmark28(-93.01589891688933 ) ;
  }

  @Test
  public void test2649() {
    coral.tests.JPFBenchmark.benchmark28(-93.0558716964835 ) ;
  }

  @Test
  public void test2650() {
    coral.tests.JPFBenchmark.benchmark28(-93.07846350556275 ) ;
  }

  @Test
  public void test2651() {
    coral.tests.JPFBenchmark.benchmark28(-93.08128552089624 ) ;
  }

  @Test
  public void test2652() {
    coral.tests.JPFBenchmark.benchmark28(-9.310366422708043 ) ;
  }

  @Test
  public void test2653() {
    coral.tests.JPFBenchmark.benchmark28(-9.316831409046642 ) ;
  }

  @Test
  public void test2654() {
    coral.tests.JPFBenchmark.benchmark28(-93.20836670437104 ) ;
  }

  @Test
  public void test2655() {
    coral.tests.JPFBenchmark.benchmark28(-9.325244418487117 ) ;
  }

  @Test
  public void test2656() {
    coral.tests.JPFBenchmark.benchmark28(-93.28892842610124 ) ;
  }

  @Test
  public void test2657() {
    coral.tests.JPFBenchmark.benchmark28(-93.34465412032374 ) ;
  }

  @Test
  public void test2658() {
    coral.tests.JPFBenchmark.benchmark28(-93.39912432625026 ) ;
  }

  @Test
  public void test2659() {
    coral.tests.JPFBenchmark.benchmark28(-93.40832779768733 ) ;
  }

  @Test
  public void test2660() {
    coral.tests.JPFBenchmark.benchmark28(-93.41356945714503 ) ;
  }

  @Test
  public void test2661() {
    coral.tests.JPFBenchmark.benchmark28(-93.44117150280444 ) ;
  }

  @Test
  public void test2662() {
    coral.tests.JPFBenchmark.benchmark28(-93.49987080703006 ) ;
  }

  @Test
  public void test2663() {
    coral.tests.JPFBenchmark.benchmark28(-93.55442099912834 ) ;
  }

  @Test
  public void test2664() {
    coral.tests.JPFBenchmark.benchmark28(-93.6163690103247 ) ;
  }

  @Test
  public void test2665() {
    coral.tests.JPFBenchmark.benchmark28(-93.63925614789102 ) ;
  }

  @Test
  public void test2666() {
    coral.tests.JPFBenchmark.benchmark28(-93.64575542829866 ) ;
  }

  @Test
  public void test2667() {
    coral.tests.JPFBenchmark.benchmark28(-93.65275547036178 ) ;
  }

  @Test
  public void test2668() {
    coral.tests.JPFBenchmark.benchmark28(-9.36839409596277 ) ;
  }

  @Test
  public void test2669() {
    coral.tests.JPFBenchmark.benchmark28(-93.6885730435767 ) ;
  }

  @Test
  public void test2670() {
    coral.tests.JPFBenchmark.benchmark28(-93.69853181095613 ) ;
  }

  @Test
  public void test2671() {
    coral.tests.JPFBenchmark.benchmark28(-93.6993021715104 ) ;
  }

  @Test
  public void test2672() {
    coral.tests.JPFBenchmark.benchmark28(-93.71966983272925 ) ;
  }

  @Test
  public void test2673() {
    coral.tests.JPFBenchmark.benchmark28(-93.72618095854213 ) ;
  }

  @Test
  public void test2674() {
    coral.tests.JPFBenchmark.benchmark28(-93.72867638132247 ) ;
  }

  @Test
  public void test2675() {
    coral.tests.JPFBenchmark.benchmark28(-93.7313240151045 ) ;
  }

  @Test
  public void test2676() {
    coral.tests.JPFBenchmark.benchmark28(-93.73168027418555 ) ;
  }

  @Test
  public void test2677() {
    coral.tests.JPFBenchmark.benchmark28(-93.74055424795465 ) ;
  }

  @Test
  public void test2678() {
    coral.tests.JPFBenchmark.benchmark28(-93.78245787005599 ) ;
  }

  @Test
  public void test2679() {
    coral.tests.JPFBenchmark.benchmark28(-9.379791152932555 ) ;
  }

  @Test
  public void test2680() {
    coral.tests.JPFBenchmark.benchmark28(-93.84353400560572 ) ;
  }

  @Test
  public void test2681() {
    coral.tests.JPFBenchmark.benchmark28(-93.86175929946458 ) ;
  }

  @Test
  public void test2682() {
    coral.tests.JPFBenchmark.benchmark28(-93.86504321299778 ) ;
  }

  @Test
  public void test2683() {
    coral.tests.JPFBenchmark.benchmark28(-93.87791896529811 ) ;
  }

  @Test
  public void test2684() {
    coral.tests.JPFBenchmark.benchmark28(-93.89426794786098 ) ;
  }

  @Test
  public void test2685() {
    coral.tests.JPFBenchmark.benchmark28(-93.97125338259873 ) ;
  }

  @Test
  public void test2686() {
    coral.tests.JPFBenchmark.benchmark28(-94.05472029189174 ) ;
  }

  @Test
  public void test2687() {
    coral.tests.JPFBenchmark.benchmark28(-94.06269851823303 ) ;
  }

  @Test
  public void test2688() {
    coral.tests.JPFBenchmark.benchmark28(-94.07836194628449 ) ;
  }

  @Test
  public void test2689() {
    coral.tests.JPFBenchmark.benchmark28(-94.1484289656731 ) ;
  }

  @Test
  public void test2690() {
    coral.tests.JPFBenchmark.benchmark28(-94.1664489486235 ) ;
  }

  @Test
  public void test2691() {
    coral.tests.JPFBenchmark.benchmark28(-94.21719801556954 ) ;
  }

  @Test
  public void test2692() {
    coral.tests.JPFBenchmark.benchmark28(-94.23108074155431 ) ;
  }

  @Test
  public void test2693() {
    coral.tests.JPFBenchmark.benchmark28(-94.26545576513337 ) ;
  }

  @Test
  public void test2694() {
    coral.tests.JPFBenchmark.benchmark28(-94.29499108020083 ) ;
  }

  @Test
  public void test2695() {
    coral.tests.JPFBenchmark.benchmark28(-9.429576233222491 ) ;
  }

  @Test
  public void test2696() {
    coral.tests.JPFBenchmark.benchmark28(-9.435007317082466 ) ;
  }

  @Test
  public void test2697() {
    coral.tests.JPFBenchmark.benchmark28(-9.43580062805205 ) ;
  }

  @Test
  public void test2698() {
    coral.tests.JPFBenchmark.benchmark28(-94.38257770105143 ) ;
  }

  @Test
  public void test2699() {
    coral.tests.JPFBenchmark.benchmark28(-94.39816173004199 ) ;
  }

  @Test
  public void test2700() {
    coral.tests.JPFBenchmark.benchmark28(-9.440713739355203 ) ;
  }

  @Test
  public void test2701() {
    coral.tests.JPFBenchmark.benchmark28(-94.41429477016197 ) ;
  }

  @Test
  public void test2702() {
    coral.tests.JPFBenchmark.benchmark28(-94.43454754178995 ) ;
  }

  @Test
  public void test2703() {
    coral.tests.JPFBenchmark.benchmark28(-94.49933396782694 ) ;
  }

  @Test
  public void test2704() {
    coral.tests.JPFBenchmark.benchmark28(-94.50357297004162 ) ;
  }

  @Test
  public void test2705() {
    coral.tests.JPFBenchmark.benchmark28(-94.55946227137306 ) ;
  }

  @Test
  public void test2706() {
    coral.tests.JPFBenchmark.benchmark28(-94.58146799433334 ) ;
  }

  @Test
  public void test2707() {
    coral.tests.JPFBenchmark.benchmark28(-94.60569694184227 ) ;
  }

  @Test
  public void test2708() {
    coral.tests.JPFBenchmark.benchmark28(-94.64909793344367 ) ;
  }

  @Test
  public void test2709() {
    coral.tests.JPFBenchmark.benchmark28(-94.6744684829524 ) ;
  }

  @Test
  public void test2710() {
    coral.tests.JPFBenchmark.benchmark28(-94.67585419401105 ) ;
  }

  @Test
  public void test2711() {
    coral.tests.JPFBenchmark.benchmark28(-94.7589557456319 ) ;
  }

  @Test
  public void test2712() {
    coral.tests.JPFBenchmark.benchmark28(-94.76786156790371 ) ;
  }

  @Test
  public void test2713() {
    coral.tests.JPFBenchmark.benchmark28(-94.78390899707827 ) ;
  }

  @Test
  public void test2714() {
    coral.tests.JPFBenchmark.benchmark28(-94.7927968998826 ) ;
  }

  @Test
  public void test2715() {
    coral.tests.JPFBenchmark.benchmark28(-94.81067416972355 ) ;
  }

  @Test
  public void test2716() {
    coral.tests.JPFBenchmark.benchmark28(-94.83137802385082 ) ;
  }

  @Test
  public void test2717() {
    coral.tests.JPFBenchmark.benchmark28(-94.90610687298906 ) ;
  }

  @Test
  public void test2718() {
    coral.tests.JPFBenchmark.benchmark28(-94.92822789909114 ) ;
  }

  @Test
  public void test2719() {
    coral.tests.JPFBenchmark.benchmark28(-95.0069430946185 ) ;
  }

  @Test
  public void test2720() {
    coral.tests.JPFBenchmark.benchmark28(-95.05035203185068 ) ;
  }

  @Test
  public void test2721() {
    coral.tests.JPFBenchmark.benchmark28(-95.07024122375789 ) ;
  }

  @Test
  public void test2722() {
    coral.tests.JPFBenchmark.benchmark28(-95.11637972897198 ) ;
  }

  @Test
  public void test2723() {
    coral.tests.JPFBenchmark.benchmark28(-95.13118158081406 ) ;
  }

  @Test
  public void test2724() {
    coral.tests.JPFBenchmark.benchmark28(-95.1688049610115 ) ;
  }

  @Test
  public void test2725() {
    coral.tests.JPFBenchmark.benchmark28(-95.1805740556563 ) ;
  }

  @Test
  public void test2726() {
    coral.tests.JPFBenchmark.benchmark28(-95.19585717662733 ) ;
  }

  @Test
  public void test2727() {
    coral.tests.JPFBenchmark.benchmark28(-95.21288955725697 ) ;
  }

  @Test
  public void test2728() {
    coral.tests.JPFBenchmark.benchmark28(-95.23981217861093 ) ;
  }

  @Test
  public void test2729() {
    coral.tests.JPFBenchmark.benchmark28(-95.2435373703799 ) ;
  }

  @Test
  public void test2730() {
    coral.tests.JPFBenchmark.benchmark28(-95.28581058743175 ) ;
  }

  @Test
  public void test2731() {
    coral.tests.JPFBenchmark.benchmark28(-95.31051465152525 ) ;
  }

  @Test
  public void test2732() {
    coral.tests.JPFBenchmark.benchmark28(-95.3170916371826 ) ;
  }

  @Test
  public void test2733() {
    coral.tests.JPFBenchmark.benchmark28(-95.31720436819049 ) ;
  }

  @Test
  public void test2734() {
    coral.tests.JPFBenchmark.benchmark28(-95.35722280960665 ) ;
  }

  @Test
  public void test2735() {
    coral.tests.JPFBenchmark.benchmark28(-95.36084722920283 ) ;
  }

  @Test
  public void test2736() {
    coral.tests.JPFBenchmark.benchmark28(-95.37041567231748 ) ;
  }

  @Test
  public void test2737() {
    coral.tests.JPFBenchmark.benchmark28(-95.40317789130226 ) ;
  }

  @Test
  public void test2738() {
    coral.tests.JPFBenchmark.benchmark28(-95.42670899795966 ) ;
  }

  @Test
  public void test2739() {
    coral.tests.JPFBenchmark.benchmark28(-9.54505398590723 ) ;
  }

  @Test
  public void test2740() {
    coral.tests.JPFBenchmark.benchmark28(-95.46572460686053 ) ;
  }

  @Test
  public void test2741() {
    coral.tests.JPFBenchmark.benchmark28(-95.46716125279727 ) ;
  }

  @Test
  public void test2742() {
    coral.tests.JPFBenchmark.benchmark28(-95.53241575842773 ) ;
  }

  @Test
  public void test2743() {
    coral.tests.JPFBenchmark.benchmark28(-95.54360580672456 ) ;
  }

  @Test
  public void test2744() {
    coral.tests.JPFBenchmark.benchmark28(-95.60681376679727 ) ;
  }

  @Test
  public void test2745() {
    coral.tests.JPFBenchmark.benchmark28(-95.66151194842686 ) ;
  }

  @Test
  public void test2746() {
    coral.tests.JPFBenchmark.benchmark28(-95.66301835874403 ) ;
  }

  @Test
  public void test2747() {
    coral.tests.JPFBenchmark.benchmark28(-95.67161212175697 ) ;
  }

  @Test
  public void test2748() {
    coral.tests.JPFBenchmark.benchmark28(-95.67597536959664 ) ;
  }

  @Test
  public void test2749() {
    coral.tests.JPFBenchmark.benchmark28(-9.57263080480277 ) ;
  }

  @Test
  public void test2750() {
    coral.tests.JPFBenchmark.benchmark28(-95.73784974286342 ) ;
  }

  @Test
  public void test2751() {
    coral.tests.JPFBenchmark.benchmark28(-95.82577085968205 ) ;
  }

  @Test
  public void test2752() {
    coral.tests.JPFBenchmark.benchmark28(-95.82675253987831 ) ;
  }

  @Test
  public void test2753() {
    coral.tests.JPFBenchmark.benchmark28(-95.8914712845812 ) ;
  }

  @Test
  public void test2754() {
    coral.tests.JPFBenchmark.benchmark28(-95.90380650663613 ) ;
  }

  @Test
  public void test2755() {
    coral.tests.JPFBenchmark.benchmark28(-95.91724940671618 ) ;
  }

  @Test
  public void test2756() {
    coral.tests.JPFBenchmark.benchmark28(-95.99677775757091 ) ;
  }

  @Test
  public void test2757() {
    coral.tests.JPFBenchmark.benchmark28(-95.9987919470446 ) ;
  }

  @Test
  public void test2758() {
    coral.tests.JPFBenchmark.benchmark28(-96.07871459146935 ) ;
  }

  @Test
  public void test2759() {
    coral.tests.JPFBenchmark.benchmark28(-96.13179877693963 ) ;
  }

  @Test
  public void test2760() {
    coral.tests.JPFBenchmark.benchmark28(-96.15076518061795 ) ;
  }

  @Test
  public void test2761() {
    coral.tests.JPFBenchmark.benchmark28(-96.15152554998461 ) ;
  }

  @Test
  public void test2762() {
    coral.tests.JPFBenchmark.benchmark28(-96.19018801172547 ) ;
  }

  @Test
  public void test2763() {
    coral.tests.JPFBenchmark.benchmark28(-96.19161108322317 ) ;
  }

  @Test
  public void test2764() {
    coral.tests.JPFBenchmark.benchmark28(-96.32588557382246 ) ;
  }

  @Test
  public void test2765() {
    coral.tests.JPFBenchmark.benchmark28(-96.33313483760702 ) ;
  }

  @Test
  public void test2766() {
    coral.tests.JPFBenchmark.benchmark28(-96.34693530058686 ) ;
  }

  @Test
  public void test2767() {
    coral.tests.JPFBenchmark.benchmark28(-96.39803758983541 ) ;
  }

  @Test
  public void test2768() {
    coral.tests.JPFBenchmark.benchmark28(-96.41145238835176 ) ;
  }

  @Test
  public void test2769() {
    coral.tests.JPFBenchmark.benchmark28(-96.4280934201184 ) ;
  }

  @Test
  public void test2770() {
    coral.tests.JPFBenchmark.benchmark28(-96.43541249080381 ) ;
  }

  @Test
  public void test2771() {
    coral.tests.JPFBenchmark.benchmark28(-96.45352821291668 ) ;
  }

  @Test
  public void test2772() {
    coral.tests.JPFBenchmark.benchmark28(-96.46002679992695 ) ;
  }

  @Test
  public void test2773() {
    coral.tests.JPFBenchmark.benchmark28(-96.47068373696177 ) ;
  }

  @Test
  public void test2774() {
    coral.tests.JPFBenchmark.benchmark28(-96.64045253723029 ) ;
  }

  @Test
  public void test2775() {
    coral.tests.JPFBenchmark.benchmark28(-96.6465338170069 ) ;
  }

  @Test
  public void test2776() {
    coral.tests.JPFBenchmark.benchmark28(-96.72351591918753 ) ;
  }

  @Test
  public void test2777() {
    coral.tests.JPFBenchmark.benchmark28(-96.75942124315881 ) ;
  }

  @Test
  public void test2778() {
    coral.tests.JPFBenchmark.benchmark28(-9.68243819052637 ) ;
  }

  @Test
  public void test2779() {
    coral.tests.JPFBenchmark.benchmark28(-96.85040398877949 ) ;
  }

  @Test
  public void test2780() {
    coral.tests.JPFBenchmark.benchmark28(-96.90605435477102 ) ;
  }

  @Test
  public void test2781() {
    coral.tests.JPFBenchmark.benchmark28(-96.9430720672362 ) ;
  }

  @Test
  public void test2782() {
    coral.tests.JPFBenchmark.benchmark28(-96.9838770695009 ) ;
  }

  @Test
  public void test2783() {
    coral.tests.JPFBenchmark.benchmark28(-9.702425581133738 ) ;
  }

  @Test
  public void test2784() {
    coral.tests.JPFBenchmark.benchmark28(-97.0461572704336 ) ;
  }

  @Test
  public void test2785() {
    coral.tests.JPFBenchmark.benchmark28(-97.04689714066855 ) ;
  }

  @Test
  public void test2786() {
    coral.tests.JPFBenchmark.benchmark28(-97.06688730007717 ) ;
  }

  @Test
  public void test2787() {
    coral.tests.JPFBenchmark.benchmark28(-97.09466670846938 ) ;
  }

  @Test
  public void test2788() {
    coral.tests.JPFBenchmark.benchmark28(-97.15073794504445 ) ;
  }

  @Test
  public void test2789() {
    coral.tests.JPFBenchmark.benchmark28(-97.1522621601187 ) ;
  }

  @Test
  public void test2790() {
    coral.tests.JPFBenchmark.benchmark28(-97.17894630660977 ) ;
  }

  @Test
  public void test2791() {
    coral.tests.JPFBenchmark.benchmark28(-97.21941160092764 ) ;
  }

  @Test
  public void test2792() {
    coral.tests.JPFBenchmark.benchmark28(-97.24896142239272 ) ;
  }

  @Test
  public void test2793() {
    coral.tests.JPFBenchmark.benchmark28(-97.31414781350969 ) ;
  }

  @Test
  public void test2794() {
    coral.tests.JPFBenchmark.benchmark28(-97.31426290483051 ) ;
  }

  @Test
  public void test2795() {
    coral.tests.JPFBenchmark.benchmark28(-97.35050728598308 ) ;
  }

  @Test
  public void test2796() {
    coral.tests.JPFBenchmark.benchmark28(-97.36994895212503 ) ;
  }

  @Test
  public void test2797() {
    coral.tests.JPFBenchmark.benchmark28(-97.37114377523064 ) ;
  }

  @Test
  public void test2798() {
    coral.tests.JPFBenchmark.benchmark28(-97.37357357346445 ) ;
  }

  @Test
  public void test2799() {
    coral.tests.JPFBenchmark.benchmark28(-97.42615248838997 ) ;
  }

  @Test
  public void test2800() {
    coral.tests.JPFBenchmark.benchmark28(-97.43350160650756 ) ;
  }

  @Test
  public void test2801() {
    coral.tests.JPFBenchmark.benchmark28(-97.45173925336137 ) ;
  }

  @Test
  public void test2802() {
    coral.tests.JPFBenchmark.benchmark28(-97.45243490582803 ) ;
  }

  @Test
  public void test2803() {
    coral.tests.JPFBenchmark.benchmark28(-97.54086607046418 ) ;
  }

  @Test
  public void test2804() {
    coral.tests.JPFBenchmark.benchmark28(-97.57200887521167 ) ;
  }

  @Test
  public void test2805() {
    coral.tests.JPFBenchmark.benchmark28(-97.58289650071801 ) ;
  }

  @Test
  public void test2806() {
    coral.tests.JPFBenchmark.benchmark28(-97.58839170469187 ) ;
  }

  @Test
  public void test2807() {
    coral.tests.JPFBenchmark.benchmark28(-97.60559833534639 ) ;
  }

  @Test
  public void test2808() {
    coral.tests.JPFBenchmark.benchmark28(-97.63162817891782 ) ;
  }

  @Test
  public void test2809() {
    coral.tests.JPFBenchmark.benchmark28(-97.65164181885024 ) ;
  }

  @Test
  public void test2810() {
    coral.tests.JPFBenchmark.benchmark28(-97.65217569308744 ) ;
  }

  @Test
  public void test2811() {
    coral.tests.JPFBenchmark.benchmark28(-9.767918202146348 ) ;
  }

  @Test
  public void test2812() {
    coral.tests.JPFBenchmark.benchmark28(-97.6997565146552 ) ;
  }

  @Test
  public void test2813() {
    coral.tests.JPFBenchmark.benchmark28(-97.80506513115745 ) ;
  }

  @Test
  public void test2814() {
    coral.tests.JPFBenchmark.benchmark28(-97.8058670313246 ) ;
  }

  @Test
  public void test2815() {
    coral.tests.JPFBenchmark.benchmark28(-97.87235282551212 ) ;
  }

  @Test
  public void test2816() {
    coral.tests.JPFBenchmark.benchmark28(-97.87530229923502 ) ;
  }

  @Test
  public void test2817() {
    coral.tests.JPFBenchmark.benchmark28(-97.88965609080009 ) ;
  }

  @Test
  public void test2818() {
    coral.tests.JPFBenchmark.benchmark28(-97.95621315370606 ) ;
  }

  @Test
  public void test2819() {
    coral.tests.JPFBenchmark.benchmark28(-98.00436664901449 ) ;
  }

  @Test
  public void test2820() {
    coral.tests.JPFBenchmark.benchmark28(-98.01284949121316 ) ;
  }

  @Test
  public void test2821() {
    coral.tests.JPFBenchmark.benchmark28(-98.06620088382678 ) ;
  }

  @Test
  public void test2822() {
    coral.tests.JPFBenchmark.benchmark28(-98.1039772217347 ) ;
  }

  @Test
  public void test2823() {
    coral.tests.JPFBenchmark.benchmark28(-98.15126711693398 ) ;
  }

  @Test
  public void test2824() {
    coral.tests.JPFBenchmark.benchmark28(-98.17395527012405 ) ;
  }

  @Test
  public void test2825() {
    coral.tests.JPFBenchmark.benchmark28(-98.17968337728023 ) ;
  }

  @Test
  public void test2826() {
    coral.tests.JPFBenchmark.benchmark28(-98.18816021586383 ) ;
  }

  @Test
  public void test2827() {
    coral.tests.JPFBenchmark.benchmark28(-98.19121481999424 ) ;
  }

  @Test
  public void test2828() {
    coral.tests.JPFBenchmark.benchmark28(-98.28387556419635 ) ;
  }

  @Test
  public void test2829() {
    coral.tests.JPFBenchmark.benchmark28(-98.28850637009417 ) ;
  }

  @Test
  public void test2830() {
    coral.tests.JPFBenchmark.benchmark28(-98.34585716341525 ) ;
  }

  @Test
  public void test2831() {
    coral.tests.JPFBenchmark.benchmark28(-98.39547443349804 ) ;
  }

  @Test
  public void test2832() {
    coral.tests.JPFBenchmark.benchmark28(-98.41273028126973 ) ;
  }

  @Test
  public void test2833() {
    coral.tests.JPFBenchmark.benchmark28(-98.42675022793645 ) ;
  }

  @Test
  public void test2834() {
    coral.tests.JPFBenchmark.benchmark28(-9.843370509815543 ) ;
  }

  @Test
  public void test2835() {
    coral.tests.JPFBenchmark.benchmark28(-98.44999718869936 ) ;
  }

  @Test
  public void test2836() {
    coral.tests.JPFBenchmark.benchmark28(-98.48876549203729 ) ;
  }

  @Test
  public void test2837() {
    coral.tests.JPFBenchmark.benchmark28(-98.57238188100229 ) ;
  }

  @Test
  public void test2838() {
    coral.tests.JPFBenchmark.benchmark28(-98.5928154178193 ) ;
  }

  @Test
  public void test2839() {
    coral.tests.JPFBenchmark.benchmark28(-98.62827584849485 ) ;
  }

  @Test
  public void test2840() {
    coral.tests.JPFBenchmark.benchmark28(-98.64585929486923 ) ;
  }

  @Test
  public void test2841() {
    coral.tests.JPFBenchmark.benchmark28(-98.73411427207704 ) ;
  }

  @Test
  public void test2842() {
    coral.tests.JPFBenchmark.benchmark28(-98.7535518764195 ) ;
  }

  @Test
  public void test2843() {
    coral.tests.JPFBenchmark.benchmark28(-98.85107387635261 ) ;
  }

  @Test
  public void test2844() {
    coral.tests.JPFBenchmark.benchmark28(-98.85773221489791 ) ;
  }

  @Test
  public void test2845() {
    coral.tests.JPFBenchmark.benchmark28(-98.9397399912709 ) ;
  }

  @Test
  public void test2846() {
    coral.tests.JPFBenchmark.benchmark28(-98.94043348443418 ) ;
  }

  @Test
  public void test2847() {
    coral.tests.JPFBenchmark.benchmark28(-98.941257660432 ) ;
  }

  @Test
  public void test2848() {
    coral.tests.JPFBenchmark.benchmark28(-98.95962916083327 ) ;
  }

  @Test
  public void test2849() {
    coral.tests.JPFBenchmark.benchmark28(-98.979054865028 ) ;
  }

  @Test
  public void test2850() {
    coral.tests.JPFBenchmark.benchmark28(-99.06033887555775 ) ;
  }

  @Test
  public void test2851() {
    coral.tests.JPFBenchmark.benchmark28(-99.08377990751343 ) ;
  }

  @Test
  public void test2852() {
    coral.tests.JPFBenchmark.benchmark28(-99.10717214961345 ) ;
  }

  @Test
  public void test2853() {
    coral.tests.JPFBenchmark.benchmark28(-99.13656019968936 ) ;
  }

  @Test
  public void test2854() {
    coral.tests.JPFBenchmark.benchmark28(-99.15158347331598 ) ;
  }

  @Test
  public void test2855() {
    coral.tests.JPFBenchmark.benchmark28(-9.92180320678115 ) ;
  }

  @Test
  public void test2856() {
    coral.tests.JPFBenchmark.benchmark28(-99.22209017992145 ) ;
  }

  @Test
  public void test2857() {
    coral.tests.JPFBenchmark.benchmark28(-9.92251841818468 ) ;
  }

  @Test
  public void test2858() {
    coral.tests.JPFBenchmark.benchmark28(-99.25953068954254 ) ;
  }

  @Test
  public void test2859() {
    coral.tests.JPFBenchmark.benchmark28(-99.27661993944066 ) ;
  }

  @Test
  public void test2860() {
    coral.tests.JPFBenchmark.benchmark28(-99.31013077866237 ) ;
  }

  @Test
  public void test2861() {
    coral.tests.JPFBenchmark.benchmark28(-9.933218995910593 ) ;
  }

  @Test
  public void test2862() {
    coral.tests.JPFBenchmark.benchmark28(-9.937114662531997 ) ;
  }

  @Test
  public void test2863() {
    coral.tests.JPFBenchmark.benchmark28(-99.45095162335522 ) ;
  }

  @Test
  public void test2864() {
    coral.tests.JPFBenchmark.benchmark28(-99.49921546237346 ) ;
  }

  @Test
  public void test2865() {
    coral.tests.JPFBenchmark.benchmark28(-9.951174582536197 ) ;
  }

  @Test
  public void test2866() {
    coral.tests.JPFBenchmark.benchmark28(-99.53138486172178 ) ;
  }

  @Test
  public void test2867() {
    coral.tests.JPFBenchmark.benchmark28(-99.53941772936629 ) ;
  }

  @Test
  public void test2868() {
    coral.tests.JPFBenchmark.benchmark28(-9.954832984056509 ) ;
  }

  @Test
  public void test2869() {
    coral.tests.JPFBenchmark.benchmark28(-99.57533161604741 ) ;
  }

  @Test
  public void test2870() {
    coral.tests.JPFBenchmark.benchmark28(-9.971050418789403 ) ;
  }

  @Test
  public void test2871() {
    coral.tests.JPFBenchmark.benchmark28(-99.7489910136407 ) ;
  }

  @Test
  public void test2872() {
    coral.tests.JPFBenchmark.benchmark28(-99.76158311961143 ) ;
  }

  @Test
  public void test2873() {
    coral.tests.JPFBenchmark.benchmark28(-99.77268279282794 ) ;
  }

  @Test
  public void test2874() {
    coral.tests.JPFBenchmark.benchmark28(-99.89205410593667 ) ;
  }

  @Test
  public void test2875() {
    coral.tests.JPFBenchmark.benchmark28(-9.990238855344785 ) ;
  }

  @Test
  public void test2876() {
    coral.tests.JPFBenchmark.benchmark28(-99.9226895491538 ) ;
  }
}
