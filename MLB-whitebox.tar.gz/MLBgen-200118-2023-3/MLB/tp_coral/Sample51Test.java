import org.junit.Test;

public class Sample51Test {

  @Test
  public void test0() {
//    0.8558203017330415;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark51(0.0,0.0010256426493579854 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark51(0.008249131810872145,1.6125660204630256E-5 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark51(-0.008912221460544566,0.0021496815215683337 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark51(0.0,2.1746109037832804E-5 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark51(0.021804492834961154,5.064823162444184E-6 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark51(0.0,5.059365272311873E-6 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark51(0.3139616682808951,91.93073525006804 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark51(0.42987661056627535,49.56438430448193 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark51(0.4331684479111938,49.5668315520888 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark51(0.4422337603051112,47.2210164356701 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark51(0.44712738698218857,49.552872613017776 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark51(0.44772432240221627,49.552275677589826 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark51(0.45552423677201204,46.538566095104365 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark51(0.45734281325080195,47.70726366463658 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark51(0.45894363901842183,45.380120947729495 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark51(0.45939738511996564,49.54060261488003 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark51(0.46100517627719306,49.53899482372276 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark51(0.4611072876069251,45.089063209813474 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark51(0.4700797338462759,47.243535588828394 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark51(0.4748761886398398,47.02141229967606 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark51(0.47645285808451376,44.068832188107535 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark51(0.4775332180915308,49.45609311430679 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark51(0.47900703884861495,49.520992961151364 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark51(0.4830798809830359,49.51692011901696 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark51(0.4840946864451379,45.95357514831719 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark51(0.4890034000723631,39.908171218111534 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark51(0.49023498148840616,49.509765018511565 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark51(0.49100128545498833,47.651369820347526 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark51(0.4929526244014819,46.94811799160097 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark51(0.5049198172846192,44.699743574393665 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark51(0.5106025024015821,42.43281398775379 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark51(0.5183338644789015,48.60368990873829 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark51(0.5183583051616631,42.13402102293702 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark51(0.5197518744998271,46.1799696688654 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark51(0.5199836618355675,49.278676485244254 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark51(0.5202063295921799,44.839984763374694 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark51(0.5214231026914675,41.96041116983925 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark51(0.5318374041365672,49.253635523374896 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark51(0.536157823267061,38.3678613415411 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark51(0.5438591674612165,49.45614083253865 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark51(0.5450263212651307,35.50038277797093 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark51(0.5493563255596194,47.427196207584814 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark51(0.5520306764470178,41.11820777515632 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark51(0.5534928905387488,42.66645715391027 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark51(0.5536909816822502,42.485014945924576 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark51(0.5642010263815369,48.34583409316783 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark51(0.5651052105560588,36.7095949083871 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark51(0.567191849788566,48.64835494264959 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark51(0.5718933792928215,49.42810662070717 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark51(0.5725643867888515,43.67670355710385 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark51(0.576650219547429,36.17114326215411 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark51(0.5770120527293585,29.252288098234906 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark51(0.5798278409684983,31.586831578705926 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark51(0.5863834716593175,32.208945265882164 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark51(0.587593147374335,29.451495288590593 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark51(0.5908755063556868,28.310497599992242 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark51(0.5928237538055243,43.90582359308374 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark51(0.6027457036778244,36.04099009118967 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark51(0.6033948847157811,33.81864301148197 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark51(0.6076915768570075,30.083917428345387 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark51(0.6100333981907022,48.87539243292656 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark51(0.6244984178471871,47.537123357292245 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark51(0.6255557256488231,28.32901897076846 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark51(0.6260970356732258,34.56929572724178 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark51(0.6270170188977602,32.9335688248213 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark51(0.6363599908012283,41.97388107531948 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark51(0.6458390394895024,33.38880737451026 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark51(0.6461772252017752,49.35382277479822 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark51(0.646546731426838,27.313450049739885 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark51(0.6493079200731415,45.571785927082715 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark51(0.6589580771237353,48.7164351582918 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark51(0.668083132013519,42.162047929774445 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark51(0.672818425198443,49.32718157480155 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark51(0.678520135433285,26.431990207025976 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark51(0.6971310406607731,44.958583039611085 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark51(0.7048535788611829,49.29514642113881 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark51(0.7120391043240861,44.63054283796791 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark51(0.7139140894564093,20.57478685438915 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark51(0.7176580151155458,49.005120514089505 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark51(0.7207111389998403,24.79540704173696 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark51(0.7235745469821921,34.936000206098555 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark51(0.732902175377415,49.26709782461901 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark51(0.7351605835713482,33.02022576092364 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark51(0.7381178663467693,24.43690051726486 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark51(0.7387641446442501,44.79025719665063 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark51(0.7421854532257606,17.967720797592623 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark51(0.7498884678470432,45.17515152066446 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark51(0.7525777467921007,49.247422253207894 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark51(0.7559750409704407,21.03832586159635 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark51(0.7583510927568033,19.798779311140358 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark51(0.7635673806964718,40.59246280710843 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark51(0.7702942127234707,25.37698429371163 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark51(0.7790720595774303,21.49450266199459 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark51(0.7900568635030254,17.06410414345092 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark51(0.7960808982575713,45.471958084503115 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark51(0.7998175127065679,36.23105360069883 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark51(0.8010848876390639,24.583890734327625 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark51(0.8140668560276061,37.982276840420354 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark51(0.8141751633028633,36.67992023773482 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark51(0.8152591019063058,30.896974313499044 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark51(0.8217007612696132,33.12016792678605 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark51(0.8351066275482424,14.71013367115026 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark51(0.8358736697549887,28.00243983730087 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark51(0.8384349112093332,29.768659293079565 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark51(0.8399419059455315,42.13241994764297 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark51(0.8411726976644402,34.3076440843077 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark51(0.8470321129531388,49.152967887046856 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark51(0.8470745265194921,30.743910635152076 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark51(0.8539683356309045,49.14603166436909 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark51(0.8560392031570245,32.38104723007123 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark51(0.8590141152092343,19.717725575686956 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark51(0.863949310765662,21.830183466633216 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark51(0.8680617437786996,41.11279967272 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark51(0.869629388320238,46.6078067130575 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark51(0.8712362706196899,17.87934313001832 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark51(0.8755402970694393,30.18380964190328 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark51(0.8778164661988956,49.1221835338011 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark51(0.8802943123751987,33.66027723251656 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark51(0.8872566051196767,15.13090700433277 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark51(0.8877555743166192,33.240326497773935 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark51(0.893650340582198,39.49020812068838 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark51(0.8956242832102581,17.548319956846825 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark51(0.8987443940014259,34.79832234738291 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark51(0.9013900863770914,36.9682472448892 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark51(0.9025460008578667,49.097453999142125 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark51(0.9041975464098577,36.4740876138751 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark51(0.9071379222178586,44.34365707942564 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark51(0.9081515907189619,43.00273353633775 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark51(0.9084165732003271,25.722363243716856 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark51(0.9129889046137123,36.095745435702895 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark51(0.9141010746578786,36.38442705500694 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark51(0.916016522766224,18.583811347185247 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark51(0.9174692998820291,17.102707920603663 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark51(0.9177637391934326,41.63644826834178 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark51(0.917959366249363,46.90872568563296 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark51(0.9196803664396394,49.08031963356035 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark51(0.9228102223196686,17.951871536671504 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark51(0.9241337445453155,45.243171291644586 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark51(0.9260559243450217,43.95263186437711 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark51(0.926838390663832,18.451744871449847 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark51(0.9318156590629343,33.33355757034789 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark51(0.9339462861439358,31.43531488683965 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark51(0.9351471305881063,46.53302670328381 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark51(0.9424566903154212,43.752442671719685 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark51(0.9440053109388344,16.595348648073056 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark51(0.9469384948924513,17.636068819958737 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark51(0.9475927765332273,33.56880842656068 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark51(0.9492657935066973,44.93960581097642 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark51(0.9492997047881602,26.324045162298376 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark51(0.9668171046831375,44.97270336004051 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark51(0.9690991940615117,26.393756692957254 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark51(0.9733927815874885,23.893674119447184 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark51(0.9782511683864783,26.081516506169194 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark51(0.9784771736789004,15.630446744968623 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark51(0.9805483188124635,40.29733749055503 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark51(0.9813569323591451,11.910962420919162 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark51(0.983365618449568,30.34106812595894 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark51(0.9853363287218802,34.03326788672214 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark51(0.9872572832718614,21.796410399790034 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark51(0.9882691425133081,31.7827895275353 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark51(10.001158690398043,16.673736442136715 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark51(10.004274282831972,20.429657891775108 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark51(10.015988619886045,22.502486692991553 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark51(10.033544182592934,29.410424202672694 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark51(10.040178768960146,14.851606333088284 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark51(10.043913166586876,22.651386517324724 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark51(10.046572330592412,29.371546299021333 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark51(10.050302904156055,12.608028382207223 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark51(10.05203485996573,15.196058535784601 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark51(10.059950521715223,22.41571184894302 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark51(1.006016946868547,30.72883599307903 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark51(10.068381235163272,30.68089635714253 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark51(1.0072132012950874,32.12840777925251 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark51(10.090950898378438,19.671918817670957 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark51(10.100570847234035,31.20420485697983 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark51(10.104527921777986,34.681476653835915 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark51(1.0107330946573967,38.58920479971357 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark51(10.113380032662517,13.104326538143738 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark51(10.115713510796681,30.237802551638197 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark51(1.0127253286180888,24.124319714705805 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark51(10.153675346704233,37.48347605223668 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark51(10.157914968958565,39.84208503104125 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark51(1.016127042500845E-8,0 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark51(1.016711172150964,23.16289767879277 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark51(10.16811142063608,20.398763626657953 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark51(1.0170261242680585,12.867315299468146 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark51(10.17295658910733,11.625577612126747 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark51(1.0197181832866091,48.98028181671271 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark51(10.19759666087755,25.63537322160272 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark51(10.198286048684608,13.594089774548394 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark51(10.20060073904942,11.363970053373691 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark51(10.205248110289206,33.872793687675625 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark51(10.208042534643454,28.28435639250563 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark51(10.213746352154004,39.472834534359265 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark51(1.0218632297322037,40.97936641765207 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark51(10.222189684850719,36.404079924274384 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark51(10.226634925909579,28.486712399793703 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark51(10.232453553270886,27.036326419510132 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark51(10.238245865001346,13.760303931690899 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark51(1.024276950535631,45.4760526836237 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark51(10.243898274365364,17.792831758829124 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark51(10.246899652548791,29.419794534024362 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark51(10.247606582409208,19.060612072056372 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark51(1.0253295893703813,41.63399799227713 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark51(10.258352818095801,22.779230080773075 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark51(10.260423562729358,27.516114184699674 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark51(10.265113078538263,24.16158642218294 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark51(10.268616962300072,16.952863336007674 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark51(10.27342049373705,33.63662349912232 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark51(10.274646986316924,32.889568923389135 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark51(10.278689032049797,20.36580128038929 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark51(10.281251449806907,39.636927588732675 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark51(10.298967894740915,13.865849195551988 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark51(10.312859724828382,25.84232772334684 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark51(10.32926640528973,14.719932986339174 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark51(10.330015515162657,20.990191826276856 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark51(10.33647938874222,38.674327883190756 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark51(10.347019860629988,18.33302134446526 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark51(10.354509596800721,37.391515088756165 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark51(10.359210403421713,15.982911842732747 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark51(10.363504938162137,19.898046833871305 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark51(10.37097715122755,34.84895553799569 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark51(1.0389587917127443,22.024609025580347 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark51(10.396573448927569,33.848378130927756 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark51(1.0404946757699594,13.499430954167408 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark51(10.405800617851027,38.307903648904215 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark51(1.040637362144409,33.88977898696633 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark51(1.0413692378557755,11.855937407757366 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark51(10.41451341542351,28.08374653428382 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark51(10.425136320840256,12.885592272282494 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark51(10.440468308418943,12.061917011602091 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark51(10.444162446973198,27.828320283311676 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark51(1.0444473072191292,17.017259067577157 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark51(10.446523122134288,13.27837520041033 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark51(10.453869910856838,34.31981800912726 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark51(10.456162962957238,13.17030104927099 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark51(10.464385037734022,37.75796465214118 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark51(1.0465225326604468,39.978114769824685 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark51(10.475978075986902,26.74021513307956 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark51(10.476337878633018,11.869516189057961 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark51(10.477846839235227,12.211833762532962 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark51(1.0479577578050367,16.115461641882405 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark51(10.49532429774959,36.39249748153057 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark51(10.496407327795481,14.013481830605002 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark51(10.527099078483303,14.090576969246609 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark51(10.527622412949242,35.9024242341294 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark51(10.552903791824718,32.99323338593925 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark51(10.557973943160604,11.545476305137116 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark51(1.0561578668450267,20.128787354723542 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark51(10.597146068612972,16.353355448223866 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark51(1.0602053552891846,29.1724240667902 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark51(1.060597437619478,18.362989007475193 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark51(10.61240964172518,32.18266277424152 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark51(1.0621040944196949,26.399656875208777 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark51(10.622579738013954,12.997959737378167 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark51(10.633330645243504,20.028702192087337 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark51(10.633696099085167,23.696752183790707 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark51(10.641281237966211,19.941299128826657 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark51(1.064214471849101,44.402520546612834 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark51(1.0645272303129403,18.19052293019132 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark51(10.64871895550803,31.346742797825357 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark51(10.655927503339342,28.66456897017318 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark51(10.665348881712529,29.573124556893617 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark51(10.670655157814252,22.990516940056224 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark51(10.672962735037999,38.60890578197157 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark51(10.67763933640309,35.559973173687354 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark51(10.678707871794728,37.94096784970927 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark51(10.693443572035829,22.53364530404077 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark51(10.708375816451788,14.076593807977817 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark51(10.714580057691308,33.24368340453387 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark51(10.72385927280348,38.02628134339611 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark51(10.751719636476789,28.407805305968402 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark51(10.752499113544218,35.090374991634576 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark51(10.767792370597533,27.763767904293474 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark51(1.077358998009311,46.53149102455808 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark51(10.775940886232732,17.81141489990175 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark51(10.77768207192996,34.21816088301779 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark51(10.783100205859355,31.762653731009664 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark51(10.790255999966874,32.03957894893617 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark51(10.805060500807627,27.087535986439775 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark51(10.810621505644221,17.070396964304194 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark51(10.811815219331564,29.28774269399503 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark51(1.0829574399837187,29.066849858935637 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark51(10.846386011414097,25.146892977987292 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark51(10.84942441489747,16.35361093622663 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark51(10.85136803027666,27.16174330249403 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark51(10.862761744681436,12.76689999576081 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark51(10.884914519881121,23.844798175235155 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark51(10.89541286340601,39.10458713659398 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark51(10.898866085573871,30.28089098569751 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark51(10.907321700893064,31.087814605101784 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark51(10.908829392639333,20.747198289827963 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark51(10.920462761835807,15.500460423352962 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark51(10.92779058348971,38.23610628245595 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark51(10.936158062382646,32.42324388680698 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark51(10.941124435439463,28.65437702011974 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark51(10.957785127876818,17.44080780975918 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark51(10.964719249676698,27.94789471669654 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark51(10.965265876328388,12.094068360430626 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark51(10.976442341888855,13.090726184961142 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark51(10.97709632354868,23.97226512623029 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark51(10.979143145798488,21.8133961454311 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark51(10.989962978604549,13.617676740919237 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark51(1.0993676569045903,28.3157584967324 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark51(10.998334474751175,27.089215332487242 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark51(11.001431319251637,20.239763650661466 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark51(11.003153911486962,28.062121647086116 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark51(1.100375370083981,17.575512846767595 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark51(11.01902843166484,16.767280360284047 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark51(11.028131661942616,38.97186833805736 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark51(1.1031725463773085,36.33462837153755 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark51(1.1031907197731243,19.291146943666092 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark51(11.033288757285305,14.496122215880973 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark51(11.046014919816328,13.788867712438531 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark51(1.105923349240939,13.453715049767709 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark51(1.105993701272979,27.157431766002475 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark51(11.062256264951856,24.811039808694815 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark51(11.06294178647893,30.430832938148285 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark51(11.083538035451141,36.32519608567662 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark51(11.085640716740947,29.640342427191122 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark51(11.089276877880586,16.532481374060623 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark51(11.091667963895802,13.455216217053206 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark51(11.100977274835138,32.12137746054489 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark51(11.106239780081069,32.661706137703874 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark51(11.111578697146356,16.81834448232567 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark51(11.133041996637857,12.493541722428485 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark51(11.138988630629854,34.86696867285454 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark51(11.141540277495114,36.31418058067638 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark51(11.142619996258716,18.97607017370248 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark51(11.151832990511219,34.6565228195741 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark51(1.1154073010197294,15.262697819518237 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark51(11.171824942843088,29.192466532315827 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark51(11.174930400960818,27.252626785905804 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark51(11.185039290391252,37.247804803768666 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark51(11.204028780000044,25.537063135030593 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark51(11.208165072952454,17.358715259286626 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark51(1.1240559336435503,13.958928791338678 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark51(1.1244057841343533,29.211968068693864 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark51(11.251340257851766,18.88287918086688 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark51(11.266458965344327,38.064790319844235 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark51(11.27215294945458,14.131422801872844 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark51(11.284558707065834,28.060520093307005 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark51(11.285565516783763,30.600316469698015 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark51(11.304252314848355,32.94959934068669 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark51(1.130790118676714,39.45510695230482 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark51(11.31258316175132,32.63034476218306 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark51(1.1314968277883537,38.84085796210775 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark51(11.315119154761405,25.388825517705403 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark51(1.1331835672775412,38.399612621908005 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark51(11.333563776757543,12.274015913059515 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark51(11.334799963639838,12.391198364500355 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark51(1.1335971732519852,27.915838000623722 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark51(11.33631444206047,15.529138868404061 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark51(11.340877882314885,22.930605237546295 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark51(11.34631249664298,18.147811357556773 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark51(11.357010029567107,34.54932364997765 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark51(11.370515057813762,38.62948494218618 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark51(1.1371169609103622,13.023045099507597 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark51(11.376616529406732,28.953001181093015 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark51(1.137957326952971,19.164393707199746 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark51(11.38262561396995,31.94191956189124 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark51(11.387438053085376,37.90880418948302 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark51(11.388764057266602,37.89985312696558 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark51(11.401329469548884,24.489877811711665 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark51(11.4049739638821,30.0469412475166 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark51(11.412008756774952,19.520433320417155 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark51(11.416787071425333,36.51480912871082 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark51(11.42067649702497,38.57932350297483 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark51(11.422055192546281,35.20555253122413 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark51(11.425560174096034,29.109291374543062 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark51(1.14285382272179,43.461501869499585 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark51(11.430502785660863,25.033507795372387 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark51(11.437901902420975,24.841353020959247 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark51(1.144128303267331,9.773833052864614 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark51(11.442196664799624,21.585996704050743 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark51(1.144579139431382,21.309620347740264 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark51(11.446577038747918,33.26408710079215 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark51(11.447367127852132,31.082652522738528 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark51(11.451924308954688,20.37663871284414 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark51(1.1453970601916978,34.20771517743003 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark51(11.456818248278395,21.4789748115205 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark51(1.145811661269036,15.154135455236556 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark51(11.461853560010766,38.53814643998922 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark51(11.477236703721047,23.671396201164498 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark51(11.478579190714939,16.331746822873086 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark51(1.1487078516027502,37.132711994111695 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark51(11.4990325931754,12.882086203895732 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark51(1.1503923271071574,47.883510357753124 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark51(11.50417138159419,30.780945867926306 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark51(1.1507046023547787,32.64705531121584 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark51(11.520927561030831,17.056192791340493 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark51(11.521198081501126,20.04112965137076 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark51(11.522855633735585,17.039931078624356 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark51(1.1527845089694466,44.04932105778761 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark51(11.537426652104472,35.99625168207649 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark51(11.539156469527697,34.058921570178256 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark51(1.1540223056398333,23.486314181047337 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark51(11.540453907628546,30.728856174604203 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark51(11.543954128125938,38.45604587187405 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark51(1.154615654971039,45.7775751585649 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark51(11.56726564615269,25.259889031992927 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark51(11.568964997784079,28.660820179336724 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark51(11.601635758487244,25.764478731878725 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark51(11.602377365268353,18.54644297977481 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark51(11.605295524382882,37.68256116677654 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark51(11.605499841459121,37.08904843424477 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark51(1.1612260871265931,26.313587658651485 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark51(1.1614596355696594,13.531925072730978 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark51(11.631928527690537,23.574007375455523 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark51(11.647144498579593,15.648123734715242 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark51(11.653186079488552,37.59961704461138 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark51(1.1654772621316027,11.707977437158362 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark51(11.668118431979607,29.587177418892594 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark51(11.680985904543524,24.888415905994474 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark51(11.682627159445929,35.043980779926244 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark51(11.69062857014203,13.106942148173943 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark51(1.1694949784470374,10.45886608938838 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark51(11.695092520144012,38.304907479855956 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark51(11.697716921329087,38.302283078670904 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark51(1.1721417119702835,11.822111379820583 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark51(11.724562541416034,28.976677082312676 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark51(11.7280507751627,12.877946375781253 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark51(1.1734762350701828,48.59792352062564 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark51(11.750897766568016,29.67865551884995 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark51(11.769809029351752,16.294116442974413 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark51(11.78544498782071,30.21673681208091 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark51(1.1791197430621736,21.541900620144077 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark51(1.1803416644793288,9.876758765708743 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark51(11.809502945949486,19.520687909537145 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark51(11.814885242781612,23.69973545723966 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark51(1.1818389420004962,14.307503139427212 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark51(1.1818893105939026,16.022862995184894 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark51(1.1825810807014154,48.695648153958196 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark51(11.83639922932636,36.339018377318496 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark51(11.836733925015693,38.1632660749843 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark51(1.184120552108709,29.278296757437204 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark51(11.849521889321736,15.740080021242207 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark51(1.1859503393847532,48.81404966061524 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark51(11.860963551108952,35.53602224605575 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark51(11.86451869692118,37.044673070732784 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark51(1.186507766758922,14.469181224731216 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark51(11.86679384900549,13.15420250554287 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark51(1.187754532833324,14.44613872853158 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark51(11.878157968478305,16.123467786333208 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark51(1.1879426494263878,41.75406126946464 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark51(11.891108919442601,34.059116785484065 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark51(11.902057404636722,33.095253309507655 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark51(11.903208398510799,16.478834104467552 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark51(11.909097500135772,21.116560036608362 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark51(11.91983986018667,29.946118919216353 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark51(11.922383500409843,34.530590265401514 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark51(11.930020689271245,18.175421079468677 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark51(11.940346793565197,15.214191518264727 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark51(1.1954613396038667,24.449645030981742 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark51(11.969172110405339,20.29762045470818 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark51(11.971571752520077,22.25270519905129 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark51(1.197666351338114,12.67503128710024 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark51(11.98569719258819,12.922176403402354 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark51(11.997201104819936,31.379009755175474 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark51(1.199840094800411,30.69857762384623 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark51(12.000548596487615,13.139980363090004 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark51(12.01542838985118,37.98457161014881 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark51(12.020674402016667,37.51953759040376 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark51(12.021362016547016,32.765527728060135 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark51(12.03217806427645,34.654840970695346 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark51(1.2051226046410903,25.628330416410947 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark51(12.056640356951462,33.01879412016518 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark51(12.06023295979952,31.35846499978058 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark51(12.061922545833113,29.12753726620852 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark51(12.069767791489568,34.082699343098454 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark51(12.07517973196191,13.854579992769523 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark51(12.075893104614039,29.808679830838315 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark51(1.210107104568607,11.728365118944524 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark51(12.101490898213015,15.142348327612055 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark51(12.115310349008809,34.98868594655593 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark51(12.128960649090232,20.406399666365175 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark51(1.21351908045227,8.572774971128155 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark51(12.138397978259931,23.805963278029935 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark51(12.140910014580513,29.379315551529686 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark51(12.144176601170955,34.164825658938156 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark51(1.2144568030613243,29.859825053787347 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark51(12.153814900956348,13.917862528996821 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark51(1.216183236563488,40.46292670735596 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark51(12.163985341672468,13.145666748548802 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark51(12.175345197849708,26.162631552700162 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark51(12.187160497373876,33.439215562820976 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark51(12.193830577883007,30.126118566064093 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark51(1.2217418030262452,42.96472084878741 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark51(12.227466037124515,28.7735358745297 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark51(12.227811352771312,29.657045158937166 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark51(12.227868160127692,14.221252315322403 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark51(12.231500078737142,14.539728392077222 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark51(1.2233856433107597,18.208311890796836 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark51(12.239810100458541,14.140456710767197 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark51(12.241620215070975,23.959050593052652 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark51(1.2246693194765754,39.40638020806111 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark51(12.24705920145281,14.636045805918078 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark51(12.255422504892422,36.20972267238079 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark51(1.225849268719685,9.933653956891746 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark51(12.26859573739327,20.03127074916094 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark51(12.280120170857018,29.06079870289554 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark51(12.280922056080213,20.357453787319145 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark51(12.297189833696876,27.97201797396926 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark51(1.2318076700649545,48.76819232993504 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark51(1.232739651413544,23.964509083566526 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark51(1.2333010788680892,9.614168249721693 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark51(12.358660400612525,17.997897661267274 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark51(12.379202906033555,37.07854900415575 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark51(12.389202870563153,29.18469086385244 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark51(12.399503620841614,36.82368683842299 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark51(12.39998603664441,16.06222238457258 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark51(12.400025812909341,37.267751745662686 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark51(1.2404267565030693,8.482224845374702 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark51(1.241907532482248,45.58863122318119 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark51(12.42039025341522,29.899825724222154 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark51(12.424260929573279,14.522905875880227 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark51(12.443778781876148,15.706355179147664 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark51(12.449365885950886,13.70099392681551 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark51(12.456729049885439,33.91949323039631 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark51(12.45742178473665,16.347447974040364 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark51(12.463342266970812,20.334498455307326 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark51(12.479960582564068,37.520039417435925 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark51(1.2481287125516882,22.726680900581037 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark51(1.24816825785076,11.420770556029291 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark51(12.499159705116103,17.600650628340365 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark51(12.504188329525249,21.25710021582141 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark51(1.2505497542981008,25.545277911004973 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark51(1.2513345003589897,46.64773640441024 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark51(12.5141888382813,35.28329439191094 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark51(12.523835871382659,30.990621118885542 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark51(12.529162620079148,18.27729340510409 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark51(12.540975458491019,37.4537625178304 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark51(12.549296058558042,35.26054760337922 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark51(12.551377767337566,18.612161581294835 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark51(12.55406471527769,13.608789958350258 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark51(12.558725394781455,37.44127460521854 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark51(1.257416995493085,11.383828863690276 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark51(12.581513870484457,25.895475655589323 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark51(12.581923811096345,17.231108623036334 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark51(12.588724501472996,14.74699145209722 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark51(12.597122204721991,18.798193537526334 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark51(12.62893180972003,36.25875423622466 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark51(12.631334543877173,27.369517444005794 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark51(12.644328568683932,27.046040810990817 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark51(12.647544062680112,28.04225238951389 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark51(12.64890797010014,21.345706309315474 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark51(12.66357879184315,26.890702398902604 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark51(12.677297175789406,14.398848026502506 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark51(12.681251664867858,23.02410542770336 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark51(12.699409733821426,15.14346339993233 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark51(-1.2699482060753658E-4,3.3938068523934715E-8 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark51(1.2706757535169828,46.47948722811054 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark51(12.71090461737981,15.488025652939811 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark51(12.713029128633082,30.632162717449717 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark51(12.718536199041196,22.959460056999177 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark51(12.719542480668494,16.770331803940365 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark51(12.7371687528737,14.895909899017838 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark51(12.743686307608911,31.289703775433253 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark51(1.2755217316525886,15.690365249300967 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark51(12.7753838996655,29.380783615175062 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark51(12.79228975181401,35.27234348001451 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark51(12.797892730107556,36.772348972205975 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark51(1.2806755443646836,9.673311985484418 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark51(1.2813985671437962,47.017936634800066 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark51(12.851265539701288,17.60417358736946 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark51(12.853670104942765,23.792662186332024 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark51(12.861640050487267,33.300218162956725 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark51(1.286516396984453,17.52491034029397 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark51(12.880368853606456,34.76498763057839 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark51(1.2882616747855309,44.68083642994205 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark51(12.888351924524784,19.232307078050923 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark51(12.895229748613971,20.408779652526945 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark51(1.292606966419541,22.696401181170316 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark51(1.292796509010378,46.40481524787869 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark51(12.93283493033077,14.46294725988583 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark51(1.2937870350316878,9.921815151829263 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark51(12.945778705580913,37.05422129441908 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark51(13.000990208805405,34.73859440722137 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark51(13.010815683764875,29.43626698566058 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark51(13.019540910224123,31.953503201099494 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark51(1.302066468588678,22.59553524405448 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark51(13.022805234623604,25.013034165657984 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark51(13.029696115630557,33.09836881112284 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark51(13.035430466539083,14.623251290098832 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark51(13.035530891926534,36.964469108073445 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark51(13.051660058582133,19.74262727964031 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark51(13.057577566077036,31.223155098093002 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark51(13.061972851687287,24.527936039570974 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark51(13.064437743970103,34.444529798387464 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark51(13.068599038659514,35.800530963180165 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark51(13.071906279789323,16.648518708645213 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark51(13.075036974934306,14.097698096103231 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark51(1.3075212149866324,10.13951156912607 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark51(1.3089560408014542,29.276102588359947 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark51(13.091193207274742,25.548321750403375 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark51(13.093279371166574,36.906720628833355 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark51(1.3096882858149446,10.663080144482251 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark51(13.099126022391431,14.034385380014427 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark51(1.310021283645085,11.224923999816966 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark51(13.100552898055572,25.22205540992443 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark51(13.104199563653504,14.880378572849278 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark51(13.1081212910358,22.126654368696876 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark51(1.3118364538886595,17.00114967547384 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark51(1.31278096040037,22.272906453594487 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark51(13.138090968326608,33.53255236218317 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark51(1.3141856005968118,18.918461434547766 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark51(13.150025066156815,22.05741066813343 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark51(13.164537456596534,25.373839937624993 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark51(13.173322173773784,19.529819382256903 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark51(1.3181911836871052,45.12548901866242 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark51(13.185549178016913,24.599238368551994 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark51(13.188796557058453,25.491383088168874 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark51(13.19166279070518,36.808337209294386 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark51(13.209669076187083,29.857588501957594 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark51(1.3215253037526082,48.459941850752614 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark51(1.3241045725326899,16.85160233073168 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark51(13.242565826386482,18.738511522218104 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark51(1.3266072625816463,35.81366670515959 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark51(13.271687682581407,20.612286729300788 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark51(13.279385927657477,14.14698342189493 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark51(13.284466931181754,14.520362759530698 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark51(13.291263493742434,18.943849876551553 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark51(13.298635158351573,35.32608638502877 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark51(13.299272795321642,20.931879167436193 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark51(13.30220390290782,34.041522761474596 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark51(13.307993646715488,25.894644163728813 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark51(1.3308429461183806,15.136504817319135 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark51(1.331897743288451,26.916216301965548 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark51(13.321425676695739,19.85619870266997 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark51(13.333391517648678,21.821274097021103 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark51(13.336019419187483,16.522858133420144 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark51(1.3348203995730898,30.372409674407635 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark51(13.358493561893702,24.65840670742911 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark51(13.361977449880408,15.537072260610074 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark51(13.36582075150578,18.40296491938483 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark51(1.3379126604459373,12.491408446310999 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark51(13.380058465741755,26.615628780150885 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark51(13.381249920631205,28.027417371362105 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark51(13.389414872226183,20.784673228135915 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark51(13.399412920875633,14.377139119559416 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark51(13.408441123215553,14.253298322532503 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark51(13.414333534473982,14.800199959709005 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark51(13.43065946076159,22.15603905720407 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark51(13.436944351993674,29.57525986088271 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark51(13.441160937267355,23.667875194075563 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark51(13.455191488158032,28.867312787911878 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark51(13.460468148324876,23.1312531578087 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark51(13.466353974958324,15.788794269086878 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark51(1.3469973016396324,16.3490536172678 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark51(1.3473619961534382,30.470379458651507 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark51(13.474372042215254,15.668565371233633 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark51(1.3477388335065115,35.81889143951136 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark51(13.481325167545037,14.540460658205395 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark51(13.484275467831793,36.50346851074485 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark51(13.48555935004752,16.13105720798019 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark51(13.506492224083473,36.493507775915646 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark51(13.508325145173387,25.819904644492794 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark51(13.51503858103895,36.48496141896104 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark51(13.516769269016322,30.849523530567524 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark51(13.524231394938653,19.891221583512504 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark51(13.524539330345561,33.634690629785155 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark51(1.3532386833107068,36.01064180551929 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark51(13.53581050486914,36.46418949513085 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark51(13.54791058503244,28.380549182459475 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark51(13.548472210590347,15.643874767732285 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark51(13.556550293246346,25.073578350298547 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark51(1.356804925926042,34.92710773312637 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark51(13.572332939544808,18.708371270701946 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark51(13.58559948790505,26.391831565856933 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark51(1.3596379798664984,12.71037174613455 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark51(13.613193021934174,16.257986925975572 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark51(13.61359580468364,25.436226267939333 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark51(1.3615345033390795,38.305246661800936 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark51(13.618068250705889,35.61906870872434 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark51(13.619147089295197,33.39589749370211 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark51(13.626970712744594,25.122694372518637 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark51(13.633394828253742,20.071744998697326 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark51(13.633959127411574,14.483680915775459 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark51(13.645546905194166,26.16468352027927 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark51(13.646314176579025,23.123933318283434 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark51(13.648405900073485,17.328075182653066 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark51(13.684772338832673,23.392795872152305 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark51(13.703083929046713,26.426019173442782 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark51(13.707751796956448,16.253558394540697 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark51(13.70916887026091,14.6816887449312 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark51(1.3711691374221688,28.353882947047836 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark51(13.712752078325948,17.76180530905568 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark51(13.716656107749259,30.217942539553093 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark51(13.725887620437689,31.409378822377363 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark51(13.727762861771648,33.36168012141148 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark51(13.745677124263935,19.029422360620913 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark51(13.747936287458693,30.12605643511401 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark51(13.748050925855004,31.359128898650255 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark51(13.750756193246943,29.763918382704247 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark51(13.754907444773593,16.804498646313547 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark51(13.757879476579362,25.97174041335515 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark51(13.76311425822756,33.127693450174746 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark51(1.3800911148039319,42.38419806738679 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark51(13.801906832321208,19.02917187973823 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark51(13.808389941822895,31.83411560837891 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark51(13.808790409079009,32.6505882102781 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark51(13.81468422151214,20.262698863148533 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark51(13.823192608100861,17.903873210398373 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark51(13.828143223637696,15.244583654427531 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark51(13.832034280203612,36.167965719796314 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark51(13.836787172182216,36.16321282781777 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark51(13.837080755029447,14.67146612817679 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark51(1.3850980299942677,28.61076611519843 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark51(13.852223030295583,25.0741680113555 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark51(13.852836921419282,23.660729344364782 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark51(1.386478340657229,40.432009969182786 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark51(13.869618777864545,15.32309900606238 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark51(13.877010117759752,22.064785532073756 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark51(13.87803716028803,16.696351911709357 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark51(13.884130124743578,22.109364493680488 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark51(1.3894341913706683,9.497557030688014 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark51(13.900413631341442,23.845297673468547 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark51(13.910654164227411,22.96584022182592 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark51(13.91551146588833,14.85196923782177 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark51(13.930280457051587,16.49223498652278 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark51(1.393509119365128,48.606490880634865 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark51(13.937487509073293,25.71240160185353 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark51(1.3945018168732446,32.71349419600128 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark51(1.395541275405975,46.05726290350549 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark51(13.983830556310409,34.82755424812569 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark51(1.4005266762078108,18.676540288164404 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark51(14.006882816301488,35.74028919242921 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark51(14.01217037232469,18.78561752067887 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark51(14.013094758940596,23.8091834492554 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark51(14.020119558118829,21.553959537766332 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark51(1.4028300173139598,26.43280680286017 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark51(1.4032046115252825,25.020792420701298 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark51(14.038151709083692,22.75434188546872 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark51(14.039109311574128,15.503194706215332 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark51(1.404558629682512,27.056561603259667 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark51(14.047094849637816,32.31536084756837 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark51(14.04985964680651,32.88609079182595 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark51(1.405120146517433,30.70258589654648 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark51(1.4059321206842357,48.59406787931575 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark51(14.068831959624447,23.61931492342231 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark51(14.080689957148977,16.519427489256827 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark51(14.095868087397932,25.990781981041835 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark51(14.102504189813994,35.89749581018599 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark51(14.104536065875507,35.8954639341244 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark51(14.105447528344087,17.29453386000732 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark51(14.128089794375413,31.7949066104685 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark51(14.132331446763729,35.867668553236264 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark51(14.132929817155507,24.036011760106387 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark51(14.150735869701947,29.415887072423743 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark51(14.154145581749134,35.84585441825086 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark51(1.4156189250377835,41.502072161891505 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark51(14.15801276447101,28.77885905504678 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark51(14.158979570710287,31.727149382184166 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark51(14.162226881595366,35.83777311840463 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark51(14.163753773225096,18.793293600848443 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark51(14.164088870555716,21.62889625062958 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark51(14.168178292610053,24.4318835293766 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark51(14.175271862147714,17.65114880305515 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark51(1.4184833754411983,28.883437623439022 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark51(1.4216269687528111,16.34906844853721 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark51(14.229906158114318,17.43332240503807 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark51(14.230662676046679,20.8391047086032 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark51(1.4231037279252323,48.13919416212224 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark51(14.237034583474056,20.443446774057634 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark51(14.23738315197998,15.312452722208178 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark51(14.242397280318727,15.177677745211412 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark51(14.242827168114273,16.720717236657975 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark51(14.255181994086868,29.76897369528487 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark51(14.269862717328621,30.777286100548025 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark51(14.281777098836141,15.213185581633232 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark51(14.284810892003662,15.105716553533107 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark51(14.294912661505236,18.003231870521404 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark51(14.305149803858015,25.565205831235915 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark51(1.4311714100099238,42.30736840731154 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark51(14.326748352539664,19.28676811140709 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark51(14.329048144297758,15.950509136297512 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark51(14.334716056251423,18.982215324464093 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark51(14.335986063711886,23.70819731800293 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark51(14.37592949669548,33.7292237035564 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark51(14.38298050822182,19.808518111168354 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark51(1.4390606680401579,32.70753527371502 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark51(14.397623348682572,18.95845165726071 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark51(14.424128789369448,22.91112511494424 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark51(14.437317702908885,20.08176687026844 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark51(1.4441733169553714,48.213322159025665 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark51(14.44390564932985,19.960376192925082 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark51(14.45008775571253,33.15766233720976 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark51(1.445448758785588,37.432256879397386 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark51(1.4465620931518117,18.472877656313514 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark51(14.468415400760719,20.557243822202096 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark51(1.4475270237539588,43.93702357011958 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark51(14.47547493640262,34.078667894827646 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark51(14.48055765117175,34.610902121366564 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark51(1.4496370510703969,48.550362948929326 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark51(14.515017946743995,16.742530216195846 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark51(14.527560363824314,16.031597254306917 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark51(14.536020215984522,20.70846922522209 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark51(14.536747390972332,18.186005097582367 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark51(14.539025985199181,35.4609740148008 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark51(1.4552160661639846,17.187046046181436 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark51(1.4561886827156627,34.1602486315295 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark51(14.58730174808025,17.547298653538064 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark51(14.588614973620793,25.68101363104192 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark51(14.59342599691339,35.3657409490103 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark51(14.596881838351479,27.242476608435666 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark51(14.629556016348914,22.704751919637104 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark51(14.631609201828226,17.862586318413236 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark51(1.4631826656481852,9.589678835836402 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark51(14.631949066912526,15.654805470035507 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark51(14.6328595977877,35.36714040221229 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark51(1.4643096092942813,10.97844003733624 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark51(14.64461940770181,21.336958880004204 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark51(14.646665343918144,28.66304645316646 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark51(14.650355016546968,29.711679933592563 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark51(1.465211258072813,40.18347016339871 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark51(14.668848932963115,22.671746682173605 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark51(1.4680629656365483,43.85851822702324 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark51(1.4686050903292944,46.06121711808626 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark51(14.693652577706047,31.23735904831232 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark51(14.714895253993916,34.86393298222845 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark51(14.715304707620906,33.47460210748344 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark51(14.730674128770588,26.103341148718044 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark51(1.4753863221058907,21.556783963550203 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark51(14.754138829699286,19.23656800979367 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark51(14.782747495908847,19.033987209532526 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark51(1.478914606666553,36.71457645908319 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark51(14.796767733383604,19.52921888597936 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark51(14.799408695739501,24.961248979533337 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark51(14.80710932662383,17.170197489919275 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark51(14.814858388760442,24.49827063714673 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark51(1.481961445390965,42.35050936226935 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark51(-1.4821408671150194E-4,9.841890345522852E-5 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark51(14.830796619928279,15.822666678513087 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark51(14.840474167252424,18.00414721748797 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark51(1.4841210433797913,16.786508463327806 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark51(14.846519054880105,15.77106008677396 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark51(1.4852578938140226,28.389579369564586 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark51(14.85888559116475,21.650181440645568 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark51(14.871325096507121,18.03929858864361 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark51(14.876601600617619,33.25205258952215 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark51(1.4880262588990556,38.23175672210094 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark51(14.886423270725018,30.682494831110034 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark51(14.8902782556072,17.101832779754986 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark51(14.897539010628023,20.951512403459688 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark51(14.902115963810132,27.05988376882395 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark51(1.4903950998767215,44.96468682863076 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark51(1.493161869312985,38.09855387793348 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark51(1.4939697375960765,9.8698318442989 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark51(14.942075744612964,34.00151619252901 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark51(14.94922450987562,31.55802327902157 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark51(1.4951781316340913,8.285491737206456 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark51(14.95320138410466,20.08708779496738 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark51(14.95331259528912,26.1122674451655 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark51(1.4964810109707969,25.072025372685843 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark51(14.966891027374075,35.03310897262592 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark51(14.96983275363391,33.390137748668366 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark51(1.4972496176712289,29.055464035094882 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark51(14.996807140498312,29.83218291849539 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark51(15.003038588486334,16.162273117344995 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark51(15.012412638628648,21.501337576365557 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark51(15.015587088126596,16.15037463667133 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark51(15.027127468916774,20.927310979273003 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark51(15.027944223236744,16.651406404067842 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark51(1.5031722459067964,18.823637925867544 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark51(15.0347850124992,16.78439649053155 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark51(15.04613818527028,17.490792691823188 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark51(15.047201112617174,34.902140279080555 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark51(1.5049416101795572,25.168379588027108 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark51(1.5058607575888452,20.116775770748035 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark51(1.505928592479549,27.8799585655307 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark51(1.5075096665557766,47.131696729518836 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark51(1.5082350292275493,41.306365048854246 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark51(15.093127311654142,30.158220005276462 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark51(15.106953718740527,18.740053351799688 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark51(1.511011191868901,44.757463352883605 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark51(15.131344769798865,32.89508848055755 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark51(15.147430948683922,32.07217617722597 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark51(15.151292485100342,20.506417683820416 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark51(15.166193238526546,27.55498137836547 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark51(1.516720409157696,7.862314261410319 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark51(15.167206043065946,24.768724640736778 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark51(15.184353137795497,24.82446297641908 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark51(15.203089718348977,20.783515374968474 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark51(15.211390618088913,32.112059640340874 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark51(15.211872275164808,16.811527175989724 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark51(15.27221104324272,28.936273966378934 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark51(1.5279483953091013,17.066169758871425 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark51(15.294290011157614,27.01507352353903 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark51(15.294812727369873,22.514399279551014 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark51(15.29854766540879,34.21787962455832 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark51(15.305122496136065,30.28046638382608 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark51(15.309531973566564,26.299929676842098 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark51(15.31596331329365,23.298496462551682 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark51(15.319782807225806,16.370329537038813 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark51(1.533914191287849,28.696087819014735 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark51(1.5343732821622398,27.126545634050927 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark51(15.344570777361469,33.629970949203084 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark51(1.5345771138567947,8.266518969717989 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark51(15.392582072756952,27.725945585080154 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark51(1.5404835877292697,8.757804762037509 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark51(15.408688199866361,22.20771283010916 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark51(15.414623476523516,18.557608552548317 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark51(15.415772273412216,20.543344568428637 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark51(1.5418926960783779,28.927836726719022 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark51(15.422805256616925,26.434769155434637 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark51(15.42850882836624,17.215654139500167 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark51(15.43743534786337,27.153251054868477 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark51(15.44138609961783,19.596298783586263 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark51(15.444544993089536,31.95672718279897 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark51(15.446203731023616,19.386548543113918 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark51(15.451339614226981,28.56826801494995 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark51(15.47231187048278,20.67646159932951 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark51(15.473148485809787,30.1441378098377 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark51(15.475103050540667,34.44622721383686 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark51(15.489595402381891,17.002056493901236 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark51(15.493897002954634,33.72447377721703 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark51(15.496250638907782,32.61202974699131 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark51(15.504531581662988,24.05596541990505 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark51(15.508193129414025,21.129795664828507 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark51(15.508712418360162,24.966332970409226 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark51(15.509501457783912,28.046467049748184 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark51(15.51741176186357,21.876329544417047 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark51(15.539990749364335,16.323877151433887 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark51(15.563211642947365,19.180338391453816 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark51(15.593817163919212,21.714769737222866 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark51(15.600065310812411,31.827577304037163 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark51(15.603363687570535,21.36438750561544 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark51(15.613084260607035,19.718836214242085 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark51(1.5613513815769329,42.31377460438976 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark51(15.641510966107518,27.552650296445506 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark51(15.654173008207948,28.67850487726747 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark51(15.660834075703406,34.28969238539193 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark51(1.5662321134219468,15.086061415090697 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark51(1.567037549929168,24.61767512701094 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark51(15.673694129458866,24.561067403414555 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark51(15.674521074831006,18.163910814559543 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark51(1.5689252904399351,9.903194003454942 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark51(15.69417570165011,26.460573846215112 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark51(15.699590102928212,29.09806074075979 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark51(1.5726256592211598,34.84451430789403 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark51(15.727110223813455,20.810607728484683 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark51(15.737110808394888,32.54946303992213 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark51(15.754495779890632,28.43072141910926 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark51(15.756390150051743,32.58714664804816 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark51(15.76542096887865,34.234579031121285 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark51(1.5772745763244478,7.503305115386766 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark51(15.818276626846568,22.85367234018601 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark51(15.822828816515354,33.37719440946344 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark51(1.582735794841227,48.417264205158766 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark51(15.842877864347102,18.99616901044977 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark51(15.893655290358396,33.97389131424379 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark51(15.901024124326995,28.420518189207257 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark51(1.5902836430622709,48.40971635693772 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark51(1.5920981343428906,34.96134802429381 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark51(15.92311585842927,22.015758312244714 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark51(15.926221646287914,32.99164264437181 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark51(15.936820722335252,16.829717444314113 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark51(1.5942809842731087,13.381487018049555 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark51(15.956809362798507,24.243990422951796 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark51(1.5969043436782329,36.73027867173545 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark51(15.979939575229139,25.50399285194527 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark51(1.5996833958043908,35.09884184596842 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark51(1.6023779799987556,20.984147737155 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark51(16.025563855743655,32.79102130710294 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark51(16.055709921398332,26.068058600527237 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark51(1.605637297919876,22.348681149670966 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark51(16.064792155187348,26.138263176948314 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark51(16.065634516594415,27.13975886565649 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark51(16.066532660022943,18.756310652209237 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark51(16.070584672131716,32.19916371229186 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark51(16.075787977800342,33.924212022199185 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark51(16.10097228890789,23.110125449785393 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark51(16.10164674392003,31.203159195903567 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark51(16.122406450109224,28.52219310725218 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark51(16.12523276858557,24.67939300892276 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark51(16.136679976687994,23.70159328808836 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark51(1.6140290286082148,13.368475147966507 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark51(16.148174032223864,28.724352103211743 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark51(16.161376236637196,17.13577747754242 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark51(16.1665697415945,24.478276643488584 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark51(16.195643703627653,29.145981781367425 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark51(1.6197166190445813,43.67766513682545 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark51(16.204680807486895,19.23661799620031 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark51(16.208141224592556,24.696450445116923 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark51(1.6210137286126347,46.444863688607235 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark51(16.210378705794696,32.069717902277176 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark51(1.6210855608758834,6.384800282780105 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark51(16.21190769214489,20.150828736424018 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark51(16.224278619756376,22.419718498851537 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark51(16.224374041607653,20.91893951477732 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark51(16.24921841003963,17.010831156109468 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark51(16.261577805096604,18.686979838652775 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark51(1.6266757374626817,7.300649876880442 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark51(16.269366788881243,31.365104041153415 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark51(16.273833982224303,31.26004708473741 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark51(16.289492296639168,30.289910292199323 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark51(1.6293730045017014,10.69597549004871 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark51(1.6321399640336796,6.6182210333254305 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark51(16.333078726780343,23.29269579491495 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark51(16.3369497417195,17.151889690857345 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark51(16.354680699964547,26.31886454838738 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark51(1.635890083256399,26.771344207965512 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark51(1.6359532213066075,6.713222198097313 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark51(16.362504877065433,18.08547364670264 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark51(1.6367703824858157,48.36322961751418 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark51(1.6376600419863774,32.34812138539985 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark51(16.387006718777798,26.86944590240701 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark51(16.406895553728134,24.203828673380443 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark51(16.420086961299546,29.291417862221124 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark51(16.42704333508214,33.572956664917854 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark51(16.433811283178077,30.70541063380428 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark51(16.442823067712425,17.509336471569114 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark51(1.6470039425072542,34.52324216692969 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark51(16.484110961334224,26.713800411302202 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark51(1.6492716139303845,43.58656376683427 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark51(16.508872981395555,21.535231544079394 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark51(16.512030291189944,20.16188802049477 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark51(16.51676297709357,33.48323702290642 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark51(16.529589946476847,23.406834290521857 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark51(16.533420887577986,17.58432616867941 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark51(16.535740534410735,19.514743435584748 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark51(16.54094501983556,31.467586737187986 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark51(16.542083518819737,20.86260928510454 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark51(16.578821986065734,27.309269645598285 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark51(16.57888692439434,33.421113075605646 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark51(16.587935833909867,33.412064166090126 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark51(16.590506179893126,25.067947496503805 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark51(1.6592271989360086,17.089578345976264 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark51(16.593718237434366,33.40628176256563 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark51(16.62577300628078,27.374528376800725 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark51(16.626545015620472,17.743658289071657 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark51(16.633216908818426,28.497483510409893 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark51(16.63731164141946,31.236223237125927 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark51(16.648920129775156,18.453588298745657 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark51(16.652408530180146,26.51093042156289 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark51(16.668301521942553,33.33169847805729 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark51(1.6683394944374754,48.33166050556252 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark51(16.700098653215605,28.78617546727901 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark51(16.70796159093871,24.382368999556718 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark51(16.712053484406013,25.441127692591706 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark51(16.714408093966668,33.285591906033275 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark51(1.6715188551236935,35.03830528714147 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark51(16.717746262750005,33.28225373724999 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark51(16.719708349791702,17.531208132391924 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark51(1.6721053805426749,32.319727433648296 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark51(16.722594813020294,32.26629489305867 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark51(16.7338883307838,28.510902723348295 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark51(16.73704291510481,18.422094670726224 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark51(16.737172448138267,18.556318107951626 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark51(16.756698439693565,17.55102804960297 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark51(16.775663860858224,20.459439092779768 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark51(16.78494020638996,18.807108648551292 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark51(16.788011573981024,25.486582363327443 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark51(1.678963351043933,9.00520190140901 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark51(16.803926124363926,18.479041361017835 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark51(16.80633371194897,29.896748339682176 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark51(1.6811157705465547,14.135951842901974 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark51(16.81969712102604,17.67102708720509 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark51(16.822258616719736,17.728233312663647 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark51(16.838761912815016,20.03759230973992 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark51(16.83920206276825,26.987233284877377 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark51(16.83941088279539,30.086759995769683 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark51(1.684045979488709,7.663719466249603 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark51(16.843486164991944,17.623976405512735 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark51(16.85668640820562,17.817445012893323 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark51(1.685966244652903,16.299803210561006 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark51(16.914186447114844,19.973844348592237 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark51(16.928725535320627,17.677692337030273 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark51(1.6930952863925346,8.323215155623018 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark51(16.93714336497625,19.395210045880646 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark51(16.93727479413776,33.06272520586211 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark51(1.6943218140212863,33.53977689051953 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark51(16.956405779707737,18.136088040352185 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark51(16.973192165296112,22.08241752171132 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark51(16.975691164791698,19.24493420135977 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark51(16.97944289151438,25.234211366396735 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark51(1.698309428690493,35.440284623890136 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark51(1.6992870899700705,17.84345041505084 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark51(1.69950887344325,10.445658341421066 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark51(17.00381398998752,31.00765294492041 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark51(17.008120619986332,18.910913530715277 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark51(1.7010961903174433,16.056802184029678 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark51(1.7014945104403978,22.56818000076055 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark51(17.03276075878049,19.484569078216524 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark51(17.03428619585506,29.047805231559522 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark51(17.052146052648155,32.70223499554595 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark51(1.7056947813073648,17.546038771563374 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark51(17.069654560318096,23.88593491815047 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark51(17.08582919834701,23.101630491838435 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark51(17.12590101644902,17.891936070207343 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark51(17.127854257777585,24.999888459823552 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark51(17.1536092308508,23.180124771299802 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark51(17.18239332643966,28.321348364502285 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark51(17.195024598964864,17.93416004411142 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark51(1.7200840031406504,21.79750628364789 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark51(17.223311381344388,25.97377054836683 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark51(1.7228234947000773,48.27717650529991 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark51(1.7235255783747432,30.69822470121491 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark51(17.245756972494803,17.98414963057155 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark51(17.262864985591378,19.56735549171688 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark51(17.27308085930581,21.164315434768042 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark51(17.281764128242543,20.149650588861363 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark51(17.2889042330592,25.12037202464367 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark51(1.7292888720102013,28.937653069414836 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark51(1.730541824682092,16.81146624442924 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark51(17.313632060534374,25.307695654530306 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark51(1.733044172442959,9.028880889889656 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark51(17.334029515197443,18.581803085281805 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark51(17.335182528975054,19.69732285691142 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark51(17.337494810135112,19.091103368851492 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark51(17.356926325680618,21.81172018849918 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark51(17.390247540810535,25.435296298023303 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark51(17.393651912578605,29.374513624654213 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark51(1.7397034622540128,8.427536922121988 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark51(17.42943237557975,27.152448835165615 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark51(17.432505473263376,32.567494526736155 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark51(17.43362975165215,21.953456691823064 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark51(17.4413555099678,28.598912535325496 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark51(17.44591788964445,25.526398137425232 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark51(1.7478085197773368,47.09297341796932 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark51(17.479901716759883,30.298128574746617 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark51(1.7481766312603924,30.522267053957165 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark51(17.487432929022233,21.48826581925742 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark51(1.7489725205540765,8.865883895360454 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark51(17.51548473919287,21.960925075828072 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark51(17.526853393837015,24.20649502424418 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark51(17.5501742050824,27.108020470736903 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark51(17.558732824459582,30.77586705963938 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark51(17.564161510395678,18.788964324856707 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark51(17.577372641367436,26.624329033725267 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark51(17.578223490841197,24.07857970430581 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark51(1.7583315967688975,31.78421618741126 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark51(17.595621980158732,26.24202505297886 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark51(17.59805601905606,20.37244448884512 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark51(17.616791080874766,24.728834894180963 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark51(17.634836592652192,28.60178088123405 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark51(17.648645767616415,18.398153240241427 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark51(1.765493691256566,43.706935846635645 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark51(17.671109641788775,28.661346497891827 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark51(17.675528876963355,21.91891752918511 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark51(17.679500921743056,20.657394915044435 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark51(17.689618395869836,27.913298756756262 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark51(1.7705553785032322,14.811384544549625 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark51(1.7706751366906677,28.658199445301477 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark51(1.7706792866680985,17.155447596255087 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark51(17.739968109843616,24.24156980954173 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark51(1.77449561016725,29.36804491459 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark51(17.754523564748236,32.2454764352517 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark51(1.7765770314898077,23.273962748247513 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark51(17.772365912362442,31.16767286556305 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark51(17.780448566337498,28.576539388964335 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark51(17.804064624121388,23.149024119543096 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark51(17.812993374894532,19.90443172596798 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark51(17.815739940109523,28.09166809852138 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark51(17.828440841506634,21.119790523699592 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark51(17.832732149621293,18.70826185122091 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark51(1.783887786645236,44.597915893985515 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark51(17.84577377304909,31.69557366036021 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark51(1.784662839908762,26.11289360161942 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark51(17.84909232088819,25.88390044868079 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark51(17.85083431124839,22.265460397009093 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark51(1.7854293246037258,43.302430328859685 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark51(17.854347838748446,29.431430090419354 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark51(17.888477012217834,29.63452083045793 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark51(17.89156832593865,28.21810635804053 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark51(17.902842373797597,24.252626803885676 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark51(17.907159526906412,31.92813171081218 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark51(1.7913706715090996,22.681557856273656 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark51(1.7919895931822865,26.018184548554885 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark51(17.92454594704201,27.41086830525688 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark51(1.7925885064922262,30.18175242635408 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark51(1.7933197119808,42.1855203315468 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark51(17.942361381173086,21.352013388626737 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark51(17.98492075357786,23.804062247500895 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark51(17.98543912048025,29.94576598501928 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark51(18.03169943326104,26.78517478859459 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark51(18.03220644249903,26.44449336859404 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark51(1.8037334877472944,6.235691259744343 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark51(1.8051487200328182,30.218633032616424 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark51(18.05867679694802,18.779946653624204 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark51(18.076734023881286,30.590043369109765 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark51(18.093059572320747,18.81946373824594 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark51(18.09358088821631,22.6042284583787 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark51(18.103285128143526,31.896714871856357 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark51(18.105719527729264,25.871954761041977 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark51(18.128731977223623,27.41187146885887 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark51(18.131368742222037,18.850001815323736 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark51(18.13676102324729,21.90964258312414 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark51(18.156812096200525,31.843187903799457 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark51(18.172703191700258,25.793258375852766 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark51(1.8181686106312172,48.18183138936877 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark51(1.8203676543744933,10.936203950771102 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark51(18.209943092928196,18.99642981757198 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark51(18.21484646080502,26.29950413978905 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark51(18.225309998985423,28.240533697400338 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark51(18.245458431354123,19.183849728744875 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark51(18.252877111936087,26.031867926107694 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark51(18.25863841172861,19.254022526704112 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark51(18.261933907838298,31.592609462589827 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark51(18.269416343709807,19.590155051716287 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark51(18.274843380609056,18.999372720755982 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark51(18.276323790789277,23.665950770232968 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark51(18.282409044553233,24.810106372943935 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark51(18.282776344574625,26.50265970459686 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark51(1.8301243012376176,44.760542246765425 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark51(1.83267354713632,29.193354957869957 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark51(1.8331279018518245,14.17874633804989 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark51(18.3345737928166,29.24030811942734 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark51(18.346594327727203,20.066752236660363 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark51(18.347506493778226,30.293049154068598 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark51(18.350795352245285,30.294567962064008 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark51(18.36672226075156,31.40187422889099 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark51(18.370681042681426,21.997902584808628 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark51(1.8373086794440923,33.9551760892511 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark51(18.37605102675512,27.693338973062765 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark51(18.381817359068876,26.94523089286946 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark51(18.395310298395785,27.722727967853828 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark51(1.8432705272789747,7.752272865580295 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark51(18.439659419936426,28.016672428357378 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark51(1.8451136382473499,5.792219608997478 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark51(1.8455567886820192,13.33670253032875 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark51(18.47674741073429,25.896304054151557 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark51(1.847996085566166,20.35576148276259 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark51(18.480327166378615,20.02090127797149 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark51(18.484479008260053,28.934364314896612 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark51(1.8513527291082426,28.19020106246367 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark51(18.537083305876195,25.37079620829512 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark51(18.551711095734078,29.106643550415214 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark51(1.855634646350481,8.691356116672123 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark51(1.8584788821369518,20.055849353018715 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark51(1.860932911978182,30.797649495718474 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark51(18.61028564433427,29.692789631279453 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark51(18.613831554802402,23.91364833772886 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark51(1.86280211070779,11.493511049181151 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark51(18.635818929829085,30.380014949374015 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark51(1.8643583925759657,40.702842952815985 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark51(1.8663962948544963,33.6000084766936 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark51(18.685108770598987,19.454460956680865 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark51(18.696257854418775,28.832120528837606 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark51(1.8726139175626315,45.912026107565026 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark51(18.747276202580004,22.018596438228727 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark51(18.754562912707904,28.910073472435244 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark51(18.755970228616277,23.458906160723814 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark51(1.8763254208399047,7.5507116348480565 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark51(18.769811437107037,26.402998827815537 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark51(18.770253832057122,19.54778562298148 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark51(18.787642583805024,29.696913153561297 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark51(18.797623945984256,22.05383408685833 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark51(1.8809673211347366,46.06198363426066 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark51(18.81054039196661,28.828519120373215 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark51(1.8820402842365525,15.335893803612421 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark51(18.82454716403734,19.618827539916822 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark51(18.850410001659114,31.14958999834076 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark51(18.857345500544152,19.96773689096341 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark51(1.8859766778010538,17.32571483115626 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark51(18.860810064705618,28.35492120388207 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark51(18.863384012838548,21.36495115290775 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark51(1.8869363475042036,7.412041292335019 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark51(18.871372189538477,21.665148003507937 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark51(1.8874297546752246,43.832037851804785 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark51(18.889215188446194,20.6276402778188 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark51(1.8891336032835966,28.97902405041421 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark51(18.892635653649847,19.721420966196618 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark51(18.941257133516743,19.85588323911422 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark51(18.943403282580434,22.37123671414561 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark51(18.964719927121948,26.483283354957265 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark51(18.979533367481864,23.55719853854781 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark51(18.983092159764567,26.40602236604299 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark51(18.9840639935249,25.44007188891249 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark51(18.984582257803424,29.05059615166519 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark51(1.8987930683793195,25.673264154014504 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark51(1.8989744206841124,7.4400477392636475 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark51(18.99588723264283,20.67659802260522 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark51(19.011420303077117,23.273274369865078 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark51(19.021183433555088,30.075385350139385 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark51(19.026998618226372,28.86644532483257 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark51(19.04397734926934,30.956022650730645 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark51(19.06184146674859,28.91959354733683 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark51(19.079374170688524,19.949430773980993 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark51(1.9083025267231335,13.558005942271905 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark51(19.09411586038226,30.445426406332693 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark51(19.12920094120527,30.573746483580123 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark51(1.9134990671912533,46.841086305058184 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark51(19.153057860161454,22.33186752097561 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark51(19.189763056875414,30.57368473369589 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark51(19.205120890927702,28.071149951767126 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark51(19.228772544771402,27.2357689499489 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark51(1.923391994388794,25.215844508946205 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark51(19.26045204707188,21.14011755251572 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark51(19.261883217333946,21.838402831703775 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark51(19.284295623774256,20.772949596519847 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark51(1.9288407147592324,7.523024632723633 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark51(19.328160303403564,23.959221629007985 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark51(19.334032431194473,28.479430880926827 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark51(19.341326726778078,24.459780733804706 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark51(19.354150063534618,30.645849936465375 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark51(1.9358501992986543,8.326733133557184 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark51(19.400838218685678,29.607468080236373 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark51(19.40348065846957,30.59651934153041 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark51(1.9403585582155927,26.7364973789837 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark51(19.40768037150864,20.94865298299522 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark51(19.41970069610454,29.84778665254376 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark51(19.421952104707692,30.5780478952923 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark51(1.9426899705204903,47.32133121032754 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark51(1.9427700161093133,7.140192802634149 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark51(1.9441816469883548,16.536117552849845 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark51(1.945766852110717,20.142279596229272 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark51(19.49493594329536,20.365447287750698 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark51(19.536685078581556,28.830542863030274 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark51(19.549034719320517,29.91929615406503 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark51(1.9569189316786337,6.62027535187994 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark51(1.9577959457805605,6.307615414660489 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark51(19.58686585132287,22.159131342122706 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark51(19.588918875195247,25.895876086390118 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark51(19.589125495169284,26.27242969429182 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark51(19.620512139928195,23.40393449860059 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark51(19.634856577841674,22.82294444225863 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark51(1.9643520743298843,21.090172563367926 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark51(19.671295730289472,27.771297058546395 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark51(1.9678426211213917,32.71326000091139 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark51(19.682396599059345,23.417902025711527 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark51(1.9712264575326532,10.780213649206953 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark51(19.735230308859883,22.966737918638785 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark51(1.9740500138227333,21.384528184494343 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark51(19.755633053705907,23.433067304072424 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark51(19.757947929877247,20.66247761455884 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark51(1.9762282529401745,6.5801430287595934 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark51(1.976491399578146,7.495520027266372 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark51(19.772241380828987,26.47897002300799 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark51(19.789916222988623,24.804633509370987 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark51(1.9795847945030687,24.035308497600695 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark51(1.9806012917691334,6.456840339195622 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark51(1.984620671254845,23.769650753048865 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark51(19.859808176836687,26.353524356711333 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark51(19.897301357238334,22.946098830497746 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark51(19.92942596921536,24.819116859095743 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark51(1.9934895055714126,5.621307763853437 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark51(19.93534206671694,24.526122479424075 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark51(1.9943417360477156,39.88519173157533 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark51(1.9944858874180085,13.360933924782998 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark51(19.958791104860367,27.666835076339567 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark51(1.996135510255698,41.297190007822735 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark51(1.9970890791131426,48.00291092088684 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark51(1.9976907835917324,7.772373810668645 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark51(19.98596415235327,30.014035847646724 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark51(19.986131214319435,22.115844476120827 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark51(19.986499637582796,29.44307331539565 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark51(20.011114561645797,25.948124509756227 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark51(20.016380390355778,21.31686032256694 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark51(2.001693696645816,14.902937216395003 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark51(20.043415416866452,21.946098792660962 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark51(20.04378684292827,26.909893459873487 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark51(20.048903271913574,21.38742127926652 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark51(20.060122716236148,21.514273929613765 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark51(2.0061614078830843,11.45959188131539 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark51(20.061634600153663,24.570173878308537 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark51(20.079030882797525,25.544314722339294 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark51(2.008107839061452,21.22771167187966 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark51(20.10253230152057,24.192004509046043 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark51(20.106075881614018,22.050748308320706 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark51(20.121783036596526,24.27178599705084 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark51(2.0138151899374184,12.49765139129704 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark51(20.138871873698363,25.43027957758195 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark51(20.1570907824336,27.844200787333122 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark51(2.018667605380301,42.22510535940279 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark51(20.21070078109655,23.31023701022461 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark51(20.21831601859285,24.854348094757995 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark51(2.0224908649942677,12.99993689897289 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark51(2.0233055209957485,15.151598836790583 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark51(20.257006866402463,21.194006074214684 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark51(20.265584441491555,28.390579061276327 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark51(20.26963928594961,27.264783963753985 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark51(2.03113224909373,17.53940334501469 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark51(2.031746052307355,8.942334289028736 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark51(20.344182006166008,26.168918427361504 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark51(20.345765147239362,25.093686378412713 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark51(20.36007804646019,29.219021078625246 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark51(20.369851691859246,23.403755845958173 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark51(2.044128751936782,33.15094826960768 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark51(2.0442158568218716,46.95793325288753 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark51(20.475249538336612,22.729672457734182 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark51(20.47793670020333,21.879965697265064 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark51(2.0499306912921753,37.65355263539902 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark51(20.517087991127795,22.343441581002594 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark51(2.05199047441738,27.97986184576064 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark51(2.0532416656346015,24.173802050304616 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark51(20.545926722016706,29.454073277983287 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark51(20.5570894802501,21.7916658732413 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark51(2.055831841577745,13.679163988925595 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark51(20.560349578086985,29.364241653112348 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark51(2.057542035636015,6.171411095367989 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark51(20.58214815500431,29.41785184499568 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark51(20.597291354746034,21.29547499195742 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark51(20.644052046054952,22.72658047029998 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark51(20.66832076629466,24.323295093264363 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark51(20.670965501408418,25.73302299703775 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark51(20.67612035395105,24.463817584890023 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark51(2.0676988641587606,15.010497592826642 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark51(20.67914964291799,27.950927875840776 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark51(2.069353901971496,33.896309986049744 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark51(20.69382173809457,25.602910308189166 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark51(2.071926592264848,27.436085765511905 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark51(2.0759272478688677,8.28630006174439 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark51(20.760663490904722,29.239336509092624 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark51(20.786325196437858,29.14630993763302 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark51(20.82248881132291,29.177511188677073 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark51(20.823813628926175,29.109377073512945 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark51(20.83112798768076,29.129504231144978 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark51(2.08332717883813,21.956021471423103 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark51(20.83613295476019,23.250972759198206 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark51(20.8529774698998,24.618878533080263 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark51(20.858255292684266,22.872539067515884 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark51(20.8590695458239,22.113171890090143 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark51(20.8825903702226,26.812773873110828 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark51(20.88494867232997,26.614296941510787 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark51(20.90180029212347,21.594910306149156 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark51(2.0910114581051857,14.1780303050503 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark51(2.0912350099021877,7.853768151431311 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark51(20.91268301601922,22.257197207726634 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark51(2.091648975169814,47.90835102483018 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark51(2.0922730963042824,28.239099697368005 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark51(20.93398530222923,23.047307255288345 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark51(20.982471094033244,26.691372491879164 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark51(2.0990118563102,17.043422325984665 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark51(2.1017193961448957,47.8982806038551 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark51(21.024869058799723,22.625411917780553 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark51(21.025087497076143,25.259911537724424 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark51(21.049337655765797,21.947224739027902 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark51(21.07781344867351,27.09454025678857 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark51(2.1082975580235512,19.877445770874402 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark51(21.087929871784254,27.01697144907844 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark51(21.095777143942968,25.93772335468627 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark51(21.106589081936114,28.47040380381435 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark51(21.109587215997095,25.2692794458427 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark51(2.111794737832275,15.942968844028215 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark51(2.1128411443982564,25.78479900863152 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark51(2.113606087216084,21.976017244191425 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark51(2.1145273511750275,12.236322373675307 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark51(2.115041138957878,5.445358271662432 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark51(21.15165061197682,25.391258343590792 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark51(2.1159375813663797,12.565715419084626 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark51(21.16747458422985,21.832871303578447 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark51(21.167707461376423,26.737920547483412 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark51(2.1181402964947154,29.14330884716466 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark51(2.11879626365004,23.905680911812354 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark51(2.1190298381696935,5.4191056689303885 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark51(2.1215294376550276,38.096456162158006 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark51(2.123121644586444,5.5447637414957995 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark51(2.1238127443652814,36.61261413521353 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark51(2.125094014316966,41.66921073938077 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark51(2.1271583004797723,16.695184438980533 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark51(21.298561773680156,28.701438226319766 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark51(21.303582975565277,21.980355192300635 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark51(21.32934301422425,26.915007561307974 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark51(2.135127086004701,45.90718682589795 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark51(21.356698805657686,22.518254968014986 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark51(21.359954221834627,28.054240962460113 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark51(21.39415711781649,27.623527887287217 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark51(2.14135925891693,9.204615407799952 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark51(21.424050822210337,26.872221988663142 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark51(2.144695360542279,27.865681953367854 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark51(2.1454971365578217,45.34133762141187 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark51(2.147191857536555,47.648700067820556 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark51(21.479156544206674,27.755630742309577 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark51(21.48039530844766,26.061667447996825 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark51(2.148414296843569,34.5232622649109 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark51(21.516795871884238,25.388736049108413 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark51(21.522361746486517,23.051185469893312 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark51(2.152921596368998,44.7116924712312 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark51(21.537006823706577,22.30866479817375 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark51(21.541694480180993,28.458305519818737 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark51(21.551176361527297,25.71525017228757 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark51(21.606041693396598,24.955090735453158 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark51(2.160887579568893,35.9231298943823 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark51(2.163958253018336,25.657092490824283 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark51(2.1661857905650947,8.985923553122142 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark51(2.1692379525163368,28.049806501962507 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark51(21.697865878298046,24.16722092918755 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark51(2.1704516681955894,23.315805746241498 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark51(21.706977898417207,28.18204157052952 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark51(21.713099543692273,24.660328886916464 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark51(21.714460770429426,22.373547790697835 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark51(21.730949172816636,24.192024359990175 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark51(21.75395662195608,22.52037749860638 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark51(21.759186543665493,25.665635884859526 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark51(2.1786042773614014,6.37882184298914 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark51(2.182807759476219,24.868434123064247 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark51(21.83247462311205,23.79270340437327 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark51(21.837631823569644,26.690874190557746 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark51(21.858156580392507,28.141843419607486 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark51(21.86014025965622,22.883942907663553 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark51(21.89594859934783,24.158945165496377 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark51(21.921167852112177,27.505571882767985 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark51(21.92664227917259,28.073357720827346 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark51(21.950931833560205,27.139971205198307 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark51(21.95981744107248,23.231050210692388 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark51(21.964548404984626,22.793796645485727 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark51(21.987032901597274,22.678372136358362 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark51(2.1989523947890603,28.310001525903914 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark51(2.2014348113194315,42.55481165662542 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark51(22.02943866709721,27.970561332902783 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark51(2.203457325684653,9.293498543334394 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark51(2.2037390458811696,43.670540453955056 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark51(22.057081366460693,27.94291863353927 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark51(2.20587389027736,45.551736678118345 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark51(2.2086358272555353,10.686199527213361 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark51(2.209500058947782,41.136823198307866 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark51(22.110344094154435,27.88965590584553 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark51(2.2120441192399296,27.696441788126407 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark51(2.2142475801239296,47.78575241987605 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark51(2.21445611340329,40.814426633737604 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark51(22.149716977786383,25.821950440043096 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark51(22.15822944633054,23.582416503759408 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark51(22.174483062420173,24.805450460945323 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark51(2.2206601640036876,16.599915998776282 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark51(2.223023565883736,9.996714118282071 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark51(2.2230668473291786,12.442926375707188 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark51(22.251374556308278,27.630048567228172 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark51(2.226457721297918,14.755988793763057 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark51(22.333016126980485,24.968574616235387 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark51(22.351002183932707,23.599491392155073 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark51(22.354812034842524,25.970651684200845 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark51(22.358625189529533,23.95931351511173 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark51(22.393631784034994,26.766080230700908 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark51(2.239558837911652,44.63465644051267 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark51(2.24035541076708,22.603607145319238 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark51(2.2412625049131876,24.23994020972266 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark51(22.4149738815931,23.300520462078268 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark51(2.242845483283304,19.954474361234986 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark51(22.455004064167454,25.670350682999455 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark51(22.465430365157687,23.12095863437251 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark51(22.469991162474372,25.243944171040077 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark51(2.2487593215654673,47.75124067843453 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark51(2.256271603248976,40.84246622217259 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark51(22.586039039110716,23.242978940553257 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark51(22.589050562606957,24.13130462854754 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark51(22.5916799033387,27.221121282673096 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark51(22.604110513506683,27.39588948649331 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark51(2.262439392554108,8.26960819820889 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark51(2.2629332163061804,31.96901359351162 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark51(22.630170883961597,27.369829116038368 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark51(2.2687258584929935,6.475126388067082 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark51(22.69812032833349,24.93736367566295 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark51(2.269903841222515,25.967237671200664 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark51(22.70550924125041,23.374439405015384 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark51(2.2710608068060623,6.680469101118399 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark51(22.733906528339332,25.485501978037505 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark51(2.2746398287989056,21.286585817088778 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark51(2.275050378709949,38.784088729041855 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark51(2.278328019713925,47.72167198028607 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark51(2.278751928906914,44.79842531131578 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark51(22.791099108291917,26.581108801463756 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark51(22.81633993548624,23.737206077865807 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark51(2.2829371461855033,47.18014656120147 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark51(22.86852551824559,24.312844068551115 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark51(2.2897177111466784,43.758343736087426 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark51(22.899552737199528,23.78117375412005 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark51(2.2902502857814255,37.49808911412856 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark51(2.2917243525070283,32.55554701706386 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark51(2.293028350181231,40.001236212392485 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark51(22.93490304543444,26.1301809831932 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark51(2.295402440892424,28.966941230229168 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark51(22.958250848915895,23.635007596129206 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark51(22.967535015153317,24.052426942453337 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark51(2.3031448661957765,5.3026198645230105 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark51(2.306685307491122,22.098181822325145 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark51(2.3076885620414433,5.520006495233588 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark51(2.308445442447791,37.05872165181174 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark51(2.309463772927984,24.16218176588538 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark51(23.097575002200927,24.105830254476416 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark51(2.313992515809929,47.00649075917036 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark51(2.3229743237392135,26.28453676029027 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark51(23.267454594294648,25.889116077015586 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark51(2.3297172298927213,31.446230350497927 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark51(23.341516718759415,24.436489847902063 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark51(2.334793851919585,18.74096311292135 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark51(23.362671099620712,26.637328900379174 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark51(2.340302412404025,9.786048482395325 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark51(23.404902637061056,24.04607323844167 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark51(2.341033501591866,12.688742779366848 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark51(23.413026853619414,24.791299263025014 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark51(23.437415041108117,26.562584958891875 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark51(23.43946357074415,24.798864738006614 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark51(23.481172001654983,25.525334944840665 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark51(23.486573488575736,26.513426511424253 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark51(2.352247904718908,25.63738335479067 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark51(23.556375687056345,25.856021470362904 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark51(23.588078887987436,26.41192111201255 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark51(2.3614381509943243,39.56192046402 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark51(2.3635194354905167,19.905270890216585 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark51(23.72915092335697,26.270849076643024 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark51(23.741233179834452,26.11126988366614 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark51(2.3819069438092413,18.48142212008939 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark51(23.82536039615553,24.46080701802924 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark51(2.3826383753279075,28.803917361663352 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark51(2.3839554671054373,32.67862741189583 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark51(2.3858810298013253,29.730306237482637 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark51(2.386606249154637,18.985958934782808 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark51(23.873588410569027,24.517183669403387 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark51(2.3889332452007466,18.971054111330773 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark51(2.390314401208201,13.460659738471392 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark51(23.91133793154765,26.08866206845223 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark51(23.925196580216202,26.074803419783787 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark51(2.394992411723919,27.934356956838585 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark51(23.969969404695732,25.561926881548032 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark51(2.3973302062706416,9.586721712751839 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark51(2.398824450821607,16.576809160023956 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark51(2.3994263640298357,19.868608598760318 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark51(24.000832099415305,25.69228523630322 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark51(24.006117681555967,25.993882318444026 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark51(24.024819901447344,25.975180098552656 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark51(24.034329830164864,25.82836541181679 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark51(2.4053263959181956,33.956191532380245 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark51(24.055789759415894,25.944210240584027 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark51(2.4066777777406827,28.51748450848541 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark51(24.08040918291396,25.919590817086018 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark51(2.4082660059990104,40.88024761452198 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark51(2.410614751462429,33.87724988268158 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark51(24.115488784036835,25.88451121596316 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark51(2.412198451206777,34.657512489395984 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark51(24.17358896199045,24.846883029087806 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark51(24.19870725657825,24.88256551088428 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark51(2.4234688419755486,11.668106485464037 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark51(2.42356729024603,13.379334845752112 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark51(2.4259645189204377,30.46206801880956 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark51(2.4323331766816483,47.56766682331835 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark51(24.36904375066436,25.471144913281393 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark51(24.400097163021112,25.148712967775438 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark51(24.409969117551206,25.590030882448776 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark51(2.446930854926663,21.176256449442747 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark51(2.4473095688886244,8.479068387881966 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark51(24.510143476149437,25.306457044342295 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark51(2.451815332316329,29.011321150104123 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark51(2.4556775440022705,26.50993519658246 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark51(2.4591551441330943,30.138199679880188 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark51(2.463707695251287,35.714281112796456 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark51(2.4645077929389174,46.10975020977469 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark51(2.466189487284737,11.68159459816988 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark51(2.4664888986081017,35.02869103325048 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark51(2.4684134779173235,42.68472331138392 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark51(2.472154727071654,26.00838924911237 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark51(2.478738710192225,47.52126128980777 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark51(2.478859593113605,5.761133964154309 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark51(2.47902393263648,9.196218804201337 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark51(2.4815273129516555,42.592960864414295 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark51(2.4816216872650925,5.41725849540139 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark51(2.485295612299282,34.9385843908222 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark51(24.945497690500503,57.75471284638971 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark51(2.4986770447879394,10.785594093957059 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark51(2.4990776188935113,15.162981631174205 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark51(2.508178071490711,10.320220972251795 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark51(2.5111275549043057,28.57623355362884 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark51(2.5130912385377306,45.60384173715201 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark51(2.5131030209356595,33.25423872054384 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark51(2.51369669477657,28.844335454591118 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark51(2.524008677427574,19.335355390445912 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark51(2.52406927031285,12.056154461864296 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark51(2.526826483143907,5.8854191736527355 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark51(2.5279680647964913,14.098819825639389 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark51(2.5327347579009682,24.643305145733407 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark51(2.5377823488936,32.28041927239528 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark51(2.538360638994334,36.56671725469434 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark51(2.5387560841537464,43.384926044392245 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark51(2.549789834279098,6.027149174088352 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark51(2.552785936774214,26.425620139755935 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark51(2.5590480946192855,32.069226032849684 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark51(2.5601800348065638,24.82608364526699 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark51(2.564554337609743,19.77862898819241 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark51(2.5652120289429634,23.540454889490697 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark51(2.575691209723942,37.70236561528989 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark51(2.579566156417613,41.06845033304404 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark51(2.582002497260536,33.52825442596357 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark51(2.5837738854886965,47.416226114511296 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark51(2.5854608658522693,13.285810496711164 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark51(2.5895908916361488,38.08650618750767 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark51(2.5896738993233797,12.864660967112513 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark51(2.599856211634287,5.241707088214375 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark51(2.6015080940487705,32.946139457786956 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark51(2.6056812122075854,13.795927090427256 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark51(2.6069120553037655,40.1321444749735 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark51(2.6075039555575046,21.005184341381636 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark51(2.615905012628758,43.502443686521076 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark51(2.617755307779305,39.69137532347179 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark51(2.622697572534989,41.931473083978744 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark51(2.626240153315294,14.13276494992768 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark51(2.6273389635940134,34.44301045813492 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark51(2.6276343060506235,33.89380001650525 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark51(2.6299336211182487,8.28797450280404 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark51(2.656028693923588,39.280609897665215 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark51(2.663008563413,47.33699143658699 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark51(2.664692184187146,31.889300027949247 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark51(2.669596780015811,46.58319781007043 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark51(2.6715600889295104,15.003224319052762 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark51(2.677289381290521,24.754506898500736 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark51(2.679451408954023,13.507331664409676 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark51(2.681726053611172,17.790786994077834 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark51(2.683938171516459,40.34091227556807 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark51(2.684166981592753,7.787417798918938 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark51(2.6853577865723537,10.077617472321563 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark51(2.6947255270508492,28.959915258669497 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark51(2.6976611964153676,16.42563550400422 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark51(2.710112686032403,40.613182372643564 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark51(-2.710505431213761E-20,1.6552900986641387E-4 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark51(2.717177065554125,47.07138756255085 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark51(2.72035053269348,46.866193788661995 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark51(2.722516439583032,24.744296819907547 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark51(2.730070429756644,17.75140813708809 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark51(2.7304598471662693,14.33422105125166 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark51(2.7334905961294567,9.079496695881929 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark51(2.735226983533165,21.419903031039652 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark51(2.738013270384698,11.647101370767885 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark51(2.738104349442267,21.021623879421597 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark51(2.7466601305132627,37.915271895763425 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark51(2.747505369210245,41.390018233995846 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark51(2.7557362579680316,25.194421324964438 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark51(2.7569337985095217,12.544325998719287 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark51(2.758098740403952,35.16285797656715 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark51(2.7745521475761876,42.3691607012571 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark51(2.7779710878844988,20.57953804446211 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark51(2.7836754243476065,30.82204437391175 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark51(2.7901657396263886,25.990013195853763 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark51(2.7918043819589053,5.258420702816411 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark51(2.7929436534590337,17.036113571604034 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark51(2.8037626875608623,26.73997016956187 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark51(2.8056413687902193,19.19170859678347 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark51(2.8096627263182317,47.19033727368176 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark51(2.811483555238354,36.107594945516155 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark51(2.81485007686031,8.408798316503635 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark51(2.8168776233320436,6.582556260114991 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark51(2.822703914096781,31.42758215585016 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark51(2.823886536597246,43.196372211702304 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark51(2.825394717269863,45.85013329195249 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark51(2.8313758460616327,33.43028235921187 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark51(2.832629995787485,40.916069418090615 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark51(2.832792538799424,35.83645422681735 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark51(2.8394351493773513,12.03473433238267 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark51(2.8437728624629415,26.518080996486333 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark51(2.844018420269066,33.26077720745417 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark51(2.846369708833322,12.838802913595316 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark51(2.8587232223103602,27.402044382425647 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark51(2.859238576850146,35.92160826685313 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark51(2.859607304263185,10.686121820575188 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark51(2.8633159291977384,5.5719894711818085 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark51(2.8644400506422585,16.777971085570528 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark51(2.876287426068288,46.85773739010409 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark51(2.8776736861984693,47.12232631380152 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark51(2.880773177264584,8.906205514278653 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark51(2.8829185153885106,25.355972782415108 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark51(2.8881102024997016,12.704308182963501 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark51(2.8905278895951625,39.463578919118504 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark51(2.893173604999788,8.61427318634452 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark51(2.894173690716144,19.93928029374314 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark51(2.895554731257448,26.629302829742386 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark51(2.8970561577632736,37.65609351436788 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark51(2.899018316807421,39.09022621049763 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark51(2.9111692248085914,5.652022448031715 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark51(2.9119072465480684,31.92838977228297 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark51(2.918663525469139,34.072128682957526 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark51(2.926039429537836,46.36740865663654 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark51(2.927683165759575,30.732717751050814 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark51(2.9286928271025374,24.476461726930324 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark51(2.9317409951600073,22.34942983945643 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark51(2.932919399764698,15.783340510938189 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark51(2.9374647673612135,12.38412380319547 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark51(2.9471927875966912,28.07264808598663 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark51(2.957602618263607,18.30146957966103 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark51(2.960319824857052,13.778237001414738 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark51(2.963185756852221,11.36759699890682 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark51(2.963382834160001,6.501884231813193 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark51(2.9666695056292385,26.466208927657803 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark51(2.967584877508102,40.99606560022488 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark51(2.968531188425743,31.566177800049502 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark51(2.973839861432964,21.26090767275764 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark51(2.9853051741082055,34.97112171259863 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark51(2.98746682975046,29.899134670492742 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark51(2.9934136804140308,17.169264513089246 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark51(2.994513228239441,30.357710960941432 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark51(2.9958695106649884,44.79222899881839 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark51(2.998170264590698,39.267036000485945 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark51(3.0020520103515906,6.116571500610732 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark51(3.0067252868263097,24.201548264419912 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark51(3.0112475647709545,23.674828480671877 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark51(3.0122316440708516,12.107455367544546 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark51(3.015140552882876,46.333014111616066 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark51(30.180442035866662,34.31332028127201 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark51(3.0186110749443174,5.452975042644348 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark51(3.020053851037204,16.754397113537962 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark51(3.03099449071172,9.200674132947825 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark51(3.03195661972201,46.96804338027798 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark51(3.0335512638453963,33.582690765046266 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark51(3.0337133660907014,32.051207343831976 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark51(3.0341066275297477,26.243209867782014 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark51(3.0345797320049757,46.44622938492847 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark51(3.036186985129044,42.727145871896056 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark51(3.0389342103176844,15.046132690151127 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark51(3.044250401635504,46.95574959836449 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark51(3.0493735930714223,25.866505829339687 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark51(3.0565717397211305,39.67729417836159 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark51(3.0583308928747233,36.93938801152643 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark51(3.0617708836637263,45.71406756286757 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark51(3.0674192189661227,9.71101482543908 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark51(3.068118564254817,6.103756670275047 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark51(3.068231851978638,18.71401453693855 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark51(3.07246015963824,9.703719627829813 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark51(3.0734047209196405,27.086809789642373 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark51(3.0793178304165227,17.317164158816798 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark51(3.08704479969399,40.657453037091294 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark51(3.089919612938516,37.22187595659855 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark51(3.092121570103056,46.90787842989694 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark51(3.1100699180611624,16.774138085854087 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark51(3.1100853376718334,15.974367863537893 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark51(3.1151566157864687,41.080795144940666 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark51(3.1166130862014967,28.80303435381208 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark51(3.121350011656368,20.987828105927296 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark51(3.1234010535883385,22.220932094314875 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark51(3.1258054308833607,6.755928513473265 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark51(3.128427255274617,12.725360918523165 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark51(3.1315749531039927,18.995139453837425 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark51(3.1322496273959786,12.29045891174853 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark51(3.13329288147386,18.71562410643726 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark51(3.1335506564073086,7.054599433721563 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark51(3.1453511151005955,45.8348975002076 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark51(3.1578947651661196,7.66548505744386 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark51(3.1593833576519668,44.01209183779281 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark51(3.1598575014960995,13.916952120704067 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark51(3.1625030236908698,46.837496976309126 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark51(3.1662153880356216,8.494969777673482 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark51(3.16676163592804,43.86455740547801 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark51(3.1685386161987514,32.55161129258623 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark51(3.168752601399987,20.529950366552313 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark51(3.1767156584925544,42.124037653367395 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark51(3.1799604792714007,6.542829784382917 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark51(3.1802531499944564,36.55557075896846 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark51(3.1821887348860347,28.578035310734577 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark51(3.1868698782906506,36.51046376851224 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark51(3.188200809564435,34.39952908787134 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark51(3.1898289049381505,24.65874214860979 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark51(3.2006259025574764,10.456125716642902 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark51(3.215054635051323,30.472561854925345 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark51(3.225231680425771,46.77476831957422 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark51(3.2254763855578545,36.1136091532355 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark51(3.227617097746869,35.914432886232674 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark51(3.2286523968145318,22.66091940779728 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark51(3.23815591285792,5.677014087595796 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark51(3.238799851029075,26.972285212871903 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark51(3.2461213732024135,35.45174996379026 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark51(3.2528578848267387,42.732863859953454 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark51(3.2620118646561167,5.537207885280111 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark51(3.2669150537805365,34.89696070886569 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark51(3.272639213535072,12.381856978592069 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark51(3.2762196191333857,46.72378038086661 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark51(3.2845639901655943,34.41963787134259 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark51(3.286811345758636,12.806094556495978 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark51(3.2872442906423807,34.70369295186419 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark51(3.289293101615158,41.44111096094741 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark51(3.2974931223223933,45.010875819922006 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark51(3.3019158114232567,43.39331417063909 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark51(3.302546872502603,13.624928623166383 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark51(3.3049162726836556,46.4672815669488 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark51(3.3112623504828207,31.796780503688524 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark51(3.314517664569678,34.8613392725203 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark51(3.317353560766705,21.249519707014613 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark51(3.3211427762160497,23.20686453343515 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark51(3.3230905794421375,45.127607576215894 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark51(3.333352773965106,41.13429232669398 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark51(3.33923140939865,27.874043724321737 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark51(3.344743759624741,46.65525624037525 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark51(3.345348088810553,19.96021064205391 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark51(3.347084988772181,21.495975211652564 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark51(3.347507735973693,6.2833439637039845 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark51(3.3506084086595678,24.203147769565447 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark51(3.35645496741715,23.81399959018411 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark51(3.35799240728001,16.937691692043042 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark51(3.3631257860810706,34.42890972044975 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark51(3.3661595977089007,36.372969230997114 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark51(3.3704574889630123,12.022064896825356 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark51(3.379482266144109,26.953282420120715 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark51(3.3910686578492353,15.559787263068642 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark51(3.396076028235683,33.8992194038934 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark51(3.398724633842452,44.966290601239365 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark51(3.41342145718923,19.813053313978756 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark51(3.416938080404094,30.707677284461994 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark51(3.425674453703209,8.191822061831559 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark51(3.4281288072477594,8.199971039903048 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark51(3.430858881325932,15.701383288708914 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark51(3.4315592352922977,24.84720557411164 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark51(3.438816134155502,45.84725972692192 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark51(3.443808347708193E-37,0 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark51(3.4706871953229204,22.115109510478163 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark51(3.4780577650015942,34.92731146894826 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark51(3.486012091649471,15.57862804335879 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark51(3.4865273003477846,18.159261223740856 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark51(3.5029194465357953,22.41348224444144 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark51(3.510230155259862,18.79687875839626 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark51(3.5103782865034674,6.628909067167484 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark51(3.5170356978931068,24.42172127643323 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark51(3.5234051021003836,23.57170974003671 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark51(3.5263471447949115,28.06491943055167 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark51(3.5301212494668173,7.926695784429356 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark51(3.530972748188958,20.42985181200845 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark51(3.5331070050244477,11.635872280920907 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark51(3.5345280611514625,30.887621466726756 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark51(3.5391531191785788,27.49708416884917 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark51(3.5400327314707027,13.650493038648733 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark51(3.5405861457035073,12.801100303297972 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark51(3.540973510165979,40.636413561191006 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark51(3.5434695446946165,36.34760444654296 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark51(3.5463033079460047,13.419037521674753 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark51(3.5502495957795723,6.801027915679153 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark51(3.559958216467976,43.428500435734776 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark51(3.561423741092824,31.47446722156505 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark51(3.565260843698084,22.781563299122325 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark51(3.5693881394149276,12.374534547550514 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark51(3.5761568064005758,35.76780574076514 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark51(3.598739987967897,40.30291099238519 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark51(3.604511575835531,12.35979119768869 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark51(3.6128012916482533,17.744387141554668 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark51(3.6144293714411493,46.385570628558845 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark51(3.6170713038829803,41.56918030668896 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark51(3.6211945798671366,20.805023740846607 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark51(3.623710839095315,46.376289160904676 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark51(3.6253425920685203,14.66581129987621 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark51(3.6399777018748267,40.31196627673572 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark51(3.6451233170299275,23.146129291885842 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark51(3.651805824184464,43.46797955504837 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark51(3.6551910584631457,44.170197972282125 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark51(3.65567739835531,46.344322601644684 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark51(3.6580059445680035,43.833731172976854 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark51(3.6580819115010144,6.154930304437627 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark51(3.665440909441835,9.624195291742481 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark51(3.6674680453843376,41.441570090716084 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark51(3.6804531009331924,12.041021919991167 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark51(3.681621475401343,41.46352923326074 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark51(3.6851187454355427,27.673308344361946 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark51(3.6987772999728663,11.792077577682122 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark51(3.7066444733625303,44.067915686305696 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark51(3.7169413864228886,21.161953257086964 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark51(3.7319824836246056,18.556558534359198 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark51(3.732520725600793,39.850862194530066 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark51(3.7506667931313977,10.713635744546144 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark51(3.7524168713572976,10.384323060393697 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark51(3.7613177707917202,31.679955372900622 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark51(3.7649955929457803,12.472574216116357 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark51(3.7703360314782524,43.91693929746069 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark51(3.7781480189638135,19.421797647741045 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark51(3.7802869379394988,9.109454619057175 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark51(3.7843927698279174,28.780599387942516 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark51(3.7877542546259804,25.605794555237367 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark51(3.7939303089253364,31.634683086727257 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark51(3.795312441972115,32.21709875913251 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark51(3.803523514063457,24.96931078050659 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark51(3.805302491699834,17.270616035390844 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark51(3.8089346149672725,22.99371315730633 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark51(3.8100470454155335,27.272074850334477 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark51(3.8189067874189675,34.9421583651247 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark51(3.819933950814743,41.959123948659936 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark51(3.826490981490551,39.098849656251645 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark51(3.8283163711658386,35.767139447356016 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark51(3.828895603728327,6.938887384050057 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark51(3.830163522196088,9.381997134800216 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark51(3.8396723648179645,7.837324676161962 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark51(3.8661372956756677,13.030049002359657 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark51(3.867778242440224,31.17941768577603 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark51(3.8685055467673237,41.80353602403727 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark51(3.8700924772102163,27.283308305008646 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark51(3.8716874050466004,5.7759803086808175 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark51(3.87561071494207,38.5890806008434 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark51(3.877478383414612,8.444995388365825 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark51(3.8822482838150023,26.777203877057204 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark51(3.885909340665748,43.64382980730491 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark51(3.8881839974992403,24.002923574848367 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark51(3.8910857433397243,45.6952290211608 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark51(3.891551280741396,13.57217500971548 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark51(3.892592112557608,41.76700091017767 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark51(3.899021552593376,35.911522287998 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark51(3.9006333135609026,9.264777052568718 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark51(3.900961022503509,41.406760363789886 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark51(3.90394367615235,23.182566173455392 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark51(3.9045719729526063,8.566988342186999 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark51(3.9090528286603217,33.91050900170143 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark51(3.920738458904019,12.455244524538458 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark51(3.929307993219794,18.22044118231294 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark51(3.93083175148017,21.190815977595662 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark51(3.9455827768489513,17.500760963518886 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark51(3.9456097236412404,32.561414686470016 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark51(3.951525606471691,26.59316888801419 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark51(3.953496252033787,13.639143361143752 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark51(3.9555162635815755,6.966980371847354 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark51(3.9580043798185187,31.668462300808073 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark51(3.958313047123127,15.67658549943009 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark51(3.9590062741494734,7.959549342141585 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark51(3.9597443151472236,42.75965852585466 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark51(3.9635309761906257,15.094562855556504 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark51(3.969179843096967,30.21702305264057 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark51(3.9894508501332617,37.31110498055804 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark51(39.913792461431456,66.69356653132613 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark51(4.000321914809774,43.353512354851674 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark51(4.008690222666971,29.427540106939233 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark51(40.092306540668744,0 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark51(4.011346444752409,18.528926692369758 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark51(4.0201950071673025,20.142353143316228 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark51(4.021662306919254,10.009194804797232 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark51(4.024159536276642,26.971863062115872 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark51(4.026546187285021,10.494632741684825 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark51(4.0323600710588465,23.158054049145065 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark51(4.038896423423351,45.96110357657639 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark51(4.049381992267513,17.64032913816635 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark51(4.05468627423522E-12,2.013587407364347E-6 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark51(4.05568337843345,16.089515209740313 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark51(4.063182573422392,45.762598550967034 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark51(4.065033360390953,45.93496663960903 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark51(4.077668184045365,14.532957986998227 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark51(4.08168496673305,8.852484699028068 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark51(4.087363502156819,41.25802125752699 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark51(4.087880988347763,24.325730120723165 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark51(4.100849463187188,6.492446349949796 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark51(4.100905847507036,9.21499578595386 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark51(4.103161196759842,26.995575231474064 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark51(4.106216367634062,8.35120967027071 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark51(4.110275575532336,10.781738900521361 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark51(4.140864597804704,45.85913540219528 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark51(4.141714711171602,34.089159862226836 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark51(4.145203605945412,9.465506905592562 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark51(4.151118575570379,22.267891365207902 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark51(4.1533717025353525,13.729996795472886 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark51(4.159000785006725,26.14034027572592 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark51(4.15925334200351,17.905100327408732 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark51(4.159820960274587,9.173016362990111 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark51(4.169739491373093,19.818397929457475 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark51(4.172104585746865,40.51129468487298 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark51(4.175032066238927,6.870614613158324 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark51(4.178318417819355,13.421907367789544 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark51(4.185875574794423,11.144135249209185 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark51(-4.1896824933834384E-5,0 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark51(4.192485193169553,29.34441519170422 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark51(4.195603640818476,18.70087371187823 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark51(4.197338497952987,18.18366287148467 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark51(4.198927032245024,33.84177585570745 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark51(4.2011465656053275,20.033437116715817 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark51(4.202344737956707,42.42676984264594 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark51(4.21294174796796,36.60174391893841 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark51(4.214626509328269,31.95218969267819 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark51(-4.215505588174246E-10,8.100106810230534E-4 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark51(4.227450480869513,25.39199136324969 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark51(4.22842989594254,14.024558222255365 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark51(4.230730024612868,20.421913242838087 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark51(4.23586195605003,36.71536538936465 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark51(4.241109595494223,11.465260353851875 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark51(4.241212242626901,7.570665391802152 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark51(4.241638181028364,41.14099584582408 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark51(4.249823356976989,42.65325608516878 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark51(4.255019759150581,45.74498024084936 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark51(4.263971458990383,20.754984283364067 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark51(4.267308404272834,18.711773733270334 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark51(4.27048566638215,19.464908881039932 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark51(4.279771679267924,7.043583547198828 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark51(4.299366939958659,35.14824662212334 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark51(4.303609815504373,13.18623994074892 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark51(4.304262395154666,30.060275072862453 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark51(4.321451272413881,21.48392946692295 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark51(4.333046931559666,29.932025319009057 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark51(4.336193990181442,26.80409022054002 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark51(-4.3368086899420177E-19,0.005733531759294845 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark51(4.3590067533685755,33.259028549378 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark51(4.366717559257161,45.63328244074283 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark51(4.3798152423992605,19.419618980230993 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark51(4.3799220223272926,13.205878996823529 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark51(4.37993734411041,36.01420972192057 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark51(4.379996936728617,36.65607971455191 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark51(4.382706260901086,7.99911524924975 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark51(4.387869534904283,12.360516796492476 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark51(4.390491203755033,45.03715062916477 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark51(4.406862263062067,36.253115196026926 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark51(4.4236177547536,29.43673866734774 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark51(4.429675374236467,18.699799707637382 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark51(4.438547222677785,45.56145277731977 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark51(4.441218431613862,28.298063456762236 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark51(4.457657686830366,6.562883972712454 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark51(4.461393338573069,40.33185279408478 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark51(4.470158065437359,13.873378702332067 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark51(4.4727813468704625,23.569155309452356 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark51(4.484299566041145,31.886803907730155 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark51(4.509483936143204,34.59880678150412 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark51(4.5261978072015125,43.96687596640973 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark51(4.528723379205985,44.97351901679221 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark51(4.529147600396044,22.900214580142148 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark51(4.5308395901548835,6.292955319500052 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark51(4.535215183559771,31.284979108130187 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark51(4.543648887387894,11.070219368301792 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark51(4.548512028066039,42.18730201577212 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark51(4.54965339789031,31.329329620822477 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark51(4.557889125038159,38.70262005015505 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark51(4.561474556343656,32.96357661339435 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark51(4.5665805135372235,21.271985753473615 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark51(4.5668722596071545,44.2363729911175 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark51(4.568104164016631,42.897129699570655 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark51(4.573007623504427,30.147015154147162 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark51(4.594491207220926,25.816225833853593 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark51(4.596056647028604,30.30845738456179 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark51(4.601558408876656,44.53395437122137 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark51(4.607819825340712,41.12122443120063 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark51(4.612419966999212,30.54018401531667 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark51(4.617520377537746,8.967226039845855 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark51(4.618506574843934,6.431438837347429 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark51(4.629665434846544,24.443480105774753 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark51(4.631487475495561,26.933010815097475 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark51(4.636902044819038,10.971231057665392 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark51(4.654904615385419,30.536280935594704 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark51(4.666501187799184,33.00424110383565 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark51(4.668328462896994,36.735122073684295 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark51(4.678569778006448,39.204046466713066 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark51(4.678995648191119,43.10345486152278 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark51(4.68829401007649,36.10627363095841 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark51(4.7006977314825455,32.753011992187396 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark51(4.706842147158952,27.704427707736315 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark51(4.711638301833432,6.581018973054739 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark51(4.713762100637837,19.33379918012777 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark51(4.717177328963373,13.259324127058349 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark51(4.722114883270365,25.677752292661864 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark51(4.722642717072588,14.990310861756953 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark51(4.731417788601533E-4,1.7268333817458577E-5 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark51(4.734353917905305,32.98309156945396 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark51(4.737706320924758,10.522841144560786 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark51(4.747357829217752,33.293204073852735 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark51(4.7499601217438965,23.566957515246017 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark51(4.7529754919416405,42.58174764848965 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark51(4.756506569832865,39.009236281878145 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark51(4.761046486591809,32.580112824558825 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark51(4.7624578395435435,33.83397081495792 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark51(4.7663925604827,31.914400307610833 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark51(4.769026874030612,40.905970793659606 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark51(4.780590399583597,9.943813831580801 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark51(4.78895302683631,8.128352200243413 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark51(4.789605518587919,43.9497462536805 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark51(4.792741623546277,44.68731618891124 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark51(4.796979125890019,7.982123696919018 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark51(4.79740136713621,13.591338168264102 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark51(4.798811770348685,12.089318746594003 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark51(4.803376566802115,8.10089207547125 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark51(4.804063478963272,22.287716189656408 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark51(4.805772438715849,16.67488903631454 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark51(4.827050447598353,14.430503173547464 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark51(4.828292236765179,8.90382945906343 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark51(4.8323106252090895,21.96179935117123 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark51(4.837436475967792,18.75401762817455 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark51(4.838748248320256,20.84523079852196 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark51(4.844155000109549,17.135437984062378 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark51(4.844725751635664,12.35996961814314 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark51(4.851820115341784,27.060387037774674 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark51(4.853056949044785,10.163915571580631 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark51(4.854859489646566,45.14514051035343 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark51(4.855370020325495,32.84638138888306 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark51(4.862609228444848,41.23025840618155 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark51(4.8647716443024365,29.86878426349722 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark51(4.869550909989584,45.13044909001041 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark51(4.873353310537553,36.01066723933829 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark51(4.876984340952134,40.472396663124215 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark51(4.8771563934698605,20.760083492338694 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark51(4.879098682866317,13.954945693241157 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark51(4.879406680823024,28.5539577205667 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark51(4.87977083075144,41.4582941918776 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark51(4.889392537686405,37.004590794835906 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark51(4.890902242283616,37.21161864029688 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark51(4.896739206766327,33.94222441031016 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark51(4.903182732017569,27.97691521741487 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark51(4.915466627016855,40.02263372574873 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark51(4.919182108976145,38.70835194706808 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark51(4.919754030917673,33.18926840731743 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark51(4.920787305753983,9.370408550125635 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark51(4.922024919153117,36.584853959468745 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark51(4.927702171026601,45.07229782897339 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark51(4.928981129277048,25.371992439818285 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark51(4.929441246746585,26.015806858225503 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark51(4.929959659274047,20.517172845465524 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark51(4.943027005277971,25.57924380001542 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark51(4.945678114820879,35.090097383159076 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark51(4.950249699147619,7.383772892802213 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark51(4.952704390919976,14.985491091745711 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark51(4.956129520169526,14.520380832974496 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark51(4.978343723408287,6.540337019475429 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark51(49.84569003777452,78.83938665132209 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark51(4.9852865037828735,13.558311523552973 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark51(4.986234011532406,11.452633512150783 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark51(4.988678477318501,23.158521592278063 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark51(4.990299251128732,11.321287470735626 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark51(4.992755268249159,45.007244731750816 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark51(4.994338738559259,45.00566126144071 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark51(4.999286139317373,29.410753166143024 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark51(5.006908756934954,7.049641707027608 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark51(5.008122593419046,16.300034688194472 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark51(5.009415378349716,6.938078512378155 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark51(5.010426725561126,12.248458101014421 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark51(5.019779945639797,19.01366944441844 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark51(5.020093261808768,43.625903444946545 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark51(5.027871433937108,43.900813456055886 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark51(5.0287462611641125,16.8997481420113 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark51(5.033390450078883,15.287065476189781 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark51(5.033467408342999,15.112423406168432 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark51(5.0345934841360815,20.672419096760407 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark51(5.034600138980778,9.688676828682773 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark51(5.03510766654793,12.907291645456809 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark51(5.041628093945349,20.162668370193586 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark51(5.042169947492965,44.14390462976408 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark51(5.046530773433176,26.977409808149105 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark51(5.0523715736464325,37.107834288200664 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark51(5.05530893458041,8.533205024946568 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark51(5.056335127863627,13.562735370755746 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark51(5.056793333570566,11.63356213746135 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark51(5.068927930225321,11.837791344952393 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark51(5.073272490604182,44.763499452919234 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark51(5.078772041297967,23.258302359181386 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark51(5.084752700783639,37.19472031671353 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark51(5.103518175564268,34.95581475582935 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark51(5.104276525046945,8.400515002961683 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark51(5.113460168127105,7.367791674767446 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark51(5.1196895278762895,26.34229610039118 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark51(5.127335191772035,8.032586033687473 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark51(5.134343041544369,15.485901682193685 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark51(5.142385045229079,7.7957666742528176 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark51(5.1500338572875375,21.657329653827034 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark51(5.150425127810649,25.498917952604927 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark51(5.152408682969552,8.697101425158607 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark51(5.153496351121051,44.846503648878894 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark51(5.154359563026631,16.852389575499217 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark51(5.156532000857414,44.84346799914254 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark51(5.157490631646178,22.128414074467344 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark51(5.162849086025247,44.8371509139747 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark51(5.176196975043628,29.2174348274541 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark51(5.1770658405091865,34.76281576661037 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark51(5.179813546335089,27.153695502774 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark51(5.182148027735902,7.3397569297694645 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark51(5.187801731615636,34.31233079677594 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark51(5.198554761365955,19.89195986646996 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark51(5.218095078488389,24.898892774191467 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark51(5.225615301477092,7.66352824599889 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark51(5.226426892717544,44.773573107282445 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark51(5.229360439327493,17.126024427654897 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark51(5.2324665436112525,9.65593841795625 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark51(5.234894341465259,41.842552760009255 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark51(5.239122236570256,16.115708655823283 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark51(5.2463501746443475,26.452736254524957 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark51(5.249625601152744,36.949150421385895 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark51(5.25244574807499,34.82039271416767 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark51(5.258424744184536,40.94801360978459 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark51(5.265736070574121,10.688899859312514 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark51(5.269134486741204,19.63072024975554 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark51(5.2709177447260345,14.812398183048316 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark51(5.272289409621095,12.997138004920956 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark51(5.274619116383235,11.71358747984516 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark51(5.276796701771829,12.459422755179773 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark51(5.279106544507499,8.55056948710184 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark51(5.279808975591465,29.340157685811846 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark51(5.283089755346722,28.143185788267857 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark51(5.285682749108389,13.81008335592459 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark51(5.287440479083671,8.374846989031923 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark51(5.288940894932722,7.561401723332004 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark51(5.291883185433051,40.30518446137256 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark51(5.296252370004751,40.32237355136493 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark51(5.297499294728494,14.69422732923789 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark51(5.298762037235676,16.31687383547444 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark51(5.29982833359918,42.5551398766556 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark51(5.302220937584584,44.69777906241541 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark51(5.303648723458082,23.57919832704208 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark51(5.304233980874457,8.882102502617201 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark51(5.31468463718447,13.418428005008366 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark51(5.331723694514409,9.212633410941327 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark51(5.335077328239956,36.78655813054134 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark51(5.337933859641225,11.001796152623797 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark51(5.338886913688555,19.44289398661209 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark51(5.346372031555873,43.53070755768039 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark51(5.349310212534618,42.72368129505534 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark51(5.349905327353847,9.591492811069187 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark51(5.362843766458852,32.5359820039223 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark51(5.363001916422297,10.495765175109879 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark51(5.3638899376978975,7.493621617017133 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark51(5.367478303738537,17.26348061293514 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark51(5.3710352303712625,26.002090728849893 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark51(5.3716138848868695,40.06866931617566 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark51(5.371751992268798,41.442767961718516 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark51(5.372279568260634,39.85288084781013 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark51(5.378046068671537,16.088353773598712 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark51(5.380513748473035,24.54674869741389 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark51(5.3901854616565,8.5770062982957 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark51(5.391431354276662,12.077900969706818 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark51(5.3946767135320925,23.0369537559598 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark51(5.398538401582982,31.43150834027361 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark51(5.400480493800401,23.16921973597303 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark51(5.406242827054115,7.220455603772706 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark51(5.407343898801518,16.03921210705848 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark51(5.408916788291,42.9916481674849 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark51(5.412189277282934,19.151804652067497 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark51(-5.421010862427522E-20,8.087985633856496E-5 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark51(5.423150172263206,17.49447192847559 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark51(5.426109868677159,22.43131568209276 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark51(-5.431588091604968E-9,0 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark51(5.444032439127653,24.455771688650785 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark51(5.444858887543091,18.40190098293091 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark51(5.458406807786645,32.63357123992233 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark51(5.463547603720254,33.284620734966836 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark51(5.464844473722792,7.336487905021173 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark51(5.472070430321651,36.62357992670647 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark51(5.4734867724856855,33.00566769469498 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark51(5.484591248704291,30.09734543064289 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark51(5.499294731103669,44.1789899420023 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark51(5.50172248607484,41.32638795525181 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark51(5.504954385369938,19.030579568541512 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark51(5.515656502939702,11.830515399531592 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark51(5.517783075616318,44.482216924383664 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark51(5.530996204815878,29.437217421045062 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark51(5.533173273281681,44.46682672671831 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark51(5.539524247119374,10.964110221358254 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark51(5.54242637592364,21.75020730485396 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark51(5.552451123253286,37.88347307274863 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark51(5.552681974312861,21.253983382306245 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark51(55.52725174676101,70.76537434558747 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark51(5.555695701905194,34.27784476096426 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark51(5.5574407825923515,14.986196330781326 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark51(5.558059102648571,32.4357288222277 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark51(5.564935687960112,10.88475906723813 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark51(5.573976945681693,23.440227599531553 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark51(5.577576223422881,36.4883739007272 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark51(5.5845478162278965,7.17833517673499 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark51(5.590150603782888,23.934530886387122 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark51(5.596079260651976,15.994960031776756 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark51(5.598934371393634,44.40106562860636 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark51(5.60379683841416,38.5067986758843 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark51(5.60418700444967,38.57907209710865 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark51(5.606340794998161,25.0367109375957 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark51(5.613201845167225,31.756528144465847 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark51(5.615187807145588,39.986514015585044 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark51(5.62156618784608,9.407500092817173 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark51(5.628179049732168,26.22038903414422 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark51(5.636962642178744,41.46275244777314 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark51(5.64427985168021,9.711968877903061 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark51(5.650486849233822,33.42362368877796 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark51(5.655892700505547,30.970461197559473 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark51(5.658918656934418,15.923895372024305 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark51(5.662873889837456,32.00860089544332 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark51(5.663499347532166,17.7293226272309 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark51(5.669392449964022,33.540923246129125 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark51(5.709992829450684,21.639180954216016 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark51(5.712924212697487,21.748784665132035 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark51(5.716401560762957,17.88541998436969 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark51(5.72856012908278,42.18280245022294 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark51(5.7323754745973705,9.962807531079704 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark51(5.737484489322227,40.92747590782682 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark51(5.749591224734047,30.209122537547756 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark51(5.7534915080630356,33.11503812319458 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark51(5.757232749610736,35.21723540783938 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark51(5.760036165696604,30.92996932449782 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark51(5.776949555808542,28.04981604811462 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark51(5.780446029624635,14.822431016407723 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark51(5.783290048078712,11.912339501926155 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark51(5.788110227185712,15.533303755908761 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark51(5.803050144928224,23.18067873973059 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark51(5.8135142867458995,27.348716417024477 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark51(5.815316609403662,44.184683390596334 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark51(5.816494990899443,31.057445560361316 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark51(5.8200206603047775,20.515030581903375 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark51(5.825184412438137,34.41164769489875 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark51(5.831662086519366,43.98522164816614 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark51(5.832028771354473,29.41141158055882 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark51(5.83285141892938,11.513029399955627 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark51(5.840786906743006,15.205348281620147 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark51(5.849448229604393,39.009180138373736 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark51(5.8507248560629534,7.94623153204202 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark51(5.854492725953772,10.041100754955082 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark51(5.860626390996318E-4,1.3049523490342443E-4 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark51(5.861756786644428,32.264995852004915 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark51(-5.863058339530121E-25,0 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark51(5.864414308013295,14.950526378590084 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark51(5.868505997049041,34.83445514367878 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark51(5.874495693257142,12.546649568838193 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark51(5.885865590973857,11.967576735102867 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark51(5.894078433363644,10.885768516544886 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark51(5.899317975901241,15.521500742981203 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark51(5.899983101268582,8.92798069521794 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark51(59.12649478107258,0 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark51(5.923145281150532,44.07685471884946 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark51(5.929401237792227,11.667024453447453 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark51(5.930763003252949,14.542528562014942 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark51(5.936320498089103,33.46938862783662 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark51(5.9389530063903315,18.109452594011216 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark51(5.939422534404727,30.92176547229311 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark51(5.945051030920595,38.87825803248552 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark51(5.95125636949075,31.090198813295984 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark51(5.952091069513867,9.39745263006418 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark51(5.952122758077067,24.622885498552222 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark51(5.952369462253458,28.166587708087206 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark51(5.953664834294827,26.851256284887928 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark51(5.958705401934807,44.041294598065186 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark51(5.96173955377857,8.84700313963998 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark51(5.963928206547806,7.805866289866032 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark51(5.974737292824656,40.767689945103825 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark51(5.974955212374482,42.928054976806465 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark51(5.976258837371077,15.61943784801987 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark51(5.977662560644376,39.67039675895671 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark51(5.987545907256788,11.833470205521309 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark51(5.988418149940628,33.71789435934869 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark51(5.998954879109377,10.121942063035561 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark51(6.000600473248525,33.29334458042314 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark51(6.010302049516312,13.838752773252835 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark51(6.012980682327033,22.967945354774272 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark51(6.018854671257046,37.764886444265585 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark51(6.019463155538716,38.0860018518286 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark51(6.020297973583608,20.236961964276475 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark51(6.022668579644529,12.671261741233891 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark51(6.02524494767745,29.67872109688416 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark51(6.025600559843113,29.406965098877492 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark51(6.029238172710073,23.812623745351402 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark51(6.030158359564844,42.64299697304827 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark51(6.031534862364342,9.683539412964521 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark51(6.0318491058556845,13.630599095351315 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark51(6.0335057964303935,41.60202860118968 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark51(6.0424409741977385,31.482282881338527 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark51(6.050842916552093,14.512378338163273 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark51(6.060577830690292,42.94954842677177 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark51(6.06471340079888,8.315048915064146 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark51(6.066326143841593,36.54442543641957 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark51(6.066848230986707,43.933151769013286 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark51(6.068145788857592,25.166264546518093 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark51(6.072420365526,12.935917138535387 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark51(6.079673583200389,40.92012854829309 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark51(6.079901510680543,15.249566722520326 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark51(6.082362560194568,24.396287882954553 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark51(6.082386650537174,37.88923595477479 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark51(6.089864102652797,14.478335199695053 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark51(6.097737161355084,15.965719980165758 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark51(6.106482405299076,40.448327409212084 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark51(6.107518167390726,18.06855425222369 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark51(6.110689869127086,41.78131608688631 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark51(6.122930460840408,34.59458205961474 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark51(6.130266531236913,15.254640177386733 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark51(6.135652011156665,25.251376895728185 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark51(6.141093028355101,42.14550033744763 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark51(6.141953245572999,18.93816781919473 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark51(6.146101203683557,8.152199676499492 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark51(6.151840851256068,28.40098211028635 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark51(6.159323072250601,22.23419262811683 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark51(6.164065556822067,38.13439517502377 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark51(6.171501153221371,7.723769354886166 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark51(6.172835621997265,30.76485830639666 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark51(6.176732508936219,34.06250537904715 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark51(6.184020329402173,8.127358813240967 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark51(6.1888091410432935,15.509075057272042 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark51(6.191765952792423,31.00449755186321 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark51(6.193695471831134,31.0425896223949 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark51(6.200508859168636,7.681917726584373 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark51(6.200569882570605,23.745913153391072 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark51(6.2030004000746,29.331225345355847 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark51(6.204587550061547,42.48884486065779 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark51(6.215217681569179,35.67896752041916 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark51(6.220642926837278,8.709071845273186 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark51(6.223922644320766,43.42875762638343 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark51(6.233014832296048,24.697276220565467 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark51(6.2465778548747295,8.858770892335244 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark51(6.250041025881016,43.74995897411778 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark51(6.251889758155642,29.7199801290721 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark51(6.26960702772201,40.911020224271084 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark51(6.2775206405896995,28.832107130191474 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark51(6.28065815945817,14.41364382163151 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark51(6.286315223529328,15.522638578533902 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark51(6.291170571304773,19.142205481190985 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark51(6.29344301976476,43.706556980235234 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark51(6.293996860955247,42.776268684829205 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark51(6.297966770031536,14.00012444337348 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark51(6.32240185575516,28.370246613521374 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark51(6.328939011886568,18.63080637883907 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark51(6.348499464673653,15.355839282102101 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark51(6.367290966903511,12.18700780824058 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark51(6.3819957210025535,42.845833124827294 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark51(6.396419744480406,17.397493757289027 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark51(6.399707176932708,41.137535583574305 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark51(6.410206243441085,15.452794221498731 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark51(6.415449182167137,14.08625524027714 ) ;
  }

  @Test
  public void test2476() {
    coral.tests.JPFBenchmark.benchmark51(6.415809904802089,13.537586009738376 ) ;
  }

  @Test
  public void test2477() {
    coral.tests.JPFBenchmark.benchmark51(6.416070109180765,8.299054586134147 ) ;
  }

  @Test
  public void test2478() {
    coral.tests.JPFBenchmark.benchmark51(6.422559474491109,35.277812499134086 ) ;
  }

  @Test
  public void test2479() {
    coral.tests.JPFBenchmark.benchmark51(6.424559254743883,38.88116956325601 ) ;
  }

  @Test
  public void test2480() {
    coral.tests.JPFBenchmark.benchmark51(6.433373074366202,28.73730498394974 ) ;
  }

  @Test
  public void test2481() {
    coral.tests.JPFBenchmark.benchmark51(6.434078551274297,43.19880996959836 ) ;
  }

  @Test
  public void test2482() {
    coral.tests.JPFBenchmark.benchmark51(6.434251542999505,19.65178869448485 ) ;
  }

  @Test
  public void test2483() {
    coral.tests.JPFBenchmark.benchmark51(6.444575547654139,40.48292497062357 ) ;
  }

  @Test
  public void test2484() {
    coral.tests.JPFBenchmark.benchmark51(6.446954737831788,19.519651373272964 ) ;
  }

  @Test
  public void test2485() {
    coral.tests.JPFBenchmark.benchmark51(6.447701460316448,15.166773639998524 ) ;
  }

  @Test
  public void test2486() {
    coral.tests.JPFBenchmark.benchmark51(6.466097056993128,10.33640594688869 ) ;
  }

  @Test
  public void test2487() {
    coral.tests.JPFBenchmark.benchmark51(6.474137072459528,39.8499158103227 ) ;
  }

  @Test
  public void test2488() {
    coral.tests.JPFBenchmark.benchmark51(6.476487297828683,25.07936759862413 ) ;
  }

  @Test
  public void test2489() {
    coral.tests.JPFBenchmark.benchmark51(6.4943326507742825,12.814207418686024 ) ;
  }

  @Test
  public void test2490() {
    coral.tests.JPFBenchmark.benchmark51(6.506560803118248,12.84548172233444 ) ;
  }

  @Test
  public void test2491() {
    coral.tests.JPFBenchmark.benchmark51(6.508501749067888,10.65753831696496 ) ;
  }

  @Test
  public void test2492() {
    coral.tests.JPFBenchmark.benchmark51(6.52555028728672,38.954266529528724 ) ;
  }

  @Test
  public void test2493() {
    coral.tests.JPFBenchmark.benchmark51(6.5303452772892925,24.86281474187581 ) ;
  }

  @Test
  public void test2494() {
    coral.tests.JPFBenchmark.benchmark51(6.531113710904595,39.39430621500624 ) ;
  }

  @Test
  public void test2495() {
    coral.tests.JPFBenchmark.benchmark51(6.531547367695097,27.898674216776612 ) ;
  }

  @Test
  public void test2496() {
    coral.tests.JPFBenchmark.benchmark51(6.54026800725353,33.82755519516209 ) ;
  }

  @Test
  public void test2497() {
    coral.tests.JPFBenchmark.benchmark51(6.550388237958302,42.71816621946397 ) ;
  }

  @Test
  public void test2498() {
    coral.tests.JPFBenchmark.benchmark51(6.550486433372534E-11,3.751201574175098E-4 ) ;
  }

  @Test
  public void test2499() {
    coral.tests.JPFBenchmark.benchmark51(6.553259628837253,8.301805905970767 ) ;
  }

  @Test
  public void test2500() {
    coral.tests.JPFBenchmark.benchmark51(6.554020081504447,43.199704571775754 ) ;
  }

  @Test
  public void test2501() {
    coral.tests.JPFBenchmark.benchmark51(6.556332685596519,10.660207486560296 ) ;
  }

  @Test
  public void test2502() {
    coral.tests.JPFBenchmark.benchmark51(6.563008191490027,41.86017693163191 ) ;
  }

  @Test
  public void test2503() {
    coral.tests.JPFBenchmark.benchmark51(6.569558197029323,40.62744032261881 ) ;
  }

  @Test
  public void test2504() {
    coral.tests.JPFBenchmark.benchmark51(6.5729428863947135,22.766694469009536 ) ;
  }

  @Test
  public void test2505() {
    coral.tests.JPFBenchmark.benchmark51(6.581800551401358,42.50819769917004 ) ;
  }

  @Test
  public void test2506() {
    coral.tests.JPFBenchmark.benchmark51(6.585838077309077,38.08814758947818 ) ;
  }

  @Test
  public void test2507() {
    coral.tests.JPFBenchmark.benchmark51(6.58588610552782,22.57404254470825 ) ;
  }

  @Test
  public void test2508() {
    coral.tests.JPFBenchmark.benchmark51(6.587372847265604,43.41262715273439 ) ;
  }

  @Test
  public void test2509() {
    coral.tests.JPFBenchmark.benchmark51(6.588104423000047,14.194666057722642 ) ;
  }

  @Test
  public void test2510() {
    coral.tests.JPFBenchmark.benchmark51(6.589890291475513,43.410109708524324 ) ;
  }

  @Test
  public void test2511() {
    coral.tests.JPFBenchmark.benchmark51(6.5960010179497885,29.942143495809376 ) ;
  }

  @Test
  public void test2512() {
    coral.tests.JPFBenchmark.benchmark51(6.605984759009697,21.044397812723133 ) ;
  }

  @Test
  public void test2513() {
    coral.tests.JPFBenchmark.benchmark51(6.6063411829172765,36.778335314411464 ) ;
  }

  @Test
  public void test2514() {
    coral.tests.JPFBenchmark.benchmark51(6.611823223465478,36.94011577067221 ) ;
  }

  @Test
  public void test2515() {
    coral.tests.JPFBenchmark.benchmark51(6.612547820692386,40.143051127117346 ) ;
  }

  @Test
  public void test2516() {
    coral.tests.JPFBenchmark.benchmark51(6.620408956747667,14.610514013385426 ) ;
  }

  @Test
  public void test2517() {
    coral.tests.JPFBenchmark.benchmark51(6.623960426954383,21.72543675817427 ) ;
  }

  @Test
  public void test2518() {
    coral.tests.JPFBenchmark.benchmark51(6.626830316822961,16.41711613359551 ) ;
  }

  @Test
  public void test2519() {
    coral.tests.JPFBenchmark.benchmark51(6.6345184796445125,14.60582698702133 ) ;
  }

  @Test
  public void test2520() {
    coral.tests.JPFBenchmark.benchmark51(6.637304572982927,19.88126271069916 ) ;
  }

  @Test
  public void test2521() {
    coral.tests.JPFBenchmark.benchmark51(6.640082570731366,8.897126891862811 ) ;
  }

  @Test
  public void test2522() {
    coral.tests.JPFBenchmark.benchmark51(6.641502949097401,17.22446407190445 ) ;
  }

  @Test
  public void test2523() {
    coral.tests.JPFBenchmark.benchmark51(6.64698507621668,15.60765118916234 ) ;
  }

  @Test
  public void test2524() {
    coral.tests.JPFBenchmark.benchmark51(6.660922049734026,25.13965084324579 ) ;
  }

  @Test
  public void test2525() {
    coral.tests.JPFBenchmark.benchmark51(6.668532529137508,32.78703806224914 ) ;
  }

  @Test
  public void test2526() {
    coral.tests.JPFBenchmark.benchmark51(6.669170279005172,25.94812775308428 ) ;
  }

  @Test
  public void test2527() {
    coral.tests.JPFBenchmark.benchmark51(6.673422529691138,9.802878661592363 ) ;
  }

  @Test
  public void test2528() {
    coral.tests.JPFBenchmark.benchmark51(6.684897664627876,43.3151023353721 ) ;
  }

  @Test
  public void test2529() {
    coral.tests.JPFBenchmark.benchmark51(6.692319037231059,13.325977685725448 ) ;
  }

  @Test
  public void test2530() {
    coral.tests.JPFBenchmark.benchmark51(6.695967495672056,11.111197593270575 ) ;
  }

  @Test
  public void test2531() {
    coral.tests.JPFBenchmark.benchmark51(6.719087520313451,7.994993834885733 ) ;
  }

  @Test
  public void test2532() {
    coral.tests.JPFBenchmark.benchmark51(6.723131220653116,30.368660569768736 ) ;
  }

  @Test
  public void test2533() {
    coral.tests.JPFBenchmark.benchmark51(6.725400893200376,27.498595215393735 ) ;
  }

  @Test
  public void test2534() {
    coral.tests.JPFBenchmark.benchmark51(6.731440953783334,25.923654490670728 ) ;
  }

  @Test
  public void test2535() {
    coral.tests.JPFBenchmark.benchmark51(6.735263441698592,36.29853493888072 ) ;
  }

  @Test
  public void test2536() {
    coral.tests.JPFBenchmark.benchmark51(6.740202557990145,27.860385588757453 ) ;
  }

  @Test
  public void test2537() {
    coral.tests.JPFBenchmark.benchmark51(6.740624919973271,40.74995739154201 ) ;
  }

  @Test
  public void test2538() {
    coral.tests.JPFBenchmark.benchmark51(6.746978620790983,22.499227521637806 ) ;
  }

  @Test
  public void test2539() {
    coral.tests.JPFBenchmark.benchmark51(6.775422984598741,43.22457701540124 ) ;
  }

  @Test
  public void test2540() {
    coral.tests.JPFBenchmark.benchmark51(6.797059990436313,13.651719783424412 ) ;
  }

  @Test
  public void test2541() {
    coral.tests.JPFBenchmark.benchmark51(6.803009984734842,32.457086569956175 ) ;
  }

  @Test
  public void test2542() {
    coral.tests.JPFBenchmark.benchmark51(6.808496035055825,35.99880502065753 ) ;
  }

  @Test
  public void test2543() {
    coral.tests.JPFBenchmark.benchmark51(6.811173352417029,10.829272324835856 ) ;
  }

  @Test
  public void test2544() {
    coral.tests.JPFBenchmark.benchmark51(6.817068798402175,12.369110284418667 ) ;
  }

  @Test
  public void test2545() {
    coral.tests.JPFBenchmark.benchmark51(6.820636039260108,43.179363960739884 ) ;
  }

  @Test
  public void test2546() {
    coral.tests.JPFBenchmark.benchmark51(6.822955251492118,11.07411611931201 ) ;
  }

  @Test
  public void test2547() {
    coral.tests.JPFBenchmark.benchmark51(6.823740987665921,27.756379609949718 ) ;
  }

  @Test
  public void test2548() {
    coral.tests.JPFBenchmark.benchmark51(6.827348446796771,43.172651553203224 ) ;
  }

  @Test
  public void test2549() {
    coral.tests.JPFBenchmark.benchmark51(6.828746764128539,23.978877238078795 ) ;
  }

  @Test
  public void test2550() {
    coral.tests.JPFBenchmark.benchmark51(6.838860401013296,9.889033855691736 ) ;
  }

  @Test
  public void test2551() {
    coral.tests.JPFBenchmark.benchmark51(6.846008894191272,41.14482416109061 ) ;
  }

  @Test
  public void test2552() {
    coral.tests.JPFBenchmark.benchmark51(6.846903461403528,10.881882298002992 ) ;
  }

  @Test
  public void test2553() {
    coral.tests.JPFBenchmark.benchmark51(6.847399936102079,15.066517069431029 ) ;
  }

  @Test
  public void test2554() {
    coral.tests.JPFBenchmark.benchmark51(6.850597282347451,13.688608485234141 ) ;
  }

  @Test
  public void test2555() {
    coral.tests.JPFBenchmark.benchmark51(6.855794124013315,13.419576423643548 ) ;
  }

  @Test
  public void test2556() {
    coral.tests.JPFBenchmark.benchmark51(6.85810130438189,24.03471039110265 ) ;
  }

  @Test
  public void test2557() {
    coral.tests.JPFBenchmark.benchmark51(6.859298448968175,30.712331082279434 ) ;
  }

  @Test
  public void test2558() {
    coral.tests.JPFBenchmark.benchmark51(6.866953821109144,43.13304617889085 ) ;
  }

  @Test
  public void test2559() {
    coral.tests.JPFBenchmark.benchmark51(6.869520707748336,16.08704806530173 ) ;
  }

  @Test
  public void test2560() {
    coral.tests.JPFBenchmark.benchmark51(6.877556116088897,35.59794361252463 ) ;
  }

  @Test
  public void test2561() {
    coral.tests.JPFBenchmark.benchmark51(6.878797822458708,23.32948576173881 ) ;
  }

  @Test
  public void test2562() {
    coral.tests.JPFBenchmark.benchmark51(6.880282918579141,10.649987606105952 ) ;
  }

  @Test
  public void test2563() {
    coral.tests.JPFBenchmark.benchmark51(6.902223718101695,29.730371542133753 ) ;
  }

  @Test
  public void test2564() {
    coral.tests.JPFBenchmark.benchmark51(6.928649362127118,22.754181906849638 ) ;
  }

  @Test
  public void test2565() {
    coral.tests.JPFBenchmark.benchmark51(6.930449286905073,23.840113270119545 ) ;
  }

  @Test
  public void test2566() {
    coral.tests.JPFBenchmark.benchmark51(6.931919949914175,25.484610981919317 ) ;
  }

  @Test
  public void test2567() {
    coral.tests.JPFBenchmark.benchmark51(6.9476553788611355,32.19958459058368 ) ;
  }

  @Test
  public void test2568() {
    coral.tests.JPFBenchmark.benchmark51(6.953030524978697,19.515077862680158 ) ;
  }

  @Test
  public void test2569() {
    coral.tests.JPFBenchmark.benchmark51(6.960240170136387,41.94550610786163 ) ;
  }

  @Test
  public void test2570() {
    coral.tests.JPFBenchmark.benchmark51(6.966148515049667,8.312086927162326 ) ;
  }

  @Test
  public void test2571() {
    coral.tests.JPFBenchmark.benchmark51(6.968181181180896,23.997441145076465 ) ;
  }

  @Test
  public void test2572() {
    coral.tests.JPFBenchmark.benchmark51(6.972178884859169,24.758044474253012 ) ;
  }

  @Test
  public void test2573() {
    coral.tests.JPFBenchmark.benchmark51(6.976573153057174,41.00169067928451 ) ;
  }

  @Test
  public void test2574() {
    coral.tests.JPFBenchmark.benchmark51(6.990127678549269,18.511032833990292 ) ;
  }

  @Test
  public void test2575() {
    coral.tests.JPFBenchmark.benchmark51(6.998678989876158,8.446442623320266 ) ;
  }

  @Test
  public void test2576() {
    coral.tests.JPFBenchmark.benchmark51(7.000097745732219,42.17496047698782 ) ;
  }

  @Test
  public void test2577() {
    coral.tests.JPFBenchmark.benchmark51(7.039062511578976,32.55007666548772 ) ;
  }

  @Test
  public void test2578() {
    coral.tests.JPFBenchmark.benchmark51(7.049136491830303,11.373445138753624 ) ;
  }

  @Test
  public void test2579() {
    coral.tests.JPFBenchmark.benchmark51(7.059767034285343,42.754278149824074 ) ;
  }

  @Test
  public void test2580() {
    coral.tests.JPFBenchmark.benchmark51(7.0601638352272005,30.171330406014476 ) ;
  }

  @Test
  public void test2581() {
    coral.tests.JPFBenchmark.benchmark51(7.061416924691713,34.42653306573692 ) ;
  }

  @Test
  public void test2582() {
    coral.tests.JPFBenchmark.benchmark51(7.066142537454297,32.3503111437706 ) ;
  }

  @Test
  public void test2583() {
    coral.tests.JPFBenchmark.benchmark51(7.081967534969053,38.36345822027306 ) ;
  }

  @Test
  public void test2584() {
    coral.tests.JPFBenchmark.benchmark51(7.1038316179381695,11.421808050285875 ) ;
  }

  @Test
  public void test2585() {
    coral.tests.JPFBenchmark.benchmark51(7.109024323641421,30.418863502407504 ) ;
  }

  @Test
  public void test2586() {
    coral.tests.JPFBenchmark.benchmark51(7.111129153656009,19.64552718933632 ) ;
  }

  @Test
  public void test2587() {
    coral.tests.JPFBenchmark.benchmark51(7.15163400730599,33.152881016317764 ) ;
  }

  @Test
  public void test2588() {
    coral.tests.JPFBenchmark.benchmark51(7.165167217385886,22.875043455679076 ) ;
  }

  @Test
  public void test2589() {
    coral.tests.JPFBenchmark.benchmark51(-71.67513057198833,37.455698068413 ) ;
  }

  @Test
  public void test2590() {
    coral.tests.JPFBenchmark.benchmark51(7.171694368101399,19.807593094614646 ) ;
  }

  @Test
  public void test2591() {
    coral.tests.JPFBenchmark.benchmark51(7.178900292127843,9.411281179430972 ) ;
  }

  @Test
  public void test2592() {
    coral.tests.JPFBenchmark.benchmark51(7.1818260911985305,15.143872183588016 ) ;
  }

  @Test
  public void test2593() {
    coral.tests.JPFBenchmark.benchmark51(7.18240407624873,16.68428393173707 ) ;
  }

  @Test
  public void test2594() {
    coral.tests.JPFBenchmark.benchmark51(7.196126333984097,24.91689882604294 ) ;
  }

  @Test
  public void test2595() {
    coral.tests.JPFBenchmark.benchmark51(7.19712669783064,39.43025183941302 ) ;
  }

  @Test
  public void test2596() {
    coral.tests.JPFBenchmark.benchmark51(7.198790395139085,32.788861799045804 ) ;
  }

  @Test
  public void test2597() {
    coral.tests.JPFBenchmark.benchmark51(7.201395738992787,10.216319350759946 ) ;
  }

  @Test
  public void test2598() {
    coral.tests.JPFBenchmark.benchmark51(7.204355042078532,18.61747639552516 ) ;
  }

  @Test
  public void test2599() {
    coral.tests.JPFBenchmark.benchmark51(7.212799190917394,35.947381287307934 ) ;
  }

  @Test
  public void test2600() {
    coral.tests.JPFBenchmark.benchmark51(7.2201591243772185,22.72951906532721 ) ;
  }

  @Test
  public void test2601() {
    coral.tests.JPFBenchmark.benchmark51(7.227315117249873,33.12751521725406 ) ;
  }

  @Test
  public void test2602() {
    coral.tests.JPFBenchmark.benchmark51(7.229923027678154,9.121474983043015 ) ;
  }

  @Test
  public void test2603() {
    coral.tests.JPFBenchmark.benchmark51(7.233134833978173,31.346228371666996 ) ;
  }

  @Test
  public void test2604() {
    coral.tests.JPFBenchmark.benchmark51(7.239598166158757,26.99315457221722 ) ;
  }

  @Test
  public void test2605() {
    coral.tests.JPFBenchmark.benchmark51(7.2418437011454415,9.428016595925754 ) ;
  }

  @Test
  public void test2606() {
    coral.tests.JPFBenchmark.benchmark51(7.242438189195298,27.766303338141427 ) ;
  }

  @Test
  public void test2607() {
    coral.tests.JPFBenchmark.benchmark51(7.252537222756951,10.50803986996715 ) ;
  }

  @Test
  public void test2608() {
    coral.tests.JPFBenchmark.benchmark51(7.254231849220602,28.00919905204549 ) ;
  }

  @Test
  public void test2609() {
    coral.tests.JPFBenchmark.benchmark51(7.2572095781081565,14.52106107575058 ) ;
  }

  @Test
  public void test2610() {
    coral.tests.JPFBenchmark.benchmark51(7.260077409556587,42.41714695755638 ) ;
  }

  @Test
  public void test2611() {
    coral.tests.JPFBenchmark.benchmark51(7.261422171360138,9.109021859400102 ) ;
  }

  @Test
  public void test2612() {
    coral.tests.JPFBenchmark.benchmark51(7.26172963552753,28.121998068888786 ) ;
  }

  @Test
  public void test2613() {
    coral.tests.JPFBenchmark.benchmark51(7.2634796650845175,25.60523589473182 ) ;
  }

  @Test
  public void test2614() {
    coral.tests.JPFBenchmark.benchmark51(7.26698830846226,26.709378326874386 ) ;
  }

  @Test
  public void test2615() {
    coral.tests.JPFBenchmark.benchmark51(7.271785017622975,24.656234679051963 ) ;
  }

  @Test
  public void test2616() {
    coral.tests.JPFBenchmark.benchmark51(7.278059803365707,26.540414030857164 ) ;
  }

  @Test
  public void test2617() {
    coral.tests.JPFBenchmark.benchmark51(7.283093138233023,40.41209149660071 ) ;
  }

  @Test
  public void test2618() {
    coral.tests.JPFBenchmark.benchmark51(7.28834096354889,37.47805162920136 ) ;
  }

  @Test
  public void test2619() {
    coral.tests.JPFBenchmark.benchmark51(7.288809478774596,13.010815117687173 ) ;
  }

  @Test
  public void test2620() {
    coral.tests.JPFBenchmark.benchmark51(7.290196356856953,9.271019782136264 ) ;
  }

  @Test
  public void test2621() {
    coral.tests.JPFBenchmark.benchmark51(7.304978313875736,15.043859499860474 ) ;
  }

  @Test
  public void test2622() {
    coral.tests.JPFBenchmark.benchmark51(7.307378649885663,18.623548542454913 ) ;
  }

  @Test
  public void test2623() {
    coral.tests.JPFBenchmark.benchmark51(7.313775510525261,41.31078115929117 ) ;
  }

  @Test
  public void test2624() {
    coral.tests.JPFBenchmark.benchmark51(7.319374140076633,36.83075353293677 ) ;
  }

  @Test
  public void test2625() {
    coral.tests.JPFBenchmark.benchmark51(7.320249180515674,16.46663330928027 ) ;
  }

  @Test
  public void test2626() {
    coral.tests.JPFBenchmark.benchmark51(7.32107197504763,21.406761828115293 ) ;
  }

  @Test
  public void test2627() {
    coral.tests.JPFBenchmark.benchmark51(7.325195766539213,38.71083500607152 ) ;
  }

  @Test
  public void test2628() {
    coral.tests.JPFBenchmark.benchmark51(7.342918531157423,25.45734766556815 ) ;
  }

  @Test
  public void test2629() {
    coral.tests.JPFBenchmark.benchmark51(7.346854022799178,35.19033509511636 ) ;
  }

  @Test
  public void test2630() {
    coral.tests.JPFBenchmark.benchmark51(7.3515151153246165,13.160658401792773 ) ;
  }

  @Test
  public void test2631() {
    coral.tests.JPFBenchmark.benchmark51(7.352841005344217,26.245362652123802 ) ;
  }

  @Test
  public void test2632() {
    coral.tests.JPFBenchmark.benchmark51(7.354756366086406,34.915649655764014 ) ;
  }

  @Test
  public void test2633() {
    coral.tests.JPFBenchmark.benchmark51(7.365604802633091,33.95066540273535 ) ;
  }

  @Test
  public void test2634() {
    coral.tests.JPFBenchmark.benchmark51(7.369836636005658,41.449489394727124 ) ;
  }

  @Test
  public void test2635() {
    coral.tests.JPFBenchmark.benchmark51(7.371224605584544,14.439275159802833 ) ;
  }

  @Test
  public void test2636() {
    coral.tests.JPFBenchmark.benchmark51(7.3754101260421265,31.21883544451879 ) ;
  }

  @Test
  public void test2637() {
    coral.tests.JPFBenchmark.benchmark51(7.376292075484384,34.829446125044505 ) ;
  }

  @Test
  public void test2638() {
    coral.tests.JPFBenchmark.benchmark51(7.3778020693870285,39.619496882449596 ) ;
  }

  @Test
  public void test2639() {
    coral.tests.JPFBenchmark.benchmark51(7.385865629108888,35.81803713666073 ) ;
  }

  @Test
  public void test2640() {
    coral.tests.JPFBenchmark.benchmark51(7.386529806460956,11.180413927987203 ) ;
  }

  @Test
  public void test2641() {
    coral.tests.JPFBenchmark.benchmark51(7.386905377463336,11.215338073650145 ) ;
  }

  @Test
  public void test2642() {
    coral.tests.JPFBenchmark.benchmark51(7.3875498658100724,8.76021605685682 ) ;
  }

  @Test
  public void test2643() {
    coral.tests.JPFBenchmark.benchmark51(7.396802509253831,21.18818525924094 ) ;
  }

  @Test
  public void test2644() {
    coral.tests.JPFBenchmark.benchmark51(7.40521201547412,20.280258019891065 ) ;
  }

  @Test
  public void test2645() {
    coral.tests.JPFBenchmark.benchmark51(7.407968681147867,36.113534492528075 ) ;
  }

  @Test
  public void test2646() {
    coral.tests.JPFBenchmark.benchmark51(7.409519110021847,10.015926653508615 ) ;
  }

  @Test
  public void test2647() {
    coral.tests.JPFBenchmark.benchmark51(7.424113303004546,18.346403691313 ) ;
  }

  @Test
  public void test2648() {
    coral.tests.JPFBenchmark.benchmark51(7.425788857882807,29.006969170621772 ) ;
  }

  @Test
  public void test2649() {
    coral.tests.JPFBenchmark.benchmark51(7.426586353016745,16.325298123044348 ) ;
  }

  @Test
  public void test2650() {
    coral.tests.JPFBenchmark.benchmark51(7.438905659545009,30.64876499322127 ) ;
  }

  @Test
  public void test2651() {
    coral.tests.JPFBenchmark.benchmark51(7.440752305265349,33.799137489457785 ) ;
  }

  @Test
  public void test2652() {
    coral.tests.JPFBenchmark.benchmark51(7.445448291094124,33.74475536403082 ) ;
  }

  @Test
  public void test2653() {
    coral.tests.JPFBenchmark.benchmark51(7.449826948574639,37.06578994967947 ) ;
  }

  @Test
  public void test2654() {
    coral.tests.JPFBenchmark.benchmark51(7.450304817274791,42.292137412306346 ) ;
  }

  @Test
  public void test2655() {
    coral.tests.JPFBenchmark.benchmark51(7.450722985508001,23.75827692612469 ) ;
  }

  @Test
  public void test2656() {
    coral.tests.JPFBenchmark.benchmark51(7.470641959652255,35.45863654942849 ) ;
  }

  @Test
  public void test2657() {
    coral.tests.JPFBenchmark.benchmark51(74.84318533264752,90.29708488923103 ) ;
  }

  @Test
  public void test2658() {
    coral.tests.JPFBenchmark.benchmark51(7.4851496800193615,18.094412677367174 ) ;
  }

  @Test
  public void test2659() {
    coral.tests.JPFBenchmark.benchmark51(7.488362873416122,42.2151160851642 ) ;
  }

  @Test
  public void test2660() {
    coral.tests.JPFBenchmark.benchmark51(7.491474078205163,16.665873772653786 ) ;
  }

  @Test
  public void test2661() {
    coral.tests.JPFBenchmark.benchmark51(7.494453040965425,16.004027178547858 ) ;
  }

  @Test
  public void test2662() {
    coral.tests.JPFBenchmark.benchmark51(7.496573040666677,40.22495700829924 ) ;
  }

  @Test
  public void test2663() {
    coral.tests.JPFBenchmark.benchmark51(7.508069150049607,28.424007040715423 ) ;
  }

  @Test
  public void test2664() {
    coral.tests.JPFBenchmark.benchmark51(7.512399196099125,40.943516922543104 ) ;
  }

  @Test
  public void test2665() {
    coral.tests.JPFBenchmark.benchmark51(7.5140314687537995,38.41224948472288 ) ;
  }

  @Test
  public void test2666() {
    coral.tests.JPFBenchmark.benchmark51(7.526386718518609,25.946180986364325 ) ;
  }

  @Test
  public void test2667() {
    coral.tests.JPFBenchmark.benchmark51(7.533171412750008,40.91276300410439 ) ;
  }

  @Test
  public void test2668() {
    coral.tests.JPFBenchmark.benchmark51(7.539978516696678,26.372606555022045 ) ;
  }

  @Test
  public void test2669() {
    coral.tests.JPFBenchmark.benchmark51(7.560736391319594,19.826321039052416 ) ;
  }

  @Test
  public void test2670() {
    coral.tests.JPFBenchmark.benchmark51(7.5612833649693085,8.892675881115892 ) ;
  }

  @Test
  public void test2671() {
    coral.tests.JPFBenchmark.benchmark51(7.567041906676678,20.753512586756358 ) ;
  }

  @Test
  public void test2672() {
    coral.tests.JPFBenchmark.benchmark51(7.567690269469267,40.37109048613234 ) ;
  }

  @Test
  public void test2673() {
    coral.tests.JPFBenchmark.benchmark51(7.571409574386905,40.3017414492769 ) ;
  }

  @Test
  public void test2674() {
    coral.tests.JPFBenchmark.benchmark51(7.5776382951264765,14.691688271095643 ) ;
  }

  @Test
  public void test2675() {
    coral.tests.JPFBenchmark.benchmark51(7.580333745246593,16.435393530574146 ) ;
  }

  @Test
  public void test2676() {
    coral.tests.JPFBenchmark.benchmark51(7.583424648717681,20.69206767122263 ) ;
  }

  @Test
  public void test2677() {
    coral.tests.JPFBenchmark.benchmark51(7.585151884756726,16.68722758346381 ) ;
  }

  @Test
  public void test2678() {
    coral.tests.JPFBenchmark.benchmark51(7.592892580534453,31.78254902375798 ) ;
  }

  @Test
  public void test2679() {
    coral.tests.JPFBenchmark.benchmark51(7.594992489059862,27.93002355844291 ) ;
  }

  @Test
  public void test2680() {
    coral.tests.JPFBenchmark.benchmark51(7.597034167983331,23.840056238993952 ) ;
  }

  @Test
  public void test2681() {
    coral.tests.JPFBenchmark.benchmark51(7.605846862370579,29.013516917571422 ) ;
  }

  @Test
  public void test2682() {
    coral.tests.JPFBenchmark.benchmark51(7.61323801171028,14.313675325673955 ) ;
  }

  @Test
  public void test2683() {
    coral.tests.JPFBenchmark.benchmark51(7.6161185503364806,41.76050451709074 ) ;
  }

  @Test
  public void test2684() {
    coral.tests.JPFBenchmark.benchmark51(7.619829787748728,10.169418445776875 ) ;
  }

  @Test
  public void test2685() {
    coral.tests.JPFBenchmark.benchmark51(7.622097494734817,23.552254487606717 ) ;
  }

  @Test
  public void test2686() {
    coral.tests.JPFBenchmark.benchmark51(7.634537695560965,11.606916765065407 ) ;
  }

  @Test
  public void test2687() {
    coral.tests.JPFBenchmark.benchmark51(7.6353650721191,24.954912506336697 ) ;
  }

  @Test
  public void test2688() {
    coral.tests.JPFBenchmark.benchmark51(7.63591103851428,39.30649034558761 ) ;
  }

  @Test
  public void test2689() {
    coral.tests.JPFBenchmark.benchmark51(7.636250367778051,19.300959570839552 ) ;
  }

  @Test
  public void test2690() {
    coral.tests.JPFBenchmark.benchmark51(7.67232303337147,29.771839117253336 ) ;
  }

  @Test
  public void test2691() {
    coral.tests.JPFBenchmark.benchmark51(7.672768970999471,18.097975375359283 ) ;
  }

  @Test
  public void test2692() {
    coral.tests.JPFBenchmark.benchmark51(-76.76392810908544,19.939801059301217 ) ;
  }

  @Test
  public void test2693() {
    coral.tests.JPFBenchmark.benchmark51(7.680671303377453,34.05561052452782 ) ;
  }

  @Test
  public void test2694() {
    coral.tests.JPFBenchmark.benchmark51(7.716259792127019,10.456439893885474 ) ;
  }

  @Test
  public void test2695() {
    coral.tests.JPFBenchmark.benchmark51(7.716471193330868,42.283528806669125 ) ;
  }

  @Test
  public void test2696() {
    coral.tests.JPFBenchmark.benchmark51(7.71869466986324,34.26934931654753 ) ;
  }

  @Test
  public void test2697() {
    coral.tests.JPFBenchmark.benchmark51(7.739850869296241,25.172658130591643 ) ;
  }

  @Test
  public void test2698() {
    coral.tests.JPFBenchmark.benchmark51(7.749742531086028,15.294673062737175 ) ;
  }

  @Test
  public void test2699() {
    coral.tests.JPFBenchmark.benchmark51(7.754808990469513,27.5824718876422 ) ;
  }

  @Test
  public void test2700() {
    coral.tests.JPFBenchmark.benchmark51(7.7586166425703595,11.16448804488958 ) ;
  }

  @Test
  public void test2701() {
    coral.tests.JPFBenchmark.benchmark51(7.776001432054613,33.65204974137254 ) ;
  }

  @Test
  public void test2702() {
    coral.tests.JPFBenchmark.benchmark51(7.778214158812826,15.641531367773638 ) ;
  }

  @Test
  public void test2703() {
    coral.tests.JPFBenchmark.benchmark51(7.787432036614167,18.256366195938824 ) ;
  }

  @Test
  public void test2704() {
    coral.tests.JPFBenchmark.benchmark51(7.792568404995308,23.06912058417791 ) ;
  }

  @Test
  public void test2705() {
    coral.tests.JPFBenchmark.benchmark51(7.811013854921114,32.978553130259826 ) ;
  }

  @Test
  public void test2706() {
    coral.tests.JPFBenchmark.benchmark51(7.826654379495757,42.173345620504236 ) ;
  }

  @Test
  public void test2707() {
    coral.tests.JPFBenchmark.benchmark51(7.827145112687582,31.679459228122056 ) ;
  }

  @Test
  public void test2708() {
    coral.tests.JPFBenchmark.benchmark51(7.831966489791185,9.142412557174339 ) ;
  }

  @Test
  public void test2709() {
    coral.tests.JPFBenchmark.benchmark51(7.841941630251185,42.025515573985956 ) ;
  }

  @Test
  public void test2710() {
    coral.tests.JPFBenchmark.benchmark51(7.845241867475096,27.83366389690873 ) ;
  }

  @Test
  public void test2711() {
    coral.tests.JPFBenchmark.benchmark51(7.8490409081898065,37.32360889699234 ) ;
  }

  @Test
  public void test2712() {
    coral.tests.JPFBenchmark.benchmark51(7.849120886661364,42.15087911333862 ) ;
  }

  @Test
  public void test2713() {
    coral.tests.JPFBenchmark.benchmark51(7.860728398064779,37.91693223349196 ) ;
  }

  @Test
  public void test2714() {
    coral.tests.JPFBenchmark.benchmark51(7.862430997348071,12.58766018049944 ) ;
  }

  @Test
  public void test2715() {
    coral.tests.JPFBenchmark.benchmark51(7.862990637999843,11.100636677593428 ) ;
  }

  @Test
  public void test2716() {
    coral.tests.JPFBenchmark.benchmark51(7.872472230486906,37.917291228135554 ) ;
  }

  @Test
  public void test2717() {
    coral.tests.JPFBenchmark.benchmark51(7.878450220557156,27.50604508115788 ) ;
  }

  @Test
  public void test2718() {
    coral.tests.JPFBenchmark.benchmark51(7.893402378517635,31.23241696751134 ) ;
  }

  @Test
  public void test2719() {
    coral.tests.JPFBenchmark.benchmark51(7.906645759309768,14.89278687423014 ) ;
  }

  @Test
  public void test2720() {
    coral.tests.JPFBenchmark.benchmark51(7.908331363502924,11.514689480726446 ) ;
  }

  @Test
  public void test2721() {
    coral.tests.JPFBenchmark.benchmark51(7.911643494655996,9.398536768681453 ) ;
  }

  @Test
  public void test2722() {
    coral.tests.JPFBenchmark.benchmark51(7.916185449890669,16.679764758221395 ) ;
  }

  @Test
  public void test2723() {
    coral.tests.JPFBenchmark.benchmark51(7.920081700884211,20.352720903489512 ) ;
  }

  @Test
  public void test2724() {
    coral.tests.JPFBenchmark.benchmark51(7.923434171726981,10.894564954956394 ) ;
  }

  @Test
  public void test2725() {
    coral.tests.JPFBenchmark.benchmark51(7.934080031296347,14.999999306510546 ) ;
  }

  @Test
  public void test2726() {
    coral.tests.JPFBenchmark.benchmark51(7.9357001078721225,14.186719587352599 ) ;
  }

  @Test
  public void test2727() {
    coral.tests.JPFBenchmark.benchmark51(7.94082519263722,33.520384520480064 ) ;
  }

  @Test
  public void test2728() {
    coral.tests.JPFBenchmark.benchmark51(7.941070859646345,24.18680127066777 ) ;
  }

  @Test
  public void test2729() {
    coral.tests.JPFBenchmark.benchmark51(7.948279091778645,15.876542587289634 ) ;
  }

  @Test
  public void test2730() {
    coral.tests.JPFBenchmark.benchmark51(7.951609949158438,31.865264699253714 ) ;
  }

  @Test
  public void test2731() {
    coral.tests.JPFBenchmark.benchmark51(7.986730114696641,23.403531351779066 ) ;
  }

  @Test
  public void test2732() {
    coral.tests.JPFBenchmark.benchmark51(7.989933248250073,42.00386189097347 ) ;
  }

  @Test
  public void test2733() {
    coral.tests.JPFBenchmark.benchmark51(7.995195179779622,42.00480482022037 ) ;
  }

  @Test
  public void test2734() {
    coral.tests.JPFBenchmark.benchmark51(8.005460645706554,36.32378290994174 ) ;
  }

  @Test
  public void test2735() {
    coral.tests.JPFBenchmark.benchmark51(8.009383781075911,10.179108182006516 ) ;
  }

  @Test
  public void test2736() {
    coral.tests.JPFBenchmark.benchmark51(8.012660369694075,9.185656563168454 ) ;
  }

  @Test
  public void test2737() {
    coral.tests.JPFBenchmark.benchmark51(8.020029897416208,23.66655961194178 ) ;
  }

  @Test
  public void test2738() {
    coral.tests.JPFBenchmark.benchmark51(8.020661902544688,37.628536687696396 ) ;
  }

  @Test
  public void test2739() {
    coral.tests.JPFBenchmark.benchmark51(80.27836835341878,94.44644605430057 ) ;
  }

  @Test
  public void test2740() {
    coral.tests.JPFBenchmark.benchmark51(8.029419122879773,23.651307286117287 ) ;
  }

  @Test
  public void test2741() {
    coral.tests.JPFBenchmark.benchmark51(8.041126615854072,10.915560383754261 ) ;
  }

  @Test
  public void test2742() {
    coral.tests.JPFBenchmark.benchmark51(8.041562343163065,35.26130156281127 ) ;
  }

  @Test
  public void test2743() {
    coral.tests.JPFBenchmark.benchmark51(8.044899475467602,27.10387295281997 ) ;
  }

  @Test
  public void test2744() {
    coral.tests.JPFBenchmark.benchmark51(8.04807407255177,12.726767296874115 ) ;
  }

  @Test
  public void test2745() {
    coral.tests.JPFBenchmark.benchmark51(8.066962930391863,14.191470564148128 ) ;
  }

  @Test
  public void test2746() {
    coral.tests.JPFBenchmark.benchmark51(8.069883901880928,29.757173243959272 ) ;
  }

  @Test
  public void test2747() {
    coral.tests.JPFBenchmark.benchmark51(8.07504478729939,17.772461401290144 ) ;
  }

  @Test
  public void test2748() {
    coral.tests.JPFBenchmark.benchmark51(8.084168768333196,13.261265653345447 ) ;
  }

  @Test
  public void test2749() {
    coral.tests.JPFBenchmark.benchmark51(8.08687093142501,21.998827215481036 ) ;
  }

  @Test
  public void test2750() {
    coral.tests.JPFBenchmark.benchmark51(8.104879828997934,24.949189590229334 ) ;
  }

  @Test
  public void test2751() {
    coral.tests.JPFBenchmark.benchmark51(8.10525691618014,14.573111458404318 ) ;
  }

  @Test
  public void test2752() {
    coral.tests.JPFBenchmark.benchmark51(8.109442985549535,16.030489891796563 ) ;
  }

  @Test
  public void test2753() {
    coral.tests.JPFBenchmark.benchmark51(8.113385791749266,29.60295713318405 ) ;
  }

  @Test
  public void test2754() {
    coral.tests.JPFBenchmark.benchmark51(8.118263664557261,15.58403935897681 ) ;
  }

  @Test
  public void test2755() {
    coral.tests.JPFBenchmark.benchmark51(8.122976317556763,19.222794548638973 ) ;
  }

  @Test
  public void test2756() {
    coral.tests.JPFBenchmark.benchmark51(8.124433254372093,39.528691235325425 ) ;
  }

  @Test
  public void test2757() {
    coral.tests.JPFBenchmark.benchmark51(8.125262793727673,26.916232318729854 ) ;
  }

  @Test
  public void test2758() {
    coral.tests.JPFBenchmark.benchmark51(8.12809788600974,36.9333288759563 ) ;
  }

  @Test
  public void test2759() {
    coral.tests.JPFBenchmark.benchmark51(8.13242948170893,35.609970355634516 ) ;
  }

  @Test
  public void test2760() {
    coral.tests.JPFBenchmark.benchmark51(8.13509363338811,24.395758380333007 ) ;
  }

  @Test
  public void test2761() {
    coral.tests.JPFBenchmark.benchmark51(8.137618522478192,30.536072322230638 ) ;
  }

  @Test
  public void test2762() {
    coral.tests.JPFBenchmark.benchmark51(8.140558282069357,40.724445806087246 ) ;
  }

  @Test
  public void test2763() {
    coral.tests.JPFBenchmark.benchmark51(8.142771020687933,41.85722897931206 ) ;
  }

  @Test
  public void test2764() {
    coral.tests.JPFBenchmark.benchmark51(81.43642459029584,0 ) ;
  }

  @Test
  public void test2765() {
    coral.tests.JPFBenchmark.benchmark51(8.150992396496193,17.65304475116052 ) ;
  }

  @Test
  public void test2766() {
    coral.tests.JPFBenchmark.benchmark51(8.154313287899996,10.320641531186254 ) ;
  }

  @Test
  public void test2767() {
    coral.tests.JPFBenchmark.benchmark51(8.172774470789149,14.273902103021612 ) ;
  }

  @Test
  public void test2768() {
    coral.tests.JPFBenchmark.benchmark51(8.183194393811235,22.656522488116934 ) ;
  }

  @Test
  public void test2769() {
    coral.tests.JPFBenchmark.benchmark51(8.184201354206238,41.815798645793706 ) ;
  }

  @Test
  public void test2770() {
    coral.tests.JPFBenchmark.benchmark51(8.214101723172163,27.5775860246584 ) ;
  }

  @Test
  public void test2771() {
    coral.tests.JPFBenchmark.benchmark51(8.216920963391644,38.24334315349191 ) ;
  }

  @Test
  public void test2772() {
    coral.tests.JPFBenchmark.benchmark51(8.219145926098975,28.244659321639176 ) ;
  }

  @Test
  public void test2773() {
    coral.tests.JPFBenchmark.benchmark51(8.23680959989277,40.33773312671073 ) ;
  }

  @Test
  public void test2774() {
    coral.tests.JPFBenchmark.benchmark51(8.243661193720996,9.404803948837575 ) ;
  }

  @Test
  public void test2775() {
    coral.tests.JPFBenchmark.benchmark51(8.24577278271768,37.36764842711196 ) ;
  }

  @Test
  public void test2776() {
    coral.tests.JPFBenchmark.benchmark51(8.253114391795165,17.790479255040005 ) ;
  }

  @Test
  public void test2777() {
    coral.tests.JPFBenchmark.benchmark51(8.254054390661036,30.536290127905943 ) ;
  }

  @Test
  public void test2778() {
    coral.tests.JPFBenchmark.benchmark51(8.268373209219206,27.84242212965286 ) ;
  }

  @Test
  public void test2779() {
    coral.tests.JPFBenchmark.benchmark51(8.269484160473262,12.688542550251293 ) ;
  }

  @Test
  public void test2780() {
    coral.tests.JPFBenchmark.benchmark51(8.284430758396539,18.833906402516007 ) ;
  }

  @Test
  public void test2781() {
    coral.tests.JPFBenchmark.benchmark51(8.292909485929712,17.23402267735355 ) ;
  }

  @Test
  public void test2782() {
    coral.tests.JPFBenchmark.benchmark51(8.296872408128692,17.042775347888934 ) ;
  }

  @Test
  public void test2783() {
    coral.tests.JPFBenchmark.benchmark51(8.298299504711037,25.542015343359267 ) ;
  }

  @Test
  public void test2784() {
    coral.tests.JPFBenchmark.benchmark51(8.298760972678053,14.044148385383949 ) ;
  }

  @Test
  public void test2785() {
    coral.tests.JPFBenchmark.benchmark51(8.30153992720198,25.655706451034476 ) ;
  }

  @Test
  public void test2786() {
    coral.tests.JPFBenchmark.benchmark51(8.30460753705077,14.026763951843662 ) ;
  }

  @Test
  public void test2787() {
    coral.tests.JPFBenchmark.benchmark51(8.30479206565537,41.69520793434462 ) ;
  }

  @Test
  public void test2788() {
    coral.tests.JPFBenchmark.benchmark51(8.311589391497137,18.3044591288146 ) ;
  }

  @Test
  public void test2789() {
    coral.tests.JPFBenchmark.benchmark51(8.318915175091195,10.615298611889227 ) ;
  }

  @Test
  public void test2790() {
    coral.tests.JPFBenchmark.benchmark51(8.319303540292152,10.585040730529926 ) ;
  }

  @Test
  public void test2791() {
    coral.tests.JPFBenchmark.benchmark51(8.329249214190654,17.141783985304045 ) ;
  }

  @Test
  public void test2792() {
    coral.tests.JPFBenchmark.benchmark51(8.353421521936895,40.127347192716314 ) ;
  }

  @Test
  public void test2793() {
    coral.tests.JPFBenchmark.benchmark51(8.359260224712742,39.32691380590353 ) ;
  }

  @Test
  public void test2794() {
    coral.tests.JPFBenchmark.benchmark51(8.360463739736005,40.20992800325175 ) ;
  }

  @Test
  public void test2795() {
    coral.tests.JPFBenchmark.benchmark51(8.360482272117077,28.408825702320257 ) ;
  }

  @Test
  public void test2796() {
    coral.tests.JPFBenchmark.benchmark51(8.361509081467489,16.83650612482768 ) ;
  }

  @Test
  public void test2797() {
    coral.tests.JPFBenchmark.benchmark51(8.362174802277607,29.74981891430187 ) ;
  }

  @Test
  public void test2798() {
    coral.tests.JPFBenchmark.benchmark51(8.368079092196016,19.85624618670397 ) ;
  }

  @Test
  public void test2799() {
    coral.tests.JPFBenchmark.benchmark51(8.389460947201385,39.42482633756694 ) ;
  }

  @Test
  public void test2800() {
    coral.tests.JPFBenchmark.benchmark51(8.391318006532853,13.971924031238359 ) ;
  }

  @Test
  public void test2801() {
    coral.tests.JPFBenchmark.benchmark51(8.392400156376592,30.77257763384256 ) ;
  }

  @Test
  public void test2802() {
    coral.tests.JPFBenchmark.benchmark51(8.394369882892832,31.21441264060735 ) ;
  }

  @Test
  public void test2803() {
    coral.tests.JPFBenchmark.benchmark51(8.40596197742694,32.094696617272064 ) ;
  }

  @Test
  public void test2804() {
    coral.tests.JPFBenchmark.benchmark51(8.41169249721294,40.487494984241124 ) ;
  }

  @Test
  public void test2805() {
    coral.tests.JPFBenchmark.benchmark51(8.421482605819534,24.94342012842074 ) ;
  }

  @Test
  public void test2806() {
    coral.tests.JPFBenchmark.benchmark51(8.431987009563642,15.562133228980969 ) ;
  }

  @Test
  public void test2807() {
    coral.tests.JPFBenchmark.benchmark51(8.453188112609915,11.34774004223371 ) ;
  }

  @Test
  public void test2808() {
    coral.tests.JPFBenchmark.benchmark51(8.456420013566301,19.32252768872931 ) ;
  }

  @Test
  public void test2809() {
    coral.tests.JPFBenchmark.benchmark51(8.470085762723102,33.77458455804549 ) ;
  }

  @Test
  public void test2810() {
    coral.tests.JPFBenchmark.benchmark51(8.473322105385847,11.770649330605963 ) ;
  }

  @Test
  public void test2811() {
    coral.tests.JPFBenchmark.benchmark51(8.476994165063829,21.555587525666226 ) ;
  }

  @Test
  public void test2812() {
    coral.tests.JPFBenchmark.benchmark51(8.484601805997755,13.332612753343298 ) ;
  }

  @Test
  public void test2813() {
    coral.tests.JPFBenchmark.benchmark51(8.497625045880014,17.160219187550837 ) ;
  }

  @Test
  public void test2814() {
    coral.tests.JPFBenchmark.benchmark51(8.500194995518092,17.22790671188565 ) ;
  }

  @Test
  public void test2815() {
    coral.tests.JPFBenchmark.benchmark51(8.503641865478514,27.2457339568859 ) ;
  }

  @Test
  public void test2816() {
    coral.tests.JPFBenchmark.benchmark51(8.512495507665177,35.933558543006626 ) ;
  }

  @Test
  public void test2817() {
    coral.tests.JPFBenchmark.benchmark51(8.512608763373436,25.402075277838662 ) ;
  }

  @Test
  public void test2818() {
    coral.tests.JPFBenchmark.benchmark51(8.51485926270368,14.806616130891783 ) ;
  }

  @Test
  public void test2819() {
    coral.tests.JPFBenchmark.benchmark51(8.516417350502664,9.943561522756369 ) ;
  }

  @Test
  public void test2820() {
    coral.tests.JPFBenchmark.benchmark51(8.518510318623282,14.188123103190113 ) ;
  }

  @Test
  public void test2821() {
    coral.tests.JPFBenchmark.benchmark51(8.518535557768516,30.481837967496972 ) ;
  }

  @Test
  public void test2822() {
    coral.tests.JPFBenchmark.benchmark51(8.519254338721211,18.556740263838662 ) ;
  }

  @Test
  public void test2823() {
    coral.tests.JPFBenchmark.benchmark51(8.527156323868871,36.35542375107564 ) ;
  }

  @Test
  public void test2824() {
    coral.tests.JPFBenchmark.benchmark51(8.530481372061999,12.23331014006304 ) ;
  }

  @Test
  public void test2825() {
    coral.tests.JPFBenchmark.benchmark51(8.530597646083123,27.664510679876457 ) ;
  }

  @Test
  public void test2826() {
    coral.tests.JPFBenchmark.benchmark51(8.532721001889769,21.43363334443582 ) ;
  }

  @Test
  public void test2827() {
    coral.tests.JPFBenchmark.benchmark51(8.535509961684681,13.974956951194486 ) ;
  }

  @Test
  public void test2828() {
    coral.tests.JPFBenchmark.benchmark51(8.542452464704425,14.464971053909423 ) ;
  }

  @Test
  public void test2829() {
    coral.tests.JPFBenchmark.benchmark51(8.556785147741579,16.113590328492222 ) ;
  }

  @Test
  public void test2830() {
    coral.tests.JPFBenchmark.benchmark51(8.556950154691544,12.041134282751143 ) ;
  }

  @Test
  public void test2831() {
    coral.tests.JPFBenchmark.benchmark51(8.565578193220944,25.075064154620264 ) ;
  }

  @Test
  public void test2832() {
    coral.tests.JPFBenchmark.benchmark51(8.567150594610311,23.312576306884836 ) ;
  }

  @Test
  public void test2833() {
    coral.tests.JPFBenchmark.benchmark51(8.571415725624703,18.00528453171961 ) ;
  }

  @Test
  public void test2834() {
    coral.tests.JPFBenchmark.benchmark51(8.571935703298918,9.91408859297263 ) ;
  }

  @Test
  public void test2835() {
    coral.tests.JPFBenchmark.benchmark51(8.580869960411277,30.701284579730498 ) ;
  }

  @Test
  public void test2836() {
    coral.tests.JPFBenchmark.benchmark51(8.585150662011355,41.41484933798846 ) ;
  }

  @Test
  public void test2837() {
    coral.tests.JPFBenchmark.benchmark51(8.601519867111577,15.636883374330694 ) ;
  }

  @Test
  public void test2838() {
    coral.tests.JPFBenchmark.benchmark51(8.603291803558875,28.67974645264232 ) ;
  }

  @Test
  public void test2839() {
    coral.tests.JPFBenchmark.benchmark51(8.60418496200893,14.696125460879458 ) ;
  }

  @Test
  public void test2840() {
    coral.tests.JPFBenchmark.benchmark51(8.606137292656783,34.10975388012773 ) ;
  }

  @Test
  public void test2841() {
    coral.tests.JPFBenchmark.benchmark51(8.61439692479074,25.874072125186203 ) ;
  }

  @Test
  public void test2842() {
    coral.tests.JPFBenchmark.benchmark51(8.627156037206564,19.008193697578463 ) ;
  }

  @Test
  public void test2843() {
    coral.tests.JPFBenchmark.benchmark51(8.629295231901938,41.370704768097966 ) ;
  }

  @Test
  public void test2844() {
    coral.tests.JPFBenchmark.benchmark51(8.633852410521882,27.36385862903117 ) ;
  }

  @Test
  public void test2845() {
    coral.tests.JPFBenchmark.benchmark51(8.635075299516686,34.05879253107216 ) ;
  }

  @Test
  public void test2846() {
    coral.tests.JPFBenchmark.benchmark51(8.638772264693003,22.710555202891342 ) ;
  }

  @Test
  public void test2847() {
    coral.tests.JPFBenchmark.benchmark51(8.639243381065201,29.467571613737025 ) ;
  }

  @Test
  public void test2848() {
    coral.tests.JPFBenchmark.benchmark51(8.640419924654779,12.63342880594594 ) ;
  }

  @Test
  public void test2849() {
    coral.tests.JPFBenchmark.benchmark51(8.64506890627888,15.33409019462158 ) ;
  }

  @Test
  public void test2850() {
    coral.tests.JPFBenchmark.benchmark51(8.652265107689331,28.150646265642536 ) ;
  }

  @Test
  public void test2851() {
    coral.tests.JPFBenchmark.benchmark51(8.67537311732962,41.32462688267037 ) ;
  }

  @Test
  public void test2852() {
    coral.tests.JPFBenchmark.benchmark51(8.690014582521194,23.78740595230667 ) ;
  }

  @Test
  public void test2853() {
    coral.tests.JPFBenchmark.benchmark51(8.69507202349304,40.57411947412214 ) ;
  }

  @Test
  public void test2854() {
    coral.tests.JPFBenchmark.benchmark51(8.702495367336155,31.732920420090522 ) ;
  }

  @Test
  public void test2855() {
    coral.tests.JPFBenchmark.benchmark51(8.703557283506013,11.968279509044944 ) ;
  }

  @Test
  public void test2856() {
    coral.tests.JPFBenchmark.benchmark51(8.705269864335534,32.99415903596301 ) ;
  }

  @Test
  public void test2857() {
    coral.tests.JPFBenchmark.benchmark51(8.708723192515482,16.913975418383615 ) ;
  }

  @Test
  public void test2858() {
    coral.tests.JPFBenchmark.benchmark51(8.708753604750413,24.65521830054756 ) ;
  }

  @Test
  public void test2859() {
    coral.tests.JPFBenchmark.benchmark51(8.723933895048471,34.03000858655071 ) ;
  }

  @Test
  public void test2860() {
    coral.tests.JPFBenchmark.benchmark51(8.73123436650205,22.680034603400784 ) ;
  }

  @Test
  public void test2861() {
    coral.tests.JPFBenchmark.benchmark51(8.751212168042203,26.722647608211066 ) ;
  }

  @Test
  public void test2862() {
    coral.tests.JPFBenchmark.benchmark51(8.752461457959214,28.48348205450776 ) ;
  }

  @Test
  public void test2863() {
    coral.tests.JPFBenchmark.benchmark51(8.756277287143169,20.77518317430397 ) ;
  }

  @Test
  public void test2864() {
    coral.tests.JPFBenchmark.benchmark51(8.763265549953886,29.444458817594324 ) ;
  }

  @Test
  public void test2865() {
    coral.tests.JPFBenchmark.benchmark51(8.78116137316674,21.00293766700581 ) ;
  }

  @Test
  public void test2866() {
    coral.tests.JPFBenchmark.benchmark51(8.789821457263812,34.18514090593305 ) ;
  }

  @Test
  public void test2867() {
    coral.tests.JPFBenchmark.benchmark51(8.790959492638237,30.61399216883592 ) ;
  }

  @Test
  public void test2868() {
    coral.tests.JPFBenchmark.benchmark51(8.796225755493722,35.82671137034151 ) ;
  }

  @Test
  public void test2869() {
    coral.tests.JPFBenchmark.benchmark51(8.802098213908705,17.659257335351096 ) ;
  }

  @Test
  public void test2870() {
    coral.tests.JPFBenchmark.benchmark51(8.806070157100923,27.931698722584237 ) ;
  }

  @Test
  public void test2871() {
    coral.tests.JPFBenchmark.benchmark51(8.816677684658728,39.93204890367923 ) ;
  }

  @Test
  public void test2872() {
    coral.tests.JPFBenchmark.benchmark51(8.839417724852325,21.977295518538 ) ;
  }

  @Test
  public void test2873() {
    coral.tests.JPFBenchmark.benchmark51(8.840692396807112,41.15930760319288 ) ;
  }

  @Test
  public void test2874() {
    coral.tests.JPFBenchmark.benchmark51(8.845035692051788,12.209063365960688 ) ;
  }

  @Test
  public void test2875() {
    coral.tests.JPFBenchmark.benchmark51(8.84600236047504,27.21163173210701 ) ;
  }

  @Test
  public void test2876() {
    coral.tests.JPFBenchmark.benchmark51(8.853231545678938,31.189741829004248 ) ;
  }

  @Test
  public void test2877() {
    coral.tests.JPFBenchmark.benchmark51(8.861735630746125,27.347696876490815 ) ;
  }

  @Test
  public void test2878() {
    coral.tests.JPFBenchmark.benchmark51(8.86381639757998,18.148176481599826 ) ;
  }

  @Test
  public void test2879() {
    coral.tests.JPFBenchmark.benchmark51(8.865225759030238,38.50160214987096 ) ;
  }

  @Test
  public void test2880() {
    coral.tests.JPFBenchmark.benchmark51(8.88006886056678,27.112809518048707 ) ;
  }

  @Test
  public void test2881() {
    coral.tests.JPFBenchmark.benchmark51(8.888541712730742,18.825457056452464 ) ;
  }

  @Test
  public void test2882() {
    coral.tests.JPFBenchmark.benchmark51(8.88956847213916,28.671018777218706 ) ;
  }

  @Test
  public void test2883() {
    coral.tests.JPFBenchmark.benchmark51(8.898645900794449,34.20537793643183 ) ;
  }

  @Test
  public void test2884() {
    coral.tests.JPFBenchmark.benchmark51(8.900372319236283,38.46556998278663 ) ;
  }

  @Test
  public void test2885() {
    coral.tests.JPFBenchmark.benchmark51(8.912917720388407,11.456154046290479 ) ;
  }

  @Test
  public void test2886() {
    coral.tests.JPFBenchmark.benchmark51(8.916629234368571,39.164690334653784 ) ;
  }

  @Test
  public void test2887() {
    coral.tests.JPFBenchmark.benchmark51(8.926914051880772,9.990211950848837 ) ;
  }

  @Test
  public void test2888() {
    coral.tests.JPFBenchmark.benchmark51(8.928399621016057,31.76970375897929 ) ;
  }

  @Test
  public void test2889() {
    coral.tests.JPFBenchmark.benchmark51(8.938983147163299,35.312118973671744 ) ;
  }

  @Test
  public void test2890() {
    coral.tests.JPFBenchmark.benchmark51(8.953199475245867,18.611775043078453 ) ;
  }

  @Test
  public void test2891() {
    coral.tests.JPFBenchmark.benchmark51(8.964528574505305,38.14003226280599 ) ;
  }

  @Test
  public void test2892() {
    coral.tests.JPFBenchmark.benchmark51(8.966861519756648,13.577279875970746 ) ;
  }

  @Test
  public void test2893() {
    coral.tests.JPFBenchmark.benchmark51(8.968237875172356,39.668827536405644 ) ;
  }

  @Test
  public void test2894() {
    coral.tests.JPFBenchmark.benchmark51(8.970824435974528,22.13335977518349 ) ;
  }

  @Test
  public void test2895() {
    coral.tests.JPFBenchmark.benchmark51(8.971214082789942,36.491625471436095 ) ;
  }

  @Test
  public void test2896() {
    coral.tests.JPFBenchmark.benchmark51(8.973177900733134,37.40390191614196 ) ;
  }

  @Test
  public void test2897() {
    coral.tests.JPFBenchmark.benchmark51(8.980419866214788,40.57478855044033 ) ;
  }

  @Test
  public void test2898() {
    coral.tests.JPFBenchmark.benchmark51(8.987426174816406,23.800634476837928 ) ;
  }

  @Test
  public void test2899() {
    coral.tests.JPFBenchmark.benchmark51(8.987555890870055,36.670071538112126 ) ;
  }

  @Test
  public void test2900() {
    coral.tests.JPFBenchmark.benchmark51(9.001005712464561,22.376598330028457 ) ;
  }

  @Test
  public void test2901() {
    coral.tests.JPFBenchmark.benchmark51(9.001573311615772,18.67965035281476 ) ;
  }

  @Test
  public void test2902() {
    coral.tests.JPFBenchmark.benchmark51(9.00567666714413,32.036968794358245 ) ;
  }

  @Test
  public void test2903() {
    coral.tests.JPFBenchmark.benchmark51(9.026511984778836,27.482423116689716 ) ;
  }

  @Test
  public void test2904() {
    coral.tests.JPFBenchmark.benchmark51(9.028857699839321,30.876550015518006 ) ;
  }

  @Test
  public void test2905() {
    coral.tests.JPFBenchmark.benchmark51(9.043830130136032,11.814408066259176 ) ;
  }

  @Test
  public void test2906() {
    coral.tests.JPFBenchmark.benchmark51(9.0544169466487,24.057826807724496 ) ;
  }

  @Test
  public void test2907() {
    coral.tests.JPFBenchmark.benchmark51(9.059783632549502,12.352643036554582 ) ;
  }

  @Test
  public void test2908() {
    coral.tests.JPFBenchmark.benchmark51(9.063261379002356,11.312686289981812 ) ;
  }

  @Test
  public void test2909() {
    coral.tests.JPFBenchmark.benchmark51(9.066487330289121,14.857703702230822 ) ;
  }

  @Test
  public void test2910() {
    coral.tests.JPFBenchmark.benchmark51(9.067162887457641,11.602615723540268 ) ;
  }

  @Test
  public void test2911() {
    coral.tests.JPFBenchmark.benchmark51(9.067556026874485,24.474431021260983 ) ;
  }

  @Test
  public void test2912() {
    coral.tests.JPFBenchmark.benchmark51(9.069117105214488,28.456538787267732 ) ;
  }

  @Test
  public void test2913() {
    coral.tests.JPFBenchmark.benchmark51(9.07973189884251,22.243035057125013 ) ;
  }

  @Test
  public void test2914() {
    coral.tests.JPFBenchmark.benchmark51(9.088581707688386,37.909861193276036 ) ;
  }

  @Test
  public void test2915() {
    coral.tests.JPFBenchmark.benchmark51(9.089460834864298,18.47063249369056 ) ;
  }

  @Test
  public void test2916() {
    coral.tests.JPFBenchmark.benchmark51(9.091512467064849,34.85012856391364 ) ;
  }

  @Test
  public void test2917() {
    coral.tests.JPFBenchmark.benchmark51(9.101565375053639,13.494073222906422 ) ;
  }

  @Test
  public void test2918() {
    coral.tests.JPFBenchmark.benchmark51(9.105933235299005,33.42242976823607 ) ;
  }

  @Test
  public void test2919() {
    coral.tests.JPFBenchmark.benchmark51(9.108139323852509,14.80697102358984 ) ;
  }

  @Test
  public void test2920() {
    coral.tests.JPFBenchmark.benchmark51(9.119642949100822,33.11875171453281 ) ;
  }

  @Test
  public void test2921() {
    coral.tests.JPFBenchmark.benchmark51(9.121709932403537,12.651476523107988 ) ;
  }

  @Test
  public void test2922() {
    coral.tests.JPFBenchmark.benchmark51(9.122395380227026,40.87760461977297 ) ;
  }

  @Test
  public void test2923() {
    coral.tests.JPFBenchmark.benchmark51(9.147395258176559,13.723254011896586 ) ;
  }

  @Test
  public void test2924() {
    coral.tests.JPFBenchmark.benchmark51(9.155173286882928,38.8656173605323 ) ;
  }

  @Test
  public void test2925() {
    coral.tests.JPFBenchmark.benchmark51(9.15651977071066,18.777183045358427 ) ;
  }

  @Test
  public void test2926() {
    coral.tests.JPFBenchmark.benchmark51(9.163522741886174,17.355028686424244 ) ;
  }

  @Test
  public void test2927() {
    coral.tests.JPFBenchmark.benchmark51(9.165055375361938,12.317643312993395 ) ;
  }

  @Test
  public void test2928() {
    coral.tests.JPFBenchmark.benchmark51(9.170243578812828,13.475257338775785 ) ;
  }

  @Test
  public void test2929() {
    coral.tests.JPFBenchmark.benchmark51(9.171725868058516,24.6287768530636 ) ;
  }

  @Test
  public void test2930() {
    coral.tests.JPFBenchmark.benchmark51(9.180895039972881,16.701986756670337 ) ;
  }

  @Test
  public void test2931() {
    coral.tests.JPFBenchmark.benchmark51(9.18156430828843,40.07412405927266 ) ;
  }

  @Test
  public void test2932() {
    coral.tests.JPFBenchmark.benchmark51(9.182410819062952,10.493348666062 ) ;
  }

  @Test
  public void test2933() {
    coral.tests.JPFBenchmark.benchmark51(9.185219430002974,40.81478056973778 ) ;
  }

  @Test
  public void test2934() {
    coral.tests.JPFBenchmark.benchmark51(9.18913473620238,17.524324760167445 ) ;
  }

  @Test
  public void test2935() {
    coral.tests.JPFBenchmark.benchmark51(9.191356540132773,33.87243992721122 ) ;
  }

  @Test
  public void test2936() {
    coral.tests.JPFBenchmark.benchmark51(9.21006608997699,34.969699261393544 ) ;
  }

  @Test
  public void test2937() {
    coral.tests.JPFBenchmark.benchmark51(9.223068996535318,19.47783443037487 ) ;
  }

  @Test
  public void test2938() {
    coral.tests.JPFBenchmark.benchmark51(9.225177311299575,37.784140242408 ) ;
  }

  @Test
  public void test2939() {
    coral.tests.JPFBenchmark.benchmark51(9.226884334751915,40.32629232719597 ) ;
  }

  @Test
  public void test2940() {
    coral.tests.JPFBenchmark.benchmark51(9.255475598932634,11.062410056159038 ) ;
  }

  @Test
  public void test2941() {
    coral.tests.JPFBenchmark.benchmark51(9.2625199722318,25.32720692874537 ) ;
  }

  @Test
  public void test2942() {
    coral.tests.JPFBenchmark.benchmark51(9.266400921600308,32.99731161723926 ) ;
  }

  @Test
  public void test2943() {
    coral.tests.JPFBenchmark.benchmark51(9.26749566850583,10.39050066883814 ) ;
  }

  @Test
  public void test2944() {
    coral.tests.JPFBenchmark.benchmark51(9.281118071908253,30.023902155058266 ) ;
  }

  @Test
  public void test2945() {
    coral.tests.JPFBenchmark.benchmark51(9.285077394283256,40.71492260571674 ) ;
  }

  @Test
  public void test2946() {
    coral.tests.JPFBenchmark.benchmark51(9.291453409684664,11.74005654962474 ) ;
  }

  @Test
  public void test2947() {
    coral.tests.JPFBenchmark.benchmark51(9.297911490638896,11.871869673173236 ) ;
  }

  @Test
  public void test2948() {
    coral.tests.JPFBenchmark.benchmark51(9.311470374367815,28.01759920652708 ) ;
  }

  @Test
  public void test2949() {
    coral.tests.JPFBenchmark.benchmark51(9.317098422779289,11.08498890520563 ) ;
  }

  @Test
  public void test2950() {
    coral.tests.JPFBenchmark.benchmark51(9.320554424288076,35.15507138685717 ) ;
  }

  @Test
  public void test2951() {
    coral.tests.JPFBenchmark.benchmark51(9.322800435488766,40.67719956451123 ) ;
  }

  @Test
  public void test2952() {
    coral.tests.JPFBenchmark.benchmark51(9.32661070563276,39.79885459457017 ) ;
  }

  @Test
  public void test2953() {
    coral.tests.JPFBenchmark.benchmark51(9.327117890291778,10.53807175277693 ) ;
  }

  @Test
  public void test2954() {
    coral.tests.JPFBenchmark.benchmark51(9.338550453939717,18.46604637528418 ) ;
  }

  @Test
  public void test2955() {
    coral.tests.JPFBenchmark.benchmark51(9.34381813239979,24.996072063484405 ) ;
  }

  @Test
  public void test2956() {
    coral.tests.JPFBenchmark.benchmark51(9.344432713174513,38.62855543523898 ) ;
  }

  @Test
  public void test2957() {
    coral.tests.JPFBenchmark.benchmark51(9.344956462868053,10.829962974737768 ) ;
  }

  @Test
  public void test2958() {
    coral.tests.JPFBenchmark.benchmark51(9.392963778391433,21.738348520980463 ) ;
  }

  @Test
  public void test2959() {
    coral.tests.JPFBenchmark.benchmark51(9.394269694490472,28.493322131528423 ) ;
  }

  @Test
  public void test2960() {
    coral.tests.JPFBenchmark.benchmark51(9.40372029705064,10.952417098535989 ) ;
  }

  @Test
  public void test2961() {
    coral.tests.JPFBenchmark.benchmark51(9.40736110600313,30.516721316367807 ) ;
  }

  @Test
  public void test2962() {
    coral.tests.JPFBenchmark.benchmark51(9.409270440218123,16.118499054244367 ) ;
  }

  @Test
  public void test2963() {
    coral.tests.JPFBenchmark.benchmark51(9.41012348004466,27.163032540548926 ) ;
  }

  @Test
  public void test2964() {
    coral.tests.JPFBenchmark.benchmark51(9.41914352988611,40.58085647011388 ) ;
  }

  @Test
  public void test2965() {
    coral.tests.JPFBenchmark.benchmark51(9.420842690318494,14.518574672343988 ) ;
  }

  @Test
  public void test2966() {
    coral.tests.JPFBenchmark.benchmark51(9.434220269176109,20.73905430155891 ) ;
  }

  @Test
  public void test2967() {
    coral.tests.JPFBenchmark.benchmark51(9.435097368336855,17.382944126556225 ) ;
  }

  @Test
  public void test2968() {
    coral.tests.JPFBenchmark.benchmark51(9.437874959574756,25.73741443598429 ) ;
  }

  @Test
  public void test2969() {
    coral.tests.JPFBenchmark.benchmark51(9.438935893783487,15.770487293413183 ) ;
  }

  @Test
  public void test2970() {
    coral.tests.JPFBenchmark.benchmark51(9.451804119611921,10.669575295494408 ) ;
  }

  @Test
  public void test2971() {
    coral.tests.JPFBenchmark.benchmark51(9.456414392732569,11.407819970863926 ) ;
  }

  @Test
  public void test2972() {
    coral.tests.JPFBenchmark.benchmark51(9.457941061619962,13.926171644329827 ) ;
  }

  @Test
  public void test2973() {
    coral.tests.JPFBenchmark.benchmark51(9.463446155526526,20.292395369932677 ) ;
  }

  @Test
  public void test2974() {
    coral.tests.JPFBenchmark.benchmark51(9.476083030175886,14.332862561669572 ) ;
  }

  @Test
  public void test2975() {
    coral.tests.JPFBenchmark.benchmark51(9.478517896614932,18.14798695331625 ) ;
  }

  @Test
  public void test2976() {
    coral.tests.JPFBenchmark.benchmark51(9.47898990918658,10.831711204303936 ) ;
  }

  @Test
  public void test2977() {
    coral.tests.JPFBenchmark.benchmark51(9.487962670047352,29.516272266060867 ) ;
  }

  @Test
  public void test2978() {
    coral.tests.JPFBenchmark.benchmark51(9.494052435628092,29.38015386843844 ) ;
  }

  @Test
  public void test2979() {
    coral.tests.JPFBenchmark.benchmark51(9.494898986799257,18.82888265654941 ) ;
  }

  @Test
  public void test2980() {
    coral.tests.JPFBenchmark.benchmark51(9.505649611305913,26.634463106488155 ) ;
  }

  @Test
  public void test2981() {
    coral.tests.JPFBenchmark.benchmark51(9.507173739052526,18.72378820911102 ) ;
  }

  @Test
  public void test2982() {
    coral.tests.JPFBenchmark.benchmark51(9.51036162595191,22.351858444288382 ) ;
  }

  @Test
  public void test2983() {
    coral.tests.JPFBenchmark.benchmark51(9.513373324456651,28.549269420600382 ) ;
  }

  @Test
  public void test2984() {
    coral.tests.JPFBenchmark.benchmark51(9.51910252223741,33.8219175138795 ) ;
  }

  @Test
  public void test2985() {
    coral.tests.JPFBenchmark.benchmark51(9.523610881859284,36.55684550978776 ) ;
  }

  @Test
  public void test2986() {
    coral.tests.JPFBenchmark.benchmark51(9.535372071065419,40.4403032069616 ) ;
  }

  @Test
  public void test2987() {
    coral.tests.JPFBenchmark.benchmark51(9.539583517560729,33.21173214496963 ) ;
  }

  @Test
  public void test2988() {
    coral.tests.JPFBenchmark.benchmark51(9.541018823598165,15.512585642107709 ) ;
  }

  @Test
  public void test2989() {
    coral.tests.JPFBenchmark.benchmark51(9.542178970577922,22.488950212276166 ) ;
  }

  @Test
  public void test2990() {
    coral.tests.JPFBenchmark.benchmark51(9.560347297711385,12.9405606266169 ) ;
  }

  @Test
  public void test2991() {
    coral.tests.JPFBenchmark.benchmark51(9.577627455704658,20.763902303185223 ) ;
  }

  @Test
  public void test2992() {
    coral.tests.JPFBenchmark.benchmark51(9.5810492328498,14.175020875396198 ) ;
  }

  @Test
  public void test2993() {
    coral.tests.JPFBenchmark.benchmark51(9.58136400359922,40.404778616271614 ) ;
  }

  @Test
  public void test2994() {
    coral.tests.JPFBenchmark.benchmark51(9.582536601118278,34.05921102068484 ) ;
  }

  @Test
  public void test2995() {
    coral.tests.JPFBenchmark.benchmark51(9.585517860259273,31.72777278928828 ) ;
  }

  @Test
  public void test2996() {
    coral.tests.JPFBenchmark.benchmark51(9.591877035988105,13.299560254747384 ) ;
  }

  @Test
  public void test2997() {
    coral.tests.JPFBenchmark.benchmark51(9.601378644109573,17.74193824429102 ) ;
  }

  @Test
  public void test2998() {
    coral.tests.JPFBenchmark.benchmark51(9.602654934467921,11.249519808579606 ) ;
  }

  @Test
  public void test2999() {
    coral.tests.JPFBenchmark.benchmark51(9.610441491091848,32.06590828912047 ) ;
  }

  @Test
  public void test3000() {
    coral.tests.JPFBenchmark.benchmark51(9.61282401145533,38.26292875127194 ) ;
  }

  @Test
  public void test3001() {
    coral.tests.JPFBenchmark.benchmark51(9.614717315659703,28.37264812813015 ) ;
  }

  @Test
  public void test3002() {
    coral.tests.JPFBenchmark.benchmark51(9.628080963382345,17.367616834102435 ) ;
  }

  @Test
  public void test3003() {
    coral.tests.JPFBenchmark.benchmark51(9.633629532480882,39.885558458612245 ) ;
  }

  @Test
  public void test3004() {
    coral.tests.JPFBenchmark.benchmark51(9.637388004512161,10.997919992254472 ) ;
  }

  @Test
  public void test3005() {
    coral.tests.JPFBenchmark.benchmark51(9.64034531977424,27.640166682855522 ) ;
  }

  @Test
  public void test3006() {
    coral.tests.JPFBenchmark.benchmark51(9.641170761929033,27.994397183292534 ) ;
  }

  @Test
  public void test3007() {
    coral.tests.JPFBenchmark.benchmark51(9.641541208932608,17.181686435989164 ) ;
  }

  @Test
  public void test3008() {
    coral.tests.JPFBenchmark.benchmark51(9.654486183640728,33.12144601249298 ) ;
  }

  @Test
  public void test3009() {
    coral.tests.JPFBenchmark.benchmark51(9.65895325706802,38.54219566456186 ) ;
  }

  @Test
  public void test3010() {
    coral.tests.JPFBenchmark.benchmark51(9.659673268855201,29.046125764597917 ) ;
  }

  @Test
  public void test3011() {
    coral.tests.JPFBenchmark.benchmark51(9.668615587396246,17.78816035352466 ) ;
  }

  @Test
  public void test3012() {
    coral.tests.JPFBenchmark.benchmark51(9.677372847921276,16.150392010455533 ) ;
  }

  @Test
  public void test3013() {
    coral.tests.JPFBenchmark.benchmark51(9.681591464788983,35.40447415873754 ) ;
  }

  @Test
  public void test3014() {
    coral.tests.JPFBenchmark.benchmark51(9.688484158051764,21.227677824007557 ) ;
  }

  @Test
  public void test3015() {
    coral.tests.JPFBenchmark.benchmark51(9.693278289543898,27.32347357487228 ) ;
  }

  @Test
  public void test3016() {
    coral.tests.JPFBenchmark.benchmark51(9.698077050568202,24.030807160558325 ) ;
  }

  @Test
  public void test3017() {
    coral.tests.JPFBenchmark.benchmark51(9.712717097740594,24.49527982844603 ) ;
  }

  @Test
  public void test3018() {
    coral.tests.JPFBenchmark.benchmark51(9.718592205210156,11.572022042472824 ) ;
  }

  @Test
  public void test3019() {
    coral.tests.JPFBenchmark.benchmark51(9.766064067216178,25.514307406515258 ) ;
  }

  @Test
  public void test3020() {
    coral.tests.JPFBenchmark.benchmark51(9.768457756475684,31.375665112439464 ) ;
  }

  @Test
  public void test3021() {
    coral.tests.JPFBenchmark.benchmark51(9.779829978033547,28.866760486129948 ) ;
  }

  @Test
  public void test3022() {
    coral.tests.JPFBenchmark.benchmark51(9.79026608416575,26.02308357905818 ) ;
  }

  @Test
  public void test3023() {
    coral.tests.JPFBenchmark.benchmark51(9.797977619829567,19.01050268853372 ) ;
  }

  @Test
  public void test3024() {
    coral.tests.JPFBenchmark.benchmark51(9.83015750987773,40.169842490122264 ) ;
  }

  @Test
  public void test3025() {
    coral.tests.JPFBenchmark.benchmark51(9.830293790206142E-26,0 ) ;
  }

  @Test
  public void test3026() {
    coral.tests.JPFBenchmark.benchmark51(9.833341551906827,12.300051552638337 ) ;
  }

  @Test
  public void test3027() {
    coral.tests.JPFBenchmark.benchmark51(9.842576323182962,22.749289035902947 ) ;
  }

  @Test
  public void test3028() {
    coral.tests.JPFBenchmark.benchmark51(9.850247274917393,19.25039328368132 ) ;
  }

  @Test
  public void test3029() {
    coral.tests.JPFBenchmark.benchmark51(9.850686886680009,33.94257012644556 ) ;
  }

  @Test
  public void test3030() {
    coral.tests.JPFBenchmark.benchmark51(9.860352474424765,27.741951460284838 ) ;
  }

  @Test
  public void test3031() {
    coral.tests.JPFBenchmark.benchmark51(9.867321454209034,36.59241094215707 ) ;
  }

  @Test
  public void test3032() {
    coral.tests.JPFBenchmark.benchmark51(9.872904067450932,30.33068015222733 ) ;
  }

  @Test
  public void test3033() {
    coral.tests.JPFBenchmark.benchmark51(9.87565323096058,11.11037215572832 ) ;
  }

  @Test
  public void test3034() {
    coral.tests.JPFBenchmark.benchmark51(9.879922040565447,17.533526829603858 ) ;
  }

  @Test
  public void test3035() {
    coral.tests.JPFBenchmark.benchmark51(9.898437952687544,12.46283257130571 ) ;
  }

  @Test
  public void test3036() {
    coral.tests.JPFBenchmark.benchmark51(9.899764996234495,26.34769181619086 ) ;
  }

  @Test
  public void test3037() {
    coral.tests.JPFBenchmark.benchmark51(9.906812387276972,19.287217558808777 ) ;
  }

  @Test
  public void test3038() {
    coral.tests.JPFBenchmark.benchmark51(9.92056143896673,39.75361718251966 ) ;
  }

  @Test
  public void test3039() {
    coral.tests.JPFBenchmark.benchmark51(9.929021048043783,14.996377262262037 ) ;
  }

  @Test
  public void test3040() {
    coral.tests.JPFBenchmark.benchmark51(9.93376321842095,39.59247484653994 ) ;
  }

  @Test
  public void test3041() {
    coral.tests.JPFBenchmark.benchmark51(9.936416975190383,15.477630713251628 ) ;
  }

  @Test
  public void test3042() {
    coral.tests.JPFBenchmark.benchmark51(9.95279672608074,14.633502987947168 ) ;
  }

  @Test
  public void test3043() {
    coral.tests.JPFBenchmark.benchmark51(9.955826346260551,14.059664521066324 ) ;
  }

  @Test
  public void test3044() {
    coral.tests.JPFBenchmark.benchmark51(9.965637804555683,17.64312835958515 ) ;
  }

  @Test
  public void test3045() {
    coral.tests.JPFBenchmark.benchmark51(9.96763148477315,38.91872349334301 ) ;
  }

  @Test
  public void test3046() {
    coral.tests.JPFBenchmark.benchmark51(9.967646306271675,22.832307668544956 ) ;
  }

  @Test
  public void test3047() {
    coral.tests.JPFBenchmark.benchmark51(9.974138894430212,22.96825050814553 ) ;
  }

  @Test
  public void test3048() {
    coral.tests.JPFBenchmark.benchmark51(9.97997395335781,26.84047542060948 ) ;
  }

  @Test
  public void test3049() {
    coral.tests.JPFBenchmark.benchmark51(9.98394144197574,28.07447433714703 ) ;
  }

  @Test
  public void test3050() {
    coral.tests.JPFBenchmark.benchmark51(9.987671248697595,39.453710923370664 ) ;
  }

  @Test
  public void test3051() {
    coral.tests.JPFBenchmark.benchmark51(9.997031054353371,36.33323596087726 ) ;
  }

  @Test
  public void test3052() {
//    	UnSolved;
  }
}
