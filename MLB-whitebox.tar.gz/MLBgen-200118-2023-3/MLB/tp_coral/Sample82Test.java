import org.junit.Test;

public class Sample82Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark82(0.0,-0.03759621892377396 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark82(-0.025479378594247513,9.860761315262648E-32 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark82(-0.16808202082341078,-5.949476303896972E-4 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark82(-0.2731173709628223,-3.661429503640482E-4 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark82(-0.28095100591455946,-3.559339453715893E-4 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark82(-0.38026507307131396,20.54919466104414 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark82(-0.6376971682483283,-1.5681424503528389E-4 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark82(-1.0000000000000002E-6,-100.0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark82(100.0,-1.5777218104420236E-30 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark82(10.11841616949279,9.882969658977047E-6 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark82(1.0626572730056499E-5,9.41037176710391 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark82(10.951233655365405,0.0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark82(1.0E-6,100.0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark82(-1.1102230246251565E-16,-69.62586012197548 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark82(1.1397569377180616E-6,87.73800508748182 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark82(11.435376118662425,8.744793259296557E-6 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark82(-1.166938676302669E-5,-8.56943059911599 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark82(1.1774878562187396E-6,84.926565885044 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark82(-1.1896984524266676E-5,-8.405491307148182 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark82(-12.886069850296487,-7.76031801485999E-6 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark82(-1.3769478580671901E-6,-72.62439126806817 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark82(1.3782950758043943E-7,725.527115643421 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark82(-13.795358991842903,-7.248814623661559E-6 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark82(14.071005650768166,7.106812581980648E-6 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark82(-1.4084335265766337E-7,-710.0086593245503 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark82(1.4104372580854452E-7,709.0000001104061 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark82(-14.158014863177565,-7.0631370970009304E-6 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark82(-1.4186538287012152E-6,-70.48935968512524 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark82(1.4210854715202004E-14,-5.278224918768559E-10 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark82(-143.43824031385267,-6.971641577670861E-7 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark82(1.5509271612756947E-4,0.6447756058517911 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark82(1.5879224678920493E-7,746.0000000712533 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark82(1.5937090072637439E-6,62.74671194316149 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark82(-1.7085352889776146,-5.85296661094076E-5 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark82(1.8333605222020655E-5,5.454464563243083 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark82(-1.9938027165267158E-5,-5.015541365807947 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark82(2.0165454522878434,4.9589757502133125E-5 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark82(-2.06477977571742,3.424061916760445E-21 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark82(2.0693334838974042,4.832473875193699E-5 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark82(2.220446049250313E-16,-100.0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark82(-2.220446049250313E-16,7.105427357601002E-15 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark82(-22.53040952187493,-4.438445732835028E-6 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark82(22.91624360072531,4.36371692247306E-6 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark82(26.359171547181575,57.55510899459185 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark82(-3.356690553424982,-2.9791247780634863E-5 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark82(3.7933932750709136E-7,263.61622101555133 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark82(3.8518598887744717E-34,-98.58407793334796 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark82(4.2351647362715017E-22,-100.0 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark82(-42.98508172241546,0.0 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark82(-46.18547237378921,-2.1651830079960632E-6 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark82(47.481876462808344,2.1060667237599196E-6 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark82(-47.867303184003,0.0 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark82(5.051217197925467,1.9797208523186782E-5 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark82(53.34679701165993,1.8745267870185935E-6 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark82(538.5333408531635,1.8568952044814483E-7 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark82(-5.434799609977787,-1.8399942320002083E-5 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark82(-5.603149685682706E-7,-178.47104862381642 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark82(5.836526244633974E-6,17.133479026490917 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark82(-6.098029601435329,-1.6398739628442627E-5 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark82(61.30619970764903,0.0 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark82(62.52507467451526,1.5993583457607485E-6 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark82(6.577848082282724,1.5202540215142335E-5 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark82(6.578725301711013E-7,746.6241357410684 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark82(-6.979346030888678E-6,-14.32798997775528 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark82(709.9999994067856,1.3234302063018847E-7 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark82(-710.0000473413711,-1.408450610537817E-7 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark82(71.27651235027135,1.4029867161369225E-6 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark82(713.4657051632049,1.4016090653441141E-7 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark82(745.9970432168013,1.3404878863279802E-7 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark82(746.0000000002372,1.3369927328641685E-7 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark82(7.577248715350076E-7,131.97402349670648 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark82(8.499662886022932,1.1765172494598888E-5 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark82(8.604530531790378,1.1621784550719383E-5 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark82(9.135173022892766E-7,109.46700160892328 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark82(-9.805536334030892E-7,-101.9832027473521 ) ;
  }
}
