import org.junit.Test;

public class Sample08Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark08(-0.0011111525889216066,-15.952900329494746,-25.612637495534074 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark08(0.0011429551581812487,-26.22126782789047,-52.412756234125084 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark08(-0.0011495275877791958,-100.0,-4.141724299456263 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark08(0.0014832942780067548,13.128548295563501,26.56532671275274 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark08(-0.0016072866015477416,-56.122967138046405,-17.413494342355715 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark08(-0.0016223205488273135,21.97057994002656,44.06306690995057 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark08(-0.0018715861611165636,20.123641613603414,41.70647426341867 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark08(-0.001907879087110969,46.8026171282453,95.13959837741434 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark08(0.0019938605145649662,-9.66043922778703,-19.135625276582008 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark08(0.0021904018588685403,-40.70053733918502,-95.39013716693121 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark08(-0.004419436722086122,-29.280784715676692,-58.561569431353384 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark08(0.005034082816631386,19.314521212318386,39.12048597636344 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark08(0.005360452087096283,-11.265886294984258,9.446243556109936 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark08(0.006361398521441797,10.822197117931713,22.81664752592057 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark08(-0.006639792905646473,0.7012327277787973,-17.46727040750947 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark08(0.00923406151039785,-33.92595990872586,-22.5715832675375 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark08(0.02090344911579749,-3.744772711261459,-7.121439040620488 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark08(-0.02141328448336154,-19.527569254185725,-39.09640727580782 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark08(0.0,-26.42966576331439,-8.626061102015555 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark08(0.031158521781328746,0.25093536718165566,1.4480992756287383 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark08(0.038072428474319485,10.65100675828491,9.54115365883708 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark08(-0.04114025284257142,4.5393977780659185,10.526171124399013 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark08(0.0,-43.40024607854985,-86.3606389145326 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark08(0.0,-44.773457307238886,-89.45159611444988 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark08(-0.06205356211996571,36.23782056063093,72.49519665440572 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark08(-0.0648586897864889,-11.38977501318191,-21.532089186650026 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark08(0.07613654753530344,-0.47192153818080024,43.71765905598557 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark08(-0.08069943293856618,-48.81397645024291,-97.5858862256736 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark08(0.08639378601103331,-92.2691807263455,92.18278694033447 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark08(-0.08986986609051917,-31.169212294487174,-62.15965841176173 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark08(0.0,9.629160241388844,19.265124206865913 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark08(0.10159971975114707,-24.15851510885419,22.486119062308152 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark08(-0.13126909431672645,34.5451104413009,69.36362697424696 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark08(0.1436566021125394,-23.61920797295779,-46.807446139577955 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark08(-0.16008546512572153,17.188913853509387,35.38234913608221 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark08(-0.180846817750016,-93.92060757947054,-100.0 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark08(0.21009062832365405,52.789723973519784,107.22144125729113 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark08(-0.263379606760025,-100.0,20.555925401983696 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark08(0.2728832752223756,0.15992535457208365,2.709272361172183 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark08(0.2751469134947402,-0.8000592858305376,0.5249123723357975 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark08(0.3117175298813777,-92.70128931424593,92.35624247785285 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark08(-0.3379808061740016,-36.88635542085357,-29.337859364790358 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark08(-0.34599722209760503,30.98707617710817,61.747845716493345 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark08(0.3563875077967168,-21.54283551791901,-42.016508512447864 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark08(-0.37223452377864596,-42.16366600740312,41.79046677661239 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark08(-0.3866168685061737,-16.336478982827078,-32.913241241558175 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark08(-0.4019405816975823,0.02862652186259851,0.3733140598349838 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark08(-0.4025324571700305,-0.052865450350740396,-0.742752154769413 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark08(-0.40681480318015384,-39.262309428843494,-79.72661021790073 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark08(-0.40923498954084475,15.352583954015163,29.751755663262816 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark08(0.41620075514163674,-78.04992082604085,2.7212662658011695 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark08(-0.45716786692460243,-72.37688313977625,-0.047472740465224206 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark08(0.4782323436385404,-4.947527673029728,-7.302938744956738 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark08(-0.48293149454358664,-5.772605002303725,-12.959563373743135 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark08(-0.5228363947620522,-97.36515975698303,-90.52947301167806 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark08(0.5314657929740516,1.706547179459052,5.19574125568633 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark08(-0.5367925108435911,50.08245899042373,98.56957135374424 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark08(0.5591055027110476,44.278709514114084,91.8055318631562 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark08(0.5846759113731732,0.006941826654642769,1.7679113874288106 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark08(-0.6043139675941107,-38.17109200661169,-77.41538835147213 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark08(-0.6091320578427357,47.06723498356183,93.87787012039036 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark08(0.6098562080257803,0.31548460064450284,3.795477058064329 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark08(-0.6238097813836121,30.53985314213163,60.66086595311332 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark08(0.6304241874410289,-0.29572074794207903,1.4256959425293816 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark08(0.671437133355127,6.377377755751319,16.338399596102278 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark08(-0.6889602304384245,44.934439692720424,95.45257321516584 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark08(0.6955234331431545,0.088832289546106,2.264234878521676 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark08(0.7191295471471209,35.32009952393091,118.1587167947448 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark08(0.7752376740375324,-29.877266517122496,-11.938813051785187 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark08(0.7835705425256044,-1.4947992645219952,0.7112287219963909 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark08(0.8474967340391686,-27.495578967169763,89.2149604558266 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark08(-0.8584305792958582,-0.9583819017369671,1.81681248102649 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark08(-0.8612731321075984,-24.538145133220144,-51.66010966276307 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark08(-0.8991480705146984,-31.0215132756874,9.855161135011633 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark08(-0.9429834366383516,15.076336142929877,71.75097103937162 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark08(-0.9587424755514011,-6.197600639355508,-15.18156244572882 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,100.0,-4.663358259962422 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,-100.0,91.01670554136125 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,100.0,-9.34726583274194 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,100.0,-99.9413142889467 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,-1.0614315865578743,101.06135399978497 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,-1.0619298297467996,100.15828471456972 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark08(100.0,-125.60579629396914,93.16046412301074 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,-1.570796326794826,100.0 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,-19.27137732035647,71.35981639520035 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,-21.640226070958505,2.4763674422690642 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,60.329027892934924,10.525526473391565 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,60.76188829485725,48.07822403736023 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,62.258262794580595,39.63912322505641 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,-65.55109620623553,29.109498088978597 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,71.75973706801142,26.669466605193684 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,81.73236280109612,-98.63717673612207 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark08(100.0,-86.46935327702222,100.0 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark08(100.08962361104295,-112.59224775773352,76.64265023486371 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,-92.20020089701781,-100.0 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,94.12729080883989,-73.94838040472776 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,95.840505767479,3.008645679614119E-4 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark08(100.0,-97.88905626258504,99.99999987906726 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,98.2105192465346,-15.30017145023183 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,99.64009578889525,-100.0 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,99.7058266210674,-100.0 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark08(-100.26085827669273,104.79383757446337,-90.81462731579454 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark08(10.036060175369768,-26.78484817610864,-21.958162924871026 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark08(-100.40419247227116,14.71307471363869,-157.58496911740224 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark08(1.0101911485489072,-71.15657761576338,68.57559014041959 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark08(-101.5641613786932,7.176189610657058,94.37968988394965 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark08(-102.20314881303797,2.20314881303797,100.0 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark08(-10.255414675006364,39.59367358268514,94.51945214295415 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark08(-10.263928665146032,-102.89592690566109,34.002281967964194 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark08(-102.8274179004942,270.0482925249105,231.80495475400227 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark08(-10.338415117568136,14.720416129290609,-0.0036167864954791307 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark08(-10.338685919412121,-9.254313214689368,-49.522039262773106 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark08(10.34160047267981,-63.17930281761926,-7.048902784959887 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark08(-104.42708315941229,-33.99289942698405,-21.915513064009133 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark08(10.45307379365925,-49.544700415999166,-66.1593837790381 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark08(10.453493552306105,-16.5282414869985,-0.21251450476424905 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark08(10.47485055109017,31.219708093519525,125.61593327366423 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark08(-10.508425618108047,9.817770920190323,-10.318938687148599 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark08(-10.521185978437114,-0.830961853790224,-31.65468531609689 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark08(-10.657255470827282,62.724564269148225,95.0481584526095 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark08(10.670323871701457,-22.979329466524938,-12.827762721650462 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark08(-10.681269607791105,-1.1841643273382658,-32.84134115125495 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark08(-10.690422484359974,15.391747792482263,0.009546343774935961 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark08(-10.71690071115458,65.86518837294535,100.0 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark08(10.750754007650324,-17.86764361757196,-2.3463740219806355 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark08(-107.55663157570527,-56.784828956019894,48.07140495842792 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark08(-10.761264051487332,13.702347717196714,1.4297903783076924 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark08(107.62537888199653,-269.06566021189144,-215.1546267580588 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark08(107.63056062028949,-208.74692428993117,175.87083981742893 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark08(-10.781711190725627,-47.40153239236591,-126.39825975869198 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark08(10.866193595985548,9.202650659414875,52.18827505845087 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark08(-10.904440886242853,3.1820103062595644,-90.54092818562886 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark08(-10.939397810666861,-83.53599990598451,59.27623618268211 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark08(-10.969111981411077,11.727149578575037,-8.612019231139637 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark08(11.010809437481255,14.459289030243152,63.52071823760152 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark08(-11.016696499185656,-16.635334687779007,-66.32075887309527 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark08(11.024638117851616,-7.579371137081759,-0.29749103002607485 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark08(-11.025475523196054,14.533179570741504,-4.0100674281051525 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark08(-11.030193188819728,-30.116670348568462,-49.02314327294939 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark08(-11.077852412453279,-20.837818454994544,-74.89848108957796 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark08(1.1102230246251565E-16,-29.754466541685307,0.960463712467492 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark08(1.1102230246251565E-16,8.927260719865794,18.37252427806398 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark08(-11.126981845781064,14.609507375612537,-3.4825255298314737 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark08(-11.127804894618492,-100.0,75.58374833292433 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark08(-111.50024382059034,-16.172865835706578,99.6800447283828 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark08(-112.32641910470916,100.0,-91.70695929815395 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark08(1.126406403803586,-26.27852532932569,-35.664154295957466 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark08(-113.04145311080447,-16.408156465253477,-3.367972567502875E-12 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark08(-11.340603086754385,39.37367951703377,77.48722981033964 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark08(-11.39812136624747,-35.40270648205994,45.89377420668259 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark08(-11.41034515778433,21.611856405631276,-9.856878583641668 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark08(-11.417305440301739,-70.52879517891587,-174.66711142660057 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark08(-11.434232890821479,-0.6394724496704729,-26.669145323095158 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark08(1.1450556471727727E-5,-31.22725296968174,-60.883675260899416 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark08(-1.1463194809287143,-34.76120293580317,34.336726089936995 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark08(-114.96324727446058,66.60105847069673,2.22052376114992 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark08(11.534685935237443,-0.002022211771428425,67.34222613824672 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark08(11.607322477268902,-26.505715058277907,-16.69031540896032 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark08(11.623409245264831,-132.2272382153408,-65.277319630341 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark08(-11.658715544335507,-69.82565747679462,-54.48865439774884 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark08(-11.669030504385248,11.570323923176888,-11.172115356306113 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark08(11.677384309187364,-15.014569891181646,6.573809471993698 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark08(11.68531167755846,-15.42945209091768,5.636809435106536 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark08(-11.688207862833082,-88.77162012839553,77.87355601851581 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark08(-11.771974947841038,-82.45824502703613,27.229320046074456 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark08(11.791219991466907,-4.35075641445959,28.24294347227644 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark08(-118.01673874575972,-194.32533374152717,157.30102097288636 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark08(-118.31707384045502,86.94572897274197,32.94214126103333 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark08(11.86672229431208,-16.332222440649034,2.9357220016381733 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark08(-118.75757099450821,-65.71606490231646,154.61858583157084 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark08(11.945358489274005,-8.385122404879176,20.636626984858555 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark08(-119.4727700833892,-5.46703836701782,-98.60469175329291 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark08(-11.961326986457662,-30.827453857523174,-95.96809234762443 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark08(11.968824779453126,-16.166152168027192,4.197327388574068 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark08(12.176946274231197,-16.25098485525021,4.07403858101901 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark08(-121.79850486623953,96.3008929762519,-9.09329948381826 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark08(1.2205404947760983,-1.8136105320846545,0.5930700373085562 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark08(12.24731375005828,-17.56649094529943,1.6089593595759788 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark08(-12.25495824840678,0.003494294452228361,-36.681622941531394 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark08(-122.66491858587523,246.89046712400574,126.87475393007296 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark08(-12.276810170682685,-25.962877861782594,-87.18538990881837 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark08(12.279466168470837,-10.338120871502326,48.700461046075915 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark08(-122.83904920288978,-57.69605162248478,75.30799830728172 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark08(12.321082349299777,-36.099658810085955,22.207780133991285 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark08(-12.331075793917599,70.36167622732741,103.73065879620522 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark08(-1.2361301135066562,-8.82729020719663,-33.829423360162714 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark08(-1.2374054505162488,0.7559658452030331,-0.6294883343477848 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark08(-12.38901108898176,-71.8960365094879,-43.98506846253076 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark08(-12.393037009958778,-68.1502715269348,-15.931229894885519 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark08(-12.40633679786472,-2.928327955715943,13.763868426785766 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark08(124.1762706418092,-282.69536900507256,-134.9153695025758 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark08(12.430815302900513,-50.541664751125296,38.08817611105547 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark08(12.455593943124313,-0.20369505489455264,37.60405604837462 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark08(12.544761195826599,-16.729052033240123,4.184290837413522 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark08(-12.585379688218246,0.11622699454417784,5.369290082003147 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark08(-126.11663838911356,-72.34463451783866,43.61436600178281 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark08(1.2655701357863682E-4,-46.07793997150181,-90.64639565386167 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark08(1.2687855774273196,-93.35498284366528,44.33582487032068 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark08(12.714925770583417,-38.477676950089965,-38.255160232103435 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark08(12.723227938603186,-64.03338614568892,4.374616851061148 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark08(-127.3010936646813,-90.62926801788808,-91.83729778655288 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark08(12.783228717114868,-33.74010252325192,-27.867817488251767 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark08(-12.842804179633703,-32.59221350923799,-2.5558095183288785 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark08(-1.2855266272554218,-43.51990120531392,3.9022233359020504 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark08(12.882370851115212,-47.47722325342704,45.501685036618206 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark08(1.2891443061934484,0.2816520206014483,-8.069601792543798E-34 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark08(-129.08699208814264,45.20786370211392,-75.76080625262584 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark08(-12.91819873918574,-16.86183123476451,28.2092336471525 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark08(1.2924929206233235,-42.95300681662263,-70.48865146961808 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark08(-1.3013325164150187E-5,28.501293165678195,57.002549637519934 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark08(13.05929837040214,-81.10316913315306,34.213997160970706 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark08(-130.87086753220854,247.20858477491075,103.34667838990254 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark08(-13.087230312869895,-46.41558442351342,24.98677301114034 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark08(131.04303996631367,-286.9899371447202,-148.9875236373217 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark08(-13.169678705289122,-16.088743681023736,-71.30297405281416 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark08(131.7478750609768,-251.09350046773642,-105.41635289092918 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark08(-13.196713773182738,21.05162238091763,5.7046809760877596E-5 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark08(-13.202887076597602,23.445996347466952,8.85412779193597 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark08(-13.203051928947843,-80.44422003512295,-30.253794479610157 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark08(-132.40321653844262,150.65930441045845,-152.68358631253128 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark08(13.297229975443386,5.859542831702402,51.61077558973497 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark08(13.308252900741024,-124.0082543552815,19.54836433781118 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark08(-133.31611265146202,234.22297110582127,169.1161695761369 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark08(13.454854695353504,-30.629905432649608,-20.72566262576727 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark08(13.537717169910778,-37.3498859565856,-32.51582407664398 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark08(-1.3563681135183208,-0.6667490766944023,-5.21076079929659 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark08(13.598503737431434,-18.594374189992116,4.9958704525606805 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark08(13.64084280414831,-23.884662907853635,-5.279267598637274 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark08(13.646493566797641,-10.45845932174499,20.04280203808048 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark08(-13.6609766726054,-1.335198958941163,95.34397893160983 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark08(13.66676104379492,-17.431656084216883,7.707767289745653 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark08(13.680636237085235,-7.181394183947598,26.67912034336051 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark08(13.731359529862992,-57.961213327362856,-43.06213073350909 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark08(-13.734425328820155,-39.74075040292093,-0.0028778842413657232 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark08(-13.763165227234248,17.907115688668,-4.143950461433751 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark08(-13.783395082329339,62.58730463736672,83.82442420205174 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark08(-137.94500048136555,268.5606787944706,124.81303224743951 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark08(-13.797936955040452,8.311507990034188E-4,-39.82301453832652 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark08(-13.873262060576728,-26.458357070795937,-93.19154132452088 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark08(13.901696177366297,-29.623453961101536,-17.54181939010417 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark08(-1.3932939058069138,-92.34826500205716,32.07388852339669 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark08(13.951114022330579,-40.48195111098958,-39.11056015498739 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark08(-13.996924646040691,18.01535957690689,-4.389258457513402 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark08(-1.4075701573846542,-24.892331796470387,-53.81075942336962 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark08(-14.144972222681274,7.864344752276047,4.70986026576478 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark08(14.225414278117533,-60.64675624502295,-64.93466154493785 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark08(-1.4272215083821076,9.782020019323625,16.853171840295822 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark08(1.4283301945814244,45.84995336353194,97.48497850745858 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark08(-143.08802121607457,105.06430174796375,-219.13153597006078 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark08(-143.15920905059605,241.0456118669163,153.32530915510455 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark08(14.333609638946319,-46.12102174116574,-10.077055649009369 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark08(14.34611971129441,-94.0889917626099,-100.0 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark08(14.361881146435847,-68.28843228811577,133.0073764510394 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark08(143.70052740338934,-139.70371213677413,164.26516926327142 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark08(-143.75082735000285,105.84659691114415,-218.36020257989145 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark08(-143.8652906295681,119.07789760077155,-192.29257428021396 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark08(-143.88977503024924,100.44811947067181,-227.93773104687295 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark08(-143.89539402657323,100.0,-231.45493374943186 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark08(-143.92160718029973,125.34599045872787,-199.92658628040815 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark08(14.39548659364269,-40.516689787569604,50.6302639535552 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark08(-144.1979026856315,98.03284117670512,-235.01669380496892 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark08(144.39695231100882,-89.44093033802024,256.06057685689836 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark08(-144.55806051933055,98.51860604696208,-235.8904924241249 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark08(14.455872533137178,23.38409024586808,91.21729211736077 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark08(-144.73176686922218,119.6162318346284,-193.54821280456397 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark08(-144.9217707485744,88.74137967524359,-256.14845830435263 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark08(-14.497741826901862,-0.02075870236563168,1.79409722660012 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark08(-145.07523957333086,126.40563646495326,-181.6409713451306 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark08(-145.1564574077341,119.05039260598663,-194.90376363765188 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark08(1.4524776793338812,-23.83930976317445,-41.13981596308673 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark08(14.54904392206005,85.610076708684,-68.30828178556825 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark08(-145.59412078710815,87.07607264631599,-261.75910283331285 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark08(14.64468983216678,-16.827659370932995,11.849373260884107 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark08(-14.645493015590782,-6.393607364572897,-56.19472433515289 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark08(146.46711479344447,-128.36721819691607,182.8793834117654 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark08(14.67414768052015,-41.71324297453029,61.664530792780994 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark08(-14.726227595735327,24.327476424394664,4.580821961602919 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark08(-147.44229199168845,141.96301709638436,-157.549915627961 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark08(-147.4972004931314,-221.4352874649283,120.4393084773346 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark08(1.4783306587495066,-2.1812630051525037,0.7029323464029974 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark08(-148.04960020300354,172.36954608920576,-98.24826039566837 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark08(14.81804226644026,-11.956243690939976,20.698864373821923 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark08(-1.4824890902380758,-45.73482664323822,43.06341812951791 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark08(-14.838339811762197,-16.006385839386695,1.76474150949457 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark08(148.47371905218372,-129.46926673169455,182.3124141065266 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark08(-148.7517759600454,99.02208951752738,-244.89036539540348 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark08(-1.487793898145321,0.16544162645656355,-2.56170211472794 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark08(14.88337746501529,8.579422703674281E-14,66.6454410921405 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark08(14.892046991203149,-0.03640869114170808,46.17411991812092 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark08(1.4899557614441505,-0.19603725470631161,49.148744071666414 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark08(14.901854029836503,14.533009379140623,87.49421641865835 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark08(-149.0572415425188,150.58412844620412,-146.00346562661346 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark08(-149.35802825335904,100.62107726945406,-245.5779676023426 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark08(149.46182844975255,-130.93101086070627,187.771193331836 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark08(14.948942131496853,-72.33767416252698,57.38873203103013 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark08(14.951588311689996,-7.17275455244555,31.336229389453926 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark08(-1.496630336081172,23.529937983245382,10.622235044455053 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark08(149.9763060882444,-141.32026401402558,173.64264223896794 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark08(150.12593318075014,-150.30420706067198,150.3321635527971 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark08(-150.13601221491842,137.29040598567124,-174.34418035367125 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark08(-150.24472807726653,143.9492821320212,-162.64800584502015 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark08(-150.39232221395875,87.72820652702939,-275.3130410717016 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark08(1.504452432796085E-4,-40.780483110555615,-81.49654114711304 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark08(1.505827831569232,3.158939231975829,0.1042391014381151 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark08(-150.58910473117265,132.03713050952683,-187.41809439176438 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark08(15.066434190471117,-20.907660243888085,4.270429726621966 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark08(150.75150837875228,-100.0,253.64582106027837 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark08(-15.082706934117624,53.24187953538741,62.80643459521684 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark08(-15.093605789500442,-33.62861149683005,1.2770440846560973 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark08(-151.10049589252426,153.57674100472778,-145.71283230120363 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark08(-151.25064048859778,130.42024984343618,-192.78874403612787 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark08(-15.125614104727461,36.49753628309719,29.189026578806764 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark08(-151.5786002391179,151.85650138225958,-149.62116376067127 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark08(-15.16419603279551,65.68369480550453,87.4453318130047 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark08(151.7033294794925,-100.0,255.24924350506132 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark08(-15.180938660463717,-90.54496538111545,0.0011427650367367877 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark08(151.8367154113632,-100.0,255.74532859084604 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark08(-151.84623796179352,100.0,-255.46769105854213 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark08(-15.20409399618612,8.64116910999212,3.636947061743326 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark08(1.5208910221016902,-54.44447656055073,52.923585538449046 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark08(15.220803951242106,-19.563116000645383,6.53670828499562 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark08(-15.268225630593307,-3.209410429855019,-52.20819864867464 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark08(15.278757379895506,-34.36063017910344,9.65670291795766 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark08(-152.92942431481495,147.1444496451819,-163.09570808377882 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark08(1.5338178967264277E-4,-40.5319751195716,-80.24149126091478 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark08(-153.4567832640429,160.81639092357622,-137.9173120595149 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark08(1.5389285133839078E-15,-28.996904663894494,-56.42290670507831 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark08(-1.539047551702963,-22.78120375845505,-48.60947251800207 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark08(-15.432686435653963,19.881398289485734,-13.290340527477904 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark08(15.437001481975374,-21.941952043536222,3.9978766801642682 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark08(-15.443399903248695,46.62503180891684,47.89589977680751 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark08(154.6142639705615,-100.0,264.41610626855805 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark08(-154.96947968424564,121.4412587067473,-0.6397691018366345 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark08(15.499404633145032,-9.242595204427927E-274,48.06660061811369 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark08(-1.554442482814645,-30.14457225385067,23.46632342917013 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark08(-15.5499490886301,-96.56413386818313,99.99999999999999 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark08(-155.74697418219154,138.42499586574604,-189.83089747970587 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark08(-155.89467448001324,98.64512083759456,-269.34022273128153 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark08(-155.94993760253328,-92.89928133399836,-43.6512787209451 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark08(-15.604360715773327,25.658518621279278,4.672591509301547 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark08(-1.5606141899600383,-31.94306854087999,-56.37970963648575 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark08(156.0812709210984,-149.86861949257096,169.17833688729775 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark08(-15.616499438029523,3.5607478127928447,-38.66265065118416 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark08(-156.19429046200196,137.37267229729432,-193.82317124529104 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark08(156.24358285756526,-106.33447762414386,256.5613144828941 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark08(-15.626165879651701,15.382067613062658,-17.246148487054057 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark08(-156.28978349472868,124.60688126851949,-218.52831927710588 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark08(-156.31622591393716,100.0,-269.4297281240795 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark08(-156.335663534017,122.67193611074553,-223.477895975115 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark08(-156.4553635233031,162.58531574121426,-142.85247826502066 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark08(-156.56410957895403,162.7769505170103,-143.51251143369993 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark08(1.5707963267860912,-3.141592653577959,-3.032598237975918E-12 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark08(157.37035190778835,-288.8720304151269,71.67431485748952 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark08(157.53466766154446,-143.5493707643409,187.007037583716 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark08(-157.54067846096666,158.2940101740665,-150.43153603831365 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark08(-157.76345128708385,189.94178116050333,-93.23878143198151 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark08(-158.00121587554432,88.68116861168025,-295.1744910606339 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark08(-158.20827761395768,183.61682358802642,-113.37314025294316 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark08(15.829345243395348,-26.93004337726749,37.80846977371985 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark08(-15.842923530869765,-0.06550592141620294,-47.32239236281493 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark08(-15.857665773899887,-97.52052192479545,-53.60119160739595 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark08(-15.896098354549785,-0.8741781103292192,13.503680851870321 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark08(-158.98718861799935,178.60641060532168,-119.42111367781797 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark08(-159.1081473311422,157.7199074481057,-161.4560336806999 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark08(-159.17060401693877,145.64976921821543,-186.1721069467421 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark08(-159.21561093554584,151.59970064675105,-173.9528283781614 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark08(-15.95389118804374,14.829215799460371,-18.077901606895352 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark08(-159.61662568549505,179.31143789036201,-118.84431117099416 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark08(160.13482509436727,-166.25360547034586,149.3110068181953 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark08(-16.08178073735173,15.835111114865626,-15.260315658930455 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark08(16.111848336238864,-4.551652501357516E-5,48.354653758903524 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark08(-16.114105659198653,19.112284243334624,7.105427357601002E-15 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark08(-161.35260581298283,180.8703662851398,-121.57279054887044 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark08(16.13886745641803,-11.389489457784194,20.383363231011863 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark08(-16.15841937910526,35.05018828183299,23.217100857462448 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark08(-161.81268630664079,113.30429029615257,-258.27061722629645 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark08(-161.93221433559086,179.14236432638742,-126.61909668722883 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark08(162.02296959231816,-101.31977913825256,283.54617892527756 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark08(-162.5811292233265,143.22139522356417,-199.91863513885457 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark08(-16.267497402976332,-3.8243917274915162,-99.46834275719476 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark08(16.27928104453042,-21.9460000591244,5.666719014593979 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark08(-16.280415524933872,-69.91758817627361,-0.11143460848808395 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark08(-162.9138944121845,137.33989290412435,-212.5174455018286 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark08(-16.403046540445743,-9.018988649401944,-65.68415176425631 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark08(164.3284964138692,-137.75725997685078,217.53393217333394 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark08(-1.6443605934650127,49.653231271733425,95.9432978977514 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark08(-16.4457850595493,1.519498103088697,-1.7513905754080115 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark08(164.56673455825606,-216.324125327722,92.59809731187653 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark08(-1.6510343840162095E-9,33.8544638098266,69.2797239399525 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark08(-16.573764779309514,-36.51946356590145,10.882466349771873 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark08(16.591489791292503,-22.17921226249277,6.986841175686749 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark08(16.594576546699713,-33.96437011399851,14.50889378091357 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark08(16.613010729444255,-29.0665560859401,-6.723856532418961 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark08(-16.647334139943883,-39.02534086745897,86.01780524425347 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark08(166.54177810833306,-197.19290879737724,105.79823070892932 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark08(-166.9758530664025,199.3752798495184,-100.94366753943592 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark08(-16.700331528648235,16.928122502749048,-15.146594755880312 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark08(16.70040979272566,-22.894045854170134,-0.6656193106157815 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark08(-16.746563977373853,-18.61466518357927,-87.20390662208955 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark08(-167.4924510984871,100.0,-219.8145762930486 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark08(-1.6782483901763723,-15.858518461367204,-35.87193472109153 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark08(16.79365413487642,-97.94450076618976,-100.0 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark08(-1.6803060752893142,8.910028733842081,13.118996193732109 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark08(-16.80559028762535,42.421045274467765,35.99611601285437 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark08(-168.284051671714,98.68935546429209,-307.2385216315751 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark08(-168.38762886447861,157.26873956659134,-189.29414234424888 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark08(-168.46900788923122,145.49950685565,-169.64717445869033 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark08(-16.85879072776245,21.441769368875065,-6.122037118742326 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark08(-16.863299595538095,21.62724741487043,-5.764607630078532 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark08(-16.86447778191945,22.295716152100148,-5.4312383701807 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark08(-16.87324184795467,56.35543181463717,62.36978766268065 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark08(-168.78910520942347,162.3640312941406,-181.48240833520458 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark08(-168.79688826736327,-21.157335426654118,162.75093719109447 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark08(-16.89228623364984,2.0414894152477603E-4,90.42295951627027 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark08(-169.4372789420505,94.42706250982332,-319.43869122929357 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark08(-169.6389381501345,167.7846732993763,-173.2047195275351 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark08(-169.8818890207076,182.77925257178106,-143.5650750724354 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark08(-170.08018607083446,169.093651073309,-171.75654941489418 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark08(17.049349625982167,1.851681822557457,98.93787051830166 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark08(-171.06057655892252,154.77631189130386,-202.1436255388965 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark08(17.126604185754488,-89.85085638970797,-35.28177222099312 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark08(17.182071466924057,-22.95072016946543,5.768648702541373 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark08(17.22767613135758,-154.3506332104424,-231.07860749777595 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark08(-172.4650542142673,117.49315751443692,-273.37352713806854 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark08(-172.75658804143268,77.77047891466765,-362.4756942813882 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark08(17.279455716879,-23.173598048531392,5.491171053574216 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark08(172.89628308471993,-184.9960126772436,149.9119052652131 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark08(-1.7301177475708753,-46.62923611322049,-98.44484752117005 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark08(-173.37456971399988,166.42476548133132,-187.25647533820145 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark08(-17.342642093850422,7.471511970968527,24.584711916274923 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark08(-173.43718930236116,218.01967197117264,-85.42079908367803 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark08(-17.34492970682641,-47.20359435509877,10.87091011197657 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark08(-174.28373787732255,-141.8831026467564,174.3273361049026 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark08(-1.7430940144598233,2.1409225093694544,-0.397828494909631 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark08(-17.46182286732042,-80.63027555394157,-50.13952472718271 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark08(-174.84412417380997,187.41086776951494,-149.63221182854886 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark08(17.49308111714134,-23.845737213987412,6.35265609684607 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark08(-17.528762429645134,55.67635319376196,75.01515137569069 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark08(-17.56164685593365,65.02598052128775,78.915109285475 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark08(-175.92466660322705,107.0275644150269,-313.51529291897276 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark08(-176.11906346933418,201.98298338310119,-110.82715861734997 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark08(-176.15933480590616,-204.0597856316072,113.13428154004323 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark08(-17.646499383153188,-0.670203384194198,2.2687628471914385 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark08(17.682818460001684,74.28847562704232,-99.7132729995617 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark08(-17.694947546625244,25.866246127692776,31.426942767261636 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark08(-17.707311924617695,0.14367483615586013,-59.978794158253365 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark08(-17.72166529808453,40.99071832012877,-3.590031312508754 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark08(-17.760993160571207,-16.90944995250483,7.245403743200697 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark08(1.7761933588443632,-34.79659168815515,31.3332441894225 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark08(17.798622048099443,-23.528287683031028,7.910087105031163 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark08(-1.7893538898948473,-56.424982631751874,-22.96489678911834 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark08(-179.67824354240457,188.54225102864754,-161.3125382891291 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark08(-179.8511587064802,149.67568658607718,-239.97662549829366 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark08(180.15190945161544,-181.59845844390924,177.2681867595538 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark08(-180.2061846057263,173.125812829848,-193.00275317210213 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark08(-18.040694147042103,-37.784380061750134,-46.232410698782765 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark08(180.9086175236672,-82.13367474888662,378.5837831608814 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark08(-1.8096361764222515,-0.09354836478921075,1.9031845412114623 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark08(-181.27214390303328,149.52818243557087,-244.47301496022237 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark08(1.8146194771796047,-14.737035777271553,-24.030213123004287 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark08(1.8167620279238526,-38.03178596982284,-69.04248952907923 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark08(-181.72619454338195,149.9293523381461,-244.03583140601756 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark08(182.08162632284498,-220.14571793004555,107.06996019314633 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark08(-182.08655766177566,90.6670110182242,56.323603657769425 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark08(-182.26182591050005,194.76899631164605,-156.75661534149523 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark08(-182.4598284640845,161.78602208879187,-223.29884472293628 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark08(-18.343724339367025,23.58531755588772,-2.6685661491929578 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark08(183.5548883524541,-197.4548905235824,157.20492961452794 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark08(-18.36083032902095,-9.718694629252298,26.252374732211866 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark08(-18.38524482169342,-16.0838208288623,-85.75257979600997 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark08(18.41653967065163,-27.697508488548298,-1.639473637480116 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark08(18.487877221347755,-83.60311167948167,-112.27881447756792 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark08(-18.525714732788988,-5.069844286849145E-4,-55.301205642647865 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark08(-18.55083281012777,13.812545336520019,-19.726522694082263 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark08(-185.6255572009062,256.7002484529411,-69.13275713319969 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark08(18.600959711118733,-47.87590529924357,-38.37813513833605 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark08(-186.0373873563556,131.5315323608736,-169.08554028310417 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark08(-187.1920446254444,241.68333069163972,-78.19415688704674 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark08(-18.74354031092028,23.963932532628846,21.39905276198048 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark08(-18.754741875487856,25.772163617282544,-1.0236899972729636 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark08(1.88493557720345,-27.806548866925358,-53.998606528035005 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark08(-188.96608257656024,208.1174720918686,-149.54078359978791 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark08(18.9169722527093,-25.30941464764646,6.392442394937159 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark08(-189.36035874089643,185.57545198277342,-195.83815460945578 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark08(-18.94870187882145,26.46132284505431,-2.3526636195608366 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark08(-19.118468079029775,-55.86314980072267,-149.39653111902143 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark08(19.201232269104572,-74.47247290618118,-89.80277275532733 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark08(19.241095581993907,32.59196594739234,-1.3409925649685985 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark08(19.29894563881942,130.09805257057738,349.67177842659 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark08(19.338442731656432,-57.644580698359356,37.067389116738205 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark08(19.33995546879362,-21.931382040541614,45.85429571471886 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark08(19.359958655153612,-33.03402779256895,-69.7422243688841 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark08(-194.44166696693603,239.99049290315313,-101.09774498606824 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark08(1.9490429826510707,20.963221714639477,49.34436870402706 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark08(-19.510001396645464,-95.98577681651204,15.977711232713858 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark08(-195.14368707413368,255.94463438304464,-73.36730946756605 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark08(-19.550741782502055,60.61883753437907,64.15386479223145 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark08(-19.61390421644523,27.740299431033947,-13.179142184720675 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark08(-19.6188545838802,-75.94790651885974,15.622800301799572 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark08(-196.27756682819725,84.22158219114586,-268.09914160518235 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark08(-19.647954610122266,-3.755102221711552,-65.61293305604961 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark08(-19.650795873845315,26.14421853504934,-5.093154948444669 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark08(-19.66561426939561,25.780418459451532,-6.114804190055921 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark08(19.787261642382724,11.367244489408607,82.48322806243684 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark08(-19.787560610717605,21.923796473076443,-15.515088885999928 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark08(-19.83718363052012,-49.881108693342895,-64.9166029250789 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark08(-19.840733647106184,46.17408356436212,34.39668849272947 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark08(-19.851108057059463,-20.390156494667664,38.67046822493223 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark08(-19.880268590999535,13.471399523189447,6.4088690678100875 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark08(-19.907737084785612,15.807931484933308,0.8319374507856511 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark08(-199.2359517920851,-81.5810448632663,13.323745468877846 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark08(-19.96076710349773,-49.21588825997864,69.09200431157271 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark08(19.983345458941216,-31.88324357851849,-2.245654453418439 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark08(-20.02515765474118,-91.13145358108535,41.50401619914736 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark08(20.029166680515065,1.494539911098568,63.55269102402204 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark08(20.042082374909064,22.75005562549425,108.6773075479135 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark08(-20.077472719514553,69.68463492388248,80.70764801601621 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark08(-20.109018586597838,40.95184959262451,21.578292214832263 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark08(-20.173878638319174,-0.8334790300743243,25.901000452033166 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark08(-20.187927666152916,6.131407426526556,-48.3009681454055 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark08(-20.247921501182844,-35.22152144092858,45.881437588019594 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark08(2.037019900739528,-2.8918575388648233,0.8548376381252952 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark08(-20.39649238430223,67.15595104380756,74.69318311885726 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark08(20.408841384002056,-20.7347066631897,21.327907152421655 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark08(-204.1112516941238,-102.04859062755843,182.7632756994102 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark08(20.447486662145522,-64.48827167670906,-61.03325768345812 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark08(-2.0454196174646775,2.036551666849845,-0.49235919189944627 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark08(-2.0525196860544543,-8.03867433658156,-20.664111404531585 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark08(-20.54647813126767,16.396737636700607,15.19710295011133 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark08(-205.6341234657093,-72.79289803813286,61.71927823438327 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark08(20.615436985426022,-30.900049056315922,0.11705776473259105 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark08(-20.661617128500893,12.390885216115011,-35.899081059694495 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark08(20.735327560661915,-31.593793991153465,94.7167406200559 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark08(-20.760610348888353,43.30235509738017,24.322879148095296 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark08(-2.076893703891585,-56.606110897399155,-31.188444166575664 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark08(-2.0825315962748516,10.03981274975007,13.832030710675586 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark08(20.830900626576387,-20.374218400438664,21.744265078851853 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark08(-20.832848709850552,16.815929646883937,4.01691906296661 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark08(20.855195757229417,-115.95009761802092,-67.72495073021632 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark08(-20.94633514448789,-12.404816313986046,-88.31926015763705 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark08(21.090938626708834,-72.88567994809685,-83.3900998907954 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark08(-21.11172710678861,74.01983234971358,83.87608246988887 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark08(-21.144821603833748,8.92517738607876,-83.62618350891273 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark08(21.178918952972513,-1.9691998361941345,61.16915351332416 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark08(-21.18716023284508,12.305288502557016,0.0060249760600773385 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark08(2.1245261815963374,-5.564646774755452,-34.67853121101722 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark08(21.256260939370915,3.060106133720482,69.96286535458452 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark08(21.25851164928592,-39.31622390662972,17.783160231960494 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark08(-212.9067742485506,100.4133977535498,-154.54941813332428 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark08(-21.29680571121524,14.330331902046314,-34.54275616284893 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark08(21.304343478209898,-22.61543856078068,20.24921710942734 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark08(-21.3225179363252,80.86420944386043,99.33166140554015 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark08(-21.323288516909326,52.894668989928036,43.30031219845603 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark08(-21.328147034137476,-5.89812445614193E-4,-19.44867266288496 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark08(21.396001549612553,-20.68030093014399,-2.30533854797381 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark08(21.396647949854096,-13.098816917665163,37.99231001423197 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark08(214.3386960709147,-234.72829373689237,175.06963227347765 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark08(21.478601796436937,-35.24675115435266,-6.0576969193944565 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark08(2.1508168285958638,-27.979959832606372,-47.93667285263026 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark08(-21.521759216852473,31.971739709103197,0.4283066089347354 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark08(-2.155555283856615,-9.756108402214714,-25.918721124106238 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark08(-21.616437997263716,-85.99457334510083,-41.86648961452475 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark08(-21.63377260258877,-11.190238345476029,-87.07185030109216 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark08(21.674098678196813,-31.845978323993215,1.5510931944870088 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark08(-21.694970555040637,-0.5425345310934518,22.23750508613409 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark08(-2.173768763697865,-33.44184166420332,-60.204117078301536 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark08(-21.742197711647442,-56.12200977995204,100.0 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark08(-217.49739281523298,100.0,-193.91652009857006 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark08(21.761685199798702,-16.47422741389746,24.78173436321996 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark08(-2.1803405336404875,49.9276343702434,94.2397756029811 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark08(-21.817811264147732,22.061450686007667,-21.097147072057755 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark08(22.001689451506362,-31.85571665549413,2.5000425698694415 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark08(-220.66461773332156,150.88923955162497,99.6210015593186 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark08(-220.82386988689777,277.08025410306425,-108.1812404128292 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark08(-22.099970782439268,54.7114585105555,43.15552851662408 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark08(-2.2104341545608577,50.20036914125336,95.34023214561904 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark08(-22.121172469122484,-4.184587039171004,25.835593088156802 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark08(22.137555530464514,-95.56889240018891,89.90015076862855 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark08(2.220446049250313E-16,-89.867676113277,-15.977336292218936 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark08(-22.209107162325584,-65.0279362116792,86.15743049136323 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark08(-222.38421354310807,200.44018655111216,-265.58099705695855 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark08(-22.242225811536066,-0.026144489018147542,-65.61407987453599 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark08(22.286926381094332,5.099676086704616,78.6309276434871 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark08(-22.358162340058534,-80.328546716604,-8.746088386719086E-4 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark08(-22.360012401469778,12.362019674530087,1.6262992949087192 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark08(-22.384375972622905,22.107812504568717,-22.937073231935987 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark08(-2.2412708443936253,42.47527884581385,79.79754148524171 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark08(-22.452779798433248,8.821796205337652,-48.380331179121676 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark08(22.54514248442534,-54.60726549001465,-40.00830719995847 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark08(-225.9443971144879,-353.61430199834757,-134.60168009727133 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark08(-22.63647336623881,66.41380271106945,64.92241306293172 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark08(-22.665818353592375,-22.193192171839065,44.859010525431444 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark08(-22.798384501473798,31.189912977644337,-4.444531222337848 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark08(-22.958574555304303,33.62622000149335,100.0 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark08(-23.038429456926682,-0.4642291873530666,-5.153579282308519E-16 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark08(23.064912558178698,-34.84854837949803,-0.032380715279293315 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark08(-23.065351849622438,52.66270256364357,36.80227070533435 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark08(-2.307601180759657,1.2419181157155229E-14,6.994282415444374 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark08(-23.131846337541123,13.594330126368208,-40.90469457726721 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark08(-231.920264262042,139.63055481573062,-144.78469648914165 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark08(-23.227056052217165,67.67198304091313,67.23314441839065 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark08(-23.27623512710666,-56.22690640465371,-94.40003214963524 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark08(-2.332377650725476,-4.422380780990067,3.008810419886235 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark08(-23.33042531372214,-89.86341995161811,89.89871754783297 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark08(-23.336956052857662,-9.601657112725426E-4,-69.6394079965503 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark08(23.339892091424684,-35.50503854444794,0.5803955121591926 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark08(23.483857109406074,-145.2066903712974,-5.878064224428215 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark08(23.529583829039783,-32.817673480522785,6.524200852868669 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark08(-23.53390638595279,31.67309064860256,-7.255537860653245 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark08(2.354310057182035,-3.139080076242713,2.3555663458555753 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark08(-2357.9790764411105,-508.50612921923715,56.45483109676738 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark08(-235.96006399525697,231.4907755645511,-100.0 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark08(-23.603917691972445,19.269812709597495,-31.217138303415325 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark08(-2.3614669294403887,-69.56695902880227,11.251917267450454 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark08(23.62587400381493,-79.85134963733749,-88.75087410124917 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark08(-23.646174291908785,31.339535283077755,-7.693360991168969 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark08(-23.806467692458543,63.39553509448409,55.392435395332384 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark08(23.826834921016616,-45.88764012072907,-18.787686588176427 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark08(23.9036201444028,-37.651666948271185,-2.021677136539114 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark08(23.97126529779735,-42.964337633031086,18.947697273378836 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark08(2.4074124304840448E-35,-36.8885454136937,-72.6154169721029 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark08(-24.09629508465472,-4.72271614063108,-5.755912373174553 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark08(-24.119554122862336,45.49051594877974,-7.233234335129509 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark08(-24.201952779024765,17.622208952023428,-55.5498519517045 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark08(-242.05246893562904,82.70684891925245,-177.02953939024806 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark08(-24.226626097008335,-79.07786709476552,-3.2996433208002998 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark08(-24.243981261854177,1.8198367593571534,-31.278949988178482 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark08(24.26768340739469,-8.703379942911056E-4,74.37208176414946 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark08(24.300320800094298,-54.52956952547565,-35.50152358958556 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark08(24.308849609085392,-45.79236134360893,-20.461387770849065 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark08(2.441278000456138,-1.3391365846897518,0.4804827102366407 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark08(24.418025482435993,-79.9218024978712,-85.01873222163952 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark08(-2448.7596249106377,-697.9059680396848,60.22848131968729 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark08(24.514747289520898,-97.25427509394618,68.75240189096161 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark08(-24.537264224355464,5.591830910187737E-4,-72.8526163843483 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark08(24.552740062648866,-42.15118601835883,-10.644151848771047 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark08(-24.578587758954082,31.781109319398016,-8.278940594981563 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark08(-24.578660658787893,-100.0,-24.00101216088532 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark08(-24.596706347041966,1.4904122159872513,24.773303190791747 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark08(24.63753207376977,-69.17035921112043,19.52307024769262 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark08(-24.70214207724629,32.04090639178118,-8.453817121381615 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark08(-24.716346557285018,4.616443070548158,-63.34535720416987 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark08(24.750930803775717,-84.28786106091549,-92.75213338370894 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark08(-24.762068827022077,32.49249299487876,-7.730424175108372 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark08(24.763614041262638,-59.40766248901595,-44.393260231371634 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark08(-24.768733213448332,57.92198471742805,41.537769794511114 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark08(-24.79309169026946,3.072954317418052,20.149341046056506 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark08(-24.79932294975299,39.874415005308876,6.91605651957636 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark08(-2.499957229286449E-4,28.172389871435737,57.14372335121335 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark08(-25.051773753597015,32.116314647101966,-9.351895639792218 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark08(-25.08487728543365,76.27374310884704,78.86365068818803 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark08(25.098777482139386,8.140077304020101,84.86409798921446 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark08(-25.178473167664702,19.99072164798045,2.2886736937876306 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark08(25.256102350805904,-40.25608557840382,-11.456253084774815 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark08(-25.35963851980655,21.945409856253825,-0.05283202110679407 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark08(25.435041396191547,-30.630744092763997,16.171057393190853 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark08(25.468952200067886,-14.180871070926765,49.589946178931996 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark08(-2.5549409155312204,-33.83584467559265,0.30399567978925096 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark08(2.5567726055220546E-4,30.879681323390972,63.32983786334229 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark08(-2.5575496323546423,-37.5719519338527,62.21213448860493 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark08(-25.61235230221817,65.28650205375169,55.289814372386736 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark08(25.715518783312696,-37.18223519085855,4.352882295015888 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark08(25.720189993188523,-41.13769687698824,-3.5644940242075513 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark08(25.796612175242768,-87.19018172219508,61.393569546952314 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark08(-2.5909930356408424,-3.424398019148761,-13.050978818425172 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark08(-259.2241146840253,-108.32388642994363,143.8751495927098 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark08(2.59610387086894,-0.04985399168335758,7.726414414752212 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark08(-26.03159262414841,18.97949608965353,-38.59378493034283 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark08(26.035295726823577,-195.68868440919346,-86.55934717211687 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark08(-26.075349417269656,16.231323337391174,-45.353604034339796 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark08(-26.146544859213424,33.29164480326524,-10.287623092596743 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark08(26.267880843970627,-35.796005908399906,7.957328737634386 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark08(26.27974284311053,-9.98608085735188,60.437863141422724 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark08(-26.282955244567678,34.50995472081186,-8.258159965284417 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark08(26.288525344749818,-47.599246700114136,-8.183414576709865 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark08(-26.29408683719424,11.536007555057736,-57.10346627053203 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark08(-26.343148571074792,-90.46143809875444,-38.67518074311574 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark08(-26.564184421843283,24.46637903689649,2.0978053849467955 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark08(26.58002558326138,3.189417788549025,87.68970865367709 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark08(-26.607798093462208,26.45645331583279,-26.91048764872104 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark08(-26.61525419696372,-1.8781741198235409,17.131215674020524 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark08(-26.63502515714497,-2.9018594332581533,-85.13124726737828 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark08(26.720951406762367,-68.78215184584151,-57.401449471395914 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark08(2.675220861257074,18.569948856249905,46.73635662306592 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark08(-26.75804542465338,1.4686196356725016,23.718629462185973 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark08(-26.77357087978868,15.903927523151895,53.429887591529045 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark08(-26.810851673134923,35.42005145428506,-8.609199781150132 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark08(-26.840138885512726,57.60671973255007,36.20685377507434 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark08(-26.85164316608364,-122.68138511179055,13.374386776334935 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark08(-26.863508223028536,43.1932032503426,5.795881831599695 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark08(2.686817369253938,8.218687676851761,23.780431736132027 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark08(26.882092186389357,-33.61198688291332,14.583876330544028 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark08(26.888387459610954,-30.79111460168876,3.9558131384436175 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark08(2.69105834898275,-8.021245009417683,-6.398518645092219 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark08(-26.911637734022193,9.613539284235713,63.68379331119317 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark08(-27.00740477719671,-2.220446049250313E-16,-16.64012773217332 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark08(-27.009290678533954,24.662104718118357,0.0 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark08(27.032404586940526,-36.37086041006513,9.3384558231246 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark08(27.0986862732152,-51.30446214502167,24.205775571445614 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark08(27.147078452378434,-45.60868345118775,-9.776131545240201 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark08(27.162360091617323,-54.99975275607887,-28.512425237305752 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark08(27.16834307181257,-41.59087722007057,-0.10592889790853655 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark08(-27.19922191621274,39.8741265972501,-0.27861622734313374 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark08(-2.720702887816358,3.126049142593511,-0.4053462547771527 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark08(-27.34672891974948,6.251251232680946,-67.96688796709165 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark08(-27.393378850230004,45.88515071293685,9.59016487518369 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark08(-27.405920850587975,0.09516085351611285,-81.07442127087536 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark08(27.4391227711469,-51.89872025410905,22.972875304643036 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark08(-2.744462460489414,-35.08283160150672,-34.30897391118324 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark08(-27.46286596962589,4.767790067710359,21.519718318114883 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark08(-27.531589235296877,-15.273305332420255,32.45171870441846 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark08(-27.592904594305757,25.920521775193272,1.6723828191124852 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark08(27.63251956696,66.98950679047599,48.01200629115746 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark08(-27.65636088820034,45.77330515278368,10.148323967761232 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark08(27.68614599536883,-66.34763245758158,-49.583892844164154 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark08(-27.75826866146234,-56.14709942651053,85.22927785287916 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark08(27.772198678817634,-30.744834703390296,21.826926629672318 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark08(-27.792602962998856,42.9219863128347,8.446071629688061E-15 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark08(-27.841096514929056,52.229242270562885,20.935194996338613 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark08(-27.84659204120289,36.2447905881775,-9.479398620458777 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark08(-27.86549181312622,-6.074969664570742,-0.009279168280412408 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark08(27.870472369772347,-88.73081316631949,-80.74998741469211 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark08(-27.882823404180453,36.48448624983428,-10.679497712872786 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark08(27.891203786079146,-80.22892353942827,-76.78420850278742 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark08(-279.9946737830623,143.15626232394362,-100.0 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark08(28.092406360832076,-89.99338608502109,61.90097972418902 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark08(-28.129542571957856,-26.559817187436238,-49.40666872570418 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark08(2.814277582033924,-3.925065099148657,1.1107875171147332 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark08(-28.17434523196492,-79.51520235505973,40.689615227867904 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark08(-28.25767569710364,5.011061519480232,21.024495582762288 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark08(28.321930317484853,-61.6173499391823,-6.658910939831415 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark08(28.32425148304989,-3.9767464731331112,78.59005782967833 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark08(28.37785515651623,0.014760557187114338,86.67921741050417 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark08(-28.41437137486057,-42.45594548848626,-75.86330977740234 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark08(28.416036470884734,-68.05067485301387,-86.15022742288497 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark08(-28.41704022195834,51.40300682038608,19.125689301692024 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark08(-2.841744906505109,-34.172962645332824,36.960544393773084 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark08(28.419367350744867,-18.321576800444685,49.343252254383316 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark08(2.8534549376828626,-27.65615886098875,-45.416862877292054 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark08(-28.576803877665633,66.63244647463964,47.54805147477579 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark08(28.6728923895883,-40.96832521378629,10.724636497403097 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark08(28.681763093417107,-43.9076547202163,-0.19922383338638402 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark08(-28.684923957413673,-98.05705957349463,-67.44302258512285 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark08(-28.72215121363089,6.903369738207181,-27.948219426928944 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark08(-28.72625575303283,-2.181898066803584,-88.97176706591077 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark08(2.8814504038552102,-26.34631299985785,-45.149144431534744 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark08(28.857942622430297,11.035277388320761,101.87503922822938 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark08(28.909902659096964,-38.20024228998445,11.900019724116888 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark08(28.98342196801394,-2.1418116347303374E-7,86.98738135449072 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark08(28.988480906797054,-32.88889083536476,13.367619586924095 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark08(2.913700931535754,-2.6483938469112633,5.015029071591172 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark08(-29.199740883148415,40.82926617646441,-12.653079278003014 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark08(-29.22616123623649,-8.62618699597134,2.0246263702404015 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark08(-2.924378511150728,10.696041302281643,14.189743397905982 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark08(29.300270449548865,-46.39788450597193,-3.3241613365023714 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark08(-29.323960442556146,-14.395072442151367,2.8198315338127493 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark08(29.45931924743113,-32.9795215780848,22.418914586123805 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark08(29.497071279571344,-47.162939188254896,-4.325685691101779 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark08(29.612484533270987,-39.620306407281305,9.599036815199794 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark08(-29.65601784760373,41.38665532576056,-4.623946564495185 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark08(-29.856249500430707,31.6325801189837,-26.07032339840382 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark08(-29.913480594952347,15.038963131093652,-58.09171919587487 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark08(-30.000456340224233,18.450541590945168,-53.100285838782355 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark08(-30.01746589544161,75.06096345609058,67.89395117529078 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark08(-30.057204816986392,-17.53259591338005,38.563066675922244 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark08(-30.098267775269864,-2.6004086232008063,-83.61506410356492 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark08(-30.188296797178143,-57.33883916812474,59.076017681467846 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark08(30.22506776647938,-68.36782328135463,-44.48964693647624 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark08(-30.281133373287386,-12.666466920593251,41.37680396708565 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark08(-30.28708705609353,-0.010805075734076134,-86.88104661437858 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark08(-30.300708578454856,40.3942693562022,-10.093560777747342 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark08(-30.332766273125433,8.46902356640264,-73.83700464712254 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark08(-30.456924539948133,6.7800311212445274,23.676893418703607 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark08(30.50408785418042,-67.37506519513526,-43.23786682772766 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark08(-3.0572673499439595,-30.7166840227487,-0.7845443816491904 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark08(-30.680067590102553,12.596476355426505,-65.27645373265976 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark08(3.06825233397609,-28.356175056734177,-47.50710625029048 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark08(-30.704458613150827,-17.457619740384224,-0.0014868280415487461 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark08(30.746937720184327,-41.88959726154771,10.032414964252457 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark08(-307.5479868761498,-769.8304548388289,-1053.9787014627325 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark08(-30.7818220668018,68.32406581316408,45.305100452925075 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark08(-30.78371907048249,-0.24398838011293833,-22.906719251453318 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark08(-30.809029788090054,71.95097894999085,53.04566486250644 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark08(3.0841119016468757E-4,-71.36673251295167,71.36642410176151 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark08(-30.866512953023303,87.91777782355719,84.80681311483936 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark08(-30.911485658136126,-1.209939534924251,-95.15433604395166 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark08(-30.950439071580632,-73.18909472051396,46.4490619464508 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark08(30.95673233704906,-12.27599727193514,2.109942843654821 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark08(-30.9567829325116,100.0,152.44128837322643 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark08(30.95720295903911,-91.80561704503644,26.25482935056209 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark08(-3.1051869910786716E-4,-50.58792215852528,-100.0 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark08(-3.1063621967703625,-83.05448605844346,13.428434145118246 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark08(31.14493925014932,-23.0845039449123,-15.975882891176681 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark08(-31.183667816879463,66.84954040646983,41.7188736862981 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark08(-31.188918688765682,41.075697200061434,-9.88677851129575 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark08(-31.212357656791653,-7.815970093361102E-14,8.276383200985606 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark08(-31.242043959991356,22.702417078976215,8.53962688101514 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark08(31.25043814428292,-132.56101817896013,105.2101666462292 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark08(-31.270369225702723,40.633051513314776,-10.982976347691272 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark08(-31.323918455209235,53.4036641255666,12.83561598505361 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark08(31.365710815865494,-96.40720297796497,-98.65478108736953 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark08(31.36663427705896,-18.24599976587134,59.178234929152616 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark08(-31.53936594736353,39.950490019645024,-14.694324640694227 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark08(-3.167763293926662,-20.937195011114227,105.71985422268756 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark08(3.1777478164814204,-109.88992043651949,-46.722772854657904 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark08(-31.81340065938547,100.5582604096138,107.17961113140325 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark08(-3.1915803520954755,-57.53853609411172,-123.34759237882584 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark08(-31.95299499049851,0.7441296186725709,1.4354551476369153 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark08(31.99466025315827,-99.39069114442766,-101.32631976376663 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark08(32.01139931778851,-42.15826058338216,11.717676786601226 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark08(-32.03964311677403,42.21552369983985,-10.175880583065815 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark08(-3.2219153725885796,-12.514553979028989,-33.12405774902882 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark08(-32.23012809770859,90.18616494572618,83.83666941036557 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark08(-32.23862735107838,66.29036600213834,35.865282459090444 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark08(-32.29714789590903,61.47999201402209,27.639336667111962 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark08(32.39062239039825,-47.248761457570225,2.674344256055097 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark08(-32.39931991246454,72.99045502812471,48.78295031885582 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark08(32.42616079543093,-39.34757163471025,37.99943188227516 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark08(-32.47019888827601,18.810767344920265,-59.78861936417859 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark08(32.52851125374723,-75.742828641796,41.64352106125386 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark08(-32.54549301735056,49.470490249359926,2.8752977734630685 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark08(-32.55008443789197,-1.1770276087851856,-100.0 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark08(-32.63935400107577,40.977614759698774,-14.653505150075587 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark08(-32.655771903949784,6.058869331887406,-85.84957704793426 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark08(-3.268845954156837,9.769962616701378E-15,-6.217622216226207 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark08(32.69802535669371,-44.05364895200624,11.35562359531253 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark08(-3.27234224126569,14.228022333364436,50.544181743620165 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark08(32.72645360727381,-35.74011715381917,27.333082647113645 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark08(-32.751690896922796,5.6647001692329464E-12,-98.34891567364623 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark08(-3.2761676783420515,4.1163188317155175,-0.8401511533734656 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark08(3.277523419295491,-36.95579450229597,-62.50822241991058 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark08(32.80973455773291,3.1886389010664674E-12,100.0 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark08(-32.829469450753,49.03969810063058,1.1617841757970535 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark08(-32.859562085058144,0.0072718858549268295,-97.72630855393105 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark08(32.91104237465198,-100.0,-100.0 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark08(32.926544460673675,-42.32162820617235,14.136376969676325 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark08(-32.93366092328779,36.89241588395072,-23.44535467516704 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark08(-32.949287028737395,-4.8358257787157327E-4,-98.12000977667567 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark08(-32.99701376099791,4.163894012643938,-90.66325325770585 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark08(-33.00825725438391,1.3975966851920854E-13,33.0082572543837 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark08(33.01202056339528,-70.0258854913154,-12.66460392187851 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark08(33.01523677142245,-59.377823868791815,24.79637984224216 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark08(33.1257042944376,-50.37795260143769,-1.3787923195625904 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark08(33.19733520660125,-96.85687272199678,63.65953751539238 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark08(33.23123727921994,-80.61800462976564,-60.08640845573485 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark08(-33.24047411078615,73.23619542858142,53.84147411698123 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark08(-33.3029858816572,29.763753757154113,-7.493473848909536 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark08(-3.3306690738754696E-16,-73.29738902145873,-77.04042727002464 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark08(-33.38515730725389,-99.83140630814322,-78.89323919523463 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark08(-33.41966470668698,80.08633711633567,59.91368011261042 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark08(-3.343477560633541,3.648387782880821,-1.7117910615418888 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark08(-33.46569276025944,-22.880439757825897,-146.0491134702367 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark08(-33.51061119197458,-44.764938432502476,24.00131057964407 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark08(-33.52996318253564,40.078303811103936,-20.43328192539903 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark08(-33.618651383109665,-26.905985579300193,58.96037514245738 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark08(33.630887811250986,-49.79198305882812,2.389040977255739 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark08(33.64767738085858,-50.78616483045064,-1.7092044765875704E-5 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark08(33.649872279340414,-92.45015893271655,-52.04972046673293 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark08(-33.65168673220006,33.57300575255737,-1.492115347152204 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark08(33.66614637133379,-15.36890210448573,70.96809249619254 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark08(-33.67144152824338,13.127860698406424,20.543580829836955 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark08(-33.672321127416126,23.105741424144966,-53.23468420716355 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark08(-33.72657376380468,74.51136184244923,48.84133698146377 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark08(-3.374122881068228,14.323975461157874,20.096378605905958 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark08(33.74320494723646,-99.99618139121672,-97.19195161392918 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark08(33.74942536878533,-55.85079795086383,-10.453319795371652 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark08(-33.79236315041527,48.3267289058939,39.35236623411944 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark08(33.81005635735099,4.998901890544261,-27.02069607329169 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark08(33.86122497478228,-45.40596092364122,25.07002601866484 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark08(33.9407817443937,-419.2947794177467,168.0311560240264 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark08(33.95517070225152,-82.58916585767979,6.314014790778071 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark08(-33.960119171692355,-7.77832686595461,40.16764971085207 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark08(-33.96961029492899,36.16730704856793,-28.190265791683053 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark08(34.03068737478173,-15.626601421340515,72.33635479082439 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark08(34.03121023230004,-98.95985264809839,-94.25527827250177 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark08(3.4091843248702665,-10.386687639830512,-10.545120323208671 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark08(34.096133418201106,-16.813462406976534,101.4444458709524 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark08(-34.1074934123005,32.89153788837886,-27.80880455014514 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark08(-34.392393106967766,51.58858966045164,8.853272374690366E-4 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark08(34.40837879353398,-59.291422014344775,16.572910719579568 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark08(-34.42864474064881,45.161447643366515,-12.303599229512605 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark08(34.485437580019266,-36.596285148636944,3.6816438954125745 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark08(-34.5586071113116,39.613405042674856,-11.131349687629964 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark08(-3.4580650007113443,15.768197296695243,21.173514319473153 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark08(34.66938118401011,-33.098584857215116,-1.1305183020646718E-15 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark08(34.69383565794959,-81.23948059312215,90.00116553647953 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark08(-3.469446951953614E-18,29.885653872330902,61.273114803022665 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark08(-34.71665149482952,52.06908094071221,9.99746471762819E-4 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark08(-34.733934568060384,12.265377565222153,20.897869335296264 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark08(-34.76126855173789,33.36470982493948,1.3965587267984096 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark08(34.91004194788699,-61.330654116440634,26.420612168553646 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark08(-35.029496778738405,-0.8713699946063684,-100.0 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark08(-35.10283249617751,35.992576089701025,-0.889743593523508 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark08(3.5106853268278786,-29.87763381144271,-47.66341862205536 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark08(-35.136948385132996,-0.5878240114724775,-5.181047698288665 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark08(3.5186962492182455E-13,25.42713223386535,52.37589496709941 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark08(-35.272583265443416,64.05554887137146,23.86414427320755 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark08(35.363468995074484,-59.17320784899585,-4.466548153394528 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark08(35.36547418752693,-60.05627749345731,24.69080330593038 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark08(-35.4912647971881,-127.77723445275926,79.72644761210196 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark08(35.499228321403386,-4.176872690899664,98.73231461632311 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark08(35.526115766256225,-47.71474064452396,12.188624878267731 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark08(-35.53467008361898,78.09241996536007,51.15162600664485 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark08(-35.55853929179693,32.845657160568734,-39.413507227458446 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark08(-35.56534026655996,-36.2273070658105,47.467724570884556 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark08(35.60561815976656,-69.51540922703468,11.91864248765887 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark08(-35.63006817323185,-24.160108888670038,59.56665090065377 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark08(-35.69805993947283,99.93469073960222,93.98206334733511 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark08(-35.71355816820481,77.98105862408386,50.38596344023975 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark08(35.71981542450941,-64.28215759065452,-21.404868907780795 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark08(-35.767553711517316,-98.36654724651011,41.54168279988254 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark08(-35.81629063526545,77.2560211511823,47.28906415731955 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark08(-35.837642667032,-5.380521016942097,-17.172283702269596 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark08(-35.93065218466365,21.99744439045574,12.362411467413015 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark08(-36.02776673236408,-72.37353444797513,-25.377652243926182 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark08(-36.04310523632661,28.02245051015573,-52.08441468866835 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark08(-36.0439046262724,29.743523854434137,-3.1243971891780777 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark08(36.05004731329848,48.449489475798,-52.34930862998646 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark08(-36.057236315596995,100.0,93.3990873800039 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark08(36.1306237495995,-49.221629586367875,11.519408402857648 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark08(36.13792470748231,-36.32177183480101,65.36079113002248 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark08(-36.24706521098178,53.579032503397464,-1.5831306261504012 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark08(-36.27165916492052,-98.22573937364206,-2.847860954185478 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark08(36.290180519038174,-5.220668941954706,100.0 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark08(3.6406635436919774E-4,-54.17935750200218,-79.6352353445296 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark08(-36.49398973990238,-34.21384461786361,-14.421495846842634 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark08(36.55415792668135,-60.19853724748409,-9.163804388129234 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark08(-36.615856859847376,33.21134000430071,-43.424890570940185 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark08(-36.619423649598424,12.385674018123183,59.908000520237124 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark08(36.6445382899811,-74.00619656322573,-38.07735211908255 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark08(36.65960772160566,-63.26640126295001,-14.983183034288153 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark08(-36.708466457758874,-7.493352234331739,-36.67888640061384 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark08(36.770600307383646,-61.29245691665855,19.380263938429803 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark08(36.82547331972282,-103.58761002936822,-96.47558440085866 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark08(3.6876869625688995,-9.853105619955869,-7.072354025410162 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark08(-37.01894622154449,1.0733690084869352,-1.6457777435440164 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark08(-37.04331241998454,51.852902592480866,-6.955608463949727 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark08(3.706130745018254E-4,-46.42907761536487,-91.2870315226063 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark08(-37.092890946708756,46.09274903286703,-17.5223784475973 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark08(37.16096073132156,-49.48553448592441,13.895370081397752 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark08(-37.17383084758565,55.99999892301735,2.0493016300726525 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark08(37.21202581923858,-218.20378763928966,-161.20628240392432 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark08(-37.219452176539356,38.316488101550895,10.27163792790955 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark08(-37.2214790609241,-17.340692314246,29.77554617861111 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark08(-37.24982019984365,38.64784468463432,9.597607081192034 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark08(37.33432166057488,-49.82847018093803,12.49414852036314 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark08(37.38310301863797,-77.60232123519862,-41.48453708768845 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark08(-37.398639689266695,46.352434183417074,-19.235805418001412 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark08(-37.42123821860071,100.0,87.73628558514346 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark08(37.52467251462022,-63.300614661539534,23.87608134753208 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark08(-3.7535054498278955,-9.937881366803328,-31.136279083090336 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark08(37.56466889956465,-100.0,-85.73519697451115 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark08(3.759394591963452,-45.69620888447411,-82.12891539438863 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark08(37.633842676773064,-63.828786512136176,-14.756044993953154 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark08(37.64844947771639,-56.49668421170389,7.38498848312681E-4 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark08(-3.7649142128022675,-15.761339541121401,83.39374309531351 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark08(37.671016061545835,-65.56342575837593,-16.55802321155629 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark08(-37.7597640711811,16.749419545796908,-79.78045312194331 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark08(-37.76007217428778,60.529120967846616,9.348821739624796 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark08(-3.778285523243557,-8.594895999359139,-3.351222525268474 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark08(-37.80024788396034,35.048452996450244,0.9166428613709572 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark08(-37.87091883626509,-100.0,95.51781246347701 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark08(3.787526380905125,-51.760908283087495,-48.11314038817191 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark08(-3.7931679773950877E-4,45.11312021606372,91.79413542247453 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark08(38.00801361331386,-67.68322319207145,-21.342405544201327 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark08(38.01211235721718,-32.31971290534052,50.967707587765375 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark08(38.04652756244683,-76.902017008252,-39.18041339113584 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark08(-38.06889707109947,11.042627752767348,-48.13867771912844 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark08(-38.10188949260822,0.08795356134054008,-112.6057419611152 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark08(-3.8143957308936223,-73.84220280768632,-12.527274654005097 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark08(38.178484738824764,-11.89338182589645,77.93800804667703 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark08(-38.2535746821005,76.41291568212228,38.06510731794307 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark08(38.31186510174949,-85.36648693016615,-54.226582228288954 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark08(38.48178742871414,-88.98672139710956,-60.95728418128182 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark08(-38.510484569229476,28.554744772257845,-56.89606895692024 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark08(38.510992355055386,-39.989748182497806,54.96665956968722 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark08(-38.53794824041496,58.71314452628988,1.8610059198788544 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark08(38.590018445816526,-52.25539669811115,12.094581925499721 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark08(-38.6291046908459,100.0,84.1126859274625 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark08(38.665801920684515,-47.252803764737784,21.491798232577985 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark08(-38.80683226486521,-4.052413443711359,26.858932040853134 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark08(38.88627438496424,-38.26166899030432,41.70628150107896 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark08(-38.90407757775694,22.39003685692333,16.513943375237513 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark08(-389.29711243232543,-239.37533399457521,-383.5808086825826 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark08(-38.97331668207613,24.683001988724556,46.31825283579303 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark08(39.037032983108645,-32.53771501508818,39.23831207040477 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark08(-39.13901130297347,65.60082536482307,14.73977872780732 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark08(-39.24640067412936,25.739966273472408,-64.86171415015063 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark08(-3.9296555439248877,-12.206846579864504,-36.20265979150366 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark08(3.9343627006175637,-5.147102843557631,1.5088824147374296 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark08(39.357679468931174,-36.7018197994274,46.24019513473361 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark08(39.54739088343911,-100.0,-81.06396434522222 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark08(-39.73389173688947,92.98241871478358,66.76330058218029 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark08(39.77630975068181,-53.816806853419465,12.469700775942766 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark08(39.78593904272731,-72.76999792637588,34.62593475647088 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark08(39.78924566540957,-21.62392088560193,76.12086341031997 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark08(-39.809388362412435,32.90144210656913,48.15079450221063 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark08(39.820423905796396,-27.05477123891079,66.92252556636248 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark08(39.88459639475518,-17.728261054795126,85.76806340147016 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark08(-39.91507718228917,77.37096252428648,36.56748982850036 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark08(-39.94663094887753,59.73055506027187,-0.3787827260888257 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark08(-3.997836980430371,30.727595617170216,49.65000439779304 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark08(39.9847454883777,-32.701589911368615,56.121852969190755 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark08(39.98693779995888,-100.0,147.22220295329922 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark08(-39.99512467956047,60.66001343180167,1.3346528249219318 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark08(40.03060655499757,-20.94905384760435,79.7645082965789 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark08(40.059023188296564,-188.88098110108527,-100.34961180680342 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark08(40.134797929082204,-79.1622758986404,-37.86281521620089 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark08(-40.15433714126062,9.73237288054008,-99.4274693359068 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark08(-4.022709855758666,-44.32636310198361,-100.0 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark08(-4.032205371944456,22.621478111888045,33.2968838668573 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark08(-40.5038055086683,84.06557418741907,48.190528175628145 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark08(40.51327670955601,-64.91950847442587,24.42188228258999 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark08(-4.059090612937625,-21.49889771329113,-55.17506726539512 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark08(-40.68469819943422,-24.466089289008504,-7.141061403054527 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark08(-41.14653219819292,75.3308596458536,29.417682551575645 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark08(41.15933773796339,-68.30023698046418,31.363162746248918 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark08(-41.17885222130124,94.38985626921108,59.697168685964684 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark08(-41.239944834596415,-15.5529131595771,-59.02597049076123 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark08(-41.386139161018164,-82.83399822882254,56.02587750617319 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark08(41.42331194356128,-111.90085935758076,-99.2910362029127 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark08(41.52927491846493,-77.56475070469878,-28.970880327207883 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark08(41.57517998943434,-24.250702841560173,75.93075081748948 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark08(-41.77464858016913,63.49484994451059,3.222162294344373 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark08(-41.801295802871486,1.601498465678958,-20.204042990626263 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark08(41.816746133068676,-89.0753212287375,-51.12960773147407 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark08(-42.11822945418497,60.90953906559043,-2.9648139045791755 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark08(-42.25629423135193,32.38928893296793,27.406308111028153 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark08(-42.28628731028256,71.5439887621219,17.79991192019101 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark08(42.46342894070036,-73.30215422662177,-11.512626501584629 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark08(-42.50031680145526,95.56502220317903,63.62909400199227 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark08(-42.5168123703241,-74.60956941216213,-37.379982380767785 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark08(42.52265735688238,-55.6759718121729,9.503580438793529 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark08(-42.56793958703929,52.32125848276638,-21.490505468790218 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark08(42.606297427281625,-77.04150567086911,-7.399596302675306 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark08(-42.65027490141825,-72.77876777931773,72.54032196466983 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark08(-42.687789265548965,-14.81135084943403,57.49914011498299 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark08(-42.695328295473736,49.111979037279774,-28.333287433925555 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark08(-4.278829992186086,-0.7735862330639849,-12.81297201378545 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark08(42.80750660070774,-20.17812836079665,89.63705940732481 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark08(-42.81756191977764,-85.56474454948061,-84.45256274667734 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark08(-42.84855885897332,45.5018742119986,-36.282090594556415 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark08(-42.88710168509966,57.23641870423276,87.01339384729434 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark08(4.294629100013166,24.64196557230341,93.83409094844782 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark08(-43.02809591535479,56.887686688310644,-13.859590772955853 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark08(-43.055475272061095,40.80100391458123,-46.04176949749499 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark08(-43.078040712063036,57.336594874921865,-14.258554162858832 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark08(-43.112205353179114,14.271956134055463,-100.0 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark08(-4.32960577563513,-35.364857255997805,-95.31230264537882 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark08(43.31588120919211,-87.33594961448242,-44.72425560138847 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark08(-43.3527655461274,200.8095718125554,316.84912867256617 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark08(-4.336421317763063E-15,-20.53769792649636,-3.218032731582646 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark08(-43.36525512030829,88.53833004298747,46.980894926058546 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark08(43.3911627560218,-60.91917181702151,9.905940960817269 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark08(-43.4172083643773,-67.58832113297623,11.710923968116845 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark08(-4.3458613451644035E-4,42.494815049056776,85.0566096171853 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark08(43.539540890211185,-54.51493576026118,75.71981848589178 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark08(-43.53973207830834,47.497281232267994,-35.62463377038898 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark08(-43.541846731609965,45.360942160878686,-35.133873107063465 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark08(-43.54395789942821,36.6693737910099,-57.293126116264794 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark08(4.355999984856894,-42.7522169591094,-71.68094588232454 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark08(4.3572169338460105,6.885767904963712,-7.539122609757598 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark08(-43.6834637704262,27.203418746122907,-75.07397811192084 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark08(-43.69129992282907,54.180891965012414,-21.14131951166752 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark08(43.71040552230704,-52.14315809756815,27.931457634821612 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark08(-43.80600997319208,-88.91313431122686,-30.94333907365258 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark08(-43.91811742529235,0.0032986180677667676,-10.842866933355157 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark08(-43.9501455044863,21.76551870911827,-2.2737367544323206E-13 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark08(-43.95571348471368,61.68163956455609,36.797458792054805 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark08(44.026350208225125,-52.86122523051728,26.356600163640824 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark08(-44.09521275218682,64.27204955720103,-7.336617109660099 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark08(-44.17434285181594,-15.900107290372844,49.78240240913987 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark08(-44.17868203503426,69.49458986274698,6.4531336203911955 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark08(-44.23755643177017,-99.63312840664872,-48.85766443765563 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark08(-44.34991400843263,38.727902533676996,-55.59393695794389 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark08(4.435072020516308E-14,-100.0,70.90664155467854 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark08(-44.40100928983334,59.07998367293234,-14.678974383099003 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark08(-44.51253945187372,70.07870524025498,-69.30298227157454 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark08(44.64047795415308,-92.32120805523309,-49.498844273292185 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark08(-44.678525065412934,10.840892873366645,-112.28682510437608 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark08(-44.719439710802675,18.249703470579462,-65.78046731368312 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark08(44.72050630478999,-52.88971639912871,52.41511192659067 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark08(-44.72421745893447,-0.8503413296534461,79.29747922171256 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark08(44.73622621099435,-100.0,-57.99844974932978 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark08(4.475049898830339,-5.982661889031151,1.5076119902008118 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark08(-44.804209182503804,99.48717875407253,71.321562657771 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark08(44.8365286987746,-73.91253477653827,-11.745962954048334 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark08(44.85442978777091,-84.06593307039687,-31.997780450686115 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark08(-44.86002571849553,-73.57116334870291,64.14859784055977 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark08(-44.867794313393375,10.001494165167074,-76.65140243659383 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark08(-44.8921594225621,52.239951236161176,-36.908964775748686 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark08(44.96962459119231,-99.99426779563929,-62.34273267340427 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark08(-44.97097048018832,14.161127176382209,1.6163543363350925 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark08(-45.015686062168065,76.39397410897936,19.311686358249435 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark08(-4.505018104960143,-8.369603905150697,-28.683465798386937 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark08(45.06130908134901,-60.005986413782715,16.5154736592286 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark08(-45.09794844026029,52.338031885231004,-29.048251923113895 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark08(-4.51056084572007,33.649103739790974,55.33732126921662 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark08(-45.230858684039355,-35.55012524346247,-24.050524883936685 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark08(45.24558345982643,-68.23726906645567,-0.16699146138096696 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark08(-45.2800677878079,74.13283060584118,13.99600594761666 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark08(-45.2826942743729,50.03127819990691,-34.21473009651001 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark08(-4.532283076381896,6.9672253070343295,-17.867725837118318 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark08(-45.39226816065402,99.25957498530148,63.91314181543581 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark08(45.44856793943688,-57.7579664866343,21.33968581970149 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark08(45.53623625665133,-24.013117427439326,89.38785671498502 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark08(-45.568086546353456,23.679810770666563,-82.66871788455086 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark08(-45.64655671517259,-23.67896279512287,-50.06190781842814 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark08(-45.68177533311867,6.410297950897601,39.27125171305442 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark08(45.69823763842418,-61.330886571878644,14.432939771515272 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark08(-45.71884867587534,88.78098947728121,41.97622925373127 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark08(45.72486507401963,-92.19935891347531,-47.035593320065885 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark08(-45.773131414158684,100.0,63.96655029480244 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark08(45.82003431627561,-69.27891934423255,-1.097735739638253 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark08(4.591443201711821,-61.26108617376783,55.09841513325006 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark08(-45.97755877337959,13.367191649626562,-69.2156578029113 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark08(-46.00972907051426,64.61237581581128,-8.795931047876161 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark08(46.03556294936961,-49.59958108567905,40.478323003545626 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark08(46.10457984180492,-41.67192278469146,55.6275830392116 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark08(-4.611142412169357,-3.4026623666984115,-1.4148931111577179 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark08(-46.28874774377974,-92.41808367236735,3.4953689819276654 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark08(-46.36902491062842,28.354897583413447,83.49998856705707 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark08(46.381987394407936,-70.00585537167547,-0.2311690055076057 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark08(46.401410768220565,-70.6927314592158,-0.841500899258315 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark08(4.642575557723462,-68.48087784090936,34.142296177662416 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark08(-46.49877633819608,-0.8971452235424664,73.60475627720669 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark08(46.51390636756746,-100.21127915045983,-60.88072005948656 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark08(46.52152565628793,-27.68570925263684,85.3427007662938 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark08(-46.60372100965778,69.12042464282007,4.825834616946151E-4 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark08(-46.66370260651064,51.32164761750953,-4.657945010998889 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark08(-46.68157131591466,-71.83356393352426,79.41309049426667 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark08(46.7898457823955,-21.796255776278922,96.99873554933451 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark08(46.97260075116255,-66.10635617431522,10.275886231652088 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark08(-47.04654448260627,47.521985477501886,-60.524866166020665 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark08(47.05165947147129,-89.27105615219129,-5.206170014889324 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark08(4.707311832915728,-80.3275966136582,80.73497337599254 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark08(-47.085958129772116,90.94349763304126,40.62912087676619 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark08(-47.09582616191346,0.7116364527978192,86.40851926924557 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark08(-47.187114078337295,22.001008761029947,3.5123756711186402 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark08(-47.18972545319258,8.467573211795665,38.728853418603215 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark08(-47.21168000510691,5.185330743193278,13.619349353279524 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark08(47.21429604337525,-100.0,37.000169782248406 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark08(47.276499193329194,-67.45575602948593,8.485261028837996 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark08(-47.38366948497095,29.337615038585493,-55.21265008170019 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark08(-47.4742260245102,62.80151705922134,-15.327291034711141 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark08(47.521223420406315,-67.35043614291554,8.5440829491562 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark08(-4.7527596316604175,-27.66045307068267,32.422269070918745 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark08(47.56022126860632,-100.0,-55.74853986738615 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark08(-47.67857281513913,16.571600687593726,-65.80718834831784 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark08(47.71400489769164,-125.59321897092948,-63.04321258928712 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark08(-47.78280804037045,-2.8421709430404007E-14,-144.25864882436156 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark08(-47.83064926031957,57.78724830078667,-27.917451179385353 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark08(-47.8861977530898,98.65385849059842,55.219920048722315 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark08(4.791821856182541,-135.079368306723,27.032661610677525 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark08(-47.993052612719026,-54.98222493383075,92.00917849559342 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark08(-48.07232032598775,64.62002587691529,-14.976909224132646 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark08(-48.09024743074597,81.94246803727233,-31.424827039491056 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark08(-48.10905454967,-0.015099710259099175,-93.24993321012462 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark08(48.142438334701396,-72.26364645602652,-4.515147286105732E-4 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark08(48.243641304991286,-96.17187827345087,-46.04204877035871 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark08(-48.41806439579509,71.70891220291313,-1.304542947491399 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark08(-48.434769657216826,19.64269143423931,-100.38007384770187 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark08(48.56087731173005,-78.10814610741468,13.790953624365239 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark08(48.57650719890791,-72.5613155229941,2.1776868775304377 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark08(4.863690768977205,-9.133213187419146,2.6998548533018134 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark08(-48.71286798888577,19.91804508858529,-4.206718311209213 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark08(-4.8926623740196264,22.53617843171569,-30.515031566725508 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark08(-49.02581386391617,-20.97048454693489,26.05750050281698 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark08(-49.082176049187126,1.2395096707290913E-13,79.42730913038639 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark08(-49.11674914776043,40.96328925133012,-63.85287261382617 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark08(-4.915374115425055,-4.7261861755201835,8.084745636937193 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark08(49.189481474972,-29.595684400223718,88.37707562446857 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark08(49.19592515308552,-238.9107423414,-303.85201761433905 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark08(-49.20660619933132,123.5539598753627,100.0 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark08(-49.22654474486144,73.38832332380763,0.0 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark08(-4.924168624304068,-39.589340961313134,-92.38039146874358 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark08(-49.34375914167237,30.365546840366548,-85.89865131965095 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark08(49.518907702542535,-73.45114623917954,46.12957155533525 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark08(49.59543871840748,-74.98053743091205,0.0 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark08(49.63152037160217,-100.0,-58.079388213757866 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark08(-49.63168087146954,56.96916856276502,60.3870308512647 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark08(-4.963722865412719,23.339774304118468,31.796058220016793 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark08(-49.692162160850735,83.70229678322156,18.32810708405508 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark08(-49.69728942559955,100.0,50.915718939192885 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark08(49.722777720471655,-95.35317456041088,-39.967219632611894 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark08(-49.741059160140296,34.40844816843629,15.332610991637761 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark08(-49.82541984773986,33.55167076675531,-37.24199920279896 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark08(49.82778991869759,-74.74168487804639,7.105427357601002E-15 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark08(49.86625289413641,-47.711526068369615,-91.71592055025228 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark08(4.993226496776274,-17.777536003639245,-20.575392516949663 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark08(-49.95087088745359,-45.059925171138616,94.60715460267485 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark08(49.97562457397982,-26.812460490334146,96.43977078078102 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark08(-50.00523334431707,40.8274868663358,-70.93171723712463 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark08(50.01025807643768,-71.39300526925886,7.244763690795318 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark08(-5.010623213029254,-26.85830525896022,-68.66712861106839 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark08(5.0182984816919145,-7.264159690350295,0.5265760643751562 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark08(-50.30889940940342,-99.99998235471455,-10.206982503902182 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark08(5.031897793729471,-16.13397900431605,-15.60171179490866 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark08(-50.43529012436559,-15.800809261778673,-0.24340932125852532 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark08(-50.45477320591036,29.479523694565017,-92.17663871892813 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark08(50.47631521982319,-42.0329662888776,67.36301851971271 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark08(-5.047706347374355,6.976321181647242,0.02839688832894136 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark08(-50.542783008655576,78.07153687952085,6.081434887800035 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark08(-505.61784911441976,-944.4034011103968,-552.0612098806591 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark08(-50.57899698540108,62.798400356825226,-24.5693939157579 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark08(50.60631117306472,-68.29843963697152,16.121332137111917 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark08(-50.727360696849644,6.563516455563658,-100.0 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark08(50.761135217273164,-67.76265429112773,17.00151907385456 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark08(-50.800333265618725,95.42262943315998,40.01503268381341 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark08(-50.89790755368213,18.185827599582574,-50.60003579796759 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark08(50.931211411144375,-81.32266323141712,34.13628788818064 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark08(5.0947037561081965,-12.94632634832514,-9.503029596888451 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark08(-51.02725433791311,111.53957673021283,69.34931011313195 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark08(51.05181968056319,-49.48107316279263,4.980902433867397E-5 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark08(51.05838843929109,-60.55915755074577,32.1468259165187 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark08(51.05992293551447,-43.79542424272949,98.03471274991828 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark08(51.08459959684046,-32.49929616792722,89.82600278146161 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark08(-51.09430961566501,-60.557013625178314,-3.8181661861185994 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark08(-51.15746105893767,97.8577964554448,42.24320973407658 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark08(51.2013332858869,-152.27999420213274,-158.99101205733103 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark08(51.24627272184401,-68.54534300753275,16.648132150466534 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark08(-51.31767375435204,58.82444645873039,1.5771088767070296 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark08(51.374406822229645,-81.96119581196719,35.72838164334051 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark08(-51.38724610919196,80.36522154103292,6.568704754489951 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark08(-51.394282343743924,14.631093021920032,96.51924777448289 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark08(-51.479196719731576,102.97382124938518,50.14980678296554 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark08(-51.5393750541766,77.41777866170173,1.7882284876685475 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark08(51.572754847396695,-66.37090394207831,15.26406767763871 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark08(-51.590304925593266,53.70692629458341,45.65053510419207 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark08(51.68555257132886,-62.21527875112412,30.626126164992403 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark08(5.170057162333196,-44.724070643847824,-73.93796816008489 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark08(-51.79948156842307,81.45247505299795,9.077301727521586 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark08(52.06410751380514,-18.183768068725854,-63.65580914193325 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark08(-52.18912342983704,51.66628317681154,-51.664007609093154 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark08(-52.280842385767535,4.256667259399935,47.98599834998157 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark08(-5.2286609526052255,7.317733159753237,-0.5707028580925274 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark08(52.46792331047709,-56.34076791092531,-94.93278384067405 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark08(-5.260022203416685E-15,-55.67565418595168,-106.92320266289259 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark08(52.61049841537225,-82.86025996889258,-6.321280071779155 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark08(52.80090313693585,-92.75947435592235,-25.545442974242263 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark08(-52.86448500999122,99.63640578552786,42.25015286787695 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark08(-52.888349455894655,99.75392735542236,41.02400956526705 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark08(-52.932149006310304,73.9624384478183,-25.212183835335324 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark08(-52.934852999822574,-83.29507237957263,83.44006610362456 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark08(-52.94821605697655,79.99756614294618,2.7212804417576075 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark08(-53.16686901272877,-18.543695960096578,-19.704472148094155 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark08(-53.32258303054612,47.52708515966609,-63.489055207751484 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark08(-53.33136572570288,70.13596828893836,-18.151364272437046 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark08(-53.44314184241098,67.59054026135635,-25.148345004520237 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark08(-5.344472525954925,-11.152887946836826,6.560568861506444 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark08(53.47109754151492,-44.59441907258078,71.40164758864057 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark08(-53.47128322051904,-44.40704417210644,97.87832739262548 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark08(-53.51224552504383,101.12193326000914,43.27710300828893 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark08(53.59248753751218,-86.49194764820061,-12.206432683864673 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark08(53.6024471964625,-74.60162026576948,13.17489738464343 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark08(-53.66616860206853,12.02368780509357,77.77244730323233 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark08(-53.74745239388614,2.2203810031669207,-29.214970228709248 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark08(53.78596776581159,-79.05347147290327,3.8220869735950975 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark08(-53.81422610503821,84.45942034347432,-18.486445638416942 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark08(53.869136261999124,-67.76671044673135,19.35970607341881 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark08(-5.395102280324963,15.883838423865276,16.912014992973514 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark08(-5.395347071926001,-23.50911424633562,-62.20174804299797 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark08(-54.07217815810681,-10.881247905200908,-20.564934033376787 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark08(-54.22487511383431,72.21476153074707,-18.245102280008773 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark08(54.23459145590056,-100.0,-37.28883603445187 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark08(-54.300168463763484,-7.708525292079443,30.875974058802854 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark08(-54.40206611326285,63.70275785740457,-35.8006826249794 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark08(-54.40289301063679,112.8712079859093,95.80943456955426 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark08(-54.45002329295269,60.58150465620867,-23.192357653184033 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark08(-54.46693417098704,-29.559598106878923,44.41314862924101 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark08(-54.486248167165876,-11.205774551139513,28.244208423270834 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark08(-54.49852100686265,71.03677687733756,-19.851212939118135 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark08(54.504820541115144,-54.68483895894145,3.446681039083818 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark08(-5.451771690944407,-0.9368220730106034,-17.22317161537768 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark08(-54.52428315430641,73.85007318889126,-15.791301223195715 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark08(-54.52760964958703,34.545885304043225,46.13477101388361 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark08(54.69103688634729,-75.81200104735352,56.79154193291178 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark08(-54.75230775292893,45.691615638537485,-71.30289565491694 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark08(-54.84271879931246,58.427693767011746,-2.3670894909801676 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark08(54.97338831188469,-95.91450253366384,-25.33811249809265 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark08(-55.00013192937212,61.61939626425977,-40.1913815819622 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark08(-55.06142227769905,17.55906851348561,-85.29777520307778 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark08(55.09384532039723,-86.19720120964575,31.10335588924853 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark08(-55.107364436818436,23.784885540860696,-100.0 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark08(-55.167892309764746,15.789646243596872,-95.97597046438808 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark08(55.26094108971793,-87.92706641823798,-8.500513240527296 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark08(55.35423468112012,36.16730925146854,48.02168659724268 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark08(55.372308415815596,-74.35334333001906,18.981034914203455 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark08(55.377488871842175,-51.128427884613465,63.875610846299615 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark08(-5.542180865267742,23.152000464040917,29.677458332278615 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark08(-55.5752084064855,100.0,34.411742911440996 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark08(-5.566841997129516,56.364207591428595,97.59868551826354 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark08(-55.717997957039756,68.74022228062344,-29.67354923863448 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark08(55.84056900092863,-40.16283685676367,88.76682961605344 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark08(-55.91109363530512,61.079293506703564,-0.5269116420788826 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark08(-55.932662476932,99.11604386106353,-31.99089124327743 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark08(-55.96711720134723,74.34855634353097,-18.381439142183748 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark08(-5.601287841740646,-43.79381532174639,-100.2206836421979 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark08(-56.19684803766132,83.51003789339376,3.280005984482341E-4 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark08(-56.26783311124812,38.71948755088714,-89.79372790517519 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark08(-56.35466909095866,66.22826751162341,-48.451661797511804 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark08(-56.41543205134929,42.47272515388194,-84.29899510720344 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark08(-56.51749604513957,-0.996950996362988,-6.912168126998438 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark08(-56.534265442777844,70.5597716386946,-30.466462614323618 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark08(56.61899825191457,-75.60476829051777,18.985770038603206 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark08(56.62425445295085,0.06681888355870276,170.5052869712225 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark08(56.64822009085355,-73.28964119239622,24.49540273551728 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark08(-56.74176618481002,71.82858662160149,-64.51830407252798 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark08(-56.7749601429557,185.19065518864167,312.92538731803563 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark08(-56.80958653064717,1.427494096770546,53.81129610708172 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark08(56.845732242066006,-51.127122595161055,100.0 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark08(-56.97106229543181,41.72850202870438,-85.88538650209176 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark08(-5.7066000609843925,16.440592272912056,16.077548471134527 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark08(-5.707046061498326,33.442302705051034,9.965768498716512 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark08(-57.080683358546814,65.1876231681572,-40.44649941094042 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark08(5.708907728233468,-14.420515241401265,-10.149187753409134 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark08(57.12376407757436,-54.13817059099165,63.094951050739795 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark08(57.174167451457556,-105.43215530785234,-46.87392529356061 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark08(57.29086339302006,86.3989852772115,-63.20177477705147 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark08(5.761393983783325,-25.890308437131164,-0.2917578877730058 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark08(-57.62224264957476,-100.0,-26.170192487249494 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark08(-57.64780896324162,49.878754088057654,-27.790760032667386 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark08(-57.659329503846,-15.647794378373689,23.41681487457092 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark08(-57.66671512770984,86.45831294670214,0.6530657695225711 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark08(-57.67235535092793,42.17058626320264,-87.10509719958365 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark08(57.766897411146445,-81.89741657236175,23.46309918758108 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark08(5.781773112013275,90.65698606779691,172.43974144768438 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark08(-5.786543894516223E-4,-70.2232643348728,-38.65624021250851 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark08(-58.02755038610802,48.75171064011551,-75.00843355129815 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark08(58.089079274961264,-10.147934036314876,198.05619338354444 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark08(-58.17244327043698,93.79150328610913,5.891262574698203 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark08(-58.24473671945469,100.0,26.156941355635258 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark08(-58.257850200905445,-24.103142170524833,-65.7420772673123 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark08(-5.829388785367991,35.590604835236896,53.69495627122269 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark08(5.833364365865333,-65.88668843135186,5.339022075359011 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark08(-58.333759850913914,36.483049554872956,-26.5490638732242 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark08(58.39887732614477,-88.38386641998092,-3.0453473262970215E-4 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark08(58.450053844187636,-54.630787710382144,66.08868394676617 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark08(-58.46989935519515,77.81635747987336,-19.3464581246782 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark08(58.580586646041645,-76.93763670987612,22.96351388166611 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark08(-58.59736067036777,36.41015742743315,-13.682480800843962 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark08(-58.67483550545701,54.74563006374652,-81.37538012793115 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark08(-5.867650498461148,-23.519194626546867,23.65108401758431 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark08(-58.68187077907317,43.681031595278306,5.564230461198451 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark08(-58.90938655300445,12.699626288344074,37.50432505378129 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark08(-58.94745458118135,88.54593264354253,0.24950198574373705 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark08(5.8995145554383495,9.93990069382109,39.1384561885753 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark08(-59.02618995397214,25.30117405356375,32.154219573613496 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark08(-59.04745405054674,87.78593442382058,3.0302279583814453E-4 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark08(59.14636298176436,-110.67199939914542,51.37095897618724 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark08(-59.20228784590578,-18.52686717676235,-66.18944868011145 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark08(59.232636332019744,-86.01849577839744,11.338177990444608 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark08(-5.923610142201941,-38.46976350676549,-93.13956111334191 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark08(59.259190932708634,-60.79786091756477,14.116581620775378 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark08(-5.931793365172616,46.585864172886524,75.69092502403514 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark08(-59.37295218596482,88.10720930944953,-0.4906162692143501 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark08(59.422970096910774,-1.7816123840477695E-22,178.55894372247312 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark08(59.44457502786624,-75.29582128151992,27.742082520558895 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark08(-59.50266866145708,33.695432102945716,-46.99212693101788 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark08(-59.51439755408498,95.35240440843563,-3.42082632684237 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark08(-59.59410906789198,17.591945110758616,32.559497436145534 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark08(5.968330461861504,7.9638829107156,27.010546882787263 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark08(-59.71986132042617,69.65459578333946,-38.279596067804704 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark08(59.76022884388581,-87.33652619624617,100.0 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark08(-59.78322113527972,-81.03376000402854,-1.9665894881353694 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark08(-59.862887649503485,39.98054522970859,-54.18682526812816 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark08(59.92203202869849,-95.79856227780616,32.7208305574994 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark08(-60.02607207287534,69.2087604801475,-17.75613009749965 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark08(60.030177394588634,-36.03170214320326,78.20333920924878 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark08(-60.072668225877926,82.3170921149919,-22.29620942990418 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark08(-60.16268032536381,80.7363060615182,-19.00282940935951 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark08(60.26694009920675,-81.21732117599151,19.93697427243211 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark08(60.33328934233755,-53.021142295216976,76.52837976337361 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark08(-60.400116300421644,51.380053501921694,-51.78251883489629 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark08(60.565178531239724,-17.75605352513638,95.06254739609707 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark08(-60.64606653560636,-97.93627827683903,45.99211021910932 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark08(-60.68422521042116,-27.49346185300784,-97.71786695653262 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark08(-6.073446045258671,38.48458304682319,58.748827957922515 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark08(60.85039912878132,-69.88841880364836,44.34515582766608 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark08(-60.91877094319146,21.931345748041096,37.41662886835547 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark08(60.96395828494152,-81.29662283788424,20.332664552942724 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark08(-60.986137710074885,-29.0924923471701,99.50341193167456 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark08(61.06609128703719,-80.12756303636456,24.513944115177342 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark08(-61.08770991377701,-5.828432750443124,-24.934763758747756 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark08(-61.150837836588735,47.555175404787775,13.559474022316564 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark08(-61.17524119433467,67.5691813063191,-55.09974995075349 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark08(-61.20245256859402,-76.49367656344494,72.09275966028336 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark08(-6.128428643972001,-0.0139577822205098,-18.36345205351732 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark08(-61.43284188019024,-63.917946814906124,-41.76003838755061 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark08(61.68211710875673,-83.27196411073739,19.08012497612333 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark08(-61.753869942593965,81.64302775569425,-21.233370595652563 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark08(-61.763925942979625,54.034041535776055,-77.22369475738675 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark08(6.177926830013937,-29.916858241390596,-40.672671952447544 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark08(-61.97930100753819,-94.47191673764699,-22.955494204411806 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark08(-62.05400170664799,27.01848900265467,82.86395593237846 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark08(-62.114445155718606,58.60892310466875,-67.55469293102342 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark08(-6.216926744227593,7.913094623996291,-1.899472201986967 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark08(-62.301376482296554,-15.338101838344361,-53.86275711660851 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark08(-62.31870348352617,31.1518767995541,-41.90898550014981 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark08(-62.41180107732557,-73.19636704200906,100.0 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark08(-62.630879341619526,35.74951444296505,-83.68313479116537 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark08(-62.755475078377984,83.66244876800323,23.20591276464836 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark08(-62.964381764705756,-81.872377774038,-44.79044788961459 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark08(6.310416832338326,0.0011230936434775908,41.98377460468441 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark08(-63.260552772520285,86.97753638781339,-15.826585541934088 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark08(6.329004631353943,-51.54350178541773,-82.52919334997874 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark08(-63.39115325831643,100.0,17.021420386836922 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark08(63.410150596717344,-98.50502111507863,-6.779590440004919 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark08(6.344517823962734,-25.740319182113907,-30.87628856554472 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark08(-63.511167904564836,54.28678905778939,-80.38912927132083 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark08(-63.5524723556177,75.63385404610327,-39.382010175120044 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark08(-63.65013353835447,14.557428459327403,-4.681220749634946 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark08(-63.71612851454203,-7.117968707582364,-32.55945337098531 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark08(-6.383596556491541,-40.948699386451764,44.033138988170556 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark08(-63.90264979642939,-9.952155304266082,-64.25146124773286 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark08(-63.98617386665147,95.19528107546564,0.002836877771776462 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark08(-64.05081881509959,69.81549097085471,-50.95067817679444 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark08(-64.08221315311633,91.72675997004448,-8.793119519259996 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark08(64.17271421979248,-87.15315138574357,18.41399624933858 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark08(-64.17886933718738,95.50222320422746,0.0 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark08(-64.20007766801253,4.605044314052776,-19.319608571169333 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark08(64.3658386784687,-63.22808378307483,68.21214479605133 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark08(64.49072217703876,-93.33707652482622,7.8436235373030545 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark08(-64.66614605621534,72.59067115887973,-48.817095850886275 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark08(6.46934167446977,-63.58548326125464,57.11614158678489 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark08(-64.71131320914594,45.87077249692802,-85.52557941207697 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark08(6.4735226017250875,21.425523045447786,63.211053077844795 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark08(64.74822125953308,-100.0,-5.471150612826804 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark08(-64.7742207415432,50.9334036510258,-92.45585492257797 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark08(-64.8175839462326,-26.321223933652476,-51.13788815482787 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark08(-64.82043185649898,-39.00349622202816,48.88431715722592 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark08(-64.83767557656226,3.914763063423294,-29.0580234848818 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark08(-64.92704033008721,-25.155163251495924,88.51140725478824 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark08(-6.506205840370442,-23.267993187838663,-80.03018056400923 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark08(-65.08565945022869,-32.003790392212,-50.871340742331526 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark08(6.52412705425445,-26.573978589674326,-32.00477968979042 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark08(65.26245516076384,-78.5485845959718,38.75147003903 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark08(-65.28925445822874,220.6652357940866,246.17842251694202 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark08(65.3654696293115,-165.30021945794306,212.5344072152046 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark08(-65.395792358564,-31.910523873775873,-51.189069580004976 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark08(-65.48513150110234,76.36952701156159,-62.61479231985791 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark08(-6.548790375041875,-155.99694523663106,-110.64332582592546 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark08(-6.552065473226874,-32.46107499037654,16.35418739000818 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark08(-65.6970931458835,-30.394042643527698,-39.32721606008205 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark08(-65.94890575416522,76.27504520331765,-0.8388614883829886 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark08(65.95712752086685,-113.76474244610174,-29.657286681108488 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark08(6.599640616447903E-4,-28.413312883705554,-11.791051232349668 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark08(66.02845771747633,-65.63548461750115,67.98160030378878 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark08(-66.07507983771369,99.11261975656794,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark08(-66.25072737942145,76.32871223343935,-31.36509090661089 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark08(66.26435969036703,76.09674169434751,13.75433557889987 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark08(-66.28735655894423,-40.75777555311561,-2.809819119389374 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark08(-66.38789022196585,86.74499479632895,-32.923475188722286 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark08(-6.653347437741747,10.763615821919455,-10.436749612460625 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark08(-66.55332989887395,-15.201387589924394,-184.7013551066652 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark08(-66.72896639790166,31.95797646190928,34.80538178069404 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark08(-66.79371288346198,-25.605584255093547,32.63423838635497 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark08(-66.79502634665268,57.124699534291395,9.670326812361282 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark08(66.87663116136657,-58.304985184792784,76.30923429380371 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark08(66.88717136461436,-99.66128400484087,1.3584310272793036 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark08(66.9937237740092,-56.37945300053674,88.40006241282232 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark08(-67.03367268990979,-39.68378025342022,21.888617159181024 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark08(-67.15311098099185,39.91876445268753,-83.02824713098518 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark08(-67.28020992984652,51.56684131033975,-97.20101235224446 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark08(-67.42769773912394,-31.977298572514727,-25.974966886359923 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark08(-67.47000720553054,-29.581688060857857,72.64742672776941 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark08(-67.48862623732934,46.323224155471365,-8.030449293377378 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark08(67.49850229202076,-119.442928645973,-35.32598277605741 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark08(6.755264023600992,-24.05990317248628,4.169699195971308 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark08(67.63378511873246,-97.47867707034824,-2.382574871536801E-4 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark08(-67.65279345523706,22.012268323340468,-0.2883347206216646 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark08(-67.84914593873788,-43.57913477903741,39.34171156469927 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark08(-67.99615713762257,30.998004914812256,72.22761503270621 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark08(-6.7998473962549,18.15427696571377,17.479808069457732 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark08(68.04275509138796,44.964343820586635,-97.28538706224319 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark08(-68.05442795681842,93.27216099115832,-16.048165561343723 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark08(6.830350778482688,-8.583055755258586,3.325541202211927 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark08(6.83457362475165,-29.558102700730924,-37.13074258551813 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark08(-68.36880245887029,92.5558936740478,-19.690000153718145 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark08(-68.45110149520993,25.037744077705685,-145.15642420527882 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark08(-68.46480146596123,18.416320696442256,1.4210813759470469 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark08(68.52836404698544,85.71484555251874,-93.74983715891672 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark08(-68.54608468931562,53.78701158469755,-99.41532793771893 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark08(68.67549675996653,-81.14588276337273,44.527727683401196 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark08(-68.67855847650515,52.891523911298464,-100.0 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark08(-68.6972096356273,130.30042487638713,42.83198878188123 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark08(68.81314780906762,-56.77493142765539,92.88958057189208 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark08(-68.86934305234016,75.42879793650116,-55.75043328401815 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark08(-6.901846168422274,-7.241608012475638,-28.188247473043745 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark08(-69.16717646778514,52.96716390071823,-99.99642822183831 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark08(-69.17769010053469,59.400736854440424,-31.248201548891032 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark08(-69.1986024376146,78.52108467789456,-50.55093829883712 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark08(69.21958937615578,-60.43421505093471,88.3611343533928 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark08(-69.25006347696537,48.79865590291388,-78.705526915435 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark08(69.29061459345154,-100.0,9.052243083428301 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark08(-69.39183167521688,17.082640309834858,2.0018439425444967 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark08(-6.96436219272858,-43.45746098017466,50.42182317290324 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark08(69.64753795125186,-76.8914330308622,-95.65844777634331 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark08(-69.67664573416286,-27.95860889874938,17.838015034887782 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark08(-6.969204858193513,1.076075577044353,-18.271195892345215 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark08(-69.7164573618664,93.50454768352418,57.86961332721066 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark08(-69.73285273315942,73.33387551453907,-62.16017023235338 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark08(-69.7495533138815,81.78044121438846,-0.1346840358156412 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark08(69.75310097836328,-86.2610979594368,36.76879025296765 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark08(69.88910227114883,-55.781833960035996,99.67443522016939 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark08(-69.95295954221073,2.7297346686953716,66.39526838099646 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark08(-70.04335096373836,33.415867531981945,-98.95349863615073 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark08(-7.008595839621266,6.3415541618536535,-15.05506818167581 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark08(-70.11542379514974,92.97370909235082,-22.858285297201075 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark08(-70.18907245157865,-15.556058092196153,-40.35132982281344 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark08(70.21990285725215,-80.39408849467328,82.54827827915588 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark08(-70.2311196650668,77.14549030910806,-55.298011010323414 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark08(-70.28456048669602,-8.253439348258953,-13.581937259880021 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark08(-70.72526239612857,-27.434928764953018,10.864915402211317 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark08(-70.95971372280883,67.45862285878788,-76.39109912405584 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark08(-71.17955151570114,-60.129954937715375,74.97612408115305 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark08(7.12336329226698,23.67595426267887,70.29279472895357 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark08(-71.31823580864032,-2.3156803039869263,1.3254182699102401 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark08(-71.33837976674648,0.001804277771069362,12.203748164401944 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark08(-71.40180193358708,-51.46230921520238,-79.87749094740977 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark08(-71.51051790978468,54.6713699388533,-85.3437909887372 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark08(-7.154883563511282,35.78910721106854,50.1767186845007 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark08(-71.72023253691759,93.82810569350515,-27.249465810177362 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark08(71.81410422345033,-126.75390937544546,62.79151748014796 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark08(71.8153510678959,-19.793348139867817,-62.77610981774193 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark08(71.83783927219072,-57.75675890829035,100.0 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark08(-72.01596095297359,73.85255480270216,-66.77197692672155 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark08(-7.202875067615198,4.045595489523548,2.2551405187698492E-17 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark08(-72.1023309830087,-140.34260195972513,38.48821573160441 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark08(-72.12592511333628,18.71525721502543,-99.984097079284 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark08(7.215210159810665,-1.081578975841628,19.482472527749227 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark08(-7.216001759240648,37.20613862753701,52.77927125753361 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark08(72.21241736206636,-84.74041277837732,28.248687817255778 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark08(72.33995986088925,-63.4256148829125,91.73944614363765 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark08(-72.4033930738901,4.5260309784865,-100.0 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark08(72.46780680755629,-87.70882867813003,43.556559393203045 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark08(-72.57492358720789,-13.736229042267901,4.213824323425063E-20 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark08(-7.257703859474056,16.9208916451316,12.06867171184105 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark08(-72.58223795767633,18.72298905622177,45.97452555823254 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark08(72.61920475158219,-64.50137062979135,90.41966712378917 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark08(72.66719118192015,-46.242024783416966,-48.66323546284526 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark08(72.67697300766264,-85.64624559012162,47.16727267756277 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark08(-72.75495027411772,-34.08882001732998,54.3494945336077 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark08(72.7623329951881,-80.14924165828283,57.98851566899865 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark08(72.85994789390972,9.225341823538784,-89.55164485453622 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark08(-72.9959906859426,76.43400599255529,-41.1141649881384 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark08(73.06671862675515,-97.42619300502481,24.35947437826967 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark08(-73.17449395582726,57.15968683892301,14.444010790109363 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark08(-73.37786817372725,109.43825863053357,2.1944180556943138E-4 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark08(7.342732423117894,-138.91292938948249,-98.37864239535945 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark08(73.43551013313822,-98.19111461249565,24.755604479357423 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark08(-7.349425166756261,7.074832728655163,-0.2720506005736183 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark08(-73.63043229074144,82.58819340878945,1.4670168427230408 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark08(-73.67782811268043,66.4721053852375,3.2073298666792207E-4 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark08(-73.73093857318786,73.05987669712825,-75.11008619945103 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark08(73.76117674422612,-73.67832169468714,75.49768317009895 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark08(73.9762356019647,-93.56502635106663,34.798654103760846 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark08(-74.01288582386545,-37.198754484219364,50.266404330690705 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark08(-74.21311062830824,27.295839611389766,-72.44491402523839 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark08(7.4246037965838285,38.07771170585903,100.0 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark08(-7.431577545016079,10.36196815412718,1.014299755297543E-12 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark08(-7.432893362165349E-4,29.613081573528042,60.06988258347301 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark08(74.50135500375976,-100.0,55.94015436806053 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark08(74.55164124804145,-65.89635967524997,92.35246826617625 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark08(-74.5671709509599,-46.480835354009784,-171.12088362944806 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark08(74.60730778264559,-100.0,25.392692217354412 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark08(74.67423719458967,-100.0,25.325762805410346 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark08(-74.75234203791373,-48.843351995833714,-95.39536300073479 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark08(-74.96115886059245,-22.90692066500773,-0.36059359130315727 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark08(74.96758546826878,-70.18932101857966,84.54621618813812 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark08(75.08337404954192,-100.0,26.810078673937454 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark08(75.24007782296182,-100.52748774422281,25.287254381753176 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark08(-75.31257085266351,90.57731542584192,-43.21228537951183 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark08(7.548916866960944,-28.738205235486706,-33.260531980885986 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark08(-7.549390391499701,37.40820520013377,53.62452127543876 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark08(-7.551881953626053,-62.13210258513447,66.9589752866761 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark08(75.62976917481441,-66.68835665729017,92.07588402180781 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark08(-75.73326796947273,100.0,-32.50977452235876 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark08(75.84203121197163,-58.58797869912458,-95.33315113916126 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark08(-75.8441931189155,84.55746191590225,-39.05230691274203 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark08(-7.589828067374509,9.957722107933629,-2.367894040559119 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark08(-7.594318430641182,-79.41805373401442,-5.131396858940123 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark08(-75.97813770731074,64.28916800585125,-60.59721462086317 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark08(-76.05522293707836,66.75135435768476,-93.09216376907067 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark08(-76.19279973852164,42.356652068511934,77.3314443732784 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark08(-76.2339876914436,62.303056649691456,-42.404153377698606 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark08(76.40665248204365,-88.93657299315785,51.346811459815285 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark08(76.41734718031701,-221.82328149273565,252.0575168574017 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark08(-76.52103836793121,-96.23331876369731,-38.20457708511667 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark08(-76.61837426596311,-1.871465271818281E-4,34.8702477944409 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark08(76.76756425980389,-94.16214166547347,43.549205775259594 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark08(-76.79025544989321,100.0,-30.370766313608932 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark08(-76.85187842641474,-100.0,-59.57418238186513 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark08(-76.87913487239612,-1.9995875217752968,25.943805062369798 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark08(76.88316839155232,-62.27726973190186,106.86606620424979 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark08(-76.96723615195955,-1.1566189785078222,-6.575351426607497 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark08(7.698412026494334,-66.05704173386334,-1.3486669991571905 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark08(-77.04462038940108,82.98334753987919,-57.32438992958249 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark08(-7.70522291118093E-4,31.54085826951377,64.63401918407958 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark08(-77.11625606172761,-34.73364045532037,-73.098755002703 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark08(-77.14588114387175,-8.25324812046722,43.394085158159555 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark08(-77.18029847284211,101.21187307660779,15.180332709157975 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark08(-77.22059585570837,95.61773287621136,-38.85552548790749 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark08(-77.30142764412314,-59.82865721142181,-80.72887047912576 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark08(-77.30583336639108,-51.071070974689086,5.232364539146445 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark08(77.40902682241546,-84.049086778619,64.1289069100084 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark08(-7.748757671133589,-9.57119865336823,-9.919990773026443 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark08(-77.50016897081093,81.82341737187461,-67.28287744405746 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark08(-77.6303752071843,81.69973853683251,-67.920852221093 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark08(-77.63537912731877,56.289965128638016,37.92924368978177 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark08(-7.774444687650349,-14.807119582975298,22.460651713171927 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark08(-77.74701111406215,108.74334179362445,-15.316523534747459 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark08(-7.811322996068952,-23.791751843848978,30.032278513123035 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark08(78.1757773710276,-118.49154290211642,-2.2845589107483653 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark08(-7.820495317353091,4.6769598362465095,0.0 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark08(-78.3034069953256,46.148319056194126,-90.93139423653598 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark08(-78.402607031083,-115.39121817454051,0.016111696968475548 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark08(-7.848974840737976E-12,-20.848069445517638,-41.69613889098684 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark08(-78.55890025156805,100.0,59.76586671521892 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark08(-78.58177727271688,94.21967565988648,-47.30598049837768 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark08(7.863883310944945,1.6697754290362354E-13,19.23920283066183 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark08(-78.8233205856009,76.1717366089806,-82.55569221204662 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark08(-78.84510694237152,-95.20393462515348,-100.0 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark08(-79.03270879816338,-21.92826509475242,-59.93191836201399 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark08(7.907053077981603,-8.177442931852347,45.06804478430928 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark08(-79.26131921050349,52.95471314396305,26.306606066540454 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark08(-79.30857762435058,14.156116744937,60.81495429096494 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark08(-79.41425454625937,67.01985689565703,-78.98461597371025 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark08(-79.41643941489454,-88.17848750699694,-100.0 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark08(-79.48583315704538,-27.111730643852056,2.6287980604365386 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark08(-79.61183283132627,3.4146617505178316,76.19717108080843 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark08(79.87484894191148,-83.96615517114046,64.97924124127772 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark08(-79.90869809577957,99.35960162616658,-39.55650845896264 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark08(7.991290276722179,-85.96435418392704,-59.48913188645828 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark08(79.9153092818136,-135.51255984188924,-57.25069597270668 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark08(8.035877093229592E-4,-25.072807146231188,-49.632226018398114 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark08(80.36078233813495,70.5346185178677,-42.86625796732808 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark08(-80.39195186583765,-13.910605491147395,78.14892164183286 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark08(-80.46404000650942,85.29625580025943,-69.22881209221451 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark08(8.055030745027464,-0.007678671091597089,25.396075482493973 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark08(80.66060505449936,-70.68879602584447,100.0 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark08(80.6775342407141,59.491807108203034,-54.27311965208044 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark08(-8.075612627445516,0.45172841305865674,-21.752584729424353 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark08(-80.85213209214078,3.21631176587486,34.611855535396614 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark08(8.08866430893531,-44.906853268489634,-72.26010282656208 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark08(-80.93434507879823,100.0,-23.42697730531855 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark08(80.94223866049377,-100.0,5.970372886025346 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark08(81.00017959888255,-100.0,-7.713174638789313 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark08(-81.07229509105048,99.5922544368508,-42.580043375025014 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark08(-8.107651143932841,1.5631940186722204E-12,8.107651143931278 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark08(-8.109623341645808,-20.572591091123638,-63.90325588038981 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark08(-81.1938180044077,4.156349663252712,-52.00383824798935 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark08(81.22214307323965,-99.54514971044163,44.576150604340256 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark08(-81.32269876920536,229.16432918425895,213.42032124014264 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark08(-81.43391517322783,27.256096805886646,-88.83907311327955 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark08(8.15598687542466,-13.705478215710727,3.978735326983255 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark08(-81.68835274901411,-1.5222726804097189,-33.99962345628839 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark08(-81.69103565616125,90.53603864602192,-62.430233349645015 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark08(8.175169245961213,32.75372193387959,91.51976657913555 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark08(-81.90112768780337,1.005494949253002,-73.68783952974658 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark08(-81.91573025824255,57.21059271268933,-67.69995372480176 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark08(-81.9508457558959,100.0,-13.244623896516053 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark08(8.200224509972035,-91.70148469471091,67.77772959637828 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark08(-82.0209650991211,-32.26965726411207,-8.830400454536443 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark08(-82.03318929642333,80.52912112359226,-83.47052931529058 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark08(82.1870005662108,-7.2656857191366555,-6.149878208771526 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark08(-82.24331061750608,100.0,-45.15917301896902 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark08(8.225910605774004,-90.10831902707437,-10.490026875950798 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark08(82.264270313478,-74.30505752563695,21.745536552362204 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark08(-82.30718030393538,13.973002249054332,53.979857600477175 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark08(8.238443269053409,-17.267452792135707,-8.25092512049568 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark08(-82.42114067017943,-68.39542470945634,25.919455385836088 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark08(-82.50112080614298,47.58007707392616,-64.05598826437739 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark08(-82.50374732204348,74.91644191271575,-3.33820424567935 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark08(-8.29151352838602,10.82409386494048,24.046381008547883 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark08(-83.01209679107686,-100.0,3.8715199663381696 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark08(-83.16616895704004,-71.33961756145254,9.992509171442627 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark08(-83.25906292998202,117.09035617130837,-23.05084697680923 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark08(-83.31126849008379,99.74667151624129,-51.90929576121542 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark08(83.32471928739994,-99.9999937820466,92.3933033288973 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark08(83.35959487362564,-82.83850561973249,85.84942172682759 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark08(-83.62042786394588,81.05266538624063,-87.18515649256148 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark08(8.374869541318054,-5.788097035944312,13.62598915864996 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark08(-83.81103294173985,-2.676417386123209,-92.07327382732183 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark08(83.87261194799822,-99.28108097444625,53.0556738951022 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark08(-83.90643953732747,67.88305089372854,-21.63904619707858 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark08(-84.03415289537521,95.66334278476617,-28.09503843941322 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark08(-84.30046331970034,48.616662532765886,71.62435992894618 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark08(-8.444514864491605,56.08241514009006,88.4020820135002 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark08(-8.473037815995625,-79.11757206683534,14.11417507437649 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark08(-84.82538597865356,119.38275927636896,15.75022237651951 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark08(-84.86592817492149,1.3022536693702618,-37.839381915872444 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark08(-85.03335863576048,73.77517443521019,-63.09197235774722 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark08(-85.03593259518104,31.50990471731256,-191.77572984431706 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark08(85.06044306586591,-78.51060619696901,-16.28700816688753 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark08(-8.509523197809502,-26.315258579513685,-77.32628694046431 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark08(8.512612357813836,1.0358825037006056,72.91072183802552 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark08(-85.20781511345244,101.43987566030661,-59.45608302642442 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark08(-85.36139439667875,76.96674138779461,-101.54365258635737 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark08(-85.39101329104919,0.2656337253968246,85.12537956565237 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark08(-85.44440741601456,155.16892408427063,98.42337242461232 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark08(8.54777929445635,-66.4357349211888,-100.0 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark08(-85.59832007844416,88.26757581589284,-80.2598086035468 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark08(-85.60623929110706,6.226500260968109,63.54317939696233 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark08(-85.77230632555049,-57.28025330044459,25.02160220300975 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark08(85.79012681958974,-89.82454315018862,94.82942703383432 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark08(-86.12203806184714,38.91926283222572,45.706145018710316 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark08(-86.12494295782953,92.56002602787089,-74.72393237576848 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark08(-86.15993382232364,16.59418042341297,58.7677691794052 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark08(-86.37211072305374,63.78847688259089,-99.8147552582036 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark08(-8.639852267125821,-5.044030729380248,2.7037916730074922 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark08(-86.72585406580565,2.088443383081869E-4,86.72585406580556 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark08(86.77451979521732,-52.58899006973826,136.926586139487 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark08(8.679777516923387,-52.74129611197545,-98.29870174987735 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark08(86.82194445200633,-91.28938489209942,79.45785989861506 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark08(-86.91769133027502,-69.98505875791292,-10.631867640824638 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark08(-8.72345428227729,-11.725175157610167,-48.05267971445736 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark08(-8.724159471484901,-23.162648801276248,15.678844703272828 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark08(-8.74348759346125,13.126525239929222,1.4639565459014634 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark08(8.7536706068832,0.3863786494945205,28.58008676486655 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark08(-87.58868542968087,90.67795265707188,-79.83935464810395 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark08(-87.82223074140455,100.0,100.0 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark08(87.86819156445839,-8.472393432251508,-12.10882896362071 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark08(8.820188382642769,-1.7820488047258976,24.467263865271406 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark08(-8.82282837815995,-85.42268200239435,29.01602296033101 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark08(-88.30029634045718,-49.622451468191244,-67.5113732895649 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark08(88.4688968634274,-63.514039645537544,15.73998959187557 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark08(8.852835409243898,-11.80405110050516,2.951215691261262 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark08(-88.67694341958357,-20.983040135517925,16.825550541187283 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark08(-8.874136601695184,-13.302248038428862,-53.22183991469941 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark08(8.878577945509702,-49.81837905757335,-73.00102427856143 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark08(8.879712016564838,-12.119292522373048,3.2395805058082097 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark08(-88.84962643919866,-71.84529754442816,-75.76871057988262 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark08(-88.98698505566493,65.32843514087804,21.777677677268684 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark08(89.33413639684217,-100.0,68.25050802491035 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark08(-89.41259580281383,29.786013237225397,12.4997845490052 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark08(-89.51604734691318,96.84044164561408,-36.92505539043921 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark08(-89.73502643602833,-84.98223115883184,89.83354704975017 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark08(89.88711891450572,-19.163259593223472,-49.0027681285425 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark08(-90.07357264696422,2.6025968538431243,138.42685373471713 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark08(90.1246141278406,-55.26246492698572,153.05840467372005 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark08(90.12627742949569,-224.66058144570422,-178.37266997657875 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark08(9.018717081170216,-63.62281930846047,-100.0 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark08(-9.037226889772182E-4,24.56996324416798,49.71620431612877 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark08(9.048420770692806,-54.90715524383444,44.28793814634673 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark08(90.83990913569609,-100.0,72.5197274070883 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark08(-90.84008554465176,79.49552148564669,-100.0 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark08(9.101081539887497,-19.4271548479871,-10.14256806951392 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark08(-91.40435456660484,172.4893804937164,71.2741317019296 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark08(-9.168171762939567,-37.00980991491077,-99.96344652516423 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark08(91.76146599865663,-64.04000481046998,97.92811267298413 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark08(9.199121807903886,-3.918755318810195,20.654540716911207 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark08(-9.203738345732653,54.989525854360146,-37.75905117054347 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark08(-92.08800165196078,-23.385154386779334,79.23675992052739 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark08(92.16896863067491,-149.33141047131252,-19.87317720946085 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark08(9.227884547854753,-88.28411872823887,77.48543785358922 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark08(-9.2319176674963,-8.011508617400265,-12.106084091055498 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark08(-92.33890897878646,47.280459507813184,45.05844947097329 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark08(92.3429656028623,-89.29984656769088,100.0 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark08(-93.03446649636547,93.48252819604114,-92.13834309701413 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark08(93.1723321004462,-22.791517610920266,-1.0096785592535866 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark08(-93.17386666815868,90.3829653563377,-98.75566929180059 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark08(-93.21143077565718,62.33502449926693,-90.23807332493939 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark08(-9.348274682470764,-28.748975284083127,-16.38283824404786 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark08(-93.51277360161369,29.555191839702964,62.38678543511582 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark08(-9.351949395997835,-11.657974858142438,90.48749128974401 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark08(-93.5599598839854,95.32804914824271,-89.6495795817081 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark08(-9.358769287893686,-2.541828623743128,10.829258430096111 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark08(-9.368601656292324,54.30755293374142,82.08009722540069 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark08(-93.73634297499892,10.673532427397504,-45.828168642862856 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark08(-93.79775081741616,-34.293711897143574,-9.540981697960689 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark08(-93.79814310851611,89.46837116563043,81.89768263448843 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark08(93.81826830821434,-125.93134670589782,188.14889654858032 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark08(-9.388609407615073,25.91019988678252,23.654571550719826 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark08(-94.05555054928024,100.0,-72.40701567134676 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark08(9.419896526081182,-27.837765091649743,-27.15232095364173 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark08(-94.22732043277742,-86.77631017268324,85.08507531760458 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark08(-9.43605619237031,12.543783356330815,-3.1077271639605044 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark08(-94.60296599929849,-243.74908867384661,-149.0401810526614 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark08(-9.471538109148412,-5.394701345957757,0.0 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark08(-9.491311252618216,0.0019584063649878435,-26.899299871371575 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark08(-95.00726547933102,-86.51497875224207,1.6855809002720008 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark08(-95.11574327400626,26.84659644154914,51.21119631523395 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark08(-9.512555284985137,15.228126499896291,2.342393979006319 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark08(-95.37320036068787,21.60684586815661,-141.9145973468117 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark08(-95.37957573269907,22.0201937125731,73.35938202012596 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark08(-95.49639975841255,-7.387474324094255E-4,22.265727708737845 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark08(-95.54942478921289,100.0,-85.0774780408438 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark08(9.575813372333283,-64.40706910494224,-98.51590176608974 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark08(-95.77686626799537,57.374126131440164,-34.06660371080508 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark08(-95.7977568030399,57.92893937486609,36.29802110137892 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark08(9.582253428177337,-1.7869866669737013,25.20366239133822 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark08(9.606002820206072E-4,-35.5249475596243,-71.04701331840253 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark08(-96.28345580954952,100.0,-241.030746345885 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark08(96.36069563835818,-124.49709513018459,43.25596828471535 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark08(-96.77772011127874,100.0,-93.75495399465743 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark08(-96.86212386462554,-178.0422202772383,1.0398154703161708 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark08(-96.86708459355395,0.08836864412639828,49.08082449721331 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark08(-96.87218212336653,-6.6166730034784305,36.01086754299698 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark08(96.95627895997028,-240.49530763804677,-189.27888352038127 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark08(-97.156388096357,3.524457174625624,93.63119395717193 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark08(-97.39140856211898,-89.78076617612413,-31.12885315262352 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark08(-97.50642753565401,-45.07400381181594,140.40776023254995 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark08(-97.52063205601883,94.19743154136101,59.56443604177805 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark08(9.758800928701547,-87.87876532261771,61.031315092020066 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark08(-97.68190034572777,3.3465659914995105,-3.347081285172948 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark08(-97.71076064229933,34.1104555004669,-53.73461824285227 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark08(-97.72410161670055,-75.65768909471724,-58.35300431461512 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark08(-97.7701672889402,-3.1886667298666214,-98.13175867299444 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark08(97.83594869035636,-94.39758145104432,-77.5991639049003 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark08(-97.97770503715553,-51.577069629452,69.02616278652053 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark08(97.98339278516454,65.91836319205024,-58.047942254052565 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark08(-98.00616214583074,40.49186936203566,57.51429278379509 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark08(-98.27894060008626,-98.88726376212122,-76.57770158060511 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark08(9.828385786856511,-56.85827399573745,-45.065494869333264 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark08(-9.84425661560468,-7.188337063053169,7.391181249321715 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark08(-9.845893564765333,-1.0698690310812819E-19,-28.85353016889033 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark08(-98.5079262588679,-100.0,-86.86020045487219 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark08(-98.5291978592914,68.9930485129981,-156.03070023750828 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark08(-98.59611100834213,-51.041174478922336,-52.33446971429927 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark08(9.887681662508298,-16.808911283304898,-2.5053187732571645 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark08(98.90307388742802,-98.90633536652467,100.0 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark08(-99.06235405330803,38.37725250285631,50.36126042642294 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark08(9.906959907240491,-37.41076335614928,-45.100646990576806 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark08(-99.1435030706904,-85.0651742147945,67.96833175915344 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark08(-99.23466948767468,100.0,-97.63349095316329 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark08(99.2818627963138,-226.59415636552492,-155.31016037846774 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark08(99.29553864891307,-99.84735614532629,99.64285171907018 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark08(99.3857213250158,-100.0,98.15720273477645 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark08(-9.938740760175712,0.0033955967612342803,-29.63142424666743 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark08(9.942828598995141E-6,-136.29028631850358,-171.5683517290854 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark08(99.45648277254901,-100.0,98.36944831764704 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark08(99.4764012244017,-100.0,100.0 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark08(9.957398176854042,85.09533381085998,-34.17291558800808 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark08(-9.969086971742186,-29.606982661963198,-87.65850990804691 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark08(-99.73150745862087,-82.14341119631516,-73.41356712370816 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark08(-99.74301814837726,100.0,-61.346665275678305 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark08(-99.80807471405849,12.167005304789086,-47.34592863734054 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark08(-9.987031589074642,43.67900227582862,57.02020989883291 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark08(99.92406136088304,-99.39093626528243,100.0 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark08(-99.97938032634731,99.42673143792479,0.5526488884225331 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark08(99.98356542460061,-99.99998694744818,99.99999001914992 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark08(99.99754100394,-100.0,61.36550157757368 ) ;
  }
}
