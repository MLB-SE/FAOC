import org.junit.Test;

public class Sample55Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark55(0.005833212816461146,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.2310523745493426E-16,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.570796326794893,59.10149759301112 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948948,-52.17436505616695 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948952,0.9909043100091206 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948961,19.944694116720523 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948963,1.0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,0.03093620357134108 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-0.03239588586253673 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-0.03592581236264836 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-0.048534056083170775 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,0.06255252563033765 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-0.06255252574366801 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,0.07216258016493127 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-0.2116236584447436 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,0.22528911758374726 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-0.28505765678528583 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,0.29421550140951525 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-0.3457997074353669 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-0.3597349460741499 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,0.5509470503879879 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-0.560417216968174 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-0.753809712804456 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-0.7599008650051722 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,0.7953520365668185 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,0.8164462618914131 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,0.825552060845121 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,0.8628683628475489 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-0.8863664157337606 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-0.9148038636362004 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,0.9472548801001603 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-0.9799719198591508 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,0.9884234367535583 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,0.999999999999671 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-0.9999999999999676 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-0.9999999999999938 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,0.9999999999999998 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-0.9999999999999999 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-1.0000000000000018 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,1.0000000000000036 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,1.0000000000006664 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-1.0000000008214818 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-1.0000000097524517 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-1.0362072012667674 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-1.3406117158255004E-26 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,1.3758210268297398E-135 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-1526.8077774262588 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,2.1684043449710089E-19 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,2378.425309299421 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-25.787566899178003 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,25.967925959128564 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,28.929325793423033 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-31.423509297804944 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,31.543992658844044 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,32.57122734495576 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,3.3337785518169625 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-35.06008262400164 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,39.23363481961518 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-40.40089388334296 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,42.474874674217915 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,4.3368086899420177E-19 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-44.324586292767414 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,4.930380657631324E-32 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,49.89933267368949 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-50.34920943776139 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-5.529293568794108E-176 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,56.003409433301584 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-5.732045286014816 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-61.33500621398001 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-63.89432688508724 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-71.75565483179629 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,7.359867586913394E-12 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,75.73593375312177 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,79.26942686690339 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,81.06888607237605 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-81.1840204218675 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-8.289328267443596E-17 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-83.98551437367021 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-85.55980011633574 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-92.98778935245163 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,95.06700609885672 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948968,0.9316305251284283 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948983,-0.9999999999999991 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948983,1.0 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948983,1878.7170982631028 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948983,-2345.7951707078873 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267949037,67.35687339978537 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark55(0.05274848301765035,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark55(0,0.8138490195160415,0 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark55(0.09222235491579056,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark55(0.10521523115195397,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark55(0,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark55(0,-1.5000000000000002,0 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark55(0,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark55(0,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark55(0,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark55(-0.18829387345807902,-1.5707963267948983,31.215011146301098 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark55(0.20476318471169624,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark55(0.20550165259550468,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark55(0,-26.2424334849306,0 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark55(0,2.6339006723193847,0 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark55(0,-2701.025553052787,0 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark55(0,-2738.6468944812864,0 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark55(0,-34.766091498726496,0 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark55(0.34837841822854165,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark55(0,-3.5837342888616917,0 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark55(-0.3701201191020647,-1.5707963267948966,-5.327993384780537E-256 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark55(0,-37.18046545835878,0 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark55(0.37277158799022914,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark55(0,-38.789650255763554,0 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark55(0.39503681696769144,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark55(0.5010712965731017,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark55(0.579691340720851,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark55(0.5906563193243386,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark55(0,-5.959711320580709,0 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark55(0,-6.462348535570529E-27,0 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark55(0.7077564028004133,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark55(0,72.09603303714411,0 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark55(0.7491440973922536,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark55(0,-78.98363322098055,0 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark55(0.8207519412503869,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark55(0.8932071751410717,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark55(0,90.7668745978956,0 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark55(0,-94.35628436003765,0 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark55(0.9540841009996823,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark55(0,-98.49514479240231,0 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark55(0,-9.860761315262648E-32,0 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.570796326794886,0 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.5707963267948912,0 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.570796326794893,0 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-1.570796326794894,-1.0 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-1.5707963267948966,-0.025701353811708683 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-1.5707963267948966,0.17828565789045003 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-1.5707963267948966,-0.8313355142837152 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-1.5707963267948966,0.8519640463628934 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-1.5707963267948966,-0.9992672274148263 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-1.5707963267948966,0.9999999999999978 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-1.5707963267948966,-1.0000000000000038 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-1.5707963267948966,-1.000000000025385 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-1.5707963267948966,11.83448054864681 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-1.5707963267948966,-3.944304526105059E-31 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-1.5707963267948966,-5.036978980452069 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.570796326794897,0 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.5707963267949019,0 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark55(10.127263953341917,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark55(-1.0170138797546795,-1.5707963267948966,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark55(10.181004956593,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark55(10.216690135078455,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark55(10.266693365313495,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark55(1.0291729761071409,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark55(10.361512501399494,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark55(10.4308251458747,-1.570796326794897,0 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark55(10.467503137417106,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark55(1.049534893795594E-7,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark55(-10.629676364283384,-46.61730020076915,-42.714550679387095 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark55(10.635975359306418,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark55(10.647474445076059,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark55(10.684524098197116,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark55(10.691260213294424,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark55(-10.833893061722065,-64.30006282332351,34.71093081715367 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark55(10.887030905105938,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark55(10.98682889613815,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark55(11.058021888000281,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark55(1.1113911276727506E-15,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark55(11.13703200685174,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark55(11.309815875526006,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark55(-11.430916135911843,65.84653959985712,-46.672281483056445 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark55(1.1440095659228806,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark55(11.467645484970461,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark55(11.632745557863222,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark55(11.72817371798499,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark55(11.822382211994181,31.696225137470776,-10.280310322301233 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark55(11.86761631604682,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark55(11.875485128951807,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark55(-11.930505167424883,-1.5707963267948966,-33.512651378125405 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark55(-11.97092525356641,-1.5707963267948983,-0.14215432139744877 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark55(12.120507156824148,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark55(12.160091918923001,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark55(-12.162893184137559,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark55(12.251539486246589,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark55(12.262537287752837,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark55(12.279607494691305,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark55(12.344172893499854,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark55(12.351058148461872,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark55(12.354703439279362,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark55(12.429933037165014,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark55(12.446349579315367,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark55(-1.24E-322,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark55(1.256808385299287,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark55(12.584149799210849,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark55(12.71356127303706,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark55(12.720078840883946,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark55(12.88034557997777,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark55(12.924772211987516,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark55(13.026009310954166,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark55(13.167234711557185,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark55(13.177425116515137,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark55(13.25062092291222,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark55(-13.533094220178123,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark55(13.534417420191549,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark55(13.574591662834662,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark55(13.627960529705163,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark55(13.638831491556232,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark55(13.775665466835676,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark55(13.870936919262753,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark55(13.938902293007942,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark55(13.942727916537649,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark55(1.3997712955717851,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark55(14.002170288011445,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark55(14.047963892192357,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark55(14.112938233502575,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark55(14.150743788768708,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark55(14.186036847093908,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark55(-1.4210854715202004E-14,-1.5707963267948963,-89.0224581040594 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark55(14.221562942953081,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark55(-14.221768336951257,-1.5707963267948966,-7.211590713085258 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark55(14.247178602675504,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark55(14.26412362685872,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark55(14.29213463666136,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark55(14.292301405481055,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark55(14.350327717221083,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark55(14.404419714097092,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark55(14.442568343719925,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark55(14.466404330283808,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark55(14.494576906566937,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark55(14.550130873520182,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark55(14.776420065935355,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark55(14.889902017744413,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark55(1.493349357895999,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark55(15.162392418373104,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark55(15.195167981798676,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark55(15.252110337699328,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark55(15.384699343075185,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark55(-15.468237542496722,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark55(15.51538284979262,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark55(15.543916127327122,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark55(-15.571181926367258,-1.5707963267948966,23.980945497566882 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark55(15.579277445547714,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark55(15.679134219441353,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark55(15.79514091675429,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark55(15.795163702948315,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark55(15.805302835001697,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark55(15.893749142056194,-1.5707963267949019,0 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark55(15.93075411439704,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark55(15.949462817999727,-1.570796326794897,0 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark55(16.019775801960904,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark55(16.127326268394377,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark55(16.16116286664777,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark55(16.245516559825617,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark55(16.248517670731673,-76.56851876814908,-78.16215333230343 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark55(16.27353108654058,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark55(16.299665509817046,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark55(16.366910187219233,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark55(16.385340312116114,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark55(16.395157288899583,34.72711855503846,78.63968690945126 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark55(16.49739384709519,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark55(1.6524767522969608E-25,-1.5707963267948966,1.0000000000187423 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark55(16.561536469369223,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark55(1.6584006754256962E-21,-1.5707963267948966,-4.5889838868082305E-22 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark55(-16.684035324382933,-1.5707963267948966,0.8860939399664725 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark55(16.838544751411806,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark55(16.839162581199695,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark55(16.869639924302177,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark55(16.89000949921973,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark55(16.992219060407248,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark55(17.11402350924588,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark55(17.152507966345325,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark55(17.171260576074605,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark55(17.2348316748231,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark55(17.240376117414083,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark55(17.242337736546364,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark55(17.318376150128884,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark55(17.346397612423637,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark55(17.362172589278813,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark55(17.466986920676476,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark55(17.498868228687837,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark55(17.50012078574892,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark55(17.524294527488525,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark55(17.52775487425461,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark55(-17.55247260722107,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark55(-1.75762752005337,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark55(17.638515992913995,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark55(17.650304406817256,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark55(17.699288399868898,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark55(17.743163622372858,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark55(1.7743237714996312,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark55(17.753479805149166,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark55(1.7763568394002505E-15,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark55(1.7773056420942623,-1.5707963267948912,0 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark55(17.812703343054928,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark55(17.821652344725784,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark55(17.868865822689248,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark55(17.888011244230277,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark55(17.89577079126824,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark55(-17.932046663368222,-1.5707963267948966,0.5420275588685163 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark55(-1.7985674179167296E-26,-1.5707963267948966,0.3705936870109331 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark55(-17.999087073868726,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark55(18.083018562494274,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark55(18.12657227167857,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark55(18.16967548195621,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark55(18.185256421170592,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark55(-18.284533287664814,-94.64317108893205,48.98566151497934 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark55(18.32885780773725,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark55(18.34420079519797,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark55(18.357947393776186,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark55(18.440470715486484,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark55(18.464024847529586,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark55(18.46915659886882,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark55(1.8523582047104803,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark55(18.525714209050076,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark55(1.8534981793622798,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark55(18.55285299386574,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark55(18.573318153264907,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark55(18.643711807573826,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark55(18.7524504571113,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark55(18.760271842179574,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark55(18.76662719117772,-1.5707963267948895,0 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark55(19.04156745889558,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark55(1.910370534204091,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark55(19.23838883722835,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark55(19.34503236282943,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark55(19.367690357654958,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark55(19.370728012319518,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark55(19.47947209403266,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark55(19.49988818649817,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark55(1.9521677040978567,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark55(19.57481849655069,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark55(19.618615502381296,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark55(19.743193096878073,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark55(19.778223526410226,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark55(19.957517120449584,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark55(19.9596704265292,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark55(2.0008316476663994,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark55(20.08936907486754,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark55(-20.19467154985715,-1.5707963267948966,72.52963368260538 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark55(20.198314141953063,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark55(20.205308173267355,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark55(20.208486961938625,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark55(-20.242325306627524,-1.5707963267948966,-0.06255255643678437 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark55(20.25111197570411,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark55(20.27555965321204,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark55(20.297270645479955,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark55(2.0474944376801396,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark55(20.51890258739195,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark55(20.527458492067385,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark55(20.54732687485692,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark55(20.565126391251667,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark55(20.570306288989855,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark55(20.680042113101464,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark55(20.683597939377023,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark55(20.725768340979617,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark55(20.873915256332538,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark55(-20.91581877278774,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark55(20.940061657701133,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark55(20.974765197230653,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark55(-20.999760928241383,-1.5707963267948966,-69.87034539418417 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark55(21.021636694505293,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark55(21.061682090920897,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark55(-21.16694600841013,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark55(-2.1175823681357508E-22,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark55(21.342418495902237,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark55(21.349757570475894,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark55(21.398409587396216,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark55(2.1455716245848997,-1.5707963267949019,0 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark55(21.481617700487547,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark55(21.59020331109308,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark55(21.760593859451028,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark55(21.861703257392527,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark55(21.876964885313527,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark55(21.890687051423456,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark55(21.949417030481214,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark55(21.950510419598473,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark55(21.959841174509705,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark55(-21.992165993065086,-1.5707963267948966,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark55(22.010930801775785,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark55(22.075225053158835,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark55(22.154027334139187,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark55(22.20330864154694,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark55(2.220446049250313E-16,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark55(22.21962697736315,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark55(22.340873928725898,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark55(22.413992653647725,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark55(22.591453895370933,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark55(22.632115990754343,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark55(22.635130450121746,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark55(2.273699085146522,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark55(22.791416327538585,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark55(22.79613027388416,61.11460993312258,-15.179342959197157 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark55(2.2883557340649584E-246,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark55(-22.954710393919335,-1.5707963267948966,0.7566128210409698 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark55(23.063773873754972,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark55(23.111342617761267,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark55(23.23845736616568,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark55(23.27112477398059,-1.570796326794894,0 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark55(-23.3397715067686,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark55(23.386457860269985,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark55(23.40166488402808,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark55(23.44301421135861,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark55(2.350975747474166,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark55(23.51046856167578,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark55(23.572294652356234,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark55(23.622210243645725,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark55(23.705915577079367,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark55(23.707902432010357,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark55(-23.80781241123728,79.66560850584139,77.05793574744973 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark55(2.387163830568454,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark55(23.903465650903485,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark55(24.087575237327314,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark55(24.17183943144437,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark55(24.18263336872647,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark55(24.20524003832054,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark55(24.284181371487378,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark55(24.313677605313405,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark55(24.314197362080463,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark55(24.31669913943994,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark55(2.434696908799509,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark55(24.39051405182122,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark55(24.401551603596843,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark55(24.424234341219204,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark55(-24.4270718049835,-1.5707963267948983,-0.16980920406412958 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark55(24.50251546360502,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark55(24.510991770707328,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark55(24.51940890787515,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark55(24.525133131434156,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark55(24.58447001490803,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark55(-2.469220317227972,-1.5707963267948966,0.005758492501151166 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark55(2.4705058634875408,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark55(24.744174462799933,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark55(24.760480745752666,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark55(24.804819203966574,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark55(24.826035793719143,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark55(24.870971256324797,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark55(-24.915174488933935,-1.5707963267948966,1.0000000001711054 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark55(24.931420379496334,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark55(25.15423589875941,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark55(25.186756328664693,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark55(25.25392238606148,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark55(25.336283473917582,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark55(25.338078241680307,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark55(25.390293498633167,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark55(25.504412705478387,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark55(25.505425334281114,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark55(25.52349481493742,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark55(25.547385714335764,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark55(25.582583385228943,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark55(25.63976408625348,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark55(-25.66000786215528,-1.5707963267948966,-1.7927943246914975 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark55(25.768201107765815,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark55(25.781207661847986,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark55(25.809388729295343,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark55(25.98942427751942,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark55(25.997889911619225,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark55(2.5E-323,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark55(-2.6015655105408966E-14,-1.5707963267948966,0.062552525398805 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark55(26.023242177254517,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark55(2.615550682596462,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark55(2.6177873583826283,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark55(26.181464419544056,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark55(26.1886304294425,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark55(26.191685925531385,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark55(26.36160622563996,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark55(26.46365422179315,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark55(2.649744574333404,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark55(26.553809064296473,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark55(-2.6593925908382845,-1.5707963267948966,-1.2108013117930694 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark55(26.71269844585491,-1.5707963267948912,0 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark55(26.85309114476224,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark55(-26.860421240996768,-1.5707963267948983,2362.7739573327017 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark55(26.887237396162163,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark55(27.020599786836055,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark55(-27.06437924564374,-1.5707963267948966,47.331370285644084 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark55(27.075655978702635,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark55(27.11264789176963,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark55(2.7220625156720644,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark55(27.341304620990996,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark55(27.463967377667583,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark55(27.47277998221709,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark55(27.659202640714415,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark55(27.695850829521767,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark55(27.837824741955643,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark55(27.864662839499665,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark55(28.08359396602658,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark55(28.175084248465726,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark55(28.240955794250624,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark55(28.24205687698432,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark55(28.311520526474148,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark55(2.8319522467995313,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark55(28.333843506861456,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark55(28.40536340535871,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark55(28.45251648045472,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark55(28.544169267718193,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark55(-28.591923793942676,-1.5707963267948966,0.41491469790028535 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark55(2.8882162122017725,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark55(28.902051329406163,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark55(29.01536905833612,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark55(2.903412627853477,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark55(29.049117517408433,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark55(29.096408970951444,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark55(29.115951028404215,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark55(29.214766742797934,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark55(29.269782684941912,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark55(29.388959073711668,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark55(29.40337614780196,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark55(29.433832797681646,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark55(2.943544263894295,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark55(29.461746020034056,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark55(29.573353236864843,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark55(29.60098188112168,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark55(2.9628346918041757,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark55(29.732213200052048,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark55(29.824174526035385,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark55(29.83884006206604,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark55(2.9855925469289954,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark55(2.9864973001322284,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark55(30.040797876157896,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark55(30.086783399131036,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark55(30.14251690663474,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark55(30.245524523737377,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark55(3.035465443015511,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark55(3.0395559108008996,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark55(3.0417710400680087,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark55(-30.49869152347378,-1.5707963267948966,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark55(30.559592429812493,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark55(30.633902217766604,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark55(30.679379158913406,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark55(-30.77233974072884,-1.5707963267948966,-10.87352071757033 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark55(-30.812787214334858,-1.5707963267948966,0.029252580581488732 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark55(30.867390885515267,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark55(30.89349207001078,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark55(-30.934289432176516,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark55(30.942074418477688,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark55(31.13511543844413,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark55(31.158389016293327,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark55(31.159696581981123,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark55(31.23632129732968,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark55(3.124036382460233,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark55(3.1323364003802348,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark55(3.135037015110001,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark55(31.4016821525289,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark55(31.463075306056506,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark55(31.536239162254976,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark55(31.586710740274903,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark55(31.609609494267545,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark55(31.619569704673854,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark55(31.63381606220244,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark55(31.654188275097,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark55(31.67885566994023,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark55(31.707439355760844,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark55(31.73271476961662,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark55(31.744600342715827,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark55(31.776590447006498,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark55(31.828370832730368,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark55(3.197989319840097E-15,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark55(32.25263624109266,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark55(32.253525818110205,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark55(-32.25406339906448,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark55(3.2324111620791154,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark55(3.24195753519519E-15,-1.5707963267948966,0.13855951610536565 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark55(3.247605156445708,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark55(32.51658615944851,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark55(3.256524023746463,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark55(-32.58883848244007,-1.5707963267948966,-0.005271598122956356 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark55(32.595010594088805,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark55(32.61255380536136,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark55(32.68504442661697,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark55(32.69069480224545,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark55(32.90120994853893,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark55(3.3028452783720326,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark55(33.24566356026665,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark55(33.27865719343458,-1.5707963267949019,0 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark55(33.29658401304445,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark55(33.41288775926662,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark55(33.42180284096407,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark55(33.423256691711146,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark55(33.43005332508016,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark55(33.48444260114695,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark55(33.61682587587582,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark55(33.622317438180836,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark55(33.78915324458114,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark55(33.7895653640949,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark55(34.09378061349392,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark55(34.14959277252841,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark55(3.4275332806042176,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark55(34.30009473021356,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark55(34.3302479847072,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark55(34.401549230635695,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark55(34.44357973013819,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark55(-34.50089470635076,-1.5707963267948957,-1.0 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark55(3.4508478066981496,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark55(34.531623640041204,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark55(34.559974110274965,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark55(34.75261395550524,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark55(34.79035073465531,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark55(34.816970374623786,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark55(-34.83100504614778,-1.5707963267948966,89.44952981101278 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark55(34.85521573795103,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark55(34.872017848724994,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark55(35.032681714656164,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark55(35.16582373094931,-1.570796326794897,0 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark55(-35.26700326416004,-1.5707963267948966,4.440892098500626E-16 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark55(35.35223424452485,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark55(35.35578627446455,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark55(35.36852917063388,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark55(35.47296902292783,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark55(-35.485333318998016,-1.5707963267948983,0.047420392738539645 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark55(35.505471615643586,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark55(3.552713678800501E-15,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark55(35.63872991964817,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark55(35.7033252314057,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark55(35.739431953371565,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark55(35.81388384763226,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark55(35.81791605441225,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark55(35.82651076457112,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark55(3.591895278957077,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark55(36.050696956464805,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark55(36.13127478752771,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark55(36.142336415611354,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark55(36.19592113705118,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark55(36.28090089446787,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark55(36.38812280049906,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark55(36.39417519942273,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark55(36.39513137486927,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark55(36.433346078681915,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark55(3.667064265000576,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark55(36.69642216950702,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark55(36.770023870851674,-1.570796326794897,0 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark55(36.82925608724667,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark55(36.87759509333033,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark55(36.94375914261935,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark55(36.95294513977479,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark55(36.96600629717662,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark55(36.98652084848405,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark55(36.992757785301364,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark55(37.23149442342374,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark55(37.235652925162555,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark55(37.2857534562709,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark55(37.35453376291167,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark55(-3.7356415574753953E-22,-1.5707963267948966,-5.421010862427522E-20 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark55(3.748273168435844,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark55(37.484365913834694,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark55(-37.52033082646564,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark55(37.593045059413626,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark55(37.614917509983314,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark55(-37.61900866611093,-1.5707963267948966,1.0000000000912177 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark55(37.69211943829043,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark55(37.69423761123048,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark55(37.797520907313135,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark55(37.80940053885897,90.48970111009746,51.8903367560456 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark55(-37.88718237330786,22.092704754162696,53.58855681800111 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark55(37.925632853653816,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark55(38.05720596347271,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark55(-38.100799209057726,-1.5707963267948966,46.34079359478952 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark55(38.10887260081954,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark55(38.111103423013205,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark55(38.125309877988286,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark55(38.182526783666276,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark55(38.267466958859075,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark55(38.30178737696818,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark55(38.381155706488684,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark55(38.424666328490176,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark55(38.59262999750891,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark55(38.70516892034516,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark55(38.84670950447363,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark55(39.010947978647806,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark55(39.039824836185545,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark55(39.04377599104989,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark55(39.081045249474215,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark55(39.1210432478824,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark55(3.9272605843714103,-28.385178984845382,8.525227239942694 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark55(39.3513977522954,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark55(39.36576591813877,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark55(39.43809294402814,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark55(39.47462961418932,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark55(39.51443126641621,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark55(39.55118683828559,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark55(-39.5745223190511,-69.84650704519348,-26.603563232990595 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark55(39.58076238418838,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark55(39.586904094622255,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark55(39.60373499941505,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark55(-39.74695718872318,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark55(39.87226563972163,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark55(3.989776128774409,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark55(39.90873069662916,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark55(39.91416471831526,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark55(40.02078556235156,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark55(40.11540859620618,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark55(40.120122929989776,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark55(40.13457434050616,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark55(40.257102166502996,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark55(4.029225390331263,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark55(40.33667550757755,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark55(40.432091680056914,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark55(-40.60559859480182,-1.5707963267948966,0.8370314849470347 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark55(40.79638201437802,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark55(40.79861850797026,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark55(40.88610108038466,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark55(40.88806735238407,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark55(40.93435097889383,-1.5707963267949019,0 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark55(40.945649954358174,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark55(41.05711661120308,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark55(4.108221344507583,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark55(41.33331967334991,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark55(41.40445670732683,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark55(-4.1427996048483,-1.5707963267948966,-43.070173489044606 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark55(41.43116649311663,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark55(41.470904615423116,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark55(41.52686937583412,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark55(-41.54539099435883,-70.67507615869593,48.33618022967886 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark55(41.564417806176564,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark55(-41.57243207277075,-1.5707963267948966,0.3749430009589203 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark55(4.157475220429089,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark55(4.1601789700230825,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark55(41.624426362900465,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark55(41.70817199708701,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark55(41.73012472936364,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark55(41.76959032125538,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark55(41.85188479333619,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark55(41.9941269156854,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark55(4.205613895739731,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark55(4.213260692876089,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark55(42.16020536782124,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark55(42.23351964413998,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark55(42.28403431724891,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark55(4.2395530333267715,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark55(42.431259920473366,40.522998318086536,-74.58072620506434 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark55(42.51861206026705,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark55(42.537766715257675,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark55(42.59167889129272,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark55(42.671938647592995,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark55(42.715291383672835,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark55(42.7196559758504,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark55(42.812088603067934,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark55(42.818959052201706,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark55(43.01800184052016,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark55(43.12292861576731,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark55(43.130617529706456,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark55(43.16806644024339,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark55(43.23350024362695,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark55(43.23834078571704,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark55(4.32560825644375,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark55(43.31113553152514,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark55(43.39044920048883,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark55(43.406557648585476,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark55(-43.41163189639738,-1.5707963267948983,-2508.289905778839 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark55(43.41411051291623,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark55(43.42910783559598,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark55(4.349964620893953,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark55(43.508585349990554,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark55(43.513959121117296,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark55(43.536025000085786,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark55(4.3666579092594136,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark55(4.368582379078873,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark55(4.3809314097751155,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark55(44.162804638957724,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark55(4.428143850723927,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark55(-44.3330277884442,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark55(44.442994901901386,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark55(4.452220818189848,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark55(44.53168769201829,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark55(4.45848525107923,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark55(44.67791680232475,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark55(44.71624485165742,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark55(44.7418676770268,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark55(44.845949093760076,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark55(45.01796843302639,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark55(45.1137647175149,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark55(-45.16582237212596,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark55(45.19325916878131,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark55(-45.19625485988225,-1.5707963267948966,-0.9833713818110299 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark55(45.30406744086442,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark55(45.51582105209092,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark55(-45.572840417853826,-1.5707963267948981,-0.9999999999999991 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark55(45.59643628124432,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark55(45.64531970655923,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark55(-45.64927952687896,-1.5707963267948983,0.05851183348928727 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark55(45.6704320983238,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark55(45.76437352080751,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark55(45.77735706917153,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark55(45.787920859291695,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark55(45.80404977607197,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark55(45.811604166740025,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark55(45.869001030241876,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark55(45.879231173681546,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark55(45.91912728940329,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark55(45.96045180898522,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark55(46.01577700126646,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark55(4.639966332718756,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark55(46.45163396819053,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark55(46.513382916569135,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark55(4.658357184425483,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark55(-46.61975027744436,-4.31621507470534,0 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark55(-46.674398816120515,-1.5707963267948966,-57.26978399797599 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark55(46.69047094071618,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark55(46.72146735339726,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark55(4.675349717120298,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark55(46.77009300311956,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark55(46.892567989516294,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark55(46.92325843717967,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark55(46.93157394098234,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark55(47.013992259497314,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark55(47.155386402369714,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark55(47.42392435952973,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark55(-4.743781552221985,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark55(47.439335367994374,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark55(47.45035069891591,-1.5707963267949,0 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark55(-47.4650357102236,-1.5707963267948966,0.30338196691678654 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark55(47.543005015697645,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark55(47.553341373977325,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark55(47.64806660431616,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark55(47.671184349414645,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark55(-47.69273115237807,-1.5707963267948966,73.36555032375422 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark55(47.77212916723945,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark55(4.777381882673818,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark55(47.78061928423651,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark55(-47.88847590734361,-1.5707963267948966,1.056938160058688 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark55(48.0175092011912,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark55(48.11662839738017,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark55(48.13111337580685,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark55(-48.14936353491595,-84.31378805516532,-37.469832697349844 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark55(48.15599398609753,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark55(48.25803983218191,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark55(48.30470281329525,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark55(48.58122132741141,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark55(48.644616472404834,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark55(48.75278371681895,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark55(48.906290739869604,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark55(48.9613774278221,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark55(49.037366450957855,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark55(49.107800256498535,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark55(49.13172691866384,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark55(4.91507325346859,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark55(49.15990713561168,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark55(49.16854616094645,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark55(4.921689138717085,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark55(49.25012174648924,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark55(49.315442337326346,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark55(-49.32143202714736,-1.5707963267948966,2499.1555197722296 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark55(-49.324620875362854,-1.5707963267948966,51.270146277924646 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark55(49.45550922775797,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark55(49.4782638629932,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark55(49.535196492282296,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark55(-49.77794041685225,-1.5707963267948974,-6.265090060143944 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark55(-4.980119362126175,-1.5707963267948966,-59.70083200695324 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark55(4.983391823103005,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark55(49.9608602209533,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark55(-50.00785532058743,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark55(50.12860036969754,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark55(50.15590925143778,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark55(50.16088194409532,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark55(50.25052373106587,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark55(50.25218647123077,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark55(50.32583689831475,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark55(50.33915302381931,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark55(50.344523562991206,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark55(50.37103678359448,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark55(50.402215970085166,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark55(50.52036267944781,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark55(50.54618044338267,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark55(50.57959024746033,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark55(50.74744398733921,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark55(50.893869187038796,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark55(51.22343593160085,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark55(51.2308041047079,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark55(51.34601077269955,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark55(51.39182816646149,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark55(-51.41354577131509,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark55(-51.50262411433158,-1.5707963267948966,-0.9999999999999991 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark55(-51.55904194679195,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark55(51.616533887258655,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark55(51.62147848095647,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark55(51.65861081738433,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark55(5.190769981753519,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark55(52.06899129125479,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark55(52.076049109687276,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark55(52.128980494021505,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark55(52.20939703589311,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark55(5.224341581684683,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark55(5.228253877309427,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark55(52.327060752346284,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark55(52.362911071314734,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark55(52.46784628946739,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark55(52.52948557203055,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark55(52.55725568051394,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark55(52.58074499743435,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark55(52.5860391152548,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark55(52.592830918930325,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark55(52.78589554863743,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark55(52.86156006487818,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark55(-52.93358917568555,-1.5707963267948866,0.9999999999999996 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark55(52.99534324850259,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark55(52.9988405995147,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark55(5.308811185458672,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark55(53.15615943042797,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark55(-5.319513144541534,-1.5707963267948966,-10.034154223807786 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark55(53.199363835604466,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark55(53.394019841435295,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark55(5.33978399312962,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark55(53.43962867821629,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark55(53.60691064429543,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark55(53.631890542843,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark55(53.73094188093619,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark55(5.375936438485022E-24,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark55(53.773685738001205,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark55(53.79614997942799,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark55(53.85535371013922,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark55(53.945447588006836,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark55(54.18943074401892,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark55(54.381124675640564,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark55(54.57966847255625,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark55(54.60237614876354,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark55(-54.685441278340605,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark55(54.71613107572966,-1.570796326794897,0 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark55(54.76083495748629,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark55(54.78829652135939,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark55(54.795359665801755,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark55(-5.483355404210103,-1.5707963267948966,0.5216007605344746 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark55(54.8388666634732,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark55(54.877069846594566,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark55(54.9445777976151,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark55(55.17296993060388,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark55(55.23679607138024,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark55(-55.24570128748793,-1.5707963267948966,-0.9649572532790045 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark55(55.27399718855105,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark55(55.41399152313758,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark55(-5.551115123125783E-17,-1.5707963267948968,39.31580018340214 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark55(55.51829314702328,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark55(55.55989613200583,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark55(55.57554760533523,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark55(55.62147554083065,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark55(55.670745231637405,-1.570796326794897,0 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark55(55.72541960833688,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark55(55.783482838838545,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark55(55.783631046703164,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark55(55.792004219361246,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark55(55.927102119621765,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark55(55.96234252241703,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark55(56.05683700708384,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark55(56.142616826933846,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark55(56.22115697650878,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark55(56.24623970085014,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark55(56.34639201906512,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark55(56.5015891528433,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark55(5.657331952888649E-16,-1.5707963267948966,-0.9999999999999991 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark55(56.652400246794315,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark55(-56.86122844376306,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark55(56.861304304995116,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark55(56.89948525510935,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark55(56.91679902501212,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark55(56.9221524688442,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark55(5.699925909189346,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark55(-57.04232051034551,-1.5707963267948966,0.8545430305999111 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark55(57.13883091309544,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark55(57.199932376877356,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark55(57.220271542438944,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark55(-57.266133805535674,-1.5707963267948966,-42.66581239703811 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark55(57.29126829604019,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark55(57.299875859412836,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark55(57.352597160626914,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark55(57.377465563928666,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark55(57.42122534681473,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark55(57.433003287428804,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark55(57.46703418283075,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark55(57.47912476679821,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark55(57.61565709352489,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark55(57.66435333820756,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark55(57.690939844366135,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark55(57.914582194221424,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark55(58.024462786766044,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark55(58.03440315241201,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark55(58.07010727923614,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark55(5.810926748552433,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark55(58.203132356994246,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark55(58.34305982765989,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark55(58.38298983343632,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark55(58.42833737425966,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark55(58.435336861062964,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark55(-58.47244133170929,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark55(58.530407071186524,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark55(58.62440730338058,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark55(5.863626381786702,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark55(58.67299344581591,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark55(58.688564009107694,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark55(58.73927793426336,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark55(58.80833924924264,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark55(-5.890449293195992,-1.5707963267948966,45.605170946651924 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark55(59.0991179763615,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark55(5.91016932451897,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark55(59.19005146642199,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark55(59.23226068442373,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark55(59.25669631722273,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark55(59.267177555421966,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark55(59.40433768749563,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark55(59.47589800231236,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark55(-59.49671472065933,-1.5707963267948966,-48.144863200465586 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark55(59.502684699334054,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark55(59.56117395130985,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark55(59.56323932430604,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark55(59.57642282867591,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark55(59.60619150516038,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark55(5.966579224947083,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark55(59.72496581543319,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark55(59.81633292434363,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark55(-59.840889795115224,-1.5707963267948957,-1.0 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark55(59.941966616101325,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark55(-59.944654307210946,-1.5707963267948966,5.503284107318959E-135 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark55(59.95657528722314,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark55(6.006131879422963,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark55(60.067646448110196,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark55(6.007177921458734,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark55(-6.012928872371987,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark55(60.137207736915705,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark55(60.141485539417715,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark55(60.17809528855571,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark55(60.34481827144202,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark55(60.35169820368168,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark55(60.381447205710685,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark55(60.43336678588119,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark55(60.514791389487925,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark55(60.54871220925664,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark55(60.653231800537355,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark55(60.80302044258498,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark55(-60.95186421093407,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark55(60.97364620987715,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark55(61.001145306244496,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark55(61.17708157219338,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark55(6.120641030323557,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark55(61.27781771786863,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark55(61.43461500375531,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark55(61.566729538662344,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark55(61.70041671014325,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark55(61.70296867190718,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark55(61.70309113324322,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark55(61.70638024500078,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark55(61.758863888652215,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark55(61.80625643812746,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark55(61.890602286561176,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark55(61.93243371943342,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark55(62.25990716956599,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark55(62.34123453022062,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark55(62.38127103214609,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark55(62.39572711640677,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark55(62.5084642412179,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark55(62.51864754196089,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark55(62.52019015145086,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark55(62.542317621084756,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark55(62.54235275277321,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark55(62.68702714040367,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark55(-62.69840920762332,-1.5707963267948966,0.05821142444903303 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark55(62.706736340337926,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark55(62.727744427701694,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark55(62.82931775620176,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark55(-62.88115864830846,-1.5707963267948966,-0.0100590429801517 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark55(62.936001645032974,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark55(62.98822307107647,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark55(63.01960781320226,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark55(6.305881748838942,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark55(6.307477811856282,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark55(63.07844090494423,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark55(63.0814856109309,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark55(63.08166898564172,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark55(63.230793592645206,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark55(63.30052865986153,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark55(63.32015433805875,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark55(-63.44711310318273,-1.5707963267948961,1.0 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark55(-6.352321590005505,-1.5707963267948966,-0.3184079951349614 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark55(63.598256034972636,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark55(63.64657371646158,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark55(6.3658944632454535,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark55(63.706885854172164,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark55(63.72696466947899,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark55(63.751225528740136,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark55(63.78256450783603,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark55(63.81309243524612,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark55(63.8740467965701,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark55(64.14760717493418,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark55(6.420655771695721,-1.5707963267948912,0 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark55(64.35486237181195,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark55(64.41799674261162,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark55(-64.45798439085172,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark55(64.50535632187628,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark55(64.5306868708777,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark55(64.67571962838998,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark55(-64.83152120870105,-1.5707963267948983,-2513.7789245177637 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark55(-64.84858016067032,-1.5707963267948966,-64.1162532817727 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark55(64.87246803306856,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark55(65.01770460307856,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark55(65.03326691289844,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark55(-6.503647539466525E-26,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark55(65.09509912478265,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark55(-65.12236169684809,-1.5707963267948966,0.05864504574648666 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark55(6.518939948014662,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark55(65.26997836815121,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark55(65.33257698552117,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark55(65.34315222525046,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark55(65.35611380707492,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark55(65.37297801227643,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark55(65.42763020564726,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark55(65.50714318311911,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark55(65.57031607919923,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark55(65.60470708138095,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark55(65.6443255172345,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark55(65.719482432264,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark55(65.73491798086293,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark55(65.83965357445395,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark55(65.85386245888253,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark55(65.89425301735588,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark55(65.95526891724128,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark55(-66.02102566206521,-1.5707963267948966,-0.22291691519881784 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark55(66.02587413185762,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark55(-66.0910080295557,-1.5707963267948966,7.888609052210118E-31 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark55(66.10137723176959,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark55(66.22102949436584,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark55(-6.622979456730059,-1.5707963267948966,-2.558940730362186E-28 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark55(66.28017047682675,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark55(6.629005974923615,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark55(66.39055609223783,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark55(66.41785130324469,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark55(66.46813612719001,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark55(66.52255915365886,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark55(66.62347877578163,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark55(66.64505107326195,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark55(66.69787179452891,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark55(66.72866621092021,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark55(66.77121660835519,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark55(6.6808437825216345,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark55(66.87786967652252,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark55(66.94455355570626,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark55(66.96295501433046,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark55(-67.17675534007033,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark55(67.22955422971796,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark55(67.32143845842032,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark55(67.32737326676664,-1.5707963267949019,0 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark55(67.40435499476672,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark55(-67.53541923951171,-1.5707963267948966,0.06477608792544037 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark55(67.57901799805083,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark55(67.6873620823642,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark55(67.7467840674436,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark55(67.77679390956952,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark55(67.87642528877868,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark55(67.96808739271648,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark55(67.9931387339063,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark55(68.00478669858906,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark55(-68.15838159988736,-1.5707963267948966,11.027018521645388 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark55(68.18502380852827,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark55(68.3015454680916,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark55(68.32775068816875,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark55(6.834475673630386,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark55(68.44925854351746,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark55(68.56245721305436,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark55(68.59151630300457,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark55(68.5991438610467,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark55(68.62138938928865,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark55(68.68178834653476,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark55(68.68365587077963,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark55(68.7113302657411,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark55(68.76159583689024,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark55(68.85187721301513,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark55(-68.92507146382938,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark55(69.02029680000263,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark55(69.04895732159,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark55(69.08705546600657,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark55(69.11187534939987,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark55(69.13138782618506,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark55(-69.1718019254277,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark55(-69.18023084965101,-1.5707963267948974,-1.0 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark55(6.928004925554561,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark55(69.45861526066898,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark55(6.94818516992099,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark55(6.955884970305036,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark55(69.5622879158609,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark55(69.59557596599595,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark55(69.6773896131167,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark55(69.70917060493139,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark55(6.977797938793808,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark55(69.83790952208372,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark55(69.85990427261743,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark55(-69.86632693261708,-1.5707963267948966,33.82096039335296 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark55(69.94218473106976,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark55(69.99656139032827,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark55(70.05033024661168,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark55(70.06941066779949,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark55(70.12189962593055,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark55(70.16214959090206,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark55(7.020470052708234,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark55(70.24838301271842,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark55(70.2810002321499,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark55(70.39505574115559,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark55(70.53400496762954,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark55(70.62020982500977,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark55(70.66048001367068,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark55(70.6770481527999,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark55(70.73385465827164,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark55(70.78158527017285,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark55(-7.09762850132132,-1.5707963267948966,-2.524181095922562E-5 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark55(70.98320581324401,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark55(71.09313827282585,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark55(-71.17847764920855,-1.5707963267948966,-0.7617776382690555 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark55(71.18842377151199,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark55(71.45593549003755,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark55(71.60324828515104,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark55(71.84651141176823,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark55(71.87028406301032,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark55(71.90257964204721,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark55(71.93287809843514,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark55(71.95142662875872,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark55(71.99928167912329,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark55(7.202495270439542,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark55(72.14938133840158,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark55(72.19439576961372,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark55(72.28114154435549,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark55(72.31828195709147,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark55(7.24445424519807E-20,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark55(72.5455740342653,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark55(72.6921363655022,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark55(72.72247132415839,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark55(72.77886741109768,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark55(72.84274226983204,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark55(72.8521400191876,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark55(72.87022670109226,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark55(73.02232270524425,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark55(73.07301459304881,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark55(-73.090663373748,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark55(73.35850520371184,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark55(73.35916478849893,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark55(73.42319591709003,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark55(73.45389133271735,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark55(73.58748441116799,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark55(73.59408204142355,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark55(-7.372359595751241E-17,-1.5707963267948966,1.0000000000014126 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark55(73.77103740229845,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark55(73.81633783850339,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark55(73.87814278898631,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark55(74.19260484318252,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark55(74.22464182099024,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark55(74.30623599641487,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark55(74.38035297272037,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark55(74.39040211794617,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark55(74.47803897731148,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark55(7.456569078055778,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark55(74.61443861304579,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark55(74.66183894229793,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark55(-74.67141415070766,15.724158643258534,0 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark55(74.73587321187262,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark55(74.80722321120228,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark55(74.94664216741577,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark55(74.99127616621882,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark55(74.99145847020783,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark55(75.01043780956326,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark55(75.05401995269406,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark55(75.0645855423665,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark55(75.10627836567102,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark55(75.16671679615246,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark55(7.533992355312481,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark55(75.37020408898296,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark55(-7.541428105465844,-1.5707963267948966,-0.9091377162328058 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark55(75.42440491596662,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark55(75.62886016708666,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark55(75.66098767281522,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark55(75.68397887074498,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark55(75.70032304948325,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark55(75.86549902421672,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark55(75.88118621748495,-1.570796326794897,0 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark55(75.92141368823039,-1.570796326794897,0 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark55(75.93049835741417,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark55(75.93694743735942,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark55(76.1811204749414,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark55(76.29474159230723,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark55(76.30009022314421,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark55(76.33363745608366,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark55(76.33767952589386,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark55(76.41083606703785,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark55(7.642050450874724,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark55(76.56272258039448,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark55(76.64164820291766,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark55(76.69830061941002,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark55(76.76241627355532,-1.5707963267948877,0 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark55(-76.86649537463627,-1.5707963267948966,78.0191522134634 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark55(77.02519461423663,-1.570796326794897,0 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark55(77.13816164698234,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark55(77.37349838088946,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark55(77.42041453660168,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark55(77.52766550433697,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark55(77.58056351080874,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark55(7.764559379152772,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark55(77.6575155528808,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark55(77.70040650757426,-1.570796326794893,0 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark55(77.7950942206048,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark55(7.785692058494568,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark55(7.79690556480044,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark55(78.08934631037232,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark55(78.1452890470554,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark55(7.856989308777074,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark55(78.68633978383781,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark55(78.80737302714527,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark55(7.8898454811892655,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark55(78.90655271178177,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark55(78.91373395352133,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark55(78.99776217919688,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark55(79.00093162256408,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark55(79.01859816120714,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark55(79.15748336672526,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark55(79.18554045745657,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark55(7.9186112892625005,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark55(-79.19179382921183,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark55(79.23085712470336,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark55(79.26428264638103,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark55(79.28976933232076,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark55(79.29431691811072,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark55(7.933979193073299,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark55(79.35549912175071,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark55(79.39582430860266,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark55(7.94050807391012,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark55(7.941422402592317,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark55(79.45428195623435,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark55(79.48300062718172,-1.5707963267948912,0 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark55(79.61334765911005,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark55(79.64297512936463,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark55(79.74124397273413,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark55(7.98622026731554,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark55(79.95508958978877,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark55(7.9E-323,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark55(-80.18924688252874,-1.5707963267948966,-0.7139430136030862 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark55(80.22522807330407,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark55(80.26301887225942,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark55(80.33106769933468,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark55(80.34532005027837,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark55(80.41698837327871,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark55(80.44721634648025,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark55(80.48395368471219,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark55(80.49115911788783,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark55(80.50539267482019,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark55(80.64160177778501,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark55(80.6488750277948,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark55(-80.87642957059364,-1.5707963267948966,-55.7795554069005 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark55(80.8859666149011,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark55(80.88734193945426,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark55(80.92768096253883,-1.5707963267949019,0 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark55(81.00934228385572,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark55(81.0975372045367,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark55(-81.3488377617091,-1.570796326794897,0.35932982212205616 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark55(8.135885960685712,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark55(-81.46938526827606,-1.5707963267948966,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark55(-81.5354372380221,-1.5707963267948966,-0.2931883157995747 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark55(81.56925880852573,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark55(81.57660549182398,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark55(81.62423647718998,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark55(81.72405260495267,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark55(81.72657510852734,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark55(81.74276921440314,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark55(81.74567406691881,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark55(81.89887119391699,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark55(81.91288584963245,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark55(81.95373656266,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark55(82.00468133774439,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark55(82.092908459575,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark55(8.210023995282963,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark55(82.16578193750433,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark55(82.25984278384465,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark55(82.30495602201904,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark55(82.32216276864591,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark55(82.33963164745865,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark55(-82.34077061623313,-1.5707963267948983,-84.59956639306569 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark55(82.3561752529448,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark55(82.40970893911248,27.264755004609725,-98.15219659858343 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark55(82.50617391842451,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark55(82.54068964349554,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark55(82.61889639838051,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark55(82.75871767949162,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark55(82.92479225602284,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark55(8.292502568847732,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark55(83.07711277447325,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark55(83.15432999001641,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark55(83.26289998907896,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark55(83.29659407432867,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark55(83.29855569595136,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark55(83.31494928773527,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark55(83.32162315771657,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark55(83.63255805694064,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark55(83.64001268160351,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark55(83.7049699350661,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark55(-83.73193687878532,-1.5707963267948966,63.456672281088444 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark55(83.77414259680309,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark55(-83.82263681594802,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark55(8.449702339328635,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark55(84.58249381002804,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark55(84.69266071713892,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark55(84.8191149888882,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark55(85.15868407185334,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark55(85.19167261208872,-1.5707963267949054,0 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark55(85.23361281208606,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark55(8.52391843457869,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark55(85.29896780394049,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark55(85.30237641702323,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark55(85.38338425832191,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark55(85.59637802874943,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark55(85.65776817694034,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark55(85.65869756636184,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark55(85.66237399063598,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark55(85.82897686356537,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark55(85.85114680258957,-1.5707963267948988,0 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark55(85.86390600068518,-1.5707963267948912,0 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark55(-85.88010751891123,-1.5707963267948966,0.9999999999999999 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark55(8.592846824684614,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark55(86.01669815289358,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark55(86.06547501228661,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark55(86.10496719636023,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark55(-8.610719513005815,-1.5707963267948983,-0.7073000871352009 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark55(86.10889865200141,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark55(8.613557447781243,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark55(8.613620860577385,-1.570796326794897,0 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark55(-86.20141945282745,-1.5707963267948957,0.0 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark55(86.2663742334153,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark55(86.2712787603186,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark55(86.32402664015089,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark55(86.5491305566687,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark55(-86.8004170543087,-1.5707963267948966,88.19366756637733 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark55(86.83900517219982,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark55(86.86892348784059,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark55(86.8854568147242,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark55(86.94069353832208,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark55(-86.95332716428553,-1.5707963267948966,63.96596459820911 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark55(87.02059092824616,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark55(-87.11253586242566,-1.5707963267948966,45.406932425298294 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark55(87.1419917090205,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark55(87.28523922034051,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark55(8.736549203454771,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark55(87.38033200532115,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark55(87.46327654598511,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark55(87.49029141221251,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark55(87.59363177588102,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark55(87.63765778709109,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark55(87.65557570801201,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark55(87.71985658644462,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark55(87.82247682539882,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark55(8.785764315704448,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark55(88.02896058229489,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark55(88.0919945202736,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark55(88.09564960827383,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark55(88.17628044488967,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark55(88.29175227220901,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark55(88.3763907301559,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark55(88.40349862460943,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark55(-88.47711493938482,-1.5707963267948966,92.64475733666326 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark55(88.49965690036151,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark55(88.53403896450367,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark55(88.54204954851167,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark55(88.54422380551905,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark55(88.5738402002379,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark55(88.67046685777163,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark55(89.0077824867881,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark55(8.925082047733184,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark55(-89.53671346571407,-1.5707963267948966,-0.2804195845895583 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark55(89.6063221556737,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark55(89.72096199350489,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark55(89.77737410441435,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark55(8.98313872617654,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark55(90.00004370140161,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark55(-90.12146503022322,-1.5707963267948966,0.9999999999999991 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark55(90.20629228391664,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark55(9.02256550268396,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark55(90.48588805378799,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark55(90.49305353472836,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark55(90.59252307969389,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark55(90.6759645301382,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark55(90.8840016535945,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark55(90.88613002823725,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark55(91.00944148728496,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark55(-91.03631384098345,78.29800554481167,40.84203419484348 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark55(91.07195658658702,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark55(91.07544168650857,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark55(91.25879731514557,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark55(91.29016362754697,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark55(91.34531967049756,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark55(91.4612196844283,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark55(91.5171054611484,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark55(91.59595737815934,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark55(91.6569303531266,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark55(91.69117755019364,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark55(91.92421148076214,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark55(92.02434120304807,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark55(92.10549619869789,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark55(92.16874054011505,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark55(92.22394385879204,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark55(92.29448342836,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark55(92.34787758512982,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark55(92.35100986739604,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark55(92.42741684875077,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark55(92.47992232163966,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark55(92.51002990653748,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark55(92.56873634184771,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark55(92.64784861320746,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark55(92.65042193565131,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark55(92.69309773856918,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark55(92.74022336294598,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark55(92.7906226975841,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark55(92.9030977912743,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark55(9.290833040356745,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark55(9.309901897259424,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark55(93.1408700233364,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark55(9.32577527362595,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark55(93.267669760056,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark55(93.4597474623983,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark55(93.46712660531261,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark55(9.358956485978768,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark55(93.59563242785211,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark55(93.68873553303634,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark55(93.77539143451682,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark55(-9.382684106857345E-16,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark55(94.01838069742801,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark55(94.15470381402598,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark55(94.18850671019737,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark55(94.22354276271813,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark55(94.46035401338239,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark55(94.67581884579107,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark55(94.69638736961286,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark55(94.81811845686333,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark55(94.8605211377037,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark55(94.90874893796796,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark55(94.98410030995805,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark55(95.0243593839381,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark55(9.50881226363431,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark55(95.13920818382496,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark55(95.2188042023472,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark55(95.31336403435272,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark55(95.45260353088263,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark55(95.58721691381936,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark55(-95.64591177423281,-1.5707963267948966,-38.960322609174426 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark55(95.64844561123711,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark55(95.66931935400396,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark55(95.6696042936787,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark55(95.70908321982746,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark55(95.80243217608714,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark55(95.94558029262404,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark55(95.95608160996706,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark55(95.96102818432581,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark55(96.0522569256054,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark55(96.10041764880758,-1.570796326794897,0 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark55(96.10332662291589,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark55(96.16331019786983,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark55(96.18128065423176,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark55(-96.22134286098061,-1.5707963267948983,-1.0000000000000036 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark55(96.33863811529802,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark55(96.34735960290757,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark55(96.46532217751053,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark55(96.60838075114071,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark55(96.64621197785576,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark55(96.77644779092725,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark55(96.8499162019796,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark55(96.90249457725281,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark55(96.91937140088312,-1.5707963267949019,0 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark55(9.698910580589711,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark55(97.15206956022037,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark55(9.718161060903533,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark55(97.26498020529576,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark55(-97.5218839776561,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark55(97.67098595312567,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark55(9.770593219422209E-14,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark55(97.74356758003752,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark55(-97.82516716284545,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark55(9.783036483340041,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark55(97.96714939427162,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark55(98.1328410428893,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark55(98.33477536561622,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark55(98.34844490286815,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark55(98.37810891314953,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark55(-98.49959945328861,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark55(98.51336189119121,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark55(98.52814103710301,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark55(98.56303932747292,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark55(98.5913378269655,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark55(98.72042377549707,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark55(9.883291411610287,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark55(98.92592539957928,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark55(99.07676597792056,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark55(99.355254815297,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark55(-99.63559968707776,-1.5707963267948966,0.36208927207342 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark55(99.85845985698433,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark55(-99.89907001910021,-1.5707963267948966,-0.8843562980779467 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark55(-99.9224130316118,-1.5707963267948966,-0.016446651231235704 ) ;
  }
}
