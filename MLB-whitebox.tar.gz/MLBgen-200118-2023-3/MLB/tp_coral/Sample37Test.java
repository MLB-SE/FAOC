import org.junit.Test;

public class Sample37Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.003709365774081874 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.005838439020976693 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.014664566083490607 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.015097324178241056 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.0162516758309863 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.023535036351102434 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.02883191506180227 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.02942214738925486 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.037877162553339616 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.05682712269617163 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.06140597345775278 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.06308045430599662 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.06923624550043428 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.07294469650867619 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.08381743065444613 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.09233786560986346 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.10678282708027084 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.11899014133386832 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.12274671903084328 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.131903066885954 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.13322310491776213 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.1349416733752662 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.13620352380779366 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.1400204827567896 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.14284963103355608 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.16926605539386497 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.17447503098787864 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.18788573462272495 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.18967412010293572 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.19067353210988536 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.19109423853512952 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.194955815236721 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.20668895776809915 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.2146449947360929 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.2166608816841773 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.2209746664756116 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.22902336551113667 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.23014921719639858 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.23190666475049682 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.2354357328795731 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.2363137744379742 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.23678857755260907 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.25418320777788495 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.25819330542391317 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.2617786427717703 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.26457667542244234 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.27735072379046244 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.29112040190220334 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.2927609224256571 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.29504391326732526 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.2983103890530421 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.3226412899398152 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.3617459426821126 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.3617956274850229 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.3659008529360648 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.38339960194563716 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.38719612953872307 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.3882658309458691 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.3913345798783041 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.4104714155509299 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.4128014870389318 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.41593170747204766 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.41771601335855846 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.4211754252813291 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.433854853243389 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.4563806505093311 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.460906951764227 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.4671527749458543 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.4690824784271683 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.48448956824200884 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.48665704801511733 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5036615113476302 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5067680624365494 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5143872263610574 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5183494827007706 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5331726700942729 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5348299502800584 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5392963339405089 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5416203632319387 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5455116331936036 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5579117576951944 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5643428720460264 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5703908033207412 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.585447566551355 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5907260952187698 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5935280012302684 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6085281606389401 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6127343647693945 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6131002620457142 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6163920099054172 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6210974057234182 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6366682308980627 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6408375440697451 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6471608149987134 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6481889850062412 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6512161941572661 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6548149821784746 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6584713766847186 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6587732284139207 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6592617447901226 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6594000903095649 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6610722085220719 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6622817784051241 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6723359256166788 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6747053126951812 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6984224024373126 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7007739860451205 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7064877556683553 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7134783281580122 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7196271623538694 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.727470123871754 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7316133315362805 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7517379245182458 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7563639073277155 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7636784230748694 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7754117424759619 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7766547434885473 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7807050580270865 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.800128230931449 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.8024793997684281 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.8166849934645626 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.820382059080424 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.8208946262590766 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.821840608710882 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.8378598425880064 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.861531260078555 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.8663529531723424 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.8672067806581745 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.8740645877925175 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.877907373841353 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.8784164657319877 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.8928487750929781 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9023240737591465 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9043501492694563 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9130871712477813 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9196522913541103 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9215390724494057 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9218236069269921 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.923413631334185 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9252325686905731 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9423691456241841 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9487626135409499 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.952860344068819 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9537801928992844 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9600023643140219 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9605288211216987 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9657016426433789 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9771521298895749 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9773445008845774 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9817399851218092 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9922944536711968 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9975737692852391 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-10.020791675673777 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.0215268223640859 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.02745550655726 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.028300620467836 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.0317336458382513 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.0434349020536713 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.0575792874226364 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.0592260960126252 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.0710068588872521 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.0719094406281613 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.072667889547482 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.073256525799863 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.0783016213228755 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.0955288096374654 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1105534520238802 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1128502517811394 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1156694910791831 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1169559920529508 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.119467627389053 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1212175598157756 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.12730547778804 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1369246996462967 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1389721523200242 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1411363454331651 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1507536530839748 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1560743459114218 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1640579203662895 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1649656311542853 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1714556089840453 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1722157648412121 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.173347098222096 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.182883506400449 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.186081001636591 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.189104653123469 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1896055699642858 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1970972177841617 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2179759746733771 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2180007759101885 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2185772660160081 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.219951828513211 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2209530962569835 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2228329330803742 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2406857113566456 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2406984115880988 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2455089897525593 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2469839256217465 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.257818541723708 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2623238849606198 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.264664663510917 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.272105914536445 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.284405097608147 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2872766424074928 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.301697034810557 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3051610182664746 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3078585928415458 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.313264171715346 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3192226793553883 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3193075952477926 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3274170582175344 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3278181289074524 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3401676580315947 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3410967318852247 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3410984935451529 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3467450318941872 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3514630801007859 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.354052587382955 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3603166132774476 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3660015052016894 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3670379531565113 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3670635283579728 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3779079656681872 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3856940178991124 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3915018445361909 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3944595852862403 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.397295514636828 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4093779444557768 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4119613514662177 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4131292336600372 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4153001479944156 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4204599612970763 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4243238147902315 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4299465229374522 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4387416430467113 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.449802998631987 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4567294343544532 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4604842047484337 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4634809953697092 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4664833300616085 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4700125423872061 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4719769274081673 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.477553684852866 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4797579290028455 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4955308973161325 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999272 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.499999999999944 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999787 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999853 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999893 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999911 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.499999999999993 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999938 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999947 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999951 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999956 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.499999999999996 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999964 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999973 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999978 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.499999999999998 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999982 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999991 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999996 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999998 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.5 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.532442026614454 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.5707963267948966 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.5E-323 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-2.465190328815662E-32 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-2728.278975251547 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-2729.9649264323134 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-30.014096518143816 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark37(0,0,31.12701624770807 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark37(0,0,3.8232460577534653 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-46.885970099928564 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-4.9E-324 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-50.10999087153976 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-5.2041840584085435 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark37(0,0,5.421010862427522E-20 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-66.60051530679998 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-6.823593100375319 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-74.55330064118392 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-76.48219229020586 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-8.183623723232358 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-93.17010581945682 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-9.860761315262648E-32 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark37(0,0,9.860761315262648E-32 ) ;
  }
}
