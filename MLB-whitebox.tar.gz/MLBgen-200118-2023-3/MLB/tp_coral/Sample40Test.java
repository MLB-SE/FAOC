import org.junit.Test;

public class Sample40Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark40(-0.002658794778220187,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark40(-1.0652921672274935E-4,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark40(2.469736199521222,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark40(-3.167696196385893E-35,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark40(4.218609352549887E-9,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark40(-43.5716310586572,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark40(-4.367828808549291,23.445757309342408 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark40(51.98553738345933,79.7191936594719 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark40(-6.005363690020854E-19,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark40(7.644568205663644E-9,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark40(9.143093258380631,74.45306107306473 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark40(96.94426777581432,0 ) ;
  }
}
