import org.junit.Test;

public class Sample61Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark61(0,0,0,0.9457819081052605 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark61(0,0,0,-99.48847205051203 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark61(0.0604569765449261,-6.938893903907228E-18,16.82933528142537,-12.060687762530364 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark61(0.6679681002381272,61.19488319967917,31.31932691930629,67.36988620561019 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark61(100.0,0.0026912043423938086,-94.82279065269182,7.743288361046404 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark61(100.0,-100.0,-100.0,100.0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark61(100.0,1.0340003897231205E-9,-100.0,-100.0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark61(100.0,1.1102230246251565E-16,-32.7296081343093,46.171912831878984 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark61(100.0,-1.7105694144590052E-49,100.0,-4.4028182081039375 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark61(100.0,2.5665614576756486,11.617108002263016,-75.04195294631837 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark61(100.0,-2.7369110631344083E-48,64.54570805684145,-92.12459112616384 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark61(100.0,-5.770611636116085E-129,49.06219665779901,-100.0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark61(100.0,-6.681911775230489E-52,91.02045446516493,100.0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark61(100.0,-6.842277657836021E-49,100.0,-84.71027221087863 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark61(10.986141593566135,-1.1102230246251565E-16,74.54914118804696,-54.53715218027792 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark61(11.337152134931895,-6.938893903907228E-18,49.502857663710444,100.0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark61(18.101108949923855,74.74664676472565,92.45126767783714,67.70271572876067 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark61(1.83060045453567,96.188449273401,130.14266810640842,15.961373301025887 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark61(20.506788609884424,62.29394850160557,67.88856142882685,-48.731790500465145 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark61(2.121088997401654,1.5427992909077357,-50.035858925358625,32.903089922759996 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark61(23.164484041870907,-7.740436497873631,-6.6558599574998,79.147183944982 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark61(29.864905793854856,4.2351647362715017E-22,-91.68436447178195,-27.718317544359806 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark61(30.225215613056434,56.007852796708704,-25.492234325035938,-61.825433097596516 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark61(3.0445229050004947,6.776263578034403E-21,-100.0,99.99999982901434 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark61(3.552713678800501E-15,-3.552713678800501E-15,100.0,-100.0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark61(37.19998322540076,-8.07225253877732,-11.552457138722545,89.97934764010569 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark61(42.41237996924713,-18.95799823666688,76.99253258778444,86.07115429705743 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark61(46.434029772815165,45.75824549739022,-24.239024411110364,85.16045765747307 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark61(49.21393425169601,-46.65941479962052,-79.30198447354755,-31.043797458311186 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark61(5.15133976331235,36.28272131473534,3.130942802258673,-17.67714423477713 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark61(54.99731479998459,2.6727647100921956E-51,-100.0,-99.93019835107037 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark61(59.60005104891355,5.4738221262688167E-48,-100.0,-100.0 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark61(5.974614715799425,8.881784197001252E-16,-9.633331672934057,98.07200444474314 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark61(-62.94556946228542,68.16928576452247,38.970020358779465,4.509428492855605 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark61(66.97524069831695,-60.72386478318323,9.717558309493086,-82.33952632771937 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark61(70.45416824298923,30.973318646736573,-51.31500966990894,7.739624403364758 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark61(70.62644216169477,-65.16049601577271,99.1341646121191,-20.201569212755572 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark61(76.31594164991655,-1.8991135491519597E-65,38.30337358682,26.131812253310795 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark61(7.718862847327495,-8.673617379884035E-19,96.7960222010474,-83.61630348252463 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark61(80.76219164619516,0.0,4.029824214153955,-70.04457707759771 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark61(88.57579252101598,2.883149706174464,-28.896536817069673,4.049206724896166 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark61(93.31814241693533,8.881784197001252E-16,-26.800046981656152,62.773680696856246 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark61(93.77702555957421,1.1917899504830416,68.3218780874738,98.81608066675193 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark61(94.03409165285504,-4.930380657631324E-32,64.72609710263399,-68.10971896070224 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark61(94.91636173945818,-68.47358134182676,63.55926301748275,88.0071195678716 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark61(95.92916527747829,75.92610297800337,87.22006350001934,42.88494265022638 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark61(97.81250183509606,1.4981364335015035E-95,-8.680841124641377,-65.10681302973211 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark61(99.63849175083163,-80.2881076897051,33.51180573633441,-1.2410118337314822 ) ;
  }
}
