import org.junit.Test;

public class Sample21Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark21(0.0025275250203440724,-225.83207410103032 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark21(0.005500636497371524,-103.76838012770108 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark21(0.007291321295992366,225.9460165374048 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark21(0.007674759588836038,74.33565806492952 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark21(-0.008054934177030772,-203.63165451624994 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark21(-0.00886000032932413,-189.05232495951364 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark21(0.009137965752537518,-200.35957115629466 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark21(-0.010721722321982884,146.65821751124392 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark21(0.011505305456243897,-142.12776344397608 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark21(0.011814397740184349,182.62313391826714 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark21(0.012221923302515742,133.64533687306223 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark21(0.013343450467776815,-173.86010075273356 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark21(-0.013817392218876184,113.75322241258354 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark21(0.0,1.4210854715202004E-14 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark21(-0.015689202637060144,100.3877934326554 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark21(-0.015707963267949012,-100.0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark21(-0.01570796326794934,-99.99999999999778 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark21(0.015707963267954095,100.0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark21(0.015730827132671266,99.8546556737663 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark21(-0.01573695116341061,99.81579725856278 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark21(0.01893680249606966,6.149089866618667 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark21(0.019274417068821492,-81.49643754135944 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark21(-0.02002128226626891,-78.45632991455868 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark21(0.02094998969278544,74.97838184311053 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark21(-0.021310301376224357,-73.71065753895998 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark21(-0.021675492760557816,-72.46877125918094 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark21(0.0,-21.835341462953693 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark21(0.02336045876858907,146.0852204474598 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark21(0.023401783992231535,67.12293076956607 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark21(-0.023410581769212513,67.09770574261407 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark21(-0.024054272822105816,94.22408330714174 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark21(-0.02468367834990873,63.637044063195944 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark21(-0.02580410349607387,60.87389655036446 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark21(0.0,-25.917462204638596 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark21(0.02671267136193815,-58.80341600851894 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark21(-0.027372031405371595,57.386910877452756 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark21(-0.030133772777684538,-52.12743649405044 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark21(-0.030161511353799665,108.47428039890559 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark21(0.032060444417767626,-101.97449730793733 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark21(0.032302018665515936,-48.62846677394862 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark21(0.032663537674496985,48.09020818407376 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark21(0.034750605001576694,-45.20198502223564 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark21(0.03506784007382096,-93.15073103967889 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark21(0.03738926090895234,42.01196516368998 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark21(-0.037652373557183594,41.71838793666717 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark21(-0.03811106414756747,-41.216280939118214 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark21(-0.03957095931395682,79.39640671469323 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark21(0.040796552130928025,38.503163741723895 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark21(0.04085919254587722,-38.44413530764834 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark21(0.0414160916727406,100.0 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark21(0.044512985787847466,100.0 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark21(0.0462014578810043,-70.70323836926583 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark21(0.04701183559538756,100.0 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark21(-0.04761801716364056,32.98743669642551 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark21(0.04859570103616474,-32.32377130697047 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark21(-0.050124493745302603,-65.16965296083578 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark21(0.051617937932885105,80.24761936556364 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark21(-0.05362075939401237,58.589145606940406 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark21(0.054478914183973014,-57.66621273774026 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark21(0.0,5.452901144879391 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark21(-0.05585353189751915,-28.1234914504067 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark21(-0.056595917111516396,57.7178147098899 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark21(-0.058423578672308935,-35.7348893417889 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark21(0.059697519348802075,78.93776880159847 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark21(0.0,-61.59823009852128 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark21(0.06207653451072043,-25.304188437317247 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark21(0.06409970688414678,-24.505514972696204 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark21(0.06776009060745591,23.18173297457273 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark21(0.07172343355823593,21.900740788148223 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark21(0.07421867824725965,21.164434127508912 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark21(-0.07510293160913435,-20.915246490908608 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark21(-0.07511443749174541,-43.59526661496024 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark21(0.07568979039477819,7.53696632367804 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark21(-0.08039287089324887,-19.539000278777294 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark21(-0.0825399379104068,-39.57612595717331 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark21(0.08586044293955752,-18.298816978974973 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark21(-0.08693387628925109,-18.068863299830987 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark21(-0.08834449467145346,39.84611375429403 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark21(0.0,90.366311986542 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark21(0.09084116618255283,17.29167945332463 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark21(-0.09933135734396381,42.7249420035699 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark21(0.0,-9.983620707584876 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark21(0.09992707406702016,32.689834294552085 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark21(-0.10236772775458274,15.34464387605377 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark21(0.10691223678464873,14.692390450673326 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark21(-0.10772840510319201,-30.322482268819975 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark21(-0.10843024907566808,30.126211840768278 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark21(0.11382964596674304,28.31552085780467 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark21(0.11854213966225732,-84.84194832976394 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark21(0.11856032986292439,-39.40734614218098 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark21(0.12233923576212863,84.35746889801742 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark21(-0.12549738212420214,25.033592169167576 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark21(0.12633768169920936,30.42722561698528 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark21(0.12634012757103655,19.512609081231464 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark21(0.12634012757103655,-25.88959337698928 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark21(0.12634012757103655,-28.694052426498647 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark21(0.12634012757103655,-68.2465269136694 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark21(0.12634012757103655,83.75553291400799 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark21(0.12634012757103658,-28.973345846257853 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark21(0.13794564528762543,-22.774167534855597 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark21(0.14180168206833244,12.996184538849572 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark21(-0.14531987214256223,-75.66372410346706 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark21(0.14964501083192927,28.126091000054043 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark21(0.15356166160823026,10.22909175600293 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark21(-0.17180584824319178,-100.0 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark21(0.18393809717052775,-59.24888513807204 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark21(-0.1848552824960084,8.497438134227053 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark21(-0.1867821015651751,17.499030013987678 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark21(0.2342554032357964,-41.29832128666134 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark21(0.23733797298967774,-39.698385497595545 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark21(-0.23933881529716752,17.304877994991116 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark21(-0.23949356247188414,-45.91177286292284 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark21(-0.25531554200678286,-16.221467056487587 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark21(0.2794246721280075,39.35076385259677 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark21(-0.28788719253425865,-37.20193646779705 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark21(-0.2956891283863208,-5.3123235722844555 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark21(-0.3173113839939103,-14.850992489053368 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark21(-0.34367140172992966,-4.570634387638954 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark21(-0.352750849889605,-8.905981751612973 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark21(0.3612452740061006,200.42324931933948 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark21(-0.4111541380434401,-7.946496003748978 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark21(-0.4369540756889575,3.594877389158526 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark21(0.4580694761254893,-3.42916611707291 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark21(-0.47184409606069266,-3.3290579238127833 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark21(-0.4734937181363555,9.593758130642115 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark21(0.506054282151442,7.036970482397058 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark21(0.5529196653036621,2.840912388113402 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark21(0.5995049471680636,-15.943502639004887 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark21(-0.6022122947425941,-100.0 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark21(-0.6029209059147521,5.210829830175008 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark21(-0.6454147293711284,5.06013315343251 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark21(0.6626689433637208,-100.0 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark21(-0.6628426097332171,127.10740549130782 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark21(-0.6632588429095966,-7.104901850553992 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark21(0.6706602928788477,-4.692315857389858 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark21(-0.7213370689541364,15.239139664299076 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark21(0.727566310190143,100.0 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark21(0.7281318868721356,-100.0 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark21(-0.7339370450825367,48.27852456901269 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark21(0.7352097012240317,-2.1365282914245016 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark21(-0.7696691065312194,-55.103446191587146 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark21(-0.7721114984845038,11.467231936516397 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark21(-0.7736686897403422,59.15918953871032 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark21(-0.7805681181817853,-100.0 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark21(0.7833807869278943,-100.0 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark21(0.7851825124137688,-85.80202728193731 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark21(0.7853494252294634,100.0 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark21(0.7853946410400526,-18.780495311398337 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853980530086987,21.911231663841033 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633031655,84.94847736148651 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633301799,34.78537638424699 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633946707,-2.333880967417262 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark21(0.785398163397288,-67.70045417607673 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark21(0.785398163397438,100.0 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974456,-19.30694179214054 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974456,21.480205007967523 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974456,-42.04313915856041 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974456,4.880180756692912 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974474,-13.82143990666458 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974481,-20.861828593121672 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974482,2.0000000000000275 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974482,-2.0000000000008953 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-100.0 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,100.0 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-100.0 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,100.0 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,10.839550525520316 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-11.463694947795474 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-12.200319888411482 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-12.44153245683609 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,13.070534738375805 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,18.55017153078534 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,19.19677465208508 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-2.0000000000000036 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-2.000000000000007 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,2.000000000000008 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-2.0000000000032045 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,2.0000000000038725 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-2.000000000004924 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-2.000000000165283 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,20.181936286750393 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-2.022405852810451 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,20.49111003087134 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-21.685384110380667 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-2.267392264809833 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-2.300710688175176 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-26.22544483861332 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,26.523232344798984 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-2.6921209612169794 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-2.714710141584618 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-27.970121534963354 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,2.861662893404639 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,29.532474443347475 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-3.1042525218360706 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-3.2194651055055674 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,35.180683981101105 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-3.5557589668278613 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,3.7622651244651504 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,4.159154943091955 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-45.256727616008696 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-45.43682432070399 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,45.953028404309926 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,58.0229813449077 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,58.377181387184876 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-5.962982562515013 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,5.997405432299681 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-61.704108790742126 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,66.04929817924794 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,67.12034395047388 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-67.66082736228432 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-74.65463390934904 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,77.34841056480951 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,82.39266413168076 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-82.42307941982486 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,83.31727181662781 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,91.16461010294226 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-99.54412228825838 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,99.99998586942635 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974484,-100.0 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974484,34.394634265247745 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974484,45.382982862173456 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974484,-5.288440057943804 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974492,-2.000000000005741 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974492,53.95944177663131 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974492,68.51910497424511 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974492,69.30567121549205 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981634160245,-4.117207726096019 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981636369399,-100.0 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark21(0.7864984179387484,-34.95467446631602 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark21(-0.7869222513864634,92.20623335091139 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark21(-0.789478495795606,1.989663220923972 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark21(-0.8436974845793515,-69.44007214339096 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark21(-0.9223173374984827,1.7030974729969017 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark21(-0.9844402810565113,-9.573752269849237 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark21(100.0,0.3449612626178197 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark21(-100.0,100.0 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark21(100.0,-100.0 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark21(100.0,100.0 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark21(-100.0,-34.779341382947315 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark21(-10.210176124166829,-50.093294187690084 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark21(10.280705302140017,-42.47581921770731 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark21(10.401346029431835,-0.15101856263123475 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark21(1.0413892910234495,-1.5083661223856097 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark21(10.449474368443987,100.0 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark21(-10.472836563916323,-85.97632123741043 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark21(-1.0484987237808003,-26.23632896963086 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark21(105.11701376768704,31.104952283448824 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark21(1.0625995912592998,-1.4782579813844332 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark21(-10.657681339325848,74.58214213417209 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark21(-106.68781009448193,-132.71790189488075 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark21(1.069519135131848,2.4040593124045877 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark21(1.0710818555106656,-61.72192239203738 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark21(10.828120481347115,-3.715501072986868 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark21(10.864950779896503,-0.2188833386607243 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark21(10.86923415999324,-95.13166982299475 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark21(-10.874803165046899,63.35536377303316 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark21(-10.93088067511087,41.62255535763887 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark21(-109.46925121151132,0.01570796326796664 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark21(-10.977380839859153,-94.67616974893511 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark21(10.996062568814278,0.14285079948175827 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark21(-11.073977161191074,-52.9271762908474 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark21(1.1102230246251565E-16,-66.12273843383429 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark21(11.10583650369999,33.803876185184805 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark21(-1.1142351001528956,60.2475668181213 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark21(11.14408661918469,-25.069502607082043 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark21(11.175278871089766,-12.121734218817608 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark21(-1136.4583533890632,-27.03918312545585 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark21(11.381190735996057,11.42039268500099 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark21(11.397467737596642,59.7137375982814 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark21(-114.17989098609031,-0.004999096329626448 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark21(114.81790215551109,18.23845486243549 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark21(1.1507784538372334,-62.98749739345207 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark21(11.56450178240027,-19.154755684587215 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark21(11.595780128189901,5.329070518200751E-15 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark21(116.14961966164681,59.91501063852516 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark21(-1.1877746098204045,59.9592187437227 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark21(-118.8235779900195,106.95755471092593 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark21(12.082204216074537,-65.15274235776855 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark21(121.36401403734972,-33.68674421880877 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark21(-12.149015663402789,53.48593461718772 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark21(-12.157587862875191,-13.115823023117638 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark21(-1.2216103486272516,60.12583455340646 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark21(122.27144789335193,97.54854463643855 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark21(122.28448427715028,-24.527926704819137 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark21(-122.34038203751916,-8.80792998265693 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark21(12.353366491985444,25.612171794347258 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark21(-123.88023239886105,44.03839626779862 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark21(-1259.1337979444281,-1313.9676123028719 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark21(12.69271074193021,0.13839270923574531 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark21(12.69271074193021,-0.14870023466723806 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark21(-12.72324398266354,-176.08691648152816 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark21(-127.23405315790608,-9.657118786971125 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark21(-1.2728658573411809,-1.23406273939663 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark21(12.764842839949054,65.63571483341028 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark21(-1.277326018139675,37.04098231642968 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark21(127.81431538327065,60.439970841491686 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark21(127.95097130537904,-103.73683346333806 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark21(-12.995727508580032,43.28536820772436 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark21(1.304080559080166,46.13228631778895 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark21(-13.216003334750823,23.508969706269255 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark21(1.332267629550188E-15,-27.21236052454178 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark21(133.32181707809184,0.016442262757152548 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark21(13.351768777178892,67.96655789536806 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark21(-133.6624682944929,121.34073425183139 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark21(-13.3814998106577,-54.81454183768826 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark21(13.465914907768838,24.520071889544653 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark21(13.48194033488798,78.6208990135916 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark21(135.0751652718032,-195.40277742691336 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark21(-13.518673559864347,10.067855532739255 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark21(-13.556961589540848,-50.70443938666362 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark21(-13.59667588400998,-99.98407471377256 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark21(-1360.817028829227,1280.68546247214 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark21(1376.6794032951545,1278.3985481562954 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark21(138.22648595761137,-78.7488676809336 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark21(13.862375792576323,-70.86892231983879 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark21(1.386966364488896,-47.5749016853714 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark21(-1.3874627381108502,-6.792828294830209 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark21(-13.884126730451264,-23.72547240041573 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark21(-13.896755128451035,-45.35117623085265 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark21(-13.942076237139148,-51.08327109399002 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark21(-14.009505811001258,7.325014151257051 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark21(-1.4057607018026033,-2.234826376598382 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark21(-14.108118157930985,-32.30278855239023 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark21(-14.121721212574437,135.55667756502808 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark21(-14.131380924327338,-30.901571951199916 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark21(-14.137166940874788,-15.82540875484598 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark21(14.137166941154069,-14.785134190421772 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark21(-14.16420871757473,123.97609264010106 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark21(14.16841694115407,-0.14692056211202953 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark21(-14.17304208989379,51.72885941940015 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark21(-14.263507068725106,23.16519377265557 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark21(-1.4323722534757696E-6,88.68096486635562 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark21(-14.380068935972545,83.1280922667196 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark21(1.44445619922386,7.276325092998402 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark21(1445.573245265963,-1203.1006566325684 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark21(14.574407768190412,-13.011830287447168 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark21(145.96301082272385,41.3030415612285 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark21(-14.630724689743133,-36.306079173725706 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark21(14.739260988969448,9.487214018406299 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark21(-14.746519652985938,73.29179135149474 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark21(1.479922405015659,36.69602684759826 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark21(14.921263005101949,-84.8295463831021 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark21(14.987588617917353,-17.343115707327584 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark21(-15.119413185030567,8.031394704856847 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark21(-15.1738925168387,100.0 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark21(15.191233295466304,-24.26602981235324 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark21(-15.21915442638019,77.09725386203644 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark21(-153.17805158952277,-125.57343235218886 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark21(-15.493802143939362,-4.253418817150674 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark21(-15.58162314037793,58.182996870303526 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark21(-1.570796326794782,-2.679968509434253 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark21(15.707963267948388,52.926158638097405 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark21(-15.748559373117391,126.37339701346652 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark21(-15.753126201066678,19.378189116396484 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark21(-1.5757099932760574,1.006797784873195 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark21(-1.5772931226009348,-84.77135806900489 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark21(161.6568436794346,109.11669545095567 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark21(16.207963268018204,-4.819171925184261 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark21(-16.240714156382783,-100.0 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark21(-162.95926932110953,69.77619026333448 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark21(-1.6332963267948595,5.9413986192590915 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark21(-1.6332963267948966,-28.62010073432465 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark21(1.6333033196828108,-13.600846450301816 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark21(16.49600099582196,-49.62238788251092 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark21(16.546803229827745,-5.885953143190073 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark21(-167.8380969951038,192.92867103193043 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark21(-16.826776358679293,-7.966353725353471 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark21(16.83530152185682,-49.89189607945528 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark21(16.907632891876943,-42.23554147474795 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark21(-1.6971364543659333,54.09219264233003 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark21(-1.697136454365933,9.546148372926027 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark21(-1.7022992166260185,-35.39774083892898 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark21(17.153867529624144,4.501624619895741 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark21(-17.239627940711127,42.91522990316458 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark21(-1.7240095404082003,-104.07173028078958 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark21(-17.27155698241498,80.88047839433717 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark21(-17.278760176921452,2.0493728792319166 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark21(17.279247876223653,-0.2691093917738123 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark21(173.14758452992118,-26.574730480109267 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark21(-1.7341855397711845,41.791010777161716 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark21(-17.4050997223149,7.763937949579136 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark21(-17.405502905533627,-0.09024710951014825 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark21(-174.60035920114396,25.817732354920746 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark21(-17.479682189598364,-26.831111362544505 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark21(-17.613464355299897,25.562632076151928 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark21(1.7615870238503872,0.8916938564644568 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark21(-17.771231610967664,-39.09542654337596 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark21(-17.84547533401084,-3.262671707793829 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark21(1.7873939946173607,0.878819293074315 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark21(-17.910179328724567,60.88932728448563 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark21(18.065102368760492,-20.69575770734434 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark21(-18.188932951681473,3.5666133687183077 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark21(18.335510805729754,69.8012178331704 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark21(18.580758778284448,53.979483814444166 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark21(-1.8615397169273535,0.8438156395543597 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark21(-18.72466385641904,21.960436970751733 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark21(18.849555903456938,-45.90760309984215 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark21(-18.897357411082634,-24.14653123981877 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark21(-1.8976639784111224,-2.3542777732807982 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark21(-19.032024688605077,-0.08253437837137767 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark21(-19.107596800935994,-74.87113862528705 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark21(19.208638194627724,56.46804706912209 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark21(192.94149826475308,-40.552017411340834 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark21(-19.388513874201124,4.440892098500626E-16 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark21(1.9471699639447877,82.60581999603698 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark21(-19.50861395736517,0.4369989146060065 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark21(19.544051751459563,50.565432806675496 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark21(19.55393966499497,-87.29863439744142 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark21(-19.605658436772423,-23.81861352899667 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark21(-19.63495367246751,62.81415142753626 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark21(1.9640488022838696,23.784869174533156 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark21(19.64938557847708,-0.0799412439906246 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark21(-1.979797232655649,29.891496836958737 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark21(19.887802672896278,32.741063806337166 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark21(-1.9891944219320834,26.142996974542413 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark21(-1.9943216007930649,-0.7876344147153863 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark21(-20.08851284959657,17.965279368436384 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark21(-20.29985145661037,-16.247392844431204 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark21(20.42224702362517,66.236906572887 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark21(-20.471011344134766,20.88455295088562 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark21(-20.48275768234342,-37.23105960571371 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark21(-20.546692375904694,0.11553100336435909 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark21(-20.67035224833366,0.07601711459487603 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark21(2.0729860287656954,0.7814772867866395 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark21(-2.0747947390699695,0.7646163366724466 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark21(-20.78396994413167,-21.010489334944296 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark21(20.86268259974358,-15.554579006158136 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark21(20.96807940120115,59.128184239368466 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark21(-21.05768453810855,-95.92028279364624 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark21(21.205750411731103,-0.07407407407462419 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark21(-21.24023857555002,5.780930733039597 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark21(-21.28931151917712,75.6377925700574 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark21(21.319100181855703,-82.68467629791522 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark21(21.325025204516272,53.80249609800039 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark21(-2.132529298983967,-13.467533097165624 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark21(-21.374160052139786,91.34733281863667 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark21(-21.396037470367027,-25.72236329574233 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark21(21.491148575128552,1.968132185260444 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark21(-21.762101889354398,-91.01163900049904 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark21(21.824124287910564,-4.397869401808393 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark21(-2.1863811292590856,-87.86739426590167 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark21(-21.89417396755839,89.95621813791857 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark21(22.11748870269959,-12.070758464968923 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark21(-22.241152586990676,-0.07062567106859875 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark21(22.241198687038427,0.07578600522735789 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark21(-22.29597985716859,0.18951256461908628 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark21(-2.2298543626191467,111.49070737506742 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark21(-22.51167166326728,25.246487353835704 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark21(-22.776546738525976,60.56153498759301 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark21(-22.776546738525994,100.0 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark21(-2.280909051881139,-0.6886711793700895 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark21(-22.964320175158203,-3.0240891259414327E-16 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark21(-2.314672252907733,2.035877422587541 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark21(-23.561944901923408,-45.203051554074314 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark21(23.651167861387428,195.9259742432179 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark21(-23.68810281630974,-39.43267646405255 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark21(-23.688285029494487,21.29582735160417 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark21(-23.81194490192345,12.265762860564568 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark21(2.397727558581057,4.002190309148446 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark21(24.547568328156075,-61.27066810747755 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark21(24.575788474633868,-52.48451871329316 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark21(24.582330783276717,-23.45824621926866 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark21(24.586055236722814,27.438902233773476 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark21(-2.4868995751603507E-14,2.806821005751786 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark21(24.987386902551783,97.98849488694424 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark21(-25.006401101147308,62.5010746454536 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark21(-25.015846759592208,-18.911740408119524 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark21(-25.05656200827886,-34.01541807342795 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark21(2.506974109820817,-19.873137601609642 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark21(25.171322468463245,-41.0060549721647 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark21(25.24820098717685,-0.062214188155135464 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark21(25.27254237345396,0.062154266222334886 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark21(25.38282128031789,-26.553799766880175 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark21(-25.501533429256337,16.38059052488062 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark21(-25.633561727831307,35.370551670342024 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark21(25.651293927196324,-75.60016982820918 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark21(25.654805572156377,-81.57694090191353 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark21(-25.848698453876892,-5.698707750568785 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark21(-25.850357122338693,-36.76692652591282 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark21(-25.901408687503306,69.93321756709702 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark21(-26.215239673243957,77.26143954436563 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark21(-2.636970404693301,-53.252872780275666 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark21(26.637690715115294,-62.344791583181625 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark21(2.6645352591003757E-15,3.1863126475951304 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark21(26.664905131980074,2.5316094385581045 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark21(26.68906955456056,5.741079666729382 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark21(-2.67127551328376,0.0 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark21(26.73619076959875,34.6791565786469 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark21(26.742267983648787,-54.84600400242341 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark21(-26.946613914504482,-29.502001376893162 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark21(-2.7048448222658834,-89.33782787991949 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark21(-27.370865187893784,-43.98775907186203 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark21(-27.4983134784609,42.87950942147464 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark21(-27.5153211302017,60.224938508817345 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark21(-27.618571424709586,-58.62447209475859 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark21(-27.649727548362083,2.441466607998798 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark21(2.7674261796184254,34.83528314988499 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark21(-277.40257279473263,-58.06909472012177 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark21(27.77433388229847,8.235328978271369 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark21(27.885595256611268,47.889177118267014 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark21(-28.00563944070929,-2.323843752610783 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark21(28.05272391632456,-51.146094005740295 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark21(28.10291276624102,45.027430359813394 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark21(28.117194835496726,52.886547456128724 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark21(-28.1479937547371,0.06341632793696306 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark21(-28.203970148276895,35.076512395494774 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark21(28.26956694577438,-41.02354883716793 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark21(28.27376985623865,15.486734030807053 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark21(28.488408560330583,62.55263731394044 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark21(-28.909178439985595,9.202361077345998 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark21(29.012608155901734,100.0 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark21(-2.922246278056832,0.0 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark21(-29.393933495803015,-33.21690211954888 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark21(-29.415888063359134,-8.630434719647113 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark21(-29.427372427481018,30.197954693821032 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark21(-29.729685321346313,-36.47819572333682 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark21(29.845137838497873,42.88582778900719 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark21(29.892998705922146,-39.988494177203386 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark21(29.923514619141656,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark21(-29.966785646402656,18.870158526394505 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark21(29.978060870410445,91.29395864548458 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark21(3.003996270233616,-64.16563875782217 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark21(-300.65392869954746,162.93323939218683 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark21(-30.110700908920847,16.181690753195355 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark21(-3.015252526018757,0.9474269627140149 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark21(-3.015252526018757,-86.01954037840737 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark21(-30.347480240830883,52.250202956136434 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark21(-30.654955642980873,19.980103098700184 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark21(30.70688463799928,-44.960987283945485 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark21(-3.072755339343586,66.53529283694688 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark21(-30.806556986937636,12.713993391884415 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark21(-30.964795177500505,-45.966847965682724 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark21(-31.05466734668856,91.31569161074607 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark21(-31.233097927730793,-37.156825816318715 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark21(-31.289586408326898,16.800273595022325 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark21(-31.294047468299652,90.05746817770392 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark21(31.34210522999203,-55.21669145402037 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark21(-3.1388881923527094,-29.862044878176604 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark21(3.1415926535897447,3.3396949123932025 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark21(31.425752768872183,99.43712275794803 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark21(3.146634941132836,-82.98693547826755 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark21(31.47349071722776,-0.09470679495824576 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark21(31.54226666346897,76.1890635825294 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark21(31.63435368474203,-0.01804352397878911 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark21(31.726330288488825,75.9447054984094 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark21(-31.83211104437649,-63.02567002585118 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark21(-3.1901118169525517,54.16349203366076 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark21(-31.974756794418383,-69.26492156561837 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark21(31.97611079723265,78.8931329621075 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark21(32.184531680321214,47.42148725428706 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark21(32.23203479083555,-22.7087495034789 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark21(32.343678735758886,65.62089062150474 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark21(324.42174810982505,-39.11615614523242 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark21(3.249059428858786,89.72124771858665 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark21(3.2665926535897722,-0.7271320005692802 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark21(3.26793278116083,-0.5526029779716444 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark21(3.26793278116083,-0.6401770499082501 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark21(3.26793278116083,-4.67533641253276 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark21(3.2759734814591575,-39.31822308203825 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark21(32.976728062023085,-54.05159524514347 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark21(-32.98182649022691,18.74670000951075 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark21(32.99062911269283,0.04761475427855588 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark21(33.021348044356756,-11.162098351512654 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark21(33.03829888193397,-94.76406108771613 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark21(330.6101339566016,29.148633546618072 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark21(33.06922246226287,-31.244910352964794 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark21(-33.11306299026386,39.77899085380352 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark21(33.265635364127064,82.83571202241015 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark21(33.560257991506916,64.9941593103868 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark21(33.75670531868607,-29.903740521069547 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark21(-33.8758413620389,-0.04636921958654128 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark21(33.87973111014743,-45.34755611697414 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark21(3.404935196812026,73.28437908135379 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark21(-34.30630055803279,-3.9790960804417352 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark21(-34.490247665838815,-0.8100833587665051 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark21(34.68385931705876,0.10672079674323243 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark21(-3.473476952205397,12.19229638179702 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark21(34.74460688440806,71.14198673407503 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark21(-34.77652376455427,-25.72356277240256 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark21(3.4872299080836697,-100.0 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark21(34.9024879460735,28.678023430738875 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark21(-34.98162624156616,-26.313960468482662 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark21(-3.50546373967427,54.25907629472175 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark21(-35.06515460137473,36.48292429304453 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark21(-35.29804075712314,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark21(-35.43879779294343,-78.94547185877315 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark21(3.548885110101574E-15,-100.0 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark21(35.688263305942705,-71.36935703691017 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark21(35.72311701271763,-44.63099541759526 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark21(35.855740480312846,-13.970749246394476 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark21(36.001975388711585,201.47245505550393 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark21(36.05233041006983,-97.65288207416837 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark21(-36.09287793509943,-177.09366912143773 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark21(36.23866419246761,27.1103057041896 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark21(-36.24211494894482,-0.2724017319696319 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark21(-3.6425451830419604,-2.891093484327328 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark21(3.6458250345373777,68.00906326282598 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark21(36.71604027729412,-19.44671038722248 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark21(-36.733886865319484,72.74201492848347 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark21(36.8167955901813,8.409623635261724 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark21(-3.6854035633438826,51.683918270018665 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark21(-37.11498467779442,-38.703146316826185 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark21(37.134468739453524,-39.179955775363084 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark21(37.56449040819595,25.71449212786503 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark21(-37.5742197779578,-0.04180516152210003 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark21(37.60882851588805,25.644728971103394 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark21(37.6431105832701,-89.88477862002888 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark21(37.78037471273866,87.91028761707217 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark21(37.84749749858943,-0.04150330750014423 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark21(37.85619147615621,100.0 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark21(-3.793480125739153,-58.2595866320122 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark21(38.48223151777654,37.77026520950761 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark21(-38.484510006474956,77.96972716954191 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark21(3.8696212447812,-46.38795882204581 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark21(38.873177037126226,37.3970119500817 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark21(39.02403492907746,9.296397304187806 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark21(39.03170444536509,-36.26731858040504 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark21(39.1398648769967,-94.9544430604687 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark21(39.20303459869285,-61.62900315398703 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark21(39.21608739194963,67.655426260051 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark21(-3.9269908169872414,-24.914596579849956 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark21(39.26990816987243,-90.78396679430487 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark21(39.269908626232805,3.120200556655263 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark21(-3.927297317169516,0.4189625277496465 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark21(-39.42257846109297,0.039845093550771954 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark21(-3.9673780749666068,-0.3959280656175222 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark21(-39.69578982212252,52.04645033775844 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark21(-3.9798201718912054,-31.038619053136802 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark21(39.82475878771163,17.34477701084205 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark21(-400.2050668811894,8.264228513174984 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark21(4.016947905700396,46.40209366829738 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark21(40.365772802527545,-16.401200170519644 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark21(40.50819284802111,11.67033864266422 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark21(40.66192112029097,-94.98379635754779 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark21(40.840704494844424,-82.66872584466742 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark21(40.840704496667115,0.03915134501464275 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark21(4.0905617456094,-0.7952974735389944 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark21(41.040087194567406,18.634893745884696 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark21(-41.0948364241035,54.96196045441587 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark21(41.18848965856563,-96.92495328039193 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark21(-41.39061775633404,-62.194452446579575 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark21(-4.148775989289021,4.440892098500626E-16 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark21(-41.645629400858546,-1.7224439283848056 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark21(4.173105081735021E-18,14.673088445668748 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark21(-41.73404493832478,80.95363619586237 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark21(-41.76359778370588,18.54553709909206 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark21(41.80274474631844,49.828950465603164 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark21(4.182261467646569,15.80200501442406 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark21(41.87591829374671,42.41592550509415 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark21(-420.1122765293754,31.072125070367463 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark21(42.03467212252377,11.133215799110332 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark21(-42.18341929789504,-81.83596176654815 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark21(42.28516069589117,-77.36596126364063 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark21(-42.31778092719596,54.8940461031935 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark21(42.32588215225937,0.03711195719782978 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark21(-42.37354157133224,20.42568884411853 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark21(-42.38780877756092,-36.557222058237926 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark21(-42.41150080705459,41.855204212019586 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark21(4.2437638219803615,0.7478058433331398 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark21(42.475134426125635,33.21907763808696 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark21(42.53196021608659,-17.95251612750633 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark21(-42.635364786338485,29.80591431019471 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark21(42.69385441075425,-1.3659123816832022 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark21(42.75191504321677,87.25861110352494 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark21(-429.5097256739786,18.61872500318185 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark21(43.127300603864285,-50.46335515363087 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark21(43.18719209431312,35.099426585412004 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark21(432.390326266423,190.10243355444914 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark21(-44.06181571369642,34.59166878526113 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark21(-44.20382218113357,-85.894884902465 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark21(44.279064982826284,-54.54814393359342 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark21(44.28348942485951,-5.719207163392468 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark21(-4.440892098500626E-16,62.83199521003951 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark21(444.3376240175441,76.14115990657984 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark21(-445.66025736108173,-180.44319896253273 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark21(-44.727137878528026,-3.5792970453646547 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark21(-44.74180664309269,-7.512936264608939 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark21(-44.77039813745108,-21.01134321446152 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark21(-44.81433077263528,-130.63520753110518 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark21(-44.82458600554271,70.1652305907577 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark21(44.94986137520507,0.03494552104889159 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark21(44.956939983607995,-76.11437274730919 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark21(45.04650948103168,-83.03778627095356 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark21(45.17765729714006,-56.98691197473436 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark21(45.24341076812994,-8.681872447371916 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark21(45.282096762511586,-0.04466710241102495 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark21(453.34167323909,-105.84196239936085 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark21(45.367782070782766,-0.2120148531056465 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark21(-45.396801697642196,-5.062208702339291 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark21(45.41390702631254,3.122706239385593 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark21(45.42675334948097,54.846176838137225 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark21(-45.460753119419955,100.0 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark21(45.489248826799525,82.28496324447502 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark21(-45.55308961433744,-26.85720936635965 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark21(-45.625020901228666,24.81247879425958 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark21(45.66845954338965,-1.5685181150001881 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark21(45.69091537877111,87.79712601737128 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark21(4.570528447627962,35.05398372096622 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark21(-45.76816694471577,9.506536856193847 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark21(4.582780389116248,0.3790238558493972 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark21(45.83715595344822,-118.24243393207126 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark21(4.586048852813653,-0.4664602905508834 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark21(4.586048852813653,-39.374029947144315 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark21(4.58749691526497,42.06458400209738 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark21(46.19455525675002,6.190072137675372 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark21(4.6265040716699275,-71.49988114900736 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark21(46.41766004295175,-0.033840489273724454 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark21(-4.706905797616029,-64.51444840453178 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark21(47.12388603931705,77.52698690079743 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark21(-4.712388849026574,13.754687754004971 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark21(-4.712388980357042,-55.41449251297594 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark21(4.712450015541267,12.891764304305072 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark21(-4.71487339382621,10.327648286604102 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark21(4.715506999965492,0.3331129245842234 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark21(47.250229931417934,-0.033271416017619515 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark21(47.250229931417934,-62.01184678801363 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark21(47.40893847176088,84.21361568321437 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark21(4.743638980384701,-1.9029965884401063 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark21(47.443212700817696,84.96310361320579 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark21(47.71908584291879,4.345051130907834 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark21(47.783713268724235,-64.72703262020322 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark21(-47.83045182392449,23.44354248950756 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark21(-47.89175674096242,0.03279888719244628 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark21(4.797920443591579,-66.35095037972549 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark21(-4.837388980384684,0.3248824056078676 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark21(48.37941453996112,-91.79387424426517 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark21(-4.838729107955727,-9.659454990590072 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark21(48.56834600307076,-2.811289067842356 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark21(48.56834600307076,-4.317302060370366 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark21(48.59017588063604,-71.81358749460456 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark21(48.71409337735876,37.73924190418269 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark21(-48.71743651126501,-75.49130498264678 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark21(-48.82102625821283,-19.480856955199037 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark21(-48.95186334050892,69.1279298630408 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark21(-49.12226930650365,12.976214310315996 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark21(49.16983738001221,-34.975631625399025 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark21(-49.30677649689257,71.26279086666793 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark21(-49.40878958783568,55.4765087825827 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark21(4.953067632931308,-29.926467258062985 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark21(49.55585982040412,12.102341895583862 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark21(496.47795414997563,106.78127466974152 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark21(-49.762102571310066,-67.48454405334235 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark21(4.993326980081321,8.21454495844101 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark21(-50.26560452778432,-37.202318785557175 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark21(50.32453225902853,57.71345063465932 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark21(-5.040371748894509,-19.010220021073707 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark21(-50.50598614645641,-67.6153060143333 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark21(50.524582891582156,-99.02250989414337 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark21(-50.910482737222075,55.32210145746638 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark21(51.01081787564236,-25.664163884060798 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark21(-51.042030553298254,-40.83618679866288 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark21(-51.05088062083414,-10.898303283162386 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark21(51.056290227413626,95.45588179125119 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark21(-5.107135815080781,-78.31334875808169 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark21(-51.45742831681801,33.125113505950964 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark21(-51.65874881592351,-1.2796710354724468 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark21(-51.710859598296665,-182.94434293569404 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark21(51.758794486520095,-65.02022150580041 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark21(51.77847595330675,34.519450076448834 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark21(51.95544013192864,59.57672471277235 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark21(-51.96261891180262,-86.40892907228019 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark21(-52.03701795325831,-8.619543325351742 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark21(521.0733726107512,85.03746543058547 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark21(52.30588018762994,-82.70160108439492 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark21(-52.412536302582694,-25.452748564590493 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark21(-524.8491938527991,-193.21031498503527 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark21(52.593423608458416,-7.704155598411148 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark21(52.77360453474469,-40.20074778507707 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark21(52.829178968409394,64.0432055080783 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark21(52.9893955000135,28.380742873606263 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark21(53.01872051678993,-49.89461137975661 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark21(-53.26610183109173,0.8476383378549315 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark21(-53.280734983455446,9.2811320504494 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark21(-53.31421328616658,3.4993929535313937 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark21(-53.3576038482504,10.890744596278369 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark21(53.431299135186286,100.0 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark21(53.46223640048188,-44.50209437877585 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark21(53.51555384033972,-28.525216154524017 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark21(-53.78907192850502,12.666194853388049 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark21(53.83578548500023,93.09723210640573 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark21(-540.2879020501871,84.72507864291538 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark21(-54.16852888008166,13.235015718767258 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark21(54.33133040033741,35.320588461295756 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark21(-54.39149932521875,-84.27233683131828 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark21(-54.47097275290287,-46.78183301230381 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark21(54.88778935759429,63.3543836433993 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark21(54.90367412803737,27.29367601561045 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark21(5.497787143776022,78.48190216291091 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark21(54.97787143836705,-0.17922063984240433 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark21(-54.990806141134684,83.13475037842485 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark21(55.112354898944936,0.02850170945653 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark21(-55.37600957142777,40.09593639767846 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark21(55.493729709964754,51.09679869545948 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark21(-55.63953361579048,-45.66506192799351 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark21(55.84099982888611,-60.26049523911672 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark21(55.9887487411899,16.86500023655831 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark21(-55.996125642329226,67.8277963570396 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark21(-56.03901532926785,-90.3343913134721 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark21(-560.8156713950596,-63.03500955874033 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark21(56.23211101681789,-34.236184406098346 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark21(56.30823000870311,30.302962274776228 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark21(-56.31081098460447,70.21499621322965 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark21(56.315049205959355,19.692656828827552 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark21(-56.385685853509756,18.880706552795814 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark21(-56.4027547288368,54.50414734182411 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark21(-56.416834045678,174.25780566713036 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark21(56.54819161111361,-3.3910687076012493 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark21(56.77833750581593,55.39076035692048 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark21(57.2122453255773,33.35639981767088 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark21(57.83878834453722,-64.06615077819383 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark21(57.976270946480014,-9.546588454750761 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark21(-58.13378106823788,0.02702037090881504 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark21(-58.14886237187004,-0.02709263905403958 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark21(-58.26896038735319,-99.05610410639167 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark21(58.37569954649808,-58.63319413903927 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark21(-58.451738856500235,-78.96633626771938 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark21(58.5256837768885,-2.1999327734506693 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark21(-58.58946093901023,70.70145361042611 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark21(-58.70456164950897,65.99786410884231 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark21(58.90486225480862,30.752608573751544 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark21(-5.904569557608255,-0.36395646794832404 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark21(59.12025335561094,92.21552755222876 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark21(-59.17578002802435,67.49338240263279 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark21(5.923911730863509,-31.29854311166271 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark21(-59.335369207756756,-21.68154018121188 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark21(59.42313002004243,-27.866038634553178 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark21(59.48497075461644,-10.714327822271693 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark21(5.955420112972092,-77.29186525876337 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark21(59.6902592465973,-29.609375007470852 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark21(59.69026041794661,-0.8824921981313337 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark21(-59.76501492577664,-15.822742850800035 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark21(-59.831431979780746,8.370191004229284 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark21(599.1619024234712,155.23865302651794 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark21(60.0779394958559,51.18710177340952 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark21(-60.1685258298986,-1.2814717942734433 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark21(-602.1919852208933,134.58014282526838 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark21(-60.35952638871202,-42.02876032254914 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark21(60.383492007254915,-43.73264450228555 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark21(604.8799223498504,-117.12416516633442 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark21(6.049900106616241,92.8638303858607 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark21(-60.64780911881673,-60.26999335278272 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark21(-60.8162696924162,-84.9501336681013 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark21(-60.852529834997846,13.499964501071162 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark21(60.88406943711058,90.16404705475546 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark21(-60.943753767946774,79.93901054308708 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark21(61.21684096546406,-75.71486366393131 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark21(-61.259058279441,-9.713811621525451 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark21(61.298311673188266,-67.20256183423453 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark21(61.373302409013824,26.960681577338548 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark21(-61.387396872572005,34.63179693554377 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark21(-6.145065066057612,70.98002639197111 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark21(61.48728488538192,10.089874517508536 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark21(61.56115217943062,87.80978959485958 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark21(-6.158293242059864,-0.38940286673803826 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark21(-61.649332512447444,0.02547953502331124 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark21(6.18385769643889,-14.537104079635569 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark21(61.937234302170324,-51.282691684759335 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark21(-6.213151463486128,-4.604019884138741 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark21(-62.164775220404834,-1.5619635934111216 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark21(-62.290982271676064,-23.96245144095677 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark21(62.515781082053834,-18.754867185193582 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark21(6.260516200835507,-33.62474713796611 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark21(-62.61399331555306,98.41536230235027 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark21(-62.733621279459605,-28.672338102054496 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark21(-627.5130665203228,68.0045529978743 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark21(62.8318530717931,-70.15308937551882 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark21(6.283185307179329,-3.6857406875965317 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark21(6.283185307179585,0.2858773992959377 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark21(6.283200782065591,19.690666221850183 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark21(-62.94781541609835,-162.16382800427692 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark21(62.9581931993669,64.62425061092024 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark21(62.9581931993669,-74.31323917121881 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark21(631.1017883814632,-75.65742905408396 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark21(6.329685776310882,-74.51429881009679 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark21(6.345685307179584,3.538614582652528 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark21(-63.50705345965557,-45.45113932632587 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark21(638.0457869582798,81.39318593488403 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark21(-6.396761147507874,74.81622668194748 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark21(6.409525434750623,-39.89912563845285 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark21(6.409525434804948,60.36754264530338 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark21(6.409525826043862,-25.184002438271158 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark21(64.2354910770928,-96.7761931759557 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark21(64.26045328536523,82.78244643766641 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark21(64.30336128283828,-31.110720315353802 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark21(6.450112557283317,-0.730665894826996 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark21(-64.51923378057214,46.50026346556507 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark21(65.18804756198821,-0.026462616955666714 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark21(-65.29659542553817,-0.024056328152455952 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark21(-65.42614131930591,41.736428775717854 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark21(6.544573601575446,0.24240254955846297 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark21(65.92971864511155,-15.891485228558022 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark21(-65.98907072715365,0.026056255814433556 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark21(-6.648959887630056,-84.81749718757905 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark21(-66.51054924601135,-60.716044801443616 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark21(66.54228898014131,-61.32478830666986 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark21(-66.54814435738652,-95.43289098924464 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark21(-6.658268809498907,29.00728714821622 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark21(-66.98950400948094,-43.10141300517052 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark21(-67.59238746171661,-0.02323924906017827 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark21(-67.62996079905865,-58.93199392895085 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark21(-67.67018033833115,2.3853203753528813 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark21(-67.73532272717067,-41.682518748588194 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark21(-6.802584043372761,-91.89894032009276 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark21(69.13768770588793,129.9853778682685 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark21(-69.16741490505156,69.72410952682895 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark21(69.19864556876306,-177.84784315213528 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark21(69.20294822474034,-29.629289028872122 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark21(-69.25688828540174,4.049172369631222 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark21(69.30964178569394,0.8469278267569251 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark21(-69.44400541836549,-23.280538164873832 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark21(69.56475968099028,-41.24439837640892 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark21(-6.962395879849524,82.72907984327662 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark21(69.76330996938026,100.0 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark21(69.852481280224,80.02891111934156 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark21(69.96297793512647,100.0 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark21(-70.19523956069486,58.51725017644477 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark21(-70.24453219784156,72.75567959504136 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark21(703.5122677876415,-192.1674142138363 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark21(706.0920860063688,-110.0509838719462 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark21(70.61499403417633,-65.36656938641111 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark21(7.068583486537204,-87.6105728263473 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark21(-7.068940146181128,-0.5976618963947518 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark21(70.70706953975042,8.060819583128048 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark21(-70.86898081263307,-13.69314607107627 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark21(71.0409723781899,11.094700639489453 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark21(-71.04829235896267,-35.3080323204647 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark21(-71.10135382899878,-92.41148370007866 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark21(71.1029194925573,31.567356812775415 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark21(-71.24513875211623,98.29903733099707 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark21(-71.3107427123347,89.40846334636647 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark21(71.59598342092798,-67.63669240432935 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark21(71.9426196002099,19.26234545151877 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark21(-7.195012011146446,-84.3144635774848 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark21(72.25663103238566,58.91835624995984 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark21(-72.64852134031582,-3.5543455177952694 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark21(-72.73130546591393,-47.14168918375738 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark21(-72.75095352376582,62.402315626664375 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark21(-7.290294343978951,50.569726713004854 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark21(73.15284828910971,48.2099252486822 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark21(7.3164718968744324,-96.48466575473826 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark21(-73.2775368084906,1.5543122344752192E-13 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark21(73.30361299367789,-100.0 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark21(-7.365857879641709,35.47582947130857 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark21(-73.71642467414338,37.28526246874338 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark21(-73.80128848836263,65.15327575595998 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark21(73.81917422232641,-0.021278974512298987 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark21(73.82742760149644,0.02431629790411915 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark21(-74.04781020079972,21.375761740558513 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark21(-74.10755526558611,51.76478763557171 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark21(74.31160286297376,-37.76329560133649 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark21(-74.41127448097842,25.70173832674358 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark21(74.49148934018727,-100.0 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark21(-7.463061388296268,-12.547285898744164 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark21(-74.82609749495397,-25.950111913727753 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark21(7.490352490428194,-9.72071376477939 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark21(75.06103590169673,9.235178655420853 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark21(75.10983765422787,15.850833860067354 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark21(75.39822368615502,4.304261218171329 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark21(-75.40212993615518,0.06115932566815722 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark21(75.52456381372608,14.928175839236655 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark21(-75.7776814216883,16.37551325474452 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark21(75.93338968521454,-93.69830785993616 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark21(76.373679452241,71.51567217662047 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark21(76.54245757630707,-89.58011068236489 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark21(76.60510855909803,-17.42054581025184 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark21(-76.79582532805449,96.25551586633964 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark21(-76.89656683138422,51.02998733342642 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark21(-76.99553752933959,29.664266338780067 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark21(-77.09536014052097,20.323573535200985 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark21(77.10146001076902,-74.28647608236739 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark21(773.126683301772,-14.886494403486637 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark21(77.36218600559792,35.12562204237 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark21(-77.99385349975898,14.849071839758366 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark21(-78.22257162934807,-47.17527230938231 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark21(-7.84690244424813,-99.74561183948248 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark21(78.53981579839693,4.118742938066041 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark21(-7.853981633927014,0.23260402212606576 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark21(-7.874923525009137,3.5011025035006478 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark21(-78.96328700352288,-55.88293066934995 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark21(79.27399824206633,84.62673529258234 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark21(-79.2943536370394,216.3591372326687 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark21(-7.937615969816999,30.534304054992845 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark21(-79.5826046522264,87.18266074937205 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark21(-79.77677999855143,-1.3787341621914493 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark21(-79.78740629197262,-95.78923303849605 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark21(80.07525917795698,-69.24060586429839 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark21(-80.11061266653972,84.50998409493867 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark21(-80.11062055539986,0.058559377294499976 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark21(80.15664611086254,-54.53584622487868 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark21(-80.22197353588832,-98.19683101354128 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark21(80.27480236235309,0.019567738325964257 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark21(80.31210158433174,44.40006265280755 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark21(-80.32946253144331,-87.47674147961537 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark21(-8.06815091518975,-69.03137251993871 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark21(-80.7377148136722,-77.38916735862512 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark21(-80.79485998557749,-42.69826208042746 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark21(-808.0613299110134,-109.72406444376435 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark21(80.8729783196624,-70.26940121841504 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark21(-80.89601130677434,0.8311969988074281 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark21(-8.103981633974499,-0.19383019333028528 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark21(-8.105662371860008,2.8513790396652006 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark21(-81.14351334175598,23.621705200000463 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark21(81.14716542621068,-0.019357377655085998 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark21(-81.34512847197203,60.30109108734993 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark21(81.58297536273759,99.48527145982386 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark21(-81.8513666617301,-86.5753005214437 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark21(-81.9992840318783,-68.70173999394706 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark21(-82.16248747736236,67.25097649377085 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark21(-82.46680715672981,-70.98843960085934 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark21(82.5689066518593,66.60829131045247 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark21(-82.8064185868299,7.007618069588915 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark21(82.92459313445531,-89.29686329019282 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark21(-83.01249463145099,21.030275780659565 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark21(-83.15184752686058,64.25460575542233 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark21(83.25220799982812,5.3246875274915 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark21(83.2522091348268,0.019099603357281142 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark21(-83.27996081424453,-91.73020709470117 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark21(-83.37854544770056,-0.09593826544820946 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark21(-83.37854544770056,-92.34802872138202 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark21(-83.46478597761849,25.045555739927657 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark21(-83.53553900554826,-49.9170162394695 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark21(83.95338870043724,-82.14144876048314 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark21(-83.96626656422175,-6.232102740463773 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark21(-8.40817570654957,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark21(-84.4092882099811,-70.01139769706784 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark21(-84.51867955101002,-21.370959148600505 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark21(84.67116382003616,180.13264053428253 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark21(-84.69666151935338,-47.67029314875662 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark21(-84.75448399244381,52.61145630495598 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark21(8.48144754330842,-14.4450041205669 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark21(84.8248165583484,96.99474427576087 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark21(84.9135810560079,-10.711407414105722 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark21(8.502676599863657,72.17013205611431 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark21(-8.514736069025872,-100.0 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark21(-85.15879669596926,-100.0 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark21(-853.5588834663549,42.94904699799429 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark21(85.45409961906546,-69.28472713601548 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark21(-85.84382573759628,22.950051632999987 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark21(86.25985647965456,79.49685914066197 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark21(-86.51879796691418,98.3112883423176 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark21(-86.66554064805419,-15.781273973244495 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark21(-86.78061363698278,83.06696273861584 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark21(86.8814332953693,-96.71458517354618 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark21(86.95045916952884,58.79386195162041 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark21(87.63813387955702,-75.87437710460236 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark21(87.68911943780603,-23.69594882082599 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark21(87.70083231228799,61.510810210964536 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark21(87.76482209718469,-88.17891027852758 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark21(-87.83331650003612,41.173335972750486 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark21(-87.83825417294318,-0.050069988943278076 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark21(87.90372263736786,65.50961312839677 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark21(-88.0432798375285,4.911264368584838 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark21(88.0718247445185,-63.55710873959279 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark21(-8.808211358128986,73.20121158689571 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark21(88.17655356763959,-41.30568154284127 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark21(-88.38491588059938,20.998207437006528 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark21(88.45948503702894,36.39038282238829 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark21(88.52270671270325,87.83663702066326 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark21(-88.75412510210509,-42.154867231418635 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark21(8.881784197001252E-16,13.568941485853756 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark21(-88.90567659290758,0.01766812184544138 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark21(-88.94767533711507,31.453950780508137 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark21(-89.05505703405463,-135.76804157277783 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark21(89.21399274102023,66.09136094286993 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark21(89.55092339377448,-81.78745369140896 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark21(-901.998814690991,-153.7537839488757 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark21(-90.32078879070656,11.10504376650374 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark21(90.37021252173258,0.03365540745249973 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark21(-90.55307738644076,-95.64031593805709 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark21(-90.5667751556307,34.17861654073968 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark21(90.82417853362787,92.88914712707918 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark21(-90.84969264250815,0.017290056588052494 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark21(9.093810412324391,11.230075689414408 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark21(-9.096505460081389,-26.460580187264952 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark21(-90.99613921886844,-82.70131407616748 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark21(-91.04650764801308,-31.004961707323407 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark21(-91.10618695405414,-58.67100650520074 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark21(-91.12181195410402,-0.018577692491658426 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark21(-91.16122289281404,88.11914873264584 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark21(-91.55358273209522,-72.44892666251891 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark21(-91.83120883117795,73.77094875232589 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark21(92.33617706482318,83.59405509967829 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark21(-92.61574297716335,55.40135135044767 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark21(92.67588276984057,-63.35488557250372 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark21(-92.67698325321612,-0.019438520469828576 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark21(-92.6769835371923,-4.3004704231817925 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark21(92.75371709015099,-35.46534287899502 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark21(-92.80332340846994,-85.5534110216557 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark21(9.304785368672626,-71.77406267034287 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark21(-93.05998400170941,-20.888611174997486 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark21(-93.23234780171832,-6.902887892520161 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark21(932.6733662087188,93.41618163737422 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark21(-9.344888866078293,-152.31557015672888 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark21(93.46201522635636,-44.19262994246154 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark21(-93.71566939675878,90.05847521468036 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark21(-94.20068633544574,96.6754999945621 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark21(-94.20858889767794,18.029170812119787 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark21(9.424777960769378,-52.25057144367638 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark21(-9.4248539007211,90.36440291178671 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark21(-9.434533165033628,5.329070518200751E-15 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark21(9.477058550679196,-87.7341656935975 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark21(94.89323870422221,-50.273938168534784 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark21(-949.0246405727698,-128.17268795167615 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark21(95.2611918643426,56.36285670251246 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark21(-9.535187957967128,-89.324275721354 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark21(95.42941801250336,20.89099741095619 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark21(-9.548467715700367,0.16450768579466057 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark21(9.551118088340417,0.16501651247263283 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark21(9.551118088340417,-23.989439981282246 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark21(95.59768562477564,87.3066251997227 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark21(-9.577616961955467,0.1815327446632189 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark21(-95.81857579827776,78.081517872251 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark21(-95.81940707194185,30.58257033506054 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark21(-95.89568411799178,56.72484355913659 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark21(959.518676389846,-21.52230776585353 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark21(-95.96772775621262,45.670087708673705 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark21(-96.06276161549346,4.811607054322579 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark21(96.26628607801231,17.786566833073223 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark21(-9.630193179255528,-25.929921674498324 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark21(96.37094047070204,-82.96558834428666 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark21(-96.50606385990147,-11.202744449921681 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark21(-96.54313334441171,100.0 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark21(-96.59471839601366,-92.78668506374726 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark21(96.79701010697909,25.527918700524353 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark21(97.07799548645664,94.06057546136682 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark21(-97.39718476128361,0.1084017759102413 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark21(-97.39755988948193,-95.95309470862823 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark21(97.43227637878928,4.813193511432587 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark21(97.43453075663643,-29.490576198046945 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark21(97.48689014204348,-18.6957554188304 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark21(-97.56140262796553,-18.788561772143225 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark21(9.76199419508003,100.0 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark21(-97.67763651863213,21.200028631740444 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark21(-97.76968343675809,93.66274031672444 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark21(9.787433319201085,-79.47153962028884 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark21(9.847753650436914,64.04840138630712 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark21(98.80024822058363,-100.0 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark21(-99.08650871564953,3.3282019839027126 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark21(9.918238403616101,13.626858343043232 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark21(-99.35076129213627,-85.31748566244013 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark21(-99.92595298258098,47.200087046744784 ) ;
  }
}
