import org.junit.Test;

public class Sample91Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark91(-0.002856150501550057,84.82014549642287 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark91(-0.004764710643542984,-65.9782104360292 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark91(-0.010758693635186535,6.293944000814773 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark91(-0.016529021495790826,59.67373139671028 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark91(-0.04358228266754438,-84.86644284135686 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark91(-0.05528008691068298,15.64859988086548 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark91(-0.06341324585311735,62.89526631764898 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark91(-0.08167167658886468,38.57716320442993 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark91(-0.08237228885922188,3.7356100728536177 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark91(-0.08540963280236236,0.0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark91(-0.09216817968265263,-72.3487992122479 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark91(-0.09552432758743482,-1.5707963267948968 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark91(-0.10995190668059338,21.88119666844796 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark91(-0.12483824022563032,4.0E-323 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark91(-0.12824162851537033,-2395.7529974537097 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark91(-0.13167024669246377,34.425579719079025 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark91(-0.13556838225887863,15.572394885690088 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark91(-0.16535651870388168,-48.57979440683236 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark91(-0.17271203702680316,-147.82756675574709 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark91(-0.1786045126352237,81.86001410789535 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark91(-0.18077588224954377,59.5698552961864 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark91(-0.19256474576525306,90.91362220833875 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark91(-0.2102476446863102,-42.76792947766306 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark91(-0.21621534073384716,0.0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark91(-0.21704037254596104,-56.33176533603298 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark91(-0.22034557533547228,-179.09619837060447 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark91(-0.22420305758269454,56.773107640145085 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark91(-0.22944613333925767,1.5707963267948963 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark91(-0.23102999037273553,-71.64993323935548 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark91(-0.26045640201381953,78.89343353566723 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark91(-0.2675535613641601,98.10301970729273 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark91(-0.2831631414179665,27.991170740890173 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark91(-0.309513070372007,1.734723475976807E-18 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark91(-0.3205825300584285,-84.48062294902101 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark91(-0.32770877907146323,0.6040552364213237 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark91(-0.33390012252234313,25.46664135124069 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark91(-0.34776165229604394,-53.754847926829015 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark91(-0.35089386451721943,-53.757968975543704 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark91(-0.3648504517334956,-40.28981136867367 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark91(-0.411879203055517,12.978338683616286 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark91(-0.41861894180282944,0 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark91(-0.4292536159051816,12.995624230264355 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark91(-0.4612150990715932,-28.764067613374635 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark91(-0.4769367020676986,-41.31764119873501 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark91(-0.48010132484811885,1.5707963267948968 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark91(-0.48988934923110605,90.6162976048729 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark91(-0.5235709590817293,38.22268280215925 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark91(-0.5321452563154456,-79.07196159606028 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark91(-0.5386692632739508,46.58522054057295 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark91(-0.540671869312185,70.20562655119414 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark91(-0.5495963494982545,-67.23601414202751 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark91(-0.5684743115432109,8.016673440035891E-292 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark91(-0.5781003738002783,40.13760876809537 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark91(-0.5943397693863264,21.397034663539785 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark91(-0.6208687013418024,20.856933465566925 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark91(-0.6279086239583074,93.43724939792867 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark91(-0.6404225324467538,-41.51135021185679 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark91(-0.6439015554356509,8.881784197001252E-16 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark91(-0.6533022308045957,76.05152591695963 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark91(-0.6615584399738571,-76.18867930344322 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark91(-0.6861365980791849,63.51798966987505 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark91(-0.6898158350508994,0.0 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark91(-0.7354630577524922,8.689314903016887 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark91(-0.7371025565310028,-1.4365261936775047 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark91(-0.7431907000727943,-98.13256296135638 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark91(-0.7480802421131489,62.76790995787593 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark91(-0.8144219488357753,37.69955483876457 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark91(-0.8146935696298278,95.06247317732362 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark91(-0.8611897546657161,13.427961227499495 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark91(-0.880602123715788,32.29652865961372 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark91(-0.9159649301779504,62.06312104170106 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark91(-0.9271776205268113,-123.44929111052875 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark91(-0.9500171301433316,11.424940778300261 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark91(-0.9516197969653971,-60.64188021517147 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark91(-0.9604429578991613,-19.843712753378213 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark91(-0.975354750358785,-4.116947403948578 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark91(-0.9904901343755341,0.0 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark91(-0.9916338675214644,-98.38100612880505 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,0.0 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,-0.5309672078322117 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,-100.0 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,100.0 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,-1.039832226607197 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,-12.566370615245761 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,1.5707963267948966 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,-1.5707963267948968 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,1.5707963267948968 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,-1.5707963267949054 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,2612.6809684207897 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,-27.8274705038436 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,-4.2030456845295373E-286 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,48.12084551709418 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,54.83705255983531 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark91(-100.50275860227961,37.67090553048375 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark91(-100.50948583458903,-1.5707963267948983 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark91(-100.52999387657978,-3.987340980530807E-18 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark91(-10.065862721218878,89.84836640169928 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark91(-100.7412159507215,-35.38334909790576 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark91(-10.153940771040885,3.870755463861298 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark91(-1.0212590611662358,9.860761315262648E-32 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark91(-10.397874307049067,-0.9730963462796872 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark91(-1.0407044306998028,1.5707963267948966 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark91(-104.23059949599785,-89.53797258580133 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark91(-104.46647171363567,-116.29815790892211 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark91(-10.447216757031015,-75.70171384078184 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark91(-104.48738267483463,93.26578889953782 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark91(-104.64488565306344,24.16041314411808 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark91(-1.0465987892528477,-85.86960043617727 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark91(-1.0487714151853458,-86.91582288532886 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark91(-10.490518545454535,-50.29866227967415 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark91(-10.503494027161702,54.84154104311751 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark91(-105.11487389812805,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark91(-1.0540442088717104,-42.928252941385395 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark91(-10.553978755366671,25.42845485246447 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark91(-1.0555041845839253,73.023764410519 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark91(-10.562404592858663,-2612.471015169773 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark91(1.0587911840678754E-22,-56.54866750568084 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark91(-10.595512072279561,-1.1701611733396289 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark91(-106.80866809541104,-1.5707963267948983 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark91(-106.81359667116992,-91.10620221292054 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark91(-1.070399926759668,51.33588238419636 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark91(-10.712072900190469,-15.890684020637266 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark91(-10.71931806201647,2594.285981482988 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark91(-1.073019135136927,-68.04201924383852 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark91(-1.0731321935028892,-99.35306734151762 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark91(-10.76198570860456,42.966412716896386 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark91(-1.0802217627129753,-42.90207538754413 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark91(-1080.4606191860707,-1.5707963267948966 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark91(-1.0842021724855044E-19,21.991148692335717 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark91(1.0842021724855044E-19,40.84070304348822 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark91(-10.939187574925553,50.03027689535369 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark91(-1.095128855925295,-96.88570908266753 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark91(-10.99557428756243,-1.5707963267948966 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark91(-10.99557428756476,-1.5707963267948966 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark91(-109.95752939920264,-75.39822368612622 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark91(-10.999263900635142,34.662464122081374 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark91(-11.025121099916682,-100.0 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark91(-110.40324360348609,-72.95980272789504 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark91(-110.98927898138409,5.806493972305134 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark91(1.1102230246251565E-16,37.699174746935796 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark91(-111.5265391993628,-1.5707963267949054 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark91(-111.6847364233183,0 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark91(-111.9423908608286,-45.96894513544294 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark91(-1.1265814985130114,-1.5707963267948966 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark91(-112.74605797397032,-47.730445940538715 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark91(-113.09494437488482,-72.25666175151841 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark91(-1.1426502343447735,1.1426502343447735 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark91(-1.1428917600036838E-7,12.738093928136294 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark91(-1.1449612098076671,50.0692982624526 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark91(-1.1490126548221356E-33,-97.3971847612836 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark91(-11.543549145785105,50.2008824423215 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark91(-1.1553244005534909E-274,0.0 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark91(-11.557058525938174,-1.0093120884209985 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark91(-1.1630469344591947,20.012602855997955 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark91(-117.5777263041991,109.46767225370866 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark91(-11.760091598525179,0 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark91(-117.80972450961335,-1.5707963267948966 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark91(-117.81940947048201,-1.5707963267948966 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark91(1.1858112333077457,4.659946547596718 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark91(-119.04590249373793,-1.4270019158546876E-20 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark91(-119.16767018261257,-0.21285244377327778 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark91(-11.933487041636951,61.26900437902097 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark91(-1.2026467426641902,6.212004733061137 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark91(-12.028367996168093,30.877923917706852 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark91(-12.110759987679927,0.0 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark91(-1.218716450557762,57.76738421517404 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark91(-12.240063942199427,-0.3263066721597459 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark91(-12.287826540912988,-43.36165947214705 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark91(-1.2330639167956172,1.233063916795617 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark91(-1.2340489314154914,20.756967494258532 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark91(-123.49065020849054,-5.701076403478211 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark91(-123.64950772614037,-78.37994792401447 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark91(-12.418660394451237,-0.1477102199079359 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark91(-12.430858167446686,-2628.7799810080987 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark91(-1.2435273682655242E-15,-28.274335264893516 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark91(-124.4088894385622,83.93003108941545 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark91(-12.475858614254943,-1.5707963267948966 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark91(-1.2495972255135648,-1.5707963267948966 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark91(-125.44404186366303,-6.533185307179589 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark91(-1.2545932940816407,-2510.215726280362 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark91(-12.566370614359169,3.1554436208840472E-30 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark91(-12.56637061435917,1.9721522630525295E-31 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark91(12.568323744499686,-53.406819671604445 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark91(12.569626281758122,-78.53981582798616 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark91(-1.2621774483536189E-29,37.69911324860586 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark91(-129.14945945818863,38.92712459013103 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark91(-1.2917670187934904,-44.50902090656501 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark91(-1.2924697071141057E-26,78.53981633974482 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark91(-129.6610626146504,3.997356471058675 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark91(-130.29495891496427,-96.52061017791034 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark91(-1.303132710964519,7.147433002772004 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark91(-130.3886928736185,50.219234696365106 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark91(-1.3040278998339927,-69.95690662044518 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark91(-1.3044901402481952,-48.06594286752905 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark91(-130.68807117858952,18.164525354609925 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark91(-1.3241284708118406,83.49866773902826 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark91(-13.3389195435619,0 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark91(-13.421067858661754,-35.412216433790306 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark91(-1.3552527156068805E-20,1.5707963267948966 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark91(1.3552527156068805E-20,90.10618463161973 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark91(-135.59802124638225,-67.58668415701968 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark91(-1.358145596599271,77.18167074314556 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark91(-13.594156746486679,-61.80406693966836 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark91(-136.2910462376722,-26.33530336202943 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark91(-136.67538802811978,-1.5546887298311183 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark91(-1.3699182671470564,89.73626868695695 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark91(-1.370602073754162,-98.76089156844543 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark91(-13.789209975074861,-82.00070927446077 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark91(-1.3800107144141127,-79.91982705415894 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark91(-13.87464038469355,0.5379498137021258 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark91(-1.3877787807814457E-17,0.0 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark91(-1.3877787807814457E-17,1.5707963267948966 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark91(1.3877787807814457E-17,1.5707963267948966 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark91(1.3877787807814457E-17,94.27903089327108 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark91(-13.974075975590353,-38.971708440217945 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark91(-13.993406752301254,-2.1754065144121615 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark91(-1.411118994917362,55.20199020390537 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark91(-1.4130896535073367,-42.56920749674977 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark91(14.137167174844913,-1.196695478361447 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark91(14.137169110560981,-1.5707963267948966 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark91(-1.4163470986578341,57.965014863274114 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark91(-141.8569164786177,0.0 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark91(-142.94246573818728,-1.5707963267948983 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark91(-1.4419706166755402,177.37115921770396 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark91(-1.4442821729962134,-29.718616055304352 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark91(-1.4466046519923053,0.0 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark91(-1.4570335212147696,-48.58092332506167 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark91(-1.4598082815635836,-1.3007796349561859E-259 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark91(-1.4646551235300365,57.52569117589728 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark91(-1.4669904736626531,1.4666076604627298 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark91(-1.4693679385278594E-39,-3.1420821790596443 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark91(-148.3855297120021,69.96900076930112 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark91(-1.4864769710338326,-42.66362252121473 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark91(-1494.2134472107787,-1.4803177745476717 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark91(-149.43734472278277,90.87028623841161 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark91(-1.4952208922146741,45.47751804247178 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark91(-1.50351186367291E-8,91.10618695410837 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark91(-1.504632769052528E-36,12.566370610081497 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark91(-15.06943646042707,0 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark91(-1.5109184564058438,-36.13963337588875 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark91(15.11357332680501,-245.63946517093322 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark91(-1.5293475141205328,1.529347514120534 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark91(-1.5474233269484579,-42.39154937497827 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark91(-1.5474788617457402,127.21118500533747 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark91(-154.8343356440829,-42.662395872729185 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark91(-1.552121769150638,45.3351820676551 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark91(-1.553689564949767,1.5707963267948966 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark91(-1.5547074917905759,1.5707963267948966 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark91(-1.5596673599302706,51.847407751096206 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark91(-1.5597349836317431,26.839103291617405 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark91(-156.07954298187073,16.708052965567898 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark91(-1.560823674022875,29.31485695064316 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark91(-1.564583996972205,-17.28497192456656 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark91(-1.5701019694632383,1.5707963267948963 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark91(-1.5706529186251335,20.42049565650335 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963146416244,72.25681112044965 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796315505024,-54.97787144910418 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796324921265,2402.4375713026875 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963261375855,51.830442205820546 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark91(-1.57079632633826,-48.69468613018572 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326536825,76.95201303033461 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326578909,89.55133056927163 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326660367,7.84692147130883 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326692078,-42.404588085303395 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267448009,1.5707963267498228 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267691565,1.5707963267948966 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267720537,1.5707963267948966 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267785703,83.25220532010663 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267828382,1.5707963267808354 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267833622,-54.962384874743954 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267896607,1.5707963267875353 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267923526,1.5707963267933038 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267929703,1.5707963267948966 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark91(-1.57079632679307,-36.12831551628145 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267935052,1.5707963267948966 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267936322,76.96902001295156 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267937575,1.5707963267948966 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267941434,1.5707963267948966 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267943903,-10.995574287567035 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326794491,-17.278759594740166 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267945708,83.25220532012501 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326794639,1.5707963267949125 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267947138,1.5678946765093453 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267947285,51.78504710149628 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267947846,74.33910199647812 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948486,53.40707511102649 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948524,-31.41592723962923 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark91(-1.57079632679487,100.0 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948721,1.5707963267948966 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948841,-44.19289328794751 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948868,95.80353652654235 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326794886,89.93310735493179 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948877,-49.90624355091806 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948912,-10.98171422151529 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948912,-133.75410661143408 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948912,32.314694686922394 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948912,-47.897073991590275 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948912,58.09967592172493 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948923,-86.39328118574 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326794893,-0.03443053249364221 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948943,-73.82769245257953 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,1.5707963267948948 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,-1.5707963267948966 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,1.585047231493156 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,-1.63E-322 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,-24.62722214522966 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,32.93946428959414 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,-48.69468613064207 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,54.37556598069073 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,65.16266364642705 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,-66.20037770596133 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,69.9534992930466 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,76.97075734786819 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326794894,95.81636766185771 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326794895,-10.99856540914172 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326794895,-48.694755347833926 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948957,1.5707963267948966 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948957,1.5707963267948983 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948957,-2595.6378797219577 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948957,33.015104410163694 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948957,51.83531079380109 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948957,83.25219941878439 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948961,1.5707963267896448 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948961,1.5707963267948966 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948961,1.5707963267948983 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948961,-43.419588487297446 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948961,-48.69434863754366 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326794896,1.556088551590601 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948961,-86.39028985009794 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,0.0 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,-10.994868692560896 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,14.137166941153458 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,-15.129032945024893 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,1.5633531820486748 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,1.5693204165824708 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,1.5707963267948966 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,1.5707963267948981 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,1.5707963267949008 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,1.5707963267949345 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,1.5707963267949765 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,20.401669238829808 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,-23.56194490192043 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,2518.4223694475304 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,-2592.6798102179414 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,26.701706200763237 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,-29.845130209101775 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,-42.411500823460706 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,-48.26759471416866 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,-52.69211296581308 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,89.53539070690256 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,89.53702129407183 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,89.54703904484606 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,-9.037699799706498 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,-98.95888617518514 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,0 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-0.5989023301774159 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-10.42468129701275 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,108.38494654884677 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-10.99557428756379 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-109.95588195545629 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-11.057382227084872 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-111.52653920243546 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,113.09733552880944 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.2382075693141008 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-12.5664011319373 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,128.8126835819307 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-130.36640285170415 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-130.37625246467275 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-13.104996117688959 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-13.221398501901987 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.393440110480236 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,14.137166941152195 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,14.137166941153907 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-147.51491089235438 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5423487136658458E-179 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.551609740834067 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5577629872815002 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-15.707963263982466 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267886975 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267927785 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267936207 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267948735 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.570796326794884 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-1.5707963267948948 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267948948 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267948952 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-1.5707963267948957 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.570796326794896 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267948961 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267948963 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-1.5707963267948968 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267948968 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.570796326794898 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267948988 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267949006 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267949054 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267949197 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.570796326794948 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.570796326795362 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.570796326796317 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5904619848486434 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-1.5E-323 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5E-323 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,164.82106566044922 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,16.641249182624193 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-17.271982958508655 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-17.278759594739945 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-18.13952369756336 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,181.89454047600827 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,18.849741773233923 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,19.23512204188004 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,20.420352248333646 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,20.420352248335032 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,20.420352248338936 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,208.91755259335764 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-21.991148575081517 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-21.99114857512855 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,22.802551065161797 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-23.561944901920135 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-23.56194490192999 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-25.279575342032558 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,2626.3986033015594 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,26.703537555515886 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,26.70353755551816 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,26.705437381884117 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-26.775157213658332 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-28.1155507888332 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-28.365275224629567 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,28.560392436402342 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-29.821629761291472 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-29.845130209100684 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-29.845130209101253 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,31.415926535897867 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,31.415926535897928 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,32.98672286269028 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,32.98672286269058 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,32.9867228626923 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-33.16562107673988 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-33.301775108671286 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,34.664237640361755 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-36.75800127324243 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,36.86735124078653 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-37.699113522508775 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,39.46469061649418 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,41.41922149529228 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-42.28059427499045 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-42.41150082346084 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-42.918158907792915 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,4.3368086899420177E-19 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-43.9822971508217 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,45.30944991300747 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,45.55309347704899 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,45.55309347704965 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,45.553093477050204 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-4.712388980379893 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-4.7123889803844605 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,47.2589047389982 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-48.68683486931187 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,48.74579191741643 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-4.930380657631324E-32 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-49.99501682020313 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,4.9E-324 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,50.26548245743668 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-51.30098863450684 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,51.38102913490156 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,51.8362787842289 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,53.38907899927046 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,53.40707511102831 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,5.3852943516399696E-20 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-54.96101266360714 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-54.97571063576494 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-54.97787143782128 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-54.977871437827055 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,56.181267922584524 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,58.119464091408744 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,58.11946409140949 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,59.27918789365786 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,59.48831048560601 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-59.69026041820606 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,59.93047509810867 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-5.9E-323 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-61.261056594931134 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-61.26105674499785 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-62.59584927980738 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,63.30885862401089 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,64.92209156823168 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-66.61830611981509 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-67.5442420521765 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-67.5442420521795 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,68.9152306002801 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-69.1578690907453 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-7.006875234860313 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,70.38706017410084 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,70.68583470576912 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,70.68583470576951 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,70.70836314661054 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-70.82665171831675 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,71.96663165737387 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,75.61116505604912 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,76.96902001294997 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,76.96902001295022 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,76.96902001295237 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,7.8539754578080885 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,7.853981633971475 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,78.55623512776297 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,8.103981633974485 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-81.68143951091275 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-81.85961771439905 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-82.26780494009564 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-8.361089130433666E-199 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,84.85425164692442 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-85.89288868074073 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-86.39379797371753 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-87.96459477828401 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,89.52766729364093 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,89.53539062731056 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,89.5377886807541 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,89.54325882011257 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,90.56907054206769 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-90.69061638090707 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,90.87318505670108 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-92.46591449496526 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-92.67698328089942 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-9.459950171145366 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,9.565930895378045 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,95.81857593448765 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,99.11636760697517 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-99.32069455772566 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948968,0 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948968,1.5707963267947596 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948968,1.5707963267948963 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948968,1.5707963267948966 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948968,1.5707963267948983 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948968,20.436495544942304 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948968,45.55271485775633 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948968,70.68583470576587 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948968,-73.82742735935688 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948968,83.2502416122166 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948974,92.70729605938672 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948981,-5.141592653605797 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948983,1.55746591300003 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948983,1.5707963267948983 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948983,158.6486994318256 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948983,-19.70208191975638 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948983,76.96054208643153 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948983,86.25593187726105 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948983,-86.37712615910752 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948983,95.80734708753586 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267949072,95.80136622682053 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark91(-15.707963271674258,1.734723475976807E-18 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark91(-157.1112544752348,-37.461985198535096 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark91(-15.72742760838264,8.95122553313766 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark91(-157.35481239859416,-1.2954509951578868 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark91(-15.743939604412885,-0.03597633646391901 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark91(-15.748622021607545,-6.7303432935561744 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark91(-15.748698397137066,3.8518598887744717E-34 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark91(-15.784421007744056,66.04990346518075 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark91(-15.857027821814246,-84.67393709305914 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark91(-15.890841323731635,-61.89480347778562 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark91(15.936843905051632,0 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark91(1.5978504588342004E-24,1.5707963267948966 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark91(-16.206775054752814,73.6497036593342 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark91(-16.2070805584122,4.1415926535917595 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark91(-16.2079586646659,-1.5707963267948966 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark91(-16.2324232690237,-27.749873881233405 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark91(-16.446858918727454,1.5707963267948968 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark91(-16.50169230688681,16.494093353789907 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark91(-16.52022594859075,26.896769795846296 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark91(-1.6609760522069756E-17,-1.5707963267948966 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark91(-1.662070608192513E-17,-53.407075111022834 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark91(-16.69520679714411,-23.46952947877638 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark91(-16.76998539494691,-1.0620221269979446 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark91(-16.770734697983475,-1.5707963267948966 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark91(-16.775718234416033,-1.0677549664670665 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark91(-167.97135775838814,-164.82976510479835 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark91(-16.814347645425883,-1.5707963267948968 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark91(-168.62496492510746,-10.627957507264512 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark91(1.6940658945086007E-21,9.424777014836241 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark91(-16.959610379617544,1.5707963267948912 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark91(-1.7105694144590052E-49,28.274333882308134 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark91(-17.122138128729844,42.56812228947623 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark91(-17.278759594743864,-1.5707963267948912 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark91(-17.278759594743864,80.11061266654515 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark91(-17.278759594746397,-1.5707963267948966 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark91(-172.78759712901638,3.818429940368706E-15 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark91(-172.78857483556348,-1.5707963267948963 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark91(-1732.651217980218,-1.3775233403883047 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark91(-1.734723475976807E-18,-62.697434358920795 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark91(-17.382707364297918,99.06411635763254 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark91(-17.456448968813465,23.73963427599305 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark91(-17.463093969810366,-20.553660755232954 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark91(-17.495970662508796,-1.5707963267948948 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark91(-175.64350120530895,-44.267984545976574 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark91(-17.577508967761005,0 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark91(-17.773153210083905,78.37331762920732 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark91(-17.930451151360295,-19.768660691717223 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark91(-1.7936620343357659E-43,87.96459430164258 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark91(-18.056581289303704,-1.7923377417918651 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark91(-18.166776896153365,-57.3792329999775 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark91(-181.67886702944543,-89.83215209616311 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark91(-181.9827070347259,-0.2299674247279864 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark91(-18.516955765667404,-0.332600155871355 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark91(-18.527076750799594,5.962965789048209 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark91(-18.590458120477365,-85.13687651711311 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark91(-186.29459446937676,-7.223813214758547 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark91(-18.644682719855638,0 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark91(-18.66343715356396,1.5707963267948966 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark91(-18.84955592151061,-3.8490834792511816E-11 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark91(-18.943067600975795,-95.00153176434432 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark91(-19.1850921877831,2671.043595687958 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark91(-195.71718934469925,-4.534963733735324 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark91(-1.9721522630525295E-31,-3.1415942068361 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark91(-1.9721522630525295E-31,62.89435307179587 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark91(1.9721522630525295E-31,91.10616369637765 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark91(-199.06125934921988,-1.5708006703277786 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark91(-199.48877786695206,84.83215373374955 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark91(-2.0194839173657902E-28,-50.26548245743614 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark91(-2.0194839173657902E-28,-75.39822277713424 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark91(-20.327051937464883,7.760681323105709 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark91(20.533266002460635,17.516332411035222 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark91(-21.235245316444207,-78.52586853982324 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark91(-2.1289799200040754E-109,1.4981364335015035E-95 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark91(-213.62566392336063,25.132741235524477 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark91(-2.1658995554019945E-21,34.557519182240654 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark91(2.1684043449710089E-19,5.421010862427522E-20 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark91(-21.810120439092188,-22.440567689394555 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark91(-2.1910496471393152E-16,56.548667764613505 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark91(21.99114857512835,-0.5812558579442196 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark91(21.99114857512855,-1.5707963267948966 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark91(-22.022398575128555,0.0 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark91(-22.022398575128555,1.5707963267948966 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark91(-22.204448388696107,-0.21330303970454653 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark91(-2.220446049250313E-16,2418.535354755756 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark91(-2.220446049250313E-16,28.27433412072672 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark91(-2.220446049250313E-16,29.746940389385685 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark91(-2.220446049250313E-16,-3.8294910408583718 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark91(-2.220446049250313E-16,47.12388462792757 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark91(-2.220446049250313E-16,-55.71283802639962 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark91(-2.220446049250313E-16,75.05600146105495 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark91(-2.220446049250313E-16,84.79107051970217 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark91(-2.220446049250313E-16,-90.96447626947551 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark91(-22.204807447143253,21.947761367084752 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark91(-22.317801366300344,-169.53781404955242 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark91(-22.43345959957881,19.16759585446983 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark91(-22.447910626590726,84.66824500232777 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark91(-22.453872505861256,-84.89147462707115 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark91(-22.464102480224238,42.7335186867304 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark91(-22.66788378422227,61.73106500278601 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark91(-22.679906068214734,40.21511200625855 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark91(-22.726562279515527,-0.735413704386974 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark91(-22.896441485826273,3.0409002203459483 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark91(-22.977961414577862,4.1415926583706 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark91(-23.008600712322917,-26.007138898388703 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark91(-23.014305200513288,-19.872712546923495 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark91(-23.092929023313154,31.204659702126634 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark91(-23.561944901927742,-1.5707963267948966 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark91(-23.775309572214937,65.88713192728179 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark91(-23.819888753513368,-1.3128524752049777 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark91(-238.37883188535173,-0.4284628709826015 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark91(-23.917639383060262,-6.117686923732251 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark91(-23.99487505342553,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark91(-24.01065383027378,-3.5E-323 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark91(-24.17660291283684,-22.8716902405018 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark91(-24.44056613133307,-2653.6230880518024 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark91(-24.470703330758873,-0.6620334368391667 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark91(2.465190328815662E-32,1.0842021724855044E-19 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark91(2.465190328815662E-32,-28.2743345221342 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark91(-2.465190328815662E-32,-37.701064968079955 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark91(2.465190328815662E-32,-65.97344683696224 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark91(-24.684713430399995,-69.80337582701728 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark91(-24.787113559756662,13.124304897903599 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark91(-2.4859661361108045E-15,-109.95574289874881 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark91(-24.904539772017753,-0.2282014567005933 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark91(-24.989474406762366,-2.5749889728608792 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark91(-25.086643218202653,-62.852742097182485 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark91(-25.13274122813052,-56.548667390897535 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark91(-25.132745244799047,-12.566376061905663 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark91(-25.37637060610166,-8.18222518614975 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark91(-2.5849394142282115E-26,28.27433388230804 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark91(2.5849394142282115E-26,6.283185307334859 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark91(26.032468429332226,96.74317256251354 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark91(-26.20397472695987,-78.53981633974483 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark91(-2630.9078092883688,0 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark91(-26.32455247496422,2.5E-323 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark91(-2636.3195166885216,0 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark91(2.6469779601696886E-23,-97.38958549997625 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark91(-26.471880132615226,0.0 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark91(-26.676015035727758,-49.01820719988174 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark91(-2.694664172011233E-16,9.424777960769102 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark91(2.701971781050168E-20,94.24790195592111 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark91(-2.7097658816958675E-17,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark91(-2.7755575615628914E-17,1.5707963267948966 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark91(2.78676072567427,-88.11795677940887 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark91(-27.97079658390929,42.873567969846306 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark91(-2.802596928649634E-45,15.707963267948722 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark91(-28.274333883167056,0 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark91(-28.38371464497815,-1.5707963267948966 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark91(-28.39576074314837,-1.5E-323 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark91(-28.509439705744043,-1.5707963267948966 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark91(-28.586190593563632,-6.6002330577836155 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark91(-28.936404362476353,97.58189129258832 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark91(-29.032511439497256,-18.017733775243073 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark91(-29.31793489356925,1.6649979327439179E-257 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark91(-29.374785258286252,2.462731674775906E-17 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark91(-29.556244692378158,28.27848702144408 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark91(-29.597760016678222,-87.65702597384237 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark91(-2.9719216785561736E-48,-50.26548245743668 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark91(-29.826512424317063,-1.5707963267948966 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark91(-29.84513020910686,-1.5707963267948966 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark91(-29.854978182324285,-1.5707963267948912 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark91(-29.85623795463534,-1.5707963267948966 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark91(-29.86307860514725,-1.5707963267948966 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark91(-29.929816835397926,-44.174404885413324 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark91(-30.071271047098165,0.0 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark91(-3.009265538105056E-36,15.723588267949715 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark91(-3.009265538105056E-36,-59.69032145336232 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark91(30.09630988555,-29.90690514220617 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark91(-301.0788699406168,-0.9064621599242428 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark91(3.0177614634104756E-17,-22.022412436908358 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark91(-30.24140244925202,62.42658251977463 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark91(-30.56926519605328,61.96770156428886 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark91(-307.87305665931495,50.26560452775199 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark91(-3.0814879110195774E-33,1.5707963267948966 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark91(-30.83927590993281,-6.85983593314471 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark91(-30.903854576973565,-91.1061869541196 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark91(-30.94152621558021,-36.17651348888702 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark91(-30.99741062418185,-63.25036898351195 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark91(3.131744545098485,0 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark91(3.1415926535897953,-1.5707963267948966 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark91(3.1415926535897953,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark91(-3.1415926535897953,-2.3503764467829106E-11 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark91(-3.1415926535916125,-1.5707963267948966 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark91(-3.1415926535916125,-1.819311028075792E-12 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark91(-3.1415926535918985,-0.0036707313342329018 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark91(-3.1415926537291092,-1.5707963267948966 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark91(-3.141592668504978,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark91(-3.1415927131944477,-1.5707963267948966 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark91(-3.1415944513896017,-0.23888508541343084 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark91(-3.1415986051887423,-1.5707963267948963 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark91(3.1416002834685335,-1.5707963267948966 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark91(3.14160044210822,0.0 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark91(-3.141601416779074,-1.5707963267948966 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark91(-3.141623171376492,-3.0921518212038E-5 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark91(3.1416541505461906,-0.047077102834177424 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark91(-3.1416693866399497,-0.12499915550740857 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark91(-3.141673529864136,-1.570796323969491 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark91(-3.1417138429202836,-1.2119157975730884E-4 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark91(-3.142080934848023,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark91(-3.1420809351163275,-1.5940791925957154E-4 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark91(-3.1420837249550893,-0.008752279090158275 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark91(3.1420926443683275,-1.570796259054601 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark91(-3.1421159187948646,-0.00781806392158201 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark91(3.1494051535897936,87.96896764439143 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark91(3.1494052384554756,-1.2037062152420224E-35 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark91(3.157651565870013,78.52893154894495 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark91(-31.60202653994662,-78.64335215145493 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark91(-31.656145987053634,0 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark91(3.1728428945989977,-2.0679515313825692E-25 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark91(31.943117524475753,-13.98431893737822 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark91(-3.2002507607165356,-1.0000087575270173 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark91(-32.18498738857794,68.68587148272954 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark91(-3.220806859733983,-106.94342968008085 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark91(-32.28020224565202,-0.864412892618883 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark91(-3.2311742677852644E-27,3.1415921233425723 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark91(-3.2311742677852644E-27,81.68141504085725 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark91(-3.266592653809099,-1.5707963267948966 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark91(3.2666083863929942,-37.59929048344377 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark91(-3.269398462003762,-1.5707963267948966 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark91(3.2847409506609595,9.28589906849222 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark91(3.2996787830793584,-59.78275116201781 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark91(33.036737546116,-82.06622809039932 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark91(-3.3087224502121107E-24,25.13274122871808 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark91(33.49953610210068,-73.51059965823403 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark91(-3.3537071894732833,-14.280143376016415 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark91(-3.389412235989148,9.672597543168735 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark91(-3.4388444648714795,79.79299374007985 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark91(-34.557519428438695,-56.54866745311511 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark91(-34.55752682165998,31.447178530664747 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark91(-34.558495751988794,147.65485461254679 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark91(-34.565331689487735,72.25663022751837 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark91(-34.59857535013689,-0.04105616064916483 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark91(-34.616839335773946,-79.42538400953218 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark91(-34.62185641562525,-13.900917072880631 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark91(-34.69012240291123,0 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark91(-3.469446951953614E-18,207.3490513937743 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark91(-3.469446951953614E-18,69.11503837897544 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark91(-34.706096966415004,5.404142682755175 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark91(-34.81477380170021,63.94271233893399 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark91(-34.85185628770549,-2606.0387280282653 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark91(-34.85541917911492,-20.206242641700484 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark91(-3.4949569568750345,-6.660575017357503 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark91(-34.95150024341204,9.424786590548138 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark91(-3.507125214856271E-12,219.91205278025632 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark91(-35.15509497820785,-1.5707963267948966 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark91(-3.516629407703917,42.729895482627086 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark91(-35.17119162885926,-98.6496621287425 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark91(-3.521233298613708,16.08760391297288 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark91(-35.26236908199138,22.749204058554028 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark91(-35.30646972600516,66.46088803616857 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark91(-3.552713678800501E-15,39.45968852326095 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark91(-3.552713678800501E-15,-57.83631549433261 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark91(-35.5426943164983,-69.85486696018121 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark91(-3.556413999176124E-161,2.8853058180580424E-129 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark91(-35.73177257901834,1.5707963267948966 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark91(-35.82954373257305,54.67909965411181 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark91(-35.865778181048185,0.7635674819266143 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark91(-35.88814997998915,-31.198690258945774 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark91(-35.90020131907914,-39.4980223670759 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark91(-35.9072947745471,167.85418622531841 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark91(-35.95728069184952,-7.604366265180639E-211 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark91(-36.00214545515583,-4.311883746742284E-23 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark91(-3.6053449898504026E-16,-81.68140873233465 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark91(-36.113218131228265,-1.5707963267948974 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark91(-36.12831551627815,-1.5707963267948966 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark91(-36.12831551628088,-1.5707963267948966 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark91(-36.128315516281106,-1.5707963267948966 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark91(-36.12831551628232,-1.5707963267948966 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark91(-36.12831551628262,-1.5707861769959954 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark91(-36.12831551628262,-1.5707963267948966 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark91(-36.12831551628778,-1.5707963267948966 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark91(-36.1440350689994,-1.5707963267948966 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark91(3.6277620952216516,-91.59235639573586 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark91(-3.6350586961654496,0.23724237023416217 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark91(-36.576969066779725,19.43289160231967 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark91(-36.639936520859706,-13.887585015872538 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark91(-36.65213427774946,0.9002224611746925 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark91(-36.705500734598616,5.2895741987006835 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark91(-36.743459818188825,48.61763198239946 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark91(-36.82910393847038,2575.524656942975 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark91(-36.83205642697565,70.67775605670727 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark91(-37.20374923577543,-32.251367420712754 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark91(-3.722440012553297E-14,-9.424778219912238 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark91(-3.73237212616193E-8,1.5707963267948966 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark91(37.34998714767073,-53.38523577688821 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark91(-37.53986004095973,27.934130821419984 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark91(-37.69911179576534,-81.6814089930349 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark91(-37.69911182490515,3.141592653402751 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark91(-37.69911184307751,-1.5707963267948966 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark91(-37.69911184307751,1.5707963267948966 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark91(-37.69911184307751,-6.776263578034403E-21 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark91(-38.18580840256249,46.22999574210877 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark91(-38.230150616320536,46.083758032395366 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark91(-38.23771513071652,-67.91172338927007 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark91(-38.2423310709801,-56.049856084689026 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark91(-38.37799854447044,14.121203433742394 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark91(-38.48024404981316,-1.897623392263867 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark91(-38.54614615878238,-90.08230289904374 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark91(3.9352696203121202,-3.9352696203121202 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark91(-3.981332451225836E-9,-87.96459762282257 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark91(-3.9921556001235407E-16,43.982297150276594 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark91(-4.013157096512739E-4,-113.0968457904717 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark91(-4.023038602199875,-1.7301408504765305 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark91(-4.0389678347315804E-28,28.27433261392782 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark91(-40.53854185067887,1.6625176746312604 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark91(-40.844610746667875,0.0 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark91(4.085349664290508,-98.3331292719843 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark91(-40.90150728942119,-0.060802792753877635 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark91(-41.0632994033461,19.667270771148964 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark91(41.06737290222213,-53.5461023298381 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark91(-41.10234751736588,43.73858519565381 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark91(-41.11170454827301,-53.0232175962188 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark91(-41.34722637033725,0 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark91(-41.393454542428174,-63.85633300970939 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark91(-4.141592653589794,-1.5707963267948966 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark91(4.141592653589794,9.366435542849436 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark91(4.141592653589794,-99.92182811232806 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark91(4.14159265359014,28.26732904319727 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark91(4.141592653590273,-28.429705428187166 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark91(4.141592654496458,-56.31399272773853 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark91(4.1415926689512155,-1.5707963267948966 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark91(-4.14639863094385,-1.0045192182448073 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark91(-4.153451452234528E-52,1.453255501512531E-51 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark91(-4.156411459920294,-2.126773847259292 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark91(-41.5703435603832,-49.21570149774924 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark91(-41.708149312413354,-0.8674448157460423 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark91(-4.1809807728335365E-15,3.3654300266722226E-11 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark91(-41.909879678865416,-1.0691959281595993 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark91(-41.943627013033236,-1.5707963267948948 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark91(-42.001537092925375,-25.0196702188358 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark91(-42.01080539511568,2610.6252330732764 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark91(-42.09315684381087,-1.252452347143555 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark91(4.210430150003275,-4.210430150003275 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark91(-4.210690353903761,-83.75390394661045 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark91(-42.117851322594376,-70.12380354783573 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark91(-42.27034774049498,24.264530079246256 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark91(-4.228117723306794,20.01989886685989 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark91(-42.284523998565724,15.707963267948966 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark91(-42.320381696881505,-1.479677200214192 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark91(-42.33387173041595,89.95921013725456 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark91(-42.343789870297456,-1.5707963267948963 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark91(-4.2354312270556695,-13.66020918782505 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark91(-42.404623986794995,-1.5707963267948983 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark91(-42.416289795399756,-1.5707963267948966 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark91(-42.42062734902333,-1.5799228523560107 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark91(-42.53650082346221,-1.5707963267948966 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark91(-42.61507622953601,87.42399092792053 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark91(-42.64275028973992,-16.14459907649882 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark91(-42.644879908466315,-3.7453410837537587E-96 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark91(-42.6501092591936,-1.5707963267948961 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark91(-42.67269560393006,0.0 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark91(-42.69869916147788,0.0 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark91(-42.73105848154566,0.0 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark91(-42.738554265695505,-14.522775795735171 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark91(-42.742673112421144,-1.239624037835961 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark91(-42.771719153646174,2538.5622320924103 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark91(-4.277477798344833,-82.81729413808966 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark91(-42.79768731719325,-2481.677101541229 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark91(-42.80170138128882,-52.58716290363049 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark91(-42.80441482998587,-1.5707963267948966 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark91(-42.83881746074255,-0.5402670645344472 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark91(-42.865227158052484,-52.9004166738264 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark91(-42.874173296103145,2.678920180948859 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark91(-42.90990034875621,-29.54622362817723 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark91(-42.938889834432025,-27.009109221895734 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark91(42.955629337883494,95.6208487142834 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark91(-42.959992152851044,26.657160309117018 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark91(-4.3020853402237265,87.57838863789684 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark91(-43.11744577856056,-14.843111896252418 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark91(-43.27002762539913,-0.8584815471787297 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark91(4.3368086899420177E-19,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark91(-4.3368086899420177E-19,1.5707963267948966 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark91(-4.3368086899420177E-19,2.1684043449710089E-19 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark91(-4.3368086899420177E-19,-28.27433388230881 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark91(4.3368086899420177E-19,-43.98229700298432 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark91(-43.460365548783365,-37.10853588030017 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark91(-43.58321692707783,59.476714845703725 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark91(-43.5879209543449,-0.39437619591220313 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark91(-43.58828500490356,18.455543776185216 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark91(-43.98229705129072,-56.54866733986827 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark91(-43.98229715072277,-1.5707963267948966 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark91(-4.398387377667632,-1.2567947240778385 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark91(-44.014484731578605,-90.63458827254912 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark91(-4.405905658210444,1.5707963267948966 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark91(-4.4265580524993595,-1.856627254680227 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark91(-44.49078375113606,8.673617379884035E-19 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark91(-44.5893035569122,-42.18141722630448 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark91(-4.459667237420761,45.77325328533618 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark91(-4.4841550858394146E-44,-15.723588268224676 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark91(-455.7944778137954,-0.6037879183691746 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark91(-4.563662670496751,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark91(-4.624190755781458,-45.641291701655234 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark91(-468.59575634669915,-1.0667947723619675 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark91(-4.692512885867337,-1.5906724214904504 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark91(-4.712388980381868,-1.570796326793484 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark91(-4.712388980384554,-1.5707963267948912 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark91(-4.712388980384691,-1.5671303489027477 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark91(-4.71238898038469,-1.568737614566854 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark91(-4.71238898038469,-1.5707963267948877 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark91(-4.71238898038469,-1.5707963267948966 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark91(-4.71238898038472,-1.5707963267948966 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark91(-4.712388980384922,-1.5702980890098637 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark91(-4.71238898038669,-1.5707963267948966 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark91(-4.712388980405999,-1.5669183725220983 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark91(-4.7123889928621425,-1.5629105122521647 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark91(-4.7123890072747905,17.27875982976657 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark91(-4.712389046011434,-1.5707963267954919 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark91(-47.12445657675675,-5.667750251628137E-4 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark91(-4.7140857597384995,-1.5690995474411549 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark91(-47.255976220913084,0.0 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark91(-47.27443308758625,0 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark91(-47.38202733084278,-51.55096538381766 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark91(-47.410563188017996,39.11839705441963 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark91(-47.45239787594726,-1.5707963267948912 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark91(-4.74743850201962,-1.6058458484298288 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark91(-47.482761995825065,-113.19247182380434 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark91(-47.498131585408274,-43.45840119344291 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark91(-47.534674557071675,-1.5707963267948966 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark91(-4.766953184668974,-89.48082642302482 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark91(-47.675372055067974,-90.03337229977556 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark91(-47.72190042919031,1.5707963267948948 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark91(-47.722105175149366,35.88396125466241 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark91(-47.72547858980116,44.04999586867006 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark91(-47.7520295471751,84.42391190369685 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark91(-47.75270529970249,62.076974533515845 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark91(-47.823370752493965,75.92247580018083 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark91(-47.83395039358276,-19.920689472421387 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark91(-48.0064763016895,-0.8825864978426043 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark91(-48.020503785229614,-84.84888516221916 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark91(-4.8085214080396055,-1.6669287544498121 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark91(-4.8148248609680896E-35,-72.25663103256505 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark91(-48.22241533103957,0.0 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark91(-4.833045265275804,4.591732695493575 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark91(-4.842168042262716E-16,91.10618695410298 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark91(-48.44370225399941,63.569203048871145 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark91(-4.8463708775849925,-1.7047782239952003 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark91(-48.507606195365405,-1.3837163915185062 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark91(48.547148749167036,-26.681303410910857 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark91(-48.69190347174885,-1.5707963267948981 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark91(-48.69468613064434,-1.5707963267948966 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark91(-48.69840808059777,2.0790819531289798E-112 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark91(-48.7061087975838,-1.5693020964015407 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark91(-48.71821812991231,-72.87345044170743 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark91(-48.73293612512235,-2381.162070644245 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark91(-48.73529156957812,70.73752066678516 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark91(-48.747828836087635,-1.5707963267948968 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark91(-48.768106393724864,0.0 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark91(-48.77284707319898,-72.25663103256524 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark91(-48.80197528828664,-1.4635071691500507 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark91(-48.91682186685491,18.58147102919463 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark91(-49.148425179353005,-1.1169076864179084 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark91(-49.20247851682882,15.712084475712816 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark91(-4.930380657631324E-32,0 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark91(-49.33869145515586,-3.7395657010123646E-11 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark91(-49.34298067877323,1.5707963267948966 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark91(-494.14787484749974,-1.5707963267948966 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark91(-49.69818029749614,-21.067900442454878 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark91(-49.74466880906779,-0.5208845610406331 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark91(-49.747386547074115,-0.4430714783304889 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark91(-49.764550066368464,-0.5009323910682275 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark91(49.801039540414195,57.24690116380356 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark91(-49.84240594836628,-0.42307650907041444 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark91(-49.86703267363571,-31.528593540994066 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark91(-49.9043106594133,-71.71574580963882 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark91(-49.918858242089584,-51.40865269055718 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark91(-49.94920867533581,-57.47394600338893 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark91(-49.98631403924704,-40.254673347469236 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark91(-49.99973471593958,-26.191537500651048 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark91(-50.072706587768096,-100.0 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark91(-50.12227370972664,-76.48023103338332 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark91(-50.132129723970365,1.5356895374291261E-238 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark91(-50.18608260681602,-28.19493403168747 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark91(-50.21001460489694,3.197060506131507 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark91(-50.25776191042389,-37.70683239009032 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark91(-50.265450600694614,-9.42477796092973 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark91(-50.265482455087636,-2.0194839173657902E-28 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark91(-50.26548245746583,-1.5707963267948966 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark91(-50.265638687612494,-2.1175823681357508E-22 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark91(-50.320904119442766,0 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark91(-5.038743753107467E-11,160.22122606661853 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark91(50.487492472693276,-19.355819833199178 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark91(-50.72707011906683,0.0 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark91(-5.076643511652828,-76.6047654816818 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark91(-51.178629552112696,63.98378470471272 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark91(-5.122313655512055,93.08690795602627 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark91(-5.127139722853219E-10,-37.6996001246158 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark91(51.941710483083654,84.37832685263106 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark91(-5.199408974407393,-70.19881471174764 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark91(-5.221013536795696E-15,25.132991295623846 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark91(-5.251779899548808,-47.98417570507223 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark91(5.293955920339377E-23,-21.991155456968453 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark91(-5.322299140436627,-53.575452037448514 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark91(-53.407075663204964,47.12388940216788 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark91(-53.40709037270563,-157.07634864037297 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark91(-53.604650501530045,0 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark91(-53.66937727895047,-1.66593504405011E-11 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark91(-53.692239646935114,-90.80184430255044 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark91(-53.69743220317611,-1.0E-323 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark91(-538.416688977954,-0.7874208672284795 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark91(-53.96892613317679,-82.07998177283514 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark91(-54.14966817263631,-38.67945815704377 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark91(5.421010862427522E-20,-1.5707963267948963 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark91(-5.421010862427522E-20,1.5707963267948966 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark91(-5.421010862427522E-20,-37.714736843077524 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark91(-54.32887116505445,28.34158585009692 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark91(-54.421075674650375,112.72640630442834 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark91(-54.82288825900989,1.9721522630525295E-31 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark91(-54.87827207688126,-1.4711969658547743 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark91(-54.97787143782015,-1.5707963267948966 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark91(-54.97787143782064,-1.5707963267948966 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark91(-54.977871437821655,-1.5707963267948966 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark91(-54.97787143782309,-1.5707963267948912 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark91(-54.977871437823616,-1.570796326793019 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark91(-54.999831060638066,-1.5707963267948912 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark91(-55.00259330308007,-26.67881569025456 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark91(-55.00323400889706,-58.624465108804124 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark91(-55.04928191086596,-20.01677164667906 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark91(-55.095803136841575,-2.9576304654169368E-272 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark91(-55.10098406834251,-6.5782859923487464 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark91(-55.12234804026583,100.0 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark91(-55.159041191946976,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark91(-55.16020165579833,-1.4728927593382894 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark91(-55.19615630984234,-24.286672770672 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark91(-55.32999061442303,-1.2186771501932463 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark91(-5.533285339859752E-14,-103.67497214530077 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark91(-55.39719050191722,42.80849368934619 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark91(-55.41796057291822,-1.13070719169806 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark91(-55.42280122341345,-1.1258665412028273 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark91(-5.542719424866078,13.883991376971764 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark91(55.4373703127126,38.47485732757133 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark91(-5.548413510279572,5.548413510279572 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark91(-5.551115123125783E-17,-1.5707963267948966 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark91(-55.570550507133,46.2048027029922 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark91(-5.5728797195013814E-42,-12.56637061435917 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark91(-55.88133332178023,-1.5707963267948966 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark91(-5.596121587396068,-98.93537020235772 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark91(-56.016587829045086,-0.5321097989491175 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark91(-56.082193028369176,-54.13504426249273 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark91(56.090390028313465,34.914296523937594 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark91(-56.095325002619,-13.291445660809572 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark91(-56.118068441067194,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark91(-56.162456691897944,-0.3862110727183343 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark91(-56.18333079903303,-32.617893919808154 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark91(-56.20283123357298,-90.66612619139313 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark91(-56.212550168820535,-0.33611759579574363 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark91(-56.24588170966172,-1.5707963267948966 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark91(-56.25021005569681,-0.4542858862222232 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark91(-56.322732878550745,0.0 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark91(-563.8765090772204,-1.57079632679487 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark91(-56.39229764980478,0 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark91(-56.41447881128812,3.275781607061136 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark91(-56.42914803103407,2.507506002317072 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark91(56.43208668503186,-87.6674627264655 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark91(-56.45306815897992,-15.635460453143388 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark91(-56.50469407135975,-0.04397369325652754 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark91(-56.54866776461617,-0.05972348419977222 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark91(-56.54866776461625,0.0 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark91(-56.55257401461628,-40.84070153958912 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark91(-56.679365281746946,-181.7897913713668 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark91(-5.691587834972138,5.691587834972138 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark91(-57.656295310959216,0 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark91(-5.765631253852504,-56.39651483259717 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark91(-5.799520163625064,-34.0738540459332 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark91(-5.894569309920072,-1.5707963267948966 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark91(-5.926385873683703,-6.589546617240586 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark91(-595.3315839247332,-1.4363247720132954 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark91(-59.69026099114902,84.82300164598382 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark91(-59.690289816462595,-0.48732967135834776 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark91(-59.751430928691995,-12.494126729738312 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark91(-59.78216061164726,50.149093176776056 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark91(-5.983143100808835E-17,34.68251918948779 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark91(-59.8605609799578,-0.1702959080037509 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark91(-5.990169744424094,-90.56722802830957 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark91(-59.930534853563834,-48.407401178411604 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark91(-60.01306418179892,18.526752157945914 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark91(-60.040330344111986,1.1553244005534909E-274 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark91(-60.06271497399131,-53.49217684486639 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark91(-60.088769150858745,64.39173635162291 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark91(-60.10369100092574,-19.349555995390542 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark91(-6.014287577450389,0 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark91(-60.31276379291475,-2602.275347203991 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark91(-60.358458828114216,-0.6681984099081445 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark91(-60.5326944509164,-0.8424340327103307 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark91(-60.60592613396609,-52.08455524174003 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark91(-60.67261729736734,-8.442421081608114 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark91(-6.0771583115626555,-0.20602699561693094 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark91(-60.8763086000524,-92.3805330162371 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark91(-60.966975201306816,-1.2767147831007446 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark91(-61.037521610046454,-8.46264604037371 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark91(-61.07054486627256,-53.08288520750354 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark91(-61.14058488381821,1.5707963267948957 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark91(-61.24722142509447,-1.5707963267948966 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark91(-61.25977531824842,2597.955426501223 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark91(-61.26105674499674,-1.5707963267948966 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark91(-61.261056744996964,-1.5707963267948966 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark91(-61.261056745000495,-1.5707963267948966 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark91(-61.26105674500097,-1.5707963267948966 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark91(-61.26105674500097,-1.5707963267948983 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark91(-61.28038037375196,-0.019323897139591657 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark91(-61.51139376874108,118.06006153335736 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark91(-61.57375481922023,62.04451702329405 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark91(-61.61225176653351,-47.38746249482462 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark91(-6.162975822039155E-33,1.5707963267948966 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark91(-6.162975822039155E-33,-78.53981633974482 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark91(-6.175645473903873,3.2665926535897953 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark91(-61.848307116450286,66.95699168073124 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark91(-62.31309276707842,-0.5187603023845888 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark91(-62.33354965630895,0 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark91(-62.58899937765807,-181.65245550071552 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark91(-62.63619835956632,0.0 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark91(-62.66256292850558,1.9721522630525295E-31 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark91(62.75853141721038,-78.56012771107233 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark91(-6.283185307178885,-25.13270752738424 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark91(6.283185307296003,0.0 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark91(-6.283185998663955,-147.65319819945125 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark91(-6.289524734871654,-1.5707963267948983 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark91(-62.924657484999756,96.32171921020858 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark91(-62.95024922777861,-22.109544731111303 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark91(6.29881030717961,-43.99276296655917 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark91(-63.22097901651749,-55.105995083262435 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark91(-63.268315501107224,-12.285096289243 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark91(-63.346698897525904,-0.9560380286361925 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark91(-63.3615508264195,79.06442248169785 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark91(6.34568557916708,-94.24973290632403 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark91(-63.619941818729544,-65.13365303014471 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark91(-63.630861771607655,8.0948E-320 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark91(-63.79972794395019,-2603.487207257313 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark91(63.9256152094693,46.50931703588054 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark91(-64.30479121731848,-53.408609504056976 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark91(-64.39198263873226,-1.5707963267948966 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark91(-6.462348535570529E-27,-42.982293525881715 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark91(6.462348535570529E-27,-78.5398163409915 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark91(-65.13560806626104,81.90456585455067 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark91(-65.1659624469435,-79.92739308032932 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark91(-6.568901732308557,-16.037096936346146 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark91(-65.96802704882232,-15.031251925279363 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark91(-65.97344572631698,1.5707963267948966 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark91(-65.9812585880262,94.24790167800722 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark91(-65.98245288121771,0 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark91(-65.99553907839262,3.6740662971949973 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark91(-66.00747162314364,64.98244742904387 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark91(-66.06881314852572,0.0 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark91(-66.45192530360444,40.05030639462707 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark91(-66.46176840561219,-83.25220532012952 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark91(-66.63455905222813,97.77573255474786 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark91(-66.75747505528416,35.20513752291258 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark91(-66.77891389419173,1.2166986024289023E-209 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark91(-66.92020015128682,-83.2900783361676 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark91(-66.93947608897862,-21.83851353592003 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark91(-6.703042568823207,-14.846223932524861 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark91(-67.28406080009144,-31.90883880716416 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark91(-67.487838344577,-38.05496387107722 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark91(-67.54285789878688,-1.5707963267949019 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark91(-67.5442420521766,-1.5707963267948966 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark91(-67.54424205218055,-1.5707963267948912 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark91(-67.54424205218208,-1.5707963267948966 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark91(-67.55282973655608,-33.79093074253005 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark91(-67.7412806017781,-98.61486026605068 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark91(-6.776263578034403E-21,-78.5398163397441 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark91(-6.794894078558151E-10,97.15055262232246 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark91(-6.795480401471376,-62.319557977504076 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark91(-68.19436676249755,-94.70310540232103 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark91(-68.28836696273248,-50.30504613662269 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark91(-6.842277657836021E-49,-75.39822368615444 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark91(-68.56408165797077,-62.0005537483456 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark91(-688.4894429370257,-1.5707963267948983 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark91(-69.09578371198603,0.47241294699356295 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark91(-69.11297462288977,42.401404460164656 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark91(-69.11503837868189,40.84070354913056 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark91(-69.11503837897543,9.909972651171674E-16 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark91(-69.2384979361405,-73.44343197395129 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark91(-69.25760842052799,-50.12291241588416 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark91(-69.34296980482793,-31.42904665659464 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark91(-6.938893903907228E-18,56.564301551082224 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark91(-69.78286337092776,42.90222990383498 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark91(-69.83020293236564,-62.81819615228757 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark91(-69.89140427514934,-38.93441358150835 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark91(-70.14719634098894,-39.462888129796255 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark91(-70.35736414375494,-30.85919615253192 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark91(70.42338040886278,39.18866556021726 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark91(-70.44019475223216,-78.5411688080063 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark91(-7.151884338368986,78.09542340122817 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark91(-7.171957782651247E-43,75.39822368627176 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark91(-72.25663103256525,-7.841453398362593E-15 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark91(-72.25663103426378,-1.5707963267948966 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark91(-72.25668691817494,-0.12410281597909377 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark91(-72.28733301625934,66.00414770907975 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark91(-72.33637973602112,-78.130581616106 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark91(-72.3832581069619,-95.3173671027916 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark91(-72.41711333711002,-26.932990154701656 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark91(-72.4818288201948,1.5707963267948966 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark91(-72.65328302776562,-0.39665199520038 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark91(-72.67552408756761,-70.07712463318406 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark91(-72.78304695987511,-3.2725131090122375 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark91(-72.79173457110713,2.138950351800851 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark91(-7.281113076892339,-1.8227805048890994E-304 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark91(-73.00848242909817,-85.00705012261301 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark91(-73.0354355155151,-37.819545557767796 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark91(-73.06839012409101,79.92183580910205 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark91(-73.07334597090014,4.1223352125421653E-230 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark91(-73.20116354085228,-2632.7031667889246 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark91(-73.28467726290349,90.73587536395306 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark91(-7.335209273796778,-15.136548490096004 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark91(-73.35632625178764,-107.91384544127536 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark91(-73.46568660246837,-50.45374906939229 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark91(-73.50630795729771,-45.59191408919976 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark91(-73.5714989938513,0.0 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark91(-73.82742726077352,-1.570796425388483 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark91(-73.82742735935824,-1.5707963267948966 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark91(-73.82742735936144,-1.5707963267948966 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark91(-7.3918859419097185,0.0 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark91(74.14938620076452,-4.217813202330902 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark91(74.23145191307438,-53.952174351939505 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark91(-74.34834796391758,51.56567904162526 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark91(-74.46820195118715,-0.9297937181756742 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark91(-7.460927452977519,-17.671813775740826 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark91(-74.6610501044103,3.409915766259544E-254 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark91(-74.67085196493177,142.28063906190272 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark91(74.71392910287909,78.703690222857 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark91(-74.77971298829843,-12.642298607190412 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark91(-74.91693212663381,-34.358710669960786 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark91(-75.17296602088703,91.10339642656021 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark91(-7.536970770755781,-36.445326379501324 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark91(-75.38005161196465,3.172842885273911 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark91(-75.3982236861553,0 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark91(-75.51553357443012,-0.11730907602317008 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark91(-75.93178440429847,-180.66482122678042 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark91(-76.0093851273554,2633.298363490902 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark91(-76.09053736219764,-57.11539049267817 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark91(-76.12247731891644,-63.77728706769463 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark91(-76.24287810939688,-100.0 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark91(-76.27990081457703,-76.66764662986607 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark91(-76.6704410043027,0.0 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark91(-76.71595334112625,-41.29695053950406 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark91(76.74938735830892,40.664230648522704 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark91(-7.68216040817892,-9.464417489334198E-271 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark91(-76.89881071310627,46.65394933116639 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark91(-7.691272632158189,-73.41454536361431 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark91(-76.93395954084497,35.904345561754866 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark91(-76.96371134378009,-36.108858994140114 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark91(-7.726622914456614,-1.5707963267948966 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark91(-77.36368924887525,0 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark91(-7.744468747090181,-72.02575236072502 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark91(78.46848934618365,-25.6869687688378 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark91(7.853981633974483,-1.5645876154177312 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark91(7.853981633974483,-1.5707963267948966 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark91(7.853981633974483,-8.259101685765408 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark91(7.853981633974484,-1.5707963267948912 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark91(7.8539816339745,-1.5707963267948735 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark91(7.853981633974523,-84.8495206978659 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark91(7.853981633974666,-1.5707963267948961 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark91(7.8539816339826345,-1.5627251037096133 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark91(7.8539816339831265,100.0 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark91(7.85398163416757,-1.5317213032201602 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark91(7.853981644978741,-0.28246277335948294 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark91(7.854072965090541,-1.5707963267948968 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark91(-78.55544133974485,-1.5707963267948966 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark91(-78.55544163767908,1.0097419586828951E-28 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark91(-78.5554467270969,-9.424905617323128 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark91(-78.56105565835955,85.24213216247648 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark91(-78.68571750814351,15.066303534235942 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark91(-78.69918316638197,-125.82307297022886 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark91(-78.72762712127361,-16.214618452923418 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark91(-78.83144771929416,-72.59361807252964 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark91(-78.93443265205218,-0.39461631230734945 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark91(-79.00946105722812,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark91(-79.03474736581592,56.05373673854519 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark91(-79.10725243205661,60.3858977502918 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark91(-79.12294465929673,-51.675433784948005 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark91(-79.16796900955973,-138.8355854304706 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark91(-79.1775127894833,0.0 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark91(-79.19026813376055,-31.691716294096885 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark91(-79.31266223089266,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark91(-79.34076119327125,22.020973585399805 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark91(-79.4140885127451,-73.1130776743575 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark91(-79.56555238888562,-1.0263072201958716 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark91(-79.58764315757638,-26.637273718929208 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark91(-79.62073767946809,-9.242595204427927E-274 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark91(-79.72430794947869,1.5707963267948966 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark91(-79.73789080969256,-17.09414267628013 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark91(-79.90864752672863,-37.69724553567231 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark91(-79.92930448169369,-42.78219781216116 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark91(-79.97455001769981,-22.620892946509045 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark91(-80.10559197956098,99.74059633712443 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark91(-80.11061266653707,-1.5707963267948966 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark91(-80.11061266653972,-1.5707963267948966 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark91(-80.11061266654164,-1.570796326793622 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark91(-80.11061266654175,-1.5707963267948966 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark91(-80.12511824524762,-39.284413748580306 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark91(-80.13702162980465,4.974154525660566 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark91(-80.33383159834261,0.0 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark91(8.046174333479541,-62.2436960780407 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark91(-80.6670904413799,-20.52199425077083 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark91(-80.74772619799757,99.38644816155261 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark91(-8.077935669463161E-28,78.5398157537196 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark91(8.08174460332359,-64.17495257831182 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark91(8.103981633974485,-1.5707963267948966 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark91(8.103981633975623,-1.3200321778004223 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark91(-81.12378686075951,-59.285941707555104 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark91(-81.68140899319764,91.10618622898272 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark91(-81.68140899333348,1.5707963267948966 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark91(-81.68745838687826,15.760666291231203 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark91(-82.80867750412764,-2640.2628331825485 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark91(-82.89910202786947,0 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark91(-82.91081705883809,-0.7208845617757128 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark91(-83.07826162083545,1.0842021724855044E-19 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark91(8.423281585043085,-11.631527447739543 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark91(8.424777960769434,-1.0003644676107044 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark91(8.424777960796757,-1.0046856575625336 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark91(-8.433758354584419E-81,-1.617361125968202E-70 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark91(8.470329472543003E-22,-18.84955025095944 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark91(-8.470329472543003E-22,-6.776263578034403E-21 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark91(-85.07133661956571,61.71082528887176 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark91(-85.15559424991694,6.303205307807886 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark91(-85.17906459568452,54.94161903136427 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark91(-85.27118776990966,0.0 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark91(-85.27549876587888,0.0 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark91(-85.28687614243853,73.46159364342972 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark91(-8.543154231089385E-9,-78.53981634828799 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark91(-85.7449270102437,0.0 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark91(-8.579776720812202E-19,91.10618512860856 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark91(-85.92813799187448,0.0 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark91(-85.97557161945664,120.393492819175 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark91(-86.02655226984038,67.46339407506795 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark91(-86.08553570535236,1.5707963267948966 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark91(-86.18726812698416,-28.46936943358618 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark91(-86.3718851777044,7.135362256188992 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark91(-86.37278819146337,9.424791854819556 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark91(-86.39239352747684,-1.5707963267948948 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark91(-86.39379797371531,-1.5707963267948966 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark91(-86.39379797371708,-1.5707963267948966 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark91(-86.39379797371932,-1.5707963267896925 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark91(-86.39379797371932,-1.5707963267948963 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark91(-86.4603134508196,-1.5707963267947491 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark91(-86.57351870423086,27.737634413599405 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark91(8.66159688262108,80.91776824115047 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark91(-86.69002767261824,0.0 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark91(-86.73509562237307,-16.312556718199048 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark91(8.673617379884035E-19,81.68140899333461 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark91(-86.76742909686325,-1.197065207671542 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark91(-8.678706458054328E-19,56.5486677646155 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark91(86.84728370240038,87.43574180410991 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark91(-86.87507774003396,-43.0309123344075 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark91(-86.94322407949153,22.723547794570077 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark91(-87.00085045903691,1.5707963267948961 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark91(-87.40572978276799,1.3508068024458167E-225 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark91(-87.4284613756075,-11.574839974356976 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark91(87.60292999176468,59.77318987958944 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark91(-87.77202610129766,47.605771111108766 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark91(-87.94429987096233,67.9159558325411 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark91(-87.9645943004904,84.82300158951293 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark91(-87.9645943005142,-1.5707963267948966 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark91(-87.96459433210032,0.0 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark91(-87.96460955931616,-5.387212440669407E-18 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark91(8.853981633974218,-0.5685429478403596 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark91(-8.881784197001252E-16,-22.341248254519755 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark91(-8.881784197001252E-16,-43.06353703830825 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark91(-8.881784197001252E-16,8.881784197001252E-16 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark91(-8.881784197001252E-16,-92.54324946798292 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark91(-8.881893576877395E-16,8.881893576877395E-16 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark91(-89.20596280132068,0.0 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark91(-89.50757748331766,-15.442194834268832 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark91(-90.23523333404371,-51.448683794309666 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark91(90.29166484579679,80.36596913157658 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark91(90.75765667278296,-49.851958077275114 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark91(-91.10618719467631,-50.26548245733308 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark91(-91.10691049521186,1.2037062152420224E-35 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark91(-91.32318500864208,-14.502815946222555 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark91(-91.36757759295617,-61.66720676255843 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark91(-91.68187790434308,64.99803921050744 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark91(-91.83084753774638,29.431586676179165 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark91(-92.0934696521049,82.92702480181063 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark91(-92.09901942892367,-86.67946840437637 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark91(-92.24970814093206,-1.5707963267948966 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark91(-92.35229124510555,-1.2461040572561721 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark91(-92.39422053013776,56.548670457068766 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark91(-92.55155972422035,2602.3795606174003 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark91(-92.57213520735202,-73.72944469775223 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark91(92.65557626713371,54.16111694330988 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark91(-92.67698328089749,-1.5707963267948966 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark91(-92.6769832808989,-1.5707963267922953 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark91(-92.6769832808989,-1.570796326792312 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark91(-92.69753507078458,-1.5707963267948966 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark91(-92.7917112834409,41.33403335628997 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark91(-92.90710982666674,-60.59848406269283 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark91(-92.92614291834205,94.62434513148816 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark91(-93.11677418676416,-45.16437751161239 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark91(-93.25027431283767,45.06694680727213 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark91(-93.61545163949351,43.69804193866335 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark91(93.6967240953067,30.8964154963885 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark91(-93.80412856735252,-30.022694616884408 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark91(-93.98321190222036,1.2268642565871395 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark91(-94.06982753505865,-0.1777754666152055 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark91(-94.09956437422709,50.11101528389847 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark91(-94.19651448842792,81.61508293964386 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark91(-94.23236231010107,47.13930710143963 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark91(9.424777959974742,0.0 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark91(9.424777960769635,-1.4498695252431584 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark91(-9.424779868126492,1.5707963267948966 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark91(-9.424793307165986,-1.5707963267948968 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark91(-9.424877197124019,15.707963267948962 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark91(-9.425290103789443,-1.5707963267948966 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark91(-9.425670048232769,-8.920874633893894E-4 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark91(-94.42873073060846,0.0 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark91(-94.52217713223273,-68.8080150334159 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark91(-94.53661482822585,-13.337967282474567 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark91(-94.54078260535385,-1.5707963267948966 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark91(-94.65888497018271,-1.5707963267948966 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark91(-9.490891884775081,1.5707963267948966 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark91(-9.604230543755762,-62.9680121936085 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark91(-961.091813447542,-1.5707963267948846 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark91(-97.38940277890929,44.04479715026192 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark91(-97.3971847612836,1.5707963267948966 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark91(-97.5826631131814,-0.19329085189780645 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark91(-97.60248542723514,-55.17994757651243 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark91(-97.77455114126661,0 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark91(-97.8049109843898,-0.415433365425574 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark91(-97.82146480293271,24.327041566559544 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark91(-97.92097687270638,0 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark91(-97.93161482940587,46.72413707570038 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark91(-97.9538057562098,132.0418332014089 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark91(-98.10518973098345,92.21917661255355 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark91(-9.815501091512942,-0.549486986691466 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark91(-98.21667992392659,-0.4962338737032752 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark91(-98.42241620743958,73.28967497872124 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark91(-98.46624599409175,78.01933463594433 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark91(-98.52312257126535,7.2118893394059125 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark91(-98.59364233777545,0.0 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark91(-98.5950961074111,-58.19451384222203 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark91(-9.860761315262648E-32,0 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark91(9.860761315262648E-32,1.5707963267948966 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark91(-98.77289578723646,-1.3828368682239442 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark91(-9.88005283307163E-22,-28.274333882322765 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark91(-98.8461337172691,16.357849199351058 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark91(-98.9601685880782,-1.5707963267948966 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark91(-98.96016858807849,-1.5707963267948966 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark91(-98.96016858808049,-1.5707963267948966 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark91(-98.98210970857198,-1.5491860574259129 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark91(-9.934285024149105,1.1489428868279816 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark91(-99.45537063343215,-24.020365261425912 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark91(-99.48863453691732,61.78071520855394 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark91(-99.52103882316314,-1.5707963267948966 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark91(-99.52365375927579,2503.3510664067694 ) ;
  }
}
