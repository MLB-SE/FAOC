import org.junit.Test;

public class Sample23Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark23(-0.00203960582263521,0.0010198029113175355,0.02380629250877971,8.901145404395455 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark23(-0.004409218283274525,-8.310621280741274E-4,-0.7831935542558109,-1.9671764217576992E-15 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark23(-0.006257602945106168,-0.012515205890212266,-4.784682808280436,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark23(-0.007187357961957149,0.003560578723902509,0.7888864876404743,-135.9333103057255 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark23(-0.008742804927872976,-0.017485609254487867,-0.7810267609212715,0.00874280492415025 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark23(-0.009560634847466727,-0.01912126969493344,0.004780317423733364,0.00956063484746672 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark23(-0.009785281267131102,-0.019570562534262193,-79.4118716973261,-14.909297170145212 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark23(-0.01211527155958423,0.004091454421402666,19.64081012523783,1.5406857149448387 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark23(-0.013159323746613778,0.006579661873306886,-74.26791569485331,-100.0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark23(-0.01322799949826586,-0.02429495229239409,-29.064765835779852,0.4048471518427488 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark23(-0.013335624300065012,-0.026670744825881068,-0.7787303512474155,-47.796537947853956 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark23(-0.014444409304216477,0.007222204652108211,-1.2957196775753432,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark23(-0.014466680591751296,-0.028931307587779398,-0.6185378618347681,-92.49967772511835 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark23(-0.014571799739977909,-0.029143599479955262,-87.64313915847309,1.0224967145586672 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark23(-0.014936210451029996,-0.029872420902059882,-0.9980495761893522,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark23(-0.018495670503606704,-0.03699134100721335,0.7946459986492517,100.0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark23(-0.019033804156603086,-0.03806760831320616,0.05499578207685385,0.01903380415660308 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark23(-0.021589199063426413,0.010790633833621327,0.010961296896424636,-0.7907934803142589 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark23(-0.02218013486501451,-0.032249752449449276,0.011090067432507275,41.7918998676987 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark23(-0.024519472981031853,-0.049038945962063596,-53.44450986570593,0.024519472981031798 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark23(-0.02455634732084601,-0.04911269464169199,0.012278173660423004,-98.96285458860297 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark23(-0.025627375174623674,6.938893903907228E-18,151.56903490275374,118.61198756109708 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark23(-0.026344208520819645,-0.05268841704163915,22.679106471262845,100.0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark23(-0.027384534897783835,-0.054769069795567664,-59.33061412764564,0.811467781302617 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark23(-0.028245960004000203,-0.05649192000800039,0.014122980002000109,-0.7571522033934481 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark23(-0.028921621314545037,-0.008530934982886151,0.014460810657272519,-4.274034920043381 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark23(-0.029243101397285406,-0.03371704912637482,0.014621550698642682,0.0168585245631874 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark23(-0.029445789981989875,-0.050837120755306796,-0.1881700181893198,0.40953061094128984 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark23(-0.03620303131409186,-0.07240606262818354,-14.295099065489262,-42.052003842736966 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark23(-0.03622408301969325,-0.07244816603938567,0.0181120415098468,0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark23(-0.03652383563923713,-3.168497339215457E-34,0.7944107193212985,-26.961455959494923 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark23(-0.03672022662326998,0.018360113302061463,-7.0476548546299895,0.7749176747153707 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark23(-0.03761245740739771,0.016325364679060775,-100.0,100.0 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark23(-0.038555672991960874,-8.673617379884035E-19,0.7854053505238248,6.938893903907228E-18 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark23(-0.0403429999082662,-0.08068599981653235,0.8055696633515813,100.0 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark23(-0.041040546607791495,0.020520273303510146,0.8059184367010852,-1.1510627026350267E-13 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark23(-0.044182548334114724,-0.08836509666822912,-21.630072958247716,3.4501835736720703 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark23(-0.04589308124794465,0.02294654062397232,0.15959890206988936,91.17876765232296 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark23(-0.04675835203472343,-0.06652748098376837,0.7045361408322272,-61.440211939601106 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark23(-0.047212839537437636,-0.09442565542956917,0.8090045831661671,0.832610991112233 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark23(-0.04933197860683143,-0.09866395694498364,0.06702048739674014,15.770583157050908 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark23(-0.04955345906452023,-0.09910691812904043,0.8090480631482482,-1389.2318717280843 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark23(-0.049972717702332414,-0.0999350962811792,-3.5538698846653354,0.0499675481405896 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark23(-0.052482342983385166,0.022889300542422882,0.026241171491692583,-0.7968428136686597 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark23(-0.05286329633134168,-0.10572659266268317,-0.859992910231506,-59.84372578423044 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark23(-0.05495818261722686,-0.08674964431746642,111.15231914483148,-0.7447519274053047 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark23(-0.056702153224714,-0.11340430549073233,-0.14066423006301434,100.0 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark23(-0.05755604736610506,-0.11511209473221005,-0.7566201397143958,0 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark23(-0.05846787756346263,-0.1169202371064862,-87.14790987602707,-28.21574977870245 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark23(-0.05857486432746439,-0.11714972865492868,0.8146855955611805,0.8439730277249127 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark23(-0.05989092171181054,-0.11978184342361269,-0.7554527025415609,0.8452890851092546 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark23(-0.06022523493206276,-0.12038786413571127,0.8155107808634796,-0.7252042313295927 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark23(-0.060494071055284954,-0.027999291884643618,0.8156451989250908,0.7980828890203365 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark23(0.06116011900637882,0.35142460622097593,-0.815978222971407,87.79088328862802 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark23(-0.06187989718338127,-0.12375979436676249,-0.7544582148057577,-1694.149555183312 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark23(-0.06302762860011271,0.031513814260956056,-0.7538843490974289,-1970.9664079338015 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark23(-0.06335814758827416,-0.1267162947219621,-29.784803499390392,0.8487563107584294 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark23(-0.06597083835380055,-0.031402754301151616,-0.7524127442203985,59.06919662779549 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark23(-0.06651057339049005,-0.13302114678098007,0.4085399592452086,0.8449585851195561 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark23(-0.06654136964562873,-0.061968647416129743,0.8186688482202626,0 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark23(-0.06701480661397263,-0.04494439347176336,-0.751890760090462,85.54743048436106 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark23(-0.06755257945026864,1.4035116404735226,89.31721991071402,-1.4871539836342103 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark23(-0.06847426252197533,-0.1369485247484064,-0.7511610321364606,0.06847426237420318 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark23(-0.06893820498797354,-0.13787639805812127,0.7670462536637973,-66.43545116742989 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark23(-0.0695655969612658,-0.13913119392253148,10.389356216209546,-99.30676675658009 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark23(-0.07112558931320381,-0.14225117862640757,0.11062786917407391,-1.4996707374816927 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark23(-0.07169531489720785,-0.14339061460939934,82.94830909011863,6.8656633494382975 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark23(-0.07223021249922379,-0.14446042499844755,-0.7492830571478364,-0.7131679508982243 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark23(-0.07371080665070662,-0.1474216133014129,13.790326591231047,51.277444077005896 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark23(-0.07491117617303952,-4.9530421478277585E-17,0.037455588086519775,8.59956662689511 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark23(-0.07505783112380811,-0.14981602674377179,0.038242309998201954,-0.7104901500255624 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark23(-0.07524178693334116,-0.1504835738666823,0.03762089346667058,0 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark23(-0.07585182261759069,-0.15135370176541427,-80.85807400441311,-0.5177992728217043 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark23(0.07687387094582518,1.724544068686523,0.3914501210181541,-50.34234555041472 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark23(-0.07814086077796342,-0.1561364888039266,-0.7463277330084666,-96.33957927043359 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark23(-0.07821480550177023,5.551115123125783E-16,0.7461699694537962,-0.7853981633974485 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark23(-0.07826521736758629,-1.257786486156657,-100.0,100.0 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark23(-0.07877664803524677,-0.15755329607049348,-3.665169504544067,0.864174811432695 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark23(-0.07904610471567568,-0.15809220943135124,-0.7458751110396105,56.62771398353014 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark23(-0.0790949791398921,0.0020447212181813335,-0.7458506738275023,0.7843758027883576 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark23(-0.0806364103088267,8.771383744104189E-4,0.7888434809848366,-53.363131308190084 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark23(-0.08128472602935742,-0.10445833306789987,-80.02948035196968,35.58668520725943 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark23(-0.08305764378949726,-0.14733355308123236,-40.58091328430153,10.818922275218736 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark23(-0.08450453455934534,-0.1690090691186906,-0.1983645259472312,5.626442254991765 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark23(-0.08503206566280741,-0.0753965326463297,-51.59711652865699,0.03769826632316485 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark23(-0.08530200392435616,-0.17059042655706194,0.39189447949163364,0.2066255430773124 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark23(-0.08574374889597146,-1.3877787807814457E-17,-0.7422822897972502,-77.80787804495479 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark23(-0.08687268104567991,-0.17374536209135805,-16.31890270472518,0 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark23(-0.08751333739002548,-0.1750266747800509,-72.95859247773802,0 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark23(-0.08801499429836435,1.3947663381981676,0.950390206687828,84.90949742908087 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark23(-0.08943567601843697,-0.1781030013232696,0.8301160014066667,0.05330209800685979 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark23(-0.08973912521110045,0.45218567021747025,0.3538740760714023,-152.98482834149567 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark23(-0.09028928447036431,-0.1805785689407286,0.8305428056326304,-0.13324100927946045 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark23(-0.09053276740996807,-0.179123572983135,0.04526638370498404,65.64810260162291 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark23(-0.09075144253760747,-0.0889796929760891,-0.7400224421286445,51.80246998657879 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark23(-0.09124138628368113,0.04562069292798477,0.8310188565392889,100.0 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark23(0.09171041220040288,1.6367314803675221,-0.04410546762747891,-90.41139290761971 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark23(-0.09217297204699015,-2.7755575615628914E-17,0.7403079785016586,39.94199383288124 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark23(-0.0927499661908329,-0.18549993140111898,57.42133971779957,-100.0 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark23(-0.09286524948856087,0.04643262474428034,0.4769623296646744,16.446137239060736 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark23(-0.09451797147718854,-0.189035942954377,0.505654286672481,-40.07407087657999 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark23(-0.09466674586762673,-0.18933349173525335,-0.18932820805326864,-0.6907314175298216 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark23(-0.09621203338368142,-0.19232287791106617,-83.98082722617346,-0.6892367244419152 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark23(-0.09635813436511591,-0.05563835257329716,0.04817906718255793,0.8132173396840968 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark23(-0.09686832422972325,0.04842140293128374,0.04843416211486162,-20.31714694298373 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark23(-0.09717789076442362,-0.18447200364094796,0.6675207979656764,2080.4933480626073 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark23(-0.09848378505910788,0.04924189252955391,0.04945336969262676,70.75001540829398 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark23(-0.09950786621992187,1.2181532219687423,-0.14045315229314098,19.836740074787556 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark23(-0.09979591175810569,-0.19459747942104555,-0.7235275160236803,-100.0 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark23(-0.09994164555721263,-0.19725501367891624,0.835368986176054,0.0999416455572133 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark23(-0.10156814230205602,-0.20313628460411184,-0.7346140922464203,-98.63833679780119 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark23(0.10298602190935907,1.5064111798670363,0.7339051524427688,-93.44497697688504 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark23(-0.10343806762403318,0.046360202779149116,-4.785585898487734,-0.02318010138957456 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark23(-0.10443302937097809,-0.20886605840314654,-48.93328664726513,-100.0 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark23(-0.10461381813269263,1.0208671478499613E-12,0.7339078372029938,36.81154742213374 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark23(-0.10814492499950147,-0.20881663572178677,-0.22117479533760503,1852.387946388855 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark23(-0.10895650128018347,0.05447825064009171,0.83987641403754,41.30071290749203 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark23(-0.10966037089411612,-0.2193207417882322,0.5529417105658374,0.8950585342915643 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark23(0.10972520788597784,0.5372453767359171,0.6071567589484596,72.8117775811745 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark23(-0.11030725619506347,0.05515349331711396,0.055153628097531736,0.7578214167388913 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark23(-0.11033351820973314,-0.22066703641946617,0.28108541423025013,100.0 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark23(-0.11046046775811069,-0.22087783757043788,-0.0993056813194514,61.66310077881418 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark23(-0.11055590001924688,1.3492813565413069,-57.30120250752347,44.09307466545499 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark23(-0.11312676217557072,-0.21847072228649456,-76.90979668163176,1697.3924722229294 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark23(-0.11364125575430428,-0.22728251150860854,0.8422187912746004,100.0 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark23(0.11409389371023496,-0.7314983969189686,0.6622644819673917,-7.740382676370122 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark23(-0.11660050988714965,-0.2331732838851346,-0.7270979084538993,0.1471861653373481 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark23(-0.11685417938494741,-0.2324739927985635,-0.7108014034146264,5.767362312213955 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark23(-0.11738903635033182,-0.06827571000046495,19.033516084365928,-0.92194958339838 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark23(-0.11755450667029048,-0.23034497252695713,0.06120533412228505,-0.6702256771339697 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark23(0.11873181096168994,-0.059365905480845,-4.747416718952598,44.919637601676406 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark23(-0.11903841953015973,0.0581679445276585,0.059519209765079864,79.49411836723361 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark23(-0.1191140691188137,-0.11080255126492278,16.631900486047027,-100.0 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark23(-0.11959805486881936,-0.23919610884443973,-0.786230092416649,272.5135379766501 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark23(-0.11984548518852467,-0.015742331208882743,0,0 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark23(-0.12019381152943534,-0.06904986698195847,-32.33978629794291,-100.0 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark23(-0.12089430880972818,-0.06908246217698655,0.8458453178023123,100.0 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark23(-0.12106488332411475,0.06053244166205737,50.61334711617664,-27.342454088216936 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark23(-0.12117372216285172,0.06058686108142584,-0.43243753935245993,-99.13667749420239 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark23(-0.12197091730852146,-0.1558060587103811,-0.7047312984094529,-45.549064984996924 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark23(-0.1226980304175013,-0.24539606083500232,-60.76882854608525,4.41795022537502 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark23(-0.12301651182940243,-0.24603302365880464,-0.723889907482747,88.00393569974018 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark23(-0.12356818774973216,-0.22748045103554393,0.8469388406400116,0.7477156443119573 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark23(-0.12514275895296442,-0.2502855179059277,-0.7228267839209661,-49.13511299201624 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark23(-0.12522704790561637,0.030097285040819877,0.05499448350699117,-0.015048642520409938 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark23(-0.12876795863161916,-0.1664473644189874,0.7262700335391178,84.36277878239875 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark23(-0.12928138426503666,0.010126712743161459,-21.94905245552906,0 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark23(-0.12948798356419766,0.04598388368515159,-0.7206541716153494,0.7530261675063983 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark23(-0.131615811849314,-0.2632316236986279,0.8512060693221051,-100.0 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark23(-0.13490186043275312,-0.2698037208655059,0.06745093021637656,-72.89724530381369 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark23(-0.1349938436674767,0.067496921833737,0.06749692183373834,-98.1468400625178 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark23(-0.13654541549902713,-0.2730908309980542,-0.7170917943141042,-25.2348891730002 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark23(-0.13700550448789472,-0.05572081724920416,0.08915065513576245,0 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark23(-0.13800940617484064,-0.27601881234968123,3.689633222394625,0.5979707713502929 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark23(-0.13822865639189885,-0.033490171027208325,72.99082507757802,0.016739304998034152 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark23(-0.13862309528645578,-0.21394386461418197,0,0 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark23(-0.13884362375237558,1.6722364906284466,0.06942181187618779,9.458636376669904 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark23(-0.13966053751309473,-0.19495676743725465,-36.84388341992504,0.8828765471160755 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark23(-0.1401872136410174,-0.2432545516099741,0.07009360682050869,0.12162727580498703 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark23(-0.14146487851750586,-0.1445898560839216,-76.08307209263819,0.16028366881796477 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark23(-0.14215411636757241,-0.08515041068631302,0.22064754424091998,0.0425752053431564 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark23(-0.14215753538313652,-0.2843150707662716,0.8564769310890171,-2.982882353279474 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark23(-0.1457967004274758,7.23698047879207E-15,-0.6494404433691733,-40.7757453637882 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark23(-0.14675187656818997,-0.2935037526319964,0.8587741015368272,0.14675186770067447 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark23(-0.14688952797375532,-0.2937790531696109,-100.0,65.73204551119755 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark23(-0.14695762348086555,-0.293915246961731,-0.3288692431536333,0 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark23(-0.1490756811059632,-0.2981513622119263,10.309660727350716,-16.907649603478205 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark23(-0.1491447810423298,-0.2982895620000478,0.0745723905211649,-0.6362533823974243 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark23(-0.14944314114961654,-0.2917549550657934,0.856028779803184,-0.6395206858645537 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark23(-0.1495663215306744,0.07478316076533709,0.8601813241627855,-60.98264450460947 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark23(-0.14962046078062186,-0.2992409215612436,0.0748102303903111,-0.6357777026168265 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark23(0.15115061172668387,0.9236203039638722,-67.51013857553413,-26.370429973068354 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark23(-0.15266004128851024,-0.0865998798690546,-38.010174924468146,49.24788933493711 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark23(-0.15483918164055877,-0.3096783632811175,-0.9424097467437829,0.1582810662918306 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark23(-0.15616615836225378,6.959881260517609E-4,-88.17503474820847,0 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark23(-0.15621999605419248,-0.2566470875525735,-14.578530102563972,-64.53170061512755 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark23(-0.15707963267949154,-0.31415926535898286,-82.46422203780364,0 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark23(-0.1571480745572367,-0.31429614894094,16.817992217405752,0.5146527104264185 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark23(-0.1585872599321244,-0.28721412075442654,-76.74039120229037,9.857988409307916 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark23(-0.15893623769631904,-0.317872475392638,41.865332652063735,-98.99838118782239 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark23(-0.16048485890271103,0.08024242945135507,12.806057777286433,0.7452769486717707 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark23(-0.16077819143093564,-0.1880669306504501,-100.0,-29.750862969945544 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark23(-0.1616095785312878,-0.1521301289815863,0.8274832083841074,88.11071198733971 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark23(-0.16199581571002852,-0.32399163142005527,-0.704400255542434,-12.098803931994606 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark23(0.16351353823017017,-0.08175676911508517,1.5347937796330906,0 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark23(-0.16396556182010563,-0.32793112364021115,0.7706934737399738,0.34795109685070247 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark23(-0.1653326991791333,0.07996391005555104,0.8680645129870149,44.80421599378035 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark23(-0.1656805038720507,0.08215286801494995,0.8647825681418788,0.7443217293899733 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark23(-0.16639283078561742,0.08319641539280008,-0.7022013374178001,-0.04159820769640432 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark23(-0.16778708138436907,-0.3340268050412424,0.0839250631808686,-0.6183847608768271 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark23(-0.1678650506762125,-0.0910490485208677,0.8693306887355545,42.84376392229504 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark23(-0.16891254828712143,-0.3378250965742427,-95.12748290054768,26.649661733004628 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark23(-0.16957295318224652,-0.3391459063644895,-6.904756626060276,-18.50484544757458 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark23(-0.17138488555741854,-0.3427697710054403,0.08569244277870927,-0.6140132778947281 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark23(0.17261624125306788,1.9160288093010305,0.6970966318974323,-0.17261623726742148 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark23(-0.17359052427542565,-0.3471810485508442,0.08679526213771271,-41.11086737123978 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark23(-0.17395551002971638,-0.29289752414789855,0.8695085763163548,116.62376099878509 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark23(0.17527665782241586,1.9183074981268493,-0.08763836683464782,-0.17335720141718827 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark23(-0.17603322018525228,-0.35206644012084454,-91.63840051179601,0.9614313834578705 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark23(-0.17667207231129153,0.04862042079789497,32.667913835025885,-38.67102804383866 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark23(-0.17686218128604161,-0.3537243625720832,-0.6518377735584074,0.6725889526946751 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark23(-0.17706300743598416,-0.2580338282573383,0.8739296671154404,-49.191864667710135 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark23(-0.17794305506447497,-0.2427414461176043,-0.6964266358652108,60.87721163535193 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark23(-0.1790220542199589,-0.3232296679815138,48.02137429427937,-140.9431332355295 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark23(-0.17958693359116074,0.07295378908957548,0.08979346679558037,-91.9280656672409 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark23(-0.18214021522580423,-0.35272237908278425,0.8764682710103504,-100.0 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark23(-0.184100116273362,0.052454222026942166,60.150163333494106,-1787.0240436464965 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark23(-0.18706043874870304,0.09352971980308551,0.8789283827717999,0.7386333034959055 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark23(-0.1887352170851525,0.09436760696623454,-0.691030554854872,-65.75835796601885 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark23(-0.1910605380562046,-0.38212107611240903,0.8809284324255506,100.0 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark23(-0.19116525857424665,-0.01250377665903607,-72.89035035824988,0.11691839453714414 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark23(-0.19133045348761304,1.0889395073015096,-0.6897320748538958,87.4240323405467 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark23(-0.19152988721945935,1.5930919111324523E-58,0.8111380991800407,69.24647985511456 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark23(-0.19156281844750048,-0.3831256368950009,25.724351861416636,14.32706134216792 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark23(-0.19259737796251153,-0.01896801009633479,0.09629854491282762,-0.7486745710941443 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark23(0.19261789459327203,0.38849531287003064,-0.09630735927983895,0.10619055366586125 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark23(0.193969263123209,1.9299469447687863,-0.7714048884813174,-0.1967792500967845 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark23(-0.1939883543519314,-0.2556201173405231,-67.996240188279,0 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark23(-0.196929664647513,-0.3938593292950258,-27.31538601423916,-0.3386014945375855 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark23(-0.19728849869861767,-0.16813407757242893,0.7620862129822111,-0.7013311246112338 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark23(-0.19754878565128553,-0.314663306036584,3.1890662083114023,0 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark23(-0.1977114197533607,-0.39542283950672136,1.1820062759916539,-100.0 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark23(-0.1978497204564171,0.09892475141227763,0.7763052500042451,92.57901211038032 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark23(-0.19897255492671043,1.1541800791604526,0.8848844408629875,-46.13017601949476 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark23(-0.19951362096520528,0.09973677536506388,0.09975681048260264,-0.04986838756972728 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark23(-0.2004767656019837,-0.40095353120396715,10.13543943512614,48.99980720341577 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark23(-0.20252985426959233,-0.40505970853918427,0.10126492713479616,0.20252985426959214 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark23(-0.2048952988543178,0.10244764942715867,-47.58752175291484,22.853064384143767 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark23(0.20538070781685358,-0.6823952892512328,-12.133466110521637,0.3410789211415641 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark23(-0.20555092114144302,-0.3580493709645869,0.33488327016184305,-20.51105818841112 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark23(-0.20591899961359594,0.05687673132829629,-100.0,42.11828793104304 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark23(-0.20616872881371298,-0.07203831468616789,-0.6823137989905916,0.8214173207405322 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark23(-0.20627151330282134,-0.1954165987262118,-39.935332512751835,-52.53487368201869 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark23(-0.20723318882188901,-0.2429420707259395,-20.981738521551325,0.12147103401484953 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark23(-0.20817422188842702,-0.16487473130326702,0.10408711094421351,0.8678355290490818 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark23(-0.20826719358536813,0.10413359679268397,-10.533655986698584,-13.44129179927205 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark23(0.2083834184182094,-0.10419170920910537,-62.11207914348488,0.05209585460455269 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark23(-0.20851255183111697,-0.041093623876259144,-0.5669123644968717,100.0 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark23(-0.21103903516312694,-0.4220780703262538,-0.36587750508000527,66.50648328616165 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark23(-0.21200240316157745,-0.414821256277587,-0.6751157514994086,9.633926942233117E-46 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark23(0.2125857054164572,1.9959677373523463,-99.36014837463458,-92.10394220774526 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark23(-0.21298447125365633,0.10077420521716417,-31.12445777817043,-0.05038710260858209 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark23(-0.21302497266273318,-0.4214202822563421,13.45828126385913,0.9961083045256194 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark23(-0.21451176538712563,1.5777218104420236E-30,10.101755669217894,21.286019520657675 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark23(-0.21456102397560306,-0.429122047951206,-95.03874630579645,7.370958885354213 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark23(-0.21489406671897207,-0.4146901548213144,-83.92985258432594,-0.5780530859867911 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark23(-0.21521321036106045,-0.4304264207221207,57.69743729961312,0 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark23(-0.21604143755637098,-0.4221996822638283,0.10802071877818549,-43.771186481063545 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark23(-0.2167528563005511,-0.4329845255031036,66.24596037740505,1.0032053464684314 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark23(-0.2169658654213467,-0.4339317308426883,-26.452656019397818,99.77749656298165 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark23(-0.21854988256509955,0.10441635097575169,16.20641227713779,96.09545877686435 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark23(-0.21930164838149802,0.1096508241907489,-156.2061542484896,48.48682526130372 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark23(-0.21958275590823406,-0.32068412996769713,-100.0,100.0 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark23(-0.2207059077193767,-0.44141181543875335,0.8957511172571366,-92.2808749465528 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark23(-0.22071024638782802,-8.107982599581374E-19,22.758915430253744,59.60439489266169 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark23(-0.22284289164275428,-0.12499723173759059,0.8968196092188254,0 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark23(-0.22313124080191704,-0.44626248160383397,12.81986260781483,1.0085294041993653 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark23(-0.2242898377028384,-0.44857967540567234,-0.6732532445460291,-91.74225404523348 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark23(-0.22449765509005462,-0.444189576905718,0.2495197752898301,1.0074929518503073 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark23(-0.2247358442528138,-0.44947168850562746,-0.12306108366875934,38.27447770073327 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark23(-0.224979306960641,0.10483593775056366,0.40887983974970293,0 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark23(-0.2256917365495093,0.11284586827475462,0.898244031672203,0 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark23(-0.22570799299732605,-0.45099313716307904,44.88025359911644,100.0 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark23(-0.22571546070176138,-0.4428301325080941,0.11285773035088069,-45.0953831371957 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark23(0.22599978824864897,1.9668399157565901,0.08859160281386132,-11.97819930983421 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark23(-0.2269418010254245,-0.2911729643715715,0.7662654785075242,59.8506424941111 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark23(-0.22794798136628716,-0.45527776105527895,0.8993721540805918,38.651692849099305 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark23(-0.2288165133957878,1.1101533881905061,0.5846493295948211,-88.64455105759575 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark23(-0.2302829286508769,-0.44581783072546544,-1.261911829743914,-0.5624892480347156 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark23(-0.23081574743652156,0.025329762430760232,0.11540787371826078,-0.012664881215380116 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark23(-0.2314935793968692,0.10245248334575338,-0.6696513736990136,-0.9345230527775499 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark23(-0.23149404116194128,-0.4316460003657521,-0.6696511428164776,-48.50389265483931 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark23(-0.23321034346764521,-0.07648333288723302,0.11660517173382261,-0.544951043888608 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark23(-0.23666818080509605,-0.19858033126381125,-0.6670640729949002,-72.15734086680466 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark23(-0.23697866725051941,-0.4656800959531466,0.903887497022708,100.0 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark23(-0.23802170654648042,-0.4760434130929605,-56.37910774884351,0.40296743724978956 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark23(-0.23832989972260066,0.1178218067881759,0.12082612271920529,48.50603418534888 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark23(-0.23943409905832075,-0.47651207842887106,-0.211830900196904,0.23817142082877008 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark23(-0.23981095857582546,-0.2863437166862347,98.06783635170163,-5.283420799767896 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark23(-0.24031099154275376,5.5275711219159375E-17,0.7948417613949034,147.68671644276657 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark23(0.24040441167693455,-0.12868070811402216,84.70814036659372,0 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark23(-0.24043861528060334,-0.3371728616114401,-136.74975790710553,-0.6168117325917288 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark23(-0.2405618793949954,-0.4261828235342565,-100.0,17.969009610520015 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark23(-0.24157342308439442,-0.23379108804603269,0.12078671154219721,0.11689554402301633 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark23(-0.24284547538669216,0.03916732451920918,0.9068209010907944,-0.8049818256570529 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark23(-0.24292339823464978,-0.48552891950690946,0.9068598625147731,-80.92422280104891 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark23(-0.2443753662550563,-0.48875073251010903,0,0 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark23(0.24442946008329441,0.507873245183427,-0.12221473004164721,-99.99909117567424 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark23(-0.24529131385066014,-0.49058262770132033,-90.16229306738366,-100.0 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark23(-0.24776307324608007,-0.18910955186560585,0.8499560830141364,14.08910475618243 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark23(-0.2480885383317134,-0.2846380308076898,-115.18482340971161,13.792733303946955 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark23(0.24867481565157903,-0.13577524556477405,-19.879346342295594,1771.0579182196154 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark23(-0.24876816750553543,-0.4975363348981726,0.9097822471502159,27.2795359775769 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark23(0.24903076437734256,0.9706785859557481,-0.9216212027307452,1.1569797427498867 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark23(-0.2497288620013864,0.12456765528944436,0.5988800157025166,2.252060718012035 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark23(-0.2503014472625674,0.12089513694975182,-0.23298281529569742,-43.72043964810698 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark23(0.2505296163730137,2.0718532926897932,-49.38818664987732,-100.0 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark23(-0.25166359088732204,0.8928431165126732,92.19985040231157,-1.1866485136443905 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark23(-0.2533560389371177,-2.3712052139345537E-38,0.7964601174994308,4.6770549752446655 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark23(-0.2535349986787887,-0.5070699973575765,-0.494100771367602,-41.72399636780852 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark23(-0.25434858078217143,1.0618966869575444,0.8377640631170771,100.0 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark23(0.2544341659368619,2.07966465866862,-0.13031890972404325,-100.0 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark23(-0.2563623522793481,-0.5127247045586927,-52.25571759068796,-16.391571310730882 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark23(-0.2584827028351259,0.04886460488392963,0.13793963320760483,-0.8098304658394131 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark23(-0.2586243220308679,-0.39847971360226236,-0.5763707515546939,-0.5832279173243499 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark23(-0.25865320879962583,-0.503335552118306,0.9147247677972612,46.57191257687407 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark23(-0.2588009689372021,-1.5271872266570145E-18,0.7465351103327211,39.428823615146825 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark23(-0.2590290291521411,-0.25537093399774907,-171.78812132263783,93.56847650369247 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark23(-0.2596525423005941,-0.5002443745672464,147.81338603369892,1.0342200143030769 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark23(0.2601442765984441,2.091084879991784,2.093568845631712,-96.86326809300488 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark23(-0.26032856508414626,-0.5100346547705454,-30.419115059098527,-0.5303808360121756 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark23(-0.26119650613593315,-0.4923927141888691,0.4679757205099775,80.02873330123832 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark23(-0.26342664023654755,0.13171332011826953,0.13171332011827377,-0.06585666005913476 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark23(-0.2647108991411999,-0.518273771383487,-0.6530427138268483,0.03408899251536929 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark23(-0.2662645722420567,1.0382671823107827,0.13313228612102843,100.00777081282057 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark23(0.26658874192756404,2.101522096811936,-0.7750693440180729,-3.121468664106158 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark23(-0.26699789157138787,-0.5171408930019814,69.69883250377602,0.2585704409650355 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark23(0.26759227066140445,0.5351845413228097,-73.26802257097374,-100.0 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark23(-0.2694051443855381,-0.5211600156064784,3.7050543645824097,37.468641391725264 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark23(-0.26947057918968076,-0.5389411583793605,-41.504697075012764,66.08586306992325 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark23(-0.2696031202602034,-0.2822636570815971,0.8914668892222416,-61.12473503024231 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark23(-0.27486298305306894,-0.42647598988238433,-0.5216661492987411,68.00236595202408 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark23(-0.2749986704028782,1.0207989859929003,-100.0,100.0 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark23(-0.2750438614648999,0.13752193073217175,0.9229200941298983,-84.88502079552141 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark23(-0.27610579820043535,-0.09491368031017543,0.923451062497666,-46.50239867067056 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark23(-0.2766471393766119,0.13507248871642158,0.13832356968830584,-0.8435851364992464 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark23(-0.2778765253195841,-0.3792880415438451,-100.0,36.46253886635957 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark23(-0.2821526010561391,-1.0885816821731158E-16,0.31988626930606967,11.488512190903725 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark23(0.28284921652385914,0.5656984330477184,0,0 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark23(-0.28308812664911553,-0.566176253298231,-27.136427247779316,0.2830881266491155 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark23(-0.2835709648778781,-0.563543496928232,12.999639252650205,17.555738985616546 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark23(-0.2846501651855097,-0.30843848974522553,0.9198178980140228,-90.39131443876173 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark23(-0.28528515418963785,-0.3552082986175644,-31.878568946508935,0.1775934588692032 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark23(-0.28672647616007807,0.14000681319842967,0.9287614014774874,0 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark23(-0.2871888299855242,-0.5743776599710482,-0.6418037484046861,109.25342485483618 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark23(-0.29123355753079294,-2.0539125955565396E-15,0.4449339077085804,-58.07935360905332 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark23(-0.29296033146235767,-0.2180557110679429,0.14648016573117884,0.893111098611972 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark23(-0.29322781111630875,0.0,0.7924718930481971,0.01285542456803671 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark23(0.29353248974214624,1.1565186939563223,-0.14673690555054203,-83.83041537012552 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark23(-0.2958954805575835,-0.3702365827640221,0.93334590367624,0.18511829138201108 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark23(-0.2976331819251404,-0.5952663637285284,63.48599204147729,26.987668719420235 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark23(-0.2977524419615734,-0.5952291530018949,0.14887622098078668,-13.572805916461588 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark23(-0.29841540396494154,-0.004554152548015278,0.9058771545787471,-0.6857638653758755 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark23(-0.29878923136970237,0.14939461568485102,16.602891618717386,96.2829452985645 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark23(-0.29954565903400837,-0.5975472505488976,0.9351709929144525,-24.84995540432504 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark23(-0.29987622698586724,-0.25434715544008124,-81.09668042670664,-18.765293145537143 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark23(0.29989708968636836,-0.16015611593274323,-65.05019001758403,-372.2923588179538 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark23(0.3000408953955118,-0.9344898003932912,-48.746672825681735,1.253031789892746 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark23(-0.30068466094890306,-0.5965919706939043,-4.555159824581861,0.29802537260843104 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark23(-0.30178780278671663,0.14867980703685824,0.9362920647908066,-0.8597380669158774 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark23(-0.3018000527651622,-0.38871181980391845,-0.46413102787776694,-0.5910422534954891 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark23(-0.30210808074047546,-0.6022400647807397,44.2323148751828,63.00256451966789 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark23(-0.3027886316392686,-0.42486828891313727,0.15139431581963425,-14.078295428548884 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark23(-0.3028523906235743,-0.6056908052415216,-0.6339719680856611,1.3854668885436183 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark23(-0.302915466287051,-0.6058309325741019,-11.398670830032756,-98.77801699365843 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark23(-0.3029448682185287,-0.5563758097669412,70.09959462826765,-10.895013945208333 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark23(0.30362522051994495,0.6251126251422239,-0.15181261025997247,0.47284185082633634 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark23(-0.30383313900813746,-0.5284280275682867,0.15191656950406873,65.36813964727679 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark23(-0.30386825691604524,0.021389987739325024,0.15193412845802262,32.61363990311892 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark23(-0.3040609147914257,-0.562595074846902,-0.6333677060017354,-26.5070244488645 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark23(-0.3040987699327666,0.053853124101116756,-91.15645844181091,31.400668412222714 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark23(-0.3048617781204818,-0.5905613280785521,0.15243088906024088,0.2952806640579164 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark23(-0.3048810040975827,-0.6097620081951651,0.744019992111606,0.3048810040975826 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark23(-0.30505559863752363,-0.6008848909495927,-0.6328703640786865,0.3004424454747963 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark23(-0.30573217963501537,-0.6114643592700197,-3.061762110236599,-100.0 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark23(-0.306246985263564,-0.3452365473827106,0.3085013810610455,-46.5747314252354 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark23(-0.3064157905987354,-0.6128315803377383,-0.632190268098082,1.0918139535663174 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark23(-0.30730535711831,-0.5700152550554334,-99.48484212541852,0.2850076275277167 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark23(-0.3078248850115789,-0.5911327888759549,0.27074469729029177,1.8256415090136824 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark23(-0.3078320279341759,-0.6136936323290827,-0.6314821494303603,1.0922449795619897 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark23(-0.30840981346970986,-0.6168196269394195,-0.6311932566625933,-21.25446971692651 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark23(-0.3096643944284263,-0.5371140844769795,0.15483219721421326,-1838.2255071226473 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark23(0.3106314674872947,-0.8080554979641847,-0.9327108510136416,23.180548355990513 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark23(-0.31108632396293734,-0.4679651154624892,0.31509489485932074,-19.704424748396807 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark23(-0.3111216940886259,-0.6222433881772517,56.91337577192184,22.134469423556258 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark23(-0.3129817375084378,-0.1666595114765024,0.1564908687542189,0 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark23(-0.31366029133516793,-0.5596876153885789,-59.9598352723893,0.27981733684784693 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark23(-0.31415926523801074,-0.6283185303618429,-0.628318530762244,100.0 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark23(-0.3141592653568168,-0.3330314919841328,0.1570796326784084,-100.0 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark23(-0.31415926535897754,-0.628318530717955,0.9424777960769322,-68.11250565661263 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark23(-0.3141592653589794,-0.16597433106743809,82.90989958889861,0 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark23(-0.3141592653589811,-0.628318530717956,-0.6283185307179577,100.0 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark23(-0.314159265358982,-0.6283185307179572,0.9424777960769393,-99.49869970311097 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark23(-0.3141592653589882,-0.47474655142414857,100.0,0 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark23(-0.3141592907446109,-0.5942944807724676,-0.6283185180251412,59.35164660053074 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark23(-0.31458401087868015,0.15729199991128062,-99.5961601049949,0.7067521634418079 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark23(-0.3150821894330914,-0.5128205187068686,89.2494487292913,0.256410251948602 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark23(-0.3153247286673313,-0.546975320404941,0.9430605277311139,0 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark23(-0.3154801190629662,0.1278544996411984,0.1577400595314831,99.3772482130139 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark23(-0.3166063730733899,0.15705778250482666,-0.8491248259821987,-0.07852889125241358 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark23(-0.3167882874534094,0.9372192029292983,-100.0,38.844066507990895 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark23(-0.3169124988661074,0.15845624943305336,0.1584562494330511,-67.73740930147137 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark23(-0.3172214006316354,-0.6267874630816301,0.6915067767783387,85.01729974740643 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark23(-0.31730341987467137,-0.6267464534601125,-22.2980794631531,-1905.8327082984194 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark23(-0.3183473833081758,-0.5751592431529475,0.9445718550515362,100.0 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark23(-0.31848727842159197,0.14452817673205565,22.33108881364481,8.438052411620303 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark23(-0.3189610187128955,0.15924626226762684,0.15948050935644775,24.575826882733868 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark23(-0.31969755541049555,2.113864638886298E-13,0.017275325106342932,-1989.1615959858905 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark23(-0.3203780517153849,-0.6252091375397557,-40.070526225946864,100.0 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark23(-0.321155175951493,-0.6031320279763741,-11.88167666620295,1926.6558577658082 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark23(-0.3217399538693179,0.16086997693465888,-0.6245281864627893,-73.38845789741637 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark23(-0.3224990825456598,-0.11077214885786243,0.1612495412728299,-1941.9402251516808 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark23(-0.3231944197860439,-0.5643549347990712,13.245944004324524,1.067575630796984 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark23(-0.3242616347540512,-0.623267346020422,0.1363229948607052,-0.47376449038723734 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark23(-0.32497381419391724,-0.5353809233448994,-0.5295548694636293,-0.299941387536605 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark23(-0.3253373254651287,-0.5990675278277084,-0.6227295006648839,-99.24383540951744 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark23(-0.32586185777323134,0.13319715827468814,0.8995060136322688,0.3384581742228894 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark23(-0.3259970294463006,-0.39641557515042525,0.1629985147231503,-53.52956089013839 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark23(0.3261216327464703,1.5625037241052453,-0.1630608163732351,100.0 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark23(-0.3266303834313078,0.16331519171528097,85.96248283482278,-99.8746882596047 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark23(-0.3266946739986062,-0.6033314567199205,0.9016495549327874,103.3475754849666 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark23(-0.3284903919484614,-0.07596256920050404,-11.03865839779317,15.40997097979657 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark23(-0.32875290764517245,0.14730407236582688,0.9497746172200345,0.7117461272145349 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark23(-0.3289449601659239,0.5761309402054926,-0.6209256833144864,-1.8588152065985435 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark23(-0.3290564073644955,0.16452820368224774,0,0 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark23(-0.3293167228598921,0.08834793177529832,-8.136320017409272,0 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark23(-0.33013552042559435,-0.559276894322694,-0.6203304031846512,31.464846920263444 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark23(0.33068748712726836,-0.16710375058186014,-93.62743606022299,-17.306795452966877 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark23(-0.33083139245885845,0.1654156962294292,0.16541569622942923,52.53896973518135 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark23(-0.33202466141594045,-0.6193853886694053,-0.6193858326894781,100.0 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark23(-0.33316130779750924,0.04646548151088692,-0.6188175094986936,98.32374632823395 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark23(-0.3333196767725688,0.1666598383862843,23.693075033416,44.67492797958046 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark23(-0.33347362713372025,-0.5559977175665837,0.9521349769643082,7.226277645606213 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark23(-0.3345125969235239,-0.5955296826121185,0.9342805840504783,72.00180190617128 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark23(-0.33523525620693506,0.1660992259006031,-0.6177805352939807,21.144414102037448 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark23(0.3378028411073356,-0.1696429299402639,-87.3471772273432,-52.11489497759623 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark23(-0.33952286916534796,-0.46944027109483855,0.9551595979801223,1.0201182989448667 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark23(-0.33969472116825117,-0.12391054187601569,0.16984736058412558,3.2039617501138067 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark23(-0.33971348957810754,-0.2462780597161354,-30.40037155687218,0.12313902985806768 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark23(-0.34022254875529995,-0.19307216832955118,-0.39694737425456816,-0.6888620792326727 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark23(-0.34104997789513036,-0.5584288706418477,-54.109537922621314,19.431062010582707 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark23(-0.3411076916573997,-0.6090561668243988,-0.6148443175687485,-33.16523779433803 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark23(-0.34198473083961156,-0.42417711871521807,-0.40431129914744673,-1614.1015023465702 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark23(-0.34490801731436055,-0.6115789599029592,-40.607152241946785,0.3057894799514794 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark23(-0.3456540543079849,-0.6125711362434556,20.10961902530221,-1989.163333583042 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark23(-0.3460245358592502,-0.47770277148428264,-33.734771611751746,2200.885301140978 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark23(-0.3470653669772447,0.013039558057754525,0.9554548665537883,74.13071208740035 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark23(-0.3476602036570853,-0.6115680615688959,0.6854365590858829,-62.888023888138974 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark23(-0.34784647841395394,0.17392323920697694,0.17392323920697697,100.0 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark23(-0.34854193872891115,-0.40232940968715925,0.17427096936445557,-54.319345200683365 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark23(-0.34899449909069397,0.17449724954509593,-94.46790302897996,-52.709545228079236 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark23(-0.34958863849058175,-0.6106038441521571,53.65699099619306,0 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark23(-0.3512742404171393,0.11729054424991621,0.17563712020856964,0.7267528912724902 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark23(0.3531898782713099,2.2485376059637483,-0.9619931025331032,89.19654299005207 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark23(-0.3534462412455712,0.12662795141729932,0.8277605387111608,79.90304255241263 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark23(-0.35424408174043703,0.15842582398478328,-0.6082761225272297,0.7061852514050566 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark23(-0.3551762486239977,-0.6075937810100653,0.7115680143704738,83.54526801690334 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark23(-0.3562967864625317,0.17743652946296962,0.17814839323126586,-0.08871826473148481 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark23(-0.35650552660235113,-0.4192701709264704,-0.539738567410959,0.346176573794023 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark23(0.3570168135778648,2.2471909325376247,-0.9704294913348891,-74.94581388015136 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark23(-0.35778582352793004,-0.6063923610465469,0.17900580235090136,-97.63464828153802 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark23(-0.3590570651897996,0.17952853259489976,-10.309928892742674,97.32008329596023 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark23(-0.3603335686768325,0.1801667843384145,-0.605231379059032,45.869961648348976 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark23(-0.36079799414975006,-0.5612747964066769,0.8978787343353062,0.3194793056167406 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark23(-0.3611666843152295,-0.5631302696619866,0.5983148128627993,100.0 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark23(-0.36319483842050115,0.0893692856477863,0.18159741921025058,74.5681408341711 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark23(-0.36423251319347116,-0.38899085485370705,-12.258436358656347,56.45672347072164 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark23(-0.36652697436754067,-0.5624959625833292,-0.46530085506242624,-88.07986468958927 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark23(-0.36660378732263754,-0.5964531167912955,0.18330189366131877,0.29822655846443213 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark23(-0.367216389146334,0.15274823874219245,-16.941805173354467,34.79379817007755 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark23(-0.36733383925484464,-0.6017312437700255,-2349.0563435711297,0 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark23(-0.3684040410667757,-0.11761242387668341,-0.6011961428640604,-6.333996426806777 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark23(-0.36879840770631833,-0.3517554545774655,0.04098730956100893,-40.307910155719476 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark23(-0.3688361619272692,-0.27607517119717606,-99.23406560007795,0.1380375855985878 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark23(-0.3688631183918356,-0.01944957763812022,-100.0,150.77429484498603 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark23(-0.3693710481095406,-0.2989223678651554,32.1611903312451,1356.1430111235527 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark23(-0.36963520432114705,-0.44465228905757387,0.18481760216057352,-0.5630720188686614 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark23(0.375451910856885,2.3217001485086652,-0.9731241188258908,-1.9462482376517811 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark23(-0.37764783702007587,-0.5934764380595022,-51.40152883233018,100.0 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark23(-0.3802414017856796,-0.5814799001271975,4.339752180932933,0.29073995006359876 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark23(0.38106276388670324,-0.20178585761609535,-99.93543251834195,-1234.2574816016254 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark23(-0.38201443722503114,-0.5156282946221222,0.9764053820099639,-74.4029791142051 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark23(-0.38252422858542656,-0.5708913749585942,-0.5941360491047349,0.2854456874792971 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark23(-0.38277098183994707,-0.4120145788372863,-0.5940126724774748,6.7232025847576695 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark23(-0.38294262205173246,-0.5939268523715819,0.8327427665250685,100.0 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark23(-0.3836997237566538,-0.28359913783948576,0.1918498618783269,-0.6435985944777054 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark23(-0.38576707346552297,-0.37363436692644747,-100.0,26.571241426781125 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark23(-0.3879325688348534,0.19396628441742658,-9.37837517957503,-64.60284403079385 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark23(-0.38863728897139305,-0.15621090493767475,-99.19420720385882,-0.7072927109286109 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark23(-0.38895465072609325,-0.7778895086842486,0.54984831706437,0.38326609951994745 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark23(-0.3890841524235808,-0.5901042459534065,82.16703586394294,0.33960099365775076 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark23(-0.3894374795653161,-0.4644303688393059,-27.653123042691224,1.0176133478171012 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark23(-0.38965976671829516,-0.5905682800383004,-0.5905682800383006,100.0 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark23(-0.3896882448682388,-0.5905540409633288,-0.5905540409633286,12.073505602286328 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark23(-0.3909024963706733,0.19033898005120475,-66.32969866443864,-0.09516949002560239 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark23(-0.3924268331140733,0.011171129495549301,-49.04757981009698,-0.7909837281452229 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark23(0.39347957000007205,1.0984542965709547,-48.8608137747526,-0.5492271482854773 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark23(-0.3937032431886203,-0.4209696406408869,0.9822497849917584,33.928381295746625 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark23(-0.3972634586574702,-0.5867664340687131,50.98132912765064,79.5948753803975 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark23(-0.3975535809132333,-0.585201037656597,-80.55531924358249,0.2926055051264268 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark23(-0.3977171532727859,0.11523303309945682,0.9842567400338412,-88.730707237539 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark23(-0.3981372790434907,-0.12184922824939115,-100.0,4.5894598548456855 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark23(-0.3989982937080698,0.025841638215930003,-98.49607985821021,53.43424650145835 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark23(-0.4020964353985972,-0.5843499456981496,0.24591344385810077,0.2921749728490748 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark23(-0.40252542705402733,0.6549942822132228,-36.79754867396325,63.29889019521665 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark23(-0.40255160431002035,0.20127580215500962,0,0 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark23(-0.4039944040302929,-0.35946896278858287,0.9873953654125945,-99.20154288829264 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark23(-0.4042798349776109,0.20210809576844316,-99.99964485509751,-0.10105404788422158 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark23(-0.4048161443113105,-0.5829900912417414,0.47325752354625034,0 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark23(-0.4053587632080339,-0.02988921159866588,-0.40808026222348215,-0.7704535575981153 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark23(-0.4093737504911581,0.20468687524557894,0.20468687524557905,0.6830547257746589 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark23(-0.40963569165218006,-0.5805803175713581,0.20481784582609003,0 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark23(-0.4133958606964543,0.20669793034822703,-7.414940745768823,0 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark23(-0.4145448094073265,-0.312729196163289,-0.6302598853380489,0.9417627614790927 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark23(-0.4150163976860602,4.607390132931488E-20,-85.29438596763846,0.23415107888909584 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark23(0.4151201170874498,2.4010365609697772,0.5761234182144072,-43.61191858276115 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark23(-0.4152892530614114,0.202409079968337,0.2076446265307057,56.65812368772896 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark23(-0.4161011670918421,-0.7604255930538129,-0.566121425861808,-1.9726682486738876 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark23(-0.4177998805891354,-0.5764982231028801,0.2088999402945677,0.28850263598671505 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark23(-0.41834559765414503,0.20917279882707232,0.2091727988270724,25.197235977803814 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark23(-0.4195084214078304,0.7317794839792355,-7.056603247114507,84.93270242153444 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark23(-0.4195177652149136,0.09444538669020519,4.600924203541993,-0.047222693345102595 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark23(-0.4217146803706049,-0.038353583918909556,-83.03294484856079,100.0 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark23(-0.4234839359770948,-0.566842322936285,-26.5836129940065,0.2834211614681425 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark23(-0.4238248155151174,0.21191240775755868,-35.70660938895869,100.0 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark23(-0.42402458094302015,-0.5632258379689264,-0.2817333092006495,-0.5037852444129851 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark23(-0.42413727829317405,0.14290279202121092,0.21206863914658705,0 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark23(-0.42444419975280195,7.670458539527698E-93,0.5581349775757666,77.61434794800232 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark23(-0.4250458529429838,0.6483995770336389,0.9979210898689401,16.97469593681155 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark23(-0.42560004448917366,-0.5725981411528616,0.21280002224458683,100.0 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark23(-0.4258514562890882,-0.498493577150363,0.6747342100961536,-0.5361513748222668 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark23(-0.4275326014451485,-0.5709243877688702,0.8450799305240522,0.2854621724438121 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark23(-0.427676612913488,-0.0764330314551327,-1.366444890321863,0.03821651572756635 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark23(-0.42774919677439294,0.2011740509466072,0.9992727617846447,0.6848111379241447 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark23(-0.42968508415842255,-0.2871959423268947,-66.86584463551216,27.72531616069437 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark23(-0.4298420178166331,-0.5704131515645398,0.13114513342234518,1.0706047391797182 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark23(-0.4298470012986413,0.21492350064932042,-0.25602872097985974,1611.4500875099593 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark23(-0.43040483905294175,0.7093614276704835,0.616575384516375,-87.53533126159242 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark23(-0.43041722686225103,0.21520861343112518,0.21520861343112552,0.6777938566818857 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark23(-0.4313231353933007,-0.2585633547325301,0.06464083868313253,69.41021824917692 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark23(-0.43365552869968965,-0.17740681990757987,1.0022259277472931,0.8740272700699327 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark23(-0.4337204535492826,-0.867440592927704,0.21686025327314137,0.4337202964638518 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark23(-0.43523721605249716,-0.39454960758990304,-0.5190013356291109,-40.24496262331723 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark23(-0.4361650274784795,-0.5673156496582081,-0.5673156496582085,0.2595137342551769 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark23(-0.4372832718250537,-1.667598366993251E-60,-0.10277814823713192,-0.7085208956765885 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark23(-0.438307164107914,9.082973274719221E-34,28.950761437134073,12.297168776783014 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark23(-0.43970215832393655,-0.5655469537722383,1.0052492425594166,0.8970386668968845 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark23(-0.4407062360527645,-0.28250318287447995,1.0057512814238305,0.14125159143723964 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark23(-0.4410542756246005,-0.8821085512492006,0.9677610734884493,1.2264524390220486 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark23(-0.4411382326931843,0.18080466591850294,0.22056911634659215,-0.09040233295925149 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark23(-0.4413201520074175,0.6823391922463042,1.006058239401157,-2.701440954718233 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark23(-0.44202271324506787,-0.46465624483621715,-99.66230593954388,13.687171820426233 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark23(-0.442767186477924,-0.5337396515035312,0.6530923948745776,-0.5185283376456826 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark23(-0.44414919901078054,-0.563261661245862,1.0074727629028386,1.0076215936731336 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark23(-0.4447941766939323,0.22239708834696603,104.68030440863687,0.6741996192239652 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark23(-0.44580358186459024,0.222901790932295,1.0082999543297433,-100.0 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark23(-0.4459893944683822,-0.5624034661632571,0.22299469723419107,-100.0 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark23(0.44734335176786755,-0.24988950173629343,-100.0,0.12870114831251692 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark23(-0.44740687527855466,-0.5563333859361528,-39.61624855048137,3.1342605196696676 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark23(-0.44770994814041387,0.2238549740701927,-12.620600661786241,-0.11192748703509636 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark23(-0.4478928747752903,-0.282505941161594,-1.0641439381208766,-13.251713897874914 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark23(-0.4488131134340161,-0.39213437187522787,-97.24309419386155,0.19606718593761396 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark23(-0.44901649013224465,-0.5608456776671124,-100.0,0.2804449591656629 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark23(-0.449125340680511,-0.5605304046618148,10.065733453340181,0.2802649064650652 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark23(-0.4491388202549898,0.19302518846751854,1.0099675735249432,-89.28174073144902 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark23(-0.44927543319784247,0.17158502679840398,-0.34122497119372286,-0.06899948237590746 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark23(-0.45159016061259094,0.22579508030629536,-28.73475852672076,-7.872469089375375 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark23(-0.4547400490685195,-0.5527342477377162,60.55886400800589,75.63404091094924 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark23(-0.45662156568985846,0.08346677273211386,-7.915655401895513,-51.28456330648487 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark23(-0.4567491250007716,0.08190382146919312,0.4616123156182173,8.54562546443706 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark23(-0.45719180190217884,-0.5220162146686751,-0.5568022624463589,1.0464062707317858 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark23(-0.4572548089228796,-0.556770758936008,0.2286274044614398,0.278385379468004 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark23(-0.4585973846573155,-0.5560994710687904,1.44524249238359,-452.0247739202378 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark23(-0.459003048684432,0.21296702086803346,-0.5558966390552322,-2.129004017148845 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark23(-0.459902949486966,-0.8954132406690599,45.61623894533736,0.44766546970434495 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark23(-0.4605462503995306,-0.889880677891278,0.24434997161811348,76.62854948285194 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark23(-0.4617616862993285,0.23088084105426418,-65.4304177126657,-0.11544042052713598 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark23(-0.4630314533106053,0.2273576238763502,-100.0,-0.11367881193817513 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark23(-0.4642045631201888,0.23210228156009438,-63.526487397812005,-1376.4360030622602 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark23(-0.46498386563091065,-0.5529062305819928,0.2324919328154553,-90.0472518520025 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark23(-0.46619745551585146,-0.5190190280520494,-15.093186524248807,100.0 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark23(-0.46908946757288017,0.37936237078297963,1.303407133200397,-59.06525702095761 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark23(-0.47170117961288793,0.17233309093940105,-0.04630329744133507,0.6979166976083168 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark23(-0.4727207708270321,0.04484509036878448,-52.92372212421325,2.1436274104612365 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark23(-0.4729517429847562,-0.19079892758877798,-64.58319001142544,-59.24853987845822 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark23(-0.4730002116971242,-0.4893518635718436,0.23650010584856218,-16.619513989698625 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark23(-0.47329935829417424,-0.01595389030619662,-0.3999580710549694,-56.38073413543974 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark23(-0.473787180522592,0.22894872965051685,-73.23558495759497,-0.11444150463999635 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark23(-0.4738605880634377,0.23686021386519177,0.23693029403171886,-0.9038238122634559 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark23(-0.47620282327324714,0.0025240979479357398,-3.7486367252871498,-0.0012620489739678699 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark23(-0.4765218827289993,-0.4149906776169747,-0.5471372220329487,91.51141978836192 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark23(-0.47711967125629984,-0.12054919823414183,0.23855983562814997,-119.32024433339127 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark23(-0.4784446931260889,-7.399438276631727E-15,-0.5187300967546441,-100.0 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark23(-0.4799172870143983,0.0,47.62353747206246,99.74799704639928 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark23(-0.4802417408812545,0.24012017736468466,-12.990339458547608,-16.042284978013107 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark23(-0.48053279297145157,0.09922884880626111,1.0256645598831824,-0.049565986998956306 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark23(-0.48217627075874414,0.24108813537857915,-3.3197812662878943,2113.043985390411 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark23(-0.48453975350476414,-0.543128286645066,1.0276680401498304,83.05169800931428 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark23(-0.48519705324604623,-0.3068132076909919,-99.99999997160461,100.0 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark23(-0.4852211247664831,-2.802596928649634E-45,-78.95808087001822,0.22615912819124845 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark23(-0.48560462985005903,0.24280231491619636,-4.461499361203594,-89.97576294767514 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark23(-0.4858322017103033,-0.09879564547429767,0.943677142302896,-58.39785741234296 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark23(-0.48981074450687156,-0.49916569202126176,-0.5404927911440125,-1.593647151107795 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark23(-0.49061385101907623,0.1878426219490695,1.0307050889069864,-0.0939213109745348 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark23(-0.4918999978430918,-0.31415926535911254,-0.31415926535894556,-100.0 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark23(-0.49212914689619325,0.14217858377452197,75.67071009609273,24.298802186101 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark23(-0.4924208556107024,0.13535643964265165,0.2462104278053512,41.47405196178684 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark23(-0.4967999769470384,-0.11604300597365547,48.144268030920955,65.15725974890603 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark23(-0.4971848420487093,-0.009065598146740794,-17.211512150059292,0 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark23(-0.4975417954911361,0.198803186159363,0.253317743039962,-53.376168257408516 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark23(-0.49855584803976505,-0.5357821621508767,-0.23127720160661594,0.26789107974810655 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark23(-0.49943236611938574,-0.5288325741363876,0.24971618305969287,0 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark23(-0.5002382167328262,-0.004784498148143745,0.2979901657437729,0 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark23(-0.5002422535208533,3.23747239791642E-6,0.8030694765290419,0.0 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark23(-0.5010589681952062,0.13757249061762186,0.2518294540905558,-0.06878624530881093 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark23(-0.5020272217634718,-0.5343845208954565,0.03134971428171233,100.0 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark23(-0.5054556960186335,0.25272784800931475,0.25272784800931675,64.94791339060978 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark23(-0.505616648478626,-0.38028589862813045,23.499555238575695,-100.0 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark23(0.5072839936725965,1.028344271862137,-140.5137691693781,-52.04645749845821 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark23(-0.5073476593493504,0.2418275040853621,1.0390719930721224,-100.0 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark23(-0.5087233854163206,-0.1564370881878247,1.0397598561056085,0 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark23(-0.5089037135328048,-0.23130568807484375,0.25445185676640236,84.66127691820947 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark23(0.5103522706773292,1.0328252686509989,-100.0,-117.24593183047872 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark23(-0.5104900131453116,-0.4224964925099571,-0.5045262301722855,-15.916335491654383 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark23(-0.5110935924258171,-0.12215221447536692,-0.5298513671845397,19.693147700946035 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark23(-0.513292202476181,-0.3130293577550749,-0.5287520621593578,-0.6288834845199108 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark23(-0.5134382791405798,-0.08763754447209561,-6.849176073651742,-51.333388816268595 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark23(-0.5135071440224525,-0.4958118149350801,0.2567535720112263,-2.1013305223510117 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark23(-0.5149760082123132,-0.2279397674881048,-0.003255644121205924,-22.423013150233878 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark23(-0.5150357602608163,-1.0268513275725095,-0.5274093297631516,42.94053826340963 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark23(0.5150663760819231,2.0432025843997628,0.5278649753564868,-1.8069994555973494 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark23(-0.5152717686800142,-0.5205910497815341,-0.5277622790574412,-0.31445126451634664 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark23(-0.5154578958673528,-1.0309157850575073,76.07290893084702,0.5154578925287536 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark23(-0.5158361402918601,-0.5274800932515181,-0.5274800932515182,0.32573561545199914 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark23(-0.5160936192824765,-0.5265818118500674,-15.467060803681093,1.048689069322482 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark23(-0.5179220680915346,-0.1802603682884542,0.2589610340457673,0.10984444443726481 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark23(-0.5185338029560845,-0.22194214277650293,0.6289238231355332,-0.6744270920091968 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark23(-0.5192065035123019,0.25960325175445,-100.0,0.6555965375202233 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark23(-0.5194954973886917,-0.4386079527810536,1.045145912091794,0.2193039763905268 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark23(-0.5195333803186822,-0.2515579613805272,0.053802958869285766,100.0 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark23(-0.5212417354577497,-0.05095072577626247,0.2606208677288748,0 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark23(-0.5215160917311561,-0.06239694310929086,-0.5246401175318702,100.0 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark23(-0.5215705415452145,-0.36618965358366573,-100.0,0.9684929901892811 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark23(-0.5225185941657117,-0.5241388663064824,0.09713050116231671,100.0 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark23(-0.5231137077916591,-0.45888729010145474,91.44419525131369,0.22944364746204043 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark23(-0.5242500918680825,-0.5232731174634069,1.4961014995238315,-64.47593394404508 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark23(-0.5242822410167902,0.2614666101247577,0.27278344937576526,-0.9161314684598272 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark23(-0.5243363125453864,0.2596154589688569,0.7976581668882563,-23.695489978275617 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark23(-0.5258595262137331,0.5175788728089693,-0.5224684002905817,-100.0 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark23(-0.5271099890944186,0.08529577856052792,20.061250292176286,-33.692912163094476 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark23(-0.5279255249279275,-0.5176745897814499,0.8222013379404824,0.25842329517117296 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark23(-0.5284496076265006,-0.48913459358534706,0.49052878514213205,-61.24823125012401 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark23(-0.5304740931186092,-0.38188854042859705,0.2652370465593046,-100.0 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark23(-0.5317421588030891,-0.5099357620717423,-60.210854881756816,100.0 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark23(-0.532499693152416,0.021906034140540626,-92.18009409900061,-0.010953017070270299 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark23(-0.5332324176421793,0.16691265515092368,-63.19719679640299,30.415240054451456 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark23(-0.5338184214236366,0.25276487637557987,-0.51848895268563,-78.08359748543336 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark23(-0.534195782398549,0.2553522298690687,0.4249972952270298,-99.61302126782228 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark23(-0.5377866899621222,-0.5160949134233009,-40.42987151099317,100.0 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark23(-0.5383222856483725,0.20149883803293142,1.0545593062216345,-0.10074935218218381 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark23(-0.5394752580387414,0.010393059294771884,-15.97930246464203,0.0 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark23(-0.5405935444783977,0.25886117779081924,-90.5007715072813,38.51851992188721 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark23(-0.5407811205982115,0.2702477356066985,-0.14504695498061607,-100.0 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark23(-0.5414318680720784,5.551115123125783E-17,-1.9546058055704004E-8,-0.46499425094174784 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark23(-0.5445320361842675,-0.16944248600195344,1.057664181489582,-26.52798470669108 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark23(-0.5454074205767849,0.2290997846461385,0.8480383748343168,-26.898729521022887 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark23(-0.5458904910573484,0.27294524552292176,-30.164840154999357,-70.83061926717305 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark23(-0.5460195913171302,-0.5123883677388831,-0.5123883677388831,-79.10728869401687 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark23(-0.5465094205013236,-0.05498681693216412,-33.30524176357707,-55.10705790904666 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark23(-0.5471500780693458,0.2718448830074582,0.2735750390346729,33.63726234508749 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark23(-0.5474159121832672,-0.5115865868637881,0.2737079560916336,0.25581132687485986 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark23(-0.5475447010946282,-0.42912325207444296,0.2737723505473141,0 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark23(-0.5487015661227237,0.24796376950556645,0.27435078306136185,12.66390293924593 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark23(-0.5489031484858358,0.22552585689832427,-95.297878160789,0.6726352349482861 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark23(-0.5492774335347659,0.03254857307987413,-0.45530425933016716,-7.947016857406819 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark23(-0.5493085638308326,0.05867377859286555,1.0600524453128646,-23.320256592750557 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark23(-0.5495566366891955,-0.5054886434010863,0,0 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark23(0.5496761664918739,-0.309745799898935,-11.249642126473686,63.27351387941192 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark23(-0.5514175373333785,0.06538741191440112,1.0610940596708232,17.113118605688896 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark23(-0.5522826201122195,0.27288138064392187,98.780055585009,-90.23028493712576 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark23(-0.5527167428712843,-0.1616485529348312,-85.8239237896662,0 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark23(-0.5529990570907586,0.0075377285518377435,-1.1993784808871193,15.19793190908846 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark23(-0.5533258912474719,0.23161227238850168,1.0620611090211842,-25.215427776399785 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark23(-0.5535532804748187,-0.7229232494543284,180.05766312456876,17.762320127657393 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark23(-0.5555343736220547,-0.48676760855891893,-0.3782476016769105,-100.0 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark23(-0.5568887374369693,0.23745291169854435,0.27844436871848466,-0.1187264558492726 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark23(-0.5592436569143904,0.24903216461605426,-174.49126984052586,-0.8006569960260652 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark23(-0.5593933654215307,-0.5049668377484281,0.7818983520174915,0.2860280409305299 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark23(-0.5594828117156653,-0.3373610055275971,-0.323489700971955,0.1686805027637986 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark23(-0.5614649721953486,-0.5046656738015535,1.0661306494951226,-0.5330653264966715 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark23(-0.562778659375159,-0.056402472653093394,1.0667874930850278,-21.056081156961895 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark23(-0.5643327746141569,0.24026349551977988,73.1600389870674,0.6652664156375584 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark23(-0.5649116596235539,-0.5020363062203649,1.0678539932092252,-0.5343800102872658 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark23(-0.5662823096431979,-0.5022570085758491,85.20802348478978,0 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark23(-0.5666585805499218,-0.4956062751652675,0.2833292902749609,-36.79040687604362 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark23(-0.5695717813871863,0.1807294314159743,-0.1017515597333142,-25.85550752977014 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark23(-0.569698849929672,-0.5005487384326116,0.284849424964836,0 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark23(-0.5700857320063879,-0.4829176056362898,-134.3221013673235,80.33929036786543 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark23(-0.5703155978318805,-0.22183717506087675,-57.739934317096406,-136.44762722754592 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark23(-0.5718807854245803,-0.1679571661613795,1.0713385561097384,-42.49566872740056 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark23(-0.5723816805566837,0.23490230256611222,0.6832322304174643,-0.1174511512830561 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark23(-0.5728345502361989,0.2779825370147049,-3.7586427022457656,0.6464068948900958 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark23(-0.5752660645627978,-1.142100885593577,-54.165592424444455,3.720369023787236 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark23(-0.5767814546170837,-1.1423750621761695,-0.02951393671721223,-10.440757240900474 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark23(-0.5778170007737305,-0.10420031294448007,98.08271394480495,0.05210015647224009 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark23(0.5782040465743423,-1.0745001866846193,-76.89754168884272,-40.30583853730883 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark23(-0.5795851587251697,-0.4956055840348633,-15.081648329094897,99.62220145468692 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark23(-0.5809184810376034,0.26022907570572884,-36.81325036407018,-0.13011453785286442 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark23(-0.5829686973619437,0.2189435308030221,41.83021653960347,-0.10947176540151105 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark23(-0.5859285888955372,-0.18134357225744216,-20.956646164749692,0.09067178612872095 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark23(0.5860049405430796,-0.29304962964229286,0.49239569312667236,0 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark23(-0.5877620020262586,0.0765954864973839,-0.4915171623843189,22.781800054634534 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark23(-0.5881160177981497,-0.4686640045177922,-0.49134015449837337,0 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark23(-0.5883797874165533,-0.24730412409691135,-3.7493768255468183,0.12365206204845566 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark23(-0.5889261178130256,0.29446305890651264,2.220446049250313E-16,-100.0 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark23(-0.5889340526656522,-5.421010862427522E-20,-0.42466664690487566,-49.847486890887254 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark23(-0.5894361176931057,0.08804517188201666,0.8099205704525324,-0.8294207493384604 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark23(-0.5895044026318588,0.1917169509476994,-54.09001504553728,-80.99113144077201 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark23(-0.5897973090268224,-0.4030236565606368,3.8880628731068584E-11,9.983095835949565E-15 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark23(-0.5900776651920809,0.23663417321620048,-0.4903593308014078,-0.11831708660810025 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark23(-0.5912353417602739,0.29041678194219256,1.081015834277585,-51.866064712647265 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark23(-0.5924618240897193,-0.3306334199091208,-0.48916725135258865,-80.65871021020023 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark23(-0.593420740293017,0.29671037014650836,-0.0420130183775404,-31.394515126827873 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark23(-0.5941330325725958,0.06898173113987648,0.8276093796746536,-0.021197218905667725 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark23(-0.5978726916961186,0.2022446364886227,0.37859373291973664,-0.1011223182443114 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark23(-0.5981029210337772,-0.45162515792688684,0.2990514605168886,-183.55735893813699 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark23(-0.5986467148704837,0.28936880368515006,0.3601091386217953,-0.14468440184257503 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark23(-0.5989180316674474,0.29945901583372353,0.25749248773887307,100.0 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark23(-0.5991800376603931,-0.4858047345237013,0.29900144222578406,0.24290407228362165 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark23(0.6004503704177812,-0.3002301568660433,-96.90806212396407,0 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark23(-0.6005299166765043,-0.47017939443799694,66.06933000715442,0 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark23(-0.6013061818062674,0.30065309063523044,42.371877150822165,73.49842015271405 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark23(-0.6022159860754048,0.30110799299109525,0.09806909109168062,66.67856900877497 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark23(-0.6024169309361957,-0.4841896979293502,0.3012084654680979,0.2420948489646751 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark23(-0.6036499338632864,0.0024566757961460017,4.097848398491961,57.59713296757721 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark23(-0.6065037616528759,0.3032518808264378,1.0886500442238862,-1.6302376006206178 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark23(-0.6068114391498809,-0.39220401409215216,-0.4819924438225078,-33.873542857417746 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark23(-0.607367928707613,0.1660049204103219,-0.220670332234437,-40.92197605871047 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark23(-0.6075041254278397,-0.2884911884988643,-0.4816461006835284,84.76642847361877 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark23(-0.6077340999272223,0.3038670499636107,94.69923106844118,-1842.2218466029474 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark23(-0.607818153665538,-0.1424846958360072,-94.42140206013441,9.474814554481782 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark23(-0.608243577042114,1.474797975161521E-6,-0.008752355994230389,-0.3053352223018569 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark23(-0.6109603178590065,-0.3780192132238566,0.6339610705062114,22.15194615701383 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark23(-0.6125095149882165,0.23318700348622626,0.060823490978953364,-0.11659350174311314 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark23(-0.6128180731076611,0.2519921937498206,0.30640903655383056,-0.17664823387253933 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark23(-0.6138041551301207,0.30690207622357807,51.85280472118572,-0.15345103811178906 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark23(-0.6142924187921146,-0.18117599301267795,-70.40923903110297,-68.74940214308836 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark23(-0.6142990331998481,-0.014431171302764945,0.7709669920946851,-29.932676411622545 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark23(-0.6165192060840394,-0.3672009716929605,-105.37849116246655,-62.34585556029928 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark23(-0.6169740819403554,-1.1908786324068807,-0.47691112242727063,-100.0 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark23(-0.6204838400670774,0.31022406276379966,-0.47515624336390966,0.6302861320155484 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark23(-0.6206597743790887,-0.4750682762079026,1.0957280505869926,-0.547864025293497 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark23(-0.6210997118964858,-0.04481196339846284,-91.53972091207253,0.8078041450966797 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark23(-0.6213094448581602,-0.3959130325701471,0.6848403161205229,67.9397042008097 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark23(-0.622676675900685,-0.7979854111197704,1.0967365013477908,35.099080481236285 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark23(-0.6227077414703481,-1.242163630900253,0.9734476564243019,45.388775705526584 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark23(-0.6234334371823697,-0.45991868249028683,-0.4736814448062635,70.93882144656601 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark23(-0.6242495278212361,0.20549449209295667,0.31212476391061805,59.798690875239785 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark23(-0.6243769859470317,0.14000945532944556,-0.23008775205546622,-0.7654275227496893 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark23(-0.6247827695404807,0.30899547032439195,0.0,-0.490324129915784 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark23(-0.6249349295623913,0.31246746478119386,1.0978656281786439,-100.0 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark23(-0.6280846767225732,0.30113905359291715,-3.907961883697078E-13,-0.48378455644974544 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark23(-0.6282560265174166,0.2635997964161541,-0.15196741046906012,-2.479141229479558 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark23(-0.62831853071794,0.1459544848304435,20.16622921564803,0 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark23(-0.6283185307179588,0.3141592653589786,1.0993986771785362,-2071.7064219444396 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark23(-0.6283185307179622,0.13492987172615453,-68.8031629807524,-5.011659111158904 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark23(-0.6290456874578914,0.3127049518791132,1.0999210071263938,-0.9417506393370049 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark23(-0.6291850945389543,-0.470805616127971,0.31459254726947716,47.05892351053718 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark23(-0.6294106398886627,0.29115258662830507,1.1000779609737805,-0.14557629331415245 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark23(-0.6294351249162877,0.30780660680984373,-0.4706806009393043,-18.214063185858663 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark23(-0.6294859426909859,0.29033305731244935,-0.47065519205195533,-0.930564692053673 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark23(-0.6307148668781094,-0.1483544078038618,-0.46999373163192665,0.06944443582997273 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark23(-0.6323991322357299,0.30599806232343696,-100.0,31.266949290800454 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark23(-0.6333661686170873,0.30406398956071967,-22.72049933261414,-0.15203199478035984 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark23(-0.6338965453914247,0.2448670525225494,1.099919759046924,-0.12243352626127466 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark23(-0.634453401953543,0.0,0.8242149088368464,-1.6654554720058731E-7 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark23(-0.6362014168966993,-0.13028767746707545,0.31810070844834964,-90.9964302288351 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark23(-0.6371169064253991,3.6036499203586656E-20,6.633957258578735,24.59244045051476 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark23(-0.6378190017891959,-1.2582171343001558,67.58916457739622,-35.093556627956886 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark23(0.6382304574439266,1.5800931032134895,0.4662829346754904,-121.74800002120948 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark23(-0.6387377186593519,0.001106922646952445,-185.70652508000623,0.3064066700704227 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark23(-0.6389316970526373,0.05663551364876104,0.5401156271102567,25.918892929577396 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark23(-0.6399187039156281,0.2909589189636401,-0.46543881143966814,-0.8800182942242685 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark23(-0.6404115061842408,-0.26344374462176307,0.3202057530921204,-36.32998354964283 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark23(-0.6414859961733801,0.2878243344479886,1.1061411614841383,62.844841179142804 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark23(-0.6416228200007863,-0.464586753397055,-22.45573513531417,1.0176915400959758 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark23(-0.6427977661878552,-0.46399854202482305,6.857634176564518,44.116430150853986 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark23(-0.6429585927044592,0.2778625194362079,-0.4639188670452187,0.6464669036793442 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark23(-0.6430582634698856,0.2846797998551249,1.1069272951323912,-20.875595497169368 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark23(-0.6437722895020002,-0.10148688891115853,0.3218861447510001,115.33346005180292 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark23(-0.6447424749620021,-0.08369525611330292,0.32237123748100105,-0.3026637159094735 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark23(-0.6447979451342507,-0.43974514155989763,1.0693120887114986,0.21987257077994882 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark23(-0.6449575625450761,0.23076075282035813,1.8015570796152556,-58.18696425838624 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark23(-0.6461511869561004,0.15269565580358044,-0.4623225699193981,97.39116610411118 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark23(-0.6461954044527446,0.27840551788940693,1.0096131827715398,43.55137820536349 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark23(-0.6469499080699279,0.1487528303586911,0,0 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark23(-0.6472887084303087,0.27621890993427833,1.1090425176126026,-100.0 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark23(-0.6501423078325494,0.270511672043413,1.110469317313723,-77.88835885232564 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark23(-0.6503388047157803,-0.13291985521054894,0.32516940235789016,36.66473395787414 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark23(-0.650438952956525,0.2693589249085466,-56.922656384339184,0.650718700943175 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark23(-0.650739698160169,-0.02550256319573574,36.12597017662912,0.01275128159786787 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark23(-0.6528196104555359,-0.07791553017290134,1.1118079686252162,46.482794672389595 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark23(-0.6539792782612706,-0.4584085242668129,1.1123878025280836,42.855518168993406 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark23(0.6539798128934957,-1.0298876953494556,-42.43702954421158,37.596724858927644 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark23(-0.6547254149836967,-0.11878889627387094,0.9466032787307872,76.28164098560758 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark23(-0.6549559501116278,-0.4541927640946477,-0.4579201883416344,-52.36514718281269 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark23(-0.6551823258974776,-0.27797172910711254,-2.981769535865629,0.13898586455355633 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark23(-0.6552071589686375,2.7755575615628914E-17,0.2239779235773377,-100.0 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark23(-0.6563641496588366,-0.4080287615602213,0.3281820744695749,0.0 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark23(-0.6566262321327958,0.2575438625293048,19.604754657255185,-0.1287719312646524 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark23(-0.6589682607483257,0.25285980529824476,-30.53690977887848,0.6589682607483259 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark23(-0.6611792358831983,-1.7516230804060213E-46,1.0586731694035834,-86.84827726497986 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark23(-0.6612756037304859,-0.4373676268945213,0.7420317541081305,-43.71820689718369 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark23(-0.6656541112463712,-0.11439135610820994,95.37897098947887,100.0 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark23(-0.6667127239838563,0.23737087882712746,-0.4520418014055201,-44.84051808594024 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark23(-0.6676402361600026,0.2355081291942458,-0.45157804531744694,0.6676440988003254 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark23(-0.6690986361735503,-0.39349649750248095,-57.32842334024667,-0.3020564381089611 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark23(-0.6706356140016457,0.22952509879160488,1.1207159703982712,88.67817825532816 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark23(-0.6710338949520729,-0.3703096375992392,-19.20460534135766,0 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark23(-0.6711510074349756,0.033705788578834,1.8283576673564381,-0.016852894289416998 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark23(-0.671166612418094,0.1389283418827588,-0.4498148571884013,5.342545502906347 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark23(-0.6717927574881387,-0.0966553529242152,-0.43701189770234805,-100.0 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark23(-0.6727178201180507,0.14015802139460107,1.1217570734564737,-36.98247777005794 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark23(-0.6730105300000704,-0.08184289426414343,0.48477614176080963,-0.7444767162653766 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark23(-0.6739035780123593,-0.43001835325221727,0.33695178900617967,0.2150091766260447 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark23(-0.6747837821909219,-0.10950061211635848,1.12279005449291,-100.0 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark23(-0.6768733644597225,0.06525930991839998,0.8630257878776648,5.30868793192283E-6 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark23(-0.6781708768298124,0.09514417683046991,-98.8258352704507,-100.0 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark23(-0.6787327288333478,-0.424565070098575,-100.0,0 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark23(-0.6791292424263593,-0.18435756291486427,-0.4458335421842686,0.09217878144749721 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark23(-0.6796051670011259,-0.062160735713022615,1.1252007468980112,0.031080367856511304 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark23(-0.6829978220996119,-0.03893728038894223,0.34149891104980595,0.01946864019447149 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark23(-0.6831501519355272,8.174383392845532E-18,110.61554629326169,12.328315604848381 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark23(-0.6833906955615892,0.20384407533358037,0.3969690449028916,93.2020845277982 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark23(-0.6847135559660277,-0.07397049650298784,-28.171932801485184,0.036985248251493935 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark23(-0.6852244507160007,-0.34966700259976297,-91.12403826292724,0.1748335012998815 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark23(-0.6860333918580497,0.198729543078797,73.31316215906907,82.78928966032352 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark23(-0.6890172509583196,-0.3821637740884304,-57.97937018868143,-12.56332272624651 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark23(-0.690174902308401,0.1904465221780942,-0.4403107122432094,0.688859981960678 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark23(-0.6911756958662919,0.040023383766436216,0.9965625364953425,-20.975792546871077 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark23(-0.6916807286355993,0.16090856165228776,-0.4395577990796487,0.7036289622518714 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark23(-0.6923353165095487,0.1059651351767552,0.34616765825477436,-27.449571353285513 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark23(-0.6931751908863589,-2.918598253306032E-25,-31.691339996298822,0.2179717859869984 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark23(-0.6962385587039709,-0.025225747311876212,0.34811927935198544,1782.09045119089 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark23(-0.6966284403615096,-0.17657958523574768,0.348314220180755,-0.41060281937613696 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark23(-0.6975558034221343,-1.0670803042898065,-24.439980491002316,46.08192335822193 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark23(-0.7022479151912828,-0.3155778926942132,1.1365221209930898,1658.771619900314 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark23(-0.7048962715505054,0.16071071245783528,-20.141035762037582,-0.08035535622891765 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark23(-0.7066176559222384,-0.4320893354363289,-0.4320893354347189,0.21604466771816444 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark23(-0.7066988378433257,-0.20773004404174533,-63.5556433527607,0.10386502202087267 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark23(-0.7070513031168184,0.14598370299086927,0.1244872193228832,0.5937466947164531 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark23(-0.7070933262139671,-0.1003869098073536,-0.4318515002904646,-45.843176084191406 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark23(0.7072965784569966,2.659358600690563,-33.11077462859684,41.86721968651456 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark23(-0.7076749023291624,0.15544652213657156,-44.312383247389455,99.90487802151839 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark23(-0.7092043218914927,0.10823299730168168,-82.36583196772567,1.0949181351692978 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark23(-0.7097180209284946,0.150931746376761,-0.430539152933201,1808.109303180893 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark23(-0.7101024606255726,-1.420204921251114,-85.37283820854816,-11.08093724926268 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark23(-0.7110157442661466,0.14876483826260328,1.1409060355305216,109.8665978362096 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark23(-0.7130435984242123,0.14470912994647178,-66.36724733933339,0 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark23(-0.7147558751995068,-0.018355104945735348,0.35737793759975334,0.009177552472867681 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark23(-0.7148919196251579,0.14101248754458065,-0.06772269620743228,-0.7520123570046112 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark23(-0.7161170209837903,-3.792136214423309E-21,-66.1008526015328,1.2689666083603633E-5 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark23(-0.7173079023847848,0.02578174085155599,0.3586539511923924,0.7725072929716703 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark23(-0.7175990246425488,-0.35325725763308047,-97.51528193631125,1325.315393905365 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark23(-0.7190501508703897,0.06718801839884082,1.1449232388326431,0.7518041541980278 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark23(-0.7193494555843944,0.12583005132534722,35.59813445365136,0 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark23(-0.7194916719686881,-0.3754280838398542,0.35974583598434406,0.9731122053173753 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark23(-0.7203861977008765,-0.4252050645470078,79.15973865641459,0 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark23(-0.7205126883500974,0.12977095009470155,54.98225279095275,-0.06488547504735076 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark23(-0.72111554984128,0.1285652271123271,0.3605577749206397,100.0 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark23(-0.7216013376032733,0.10262237554991901,0.3608006688016365,-0.7764953155024452 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark23(-0.7224333301493858,-0.002439262070307202,-24.53614368630285,8.608307341015083 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark23(-0.7238711312613195,0.12305406426931702,1.147333729028108,-0.06152703213465851 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark23(-0.7262325525334488,-1.5295114930909958E-48,0.35900859578287553,-0.4316049229867466 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark23(-0.7278694649582316,0.1150573968784332,-10.179387828623357,82.0046556869421 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark23(-0.7281776277703469,0.07485200362797108,-16.919519135942355,-0.0374260018139857 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark23(-0.729665347277336,0.09865549471696446,-0.0821866875666124,0.7360704160389661 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark23(-0.7302761119461816,-1.1870816589370035,-25.679712192609685,-100.0 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark23(-0.7312855708134897,-2.862246728843688E-40,-0.11654062294008673,1.4904621644005156E-9 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark23(-0.732054531502248,-0.11830636963670411,0.366027265751124,0 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark23(0.7327779930501,3.019781158901872,-1.0542687394846193,65.242347544005 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark23(-0.7328260612250934,-0.41898513278490135,-20.559624404686605,-45.35203588052822 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark23(-0.7353993224766562,0.09999768184158153,0.23544503797283609,0 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark23(-0.7360093550874057,-0.07902070152374252,0.36800467754370286,98.24842765438055 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark23(-0.736879149168221,0.09703802845845444,0.8250665332837774,0.7368791491682211 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark23(-0.737292101467931,-0.04090698635648238,1.1540442141314138,-0.7649446702192071 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark23(-0.7398328726450956,-0.41548172707489783,44.41961715981856,0 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark23(-0.7412467548682233,-0.15140217841420345,-85.58102329266406,1.6221583848525079 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark23(-0.7412795126407923,0.37063975632039603,0.3703507579466531,-0.9707180415576464 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark23(-0.7419552094065535,-0.41417792319182417,-0.41442055869417155,70.81384396312332 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark23(-0.7454272719384191,-0.06133543313444563,-0.05918780290691993,-0.00942601756543056 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark23(-0.7461505859655929,0.07575198188116564,-0.41232287041465177,15.465651099433089 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark23(-0.7469977814725335,-0.30732758948364697,0.3697831892571387,-6.235630189127603E-38 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark23(-0.7481496652304506,-0.41132333078222283,0.9496309502224305,0.9910598287885597 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark23(-0.7487831023863873,-0.06979314781957933,-97.84045400593341,38.229832217365804 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark23(-0.7503389652315484,-0.40587832607208485,-0.4102286807816741,1918.158315802416 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark23(-0.7505795686905847,-0.4101083790521558,-0.410108379052156,0 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark23(-0.7506549571740573,0.06768724521931795,1.734723475976807E-18,-53.4409112514328 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark23(-0.7509244110365292,-0.06210160380227825,-100.0,0 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark23(-0.7517155574462002,-0.27029069691636887,-107.2087941058812,0.7777275293116592 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark23(-0.7520340186822978,-1.3860826214714028,1.161415172738597,-88.97199009531502 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark23(-0.7520817881614105,-0.34211419129276255,1.1614390574781535,-8.862462623823811 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark23(-0.7523939705936583,-0.26048214824819654,1.1102230246251565E-16,-172.65576864324154 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark23(-0.7527452184481422,0.06530588989861194,63.8972656516,-0.03265294494930596 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark23(-0.7527695339577508,0.06525725887939471,1.1617829303763236,19.64257137401444 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark23(-0.7540272517061792,0.05262573090099771,0.3770136258530896,-1923.7985084293655 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark23(-0.7540999726043666,0.06259638158616299,0.14505105545858288,58.09231771854581 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark23(-0.7544918223790685,0.06181268203675905,0.983155747658966,-61.47877526410584 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark23(-0.7548666116241005,-0.4079648575853576,-0.4079648575854051,-33.28354978874574 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark23(-0.7560221813298277,-0.3153356626400301,-0.07111359733845976,-68.85249550098902 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark23(-0.7571862674969068,-0.40680502964898846,0.37859313374845316,0 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark23(-0.7584130147939494,-0.1269008416573968,0.8632802033525968,-93.1940565034026 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark23(-0.7593459434062615,-0.40572519169431737,-2398.2263408025765,0 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark23(-0.7601026164140384,0.05059109396681949,63.96378451458747,100.0 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark23(0.760130087135252,1.642879200567406,0.40533311982982234,66.0523094854447 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark23(-0.7612335231892242,0.04832928041644635,0.2433517844402861,-61.353573632830845 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark23(-0.7614772839575396,0.04784175887981699,-77.5632129844642,100.0 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark23(-0.7614840765339732,0.04782817372694992,0.3807420382669866,-94.39681897770119 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark23(-0.7619247707320664,0.04694678533076338,92.25107665537031,-66.86445834335017 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark23(-0.7629288305631492,-0.3202289446189454,-0.4039337481158737,0.1601144733716992 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark23(-0.7630806023616945,-0.18737407482419402,-94.88021595130952,28.348910011765444 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark23(-0.7643988121587199,0.041998687081400386,1.1675975694768082,0.7571655776432018 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark23(-0.7650423956658349,0.04071153546322658,-0.40287696556453084,-55.44468468805661 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark23(-0.7658485408723337,0.0390992309978274,0.38292427043616684,-0.8049477788963619 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark23(-0.7660132639388644,-0.018739835814959915,0.5937619166118278,100.0 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark23(-0.7675852565577087,0.035625813679478924,2355.427278152499,0 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark23(-0.7691836180482003,-0.11580731598256908,4.394659646109422E-19,-0.0014639509154598552 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark23(-0.7713541138782047,-0.1360454949779186,-54.6276740848135,0.06802274748895931 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark23(-0.7717110829878496,-0.3141592653589793,-100.0,44.100217829762144 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark23(-0.7717975393413394,0.027201248112217358,-93.48549876413934,0 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark23(-0.7720807231000887,0.026634880594718587,-87.58644470075095,0.23945502878908434 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark23(-0.7723520048320851,-0.2514246504012352,32.97933813812267,0 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark23(0.7737582935485021,3.1167421996680007,0.39851901662319716,72.26905721773205 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark23(-0.7743223945443134,-0.37439361828469103,-53.91743365407687,-47.099375440948414 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark23(-0.7744132020753615,-0.25659734404427503,-0.004104525961194733,0.9136968354195858 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark23(-0.7744829597638013,-0.19768741483753227,0.3872414798819006,-6.14676742297848 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark23(-0.7745465153752065,-0.22563522974821626,-62.037673692990346,0.11281761487410814 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark23(-0.7760287112423194,-0.06885275913725881,-0.2110365791191088,-34.175062813598586 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark23(-0.7763812127847923,-0.06477060579482939,0.38819060639239616,55.419776381871465 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark23(-0.7767528053252502,1.9101153855253725E-5,0.042604246101422306,-285.8344435960188 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark23(-0.7781225835410087,-0.39055705514914507,1.1744594551679526,-67.53366102208012 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark23(-0.7809983035928811,-8.673617379884035E-19,0.6897419080814697,79.63998136908346 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark23(-0.7814610361270997,-1.5625410448847639,0.7942558438193382,85.60322047782225 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark23(-0.7823184028584533,0.006159521077989338,-0.3942389619682216,-25.356264273025545 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark23(-0.7829829598909751,3.469446951953614E-18,4.886465284434145E-4,1.734723475976807E-18 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark23(-0.7830889070007996,-0.3938537098970485,0,0 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark23(0.7848613109086594,1.00245932018215,-111.89824781710482,9.713721979945815 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark23(-0.785218602073773,-0.10074518583034853,-47.592377823074884,25.568273809700454 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark23(-0.7853892100347334,2.46191210121914E-7,0.0,-0.04449261398213483 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark23(-0.7853981633973914,-4.251149477885447E-12,0.16552992437758718,-47.10276614762677 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark23(-0.785562418761389,-0.02268823379605632,1.1781793727781427,0.7967422802954764 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark23(-0.7886135672871544,-0.06326756551243601,-79.23651360775024,0.0316337827562179 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark23(-0.7889908234649199,-0.3909027516649881,-44.87927426406612,0.1955135829217374 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark23(0.7896013705906628,-1.1801988486927797,-97.31999411439544,-100.0 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark23(-0.7918813302029682,-0.389457498295964,1.1813388284989323,86.60560293314543 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark23(-0.7925730750156482,-0.017203743413845562,-79.18273790135743,503.49151310011564 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark23(-0.793667256156663,-0.14746104724904002,1.1822317914757798,0.07373052362451998 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark23(-0.7943866936932592,-0.017977060591622518,1.1825915102440778,-19.47177394845551 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark23(-0.7969074657621487,-0.023018604729401093,58.47718757875679,-37.687114822794854 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark23(-0.7978209935021239,-0.27833020651941753,1.8515827781125642,-100.0 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark23(-0.7980030507084996,-0.02520977462210294,-100.0,0.012604887311051471 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark23(-0.7982955039510012,-0.02605421379127022,1.184545915372949,-0.4631243490943223 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark23(-0.7985473737664868,-0.026298420738102023,-0.3861244765142049,61.57640270539374 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark23(-0.8006937806149996,-0.18372003639489048,3.9678188492686587E-17,-62.73024432412164 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark23(-0.8048490741441854,-0.13962878867439277,-0.9243709696486201,-60.325170532602456 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark23(-0.8048818291357898,-0.3169694302076087,0.4024409145678949,100.0 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark23(-0.8049316783585223,-0.17360454451547602,7.3740737280326165,100.0 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark23(-0.8130826366519401,-0.05536894650900137,-0.378856845071478,-0.7577136901429209 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark23(-0.8132323041597164,-0.1788820930242649,0.4073813750509374,0.0894410465121005 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark23(-0.8142248227826085,-0.1806739505236238,-22.964371592362532,0 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark23(-0.8157377214366486,-0.3158700924689642,0.4078688607183243,-45.020087500526685 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark23(-0.8162063872364942,-0.061616447678094835,0.4081031936182471,-39.804761896138125 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark23(-0.816661939516959,-0.21631996971403786,0.0,-40.688366944714645 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark23(-0.8182170049747852,-0.10770018842339418,-41.47456900162356,-92.78294895310228 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark23(-0.8185912261953585,-0.06638612571613767,-0.3462367998438727,-121.9049315820632 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark23(-0.8190503634624025,-0.3758729816662469,0.4095251817312012,0 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark23(-0.8191869263660816,-0.06900620899063727,1.1949916265804892,6.300111947923981 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark23(-0.8216350051792366,-0.07247368356357951,-0.3745806608078299,0.8203200848597902 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark23(-0.8228845181074453,-0.0749727094199943,0.7467899289242574,-45.37741574198496 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark23(-0.823506242256348,-0.2868410072620696,-0.3736450422692743,96.6300669026672 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark23(-0.8237010927756724,-0.343815155222935,-42.15277032629146,-0.6134905857859808 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark23(-0.823722038882974,-0.3054929878311681,0.411861019441487,-100.0 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark23(-0.8242747796971955,-0.07775323259949475,67.89152996707291,2095.263834177583 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark23(0.8249378370232611,3.0963775970672747,-0.41246891851163053,74.63566777403085 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark23(-0.8249379710662889,-0.07907961533768137,-0.14863525587648013,72.5892528440364 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark23(-0.8269010718091765,-0.24508545379985636,-21.29407144099104,17.023092781008643 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark23(-0.8273931299549618,-0.08398993311502734,2184.5330544073972,0 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark23(-0.8276350238016338,-0.09986745865762614,1.1847775435131975,0.9838753349427063 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark23(-0.8276647613824267,-0.36981731767723136,-72.93272737303376,100.0 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark23(-0.8282184828512644,-0.08564063890763243,-69.6282515658784,0.17584185038006422 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark23(-0.8287385574024586,-0.3007411653324596,-0.09597504848352333,-23.425772682949365 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark23(-0.828937434071957,-1.633339370564312,-30.331018800869863,27.644924848876645 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark23(-0.8293452084223192,-0.08791601274841301,0.8909897432394426,1.1065706873998096 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark23(-0.8297532285970949,-0.1873582515342611,-0.37052154909890084,0.8790772891645788 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark23(-0.8303763675490092,-0.09259638568646056,1.1022894979718234,0.8303814359212686 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark23(-0.8304291886623865,-0.19955306798987954,-92.02847869437021,0.0997765339949398 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark23(-0.8313200752367808,-0.22490416074813097,-59.93170705544735,0.8978502437715137 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark23(-0.8323131893264382,-0.1295880302673997,0.4161565946632191,127.42754280785647 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark23(-0.8324688964542926,-0.3691637151703018,44.412059511506875,2021.9825971298646 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark23(0.8324878462391803,1.6649762931605654,-0.416243924014292,47.16827078813332 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark23(-0.836438273680741,-0.21243145558201862,-0.36717902655707785,0.10621572779100932 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark23(-0.838222440989355,-0.23902807173231366,-98.26356982735308,88.95864728909692 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark23(-0.8406095902554469,-0.11042285371599803,-28.413274265509468,35.181474400962806 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark23(-0.8408539983837675,-0.11193892314605741,0.4204269991918838,0 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark23(-0.8440953235713167,-0.17485303584241907,135.6223450230731,-7.231331027596041 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark23(-0.8449431683411882,-0.22745874294253557,1.2021673830238209,-61.84734883435603 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark23(-0.8480410804651618,-0.35567194654507495,1.2094187036300292,0.9632341366699857 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark23(-0.8495747857199316,-0.12835324464497333,0.6185215047563561,-17.27866204457639 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark23(-0.8497124983560624,-0.36054191421941684,19.40322308536335,99.02491032853014 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark23(-0.8498107406896228,-1.6915901543507477,23.081276585707897,91.95190904429818 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark23(-0.8510907814619877,-0.27844164087446693,-35.75540824234782,-39.380671286382494 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark23(-0.8545180439179489,-0.13823976104100155,-90.71085085823768,0.146093522601356 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark23(-0.8555127168931901,-0.1857612040210837,-95.1319212407022,-1244.2809089201278 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark23(-0.8556069838671949,-0.1905782855588365,-0.010169302448118506,-100.0 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark23(-0.8565756039714358,-0.3571103614117277,0.6473638153264147,85.41438299517776 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark23(-0.8568334026321496,-0.14287047846940282,-80.14777549593892,-21.17253945274604 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark23(-0.8574596586675937,-0.14448812836820324,0.42872982933379683,-0.7131540992133467 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark23(0.8585571386725294,-1.8825702468988645,0.3561207630545275,-20.265726741217087 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark23(-0.8594521899150585,-0.1501049078990213,-3.4950345563934655,0.07505245394951066 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark23(-0.8597941934413699,-0.14879206305945852,1.2152952601181322,1886.2911691108054 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark23(-0.8599204267475885,-0.3554379500236013,-95.87317363785684,-0.43506167678095437 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark23(-0.8602403473346576,-0.31644159851362397,-69.51833098508037,0.15822076912851374 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark23(-0.8610853941857357,-0.2410066666961208,-4.219238383813796,0.9045865764260539 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark23(-0.8620210323218106,-0.15324573784872508,0.4310105161609053,53.87982255824132 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark23(-0.8627532714757535,-0.3130760197914486,-55.732084090111634,0.15653800989572453 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark23(-0.8631383343255674,-1.7195336566702917,-0.3538289962346647,33.060028461674584 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark23(-0.8636913389509218,-0.30135526450393213,71.29809790323834,0 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark23(-0.8653849979210841,-0.15997366904727195,1.21809066235799,-53.371240172635325 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark23(-0.8678173806519669,-0.20123935899279122,-19.852183077931553,98.64053387886726 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark23(-0.8679169218833914,-0.16503751697188643,-25.8186948569338,-0.10382549578709273 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark23(-0.867920001213648,-0.16504367598541048,-91.69035009923014,66.2071907808839 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark23(-0.8685125249337421,-0.29374598090410053,89.06475394895337,-4.877872374157554 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark23(-0.8691167620972257,-0.349532219882323,1.2199565444460612,0.17476610552791216 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark23(-0.8726109276208689,-0.17442552844684212,-0.34909269958701117,22.406779599583736 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark23(0.872700079331903,3.3161964854587023,93.83914438786864,-0.8727000793319029 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark23(-0.874061881310876,-1.7067181721332685,1.2224291040528863,-99.92770760973302 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark23(-0.87518837698837,-0.2801675035179349,0.8235368780132525,59.92217567055295 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark23(-0.8759905609223821,-0.34735500721820367,-0.3474028829362572,-0.6042959405596573 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark23(-0.8765812082053026,-0.18236608961570955,0.7195747621151969,12.340945812992999 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark23(-0.8790915334207466,-0.2338001868375168,-0.27829957967389435,-109.96297677611673 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark23(-0.8805794640412651,-0.3016611952531721,1.2256878954180808,0.15083059762658607 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark23(-0.8815530139008569,-0.1923412196457972,180.01070571617004,67.49144904423031 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark23(-0.8821670592820732,-0.19982333724879922,-0.3443146337564117,0.09991166888673009 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark23(-0.8827122169711629,-0.23309826772081174,0.37322814053971404,-52.50644273408805 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark23(0.8832380542820055,1.8539660110341487,-1.813671410825243,-0.9269830055170742 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark23(-0.883469554475641,-0.34366338615962766,0.6857443266308542,4.067195822448713 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark23(-0.8837914015678094,-0.3435024626135433,1.0476871033317254,-92.85551120339707 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark23(-0.8841786150299767,-0.19756090326505715,0.44208930751498837,1866.9006808967042 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark23(-0.8857083570640716,-0.2728602784091415,-0.34254398486541243,65.53573744771904 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark23(-0.8863832579719282,-0.2691039184733453,1.156282465076922,59.2719486632225 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark23(0.8871900175419977,3.055762953775355,-0.44359500877099883,25.175788935951207 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark23(-0.8902028753894682,-0.24570660603945327,0.43850133784710377,-100.0 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark23(-0.8903070665814314,-0.3159168336455817,-3.4862835636258804,-80.99089046865959 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark23(-0.8904293133654846,-0.2248510143197887,-47.739701474020784,41.38494128661705 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark23(-0.8907225699864207,-0.21064881317794515,0.42689166314111643,0.890661101806999 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark23(-0.8907289170187733,-0.21128341578990004,-25.16372278908664,22.038896473208165 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark23(-0.8915919309276317,-0.2180890031156309,-100.0,100.0 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark23(-0.8927441256364541,-0.30762312361843586,0.35620452837044064,100.0 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark23(-0.8929056330803109,-0.21501493936611785,-0.057536158494155665,54.23936272856626 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark23(0.8930415732560001,3.356877078068131,-1.0423666317456732,-51.15835603426072 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark23(-0.8932384356869084,-0.2475828710265917,1.2320173812409025,-1.567342568474263 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark23(-0.8942129557551581,-0.22689578751012007,1.4148991057332552,0.11344789375506004 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark23(-0.8971141107046474,-0.2855274714931315,1.233955218749772,42.418161095198364 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark23(-0.9004239246527104,-0.32351959936477104,-0.3351862010710931,-51.83132953189374 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark23(-0.9006075678409096,-0.2831073501040928,5.065010460407109,66.11204924900592 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark23(-0.9006763885598552,-0.3350599691091335,-0.3350599691175207,43.58976675581722 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark23(-0.9013380227353771,-0.3347291520297375,0.45066901136768855,0 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark23(-0.9020872647070285,-0.33435453104393376,42.03940810036153,53.42019051632952 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark23(-0.9021424031419871,-0.23348847948907792,-49.15436044004875,139.23487514753936 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark23(-0.903167457775759,-0.2587309357384455,0.9542498660021197,97.52362924310088 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark23(-0.903370052173874,-0.3337131373105109,-27.139402715392336,14.727544752339696 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark23(-0.9053789177170622,-0.23996150863922838,0.9856844189173657,0 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark23(-0.9057448812237556,-0.2528323438885247,0.4528724406118778,-67.8814521209382 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark23(-0.9062729857742813,-0.33226167051029876,-0.33226167051030764,3.543942655752332 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark23(-0.9064933039191896,-0.33215151143785254,0.4532466519595948,66.92837931019879 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark23(-0.9072722661044623,-0.33176203034521684,1.2390342964496794,0.034821936773455686 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark23(-0.9081366320523574,-0.26340088924124716,1.1966804179977046,1879.7909858785783 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark23(-0.9098562003901844,-0.3289609106953233,0.2838487692000102,0.1905375526713329 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark23(-0.9099137454677766,-0.3304412906635599,0.6952128519724707,49.44021693313705 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark23(-0.9103098552657649,-0.263573283459936,0.456163515860608,-100.56620353696559 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark23(-0.9103774904257389,-0.24999026341772201,17.3816753246731,0.12499558052883605 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark23(-0.9104489894077057,-0.2501016520205153,0.45522449470385284,0.12505082601025763 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark23(-0.9122449706789795,-0.2536936145630623,-97.52282245863307,-58.67878612574703 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark23(-0.9137145361559109,-0.2566327455169284,-0.3285408953194928,0 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark23(-0.9151435592359678,-0.2594907925418029,61.63916137533709,-71.41548875631275 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark23(-0.9158812860108095,-0.2609663870011674,1.2041556400493427,-100.0 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark23(-0.91633323688594,-0.26711889272034084,0.3522483540353127,30.99793223002547 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark23(-0.9195246910794412,-0.26825305536398614,1.467825590049043,-93.2175083575139 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark23(-0.9212522946786175,-0.3088262815567799,13.16741551193816,0.939811304175839 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark23(-0.9214065024067875,-0.2750640567682583,1.1379890825741001,61.227579356296026 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark23(-0.9224319905124043,-0.27406765423426,0.5575227842157761,-1777.3805027244703 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark23(-0.925137667179266,-0.3009634261573577,-98.38913757697688,4.368521331888854 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark23(-0.9313612198954495,-0.29979800717545835,0.4478227585754918,-53.88537324924642 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark23(-0.9320051994322075,-0.3193955573327586,98.87400608184021,0.15969777866637813 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark23(-0.9324825913970013,-0.2941688559991063,-0.31915686769894747,0 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark23(-0.9363767065907335,-0.30676910044157496,-52.280358894426136,87.81921300834333 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark23(-0.937085785154502,-0.30337572138393315,-0.31685527082019727,0.15168786069196658 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark23(-0.9389814560440425,-0.31256144149899256,-0.3159074353754271,0 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark23(-0.9401415078263343,-0.3141592653589793,1.2554689173106155,0.15707963267948966 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark23(-0.9659571654662522,-1.9319143309325042,-38.61472520634065,0.965957165466252 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark23(0.9674180311918456,-0.9804273225123123,-11.192825583711155,-48.35337136648165 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark23(0.9706327546006235,2.5411154899053607,-1.2707145406977602,-24.832500827184738 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark23(-0.9844384275331259,-0.04482931563620492,-84.04581155259329,100.0 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark23(-1.0204742022862254,-0.950840979927392,1.092777926213863,-12.096569815120912 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark23(-1.0395290918166344,0.2348772992694352,-73.33664122662832,-99.55677283886834 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark23(1.0454989986027505,3.661794291573264,-96.82439021229493,-1.830897145786631 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark23(-1.0471541370469792,0.4819837211483684,0.5235770685234896,-8.864424145455757 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark23(-1.0619321936873638,-0.2543648196418257,-100.0,65.2682192758225 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark23(1.0670255825344843,3.7048474611279087,-9.845759462888125,98.67853846810603 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark23(1.0742122502872506,-0.5522068916694793,100.0,0.5253839141981756 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark23(-1.0796256042550376,-0.24555639083121322,-100.0,-1489.5760053158951 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark23(10.814055789720015,-5.407027894860008,-42.03519803693655,18.190270460178546 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark23(-1.091315009555899,-2.1826300191117944,-3.314495602089485,0.9889203529847409 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark23(-1.0979213024724768,-2.193155389900122,-0.7574802158567148,25.443274628375345 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark23(1.102673369002141,1.2909878085618152,-0.5555248200838853,100.0 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark23(1.106384086166486,-0.9972524807371161,-90.0866497642759,-0.28677192302889637 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark23(1.1264894244178663,-1.3486428756063806,-1.3486428756063815,1.4597196012006282 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark23(-1.1277030850313106,-1.9989480771161559,0.43124062854235734,33.739591877599004 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark23(-11.347461391985766,-22.69402347266963,5.661804418525602,39.6212818709582 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark23(-11.41324787208579,-22.627968909036127,-65.79529165122474,8.963440630879056 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark23(1.1547015015077244,3.8785801929656194,-0.18465148975615264,-96.21626334005542 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark23(-1.1583706606564725,-0.7459449945180483,-0.7072557834844198,-0.5872721159639548 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark23(-1.1604001785152607,0.4756583573795913,0.5821074719228995,-33.19992207431961 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark23(-1.1625895381705575,-2.314910735383249,1.366692932482727,-68.74299821747339 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark23(-11.772941494420728,-23.54588081250252,-32.18258590405746,11.77294040625126 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark23(1.1832430517970887,2.366486465595332,-1.3770196892959925,-100.0 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark23(1.1845032183589241,3.93980276187658,-100.0,-2.755299544335738 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark23(1.186871115406079,2.374178312432051,-1.378808653772396,-0.4016909928185773 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark23(-12.035725894796155,-22.500655462797415,0,0 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark23(-1.2215366376809758,0.36042072472175746,1.396166482237936,42.232275475663755 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark23(-1.2310848886158823,-2.416537134455112,0.45730046896846344,-44.365112520937224 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark23(12.325548049643691,-6.931767136160241,-5.377375863067585,-3.083595517317734 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark23(-1.2350089289058563,-2.469900756918083,1.4029026241883016,-82.0172548273816 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark23(-1.2754324182252954,-2.0803534202212153,-58.51714606033298,100.0 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark23(-1.2861963062220698,-2.572389384652161,1.4011339222534305,93.96317941408856 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark23(-1.288298623138292,-1.0709193752261346,2.212103697938193,-100.0 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark23(-12.883302438552263,77.67385315751528,0,0 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark23(-1.299737012577238,-1.0555659582259953,-72.40330165058128,24.089581410579754 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark23(13.091373447859908,-63.207513802331135,-36.0936853066006,93.98599776692262 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark23(1.3153738775223025,2.9982625276301094,-1.2008976595420693,-46.9986216823882 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark23(13.161812993199076,26.395420593851192,43.76337417748053,25.98408122138941 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark23(-1.3228872964927816,-2.6457482293823755,0.29068576800558477,-100.0 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark23(-1.3285084364612192,0.6642399255889132,-0.12114394516078494,0.45327820060299173 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark23(-1.3322676295501878E-15,-2.4424906541753444E-15,-0.7778348653270318,-19.79540102238439 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark23(1.3529590510582223,-1.0398173816763474,0.10891857730378585,27.825303484624243 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark23(13.571033686310468,-6.876108041822159,-12.263120101713199,3.4380540209110797 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark23(1.3607763742984555,4.27795513210085,-1.465786350546676,-2.924375729447873 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark23(1.367025288996874,2.734050577993748,-0.1440414736327638,-0.8917769042314992 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark23(-13.688304103382501,6.587515468251627,-58.23201018986385,-100.0 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark23(1.371303319314144,-0.6858861059385822,-142.96594931440077,179.61470271898298 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark23(-13.832070962945783,7.827891457017782,6.130637318067826,6.296320999381686 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark23(1.3948399402404839,4.360476207275843,-0.6974199701202424,-1.3948399402404728 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark23(-14.099208777650624,-28.19840605030441,7.049653840874707,-56.585015951140974 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark23(-1.4296712886299148,0.4319249243829181,-60.81057720078962,-70.2048564505962 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark23(-14.35406773527559,-27.339872050032614,7.147410771971907,13.672503383425546 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark23(1.4457975065110615,-0.8417256121293335,-105.94964843829291,0.6628185347572583 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark23(-1.449256817749645,-2.8777417621231183,94.9987819664119,47.73727176086923 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark23(1.4638694933951077,-1.3206283345815417,0.053463416699894406,0.6603141672907709 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark23(-1.4689710298314747,-2.937796580697121,1.5198836783131855,1.468898290348532 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark23(-1.4790802710592623,-1.3873642153236352,0.7395401355296312,-0.09171605573563069 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark23(-1.481332384388054,-59.39719514238422,0,0 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark23(-1.4884079942654642,-2.568801273414318,-0.04119416626471617,46.83725292958316 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark23(1.500180680669132,3.000361361338264,-0.750090340334566,54.53509169375337 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark23(-1.5055128070416182,0.752756402926387,-41.20847417982213,0.40901996193425477 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark23(-1.5065439502119937,-2.6984819092774375,1.2349223554289224,56.95562932368108 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark23(-1.519265006759221,-1.4677336867235458,-39.35786344889569,1.1817056366366692 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark23(-15.204841492555516,87.65366656639563,0,0 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark23(1.5459305240985854,-1.558363425446741,-0.9345434999757978,0.779180723235986 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark23(-1.5475418289388285,-3.092610244542236,1.063625043332382,47.09910023883887 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark23(15.565922781105346,-7.782967837396905,-30.559504857928093,0 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark23(15.61808735896632,-45.293532305813436,-97.7566505927879,-15.099967800058138 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark23(15.638235589345038,32.84726750548497,0,0 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark23(-16.063488673652376,-32.12693762663989,-100.0,16.063451131165568 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark23(16.324938091319634,32.66915766548021,-26.98758863581677,-16.974283218957503 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark23(1.6401029502023583,4.851002227199614,-72.75957924940705,14.070252128082139 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark23(-16.55867609561628,-33.11735212053265,-100.39027468741045,16.558676060266325 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark23(-1.6627569544050396,-2.334456153482533,1.6167480781641106,-43.60051775331041 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark23(-1.6840106433730846,0.056611013634525725,-2.373661730884785,-0.028305506817262405 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark23(-1.7017345667871349,0.08019930394805115,-32.42126661331199,57.30984981554636 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark23(1.7085158474940336,4.987464224948371,-1.639656087144465,-17.416276013610318 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark23(-1.7418056083325097,0.08603471795940125,-72.30089485768367,7.609021890005764 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark23(1.7494989819272457,5.05364577571115,-1.2676790002433072,5.327374188379334 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark23(-1.756768975926972,-3.465512807040498,0.22547197961765686,30.79154462844571 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark23(1.7589696614785415,5.088735649751979,-100.0,-26.89485369243232 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark23(-1.8500198806348027,0.7021031762408548,-185.8285293165049,-0.37876614267886277 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark23(-1.8825952662663168,0.23421227566697891,-14.081950240383623,-0.11925617803565171 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark23(-18.934251659628714,-37.85771132431727,8.68172766641691,-2.3394057433105644 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark23(-19.01257349319773,-37.40922462337705,0,0 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark23(-1.906344083113104E-4,2.63600881168688E-13,-13.351580217437826,0.010879926696711699 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark23(-1.9064244171819975,0.1678317109491534,45.72087914921149,-100.0 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark23(-1.9186164567206916,0.9582796042786775,0.17453123824956632,-32.96579713699499 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark23(-1.9189818769811535,-3.837929577404344,-66.10371729924988,78.15682589034635 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark23(-1.9279901520101026,0.1789085072848206,-90.92930146642836,22.41201396133636 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark23(-1.934330321500362,0.6320643145420063,0.9669723413123656,-25.429900766842565 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark23(-1.9574613515048753,-1.9036813384437634,14.793483027689632,0.16644250582443343 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark23(-1.959854027703722,-2.3489117286125554,0.979927013851861,-23.186393385429355 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark23(-1.9642916198754803,0.9821458091153603,-2.976865605374524,-0.49107290455767066 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark23(1.9833950601389392,-1.777027859666072,-0.20629936667202126,23.37932135428824 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark23(-19.846281613633302,9.845095230848916,2.4583347904626014,-4.922304772579298 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark23(-19.889264198503497,9.159241693597545,2.729610148677729,98.01346649115303 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark23(-20.03840822346767,-71.8422338908114,-51.8479828989808,-45.95843837666458 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark23(-2.009782372599389,-3.9973254869964445,1.7902893496971428,-19.269588103690175 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark23(-2.032222323260966,-3.1855957300638305,-113.13418329340755,2.3781960284293633 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark23(2.0438602813856965,6.240049033709115,-75.89189988957123,-5.190422122497375 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark23(-2.059290908205624,-3.2037303389768,-37.955104577968605,36.94478252237357 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark23(-2.07072743280368,1.0207238895152688,0.24996555300439172,-15.774554498374634 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark23(-2.0775266156014967,0.35782301817811235,149.47899473043975,87.84021713559042 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark23(2.0796628612752732,-1.0401973759964998,-100.0,-100.0 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark23(-2.0946779696164914,-4.189253303987543,0.9683904553582848,22.764665830849488 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark23(-2.108313928731021,0.3880475143287093,-84.77749119271573,-0.19402375716435472 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark23(-2.1191096187413896,-4.23821922509673,1.6739161714936723,1.3337114491509166 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark23(21.281361389113613,42.61500136083288,0,0 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark23(-2.1333105707464863,0.47912671357648867,-31.135686706898092,86.6546255201329 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark23(21.473046091906255,80.67012629434149,0,0 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark23(21.515363531266665,44.5805295463507,-11.543079929030782,-22.29026477317535 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark23(2.1682280787383093,-39.21636438450358,-10.898248059434295,-14.787829110653377 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark23(-2.221171930908821E-14,1.1105859654543904E-14,0.7853981633975313,-100.0 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark23(-22.313070168602692,39.20850058732236,-68.91061040608888,-6.4049727829752925 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark23(22.396969623273108,95.73228712199901,74.27243814014767,-82.6807379935098 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark23(2.256551629828566,5.423360778710836,-0.6326655369079227,16.26746654429899 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark23(22.597165109590335,-53.15303302311112,0.8140853952534712,-11.839627521378134 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark23(-22.632601760357048,-45.26520352071409,0,0 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark23(-2.267804950976921,-4.534020228282473,1.1790007546676982,12.479172511648464 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark23(-2.3277913666394845,1.1093071239285024,-103.55781551703248,100.0 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark23(-23.31064817017254,0.17862717183146515,0,0 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark23(2.3761771296738634,4.752354259347787,-1.1880885648369317,88.12044967606927 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark23(-2.394276789995117,1.1971383949975585,0.8799030377044182,-32.003366767473196 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark23(-2.416935792548692,0.42778935112431465,-2.7676959537747203,-1.16104016207808 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark23(-2.5622792217066888,-4.675864797444416,1.5630161410518555,62.02522338221073 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark23(-2.584741323426267,0.5069790709415904,-59.183776461024024,-171.78562229246162 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark23(-26.065356389303204,25.549232489185236,-51.41469885096533,-13.016201007456642 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark23(-2.606972580300051,-3.713471440811931,2.1171430282130554,-100.0 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark23(-26.261139478708664,-52.52227895475559,91.86810876130585,26.261139477377796 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark23(-2.633031824314518,0.6364241134066753,-100.0,0.4504866565687732 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark23(-2.6345181204976083,1.0791260187256844,-100.0,60.7414889736448 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark23(-2.6348155113674863,-5.258147010197519,-81.83694018642882,173.85368497250903 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark23(-2636.787633381216,97.93714832388454,0,0 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark23(-2.6380836165522163,-4.468529095793505,0.53364365978575,-59.812783058051075 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark23(-2.6435209267871933,1.1383587036141345,-0.7781023921239183,90.36535541942222 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark23(-2660.7270440015645,58.676033991506614,0,0 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark23(-2.6848633353748474,-5.360930629714421,100.0,-2.8123447415728506 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark23(-2.6934644778845485,1.3362384979484014,0.5617149443709842,59.81563918499795 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark23(-2.7015948072266154,0.5654006737187582,-59.13493137090229,84.31186767506745 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark23(-2.731388171998644,-5.448530638273823,1.033708451842775,-42.82854707297818 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark23(-2.783187206964118,-5.535358231669689,165.67565275030415,-118.96949608418865 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark23(28.414482408213303,-95.95217109622357,-57.31882453988719,-40.62273994932579 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark23(2.861466618923841,6.902489021185762,-0.6453351460644722,-5.805916049177775 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark23(2.8747333613237647,6.642116200075886,-1.4366718457679997,-5.672887920330138 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark23(2.8778752178540956,7.3451063509371695,102.91413654503638,100.0 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark23(-28.898683801920843,-57.79736760384168,0,0 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark23(28.92641467560847,68.67760481882766,5.9398103576250065,61.61621800549824 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark23(-28.936726266395095,14.178157682157142,16.619902674971026,-91.03865849734095 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark23(28.991373095571447,91.12649333519872,0,0 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark23(29.448396712246108,74.7790224425153,0,0 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark23(2.9570472228552815,7.484890772291518,-1.7721652265779884,-2.9570472227483107 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark23(2.9656200090576283,-2.0805084105741303,-2.227762585222433,-100.0 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark23(-3.0076728303247675,-6.002823916275254,2.289234578559832,3.001411958137627 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark23(3.015792636184726,-1.625592621702464,-94.10308654597308,95.84459297032043 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark23(3.0506841690494517,7.640735143443556,-2.303953511154991,81.00217561404448 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark23(-3.0527137370597104,1.4620733024013284,0.7409587051324069,-36.91955776715585 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark23(-3.082273280287348,-4.5937502337798,2.326534803541122,27.42865584661335 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark23(-3.090361333778316,-6.180498830730633,-42.97438271952974,3.8756475787632354 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark23(-3.122147952689664,-6.244295905379328,52.53215345390065,31.268526063514216 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark23(3.1315573380953814,-2.3511768324451388,-0.7803805056502424,-51.43061485071003 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark23(3.134778290247818,7.26778969648655,-0.7819909817266791,-94.74008160518963 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark23(31.448170260355397,24.40175737898778,28.366098911695957,-97.55700301682559 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark23(-3.157997479368081,1.1821542522003323,-5.640432608404607,-0.5910770996521102 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark23(3.1893932998675143,6.50321884600741,-78.00620199330267,-3.3964303622173015 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark23(-3.192824687417771,1.5639419779396304,0.8586371474470263,-28.215437324150088 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark23(3.233913206219106,8.035202839646297,-1.3613369154399593,42.6069389013206 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark23(3.234870522029035,8.039645174892208,-0.9270947294787288,-3.234207707545086 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark23(-3.2942940005136743,-3.3378249378188247,0.8617488368593889,-100.0 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark23(-3.314466988009121,-6.591394378001392,1.746965327299421,-87.04528675775514 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark23(-3.321963958599067,-6.6438281679524005,83.56807172029986,99.64048830063302 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark23(-33.809976398580304,-66.04915647036572,0,0 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark23(3.3990786299960702,8.36882466139102,34.13026232783074,-32.456233067141525 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark23(-3.440182851151547,-6.815387803518091,2.0642353070695707,-21.599041407718303 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark23(-3.512569694058592,1.756284847022797,0.9708866836318476,-0.8781424235027832 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark23(-35.51842962926048,-69.46606293172607,0,0 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark23(-3.552713678800501E-15,-2.528580129924722E-15,-0.785361950546828,-40.268205521207506 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark23(-3.5561537514366823E-4,1.1665768229608883E-4,22.776349586801047,59.216720371385705 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark23(-35.58240888754858,13.346911133350275,0,0 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark23(35.902666515303,52.59153419056338,81.03687994582054,26.660225318903954 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark23(-3.601379868369591,52.058529634725744,0,0 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark23(3.602415520761167,-1.8012077929649821,-2.586605923778032,0 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark23(-3.611335425332849,-7.214116423304639,50.41937951349477,-13.673472123194465 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark23(3.618281346026978,8.807359018848851,-4.492262329656401,-4.403658042674188 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark23(-36.79386491522283,42.91466611651134,5.550087678627861,-31.201221694763632 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark23(-3.7477196105374517,-5.926037469435829,1.0884616418712776,-42.34066440803393 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark23(-3.767556794352269E-9,1.4747316660137717E-10,1.8837783971761346E-9,-99.99999999719775 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark23(-3.8110814529930903,-7.515828581792741,1.1201425630990969,-38.65352414684649 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark23(-3.8746083370465243,1.1519060051258139,-100.0,-2.2858673071242137 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark23(-3.892098898298637,-7.784196780315446,-61.14102920173795,5.462894716952619 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark23(-3.9024922978176715,-12.673674325809788,1.951246148908836,66.813877923401 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark23(3.980661674869153,8.194793255654758,-23.975927806450418,86.22348406268084 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark23(-4.014253570690536,-8.028506608390664,-30.757660783228204,3.228855140797884 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark23(41.38582427800142,-77.27477165605319,28.85588881439071,76.5487673425688 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark23(43.17304925456077,-29.998401641395414,-20.80112636276512,14.252671449013055 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark23(-43.20913193009748,-84.93888167787549,0,0 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark23(-43.247137917010214,-86.494275504316,-98.69287715350855,43.247137752158 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark23(43.27468835278634,88.12017303236757,-24.55634311002433,-44.06008651618379 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark23(-4.357996810232715,-8.269550136051613,2.9643965685138056,95.18379949311979 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark23(-4.3678445706457865,-11.006829715498363,5.1772685507490195,-138.09447421564843 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark23(4.409102532896071,10.389001392587033,-2.6677720154897155,-5.194500696293517 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark23(-4.594087632778607,1.5116456529918556,-37.98496516866644,-0.8161615783732783 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark23(-4.6195176144167585,-9.236920464260628,-100.0,-73.13371765700865 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark23(-4.66733851236436,2.333669249966151,2.7040837910345146,-0.3814364615856256 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark23(-4.711017755400081,-7.874616014558569,1.570110714302592,-39.25331868260948 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark23(-4.742663699420376,47.476276512663674,-82.34532845953693,40.3632098277223 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark23(-47.451245511494754,-52.325774377026946,-46.40298754621406,-8.302982534738163 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark23(-48.09725706545973,-94.62371780412457,0,0 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark23(-4.878520375519326,3.1922602873262704,3.0231904917319716,-22.98190971827632 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark23(-49.418178327928366,-95.2477423067208,35.25809484685496,-5.6007071415719025 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark23(49.56727286452906,-56.42719694286469,50.53176563958314,0 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark23(-49.627087199182625,79.01370713925445,-93.8484113884773,0 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark23(49.73421708518993,99.46843417037987,0,0 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark23(-51.20610596201012,-81.28724690690916,33.86943555306047,-86.35604036488849 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark23(51.39587200256341,-91.08999445132338,36.287915082903766,0 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark23(-51.492259646821495,-88.99422981401031,-44.88609168569893,-79.68764488764228 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark23(-5.214996746886624E-16,-5.989105478565845E-16,0.7853981633974485,-23.33170799009598 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark23(5.286566360414291,11.98734251253445,-87.09661861056581,49.77259627251522 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark23(-5.327455761048722,-9.151625712407476,1.9113111551057413,3.8304652855937764 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark23(-5.346339178591286E-7,-1.0692678356947563E-6,-179.83384937423696,0.03563146949597898 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark23(-5.353569998500072,-10.70665453013289,1.891386835852588,93.31792119605132 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark23(-54.00931445603324,-107.0582297795048,0,0 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark23(-5.447480012306578,2.723740006152944,2.9529413688607034,-1.3618700030764757 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark23(-5.584489228009637,-10.873497829252583,-93.52637008457532,5.436748526243903 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark23(-57.192301398837444,18.767276361090836,8.664505033532777,-6.376309964723561 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark23(-57.44106928018458,-22.5280723299975,9.43991984025088,-93.28497440761015 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark23(-57.484744485103874,-9.500492512400442,-71.94127399642265,-53.68418599422655 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark23(-58.347362041638334,28.397712565594315,36.47256046845514,0 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark23(58.58249313524584,-39.80601587261332,94.41474598441766,-82.44531241869244 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark23(-5.911838539880618,-10.659861280510507,-35.56671005473608,127.84727837764311 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark23(5.961298724015732,13.239640837299328,-4.3952323226423635,-52.118080350053255 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark23(-62.34572993559156,65.15751276086814,-15.557377003470705,4.784936938102732 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark23(-6.236191300367583,-10.903822742345847,4.0472762417495165,124.6639072316303 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark23(62.94100137967044,-93.06762448638753,-94.7553115777936,-79.95837707868114 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark23(6.490085750246871,14.430720126738063,-4.060440367410175,83.10567935119542 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark23(65.04202652173063,-55.10751294677583,89.91105785616813,70.52715637049295 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark23(-66.01695018159216,-57.826538206323576,21.907108836255347,45.88670566151228 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark23(6.624777224418304,14.820350774756804,79.5396402304064,-7.410175387378402 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark23(-6.661338147750939E-16,-8.881784197001252E-16,-18.292511719438806,0 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark23(-67.25961048618565,29.424512774469548,-6.475245182012031,0 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark23(6.751793897366892,-3.4024782453047364,-83.47477118724015,5.1665324213841455 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark23(-6.861711848015976,2.645457760610889,4.216254087405437,0 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark23(-6.965052965057783E-4,-0.0013930105930115289,-2.7755575615628914E-17,-0.017300854409769917 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark23(70.07596132309459,96.80354150862894,94.3748433789967,-57.64267216912846 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark23(7.1531420502327165,60.87129218927183,58.11860137734374,-18.909376135742775 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark23(7.156335841527641,-4.275293432267634,-3.559629364887055,-100.0 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark23(7.385147476101935,65.4384124268571,48.79360210520488,25.078273399006278 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark23(74.36253516676135,-43.01528664898369,0,0 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark23(7.442782359882056,16.453067823116523,-89.76582130417259,-19.2224227185459 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark23(-74.50836168355401,89.03954839474068,-27.942753419271767,0 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark23(-74.81271942376932,89.2867140593055,0,0 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark23(-75.15887865215639,44.796842670910124,0,0 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark23(75.20160425500592,85.22003311199464,91.31316461195854,-69.53677393842703 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark23(-7.6007935671304665,-14.344047359087341,0,0 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark23(7.607420957043697,15.214841914087392,0,0 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark23(-76.75805250278506,-92.65780464068594,-83.51439969794342,-26.759138290412054 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark23(-7.681589509204708,3.8336315095547207,3.055396591204906,-19.192056868223716 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark23(76.9682268263771,-38.84421615661668,97.63452529561928,30.854874515188953 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark23(-80.67734136128466,41.88476201777178,-39.97984566075967,0 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark23(-8.152869263532773,3.291036468368939,-56.85764520105985,-2.177803462877008 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark23(81.62678065786949,68.82780256552974,62.090781883538426,-20.929244272397312 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark23(-8.173996955012158E-10,-1.6347993792020787E-9,-0.7853981629887484,99.99999999920487 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark23(-8.305877254371476,-16.52030204387177,4.152938627185738,-1.9502500529361546 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark23(8.470569896708561,18.511472968141824,-4.847687367394219,35.59445782074985 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark23(-84.97490393674201,16.63239766891209,-71.86428653472845,58.92296392963516 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark23(-85.57350929322949,5.4635602103516305,-23.868739068678906,-0.05394113625436603 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark23(-85.82809337045862,-73.59087654505325,-65.64137657782898,64.44239607931567 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark23(8.686406148618591,18.94360862403208,0,0 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark23(-87.10103202197126,60.24767312410066,-85.08509116054783,-28.402308105870503 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark23(88.62759303331984,-59.26762689792589,-29.126718384951246,24.33127420665157 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark23(-8.866646229959681E-4,4.433323114979216E-4,-62.4790669586011,-2.216661557489608E-4 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark23(-88.75613156577626,34.436098077537594,93.35404469814014,-56.948475713575 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark23(-8.881784197001252E-16,-4.440892098500626E-16,-74.17097370035842,0 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark23(8.893719700251618,18.81852196297887,-16.772859385860766,-8.623862818091986 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark23(-89.28734452693467,-45.13358996432642,-18.437603979839068,-4.341133220464499 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark23(-9.045222989987876,-17.71981932364196,-100.0,37.128359049180645 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark23(92.09592352019044,-32.641028429542814,-75.24944635115183,-22.306234747609977 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark23(-9.278159588364082E-15,3.776772314623751E-15,0.7853981453685795,-56.520220567864534 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark23(-9.420264413621657,-18.840528576595425,5.233784197131665,9.420264288297712 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark23(-9.503148865275023,-18.935097369656823,-25.219188430287193,-74.57530267425534 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark23(95.96604583675372,58.45296303980797,65.76982295448707,0.1045330343491031 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark23(9.629573598191875,20.829943523178645,-4.456899985500326,45.34829790741791 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark23(-9.633517413741831,-17.857957079913124,-10.116248387425843,9.71437670335401 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark23(-96.44495230679846,-47.06944374442059,65.17866394862011,-34.2098261816909 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark23(-98.29973956742191,21.965902112279892,0,0 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark23(9.909293473889884,20.563847224231484,-4.033171970045773,-9.496525448718293 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark23(-99.37675470379077,-16.678187143620107,-20.305022144232737,15.553721019000207 ) ;
  }
}
