import org.junit.Test;

public class Sample31Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark31(-0.09337911058740644 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark31(0.10944854580685615 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark31(-0.4049950962613398 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark31(0.42130200334140255 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark31(-0.4999999999999999 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark31(-0.5000000000000001 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark31(-0.5000000000617105 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark31(-0.5471093471272042 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark31(-0.5923344327357611 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark31(-0.6604507751540893 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark31(0.8506323606176664 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark31(-0.9966278058583669 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark31(1.1439246098055236 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark31(-12.5 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark31(1357.0277061133002 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark31(-14.5 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark31(-1.5 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark31(-1560.9395669238759 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark31(2.5340218187253782 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark31(2617.776857793111 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark31(-2712.8234917847144 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark31(-2.7395727881109195 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark31(-27.5 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark31(28.487061093992168 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark31(43.37397049394883 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark31(4.607238505534288 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark31(-61.78806321826038 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark31(-73.07237453863314 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark31(75.43722597083485 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark31(75.46324654477988 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark31(84.68035371440166 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark31(-87.14750673433261 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark31(-92.82250250363546 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark31(-95.67899195389391 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark31(-98.27439728543928 ) ;
  }
}
