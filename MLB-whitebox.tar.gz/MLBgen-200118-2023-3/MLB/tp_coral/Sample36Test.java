import org.junit.Test;

public class Sample36Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.025412559820253477 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.054443733737926436 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.05809117367547856 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.13658383007249597 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.1590888704298834 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.21760328477029134 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.23790289375180862 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.30681469934918937 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.3076243287727891 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.356335824258025 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.40773505131666354 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.5157101395161021 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.5744357819802417 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.650915794714436 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.6851441292997862 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.6880688950306819 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.7342891705105501 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.7988570647583799 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.822718793038618 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.823752724874808 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.8545546303921014 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.8656852353303464 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.898204923231873 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.9515550880225163 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.0000097856548393 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.01305542601041 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.015505939069797 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.065737333294564 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.103930967448477 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.126888154121104 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.15975055638107 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.226856117066504 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.254316815592517 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.271439478306647 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.32419868010777 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.463139196914753 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.464891065914216 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.472741214426406 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.528331455547786 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.564616765397389 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.604265574961886 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.774063687121043 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.801439071093895 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.850042360202352 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.868643861628314 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.911011226803979 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.92881369679715 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.975456655191522 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.982729233436416 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.003035765187505 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.009198665012505 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.018177534383284 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.048511274272713 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.1068050219599002 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.090899615834715 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.097848216090895 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.129341304117418 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.132992329005816 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.1859416990755 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.188877835037417 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.197416845409052 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.208746632820294 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.211713184499828 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.230310575536052 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.314154578638536 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.328935886203851 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.1372084817146515 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.383062814893009 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.415769073093202 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.431480819774052 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.471512463558284 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.570369268199372 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.584071445527485 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.158475052573209 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.652942719877672 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.691083299360244 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.708797887188837 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.711982104198611 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.743650577849849 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.1797107403530305 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.806362849079875 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.828770233607443 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.89522085932957 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.94615696101502 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.973924220601532 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.97717269187217 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.03674962344543 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.056028561817072 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.2120909502668695 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.265576181070443 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.271470110959683 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.271764787889722 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.284856671279314 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.232595164407831E-32 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.32690011642454 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.335345926802347 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.33575382884122 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.352341041753661 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.353347359175501 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.420771607016135 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.518752785392095 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.538588068057791 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.548523050106368 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.554355117578979 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.607349330451683 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.802404350078447 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.85849373986683 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.881879643152729 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.888311265597551 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.92068611976012 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.921860707863871 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.0235785080353 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.05515377461927 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.075621193344602 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.089590655544 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.10640531738008 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.167958883759482 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.184988856600953 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.227640815274654 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.242304823147762 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.3266714545577116 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.278969966755596 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.347474480623205 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.363953726130262 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.3416502699047612 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.480718537764915 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.492553985678683 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.515933138994285 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.56327181835313 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.3566455085005487 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.600023863743743 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.629362679998252 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.635040386136893 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.648391880478854 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.659331423847163 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.73621084892082 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.7364039012365 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.746407482583507 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.764602968787472 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.784308453885743 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.792322210722858 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.79766603425962 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.3835741126847694 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.850494102317953 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.874083778995157 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.38823440188105 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.887582968950369 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.887974033734565 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark36(0,0,1.3896287844603137 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.917966878900032 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.925516232266503 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.956344932772808 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.961268932478845 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.987676523042069 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.026120203523845 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.030260944301105 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.4034271710124528 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.4056790661479965 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.196047276600197 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.228097769615445 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.353079057558801 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.379124234371886 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.41326416158202 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.423260232955244 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.592101923659499 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.62399396697198 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.4633189383311134 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.65437158942295 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.669151254965357 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.4708938443118882 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.80016271962819 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.830671760121021 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.831411718387201 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.487689525613618 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.919014480709777 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.962451222919796 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.033376071047869 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.5041172843509827 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.042931817818015 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.046073903459117 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.04713943939457 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.07567446989016 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.081479522940782 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.200860500265705 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.202393098934337 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.354826823209166 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.365742012294149 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.423947027720942 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.443631783752537 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.447743980872161 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.453945510866319 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.471790553264 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.5473351579472734 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.481508455031928 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.48620253532691 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.494302150832496 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.531903617191745 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.537905375977033 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.541105901300341 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.544612643011519 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.561858057885587 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.56349848549965 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.631983346843569 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.69303034489809 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.69719502167095 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.702415570617319 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.735068805211895 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.745618653497147 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.5772646767618 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.83521262178067 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.855453806736449 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.874211580051451 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.913425918386253 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.937306575360893 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.939780240800204 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.950299595676753 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.957779278862546 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.967211685530174 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.971192505403152 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.97996285720275 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.005879632128384 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.014978580848194 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.017687965566395 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.18643418215069 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.218909662308164 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.306127278033998 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.353112822100456 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.35693630309217 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.36618276857824 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.39147108132677 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.399201041295214 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.40742038789527 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.429380016219497 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.432907522243084 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.453548307711173 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.473107569113537 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.475312560647453 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.48168267550163 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.6481968247562122 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.494047598990264 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.650619344851421 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.549683462948764 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.55692377608898 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.646555325887718 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.667694001663122 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.694033143221688 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.697825250266305 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.701067903124184 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.6754471043978612 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.77266455946713 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.774924130593575 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.78958984356818 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.826250092473757 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.845370920540347 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.85593201747595 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.872559846051942 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.689889589344574 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.915775784189165 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.964168217839187 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.970031403986937 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.99166988954876 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.997861440134756 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.7026356682207933 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.083379410978125 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.149918016217725 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.213011312705476 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.214211410024618 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.235795102743865 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.25233589955721 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.27745316353125 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.284251165432465 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.303587921040048 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.3394588104981 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.41259137653772 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.422056385039582 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.7438610382123585 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.451051887303976 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.46303354195649 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.507514293476234 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.52526487683494 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.636638336614325 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.656860037536887 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.6630278203652 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.767987937872391 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.68929715260829 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.71691680087673 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.72713763111986 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.731226648964338 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.743748838525434 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.802740942237946 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.847669533207707 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.78665086339403 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.951708574147474 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.97727873111367 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.978618564743854 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.7980308189773808 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.011990540442298 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.025961130287385 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.05468631906875 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.093981817904535 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.8122485023141337 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.138689662723294 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.153874625085663 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.28924070591225 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.299866362493418 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.392029763235456 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.402850072077868 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.414866897382453 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.533911501875338 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.539298679310974 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.539776329592968 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.70221117597785 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.71441190953766 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.727563049950362 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.800270579524934 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.81142945730747 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.811749519369997 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.892247192777404 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.8897265154021596 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.910279350682018 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.912176918166708 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.976910400183073 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.8982518135284039 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.99341289788086 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.9031711523140586 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.037719826412797 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.087064629843127 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.144255709722756 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.149667232756954 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.291835496374034 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.296676695995814 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.374477441280362 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.404802473496517 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.407338399260226 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.9446360903511817 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.45414519881399 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.489919305337096 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.50353727499845 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.755291676851243 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.771966088082678 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.80844772833987 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.812223546865297 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.839616560726682 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.864589122429493 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.932899448045475 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.9936952264196748 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.004598216151038 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.053571677430696 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.058160758461653 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.09709196273448 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.097120940660645 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.100048873682823 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.012163951880595 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.132460625113254 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.15306623337341 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.230689336870242 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.237912988468196 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.257705534852647 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.28089748594286 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.316964277043525 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.34529142642137 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.347138511126374 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.366144179154432 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.41063771977423 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.42095108062321 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.428787721161285 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.433232994779488 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.436497049200696 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.0462233812289696 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.46727349795239 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.58290477059886 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.592440999997535 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.643763412540636 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.685976239867898 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.783827986390577 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.797698289583394 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.849229693192697 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.866122964233398 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.9358294464096 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.9813031655695 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.100956798224175 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.01037068331088 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.103137719213663 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.1080255314096945 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.1088053010209933 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.120963926455374 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.1138429770508793 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.141578082196546 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.195735959965603 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.252541716004146 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.30033538434266 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.314820176921884 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.1362299999739633 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.400636673776447 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.421969691447117 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.446325624712912 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.474495869868775 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.486897974494923 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.643054050247116 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.67610610192409 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.682576155789278 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.73180235822865 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.779540054196048 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.78479653131285 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.80466865708584 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.846664571889534 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.868873659327065 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.941242692810974 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.98231750834742 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.999434265996797 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.04398176352356 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.053493250290913 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.05357043109592 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.183523371646103 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.203623601756178 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.22509817532756 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.256605819017565 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.25755364879049 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.335856266361432 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.35928283751801 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.39696477273236 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.410126838897938 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.444660249839444 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.462133966616477 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.496879876708746 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.530581673386536 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.546742157702866 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.618357351870273 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.633781141535053 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.64808516262613 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.654407272570978 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.663648749066965 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.70614999666421 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.710060511686464 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.76554596752493 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.796746780704822 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.83414001591713 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.896566531614383 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.902793606073928 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.915186350376842 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.950266836099956 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.004765847029233 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.022436366582056 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.026963066827904 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.054091043949043 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.087044862982992 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.130876671926075 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.146405986672065 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.156276277946432 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.19279404019241 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.220774574749953 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.289438714006394 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.303794679507874 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.34183115277601 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.345980752623902 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.3351947569814087 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.377738411886668 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.38791325236862 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.3428393048778133 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.430555192616936 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.349576115060586 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.512383008497224 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.538571820888052 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.578381176295466 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.622304266427776 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.639472320984083 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.640711791063083 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.655684501969574 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.66632938032174 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.672080158308148 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.687200719370054 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.70661113160979 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.709661207685187 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.7109218485503 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.754407860599926 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.826327649760586 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.831365526853546 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.85570205026137 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.85820257611107 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.87313680006868 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.91598122098806 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.9199880886719 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.4027198346834524 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.049504087516738 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.0632559575358 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.081557001157734 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.143738498673088 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.170884657084898 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.202518963743373 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.2028436262012 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.236849830919653 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.239972003595398 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.244048427013837 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.27074236880678 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.28417553559757 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.310269008241335 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.341526516133655 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.34795061303518 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.34909106123348 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.349091522422256 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.351275170748295 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.361992958200872 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.377679215578382 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.433421748590533 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.446095244727317 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.46451107837531 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.48806509266548 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.51458044920078 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.520968672343074 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.457935691169368 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.627595880957003 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.463054422693517 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.63558787625901 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.643793417096276 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.709789299363337 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.731532581762366 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.890749150666295 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.92802481323382 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.4989016867358345 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.0717032259342 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.076271163062813 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.165681207987205 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.17581047254494 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.21381892369874 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.256345357768154 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.30080083387874 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.308661733435514 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.38713011365006 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.405634704949435 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.4442891117304 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.461173234779295 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.478679501743542 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.485485138682833 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.550836640966907 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.566927243479086 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.671265685720783 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.759531029972322 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.827724092049877 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.85480940710218 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.879255330370853 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.5918682327817493 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.951770322832914 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.952326591289093 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.972172659780384 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.98196601446719 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.022614148129335 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.135273393193728 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.136669911050348 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.156874089308843 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.170460143660335 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.24049040881107 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.25049904030672 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.258894620941888 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.626317966500295 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.279991395990308 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.306715141183318 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.329596276061167 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.34690476653762 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.348150165592372 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.353444776261867 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.470989963601866 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.50049207641929 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.54507025971226 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.570369969559565 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.580400365971755 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.583524113945757 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.60033647137263 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.606141020952094 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.626480335096332 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.637601025509966 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.646633633524857 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.717775744081877 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.769017841317066 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.840724954649602 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.6880649095738534 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.883673440902726 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.909952674246966 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.990530748891544 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.036161044515424 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.11250063263728 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.116356578213143 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.120177432927363 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.167879857620008 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.19581339157085 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.721851367502822 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.224354658523552 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.238649869066677 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.72848383481103 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.29390565417947 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.310604641082563 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.347303638035655 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.392269410417455 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.400470080880808 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.40373288741658 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.4389042121705 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.453397574116025 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.54714199197788 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.59072872706166 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.593969885731752 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.629496499261208 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.7647930395723535 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.661093869055037 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.664382815281854 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.71603271651597 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.758643479049 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.78733147153804 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.788417276143917 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.81323140839214 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.83357241769646 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.876047529580703 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.890465736743124 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.980610526339362 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.999250175422446 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.104523721930576 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.165890223120456 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.20658777462907 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.21941520234084 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.272793243594307 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.362981775267656 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.390785851272852 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.426359169930436 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.451190566945854 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.503744437969345 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.55981892613464 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.62128188144422 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.665916467626303 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.869287167894015 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.713527673542586 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.72462084464125 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.738087287658715 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.76371495351941 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.776554188422026 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.790307061888498 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.833541689875616 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.83549516867052 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.8879647180261543 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.894899456109727 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.8904361805983427 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.912823889055133 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.93658526966017 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.94337630801482 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.950045924937555 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.954261712064323 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.984474581045873 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.03821561595818 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.038645219195814 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.135233546714474 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.170461658138436 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.207868748970654 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.300406784833612 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.315907166981845 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.3842858334461 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.9393994764544686 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.39653005159056 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.397664758667304 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.464122915285955 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.46497937306991 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.537442918333895 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.67908923884484 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.710001334623854 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.73592146887414 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.76689055511912 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.798131484062253 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.80347395366563 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.9808371608897204 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.98614246650682 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.930355015527127 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.937662082216107 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.955102278733932 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.96618056793092 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.021314616020206 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.035985060590903 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.037840637514208 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.043505808131755 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.111754110162863 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.138653428413974 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.150928427392913 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.161841591169164 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.184660753465778 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.244760707990935 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.26977937016717 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.271358861854964 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.280485924114743 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.293592920128958 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.32136975917578 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.40902297239964 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.40955162407097 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.457526678970083 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.462276461386395 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.490758733550138 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.515711168801758 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.66359444783376 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.680393887051153 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.713948506618635 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.76497208498911 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.831575518074075 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.891218094100978 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.91134389894539 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.93256587778714 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.94179367094823 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.03230056156498 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.111190135048645 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.118140899163848 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.132891140784082 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.137887631946143 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.183828799241383 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.211718831785547 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.242647646149805 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.30691927804679 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.37773134418231 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.139214386408341 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.48555085800821 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.4986495169087 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.509544452926136 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.537205321367438 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.54320224038048 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.57874091051302 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.596181653791916 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.604179976021513 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.686346142303677 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.72198691915895 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.862975078023155 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.97662947386881 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.05081131994547 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.08875105337799 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.096991280124556 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.18586256310169 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.19724787882828 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.202154387548504 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.20910109862689 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.2263034330267 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.27456230170036 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.29765582506836 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.335379977691176 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.340664410194194 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.235872151486646 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.35951677973097 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.37761600074336 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.2489621270346305 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.48971892009777 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.51276543358034 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.538654594640334 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.62635251874673 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.72491410535898 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.764978766896164 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.76578675961997 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.80196173371388 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.280257545642911 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.90982623665779 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.916563639327336 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.925285472691485 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.955404387357305 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.95700210560504 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.966792228204355 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.96726605552911 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.98130788966904 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.3038136446320863 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.03873536436768 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.09947952634738 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.12635775170207 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.13295813087083 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.175201448602934 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.23362180808165 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.24652442858127 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.381162020343425 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.3926543103849 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.41730656413833 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.472091776533716 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.3498876974042133 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.51937752902427 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.553071054956845 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.57472184988572 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.61607536692273 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.65641265889312 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.66268182076222 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.68019714661568 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.72298898529233 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.72622869826469 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.795339626756046 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.81221451976273 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.81973807995648 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.82656469246375 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.82898493606609 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.388531888122941 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.887154196113386 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.93062445279611 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.93721545149218 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.3950464093083497 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.96793492809158 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.975479643303345 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.997995650469775 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.40525910522949 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.133696187630804 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.15316294462943 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.192428966264245 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.22207171539684 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.240719808283046 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.25707364401731 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.37964318826296 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.403693611099655 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.4141651318226 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.47768329693392 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.483574230595295 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.544579865877935 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.56406532798076 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.5996139953354 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.61606201099974 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.640652014301864 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.64883891195254 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.695836404760755 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.70477727727288 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.715707178176686 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.72707343374866 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.77558914289749 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.4786741133783465 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.80242447166131 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.804576890110866 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.81726081649097 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.976455148766746 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.5009224200911717 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.5010655129508024 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.02034815716293 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.04610097876326 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.092879894753 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.13873428580936 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.16151288832373 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.17414665160463 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.1957725581625 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.19938056320768 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.20193546720891 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.21099505247159 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.22350338536158 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.328860007746016 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.373387914823255 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.47656700111989 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.49144171131131 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.50361869908494 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.5510292157758983 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.52328422114492 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.62220175443704 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.63245510296808 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.642642675493775 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.648524148938776 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.70594228701751 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.76954599713224 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.7904117417104 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.81974809925012 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.84940801972071 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.93435598414685 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.977988295876045 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.014543711139325 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.062141578812245 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.6113614359772868 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.15072581428072 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.26525153493023 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.31686573900777 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.3213479794394 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.360900318052344 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.409138126612596 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.44796013275264 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.50230409106896 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.52603454303931 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.57060753472696 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.57593725726582 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.60378674221931 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.695235674364945 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.70986051439134 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.760311969930726 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.67808726234 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.82113921731727 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.826349047510234 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.84503259374159 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.684755589105876 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.861949775441595 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.6868562211699754 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.90534490455877 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.94401079075518 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.958895415846385 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.96246255231019 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.05315849826065 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.081753211702974 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.09995098956027 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.11158222695159 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.141926332811906 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.22060812147801 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.22863666801497 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.265848293949546 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.29324112154835 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.35669574485523 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.411291910260715 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.43979732421623 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.45074630769625 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.487759788795614 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.48942120026637 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.56387390192406 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.583274705450776 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.59226615245757 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.6419113139161 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.743090948142545 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.76135026259298 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.77772102865201 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.781903769762934 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.782970290804755 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.82304134497338 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.83182932109952 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.940795755039794 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.036054890902406 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.06747034977034 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.126702620712315 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.12783897815082 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.815764158512522 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.8170318022368974 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.227706958990446 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.243822002793415 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.831847528857139 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.361216540354825 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.42814350789756 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.849027236689224 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.55154198952191 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.5538503708897 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.55974261156783 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.57595859746499 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.58789429473528 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.8651237489835637 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.8673025335173463 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.731168787291594 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.77478301633512 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.8883697286651966 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.91829774792788 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.978286202504094 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.898013537788515 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.057687501253604 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.057844892354595 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.106136579691 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.10864639056071 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.919746902117467 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.22298090710355 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.2690910719405 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.27510683517437 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.29341754415439 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.29523801809969 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.9318063981133946 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.34396483243321 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.9388802362868063 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.41224516964279 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.941539651526284 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.41561904561224 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.454191784545586 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.45682045049295 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.469137645293074 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.948338376024793 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.486259046113425 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.521902973006576 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.9534121563286675 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.54114056563567 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.57258572471305 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.58175983478511 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.9627994156893322 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.66176676348887 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.69436113019149 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.70342719258662 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.75720057989014 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.758250247022445 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.76144675034763 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.79195881780937 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.80203093722912 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.83156199048861 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.864473515484434 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.91431663847125 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.93367734972375 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.03011126512166 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.039913325263534 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.06047164506863 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.08661510554967 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.10418559488536 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.11133164357701 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.12503021690801 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.179613004938616 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.19352823215432 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.19607640183682 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.024901661495875 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.030917952470787 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.42139164097544 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.463758107649284 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.467780638269545 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.48081473619796 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.48214072597669 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.4958389306781 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.60518950364849 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.684901885751025 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark36(0,0,40.7127681235998 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.74840794241214 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.075622863015013 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.766605641145894 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.81548730945597 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.82259991974513 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.824633618926256 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.82770042418189 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.8827046551828 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.935084806549284 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.952708983881635 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.96042228551915 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.9898386134568 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.033890637973734 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.096061870719616 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.11111856378451 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.13065575278709 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.19646030494184 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.21646451263772 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.2612232382886 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.27401926731664 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.27808384658949 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.315425803690765 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.33653828323498 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.3386348966976 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.38126475068225 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.400766058735236 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.461142360240146 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.146334592989007 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.50488311129181 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.509425811268216 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.513747739138715 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.518889791960525 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.52893702230707 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.570086284374156 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.574162922245364 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.59091889664583 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.607459636091846 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.63204052904308 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.63763502315172 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.657306253053925 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.172254080112651 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.724956852073845 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.75292627262592 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.768933928185504 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.77445905033777 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.78892502493361 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.88455968377119 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.977508910107694 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.200804937243348 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.01882782228743 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.044662224964505 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.04649200997059 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.223056663378671 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.312308428401415 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.344888833736526 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.42833003450595 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.45230565418068 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.55664481600394 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.63690200868968 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.67341081266836 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.82575040710495 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.895109582627036 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.900248689549755 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.90439758260416 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.93003307203491 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.941038987009804 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.989057625913205 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.002909532763354 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.0139774384106 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.02592385410657 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.067395679825424 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.07432362246048 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.21851974449882 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.327297864440212 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.40788162123373 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.51494150331674 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.532624376782806 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.5593714478268 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.69305531827345 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.693986179979035 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.70380250736148 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.71056866468521 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.7233915819587 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.72585711012036 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.79224177940273 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.842965450762186 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.89403856793124 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.8992478014961 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.3916077844760935 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.94065667825811 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.94290386465396 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.95553235478688 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.95865543708699 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.02738428133486 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.04456570804205 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.266926554680055 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.29119093100904 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.29765392893026 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.30882984613758 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.435213601938969 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.39686794320756 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.44083514090706 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.462056574833355 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.464260905425235 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.49102533791185 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.542766228286254 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.59238461880348 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.60620609893275 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.61463548967335 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.67953200498902 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.70241516167259 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.72013413155307 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.72392568177177 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.74818081771383 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.91137830879541 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.91467845312842 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.92826050935712 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.9290463335712 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.054945161316425 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.11482942373679 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.1286892841791 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.14031589018002 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.220529794532524 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.252287424472314 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.32146280070943 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.36207691948404 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.383978194992224 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.40611647874664 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.41279183007219 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.465320854537694 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.46667376453786 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.4746085570938 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.551369742903844 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.52822143861217 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.563698639478936 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.61192469306301 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.652579871040814 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.75044726412381 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.892713948000385 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.91323425357117 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.972183840262645 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.0501532206973 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.09069275401991 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.616159588706694 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.18199545250277 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.201657752629366 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.22555195967675 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.230060413812105 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.32237552949685 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.638574099886242 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.38749180383035 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.41266136936826 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.453474826593144 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.45353024943284 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.56904303195706 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.578195010845924 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.666924533525346 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.67070419302699 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.74614438281193 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.77498068369745 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.788353970607986 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.80685781828602 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.815518232501674 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.82567971826388 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.910084258236886 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.92514062411719 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.937577547870355 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.042655386125844 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.11349236508564 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.19010635112581 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.19123458176504 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.264677615424475 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.29679481075586 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.31414188472562 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.34474055564488 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.431731142405795 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.48170164424419 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.514939759788845 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.751791091518882 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.53281021529041 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.55430232291342 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.77079932939876 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.781290280382805 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.78314442566567 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.79432062690545 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.79724909617682 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.8022694765029 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.80573159419048 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.81195944586021 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.8487412994697 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.85767496600464 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.906413876907436 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.91446622720588 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.792584221884155 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.93500784679032 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.9385717971601 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.999126278573875 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.8005367614193375 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.0143698129593 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.01587057983778 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.038979209789545 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.804449130726823 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.806655051926299 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.11213894354231 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.12496585752895 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.17779224196397 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.21090344960537 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.2636902056361 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.2850000218896 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.34613690875918 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.34771627366281 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.3499530103068 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.3816843169756 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.394871778883505 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.840368896183662 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.44134855893394 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.498597600634284 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.51764612048759 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.58353329056582 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.63959419849155 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.731558189334415 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.759459176142926 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.879541813723435 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.805927452141226 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.81717675146848 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.857246963639824 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.85955916424314 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.8836610621916 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.91778136117453 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.941653628189606 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.05630797437415 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.06185806634051 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.08532393341913 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.09385185928681 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.909785584564872 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.910874471352258 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.15955766165212 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.20628661258697 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.21670183042109 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.25070182200633 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.25558379648132 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.28621689637458 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark36(0,0,4.930380657631324E-32 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.34269584847335 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.34437125611648 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.42728423079945 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.49600296346157 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.61318868354327 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.62602906957883 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.63464058819695 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.74156682233075 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.75286427078753 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.77492945184607 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.821247694159766 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.82526205038968 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.83055457174568 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.88627113878741 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.905977333974725 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.91329167708953 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.948498472825854 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.959618303363754 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.0152671575647 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.13257603643542 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.16628974392234 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.185984133973264 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.29572329313212 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.325902640655976 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.38289493167834 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.40450537832055 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.042708976025679 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.42810142408012 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.4447361743688 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.49592823219382 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.51881595170358 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.52110407199726 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.58280354361953 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.58526670675691 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.58728974132174 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.59179221798604 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.59973355245246 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.60300942631195 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.71033339512576 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.72450136019913 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.738448584040555 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.776014864007315 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.79486592007094 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.0835619893632185 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.838175515364185 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.84146326927659 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.90113991253871 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.909046873484854 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.925983180862275 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.96989454274075 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.01168303925221 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.10984483554599 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.123902197917474 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.12714185232399 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.1133034945456615 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.161087944616376 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.1801582705278 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.22302240049932 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.22819082851133 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.22857580263429 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.24490930548935 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.127112780794036 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.284726729755235 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.32158218336591 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.336242711605486 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.34700360147883 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.35160545349628 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.3543634513369 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.46640154230744 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.47455654269659 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.51159917450578 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.52533733690645 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.55520876568778 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.57898356900865 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.584388169275954 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.59036698467876 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.62296523257939 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.62739959623901 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.63120741393614 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.648482425095985 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.70159213266929 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.70342347992691 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.73454191069844 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.760365357089256 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.79302451922945 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.79553073758687 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.8006359704863 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.81022153610637 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.81470118201745 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.820815038202014 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.8515736329429 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.86509128736871 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.88276466307089 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.91415415746239 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.92875242385622 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.193968719999347 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.03959384211731 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.06721745920415 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.07290968163323 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.07799807633009 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.08181237522504 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.11176208556611 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.11468149709329 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.163308159189235 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.20460321626661 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.2390163396675 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.31286829257762 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.31319170709876 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.31442728705833 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.239340078974891 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.43058116683481 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.455714447175254 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.48008162636808 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.49430501031447 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.501836441099826 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.58340300834246 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.628321698354256 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.2665816824655 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.73721087803882 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.74413254175816 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.771474098626236 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.277391896508448 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.9496493244777 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.964447743754796 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.99025270271536 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.04108683109736 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.07548780866005 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.13986579464991 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.154505847401 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.20375181265171 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.32924650645181 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.30262663002014 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.330293469997187 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.33810309652567 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.352080836890515 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.373311242761986 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.39045586977866 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.41925738570295 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.43093289890162 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.43331042097876 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.49131932682809 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.50780046084154 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.563035923215494 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.56469407600779 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.5731132119325 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.583183447191864 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.656764235310604 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.6607365578909 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.67487696282747 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.6951516190086 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.76765985669634 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.78035547075335 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.79246796294057 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.79690718919694 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.382616944616302 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.84359502492424 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.886969142745 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.89039415068364 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.390297004819459 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.91544856596764 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.92593255557245 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.96790628992023 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.97172459335591 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.02962880143258 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.0368351815256 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.055510747765226 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.06149661265833 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.121366310930185 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.4140180982241475 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.15695993992655 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.23194559215803 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.423407825871124 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.339331757142936 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.37156743309757 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.39696001421155 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.40810479370053 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.41573975826191 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.43258994104356 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.48329203089857 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.49349548445763 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.523368805192085 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.523420939818415 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.57305836069026 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.59830674268107 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.606801101841555 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.704822645987306 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.79134725702808 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.83043579143283 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.83100775090668 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.86041898352896 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.86720507668434 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.88386432164549 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.490555964552328 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.92278411182285 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.924539332839984 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.92656658913606 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.493224938266067 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.93867984379184 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.502768717971264 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.03681750531688 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.052325283566404 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.11807611607236 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.13090193166026 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.24370383703119 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.25796337902862 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.28936211562381 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.32253054583263 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.37370117430098 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.480597842754406 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.54852245819923 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.51403059487461 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.526655766819474 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.5313617264227 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.59220443233117 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.6437262350862 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.68113787160773 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.70233304065768 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.7257060472359 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.739680517705615 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.80996051796483 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.81896018799286 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.831024195861765 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.88597037838918 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.93167513524353 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.936274513918164 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.951934303893424 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.96083064095896 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.5969460895298795 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.02764133554694 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.12719835275677 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.135570409297195 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.16174738393158 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.20302998133826 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.23585860690461 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.303747191779905 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.31800814029309 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.636722094669409 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.42055399994392 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.430862519563085 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.45870407769353 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.460858778769854 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.48504487203787 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.49376613064181 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.50338275780402 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.527439517394626 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.532436364164184 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.537016376261604 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.54702913558194 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.54865588452993 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.5672537572359 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.61228233954909 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.63271271978194 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.63716088549475 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.644267890556655 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.664870348223829 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.649249180556225 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.650651380903994 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.66854174623901 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.713572603221074 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.71996228083482 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.83013083036099 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.85238675619944 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.88612979308558 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.88635934938995 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.90370333048451 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.90417385621649 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.92909746215027 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.94681765261846 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.99797325417239 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.051808247316906 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.06021612076948 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.10761412842602 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.12137786625713 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.14991553050432 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.15299610514337 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.16751249874763 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.204572549752264 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.72508499410489 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.27856350570934 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.327282583396254 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.33560340415325 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.37770787470211 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.388835036902705 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.38928944289838 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.48828433625379 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.49748569521296 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.753164232453116 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.535626839006596 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.57318764577442 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.59935879944664 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.68472753654707 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.777537701164249 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.778652871199014 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.793539887140064 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.819250513539686 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.8497978657684 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.785135580761548 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.787724438154655 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.889513084410304 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.923243963205564 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.99087979453592 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.00347027018389 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.03106695469176 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.13812198165178 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.164646589139714 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.18120438042571 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.186100661052855 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.18710921065564 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.23857710022384 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.29661342672124 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.31004225221057 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.3349856635142 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.34049597341935 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.40932015410878 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.42644634108005 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.42979619716924 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.478706906725584 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.52113713850582 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.852764618709031 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.53480622270184 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.64777310410665 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.66432985169643 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.711588369623804 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.73611983775731 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.76400437622502 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.78190302769901 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.885482392711651 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.888769030437643 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.9087640318042 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.92583432943071 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.010429569702374 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.029555229719975 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.065405379173505 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.109239173433224 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.916620078494077 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.18227615302203 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.189103293089175 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.919677526080676 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.20274750853884 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.24082128460337 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.270484459259045 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.31014343806371 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.361479877443514 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.364574917493876 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.36784102896968 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.40059264529758 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.448351141420176 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.46788276817971 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.55070131560909 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.55590343388258 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.57686958809079 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.61874735963575 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.9713354546841515 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.75283294014122 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.981367843749254 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.8322186959688 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.85008373222165 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.87250527550747 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.87563392475401 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.911308692921224 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.912708562410444 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.918363938133965 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.979901426800495 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.021352325458466 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.0588252994632 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.0701822609403 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.107845547203674 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.18314204004647 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.24333038872658 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.29875661785047 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.336330298514355 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.036447946282578 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.3648478623837 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.037625053828961 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.480617551834 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.6071607517171 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.62668299407004 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.063934165227366 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.686590072220945 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.782133845611995 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.799214123420285 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.89540735822403 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.931160875733134 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.96351093765789 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.98411426165489 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.001015053314525 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.03514365930243 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.04924463226582 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.107988624571476 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.10927839804432 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.15983324582071 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.232181910328976 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.24227569062888 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.25054841143527 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.275697218162776 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.130083254544559 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.31566964275854 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.399257929208126 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.40475306960631 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.43222096004464 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.450716489054 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.4867535722494 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.48911483033967 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.529176187115354 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.54997231475714 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.55158286223632 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.57362200351757 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.58358219436726 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.603856879571374 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.60414313969109 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.66715412482671 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.68927426191762 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.74612624659601 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.74657898304772 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.77411912485231 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.82909873332032 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.868925012681466 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.87902627720761 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.8852950329718 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.94259207076149 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.1943986650198894 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.194574786254094 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.05176780877066 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.070905093873854 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.208022317221349 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.11372909418999 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.139130798498066 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.152086481490244 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.17996220533064 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.18754302373555 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.24203977828875 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.24734162417987 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.323343997983535 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.24475721623125 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.45322989874451 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.48195832842991 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.496397186164685 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.51848702385543 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.54287824016676 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.55668324169228 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.66030730913668 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.66533212534673 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.71403169668024 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.76588891503438 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.78268512867684 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.798288917638544 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.80748377148928 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.8116141918531 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.841223956270184 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.8707427927875 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.12410796832477 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.13133985712695 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.14595568681413 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.15089273598817 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.152845110933264 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.15641276231656 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.17148439049507 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.17883263496324 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.19270850981009 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.22806102066978 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.27420778294059 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.305926162737514 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.38088790602012 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.39423932324137 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.41655540957167 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.41698335245298 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.349887196516164 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.51034661477877 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.351437101668182 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.57199910815743 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.58586968679256 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.6149104340495 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.64509572585397 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.365227724594973 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.65306421602928 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.6872247247489 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.6995690643466 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.739458059052055 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.801682219199016 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.81510481682984 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.384612670458111 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.85342423459572 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.87221436502315 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.91276602557636 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.92085995353389 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.94929936587652 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.97739846401949 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.01145300130457 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.14836575322019 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.16028483598267 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.16195431637415 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.16782833232928 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.20938359773635 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.21220800123308 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.21331144776866 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.431320143289952 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.31364721806831 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.3192098014224 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.33569073869789 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.37113878075863 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.37553008800157 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.38526599916284 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.43304320784515 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.446650804071112 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.50871528582329 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.51904053237907 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.452653001271955 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.59773828535523 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.59864259355801 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.64473268354665 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.64945158838553 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.65462223259621 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.67387961819057 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.69269012013352 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.69875125124203 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.73918145465989 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.8366947518088 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.84100129668985 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.85490810140598 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.91158888529617 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.50679858419268 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.09717639066437 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.10852745098865 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.18445102565093 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.20741200209596 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.21907115246808 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.2343428488865 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.26827959676966 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.37971981693009 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.44759704010386 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.4476744202357 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.53229546072657 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.56849683280177 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.59264801393246 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.6467579967844 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.72772830012019 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.76567215784515 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.577485704774659 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.80416579304543 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.81022512064492 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.84676742343567 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.87715453988898 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.93532884084372 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.10275934235143 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.612861167479139 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.15414302849362 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.620865669145942 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.24444767106527 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.26672477005272 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.28509827351465 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.29958448534074 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.32528538783578 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.6331746757677195 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.38909889629996 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.40947695674744 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.43094189516287 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.46601027903192 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.52581986172038 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.54885708200204 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.5652549990399 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.57535264154436 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.67643646128465 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.72139917234384 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.74928910699656 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.77851958891813 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.7997761023307 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.82312265630787 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.84514882013059 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.87024315111394 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.01400684035816 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.09443055779795 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.10839259122852 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.13044088732059 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.14498526865584 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.19471570178435 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.26509784183344 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.730095333780213 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.35421515346698 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.35534455972167 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.44032841854062 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.4468050863083 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.745495303409953 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.46584083109116 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.49717664105725 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.5030910724305 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.51552810945655 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.754403856670805 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.55319349635913 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.60860040324954 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.61025874259306 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.67136775646023 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.68052718798674 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.68623239872875 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.68746187500201 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.7091991924849 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.71097358106192 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.72326577384521 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.7461279908826 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.77584325477196 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.92036417658576 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.7987426530118995 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.804333045384851 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.07944679191579 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.10276707559358 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.14182516003144 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.18569927576658 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.20662216840006 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.821449489284873 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.23638280361726 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.24670980418955 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.32772297223322 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.37982270385332 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.3865322536194 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.44794875940619 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.50870547397044 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.52575323164172 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.52609928037367 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.54664706307543 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.56383293514395 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.66169411070177 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.70660048344061 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.74504930689262 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.75476756581216 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.76242032189894 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.79153648483607 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.882357170998077 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.83371908115538 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.87299177887994 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.89946514220463 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.93438921242691 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.00071027322845 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.00266457385456 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.00537748952813 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.03777942377516 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.10729368238613 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.16110347408066 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.24742072849541 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.25989373641028 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.26534509089272 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.3128422340724 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.33511619850911 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.3410677248741 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.42209994422848 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.44832345125857 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.46743072388679 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.51189837464739 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.5993795250772 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.65748990120912 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.71745104050207 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.75004525376534 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.85632395419692 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.87048375978105 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.87821554325308 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.90243184017737 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.93501331759855 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.96822483002283 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.97914501705387 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.01946210945884 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.05051208935613 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.05780814401767 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.05815807444746 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.0833622532282 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.014239418314787 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.18112828596074 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.19043722224107 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.021086956781957 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.022253241832971 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.23240626450635 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.047862836172939 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.49338863267076 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.4971104068116 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.53258287378621 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.56238252043534 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.5865129338574 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.59880627910505 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.61836076373436 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.065527550292131 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.67882190932646 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.6885105838422 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.71263689972338 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.77805958812031 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.83265257942921 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.084938529144665 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.89672429592902 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.94903840227417 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.97624714325843 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.97901649263241 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.01790544850476 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.04606062011247 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.0958277322558 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.111494021105841 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.17712348563623 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.27925939580275 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.28342269106234 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.3236100408728 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.34792772107188 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.136460559349473 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.3975290049817 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.44657671177788 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.44700837944661 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.46518658902643 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.50126874459437 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.59159268641693 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.60749049440545 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.61134263141635 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.69772659713847 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.172488195184187 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.75071688949706 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.75680881472677 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.77412352390868 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.78155640088187 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.195498606901893 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.197326150147461 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.98589775946145 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.98741868782918 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.04569669526168 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.10632136800332 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.24491891368254 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.33198361693789 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.40122908406323 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.40251543718234 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.42779995914447 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.49176712322233 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.56293783198649 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.63520112298269 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.66301508671944 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.73120657688739 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.276742969649902 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.79106811235204 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.7915083283771 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.8110924371972 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.83165247842946 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.83424337515055 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.86295112686221 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.98431979410702 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.9861893087861 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.00758653167281 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.01885808205162 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.0416651231691 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.07932035224184 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.10770910441839 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.13905717594858 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.16267340300202 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.22429241504828 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.23961570542448 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.323990095789853 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.25582172165016 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.27203530191773 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.32857539490713 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.33220021138496 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.33283596384852 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.36882585211642 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.44046156672212 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.44282171113093 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.48791539197144 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.48964480521627 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.355184158335987 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.6403255586394 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.66124853502463 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.70950776592429 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.72621333451733 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.7337833844302 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.73651983995752 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.75594915841661 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.38087359886643 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.82656521887242 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.8292865936919 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.88574057045633 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.94466534953297 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.95571950159345 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.06104209592057 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.09937188294992 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.13640632931885 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.419763636436997 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.2211445945721 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.22774265883388 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.27015934516234 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.2809070444129 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.2824900724738 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.29729175381688 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.32366052801444 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.45002971410288 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.47559361435322 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.447682944806914 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.50203734598146 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.451184787996141 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.5156181332373 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.51775424566969 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.454724032057385 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.55285538873596 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.5596089779079 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.5596278447443 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.60621901545909 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.66805360397284 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.467875252899219 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.69641419757414 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.72829786640425 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.73622666923762 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.75065335250275 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.75258818440724 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.78640669160961 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.81012292210842 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.82812906353568 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.82889936907642 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.90176546928765 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.91046848013754 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.93916435040629 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.98051312816538 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.98082913470478 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.98633987601124 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.99180774421137 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.99224209260184 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.00125173985977 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.00194325070308 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.02888627445445 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.11864518631579 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.17877951332301 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.5179885405457725 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.18900254069769 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.20382039646628 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.22205236848767 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.2292114338468 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.523453488268146 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.25129780212573 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.25239885216988 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.25745822132366 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.32055969064358 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.33398161917128 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.38389688256753 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.41022908087064 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.51650525413025 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.5754222309183 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.579202090024 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.5955899668749 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.5964274634833 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.59685169790697 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.61154244493974 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.564317972832654 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.6455254601667 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.730238020048 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.75094072021085 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.76549616185426 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.77977267255973 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.79113960954902 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.579213906324171 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.04381145501367 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.05533325446265 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.12912517983739 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.17605913520615 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.22284790433795 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.22733387313667 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.24147420536156 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.625036715024592 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.632160483834284 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.43601043360881 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.5335764419333 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.58469535796975 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.60812178591894 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.61991266100266 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.67063538132652 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.672548197700024 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.76381983883292 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.76534145774143 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.79340169673844 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.82877577368501 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.684410454431486 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.85827415052225 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.687952886199213 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.92740057848269 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.93836113579586 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.03182138496452 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.03268514973117 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.06791257088932 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.1199364359712 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.715892114681182 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.16015907333116 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.18024435087523 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.19317152546921 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.20492115494318 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.21622634421293 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.22403530870491 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.29770029850613 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.41119774865892 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.46028204164723 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.47522783899407 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.49085636519939 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.49497040272999 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.57807411036018 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.58169067184299 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.58560419641066 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.64571014848613 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.71971450176436 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.78174632310599 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.79535448099664 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.81451052220581 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.88429876757057 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.88460787256307 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.89250774217248 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.93556888955375 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.94429867981623 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.95467236859635 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.96128893526814 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.98323915644552 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.09011263358005 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.14493696741366 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.14695846213984 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.1934074696548 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.29212304337598 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.3098715163398 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.3101857444812 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.34059335733458 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.36162893752845 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.36258694369131 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.38038342568865 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.41812087334922 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.42493659639369 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.47150712430562 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.47348112699164 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.8477269795082805 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.51983923657394 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.55428385517669 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.58261089937697 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.59406283055996 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.63523742090719 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.63537906881757 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.64564079563586 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.67546779472463 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.72116053245696 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.75686923636422 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.84157135604431 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.90858540511073 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.93026353390773 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.93749100404399 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.9486102196716 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.96746390260137 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.97685181677701 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.99110330160583 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.04304532248855 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.08129242424081 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.908489479613024 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.909990372767609 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.10496360190209 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.12322091727597 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.16445780271599 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.18699041318612 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.18805415565802 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.18926757600038 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.24451897390072 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.33568421439512 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.3749052165055 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.38139140824222 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.41701409384282 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.42587755775617 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.944643143084633 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.46601845095556 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.52586293640844 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.68463813817526 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.76065166041973 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.81350607372588 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.81566211873077 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.81671404529925 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.87372083410276 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.89442022002673 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.94587898908465 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.99707472777456 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.99872037156268 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.020573648818 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.08876069005599 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.14794145238199 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.15272298062193 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.22682660799947 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.31151531751635 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.37480022057073 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.38021110809635 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.038869582162803 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.39296546311914 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.44695014334837 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.051347802596894 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.53731632164195 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.58012325999519 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.61796325969547 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.63757143843529 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.69422881965005 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.69580944244396 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.75511964105202 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.79578392668363 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.079911828402714 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.82499931473103 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.08379051926238 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.84511366821727 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.89810778349397 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.91188505381213 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.91900218757601 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.92879168694031 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.9360952061204 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.97283665645205 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.98277024264446 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.0956465267914 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.13117584284973 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.15705056213784 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.19308673100511 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.12109089948234 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.28983719862842 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.3272958393173 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.33089606364777 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.3597332161242 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.36209107870673 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.36798674872185 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.37696711273804 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.3886281911988 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.41690894011009 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.42989067214354 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.43883334529673 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.45111944434726 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.45932111764509 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.52431513957718 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.53860275794761 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.64559697009601 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.73474700441756 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.79389222819711 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.85395262030745 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.85617883936744 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.96000452585908 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.00752832969738 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.03665800878261 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.0907706721224 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.10622468582953 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.14798227724438 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.217038972241326 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.18974996729051 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.25854539379858 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.226719226148347 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.2924219055131 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.30575376238289 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.38376485530338 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.39308930798643 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.44697328626056 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.244769585018759 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.248691371243993 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.52530537723261 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.61230308839811 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.62185466072431 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.6455082255248 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.796071314562 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.81031612349932 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.8280827467834 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.28633874769777 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.9004602861491 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.93211346958543 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.9348557363275 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.9513129187458 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.96400392347591 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.98841693688179 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.04810768314432 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.04999929191064 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.06327446748614 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark36(0,0,83.19434585959752 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.2393825326352 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.25332486141698 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.33472018535473 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.46408479377507 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.48439696632732 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.5679977619542 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.64892998267067 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.70301704662762 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.706081492443 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.78628671430434 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.81083578781379 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.82121315763416 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.3872983738664 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.91942065462132 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.92518411733451 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.937006002722 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.00051021074235 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.06035099391976 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.10741860198023 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.1815252720967 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.19386369446431 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.20008248330558 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.427071857535722 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.430046518897854 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.30231550835003 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.30287035119564 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.3355365948629 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.39566124615625 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.443679170013723 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.4372984519708 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.44091434366658 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.46378891482186 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.57882413334087 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.60856534002032 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.6217978881458 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.672148686091 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.724022162267 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.81231745941405 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.81626600584922 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.86609709933357 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.90764731593563 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.91894805024513 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.96523014433718 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.0130777988461 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.02825181568204 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.09879888965199 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.11986822501369 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.13502382622448 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.14358176656356 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.21654648707846 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.25381725446788 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.525600284978552 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.390174923769 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.43942059167198 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.4843293914545 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.50137204229524 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.51293981739761 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.5248769562293 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.5504919107357 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.5646827047075 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.57616988256306 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.60051427934692 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.64936810724733 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.65626724009572 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.79519468287737 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.584676501885852 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.95178753380175 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.99062788606354 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.00622965676759 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.03875581723682 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.10042385050767 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.13067143278738 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.1508948119406 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.17408264477693 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.25777021665147 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.31660511861772 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.39307246746226 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.639979331504705 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.43877610028889 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.45097994454767 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.55135026571375 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.56115986923949 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.5870433012304 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.60666129225089 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.63843804463394 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.6793276957601 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.70262632624642 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.73495810233291 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.77030290471038 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.83648241329146 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.684408285755012 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.84836722558906 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.88625332436975 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.92990503094984 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.93061144272056 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.96054220123702 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.98796022951677 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.0182316805236 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.01957390051314 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.02822468115 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.03829071381625 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.06098162723745 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.06759707004295 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.1077876745178 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.12370844007862 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.15808825583883 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.16726528187597 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.17784134623123 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.18118313936611 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.23493999790728 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.26524191287493 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.27665783874552 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.730518482967128 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.4042124099143 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.42872894367959 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.46986645375694 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.749284374696927 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.51236313926103 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.5749018779724 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.62514885678705 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.64319512337863 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.65452786165773 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.65987055060822 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.7233726378775 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.73388431776834 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.7820455042031 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.79548160732827 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.81923128786849 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.83192225476928 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.83826695537607 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.84103715588643 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.85429968772593 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.786103874687768 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.86802054346055 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.86941168116913 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.8753734856283 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.791701614223072 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.92569505844267 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.95095633201208 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.02680048300977 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.03265010692559 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.03720008101772 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.08787505309034 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.21918893903975 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.33012942662755 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.34832216978003 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.38825118672875 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.48866485788366 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.53894456276852 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.60530223714949 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.6197354941036 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.865868154545709 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.66926127229763 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.67095261050737 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.873083235036134 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.73604307600863 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.76210836861526 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.878957143465655 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.84072268530814 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.88779211623836 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.88861482988999 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.93943968555018 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.94690226164248 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.99679687850023 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.99880368001214 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.07145820962397 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.1052575375933 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.11041849053889 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.26070008760043 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.26691374455136 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.28205542163346 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.28813453795547 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.29023325463623 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.32941006693423 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.34887229802342 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.5058798391945 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.54466392212596 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.6571973505265 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.972670374880607 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.8389948148902 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.86307825347319 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.93250823338394 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.98073477054189 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.05532610139298 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.007780710212572 ) ;
  }

  @Test
  public void test2476() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.15605234020876 ) ;
  }

  @Test
  public void test2477() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.16113210718571 ) ;
  }

  @Test
  public void test2478() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.20481950734734 ) ;
  }

  @Test
  public void test2479() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.26136187337836 ) ;
  }

  @Test
  public void test2480() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.29230442495937 ) ;
  }

  @Test
  public void test2481() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.34676699099296 ) ;
  }

  @Test
  public void test2482() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.35303962289483 ) ;
  }

  @Test
  public void test2483() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.38992937324042 ) ;
  }

  @Test
  public void test2484() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.50341973131293 ) ;
  }

  @Test
  public void test2485() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.51091770876387 ) ;
  }

  @Test
  public void test2486() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.57944984476265 ) ;
  }

  @Test
  public void test2487() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.70132118611609 ) ;
  }

  @Test
  public void test2488() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.74201320349738 ) ;
  }

  @Test
  public void test2489() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.91862841086682 ) ;
  }

  @Test
  public void test2490() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.98119946757244 ) ;
  }

  @Test
  public void test2491() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.98465374032294 ) ;
  }

  @Test
  public void test2492() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.0295400200282 ) ;
  }

  @Test
  public void test2493() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.03355371311036 ) ;
  }

  @Test
  public void test2494() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.0600049765853 ) ;
  }

  @Test
  public void test2495() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.06059209295569 ) ;
  }

  @Test
  public void test2496() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.09109768521797 ) ;
  }

  @Test
  public void test2497() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.110460953747165 ) ;
  }

  @Test
  public void test2498() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.1089153352417 ) ;
  }

  @Test
  public void test2499() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.12018688978799 ) ;
  }

  @Test
  public void test2500() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.14056471327643 ) ;
  }

  @Test
  public void test2501() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.17488698932674 ) ;
  }

  @Test
  public void test2502() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.17509911811128 ) ;
  }

  @Test
  public void test2503() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.18571225820847 ) ;
  }

  @Test
  public void test2504() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.11910428576806 ) ;
  }

  @Test
  public void test2505() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.19939938405454 ) ;
  }

  @Test
  public void test2506() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.20672936679861 ) ;
  }

  @Test
  public void test2507() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.126308423793688 ) ;
  }

  @Test
  public void test2508() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.12717937964824 ) ;
  }

  @Test
  public void test2509() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.27802698346451 ) ;
  }

  @Test
  public void test2510() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.29422348146664 ) ;
  }

  @Test
  public void test2511() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.29705531167731 ) ;
  }

  @Test
  public void test2512() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.33958874461918 ) ;
  }

  @Test
  public void test2513() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.3463099835626 ) ;
  }

  @Test
  public void test2514() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.43445858811927 ) ;
  }

  @Test
  public void test2515() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.52213002035148 ) ;
  }

  @Test
  public void test2516() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.52576918135229 ) ;
  }

  @Test
  public void test2517() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.54376696147268 ) ;
  }

  @Test
  public void test2518() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.62525372350578 ) ;
  }

  @Test
  public void test2519() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.70927322087854 ) ;
  }

  @Test
  public void test2520() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.8550679493487 ) ;
  }

  @Test
  public void test2521() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.8605666448677 ) ;
  }

  @Test
  public void test2522() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.87444419434883 ) ;
  }

  @Test
  public void test2523() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.87589701226698 ) ;
  }

  @Test
  public void test2524() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.87604224805844 ) ;
  }

  @Test
  public void test2525() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.88483284673083 ) ;
  }

  @Test
  public void test2526() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.198223821501458 ) ;
  }

  @Test
  public void test2527() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.00386613174612 ) ;
  }

  @Test
  public void test2528() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.01747576259542 ) ;
  }

  @Test
  public void test2529() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.03291023737042 ) ;
  }

  @Test
  public void test2530() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.07133608675966 ) ;
  }

  @Test
  public void test2531() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.19043883871001 ) ;
  }

  @Test
  public void test2532() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.2869104540958 ) ;
  }

  @Test
  public void test2533() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.3123900365865 ) ;
  }

  @Test
  public void test2534() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.238434178039597 ) ;
  }

  @Test
  public void test2535() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.386950591518 ) ;
  }

  @Test
  public void test2536() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.40978496553562 ) ;
  }

  @Test
  public void test2537() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.47709033309039 ) ;
  }

  @Test
  public void test2538() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.4864394279093 ) ;
  }

  @Test
  public void test2539() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.54037583270107 ) ;
  }

  @Test
  public void test2540() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.55849247978377 ) ;
  }

  @Test
  public void test2541() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.56006186639422 ) ;
  }

  @Test
  public void test2542() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.61344326924865 ) ;
  }

  @Test
  public void test2543() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.62954994595142 ) ;
  }

  @Test
  public void test2544() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.66131181786983 ) ;
  }

  @Test
  public void test2545() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.67404361415208 ) ;
  }

  @Test
  public void test2546() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.69492422216182 ) ;
  }

  @Test
  public void test2547() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.70611954585779 ) ;
  }

  @Test
  public void test2548() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.7323733591382 ) ;
  }

  @Test
  public void test2549() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.83382947508044 ) ;
  }

  @Test
  public void test2550() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.288391058366557 ) ;
  }

  @Test
  public void test2551() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.92879964430156 ) ;
  }

  @Test
  public void test2552() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.01086463133379 ) ;
  }

  @Test
  public void test2553() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.08726108740598 ) ;
  }

  @Test
  public void test2554() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.08880105325198 ) ;
  }

  @Test
  public void test2555() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.314997859918051 ) ;
  }

  @Test
  public void test2556() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.21593277911893 ) ;
  }

  @Test
  public void test2557() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.22963586119182 ) ;
  }

  @Test
  public void test2558() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.24494911534427 ) ;
  }

  @Test
  public void test2559() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.29414919783497 ) ;
  }

  @Test
  public void test2560() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.29418761226134 ) ;
  }

  @Test
  public void test2561() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.29918627766665 ) ;
  }

  @Test
  public void test2562() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.37236136931301 ) ;
  }

  @Test
  public void test2563() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.37620582282736 ) ;
  }

  @Test
  public void test2564() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.338332011537204 ) ;
  }

  @Test
  public void test2565() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.39105497318026 ) ;
  }

  @Test
  public void test2566() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.41773702483418 ) ;
  }

  @Test
  public void test2567() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.44762856213124 ) ;
  }

  @Test
  public void test2568() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.4493610435599 ) ;
  }

  @Test
  public void test2569() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.45700678665499 ) ;
  }

  @Test
  public void test2570() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.45849144325899 ) ;
  }

  @Test
  public void test2571() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.54200105046702 ) ;
  }

  @Test
  public void test2572() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.61401700935106 ) ;
  }

  @Test
  public void test2573() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.63815498760293 ) ;
  }

  @Test
  public void test2574() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.6689692291903 ) ;
  }

  @Test
  public void test2575() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.684163157419 ) ;
  }

  @Test
  public void test2576() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.68918237264865 ) ;
  }

  @Test
  public void test2577() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.6943466835434 ) ;
  }

  @Test
  public void test2578() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.75881833492782 ) ;
  }

  @Test
  public void test2579() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.7673770993064 ) ;
  }

  @Test
  public void test2580() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.7734021028778 ) ;
  }

  @Test
  public void test2581() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.77509762477985 ) ;
  }

  @Test
  public void test2582() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.80180823410046 ) ;
  }

  @Test
  public void test2583() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.80423637942738 ) ;
  }

  @Test
  public void test2584() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.84126387538197 ) ;
  }

  @Test
  public void test2585() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.85894512895877 ) ;
  }

  @Test
  public void test2586() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.86682131872253 ) ;
  }

  @Test
  public void test2587() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.92415051434043 ) ;
  }

  @Test
  public void test2588() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.93374703054609 ) ;
  }

  @Test
  public void test2589() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.93542896595464 ) ;
  }

  @Test
  public void test2590() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.398139801777575 ) ;
  }

  @Test
  public void test2591() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.01093452343588 ) ;
  }

  @Test
  public void test2592() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.01409511802463 ) ;
  }

  @Test
  public void test2593() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.02902178098769 ) ;
  }

  @Test
  public void test2594() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.09490214955002 ) ;
  }

  @Test
  public void test2595() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.11327633014557 ) ;
  }

  @Test
  public void test2596() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.414057071670953 ) ;
  }

  @Test
  public void test2597() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.25858691732437 ) ;
  }

  @Test
  public void test2598() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.31601129546068 ) ;
  }

  @Test
  public void test2599() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.36194155818012 ) ;
  }

  @Test
  public void test2600() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.39830640637655 ) ;
  }

  @Test
  public void test2601() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.40160889162838 ) ;
  }

  @Test
  public void test2602() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.45314220931198 ) ;
  }

  @Test
  public void test2603() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.49868211193639 ) ;
  }

  @Test
  public void test2604() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.50510999532686 ) ;
  }

  @Test
  public void test2605() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.5104702572858 ) ;
  }

  @Test
  public void test2606() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.55666373566672 ) ;
  }

  @Test
  public void test2607() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.66837859237731 ) ;
  }

  @Test
  public void test2608() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.68821477756049 ) ;
  }

  @Test
  public void test2609() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.469222121027173 ) ;
  }

  @Test
  public void test2610() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.69935873112136 ) ;
  }

  @Test
  public void test2611() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.70026197103267 ) ;
  }

  @Test
  public void test2612() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.8504490551969 ) ;
  }

  @Test
  public void test2613() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.85827794250336 ) ;
  }

  @Test
  public void test2614() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.86123689914527 ) ;
  }

  @Test
  public void test2615() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.86912941880526 ) ;
  }

  @Test
  public void test2616() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.98508920768187 ) ;
  }

  @Test
  public void test2617() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.503258626284648 ) ;
  }

  @Test
  public void test2618() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.04833646447528 ) ;
  }

  @Test
  public void test2619() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.05454119150329 ) ;
  }

  @Test
  public void test2620() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.511166207386722 ) ;
  }

  @Test
  public void test2621() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.13088182577991 ) ;
  }

  @Test
  public void test2622() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.24636576852879 ) ;
  }

  @Test
  public void test2623() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.26396027563399 ) ;
  }

  @Test
  public void test2624() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.27087960144374 ) ;
  }

  @Test
  public void test2625() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.28742867085029 ) ;
  }

  @Test
  public void test2626() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.2979500037725 ) ;
  }

  @Test
  public void test2627() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.3122281120895 ) ;
  }

  @Test
  public void test2628() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.32767855080202 ) ;
  }

  @Test
  public void test2629() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.4271686935083 ) ;
  }

  @Test
  public void test2630() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.43027792416952 ) ;
  }

  @Test
  public void test2631() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.46544970733231 ) ;
  }

  @Test
  public void test2632() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.4827564323037 ) ;
  }

  @Test
  public void test2633() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.52822340450746 ) ;
  }

  @Test
  public void test2634() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.53792087222395 ) ;
  }

  @Test
  public void test2635() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.54231042281943 ) ;
  }

  @Test
  public void test2636() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.54927941331262 ) ;
  }

  @Test
  public void test2637() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.55638084910349 ) ;
  }

  @Test
  public void test2638() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.5901302948629 ) ;
  }

  @Test
  public void test2639() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.60109035935722 ) ;
  }

  @Test
  public void test2640() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.6216961288753 ) ;
  }

  @Test
  public void test2641() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.62816550518194 ) ;
  }

  @Test
  public void test2642() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.6625924562351 ) ;
  }

  @Test
  public void test2643() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.68543733523047 ) ;
  }

  @Test
  public void test2644() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.7408240721428 ) ;
  }

  @Test
  public void test2645() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.76936595000114 ) ;
  }

  @Test
  public void test2646() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.76983504541312 ) ;
  }

  @Test
  public void test2647() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.80343657092725 ) ;
  }

  @Test
  public void test2648() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.583862766124057 ) ;
  }

  @Test
  public void test2649() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.87591758896433 ) ;
  }

  @Test
  public void test2650() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.88688546976165 ) ;
  }

  @Test
  public void test2651() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.597983269431552 ) ;
  }

  @Test
  public void test2652() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.0197787977875 ) ;
  }

  @Test
  public void test2653() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.04520928628311 ) ;
  }

  @Test
  public void test2654() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.15080541239571 ) ;
  }

  @Test
  public void test2655() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.19350633448612 ) ;
  }

  @Test
  public void test2656() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.2242783362754 ) ;
  }

  @Test
  public void test2657() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.34343127659892 ) ;
  }

  @Test
  public void test2658() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.4073685961959 ) ;
  }

  @Test
  public void test2659() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.44752429722921 ) ;
  }

  @Test
  public void test2660() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.46396256720351 ) ;
  }

  @Test
  public void test2661() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.48406842054467 ) ;
  }

  @Test
  public void test2662() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.49567930052294 ) ;
  }

  @Test
  public void test2663() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.54023701614447 ) ;
  }

  @Test
  public void test2664() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.59041366790977 ) ;
  }

  @Test
  public void test2665() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.62970973496738 ) ;
  }

  @Test
  public void test2666() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.6784883899134 ) ;
  }

  @Test
  public void test2667() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.67898496183463 ) ;
  }

  @Test
  public void test2668() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.68382100316346 ) ;
  }

  @Test
  public void test2669() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.8101091798954 ) ;
  }

  @Test
  public void test2670() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.89035465366838 ) ;
  }

  @Test
  public void test2671() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.89680845420774 ) ;
  }

  @Test
  public void test2672() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.91981869343913 ) ;
  }

  @Test
  public void test2673() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.92534938184816 ) ;
  }

  @Test
  public void test2674() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.93133358704496 ) ;
  }

  @Test
  public void test2675() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.98015317581175 ) ;
  }

  @Test
  public void test2676() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.01492058359975 ) ;
  }

  @Test
  public void test2677() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.02599344530338 ) ;
  }

  @Test
  public void test2678() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.12821279659707 ) ;
  }

  @Test
  public void test2679() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.14100965797496 ) ;
  }

  @Test
  public void test2680() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.14867335066674 ) ;
  }

  @Test
  public void test2681() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.23543504215917 ) ;
  }

  @Test
  public void test2682() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.25608264163243 ) ;
  }

  @Test
  public void test2683() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.30136301524817 ) ;
  }

  @Test
  public void test2684() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.32408193491875 ) ;
  }

  @Test
  public void test2685() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.33835945944291 ) ;
  }

  @Test
  public void test2686() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.37438016524058 ) ;
  }

  @Test
  public void test2687() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.38547597438216 ) ;
  }

  @Test
  public void test2688() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.52361806600342 ) ;
  }

  @Test
  public void test2689() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.53512535848479 ) ;
  }

  @Test
  public void test2690() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.53881406217182 ) ;
  }

  @Test
  public void test2691() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.755755143448596 ) ;
  }

  @Test
  public void test2692() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.60992100874009 ) ;
  }

  @Test
  public void test2693() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.63193521453168 ) ;
  }

  @Test
  public void test2694() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.64997701125735 ) ;
  }

  @Test
  public void test2695() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.67106729657202 ) ;
  }

  @Test
  public void test2696() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.77038569318485 ) ;
  }

  @Test
  public void test2697() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.73251243122614 ) ;
  }

  @Test
  public void test2698() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.77841064484383 ) ;
  }

  @Test
  public void test2699() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.81838898454833 ) ;
  }

  @Test
  public void test2700() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.782086061119315 ) ;
  }

  @Test
  public void test2701() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.84746861827023 ) ;
  }

  @Test
  public void test2702() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.91147135257019 ) ;
  }

  @Test
  public void test2703() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.92123114073128 ) ;
  }

  @Test
  public void test2704() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.93117014400666 ) ;
  }

  @Test
  public void test2705() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.9551420801639 ) ;
  }

  @Test
  public void test2706() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.9626741534944 ) ;
  }

  @Test
  public void test2707() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.04451247082062 ) ;
  }

  @Test
  public void test2708() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.0679532974504 ) ;
  }

  @Test
  public void test2709() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.11764422161944 ) ;
  }

  @Test
  public void test2710() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.14413486787879 ) ;
  }

  @Test
  public void test2711() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.15544781041694 ) ;
  }

  @Test
  public void test2712() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.17785378596106 ) ;
  }

  @Test
  public void test2713() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.21730258495533 ) ;
  }

  @Test
  public void test2714() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.823766320696762 ) ;
  }

  @Test
  public void test2715() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.25998846223118 ) ;
  }

  @Test
  public void test2716() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.827321529069934 ) ;
  }

  @Test
  public void test2717() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.29077074547818 ) ;
  }

  @Test
  public void test2718() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.31257075370897 ) ;
  }

  @Test
  public void test2719() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.33607188933145 ) ;
  }

  @Test
  public void test2720() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.4301887176908 ) ;
  }

  @Test
  public void test2721() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.44242472762177 ) ;
  }

  @Test
  public void test2722() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.47032831702653 ) ;
  }

  @Test
  public void test2723() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.50328543270874 ) ;
  }

  @Test
  public void test2724() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.852451974182912 ) ;
  }

  @Test
  public void test2725() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.5386040825805 ) ;
  }

  @Test
  public void test2726() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.857065344231984 ) ;
  }

  @Test
  public void test2727() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.5728073177357 ) ;
  }

  @Test
  public void test2728() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.60900340546412 ) ;
  }

  @Test
  public void test2729() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.86403786551729 ) ;
  }

  @Test
  public void test2730() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.76497187959339 ) ;
  }

  @Test
  public void test2731() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.76944573011937 ) ;
  }

  @Test
  public void test2732() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.83907264950342 ) ;
  }

  @Test
  public void test2733() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.91680937547412 ) ;
  }

  @Test
  public void test2734() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.92317064525085 ) ;
  }

  @Test
  public void test2735() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.95887414166238 ) ;
  }

  @Test
  public void test2736() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.99412638225773 ) ;
  }

  @Test
  public void test2737() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.13439244976519 ) ;
  }

  @Test
  public void test2738() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.13707319188651 ) ;
  }

  @Test
  public void test2739() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.914355408746673 ) ;
  }

  @Test
  public void test2740() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.914803377043697 ) ;
  }

  @Test
  public void test2741() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.91566885648227 ) ;
  }

  @Test
  public void test2742() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.17393193960639 ) ;
  }

  @Test
  public void test2743() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.18104893675672 ) ;
  }

  @Test
  public void test2744() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.18710791655624 ) ;
  }

  @Test
  public void test2745() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.22367250328293 ) ;
  }

  @Test
  public void test2746() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.32438079062523 ) ;
  }

  @Test
  public void test2747() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.35339009052396 ) ;
  }

  @Test
  public void test2748() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.38118097284475 ) ;
  }

  @Test
  public void test2749() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.4153543250544 ) ;
  }

  @Test
  public void test2750() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.54410379037742 ) ;
  }

  @Test
  public void test2751() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.56633450910132 ) ;
  }

  @Test
  public void test2752() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.57873738864427 ) ;
  }

  @Test
  public void test2753() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.58402712326544 ) ;
  }

  @Test
  public void test2754() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.73483243070676 ) ;
  }

  @Test
  public void test2755() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.73539784672751 ) ;
  }

  @Test
  public void test2756() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.73583784689053 ) ;
  }

  @Test
  public void test2757() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.98186421592726 ) ;
  }

  @Test
  public void test2758() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.82296306742671 ) ;
  }

  @Test
  public void test2759() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.92836834820662 ) ;
  }

  @Test
  public void test2760() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.9362162021086 ) ;
  }

  @Test
  public void test2761() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.93693166883797 ) ;
  }
}
