import org.junit.Test;

public class Sample03Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark03(-0.012705205021581234,-1.5707963267948966 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark03(0.01728667576356139,-36.145602192046184 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark03(0.017294501426933007,2452.7260514921677 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark03(-0.01909516784600559,9.761856241197968 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark03(0.02311442947391562,-1.273863109239354 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark03(-0.030775827716118087,-88.95942800999475 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark03(0.03804462908556893,1.5707963267948966 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark03(-0.046206843602234676,0.0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark03(-0.04728191456106323,-1.5707963267948974 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark03(-0.053562007166334524,-75.32759430333522 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark03(-0.06448030780021408,-29.763244982889447 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark03(-0.065468772446523,6.689094879480021 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark03(0.06628751716611792,-122.66605878731082 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark03(0.06841248271544842,0.0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark03(0.0692840103322319,46.14981288265821 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark03(-0.07691904539926739,0.0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark03(0.08182050527422602,-100.0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark03(0.1362855883368091,64.12411635731698 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark03(0.16815907381208317,76.96104936274412 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark03(0.1728465968191553,11.168420884383432 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark03(0.17410027162660116,4.886489252011291 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark03(0.19219814846691463,-2651.6977348329824 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark03(0.19410398331094278,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark03(0.19770778356059107,1.5707963267948966 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark03(0.19807569204438097,49.85781799115403 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark03(-0.20621626653024183,1.5707963267948966 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark03(0.21308862593645017,-57.33171596439022 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark03(-0.22071096499989906,-1.5707963267948966 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark03(-0.22181991858566374,73.60560744077448 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark03(-0.223742892188735,27.906011446831315 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark03(-0.22680237934649483,-23.368636144718685 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark03(-0.23240528692122098,2521.6335346073024 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark03(-0.2392875326378728,83.4914928527674 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark03(-0.24567991311685025,-33.335520743608996 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark03(0.2475971069743473,16.14608928531051 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark03(0.25007971317448363,-45.191408590908196 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark03(0.2619820495329439,164.6716322639312 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark03(0.276150277367945,-1.2946460494269516 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark03(0.2785693874340518,0.1729764047426162 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark03(0.2846077767216286,0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark03(-0.28994330735259805,1.5707963267948966 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark03(0.2938321345966415,53.689739752615765 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark03(-0.30889934061363533,52.229608084524074 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark03(-0.31323818954330296,-23.56889156033896 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark03(-0.3197945568363565,82.39724992238143 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark03(-0.3358216191157609,-98.62434696896273 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark03(-0.34390219073103623,-25.5134173586511 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark03(0.355783154491474,72.5401807673877 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark03(0.36070537274963854,86.69032222157395 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark03(0.38238429470731483,0.0 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark03(0.3848374553515015,91.7573368306067 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark03(-0.4115794504613177,-1.5707963267948202 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark03(0.4259019368866984,73.49641735107915 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark03(0.43479578350636294,0.0 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark03(0.43916397252792194,32.84679207783438 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark03(0.4421506546375964,57.236575517624644 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark03(0.4469885678694647,-86.87231873795606 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark03(0.4544917880869135,1.5707963267950307 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark03(0.46639888160645215,0.0 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark03(-0.4710678870514755,1.5707963267948966 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark03(-0.48371719634620547,16.33707482297754 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark03(-0.48600659416995895,-8.358840911449184 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark03(0.48688642017560674,7.367095213798876 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark03(0.5316595256381353,-227.38278972892985 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark03(-0.5400747097164924,-46.093168186768494 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark03(0.5735163547091437,-95.24505957977955 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark03(0.5793206644912413,49.11076567614569 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark03(0.5889323665220135,87.00158444991163 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark03(-0.6027164333592262,-45.54729385814011 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark03(0.61284217074369,-58.13099610124601 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark03(-0.6154705977959518,1.5707963267948966 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark03(0.6373196309737403,0.0 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark03(-0.6422261773119554,-2.1966873134612728E-9 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark03(0.6491635156939317,29.9593504423856 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark03(0.6616480555931928,-67.98269045709921 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark03(-0.6650572079773709,-1.4364685638307098 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark03(0.6677141285666508,-16.079401459628457 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark03(0.6745555141158405,-16.685756424464042 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark03(-0.6772357308027459,-18.398386412039308 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark03(0.6800923374029395,-51.327529285037144 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark03(-0.6941162962973753,0.0 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark03(0.7034376087871057,1.285930424351847 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark03(-0.7511437665744894,54.977871784752494 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark03(-0.7571025311369937,0.0 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark03(-0.7656570312013804,0.0 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark03(0.7719543234474379,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark03(0.7748591626518166,40.66998325504642 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark03(0.803123671698955,-56.46701572863234 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark03(0.8154821002609225,0.0 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark03(0.8192099801584813,56.31172797299996 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark03(-0.8216506707482694,55.30185989255253 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark03(0.8273341440962356,4.656761641621728E-7 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark03(0.8562331497680511,0.34090636178246886 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark03(0.8633681599421038,-100.0 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark03(0.894629804551809,-110.93754531906332 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark03(0.8991840387880177,31.938705778955324 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark03(0.8995923769269218,19.38919847856713 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark03(0.90568297394316,3.9403690948857992 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark03(0.9367870396789524,-70.35468188918972 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark03(0.9540310527735085,-1.5707963267948948 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark03(-0.9633413015202557,-96.62548206458632 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark03(0.9733241141285286,-2.3629924725753426 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark03(0.9936245418005356,1.5707963267949054 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,0.0 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,-0.014331549397974097 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,-100.0 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,-1.0398314119215128 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,10.83233535567216 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,-1.5707963267948966 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,-1.5707963267948968 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,-1.5707963267948972 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,-1.5707963267949054 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,1.5707963267949054 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,-1.720219525295045E-14 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,-22.66874716405966 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark03(-10.00296830255254,-98.96016859033308 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,-45.54274451236947 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,-47.070196779852736 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,6.123233996776524E-17 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,7.105427357601002E-15 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,-76.92012925013188 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,-78.27271380310899 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,80.11062484776699 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,93.119373309974 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,-94.30709234758098 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,99.00722664628375 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark03(1.002706351629212,-100.0 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark03(-100.53063577754426,-4.712388977787288 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark03(-100.53087494656063,58.119525126671206 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark03(-100.89643755736174,41.17348013937179 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark03(-101.01429849781051,65.0839398244638 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark03(1.0135781486436883,-32.7948412071234 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark03(-1.0160947269996372,45.27333022331163 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark03(-10.197646939139645,-1.5707963267948966 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark03(-102.01115989281195,-0.02427725170747752 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark03(-1.0231512534803318,28.821978955622704 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark03(-10.231860636759144,-74.6345100353499 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark03(-102.32733465317287,72.48220444406984 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark03(-10.277565371125235,0 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark03(-10.316126632775486,24.453063792382522 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark03(-1.0365272785244315,45.55197775981446 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark03(-103.70997119154634,-10.995574069106985 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark03(-1.0381877984760877,0.0 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark03(-103.87636435436177,-16.49744943936456 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark03(1.039831411921513,-100.0 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark03(-10.411986877761379,155.51539001995664 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark03(-10.424659160990428,-14.429204203135605 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark03(-104.5390408952417,52.593094255248076 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark03(-10.46366510306827,93.6913659933868 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark03(1.0464480930200045E-10,-38.80091006834841 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark03(-10.468348924316956,0.0 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark03(-10.53481002802215,1.5707963267948974 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark03(-1.0555332455102988,91.21550011772311 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark03(-1.0582611233211594,1.0896256985307224 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark03(-10.626244404820667,-22.852185452178063 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark03(1.064696582275557,-1.5707963267948966 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark03(107.39695526430783,-0.6521829592219026 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark03(-1.0757394970808098,66.17479469567849 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark03(-1.0770360751083672,-44.3558213952018 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark03(-10.79762444785335,48.694698901904275 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark03(-1.0800592102819593,-135.57922122087405 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark03(-1.080511178234111,47.684020280189515 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark03(-10.812175616521273,-0.9091872167792161 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark03(108.36812369964908,-62.95604262377239 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark03(-1.0842021724855044E-19,-32.98672286269282 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark03(-10.920494462332854,-0.46283824447168903 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark03(-10.995574287564276,0 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark03(-110.20256371508553,2525.958403734941 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark03(1.1075681821722867,1.5707963267948966 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark03(-1.1102230246251565E-16,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark03(1.1102230246251565E-16,-12.101369288239653 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark03(-1.1102230246251565E-16,-54.97982456282874 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark03(-111.61514856284973,-68.82773525623983 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark03(-111.67476568845893,-0.3174315524530509 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark03(-111.69602413952052,43.99025696751514 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark03(-1.118810255515637,1.4147406067350736E-8 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark03(-111.95850430469821,-14.429218274720498 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark03(-112.59709403001986,55.63506937703988 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark03(-112.87951388514153,26.90109895923031 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark03(-113.09709384555723,-36.12831551239074 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark03(-113.09725254246703,86.3937979737193 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark03(-11.358657529489165,0.0 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark03(-1.137470927473569,50.202509888680936 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark03(-1.1446722434325096,14.864126447112525 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark03(-1.1451967877312242E-11,71.3540801657102 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark03(114.66813151432599,0.0 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark03(-11.602170835571869,79.79880343967454 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark03(-11.628553525751869,-1.5707963267948912 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark03(-116.33464577880008,2.761432434918305 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark03(-11.678821250550882,-12.385253479355123 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark03(-117.80956221754437,0.0 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark03(-117.82260522683656,1.5707963267948968 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark03(-117.98101312319761,0.0 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark03(-118.02123449488201,145.6064094224102 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark03(-1.18560015876569,0.5385512764071558 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark03(-118.84387352497811,2448.4650518523476 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark03(-118.92182143595807,80.64256053301756 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark03(-11.893115129913895,-15.901035581942551 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark03(-119.08100515126658,56.84553984266935 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark03(-119.15413733324162,84.8603121728078 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark03(-119.24073944350457,-0.5632741636621504 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark03(-119.37952035701699,42.41150051538058 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark03(-119.3806331347494,-32.986722862692794 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark03(-119.38227998174415,1.5707963267839635 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark03(-119.7483830720413,72.34590626063635 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark03(-11.983582840179835,0.0 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark03(-119.89426027325491,74.91121341097173 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark03(-11.994560161739813,-136.44305450455693 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark03(-1.2086341274113297E-24,1.5707963267948963 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark03(1.2100555578829386,0 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark03(121.76543753642909,-37.894273017201286 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark03(-1.2213488845663907,1.5707963267948968 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark03(1.2224263299339153,-60.04451670705262 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark03(-122.5215607535864,-61.76105674500939 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark03(-12.275795150734908,84.70589198411488 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark03(1.231883063566496,1.5707963267949054 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark03(-123.85785254344168,14.480983516954232 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark03(-124.00132872486375,-18.75797482960568 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark03(12.433659858326735,0.389425318250062 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark03(-1.2522073874529023,0.5691978753322485 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark03(-12.566370614389553,0.0 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark03(12.566371568379784,-42.411500812175845 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark03(-12.566439363356787,0.5707737867706123 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark03(12.566614754984313,124.09283231579623 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark03(-12.56833047319015,45.55309347704859 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark03(125.96957689546569,-5.018259732258654 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark03(-12.597620614375936,-1.5707963267948966 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark03(-1.2627487786771279,0.0 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark03(-1.264739499320271,0 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark03(-1.2682339190399738E-8,-174.3630046106596 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark03(-12.697967868938605,0.0 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark03(1.2708993510529666E-7,130.37577763276647 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark03(1.2775323922982498,0.15920338289220468 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark03(-12.809893509423048,1.0759940822731728 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark03(-12.811856374450452,2.999480717297317 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark03(1.2852274569006048,-1.5707963267948966 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark03(12.88799530276059,-1.5707963267948974 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark03(12.894272930197834,-5.212388980384691 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark03(12.94490242799371,-2643.7987553679673 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark03(1.295695831400766,-1.5707963267948966 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark03(-129.66478913601367,45.508458001406304 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark03(1.3002286271823327,1.5707963267948966 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark03(-1.300686159019456,-9.507032205161687 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark03(-13.016084349107608,1.5707963267948968 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark03(-13.054482946802208,-2.5696865388688948 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark03(13.065075500833998,5.212388980384691 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark03(13.07921909023768,-93.18983175677741 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark03(1.3158624748036547,27.290765461715072 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark03(-131.94689145074975,-1.5707963267948983 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark03(132.19689167409186,-4.962388968638834 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark03(-132.23264937249286,0.5916323873521829 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark03(-1.3245848753726968,-3.804815796492548 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark03(-13.261327750893818,-72.14753851762941 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark03(132.6969545485257,-2.6308970265433547 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark03(13.309070456273023,74.57012720127399 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark03(13.324080453910259,-75.15966323220586 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark03(13.377433883162698,19.87113213505663 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark03(13.417300848661739,67.95547975624785 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark03(13.419434646774135,0 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark03(13.420259639559461,0.0 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark03(1.3438620232978105,-1.5707963267948966 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark03(13.44632340450335,56.57202490941724 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark03(1.3501356642274775,0.27159237332459896 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark03(13.52502726248295,0.0 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark03(-1.3547564708242756E-18,86.40163843646067 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark03(1.3547913733105084,75.53492781300899 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark03(-1.354795728950009,-22.872298043216688 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark03(-1.3552527156068805E-20,0.0 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark03(-1.3552527156068805E-20,42.41174496408721 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark03(13.557104324409181,61.51893807232963 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark03(1.3569210924509907,2.9605460753741755E-5 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark03(13.574109799623571,-73.56484556928886 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark03(13.58495079869122,-37.758097297914304 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark03(-13.608735542338593,0.0 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark03(-13.608814813097794,16.666200956305588 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark03(13.616238080292117,14.42920367559124 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark03(-136.40591628575197,1.5707963267948966 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark03(13.69126825749282,-44.93631477225337 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark03(-13.706191523284202,-92.72022760555733 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark03(-137.0958883484311,-0.4366079172750884 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark03(13.711829158507792,-18.438810219644495 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark03(-1.371739468244459,-69.74539601937104 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark03(13.723908470457062,82.3797479871497 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark03(-1.3754770402171115,44.84672340598581 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark03(-13.798367451923063,0.12839076411507727 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark03(-13.80033462663786,-3.1864340836882348 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark03(-138.07205517075198,-158.0288685669007 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark03(-138.23049787881124,1.5707963007272228 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark03(138.26134044913175,-1.5707963267948983 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark03(1.3832993739790642,-0.3449536852020634 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark03(-13.848110128135076,-1.5707963267948966 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark03(-13.858484913292724,-0.45493024673977295 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark03(1.3877787807814457E-17,-1.5707963267948977 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark03(-1.3877787807814457E-17,42.411500823476764 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark03(1.3903840995025347E-16,1.5707963267948977 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark03(-13.906332489283441,1.5707963267948948 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark03(139.08153740652196,-16.928960743485504 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark03(13.940742289408476,-1.5707963267948966 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark03(13.980487136967085,-21.26242203978063 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark03(-13.988073703172553,1.5707963267948966 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark03(14.006906831208235,94.11751949774796 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark03(-14.01243720917102,0.5490876654504327 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark03(14.015202638995888,-25.460385407631364 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark03(140.5907548226511,-38.54819600984158 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark03(1.4060328976343044,0.0 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark03(-1.4060507099487447,-1.5707963267948966 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark03(14.064733966521684,0.0 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark03(-1.407952305079462,-58.84000627343826 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark03(14.079768416933163,88.41585245003048 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark03(-140.92155099667582,40.40121754111644 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark03(14.106362325896393,0.03080461525767524 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark03(-1.411257702598789,58.19920366836692 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark03(-1.411514475997798,0.056601341571001 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark03(-141.17938184227853,-7.022760408467602 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark03(-141.22331195142965,-107.4979536158629 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark03(-14.132185163879512,-33.115693315204226 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark03(14.155428706004784,-51.34745703956989 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark03(-141.8726764362384,54.26222684958998 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark03(14.204934862462991,62.22474134238598 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark03(1.421984813997426,-33.349327338843636 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark03(-142.40806385300476,-136.18246589715858 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark03(-1.425821586215946,77.82811951380242 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark03(-142.78414690568755,-39.23900374738322 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark03(-14.284846692088522,-42.37380767709582 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark03(-14.309532891546212,59.14424110436602 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark03(1.4403357073796905,-16.9574629895517 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark03(1.4418647664012028,-6.276621078285584 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark03(14.444032804165817,-1.5707963267948968 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark03(-144.51326203860307,-130.37604413184195 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark03(-144.51332609324245,0.0 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark03(-144.51376441837115,-36.12831551640765 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark03(-144.51426060038978,95.8185759344873 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark03(-144.5603904179109,-69.74197449836153 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark03(1.4472629479653225,2.3435001645019753 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark03(-14.475171433001591,-100.0 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark03(-1.4512144212930336,-8.54943934362706E-4 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark03(145.18944870752003,-17.27877137767817 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark03(-14.527010599924603,0.0 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark03(1.4585872409675864,1.5707963267948966 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark03(-146.65485471832764,2.5707962567091607 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark03(1.4675959613887115,45.00635143771987 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark03(-14.687831561713182,34.269055705976314 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark03(1.4756749041803392,0.0 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark03(14.805936800591653,18.01681106778554 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark03(1.4822812790819853,0.0 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark03(-14.829280180726357,0 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark03(-148.76834756633738,-5.9960339806100365 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark03(-14.888139296685495,0 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark03(1.49942114764204,-1.5707963267948966 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark03(-1.5041190755198794,53.34039785975147 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark03(-15.05906104229868,14.429207315898658 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark03(-1.5070611450052667,-57.4386368255805 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark03(-150.79638536588368,-4.712388978513333 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark03(1.5156562261166004,-0.5697931091300316 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark03(-151.93884740617452,-4.570086804939351 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark03(-15.21271701369901,0.0 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark03(1.5219551149692667,-0.05194808775360021 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark03(1.5220555880231723,-3.3298201341436218 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark03(-15.30077331499146,57.766595341672286 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark03(1.531020091460137,-1.356855965477463 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark03(-15.385493937976761,20.74282157830586 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark03(-1.5407439555097887E-33,-1.5707963267948966 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark03(-15.409736228315388,1.5707963267948966 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark03(-15.412923545649008,-39.78710118465263 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark03(-1.5470309257082988,82.34707375064224 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark03(1.551756357294915,-88.1756959490706 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark03(15.54779143685299,-88.82272635296586 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark03(1.5573989309548635,-157.0930300753297 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark03(15.62169210679889,-1.5707963267948966 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark03(-1.5627178369904458,1.5707963267948966 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark03(-15.636879330703636,-0.005166855598060244 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark03(1.5664236047797875,-9.069129553978955E-4 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark03(15.675494162209365,-0.39431528037537167 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark03(15.707962066754096,1.570796326794898 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963252447548,-3.0390520069207554 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark03(-15.707963264159423,-89.53539062730825 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267883487,-1.742138864642268E-5 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267901854,-78.07111075445088 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark03(-15.707963267924429,1.5707963268194467 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267946141,36.56938920960485 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267946283,54.22212965914284 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267946887,-17.279204018596108 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267946903,0.0 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark03(-1.570796326794705,53.78790054106753 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267947207,1.5707963267948968 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark03(-1.570796326794735,0.0 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267947491,-2589.9750490764454 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948024,-58.19917262187595 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948521,-93.84803719749155 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948557,84.91504354786184 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948628,1.5707963267948972 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark03(1.57079632679487,0.0 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark03(1.57079632679487,1.734723475976807E-18 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948841,86.06213631131715 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948877,-1.5707963267948961 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948906,0.0 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948912,14.42940644651884 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948912,-15.958161124030951 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948912,20.675984378465856 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948912,-4.530989579866329 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948912,46.449035198443724 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948912,4.828087505948361 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948912,-49.687391375933515 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948912,49.853109626898004 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948912,-67.02262268762439 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948912,88.30009797681635 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark03(1.570796326794893,-1.570796326794897 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948948,0.0 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948948,1.4481557853857566E-5 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948948,-25.77216242480685 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948948,-26.78021034052493 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948948,-27.08821991582579 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948948,36.128315516499995 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948948,-58.00124059517025 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948948,69.52961989342619 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948948,-78.97485960089449 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948948,97.31749940883878 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948952,27.051656540186286 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948957,0.0 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark03(-15.707963267948957,0.0 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948957,0.0 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948957,0.7182004898126166 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948957,100.0 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948957,1.4689572391775125 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948957,-2523.7975679088113 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948957,-27.12710710643576 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948957,31.526052078778477 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948957,-32.78307714308811 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948957,-55.713636077962434 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948957,-64.3631491533556 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948957,-88.34110984769447 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948961,0.0 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948961,-10.160215931020957 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948961,-1.5707963267948966 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948961,-40.33495740533819 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948961,44.939649611177295 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark03(-15.707963267948962,32.98672178401568 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948963,-1.3775545114326917 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948963,15.873424407183549 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948963,24.108976697216953 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948963,2452.911444631114 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948963,2516.3323846780977 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948963,29.94661015251965 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948963,-3.141592653589793 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948963,-52.652245947019836 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948963,-56.13242827552412 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948963,-93.30414873180418 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948963,-95.4845261808974 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark03(-15.707963267948964,-1.5707963267948961 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,0 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,0 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948968,0 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948968,-1.5707963267948966 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948981,0.0 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948983,100.0 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948983,-1.5707963267948966 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948983,-2508.3137298802108 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948983,32.753791398281976 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948983,-36.128328214192 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948983,48.399355997899036 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948983,61.32821609460686 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948983,-69.19629506821431 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948983,-8.60888432827545 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267949054,1.5707963267948968 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267949054,-2.455572864387324 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267949054,79.87828597826712 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267949054,-88.47614521663667 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark03(1.570796326794922,-0.5707954337984616 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267949268,-6.781476001219127 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267949303,2608.458884805657 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark03(-15.72362476005739,-120.9513171786347 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark03(-15.757706718629777,0.0 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark03(-15.777695357669954,99.02990067779947 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark03(-158.17476487424742,38.24486205252853 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark03(-158.50609175557642,-29.087092754621978 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark03(-15.960608607068494,0.002973813894680348 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark03(-16.02500680849175,0.0 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark03(-16.079760202462428,53.49968088197724 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark03(-16.21578486223156,7.346160039691891 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark03(-16.312656440217303,-28.647176719215352 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark03(-16.51585050596444,-27.52048692901826 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark03(-16.542798214343748,-81.03268785555255 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark03(16.603089056618828,-4.364950206846572 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark03(-16.684592373694294,-54.97790083892762 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark03(-16.984777201815774,0.0 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark03(170.00446255045114,-5.070848235036715 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark03(-17.031297453514394,1.570796326797933 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark03(-17.141868483635903,-1.5707963267948966 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark03(-1.7151244994428829E-15,-1.5707963267948983 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark03(-172.03537119754617,-54.70136154421284 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark03(-17.3703055170392,4.876715179465741 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark03(-17.404466115974557,2614.1721679096013 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark03(-174.310973131222,-22.763107428374052 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark03(-175.5962091334439,136.99225989874054 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark03(-175.96349041875453,95.81857593441119 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark03(175.97642393329346,1.5707963267948983 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark03(-176.18240621306825,-58.7938337114838 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark03(-17.690528875313134,73.72274829628437 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark03(176.99081258319427,-14.434319326827797 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark03(177.4520264903365,50.21752401994987 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark03(-1.7746681998026035,107.49301673915816 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark03(-1.7763568394002505E-15,-14.429203695407331 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark03(-1.7763568394002505E-15,-1.5707963267949054 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark03(-1.7763568394002505E-15,26.12161029974215 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark03(-1.7763568394002505E-15,69.05609484201929 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark03(1.7763568394002505E-15,72.86517906268278 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark03(-177.81748012334916,-44.42542296936053 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark03(18.003163026656537,0 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark03(-18.268338854292594,-49.37292774197417 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark03(183.74085194296833,-94.29009789972837 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark03(-18.392940066489246,36.71574265495522 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark03(-18.52569969744333,-37.26704650226013 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark03(-18.54238603185585,-65.99871743993955 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark03(-186.2739230564495,-0.2518315963809939 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark03(-186.40274458591102,-35.69603140681639 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark03(-186.68285479963689,0.14904292280679438 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark03(-18.6985102979293,94.54508797494796 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark03(-1.878651379060841,74.67560062856145 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark03(-18.823309316004288,4.738635648883962 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark03(-18.849555921411802,-51.83628079603099 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark03(-18.849800871450945,1.5707963267948966 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark03(-18.858527465188626,-39.26982118593795 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark03(18.86838944746291,88.30761281870129 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark03(-18.928763360568013,5.84524745500093 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark03(-19.064739960684292,63.243840998883385 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark03(-19.14293314110988,9.597419799970197 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark03(19.15532463172036,3.624307223557007E-16 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark03(19.175909718742673,-94.56137458378812 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark03(19.229077950818535,-128.03178298158295 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark03(-1.9259299443872359E-34,1.5707963267948966 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark03(-1.9259299443872359E-34,-7.853981633974482 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark03(19.274969636954975,0.5707480389064391 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark03(-193.0174301635598,-78.11565100940366 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark03(-1.9312371594306,-91.4666277867397 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark03(19.316506784661385,74.26956328883487 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark03(-19.331965251998177,0.0838975414619153 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark03(19.349555921538762,11.43286342245015 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark03(19.349556002573554,70.20352836623356 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark03(-19.36495701513699,67.02884095858232 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark03(-194.6927219356358,-61.76572414140804 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark03(-1.9504707938974555,-71.91778807057378 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark03(19.538051557906183,1.5707963267948966 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark03(19.542592305257013,6.123233995736766E-17 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark03(-19.600473858977495,2573.6188693480753 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark03(-19.619158116417935,-1.5707963267948966 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark03(-19.715884264788706,0.0 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark03(-1.9721522630525295E-31,0 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark03(-1.9721522630525295E-31,-1.570796326794897 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark03(19.76234991474037,57.442529166936694 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark03(-19.785679448040796,-43.55523880509092 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark03(19.82986572441783,0 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark03(19.88978649822009,0 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark03(-19.968363872993365,107.41525271469995 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark03(20.002965509836173,2627.6060322830926 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark03(-201.05829644615204,64.40313767992836 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark03(20.118957937181424,-32.80962350434222 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark03(20.130242024380962,-23.611449263769018 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark03(-20.133999328919597,-2.2099699308369765 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark03(20.21942296696706,-87.00683663840843 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark03(-20.233882531293034,-79.46705199923805 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark03(20.25271184110204,-60.78141926439506 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark03(-20.25586456090744,77.88540149166147 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark03(20.361932894017315,3.2219838559708265 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark03(-20.384058767570906,-19.695929540695076 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark03(20.410896107284785,71.42326856478144 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark03(-20.429567573595236,44.47052451927013 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark03(-20.43125476136865,-72.08365947696973 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark03(20.450683647873205,0.10814502208218166 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark03(-20.480330864951938,1.5707963267948912 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark03(-20.497572922169194,6.838704349462103 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark03(20.50181413827889,-0.08663403498152078 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark03(20.52895337320038,64.43132316216062 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark03(-20.531989405008922,0.0 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark03(20.532155710662582,107.94667742463389 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark03(-20.54118795517381,72.21708573196057 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark03(20.544269280655477,1.5707963267948966 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark03(20.585726627737795,-19.632304433764133 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark03(20.592514050213204,1.5707963267948966 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark03(20.599782375240803,-44.16172727716425 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark03(-20.633027829319676,-6.281478345499073E-16 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark03(-206.33391744224832,-17.585213552412313 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark03(20.634129028673883,0.0 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark03(20.636230668127087,9.59924941367512 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark03(-20.64010565751104,-0.266231177133747 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark03(20.667618007168617,51.68940865552757 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark03(-20.73822106610825,0.0 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark03(-20.746390275767283,58.63439441255602 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark03(-20.75667973261383,44.546754407283075 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark03(20.780553467282843,16.118962258355225 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark03(-20.828603933002153,-10.995691417994568 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark03(20.83508628117446,-1.5707963267948983 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark03(-20.842070663070572,-9.846496375506296 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark03(20.878219144165154,81.22354209750313 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark03(-20.908427070794318,23.846574060751962 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark03(-20.929499395285205,32.51728877547945 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark03(20.94713186627088,-4.389638644207196 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark03(20.97858426502131,-9.727606168245558 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark03(-21.025318380675117,8.918716371308946 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark03(210.48670779036536,1.570796326794897 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark03(-21.12094946562711,0.0 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark03(-21.144050585593874,-53.49155605207745 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark03(2.1175823681357508E-22,-92.67698327966116 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark03(-21.1935168176389,-1.5707963267948841 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark03(-212.05750411728621,2.471077887941453E-11 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark03(21.23941715491094,-0.027144790214234833 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark03(-21.43888618644565,71.23809709445325 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark03(-21.460098235949076,-44.41675600382363 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark03(-21.461762510203663,4.658715441331523 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark03(21.47333399533079,4.373700233423719 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark03(21.481922777301477,0.3892195738762086 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark03(-21.519708584714625,-13.677750975359643 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark03(-21.54703850990857,-0.011738473889438302 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark03(21.59414653497761,31.51532788864921 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark03(-21.632079611600673,53.66547880663266 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark03(-21.667975867193604,1.570796326794897 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark03(-21.67222354363357,-86.38474402458452 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark03(-21.685692885301332,-17.035535940334295 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark03(-21.700977324279943,-16.835517905803115 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark03(21.72070733304678,0.0 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark03(21.737722388465855,-25.01751174601617 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark03(-21.755018119770636,1.5707963267948966 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark03(21.76640584075347,-12.87681464118458 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark03(-21.76713239622201,2597.9807084738513 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark03(-21.769349136465173,87.5672208129016 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark03(21.772839253343548,100.0 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark03(-21.775814733922168,95.07269230176121 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark03(21.81260688189031,1.3922546335566546 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark03(21.825403855145346,-100.0 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark03(-21.903017682463314,136.61332833885425 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark03(21.939809909835986,62.55776705413363 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark03(-21.940069597297665,-47.844935367703904 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark03(-21.963611846907224,-2.0707963267949854 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark03(-2.1963771321504595,31.50813528395768 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark03(-21.97487500240214,1.5707963267948966 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark03(-21.97747249611001,-1.5707963267948983 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark03(21.991141690967027,-130.37608197822155 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark03(-21.991144818897578,-0.5669126754943764 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark03(-21.991148020768666,-26.703537555513105 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark03(-21.991148569523673,58.11946409140808 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark03(-21.991148571381736,48.694698462064835 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark03(21.991148574452144,237.19020746807092 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark03(-21.99114857473766,95.81837978089945 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark03(21.991148575123805,149.2251823123695 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark03(-21.99114857512844,-1.5707963267948966 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark03(21.99114857512846,-1.5707963267948966 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark03(-21.991148575128545,-1.57079632679482 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark03(-21.99114857512855,0.0 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark03(-21.99143452525442,-67.54389636259775 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark03(-22.01084706498824,-1.5707963267948963 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark03(-22.11452938586539,-44.08687056315523 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark03(-22.15039455415802,-1.5707963267948966 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark03(-22.201984830044523,-6.8434626091602535 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark03(-2.220446049250313E-16,0.5798032498950031 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark03(-2.220446049250313E-16,6.123233995736766E-17 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark03(-2.220446049250313E-16,93.82161349603953 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark03(-22.28043771087775,-85.39125818264924 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark03(-22.285411740952128,-0.8475499366417618 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark03(-22.315870317261812,100.0 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark03(-22.327015362166712,49.030552917679955 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark03(-22.36390118428251,0 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark03(-22.41036031043587,-1.5707963267948963 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark03(-22.446595061762796,-67.17812327927497 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark03(-22.46367481147409,-80.81776365160249 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark03(-22.511405952130783,-178.44993960067083 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark03(-22.55765066936246,-84.71190394072322 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark03(-22.625948970452,-20.420352248333657 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark03(-23.10935163602133,-44.40796466750571 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark03(-23.114335501830197,-85.60218768545208 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark03(-2.3122464224551322,-18.44825349127646 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark03(-23.150999883057267,-42.65860186930801 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark03(-23.25183510153605,-76.60315718866329 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark03(-23.31666259385763,-64.00003366585503 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark03(23.43313200785424,0 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark03(-23.561944901923187,0.0 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark03(2.3741992746117077E-32,-10.995574287564274 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark03(-23.82713552165761,158.13935498888077 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark03(-23.85446485608624,0.0 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark03(-23.977480582887097,-93.25675128642865 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark03(2.399178221076282,-1.5707963267948966 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark03(-24.042169113485382,-45.28502191070302 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark03(-24.42563573598737,1.570796326794897 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark03(2.465190328815662E-32,-1.5707963267967158 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark03(-2.465190328815662E-32,-54.977871445261556 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark03(-24.789881808370364,-0.5804396393141917 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark03(-24.7970192524472,0.1717193455505407 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark03(-25.024844339504774,0.0 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark03(25.132741347927638,1.5707963267948966 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark03(-25.132741368072573,-1.5707963267948963 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark03(-25.13274313606771,-73.82742987029647 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark03(-25.13274319854718,-102.10171422042391 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark03(-25.13280535765427,0.5706736393668971 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark03(-25.136647849053578,224.63170233718458 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark03(-25.13665314569428,-1.5747082437708295 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark03(25.14836709588336,-67.54424205218048 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark03(-25.16176496440326,-81.0016497697992 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark03(25.197891870798095,4.77753962246444 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark03(-25.22328707308196,-1.66134217115851 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark03(25.22493322057862,-1.0016897829763423 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark03(25.236021499779337,-77.37739438495548 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark03(25.25247014232855,12.385837765032662 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark03(25.32367946730808,-18.535126370885738 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark03(-25.345536308851123,0.0 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark03(-25.37036901205247,0.0 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark03(-25.374149203355117,33.35642543969823 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark03(25.396675188236742,1.5707963267948983 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark03(-25.39915290836418,-166.9263424438902 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark03(25.41057333291812,-63.82336977800263 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark03(-25.41252959564224,-92.99887039497649 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark03(25.42203364791027,2533.6105033302624 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark03(-25.428778828710584,-0.18298242153843886 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark03(-25.449555459105483,26.643370133382845 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark03(25.466345067528533,-40.49039995843735 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark03(-25.52418800129462,60.207393208402095 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark03(-25.52647651061342,91.09271290401071 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark03(25.558228230875812,16.51220282529808 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark03(-25.567597655396,-82.96620310329828 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark03(25.596231173552585,83.54391463100973 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark03(-25.60178266301336,-1.5707963267948968 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark03(25.634777750389144,-9.742762853844425 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark03(25.7142910530804,76.93440374442636 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark03(-2.5814854737384376E-14,1.5707963267949225 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark03(-25.838654633478242,-9.731193397488909 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark03(25.933470984405503,0.032377805579390184 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark03(-25.934885000457868,39.07997949728386 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark03(25.963809674256943,-15.925791186024217 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark03(26.005906931904278,45.553093477052 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark03(-26.006176007981125,84.1256400993923 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark03(26.033843670938438,-4.425173359619154 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark03(26.100969715423204,91.65776955111134 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark03(26.14705097583993,-1.5707963267948966 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark03(-26.185445156912124,-120.64325396862003 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark03(-26.200256728225085,-1.5707963267948966 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark03(-26.233092358353595,25.349077392318392 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark03(26.237721867714512,0 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark03(2.631767899052349,-63.396129973988316 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark03(-2632.539133511984,0 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark03(2.633112669836194,0 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark03(-26.369014353368108,1.5707963267948966 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark03(26.375721966246516,3.552713678800501E-15 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark03(-26.398631692090987,135.4474590439025 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark03(26.428790477027036,4.440892098500626E-16 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark03(-26.461787614042567,0.0 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark03(26.53964575895516,-7.200826155859815 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark03(-26.58589782275896,58.689669120051974 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark03(26.65456055005312,-31.577694461245446 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark03(26.70353755551335,1.844284414371515E-12 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark03(26.755507282888402,-0.3932101312796169 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark03(26.776530649591542,0.11500251147662807 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark03(26.83482715167961,12.00317413732121 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark03(-26.84905221790518,58.35450369445667 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark03(26.873037052554828,58.46762444600835 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark03(26.882072846270418,-53.93824521680258 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark03(-26.901357968005215,-100.0 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark03(26.913901247521853,63.042216763804475 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark03(-26.93765592720301,117.42731272993586 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark03(-26.946932270269727,-72.96932457103784 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark03(-2.6948419387607657E-15,23.561944901923447 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark03(-26.984833235249692,9.14348228103293 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark03(27.015419691546086,-81.30170213114434 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark03(-27.018185129739436,37.20406789974463 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark03(-27.03351475957838,-1.5707963267948966 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark03(-27.038612215317386,102.67206284493192 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark03(27.04971578821098,-73.827489508923 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark03(27.06766561981084,-33.15533599629819 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark03(-27.07024369564723,80.11061272421556 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark03(-27.07977440490169,-15.353246098559097 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark03(27.083373096324834,-1.5707963267948966 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark03(2.710505431213761E-20,1.5707963267948966 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark03(-2.710505431213761E-20,-17.279247875993864 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark03(2.710505431213761E-20,-58.15071409141122 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark03(2.710505431213761E-20,-67.54424205212393 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark03(27.106312046572768,-98.63186817163476 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark03(2713.115910629235,0 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark03(27.141574429749575,-1.1474026117602278 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark03(-27.14975568680915,14.454145328441214 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark03(27.163389184094527,2567.911041646865 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark03(-2720.197909114023,0 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark03(-2.7369110631344083E-48,70.6858347057701 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark03(2740.5458305027737,0 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark03(-27.407756006741238,0.0 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark03(27.599367852234195,94.43676490315977 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark03(-27.610290966032494,-9.289186336057327 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark03(-2.767208041052214,93.99423642500693 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark03(27.732631364630375,24.566798003830506 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark03(-2.7755575615628914E-17,158.65042900628447 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark03(27.77568455012252,67.78677856106592 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark03(-27.779046304831922,-19.521504587871576 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark03(27.784026389035503,77.74865295847673 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark03(-27.81528618876726,18.162678948158927 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark03(27.825352666283997,243.48047238460455 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark03(-27.83105220974455,-2439.753867708726 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark03(-27.84306534428021,0.5707220083183123 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark03(27.86737885973051,8.031602017646506 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark03(27.890387185614856,-130.85627771692077 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark03(-27.890433274157985,-21.555875963289665 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark03(-27.89813598766002,-0.13485180994586382 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark03(-2.790640140986028,7.105427357601002E-15 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark03(27.908175655743882,0.0 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark03(27.92804506047548,94.5505910926324 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark03(-2.79423683095653E-15,1.570796326794897 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark03(-27.95480299760355,7.273661547324616E-16 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark03(27.99200833272792,-1.5707963267948966 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark03(-27.998894870065648,22.163522975808853 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark03(28.024992225551784,-4.961730637141044 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark03(-28.026471500331798,1.5707963267948966 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark03(28.050924217064573,63.22075594429798 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark03(-28.099088662313946,0.34792951180582615 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark03(-28.103692980285814,11.287116421428294 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark03(-28.108642007087568,-186.7578537026874 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark03(28.178052363684237,1.5707963267948966 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark03(28.18134057602532,0.0 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark03(-28.20878450074015,2.070796326795417 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark03(28.20902161691967,-85.42452835376292 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark03(-28.214102766375504,0.0 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark03(28.258944714222103,0.05387726270171811 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark03(-28.27084219423142,-0.5651149480855825 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark03(-28.27352513071871,-1.6332963270215253 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark03(-28.274318070953477,-32.98672285210618 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark03(-28.27433388060986,32.986712193448994 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark03(-28.27433388128979,1.5707963267948957 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark03(28.274333882265275,10.995574150731217 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark03(-28.274333882299032,0.0 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark03(-28.274333882307914,-1.5707963267951484 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark03(-28.274333882308092,-26.703537478010922 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark03(-28.274333882308134,1.5707963267948963 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark03(28.274333882308134,-1.5707963267948977 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark03(28.274333882308134,1.5707963267949092 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark03(-28.274333895252063,0.0 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark03(-28.27433391556384,-1.5707963267948983 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark03(-28.274334137936712,-1.5707963267948974 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark03(-28.300299616371944,0.0 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark03(-2.83371641779641,-135.46181963526115 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark03(-28.380201098512998,-108.01271525593258 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark03(-28.40968010130061,0.0 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark03(-28.476199146696835,-19.102966173433607 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark03(-28.651897406668642,1.1936114824380457 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark03(-28.741633630173936,2439.156118699006 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark03(-28.762421503832627,100.0 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark03(-28.87250831055927,1.5707963267948966 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark03(-28.910846183781473,55.458838175358004 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark03(28.996641559610225,0 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark03(29.04097320383238,44.903690778915774 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark03(-29.15072454001634,-92.45144655697837 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark03(-29.1732849286783,0.13253701884299426 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark03(-29.241046362088554,26.586012267088094 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark03(-29.35182485278294,94.81565596516785 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark03(-29.391315268888476,-5.829370366965027 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark03(-29.428590164283406,1.5707963267948966 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark03(-29.586794799746002,0.4902303827839507 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark03(-29.607380665184564,-42.38702785622239 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark03(-29.61701189941903,17.91580825777737 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark03(-29.735608562900524,24.151617063026904 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark03(-29.745595195193822,31.59668909743049 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark03(-29.748962114548476,45.29025565831958 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark03(-29.78830044980707,0.07660111961830572 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark03(-29.932534892841005,0.0 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark03(2.995077778545948,64.76537501475022 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark03(-30.025957417110078,0.9278258954660098 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark03(-30.15298021631929,-0.001756228854016334 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark03(-30.302225199678844,1.5707963267948966 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark03(-30.579171325965554,-94.47786732173937 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark03(-30.691512301817426,-12.797921809752422 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark03(-30.72020662924462,-49.39040603729511 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark03(3.07710481911856,-83.2129291184486 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark03(-31.00149133637383,35.62548117450091 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark03(-31.045389986901,-59.738332143805636 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark03(-31.183770440683887,1.5707963267948968 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark03(-31.293696944857604,39.118232223891056 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark03(-3.133441187454307,-9.662467387952972 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark03(-3.141582237543157,-32.98672286268528 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark03(-3.141592653381926,-0.5350788480744894 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark03(-3.1415926535897922,1.5707963267948963 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark03(3.141592653589822,-1.5707963267949248 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark03(-31.415926543348515,-1.5707963267948963 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark03(-31.415927347638576,0 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark03(-3.1416002829844807,1.5707963267948966 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark03(31.416048606225385,1.5707963267948988 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark03(-3.1420809348397936,-1.5707963267948966 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark03(3.1420809348397936,32.9868521998193 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark03(3.142080935913714,-10.995287572883708 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark03(-3.142614976594298,-1.569774003790392 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark03(-31.4387038580426,-11.283216113069132 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark03(3.145903996417685,146.08601399760892 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark03(31.46078440497223,1.5707963267948974 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark03(-31.53537556946346,-1.5707963267948966 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark03(-31.539920655042565,-1.5707963267948972 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark03(3.15721869393562,67.54037192140022 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark03(-31.582813241671595,-227.72753975733315 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark03(-31.618853038363028,-2.070796326794897 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark03(-31.619087135200246,0 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark03(31.6957166708396,48.82336950831311 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark03(-31.82758485807328,-54.28359197890019 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark03(31.86119902383049,1.5707963267948968 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark03(31.867848556626853,-1.570796326794735 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark03(-31.898928034724136,-0.028433064606844027 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark03(31.96277703025973,-17.06013166765443 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark03(-31.972196943528118,-13.635116379133791 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark03(32.04034560436082,1.5707963267948966 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark03(-32.08432356341535,15.832588365453688 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark03(-32.20823749522251,-1.5707963267948966 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark03(-32.293877907327115,8.731933005403667 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark03(-32.367921842277596,-49.06170819196126 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark03(-32.37396593455977,2.570796326794897 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark03(-32.388832131955574,-29.946862436327336 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark03(3.2406678057196956,-24.38889046362165 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark03(3.2412606460204323,10.895906295133639 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark03(-32.457467449549625,-0.08053050793230965 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark03(32.470831797782,-100.0 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark03(-32.47227167567605,0.0 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark03(32.53859858151975,2531.556825473062 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark03(-32.545809595617214,-36.684418448767545 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark03(-3.2546923849970737,0.0 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark03(-32.59842558176131,-52.667370721242634 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark03(32.63096839991926,0.0 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark03(32.636179991503546,-56.19812489342699 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark03(3.266592653591822,-54.8889180439869 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark03(-32.670370980314644,47.803722455194176 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark03(-32.6811695254809,8.46316138195192 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark03(-3.2688774376613905,-83.20650562612022 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark03(-32.752187810817006,2529.6729199205265 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark03(32.76792442074151,148.5525693334353 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark03(32.77355815987099,-1.5707963267948966 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark03(32.79021599244072,-17.999908058629444 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark03(-32.840794940881956,-84.65088094941984 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark03(32.869663670940795,-0.1170591917520317 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark03(-32.902633281831115,16.185409667410656 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark03(-32.923888562678485,53.92369690221524 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark03(32.93388955906279,-0.5224080486329076 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark03(32.97079367957162,82.68627921357603 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark03(32.97140451560816,-62.86107265408876 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark03(32.9831830371168,0.0 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark03(-33.07418696907455,97.47683636766531 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark03(-33.086802407697995,1.5707963267948966 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark03(3.3087224502121107E-24,67.54424205125893 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark03(33.13979363197138,-0.1395913376336485 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark03(3.314038556000216,-4.539943077974267 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark03(-33.3462813921154,-1.5707963267948628 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark03(33.62057052287791,-107.70258018043816 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark03(-33.632629633951524,-2683.6061437459416 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark03(-33.66013326389739,102.99914716725861 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark03(-33.66764534104804,50.17235424906491 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark03(-33.70278047507722,-9.809847794332072 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark03(3.405399045812796,-70.94964109799335 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark03(-34.140088708377355,-45.970523958162374 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark03(-34.28163372340846,10.996603084392959 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark03(34.5575191894877,-1.5707963267948966 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark03(-34.55849575199042,1.5707963267948966 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark03(-34.56530296058501,40.690572100169874 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark03(-34.73124912446086,13.405153490874822 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark03(-34.7348560800305,-1.5707963267948966 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark03(-3.483390858338865,59.573915773083115 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark03(-3.486900654001815,88.46668657876423 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark03(-34.87935353749088,-1.2489619787917436 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark03(-34.88569557446002,90.36844338941216 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark03(-34.888426562714365,1.5707963267948966 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark03(-3.4912095499805442,-44.242440904154044 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark03(-34.93590507587899,-56.25741964672561 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark03(-34.95341096925411,-16.587515235330017 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark03(-35.162410394472765,76.18495917415714 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark03(3.5243785301744566E-18,-1.5707963267948966 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark03(-35.35880914465149,5.991423378867424 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark03(-3.552713678800501E-15,-0.5185981447415134 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark03(3.552713678800501E-15,36.48739061036192 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark03(-3.552713678800501E-15,-73.5253675578304 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark03(-35.59846808315829,100.0 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark03(-35.65155386969324,136.23960306898007 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark03(-35.807541247751345,-87.06123060527102 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark03(-35.8787794587802,-1.5707963267948966 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark03(35.92690426042168,32.99926682542113 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark03(-3.5929615784295166,-2628.2383774059936 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark03(-35.94325860235044,-0.01208178061300152 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark03(-35.98131765491451,0.0 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark03(-36.03313439726976,0.1547382996319726 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark03(-36.27622521241745,0.16181306628066103 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark03(-36.591295645537684,30.44537820748365 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark03(-3.6694359550266107,94.85188546301728 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark03(-36.74622935939691,10.076145494506022 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark03(-36.78094934343712,76.90777789650488 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark03(36.837093634810856,-0.02564094838123765 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark03(-37.10073328615353,-109.88960201339974 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark03(-3.722412673235333,-100.0 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark03(-3.7360242837372155,71.25029643374998 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark03(-37.58048376821636,-84.92953463502649 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark03(-37.6324408841099,90.99931188257264 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark03(-37.69911162998626,67.54424203479915 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark03(-37.69911184307751,-1.5707963267948977 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark03(-37.701066588432916,-1.5707953064497677 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark03(-37.701070647129924,-0.5706216137321226 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark03(-37.72385146407514,1.5707963267948966 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark03(-3.7748873125036653,0.28534209935607313 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark03(37.82922749929614,48.33812812739964 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark03(3.7874848750001174E-18,29.845130209013828 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark03(37.98465235518054,80.75999335814825 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark03(37.988897105087005,-67.44836659329074 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark03(-38.0266055526475,1.8982900363648807 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark03(38.0416370236442,77.21480114760955 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark03(38.04932952618456,30.18234191141053 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark03(38.09002381296585,0.008173658721550908 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark03(-3.816017724833202,0 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark03(38.25538019522857,0.0 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark03(-38.255947479367,0.0 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark03(38.29170242970547,23.56194490192345 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark03(38.31116015892536,38.51931938038396 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark03(38.33071731512416,-136.35479592552736 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark03(-38.37576753990319,1.5707963267948968 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark03(38.426487134983454,-1.5707963267948963 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark03(-3.8518598887744717E-34,-1.5707963267948963 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark03(-3.8522620983354114,-36.64253443575587 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark03(38.5763900446677,0.5119961819192318 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark03(-38.6068007615534,-1.5707963267948966 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark03(38.69220949472731,59.23368132726864 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark03(-38.73587378987861,1.5707963267948966 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark03(-38.88565846992319,72.54707968838542 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark03(38.99821026754898,80.6663581864598 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark03(-39.061293315344365,0 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark03(39.113197966044616,88.6085897434369 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark03(-39.124707258558345,-78.99350971326535 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark03(-39.15398896099748,-1.5707963267948972 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark03(39.17139983401356,0.0 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark03(39.17161771465635,-50.981019895722376 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark03(39.17233919310988,1.5707963267948966 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark03(39.19710152033823,-149.57659450154625 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark03(39.25750617199196,1.5707963267948892 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark03(-39.70314937617469,-14.593614369232768 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark03(-3.9777828239157884,74.88114068392457 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark03(-39.9275127004497,-64.8841455662766 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark03(-39.94196302718602,-31.008129971515473 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark03(-40.14264432648802,-47.35372609536874 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark03(-40.19027281778615,13.354860137314034 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark03(-40.19039530558211,0.09666973756023062 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark03(-40.31015252478891,82.2046701477467 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark03(-40.73119749027576,-22.881210573915453 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark03(-40.84070448888641,-1.5642227200543155 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark03(-40.84070497350448,1.5707963267949054 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark03(-40.88283824729259,-41.79417396988929 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark03(-40.88964052048358,70.68583470577035 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark03(-40.92766399598998,-3.264518108091565 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark03(-40.963223124846344,-1.5707963267948966 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark03(-41.038186816334,0 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark03(-41.13954696423464,0.0 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark03(-41.168183020237244,76.31604485060677 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark03(-41.23024001471081,0.07281592935762049 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark03(-41.2943101312711,75.04862197827376 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark03(-41.29942995108755,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark03(-41.340994111905054,-1.5707963267522542 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark03(-41.37652835934562,1.0349724641165885 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark03(4.141592653589794,1.8302107741441773 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark03(4.141592653589794,-48.5671713129077 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark03(4.141592653589816,-65.26016132680576 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark03(4.141592653610468,66.59819461875551 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark03(-41.43999173767499,-1.5707963267948966 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark03(-41.46179369986959,1.5707963267948972 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark03(-41.51817143584759,-1.5707963267948963 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark03(-41.542865021197386,-1.5707963267948966 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark03(-41.61919923428663,72.89600018223453 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark03(-41.64981990455681,46.54483097425697 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark03(-41.704094664439545,1.5707963267948966 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark03(-41.71279184553587,-1.5707963267948966 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark03(-41.96892873189677,1.5707963267948968 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark03(-42.04371656150382,-32.95714636223951 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark03(-42.12807071064761,-16.215688476056044 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark03(-4.2224800484827085,65.51639380001592 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark03(-42.239008966199556,53.75050467210071 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark03(-42.263706401759066,31.950685014336543 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark03(-42.28741658932593,30.030340133836376 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark03(-42.32686841162774,0.0 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark03(-42.53784439737355,-2458.8111044170078 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark03(-4.2558778505312524,-1.5707963267948963 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark03(-42.59682513794526,0.1853243144830515 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark03(-42.59824668959101,58.372751989368766 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark03(-42.61192612279519,-0.1148868084429181 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark03(-42.63913058301311,25.735770611365822 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark03(-42.70163033886365,33.168993441335374 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark03(-42.73269932567638,-4.545208437686867 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark03(-42.73740341884158,8.916922731415958 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark03(-42.74250455235101,-1.5707963267948968 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark03(-42.75131532480843,88.30440880186043 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark03(-42.754232558448464,36.546760360028316 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark03(-42.763160904246746,1.2622759936055137 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark03(-42.772635560157354,-103.75877953598768 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark03(-42.877199334689095,-77.45020961848704 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark03(-42.93383278366358,100.0 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark03(-42.946957461599524,30.276437686849057 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark03(-42.966589530220574,-81.15758594816664 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark03(-42.9703271232687,-1.5707963267948972 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark03(-42.97359251100852,-64.38452902446288 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark03(-42.991574503603445,-62.06429868800764 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark03(-4.305650033138965,-5.429924642271118 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark03(-43.07095188363759,71.44327243319958 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark03(-43.13519759804169,49.54178568285721 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark03(-43.144070569862556,0.0 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark03(-43.251355797634325,12.316860220074673 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark03(-43.25972616549101,1.0416193810316088 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark03(-43.305075685110594,-90.37356200464579 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark03(-43.50359034557572,0 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark03(-43.533437714301044,-1.5707963267948966 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark03(-43.582045168053575,-53.39443841081486 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark03(-43.62036806052443,-66.0142538191878 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark03(43.728508116623175,-41.06985076720318 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark03(-43.77503690340989,-97.82502336197823 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark03(-4.3790577010150533E-47,-20.42035224833365 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark03(43.89082224863739,12.143742507129545 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark03(-43.95322919267521,39.73756570440062 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark03(43.98229716515827,1.5707963267948966 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark03(-43.98234998022212,149.2267775580743 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark03(43.98278545073322,-14.137166956586606 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark03(-43.982798819192126,1.5707963267948966 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark03(44.0120334358669,-0.4454783879200962 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark03(44.080435587373046,88.41968176058268 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark03(-44.10669680943386,-98.8356315691769 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark03(-44.10752801384439,14.466914336543539 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark03(44.118749237140534,-0.8425351156808752 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark03(-44.128794695399776,1.5707963267948963 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark03(44.13951740272848,1.5707963267948948 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark03(-44.14112797618431,-1.5707963267948966 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark03(44.237180206058014,96.34128608396284 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark03(44.28296487854277,-1.5707963267948966 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark03(44.32824715434509,47.04681477943981 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark03(44.342545161405724,-53.98308175330594 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark03(-4.440892098500626E-16,6.7480315283563925 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark03(-44.419659008211255,14.574528799108219 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark03(44.42174358622516,-57.59004398221094 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark03(44.42646663628523,-100.0 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark03(44.42758242668053,7.206673473486916 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark03(44.449087840268106,100.0 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark03(44.47474398899058,5.9817196452109686E-9 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark03(-44.52883043339918,-46.09962676019408 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark03(-44.596298439865365,0.007928886402786724 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark03(-44.60619447381533,42.772080724704864 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark03(44.613601891144526,145.45275365103797 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark03(-44.630174011332464,-36.12833845318671 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark03(-44.71239796955772,-72.25663103256524 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark03(44.719007452178374,0.7806477987129498 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark03(44.72746154432418,-0.8256319327278233 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark03(44.81244478069844,-69.30065602172849 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark03(44.85913151295097,39.90687870120479 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark03(-44.874538434648215,22.244272983372483 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark03(-44.92422044989998,14.429203947699818 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark03(44.97044520058361,-1.1619821148470537 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark03(-44.987056272310795,-88.38373332697928 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark03(-45.002798845942145,-3.238104483156519 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark03(45.0729424937706,-19.96469372745227 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark03(-45.07442180813401,-47.080770919879114 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark03(45.14414312167178,0.0 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark03(45.16373235986208,-63.22121418898578 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark03(-45.189227441385064,-1.5707963267948966 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark03(45.212040099251595,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark03(-4.521447299289937,93.83409837964402 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark03(-45.23133524796008,-52.148182308804635 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark03(45.28172192260277,0.0 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark03(45.30592169778223,-70.25034545670455 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark03(45.34951844037863,33.43025007862133 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark03(45.38285169776831,88.1348360797979 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark03(-45.38858548090017,-73.83086968718277 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark03(45.39792967075978,108.20066020492301 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark03(-45.44085078408463,-62.33858590660215 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark03(45.448368835189626,92.41791766550408 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark03(45.49631741659559,0.0 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark03(-45.50103283563121,1.5707963267948966 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark03(45.55309347704714,0.0 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark03(-4.563239167698512,0.46514091003288327 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark03(-45.707894728908926,0.0 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark03(-45.752218321612624,-27.049131341926877 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark03(-45.81550390756202,-79.71567059691144 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark03(-45.85750342060253,1.5707963267948966 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark03(46.09624856516192,-1.4239034962809296 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark03(4.610658930141334,109.85401282539941 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark03(-46.11958968174661,0.0 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark03(-46.154279470661955,1.5707963267948966 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark03(-46.20260243678713,14.532677411007704 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark03(-4.647343422796268,2616.8916141899585 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark03(46.50549977283438,0.0 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark03(46.5125666505206,-1.5707963267948966 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark03(-4.657025182625715,-0.05536379775897611 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark03(46.665845770487124,-2619.4160949315474 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark03(46.734790354523966,46.52352479643477 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark03(-4.677415191514202,-0.5566274362321175 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark03(-4.687228120949214,0 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark03(-46.91498393815381,-6.549400676011302 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark03(-47.103751638024384,-78.97231494831216 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark03(-47.123849502063244,48.698592380726474 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark03(-47.123889803846886,-1.5707963267948963 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark03(-47.12718143863324,0 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark03(-47.13460438469896,52.85703362535307 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark03(-47.141681994627646,-47.133366201354285 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark03(-47.19198437885508,8.59190874673341 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark03(-4.725699613914143,12.57968124788863 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark03(-47.374421059219564,0.0 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark03(-47.49091889864915,-1.5707963267948974 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark03(-47.622876631064656,0.0 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark03(-47.835991462884756,-1.5707963267948966 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark03(-47.873903791631804,-24.146526865233824 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark03(-48.11299651772079,5.174955081247674 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark03(-4.8148248609680896E-35,14.137166941154067 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark03(-48.1485001736174,-1.9857835716388559 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark03(-48.16377752176554,-2501.619412895391 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark03(-48.240044868345635,1.5707963267948966 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark03(-48.36382900864942,0.43378426998117653 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark03(-48.36766066050635,-30.419692569839484 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark03(-48.48521946701476,-16.86789567209547 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark03(-48.49964830488905,-36.868214004026946 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark03(-48.55508822242256,136.34211325594333 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark03(-48.578689308633116,63.001052531428456 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark03(-48.670536687329985,-6.42920625830842 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark03(-48.70701643954368,4.929074646838103 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark03(-48.71851501388751,1.5707963267948948 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark03(-48.730458005688874,-15.108238905948198 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark03(-48.7602899553421,14.42956870496414 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark03(-49.1056784895131,-84.34744725427723 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark03(-49.21861256863236,2676.3023242695654 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark03(-4.930380657631324E-32,0 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark03(-49.32602445896103,-41.33759751567534 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark03(-4.94168968653041,0 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark03(-49.43798716349554,-82.55448359626685 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark03(-49.582250963972555,153.05347160849314 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark03(-49.73906066588337,-90.57814623662142 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark03(-49.750660431913914,0.0 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark03(-49.75153299957399,168.0765038483855 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark03(-49.77757228508752,5.212388980384692 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark03(-49.81063451687594,-1.5707963267948966 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark03(-49.82576487493889,6.245784823410872 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark03(-49.85305510372966,28.577461300016523 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark03(-49.87278742874317,54.80298717614673 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark03(-49.90478107788408,1.210094947242286 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark03(-49.912774332869105,32.66634521661871 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark03(-49.95945869770504,-1.5707963267948966 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark03(-49.96781424101768,-24.31625766059191 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark03(-50.01644462982864,-16.611837591968566 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark03(-50.04499395037647,79.46478031715137 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark03(-50.05553104056404,-4.962388980384702 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark03(-50.056011817728745,-3.339403113205697E-5 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark03(-50.05687290093222,1.5707963267948972 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark03(-50.070932593938664,49.2145438144143 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark03(-50.07872541313023,-54.31017695449969 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark03(-50.129452026634745,-0.2918655432741198 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark03(-50.19141467758512,79.6483249457601 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark03(-50.20574312132441,0.09275253461746068 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark03(-50.252961042089254,6.85977108266112 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark03(-50.2650422631897,-4.712829174631704 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark03(-50.265480904242416,4.743638980384711 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark03(-50.26548245743661,-23.561944888827597 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark03(50.26548245759191,-1.5707963267948977 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark03(-50.265482461109585,26.703418849478698 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark03(50.265482491318664,-1.570796326794897 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark03(50.26548319726468,0 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark03(-50.307680134830534,-52.62872746011426 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark03(-50.30772506003803,67.50199944957922 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark03(50.30832729282761,17.719177180918592 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark03(50.35081202184918,76.29655027280262 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark03(-50.42041755620134,-20.917867287736343 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark03(-50.464496820394665,38.44787332622849 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark03(-50.470219282369634,74.74653951126481 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark03(50.47263034396569,1.5707963267948966 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark03(-50.52764661653486,15.768836998820376 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark03(-50.57402430717333,14.22523081433296 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark03(50.59391554101276,1.5707963267948963 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark03(-5.065403700599291,-31.768941256112534 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark03(-5.068563813051227,57.86832780160472 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark03(-50.727033114660436,86.70772787384065 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark03(-50.73349024878746,-14.885140459583553 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark03(50.82947402951534,42.73776879887594 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark03(-50.91818442061109,-2592.257023645253 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark03(-50.96081536969971,-27.39887046777626 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark03(-50.966928806184654,0.0 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark03(51.09085484019353,85.015469378057 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark03(51.17121712131788,-52.76217277574815 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark03(-51.1809570921367,-1.5707963267948966 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark03(-51.20635502664674,-97.77408237696103 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark03(51.231431396591944,-0.27314486504296204 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark03(51.23380058632898,-32.912358729510146 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark03(51.24640224298887,-46.99840086735219 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark03(-51.25199935791229,1.5707963267948983 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark03(-51.30378804132515,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark03(-51.34959750678263,1.5707963267948966 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark03(-51.39243368003479,10.267620905227233 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark03(-51.39424425025127,59.68629810526073 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark03(-5.141592653590111,-45.16169937002135 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark03(-5.143993117090416,-0.4094876275266658 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark03(51.445887824064044,32.06642371901634 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark03(51.483669918226354,-65.22342907747168 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark03(51.571155924616164,-1.5707963267948966 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark03(-51.58518705613707,-12.25884299231036 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark03(-51.60458069345704,76.83621394006644 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark03(51.65174249614671,0 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark03(-51.66829404199505,-78.83704020037379 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark03(51.704406450651106,43.398386899796975 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark03(-51.71158132848206,4.515129675469959 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark03(51.81056272677708,-44.80397033385941 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark03(-51.86360448192574,1.5707963267948966 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark03(-51.87213594249304,6.477891068290341 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark03(-52.04485938350529,2601.5664641536064 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark03(-52.04911119353011,-4.4480365206661965 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark03(52.1279597670505,-61.27101652689302 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark03(52.15549232040245,-0.3192135361708637 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark03(-52.161331842179,0.0 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark03(-5.225725841985991,46.17094110303745 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark03(52.291524455228966,-27.80565045218843 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark03(52.314733079348066,-0.1779292034395915 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark03(-52.36618997235585,0.0 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark03(-52.73078224698379,8.530274498017175 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark03(-52.82934229460464,-34.99955460616364 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark03(-52.99818843280012,-10.586687609337911 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark03(-53.041460898680654,10.74896444724385 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark03(-5.308707162359212,57.58662681496156 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark03(-53.352047930434196,-71.19399960441295 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark03(-53.35262148532596,-2.0707963267948992 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark03(-5.3369726517483045,-1.5707963267948966 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark03(53.407075111018216,-1.5707963267866272 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark03(-53.40707511102643,1.5707963267948966 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark03(-53.40707511150907,-1.5707963267948983 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark03(-53.40707701838153,67.54424102064525 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark03(-53.43554208593622,-7.655287233850984 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark03(-53.60744249093279,-39.06954078996611 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark03(-53.647988629636686,0.0 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark03(-53.747128570348025,-2624.55201271077 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark03(-53.898575911187784,-9.656430577693726 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark03(-54.070928801665204,-79.56092938466594 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark03(-54.19990217151756,-75.27436990702074 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark03(-54.20351977384756,53.22013784739937 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark03(-54.376016043797,94.99014864999518 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark03(-54.64996005418193,-2.135788815841736E-5 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark03(5.475249422415203,0 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark03(-54.82357653105729,0.5707215139841538 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark03(-54.98144638872999,14.429212241332557 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark03(-54.98155617475334,-0.676167129523999 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark03(-54.98500034384759,-73.28240611406903 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark03(-54.989357060028524,21.835843299243535 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark03(-55.09387866536376,6.708385300210651 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark03(-55.127296173326606,-41.79155878653762 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark03(-55.20640856377463,34.10321100708114 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark03(-55.20856155266243,-4.588973583298767 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark03(-55.21532046797283,-4.712388992734 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark03(-55.22819017749461,37.94943058275075 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark03(-55.278528146094544,-0.3006567082731624 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark03(-55.2867700797789,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark03(-55.357720409813396,1.5707963267948983 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark03(-55.374401984253566,-18.56483782697822 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark03(-55.391046286023595,37.28593699487531 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark03(-55.399277115083976,42.06044630806929 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark03(-55.44679921688163,-1.5707963267948966 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark03(-55.456676684290386,0 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark03(-55.51142932796418,1.379435024259827 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark03(-55.531552788773915,-63.20505258605411 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark03(-55.537613829511905,-56.0666850521605 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark03(-55.547881538931804,59.847398212661794 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark03(-55.64496656317903,66.52167507366914 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark03(-55.66987552244029,44.52520075807408 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark03(5.581395877437174,0 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark03(-56.05179506445626,9.297292317621057 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark03(-56.18015280756885,-35.345765721167055 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark03(-56.21262458735612,76.00183251715663 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark03(-56.22754522261139,-0.39199989698512816 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark03(-56.261914627454175,0.10265681118726974 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark03(-56.27934466367689,-99.22949168901788 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark03(-56.30607710946228,72.67512716087771 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark03(-56.31242328136919,0.009273054137955868 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark03(-56.32074368386725,-104.44987328405414 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark03(-56.398894098127215,0.0 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark03(-5.643627980210653,1.5707963267948966 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark03(-5.645958089067776,64.32346973275781 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark03(-56.46556949350426,-1.5707963267949054 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark03(-56.46775950358656,-11.738076242853907 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark03(-56.479216790411854,-9.15382406984422 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark03(5.65021285756257E-10,-2536.1642011951003 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark03(-56.54138711121511,-2501.7373512344925 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark03(-56.54866756426181,-67.54424093523963 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark03(-56.54866770624759,-67.5442420521497 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark03(-56.54866776460006,45.553093613572315 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark03(-56.54866776461627,-1.5707963267949 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark03(-56.5486682602879,-0.555001221732467 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark03(56.548680561024945,-1.5707963267948966 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark03(-56.54869828219441,1.5707963267948957 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark03(56.55257401461641,61.2610469135349 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark03(56.55757455917625,-1.5618895322349222 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark03(56.574015365180784,4.7436389803846915 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark03(56.68298507810212,0.9203516953956513 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark03(56.69992658648693,1.5707963267948966 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark03(56.719830084085814,168.8999339487944 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark03(-56.724971227354146,-2473.6053080829533 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark03(56.81140323739367,1.5707972114643474 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark03(-57.022496309136294,117.56130861372299 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark03(-57.04029109841589,0.0 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark03(-57.04044279106406,1.5707963267948968 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark03(57.05580487328726,1.5707963267948966 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark03(-57.15411406662858,79.50516636452743 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark03(57.210914044518425,77.32224754844935 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark03(57.216727665478686,0 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark03(-57.22648845997989,-44.025576778755976 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark03(-57.24536119041692,0.007737016389618052 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark03(57.2724256559635,68.28374527891052 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark03(57.34482797528999,-1.5707963267948966 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark03(-57.3721238178325,0.0 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark03(57.417440388778545,1.5707963267948966 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark03(57.4655931658566,0.0 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark03(-5.752162246530478,-2583.7027457354993 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark03(5.754926466214009,67.01490667470719 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark03(57.566414850625016,-0.43014253909964606 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark03(-57.674100284706704,-9.87014176747385 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark03(-57.72586651822997,-58.33055128049922 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark03(-57.752573255796754,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark03(-57.768163018676866,95.09164078689034 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark03(-57.798886328583,0.0 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark03(-57.82471120408126,-0.5701495985981865 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark03(-57.888542508721216,52.59132426365298 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark03(-5.791577554665898,9.916385713283068 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark03(-57.92553500249636,4.743985001228509 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark03(-57.981297769723724,89.58976406099201 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark03(-58.00108196713596,107.85421126702553 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark03(58.21817726343757,-0.09871317202639258 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark03(-58.27994599200151,-1.5707963267948966 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark03(-58.35781995580158,-1.5707963267948966 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark03(58.46191700055324,-98.1239551646131 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark03(-58.55657098613487,0 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark03(-58.626093100631515,81.39516825111855 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark03(58.68906544776311,-0.2976054428296273 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark03(-58.69542142575044,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark03(-58.73381059736133,1.5707963267948966 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark03(59.25090356649753,-1.5707963267948966 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark03(-59.543236664616,0.0 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark03(-59.68734442628255,1.5707963267932887 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark03(-59.69024857549553,14.43068794281929 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark03(-59.69026041820608,0 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark03(-59.69416666820614,1.5707963267948966 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark03(-59.79673117373956,3.552713678800501E-15 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark03(-59.83884449773021,16.049582941163806 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark03(-59.908467203455615,0 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark03(-59.91327695308927,32.8120033532002 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark03(-59.91831442381148,-17.37688360980694 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark03(-59.937091374526105,1.5707963267948966 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark03(-59.974468601261115,-0.1979195770604526 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark03(-60.08276723070291,-1.202160062965277 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark03(-60.13602722988259,0.04386380898789317 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark03(-60.14730432236351,1.110809826084674 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark03(-60.14854562321483,89.50356277337409 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark03(-60.348489554977,0 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark03(-60.38304362945438,10.995574287564276 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark03(-60.52033215586987,61.88715313065644 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark03(-60.85657173629269,30.48175419783113 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark03(-60.91615349932317,72.8820535117689 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark03(-60.95687438369395,-95.62309350616059 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark03(-60.99932640348898,1.5707963267948966 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark03(-61.12886614124001,88.09678490427517 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark03(6.123233995736766E-17,-1.5707963267948966 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark03(6.123233995736766E-17,1.5707963267948966 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark03(-6.123620489232182,-26.543972737565838 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark03(-61.26105674500568,1.0102707116644178E-12 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark03(-61.3539168434274,0.7320742855254452 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark03(-6.139630976081506,1.4272419956968159 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark03(-61.58931039177279,-95.81443587257006 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark03(-61.73677141416909,-2573.227941079352 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark03(-61.95996504599003,1.5707963267948966 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark03(-62.15388884103212,19.77014328778428 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark03(-62.23606324209288,-6.923906117506967 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark03(6.226839297323668E-17,98.96016858807776 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark03(-62.4145513442227,0 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark03(-62.623978611424924,12.377188481349364 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark03(-62.68524732223357,96.33438043585409 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark03(-62.8318530717955,1.5707963267948966 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark03(-62.831853071795784,-17.278759591854705 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark03(-6.283185307179591,-1.5707963267948966 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark03(-62.83185307181042,174.35859473913033 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark03(62.83209721242087,-1.5707963267948966 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark03(-62.83292200642543,0.0 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark03(6.284161869679709,-1.5707963267948912 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark03(62.843373463093855,31.737539045123448 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark03(62.844668288931985,-1.5707963267948983 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark03(62.85125439976798,-19.351617220829393 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark03(6.286688147668697,0.8949865984506813 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark03(-6.287096840259828,155.50761234412138 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark03(-6.2871165662644,1.5707963267948966 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark03(62.89517591892328,-4.837388980384691 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark03(63.08568740360661,58.33208444542023 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark03(-6.314435307179588,158.6772839867715 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark03(6.315490610553218,-155.54031846421097 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark03(63.178077458276384,29.756232368819 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark03(-63.22388866357174,4.339500168232547 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark03(63.35787284397438,85.20661921518536 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark03(-63.369513383738266,0 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark03(-6.3456853074586625,54.92140219954583 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark03(63.475486088776876,11.782484071001704 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark03(63.55752255976052,-67.68801592916252 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark03(-63.56728856400909,-0.530470142973488 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark03(63.70460653323448,0 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark03(63.76050791655314,0 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark03(-63.77471229380565,45.25365416342578 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark03(-63.782944546781756,0.0 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark03(63.82376917003808,25.828088511421996 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark03(63.89412758448768,0.0 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark03(-63.98538531274983,-6.856727521174187 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark03(-64.0268830203002,-72.63130055465506 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark03(-64.08482309658424,-11.785300596973187 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark03(64.1946897583962,41.41508210313745 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark03(64.232516172201,-68.42578966190972 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark03(-64.24837480484936,54.977871437824916 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark03(64.27401315592061,39.73652273238574 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark03(64.29130723189655,-69.84204029842354 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark03(-64.35088189341508,28.32610138748382 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark03(64.36286308769269,49.69892735602893 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark03(-64.37405278736776,-71.7634187500635 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark03(-64.53831169547504,38.93628802076654 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark03(-64.61522814285574,-88.25809682936318 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark03(-64.67105070696635,85.69953281995748 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark03(-6.469085940781127,-18.04417443317326 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark03(-64.8937832245148,1.5707963267948968 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark03(-64.91092254881279,0.0 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark03(-64.92837020068654,6.42953626931373 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark03(64.93928457303181,0.0 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark03(64.93981454176291,-1.5707963267948966 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark03(64.94356150874367,-97.8388832652771 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark03(-64.9539371621024,-122.55199956872575 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark03(64.96581071197384,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark03(-64.96694897196444,39.20935460080357 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark03(-65.0021721206654,-61.947093594846095 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark03(-65.10231021225003,4.2386772295461554 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark03(-6.533185307179587,30.65783096269061 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark03(6.533185307179587,70.45619874722034 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark03(6.533185307179588,-51.7019099364826 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark03(-6.533185307179598,73.74445685075968 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark03(6.533185307179716,-45.45379472125909 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark03(-6.533185307461988,-186.82270215462958 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark03(6.533190029009034,95.63377152108559 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark03(6.534821513854168,-11.156870340436484 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark03(-65.3828861221622,0 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark03(6.539677744595835,93.2208205461562 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark03(6.550078599276084,5.2123890509303115 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark03(-6.5551659082205616,-1.8427769278358717 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark03(65.55434033477155,-38.66248647345847 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark03(-65.65820872901668,-3.802407300472918 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark03(-65.65938470108094,24.582505969160295 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark03(65.6829968667549,-4.426188086265361 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark03(65.86748052351297,0 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark03(-65.9734456772833,76.96902001294927 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark03(-65.97344572535395,268.60725615328477 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark03(-65.97344572538564,73.84305280576459 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark03(-65.97344596609818,-17.27875959468498 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark03(-66.01152292841668,-4.837404847805963 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark03(-66.07697416073566,86.74059731365608 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark03(-66.18798695364383,-28.28110678589107 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark03(-6.619881780053433,-21.06819064128871 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark03(-6.620647120455054,123.75544800352137 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark03(-6.636148187472078,21.32037839419452 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark03(-66.42627152911513,-1.5707963267948968 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark03(-66.54113968611861,0.0 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark03(6.656594364103026,-14.577573796065337 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark03(-66.61776392593173,62.289519665098226 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark03(-6.662168130669073,-47.44003426497816 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark03(-66.76114983122979,-38.48220406402829 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark03(-66.78983396144751,76.15263177688809 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark03(-66.79820637544577,1.5707963267949019 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark03(-67.06297608084574,-27.981950321238287 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark03(-67.08509484097121,13.226789998931736 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark03(6.708949656714997,136.6260204892657 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark03(-67.25789382717704,98.87595996737952 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark03(-6.734982426880379,13.720850647794052 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark03(-67.36328230926725,-89.75439992939468 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark03(-67.36379465239112,-0.05091627829223176 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark03(6.73705244364173,-70.13780439563256 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark03(-6.764795260591071,-79.62900271312843 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark03(-67.67611769623048,-26.041023511612906 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark03(6.775209133227472E-21,1.5707963267948968 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark03(6.776263578034403E-21,-1.5717728893373775 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark03(-68.11142656241165,11.593754258119105 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark03(6.836129918993105,-1.5707963267948968 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark03(-6.841337844149026,1.5707963267948966 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark03(-6.849806402377772,-98.3935474928803 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark03(6.856994728326508,-19.846542827186735 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark03(-68.83594507584573,4.99153291001627 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark03(-6.898843842988324,98.73725364769828 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark03(-69.11504602457491,1.5707963267948966 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark03(69.11699150688489,-17.27875944464465 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark03(-69.1215568687692,-68.24719471308538 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark03(-69.1276316481058,0 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark03(-69.14963973684303,-40.462965003759344 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark03(-69.15140545495649,1.570796326794897 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark03(-69.23379864813545,1.5707963267948968 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark03(-69.29257413779833,59.30150063577949 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark03(69.31568244710718,-0.38775473853392356 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark03(69.32356807771049,100.0 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark03(6.938893903907228E-18,-1.3279220885518146 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark03(-6.938893903907228E-18,-1.5707963267948963 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark03(69.41620058262411,11.00165176779607 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark03(-69.50508724190695,-157.29435349618805 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark03(-69.56399352388611,-81.20184081324213 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark03(-69.57062442746108,-73.50252946598565 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark03(69.61270659172197,69.5306493428015 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark03(69.64930732503163,53.12302890041053 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark03(-69.65586316652994,4.440892098500626E-16 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark03(-69.74157175671266,99.44575247888997 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark03(69.75307206091185,-52.69147634942622 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark03(-69.82061894648577,-2.276376894305211 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark03(-69.93363882031997,118.73165797397397 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark03(69.98340743436523,51.725936463198934 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark03(-70.11892876156497,-0.12629977620492916 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark03(70.18276310025793,-7.23469329692449 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark03(70.2844049758699,-18.448126191638316 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark03(-70.49774281544137,-2609.989738979624 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark03(-70.63016059450622,-91.29189728549947 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark03(-70.63903552589272,44.52733781129522 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark03(-70.65379385863804,-67.36131118646331 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark03(-7.074663001384766,3.921326582678004 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark03(-70.90114840991228,71.0200833208613 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark03(-70.97660000996822,-128.60385036454903 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark03(7.099111361661985,111.52693289833869 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark03(-71.0015608073569,-4.04120934969356 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark03(-71.00336305181436,11.736104255568756 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark03(-7.105427357601002E-15,-100.0 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark03(-7.105427357601002E-15,59.47220451263699 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark03(-71.22753951039317,-1.5707963267948966 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark03(-71.27482067617264,-34.58025403412752 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark03(-71.37634915420657,116.4137062441246 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark03(-7.1579373642290225,0.0 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark03(71.7776373526764,-1.5707963267948966 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark03(-71.83237548318968,71.59257609687916 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark03(72.00263339954452,0 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark03(-72.08956388672567,-55.80826350538859 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark03(-72.17379388929031,77.54823907790362 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark03(-72.2566173393722,-158.55822971706272 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark03(-72.25663103256522,1.5707963267948948 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark03(-72.25663103256522,-1.5707963267948966 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark03(-72.25663103256522,-51.83627824072616 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark03(-72.2588283152048,-72.2480616100032 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark03(-72.25915210800018,0.0 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark03(-72.28276350125311,14.773977764829667 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark03(7.229637648724066,1.5707963267948966 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark03(72.31558843906919,85.49792418751358 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark03(-72.31663998615568,-80.25978940193093 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark03(-72.35949183334493,9.734229662945882 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark03(-72.37676760309377,5.53205865520442 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark03(-72.381631032563,11.120574287607946 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark03(7.255477423624888,-19.448060131888354 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark03(7.263296053656889,39.69385286147163 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark03(-72.75859671326205,45.34079644509167 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark03(-72.76005372824127,93.30733207161357 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark03(-72.76982659375332,22.867716500366825 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark03(-72.77173609912406,-80.21926523487149 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark03(-72.78954529419832,0.9463685450906478 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark03(-7.308072096378697,22.53705811272434 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark03(-73.115277004009,-0.8579801051995527 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark03(-73.17145365345168,-8.233726339967305 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark03(-73.37841772037443,0 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark03(-73.40601716105493,-0.4214101983052077 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark03(-7.346839692639297E-40,45.5530934760455 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark03(-73.55839946110656,23.52229591526782 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark03(-73.69998951217596,1.188949053072658E-6 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark03(7.373253417083504,-0.5495681161365163 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark03(-7.375552056304116,46.74481701552962 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark03(-73.81785129613556,-2616.71898054056 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark03(-73.82742735936516,0.0 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark03(-73.91100585335042,89.30521934185614 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark03(-74.26115572658097,-0.4445105579766341 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark03(7.432502832659864,-1.5707963267948983 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark03(7.448470949578919,63.63462154169221 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark03(-74.64247662826891,19.144556405934594 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark03(-74.70840487718445,1.5707963267948966 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark03(-74.72485569689059,-1.9569689710185827 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark03(-75.00817177694529,-9.083128718382568 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark03(-75.24005736771933,-73.84057483025096 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark03(-75.32233052681033,1.5707963267948974 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark03(-75.39822368613815,1.5707963267780112 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark03(-75.3983457564678,0.0 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark03(75.39926369672938,-4.712388834003758 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark03(-75.40213012665382,23.561975524701992 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark03(75.45824725495858,-0.11212099523861137 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark03(75.46976970181782,-34.06268388567146 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark03(-75.48016074127716,0.9661128201745601 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark03(75.48283056710841,1.05251140650154 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark03(75.48880496530421,-53.034242815741564 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark03(-75.52861230873013,0.0 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark03(-75.60083739506318,1.5707963267948966 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark03(-7.566300828162554,0.0 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark03(7.572498500762606,-47.99209913757143 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark03(75.77210034790154,80.48448932828623 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark03(-75.78178150603618,-4.621318578256677 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark03(-75.79313202696284,-57.79120772167214 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark03(75.79344326908173,-138.9967897038853 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark03(-75.79432796416913,0.0 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark03(75.91028150048483,-0.2881993285039971 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark03(-75.95363476866447,140.8831523816165 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark03(-75.95363612322572,86.92534959843226 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark03(-76.050806857269,0 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark03(-76.07683142045838,0.0 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark03(76.0830618616557,44.4522210423356 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark03(-76.09849246816339,66.24486714547038 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark03(76.13350818447486,-2582.5056592208425 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark03(76.1556689009646,-2.649930793895294 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark03(-7.618834208268326,40.605557070961154 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark03(-76.1946570298197,64.86976146661821 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark03(76.26492771251873,1.5707963267948966 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark03(76.41127989356872,0 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark03(76.4439693186035,-2598.4177391595363 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark03(-76.5346874221114,8.99044536993085 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark03(-76.5704537925872,79.55355977907095 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark03(76.65032053882709,56.29000824563735 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark03(7.665114958022779,-1.5707963267948966 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark03(-76.69749841314741,1.4810930676485323 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark03(7.669884002880468,-81.49731136224061 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark03(76.72321459563624,31.661731953211632 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark03(-76.73658979682367,-135.12938628342295 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark03(76.73866084178393,31.65791818095078 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark03(-76.75692378178671,-76.86080950046748 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark03(7.679925728188401,81.8554648991207 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark03(-76.82868898367477,-63.33370835663792 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark03(76.86660948321556,107.28698007383585 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark03(-76.92879885687893,1.5707963267948966 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark03(76.9690200129676,0.0 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark03(-77.01408809735135,0.0 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark03(77.01494312553109,72.20407242999784 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark03(77.01930912230253,-16.689792978622954 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark03(-7.703719777548943E-34,1.570796326794843 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark03(-7.703719777548943E-34,-32.98672286269282 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark03(-77.05753118981495,-3.053081476724775 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark03(-77.06129114929823,-53.49934624737478 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark03(77.06305916249471,90.88335961235629 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark03(77.07827701815903,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark03(-77.15966449960739,0.0 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark03(-77.1930503295821,10.680293664124633 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark03(-77.23283813419148,28.01807167751288 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark03(77.24227839646043,-25.405999612228847 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark03(77.24679177483523,31.69369829778323 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark03(-77.2622843836856,0.0 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark03(-77.26814067588732,-24.64350125471715 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark03(77.27114662970313,-29.5144405715549 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark03(77.27206548113055,18.54651045335814 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark03(77.31501185030474,-44.55060658394276 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark03(-77.3261823413088,0 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark03(77.35345672258484,-55.8913463655197 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark03(77.37351007145202,-112.62607794189708 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark03(-77.37684420821095,1.5707963267948966 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark03(77.38962883349649,-28.130421131390303 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark03(-77.39225933646745,-47.37508793373647 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark03(77.39996670297775,2.895659788010336E-4 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark03(-77.46137961271636,72.5141874949968 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark03(77.47126749994823,68.61279089197716 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark03(77.47337090280918,-23.733498227026416 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark03(7.747490766183757E-10,-142.94245988298243 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark03(77.50182746985622,0.0 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark03(-77.50751559149907,77.94408676533949 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark03(-77.53281987441419,29.588817336432925 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark03(-77.53626290963915,-33.99027629279851 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark03(-77.717073112314,9.97105369538993 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark03(-77.77485217189775,2.570796326794906 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark03(-77.83686965407674,57.15423747587201 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark03(-77.88854266301625,100.0 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark03(-77.9748014674314,88.11580629554007 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark03(77.98850246611119,-70.27498323523898 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark03(77.9940073083124,-50.55946915423568 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark03(78.0042532789642,-46.83876402750948 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark03(78.04579744367575,-1.5707963267948948 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark03(78.0476656548926,30.43741874740931 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark03(78.10313100250318,-2614.7704347369477 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark03(78.123128291142,67.26791495279284 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark03(78.1281951838097,54.69788005333086 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark03(-78.12915813121938,-30.868921679691937 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark03(-78.13207831116674,122.60332899783953 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark03(78.15943288345557,-81.6344547038451 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark03(78.22319399872057,-1.0737417897761539 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark03(78.25426330308389,-27.25353358130252 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark03(78.27354659513381,1.570796326795007 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark03(78.33068557356509,-1.5707963267948966 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark03(78.34382773501468,47.6180376100223 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark03(78.37203947805283,-2.6853601086842978 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark03(78.37329030975994,32.98672286269283 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark03(7.838560452265966,-90.31565846865992 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark03(-78.39969112222485,-71.90188075276427 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark03(-78.45519965421745,-1.5707963267948966 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark03(-78.51007344593982,1.6332963268575673 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark03(78.53980930986091,-36.128315516182596 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark03(78.5398163177915,-73.82742732531396 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark03(-78.53981633867063,1.570796264746536 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark03(-78.53981633974293,1.5707963267968006 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark03(78.53981633974482,-1.5707963267948828 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark03(78.53981633974482,-17.278738747624814 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark03(7.853981633974483,-1.5707963267948966 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark03(7.853981633974483,1.5707963267948966 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark03(7.853981633974483,66.01432456680276 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark03(7.853981633974483,-68.85650031263218 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark03(-78.53981633974506,-23.561944846533013 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark03(7.853981633977193,44.21470786923059 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark03(7.853981633977367,4.09567409270701E-31 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark03(7.8539816339829205,-82.9877215516826 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark03(-78.53982679458342,-1.5707963267948966 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark03(-78.53987737490111,-1.5707963267948966 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark03(-78.53987737492311,146.09195778452718 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark03(-78.54030462099483,42.411485572101775 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark03(7.855277633267654,-0.04792539437488727 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark03(7.855902388976989,2426.4153379698123 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark03(-78.57211864817124,94.36192834123185 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark03(-78.7437033777314,-82.84882133706674 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark03(-78.75534903436971,127.19944858956916 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark03(-78.77046564636163,2541.4957611003106 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark03(-78.88248308914474,-32.412905077546604 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark03(-78.94952434039773,0.0 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark03(-78.96309976538096,-14.473218661441052 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark03(-79.0569787152067,0 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark03(-79.35000165103129,0.0 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark03(-79.36866293425173,90.75188404121458 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark03(-79.478822528671,-59.51171944897171 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark03(-79.6431338839061,12.726042105184405 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark03(-79.68526368111569,0.4253489854240419 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark03(-79.84241783265213,70.8734187913625 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark03(-80.2000680478941,-1.5707963267948966 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark03(-80.36526017981998,-19.309949075236446 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark03(-80.37281041413638,-0.013568769241478257 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark03(-80.60248844593079,0.17876040466113752 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark03(-80.65818602384249,0.547573357302762 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark03(-80.72297805353473,-1.5707963267948948 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark03(-8.107432166877564,-37.97163658369591 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark03(8.121050340069273,1.5707963267948966 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark03(-81.43157107683272,-42.948317071635444 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark03(-8.144903164877022,-69.16871836991248 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark03(-81.46658395254383,0.4330953744457956 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark03(-8.157183300673282,-1.5707963267948966 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark03(-81.64873206171815,73.31576301008036 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark03(-81.68140899169873,29.845130209096904 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark03(81.68140899333461,1.5707963267948966 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark03(81.68144102438629,1.5707963267948966 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark03(-81.68539439579921,85.35326239799741 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark03(81.68922149333824,-1.5707963267948966 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark03(81.70965123153047,-7.011555967818755 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark03(8.171499578470048,0.0 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark03(-81.72951104249441,61.35289193647826 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark03(-81.74390899333463,-1.5707963267948966 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark03(-81.78680410900178,31.858570399968414 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark03(-81.78815041939127,77.9827170177418 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark03(-81.7968999881382,-0.5527845088827332 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark03(-8.190190666661682,0.0 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark03(81.94360361466744,0.0 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark03(-81.9835484914061,-53.8639601216024 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark03(82.08246182162904,-52.79752070806869 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark03(-82.08712931360505,-2.3514046830441424E-8 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark03(-82.09157316229198,2.145837295795167 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark03(-82.17887980947071,3.621772441321454 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark03(82.17901253814405,-101.60415769685885 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark03(-8.219119183734307,-73.43563963094834 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark03(-8.233142734989968,83.59311695044877 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark03(-82.43273840052015,24.74754457161525 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark03(-82.46809761950252,0.3469058053416876 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark03(82.47704502267814,72.53116246523444 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark03(8.249564871531419,0.0 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark03(-82.55503067525984,-47.21931743681607 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark03(8.256457030072951,8.544545685881788 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark03(8.260708940720303,-14.17083839632825 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark03(82.67589178406884,-32.57145972874849 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark03(-82.67875096840814,-5.679958309041552 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark03(82.7007322104862,0.0 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark03(-8.280475260110748,0.0 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark03(82.81270973960207,-0.20451803349057723 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark03(82.8341401701216,-44.58749796343871 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark03(82.86819371945795,0.0 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark03(82.87126993320786,-36.59806374438893 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark03(-8.291295626946543,60.73587619246411 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark03(82.9471810348521,22.906469021702065 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark03(83.02620785344709,-0.49996596239666685 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark03(-83.03284428313329,0.0 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark03(-83.03885280252761,-0.26788073905049103 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark03(8.304837830273,16.829996261885988 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark03(-8.308301657492137,-68.31907461139116 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark03(-83.13631614415364,1.5707963267948966 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark03(-83.16330427941327,-9.757991231315444 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark03(83.17795223273798,0.03970497269874935 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark03(-83.17893052312817,-15.781238064950312 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark03(-83.18559222422095,-21.764620590808974 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark03(83.21486947287161,48.536163707668074 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark03(83.21678751301513,-1.570796326794897 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark03(83.24396310038239,0.0 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark03(83.252205320127,0.0 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark03(83.25528913173137,-36.57567887070876 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark03(83.26745832959764,-1.5707963267948974 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark03(83.35144612264168,0.0 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark03(-83.3810102399498,-62.48538012381422 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark03(83.42515997154236,0.0 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark03(83.42919922675242,-1.5707963267948961 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark03(83.45492735004575,-31.213204505981704 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark03(-83.47096855768214,-26.969815849192045 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark03(8.347677636597869,30.970318976986533 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark03(83.51368906364621,-18.84708007316847 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark03(-83.52179217378746,8.881784197001252E-16 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark03(-83.5452333814715,72.5359414363704 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark03(8.36015247545015,2453.884664360853 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark03(8.36680548829699,37.87990765563938 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark03(-83.75041074237579,-57.5077151571523 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark03(8.37523902757624,0.9606932714302348 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark03(8.375541332357827,-7.154625573038888 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark03(-8.386057200520916,-0.2500590702867017 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark03(8.390146868531275,0.0 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark03(-83.92099937088699,-0.022284237099818083 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark03(-83.9242859097479,-62.511964970815015 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark03(-8.397386490401887,134.64362029495177 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark03(-84.01998909128018,-9.492882238370246 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark03(-84.078219026884,0.0 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark03(84.08214493461603,37.986135625133414 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark03(84.18358038901059,26.03292195506684 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark03(-84.28666627906297,-1.5707963267948966 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark03(-84.30029398145457,-24.10682849177978 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark03(-84.31363924607278,123.39732033501866 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark03(84.31704354528351,-5.318296292067764 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark03(84.33153251185226,12.309141151475032 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark03(-84.34747790128404,-1.5707963267948968 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark03(84.39631367449455,0.6845470506905325 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark03(-84.4427767510843,-93.48614560032907 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark03(84.50462468300884,1.5707963267948966 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark03(84.51037913358113,1.5707963267949125 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark03(-84.55027987341866,17.006037821238106 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark03(84.57126072047247,1.5707963267948968 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark03(84.6103494556076,-21.13861288356442 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark03(-84.65762616261388,2583.0988369547817 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark03(84.66543544254131,-5.212388980384691 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark03(84.69291648524978,12.535729866788614 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark03(-84.6956124122521,1.5707963267948841 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark03(84.74301688919667,7.514502031196685 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark03(84.76144510822633,2.6305619495340054 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark03(-84.76779628616353,1.5707963267948968 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark03(-84.77116979456396,0.04260998734251992 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark03(-84.79817775668153,0.0 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark03(84.80280082052356,-0.03471002805338357 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark03(84.80597032755878,-54.57783614086474 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark03(84.81521772166334,4.720172905719363 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark03(84.82268589202862,-4.743638980384691 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark03(84.8229430722892,11.185885849735456 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark03(84.82300164691932,186.9247628537884 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark03(-84.82300164692347,1.5707963267948966 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark03(-84.8230016469244,-1.5707963267948961 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark03(-84.8230390150848,4.712636800186647 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark03(-84.89769872946,71.3442397747308 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark03(-84.90070188505179,-29.973279230951675 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark03(-85.00764652768487,-24.308894219357484 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark03(-85.03774950509941,-7.84547926331804 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark03(-85.06317429994168,-27.193777909759508 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark03(-8.507072840228345E-31,0.5707963110795383 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark03(85.12625107373103,74.77040210802454 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark03(-85.23376959108694,23.972712846085972 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark03(-85.36278941358273,-42.46127334541204 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark03(-85.39542858197237,-1.5707963267948972 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark03(-8.541264146190784,6.959229456454594 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark03(-85.48819607858842,0.0 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark03(-85.59695713861004,94.29882524182992 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark03(8.560017614711965,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark03(8.583065647460757,66.90808018480215 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark03(-85.98933739335851,-0.5691522412455311 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark03(-85.99922775519673,0.0 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark03(-86.18725167430378,0.0 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark03(-86.30981380284489,1.137033246567377 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark03(-86.39379797371629,0.0 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark03(-86.42029524273418,-27.022851046188094 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark03(-86.43760538320234,2.220446049250313E-16 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark03(-8.673617379884035E-19,0 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark03(-86.74314116023632,92.2716862934324 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark03(-86.77531916135092,0.0 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark03(-86.77805063927329,-77.54292075693341 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark03(-87.3334294734376,48.161877609240406 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark03(-87.44247231910138,42.596843261164764 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark03(-87.6754887097622,0.4943880302382842 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark03(-8.767655455853472,1.5707963267948344 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark03(-87.68073993693076,1.5707963267948966 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark03(-87.96459430051428,-1.5707963267948963 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark03(87.96459430805632,-1.5707963267948966 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark03(-87.96937270216257,-76.96558879964388 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark03(-87.96974881206158,2505.022178439715 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark03(-8.802171495404695,3.7214266496724804 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark03(-88.06287765302937,64.57406929600137 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark03(-88.15088097319912,-0.24510393603858927 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark03(88.15463701733896,-75.1412392886583 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark03(-88.21201520430247,1.5707963267948966 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark03(88.28549832871857,-2685.4959555036326 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark03(88.2972821608595,-99.9275506673061 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark03(88.3289291567165,-1.5707963267948948 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark03(88.32963760269297,-83.90168535858878 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark03(88.33238937114356,0.0 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark03(88.33921057542977,-1.5707963267948966 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark03(88.34669369131632,50.305036011342736 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark03(88.36141631216759,-86.42485027148841 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark03(88.36170228093599,4.454665008198073 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark03(88.45960138210671,-15.566467404482687 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark03(88.52049998428603,0.0 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark03(-88.53129210481009,-22.99524709762757 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark03(-88.53413738468927,11.4614556898144 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark03(88.53902328734192,-35.058323902665634 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark03(88.54093678983611,-13.825646619413348 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark03(-88.56955431587257,-2693.3054298792204 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark03(88.61115675812661,87.48823325283558 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark03(88.68040792966389,60.534895590585904 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark03(88.72863011600113,38.86309564435999 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark03(88.78277403756448,-30.048270424813083 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark03(-8.881784197001252E-16,0.0 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark03(8.881784197001252E-16,-15.403606801110376 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark03(-8.881784197001252E-16,-1.5707963267948968 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark03(8.881784197001252E-16,-6.620818397133437 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark03(-8.881784197001252E-16,88.37292879215053 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark03(-88.83868115590597,42.41158956997206 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark03(-88.8669004187585,0 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark03(8.887080146002863E-16,83.25220913482805 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark03(88.89216245383173,0.48555037131244144 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark03(-88.91414102212993,-1.085579326531045 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark03(88.92257375788685,6.896002176601842 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark03(-88.95010480474926,-0.43612527459864053 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark03(-8.90049827176253,-65.97344572538566 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark03(-89.02710262017717,2611.07120315574 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark03(-89.0482374496373,100.0 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark03(89.12091993970591,46.09222478451528 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark03(-89.13965904106959,-74.43985440494569 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark03(-89.14418540578295,32.800473770997186 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark03(-89.16242588794172,-19.410831710943953 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark03(89.21483595510765,4.518062749648475 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark03(89.2972637295694,1.5707963267948968 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark03(-8.93939914484241,0.0026375400079280274 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark03(-89.42358878362904,70.87476085679617 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark03(89.42545692031405,161.6453546723661 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark03(89.4430250218511,-108.09484039183845 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark03(-89.5185138284581,79.62580940349082 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark03(89.53539044518159,-1.821280218671821E-7 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark03(89.53539062730896,1.369384325706602E-11 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark03(-89.58987799376766,0 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark03(-89.6297033076364,0.0 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark03(-89.65268317243904,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark03(-89.65702836668929,-59.56862267882589 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark03(89.6674692979029,-0.13207867059379072 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark03(89.70507287237551,-44.50992177984104 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark03(89.71598630062746,3.180018137558463 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark03(89.72084928194843,-15.707963267948966 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark03(89.72392507264564,1.2779783667239202 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark03(-89.74689549177572,-50.60553434320837 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark03(89.76292459444907,-0.22753396713996749 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark03(-89.77862183969452,-0.06218368499975653 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark03(89.81106772640484,-0.31085696348117653 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark03(-89.81634611060434,69.37112106034274 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark03(89.82615270890327,88.4727113336701 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark03(89.92618312653292,-1.5707963267948966 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark03(-89.95904046813644,-1.5707963267949054 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark03(-90.01262853439063,-2651.7643207444194 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark03(90.02272383325663,24.30798663059496 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark03(-90.02335174119598,19.306871322052416 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark03(-90.02949021754424,108.24445039649258 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark03(-90.17135207324161,-1.5707963267948968 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark03(-90.23219022119173,-11.45585054124627 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark03(-90.34400350880414,0.009360885208888064 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark03(90.37577614169848,-26.761367056138102 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark03(-9.046056114161928,53.835835254050544 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark03(90.48440382331614,-44.44210770224646 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark03(-90.50978238157299,-2672.960621476297 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark03(-90.5200982065544,1.5707963267949197 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark03(-90.53063001593165,99.87005592584646 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark03(-90.53578669525854,16.578215161154958 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark03(-90.54520717351198,-22.627104302788382 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark03(90.5489111622955,-44.14978768845244 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark03(-90.55154935736567,-95.81565937296878 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark03(-90.55805950980277,-100.0 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark03(90.61390127531273,-19.29788479290501 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark03(-9.062414824571164,9.221951720408333 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark03(-90.63583395819211,-1.5707963267948966 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark03(90.64151944859852,0.0 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark03(-90.67171583247652,-83.47928167237144 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark03(9.070331300575639,5.068837564638481 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark03(90.7354165328571,-2536.546057344937 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark03(-90.74490008529166,-159.72681824612968 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark03(-90.7683292265415,1.5707963267948968 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark03(90.81049412345446,0 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark03(-90.8113854864415,0.0 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark03(90.84329612787869,-31.90455946216295 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark03(-9.086398126506651,57.22762515622401 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark03(90.86495736005955,0 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark03(-90.90317821529155,1.5707963267948966 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark03(90.97787753563591,59.57024818741377 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark03(91.004716989814,14.429208125693258 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark03(91.01827935628634,83.22505324942985 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark03(91.02657224512407,4.55957095156159E-6 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark03(91.10613489131003,45.55333764415776 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark03(-91.10617784572418,-36.128437586703534 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark03(-91.10618664035583,-39.269907968565626 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark03(91.10618695410393,1.5707963267948966 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark03(-91.10625535009056,10.995574258274091 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark03(-91.106675235354,48.69468448475139 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark03(-91.14724702954227,44.3989072339556 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark03(-91.21319058129419,-11.706464573195937 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark03(-91.27020863972311,-55.236646869173775 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark03(-91.31975747924014,32.773152337556695 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark03(-91.3567938591747,-2.783458247126457 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark03(-91.9878635234936,67.0185358376086 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark03(92.07391991712743,84.32610380319863 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark03(-92.0838499112008,1.5707963267948966 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark03(-92.27738496773631,-31.815524849060523 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark03(-92.57386160265489,-28.942356400014035 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark03(-92.58802342235266,4.347045722625722 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark03(-92.71818121290964,6.150399253482082 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark03(-93.10595270201432,-56.11969834350086 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark03(93.8307586220183,5.203864063028902 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark03(-94.16293342621336,87.89210229914787 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark03(-94.24776762648435,-4.712400961594556 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark03(-94.24777759893345,98.96016457230883 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark03(-94.24777955469882,-36.12831506733023 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark03(-9.424777960769376,0.0 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark03(-94.24777960769377,-1.5707963267948966 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark03(-94.24777960769377,1.5717728893348066 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark03(-94.24777960815956,-1.5707963267948966 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark03(-94.24777962270508,1.5707963267948963 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark03(-9.424777964924312,1.5707963267948966 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark03(-9.424778079978745,-1.5707963267948966 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark03(94.31560455145211,-114.45880412997397 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark03(-94.3859364502531,0.0 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark03(-94.41952866639308,-67.88135933383602 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark03(94.44005819905533,-0.20779217619256624 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark03(-94.51754404501614,1.5707963267948735 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark03(-94.53530527844771,-75.63597389668442 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark03(94.57680958956288,-1.5707963267948966 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark03(-94.642408526511,-32.560111237586 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark03(94.6903909531782,1.5707963267948966 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark03(94.81794287596864,-33.89202068185668 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark03(9.505472414260037,98.9601228936274 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark03(95.18766436312343,-80.11061371031592 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark03(-95.22826894793262,-1.5707963267948912 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark03(95.24017631576018,2528.3239631700694 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark03(-95.2477796076884,-53.977871437710995 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark03(95.25412503375414,0.0 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark03(-95.26448878171777,-1.5707963267948966 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark03(-95.27195510775975,-87.9789756273555 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark03(-95.32153236326046,95.39311885500776 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark03(95.38953953954487,-100.10192851992956 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark03(-95.50304094005998,0.0 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark03(-95.57941296185068,0.0 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark03(95.60552851003408,0.0 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark03(-95.6782169112581,-1.5707963267948968 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark03(-95.71744074032412,-63.807652641962996 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark03(95.7616129351707,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark03(95.81428956536203,-1.5707963267948968 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark03(95.81673187575156,0.0018440587371913245 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark03(95.81886240049944,-0.0015249975756187195 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark03(-96.04220815092108,0.8297478750929789 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark03(-96.1217831662648,0 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark03(-96.13597837225653,-2.824190215821956 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark03(96.15643882058714,-28.42215369508527 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark03(9.629649721936179E-35,1.5707963267948977 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark03(-96.34097858040185,1.2567483699589828E-14 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark03(-96.69144985667042,81.75847716706036 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark03(97.08828227630067,0 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark03(-97.1987595473522,2.0707963271529652 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark03(-97.3893722609217,-1.5707963267948966 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark03(-97.39013045890569,45.55504660205234 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark03(-97.41370209193812,0.026764248867914453 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark03(-97.78228082764073,33.41151447390442 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark03(-97.78888825707905,-120.75002613564509 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark03(-97.90065507984616,54.46912030891096 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark03(-97.90208358395391,-86.90650929638963 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark03(-98.03902660879501,1.5707963267948966 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark03(-98.1820047046018,157.3509882220244 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark03(-98.25300746532002,0.0 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark03(-98.25365801700683,51.83627878423159 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark03(-98.47580170447753,0.0 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark03(-98.49068443692902,0.0 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark03(-98.5390868975552,0.014128390437265846 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark03(-9.860761315262648E-32,0.0 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark03(-98.62248486380719,98.06522964089689 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark03(-98.68238775579229,-1.5707963267950051 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark03(-98.71507929846555,-32.48485041723012 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark03(-98.71934150737091,-72.73861362543235 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark03(-98.94157373794185,-0.4004362123154698 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark03(-98.96016858807803,8.647527148398494E-13 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark03(-99.04645258578586,69.02875438126809 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark03(-99.12814148442988,37.867084739428904 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark03(-9.932931547806016,1.2170798421176804E-9 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark03(-99.48781446712077,-54.39637729805706 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark03(-99.49542721034068,0.7421730763428142 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark03(-99.50715765560912,1.5707963267948966 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark03(-99.51602898317059,-1.5707963267949054 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark03(-99.52040596675538,19.410400044575585 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark03(-99.52644946365243,-66.9931175643221 ) ;
  }
}
