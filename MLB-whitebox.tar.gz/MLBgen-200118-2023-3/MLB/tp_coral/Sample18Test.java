import org.junit.Test;

public class Sample18Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark18(0.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark18(-0.05116674384433395 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark18(-0.235757971522645 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark18(-0.25933885608100127 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark18(-0.35656863317634624 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark18(-0.3639159991136296 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark18(-0.390166520470018 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark18(-0.4975480495994429 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark18(-0.66286062681624 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark18(-0.6778931292527233 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark18(-0.695944277486916 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark18(-0.7071067811865476 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark18(-0.7294193228154029 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark18(-0.743593233896874 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark18(-0.7711587829710425 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark18(-0.7898829566119758 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark18(-0.8060222720885264 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark18(-0.8492478449745704 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark18(-0.8576696457075315 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark18(-0.8936412771141988 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark18(-0.9093205118510639 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark18(0.9187874643897994 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark18(-0.9476874825786297 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark18(-0.9535100056633504 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark18(-0.9567474419371678 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark18(-0.9706376253483359 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark18(-0.9832348241682798 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark18(-0.9875105115423344 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark18(-0.9935264266584767 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark18(-0.9976423402343784 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark18(-0.9986206445725228 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark18(-0.9995431156712772 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark18(-0.9996806805093854 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark18(-0.9997373422201865 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark18(0.999983821953501 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark18(-0.9999999999999938 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark18(-0.9999999999999957 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark18(-0.9999999999999996 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark18(0.9999999999999996 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark18(-0.9999999999999998 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark18(-1.0 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark18(1.0 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark18(-1.0000000000000004 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark18(-1.0000000000000018 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark18(-1.0000000051217601 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark18(-1.0000593607299775 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark18(-1.0004757087361011 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark18(-1.734723475976807E-18 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark18(-17.759095656111896 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark18(-20.38020188547813 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark18(-27.330725008256323 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark18(-29.089343394748866 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark18(-3.469446951953614E-18 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark18(-37.27740662154848 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark18(-4.6238505076077374E-12 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark18(-4.788829143402424 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark18(-5.403227209783267E-225 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark18(54.06208619338412 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark18(-60.65968715943948 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark18(-65.5284403159126 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark18(-79.75349424251183 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark18(-8.881784197001252E-16 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark18(-97.40963327703287 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark18(98.54528823600651 ) ;
  }
}
