import org.junit.Test;

public class Sample56Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark56(0,0.0,-0.011644971279579376,-23.868156716379602,67.03564075352764 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.002296195204531106,35.42573255562047,-34.34018480729341 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark56(0,0.0,-0.048634156471112466,-7.528673039682866,0.18813209704291678 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.01001740467168979,0.2244875059405308,-6.9972550152123745 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.012137336321421888,-2.360426708535684,51.84521710995355 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.013170244978576679,-34.138057275843856,43.53254408584208 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.014287356884037851,-40.284640354515815,57.498190034322526 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.016301381714498644,-52.989180638869136,71.2070614673001 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark56(0,0.0,-0.16330958574516302,-0.07493029168993044,20.963435365966806 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.017049309055258578,-23.736114572925022,0.06617748334374196 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.019370602342079726,-4.774343712108826,27.561685974613614 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.0214039406082306,-3.552713678800501E-15,-7.098916957580163E-15 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.03184685058056744,-1.966008844761248,3.552713678800501E-14 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.03277995352562013,-100.0,100.0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.03442472570860888,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.040060405537700516,34.80324111416692,-67.3582419503105 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.043431740120294465,0,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.04568304417971092,3.552713678800501E-15,0.0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.04851303743183161,42.744211215737096,-70.04019206205692 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.04895967426582892,-69.6566751400365,71.00832621904274 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.05377661899837401,1.5777218104420236E-30,3.0133719519608775 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.055567324061269366,2.0387339186584263E-112,-8.200532357869981E-143 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.05946517251217287,100.0,-2.552465472035223 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark56(0,0.01234495424340125,-1.4851865869064617E-16,12.076156980293426,-12.076156980293426 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark56(0,0.013758636306009764,-0.007381290547013947,80.67746974522106,-79.10667341842617 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark56(-0.006275565448524179,-92.47113794977876,-5.551115123125783E-17,-0.04471636154057279,35.12799952137468 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.7359727174591164,-1237.2563143017103,1255.0522022610483 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.8414406344269025,0,0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.9999999999999998,0,0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark56(-0.010558142590299647,-74.55917563449214,-6.102278282139237E-36,22.65795228589434,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark56(0.012450171233231833,-99.98184625590395,-0.01799940952973844,-32.30277191508204,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark56(0.015575868410351822,-2.134847434980479,-0.037372285313133795,-100.0,99.99999999945355 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-15.885377559117074,17.081329599702656,84.39674297755721 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-1853.155381974786,0,0 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark56(0,0.22012433574438933,-0.030755012948530558,-40.350738488430274,0.03892856452293403 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-2.220446049250313E-16,59.91414255593591,-43.458727495114566 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-2.465190328815662E-32,0,0 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-2629.3878514955604,0,0 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark56(0,-0.27342342267080966,-0.03200368814612697,-98.74088210266233,100.0 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark56(-0.028852744925817773,2.1411157519533113,-0.06072538154529725,-99.99874648561872,100.0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-35.08343378144218,0,0 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark56(0,0.37444049570353,-0.047554581721302225,0.004873344019973919,-318.8360140642475 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-4.440892098500626E-16,0,0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-4.930380657631324E-32,0,0 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-55.17237094768615,1.4646831493622727,-3.109401061989729 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark56(-0.06548953112692857,-3.1355273770246264,-6.064255066819957E-4,-9.786765130113054,94.79228721261214 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-7.155071348901188,0,0 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-7.610916780384919E-4,-74.50737471153691,-14.743851978195464 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-82.96692761923794,0,0 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark56(0,0,85.87709107753898,0,0 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-86.54693862269629,0,0 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-8.881784197001252E-16,1342.9071865313763,-1056.6794208263454 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-8.881784197001252E-16,14.985053642301036,-28.59442647926604 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-90.25017150359342,0,0 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-9.331538966024596,0,0 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.0012623371528962535,100.0,-98.5 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.00155706351516576,36.96808940242578,-80.84350627729201 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.002192294723160959,100.0,-99.19231714638813 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.0028431306335031025,0.545445803227416,-0.5454458003104179 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.008398768228760536,77.86415137187171,-79.36415137187171 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.010468408482895408,-100.0,100.0 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.01051508715201277,-21.789321341769874,21.7893213422516 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.011569934127230612,33.15851736870886,-34.621451738203405 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.013287081868774475,-9.511728648770033,11.011728648770033 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.016047164851650808,-86.67522295154751,77.25742735977718 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.017834975873050204,100.0,-100.0 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.01796071902577856,-100.0,98.43985953006522 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.018114220819037297,-0.07028379797054596,22.34933757354917 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.018324443336688034,2.859210027129155,-2.859210032434019 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.019136307522923002,-0.7105808183030806,2.2105808183030806 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.019873916177909845,-63.63663780105196,63.63663780105195 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.02134378610951577,-0.33893259019867233,4.634539056495399 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.021416830147054755,28.432321095617542,-26.861524768822648 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.021532603634889166,32.31815155692627,-37.279026496703636 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.022561347855128908,11.407956482569773,-0.4831785218003928 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.023172156202436345,-2.376438583747465,3.947234910542362 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.02466935118458975,22.701469560648217,-21.130673233853322 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.025561064548093093,-44.6497660063681,31.888701089193244 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.026684521193892363,89.229381044455,-91.93594122134733 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.028333966586615966,49.69653221841155,-48.125735891616635 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.029179079759941905,-25.86426061762041,24.44819430340736 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.030306671140695688,0.6937465930237349,-2.2645429198186315 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.030360191462302816,-23.982708227291376,25.553504554086274 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.0317239364675218,-4.692826092520105,59.670697530190026 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.03702676509516373,-7.692347719853276,7.692345878596431 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.037298569943528814,0.6186658534813825,0.9521304733135143 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.03914735229150969,-100.0,98.55284997176098 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.03966643296653896,1.0054440911602367,-1.5622910717812952 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.04032482474591609,-98.5,100.0 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.041140281160016556,-35.475143749233226,100.0 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.04394524764324098,-100.0,98.5 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.0445388521077249,98.5,-100.0 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.04798536068258025,23.280370689921966,-0.06747299464070657 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.04954774946986394,6.3226412834469485,-4.751844956652052 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.049968778895119366,-22.710041651162918,21.13924532436802 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.05065490040698149,100.0,-98.48910239129069 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.052172858760496856,-99.99999999999999,0.015707963267948967 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.052532709300973784,-4.863235319968787,3.2924389931738904 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.05357191295133923,-190.54021691762406,100.0 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.0544649755012362,-100.0,87.50303358841853 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.0551812588453557,-91.08068954670998,26.7427015751889 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.05523702627749871,-0.14869296764681977,4.2706324710733226 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.05580847914873989,-80.66354237921396,0.6237260423507167 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.057496100558136115,-6.136349120400183,4.6363490282349336 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.0580232850512622,-85.48448682546895,8.942675784342136 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.05918207847981025,13.721748190586766,-15.292544517381664 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.05974555395483608,-104.72355412780429,100.0 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.05983092135452732,1.286640389548545,-2.8574367163434418 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.06014513614070796,0.13078498588207446,-1.7015813126769725 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.06077167004773372,0.8441594835800288,-1.3288427596346524 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.09019347143517223,-10.436881873304802,7.3281834228291585 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.18528934534355773,99.51373687280801,-3.766811652298354 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.471160680890106,4.584470738430013,-4.558828414548341 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.5179289364745979,-7.134971500624124,7.12866128699259 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.613696563695947,70.64433729586682,-3.170918727992415 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.9999999999999993,-10.821866082493127,11.927537722823432 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.1102230246251565E-16,0.03545169444292405,-44.308074733178735 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.1102230246251565E-16,0.8707004611186591,-4.427089510330013 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.1102230246251565E-16,-0.9807706757282377,-0.590025651066659 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.1102230246251565E-16,-15.080153138512669,13.580153138512669 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.1102230246251565E-16,2.768394530026239,-4.268394530026239 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.1102230246251565E-16,36.57006646052911,-34.999270133734214 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.1102230246251565E-16,-52.622620383103225,100.0 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.1102230246251565E-16,67.1108571952725,-65.02231835679099 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.1102230246251565E-16,-75.76611333614258,74.26611220642629 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.1468396049732233E-12,-29.545808516804765,27.99738845423816 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.2167183039717217E-16,0.14038457785810765,-4.7819772314479 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.474657562093619E-16,0.04150144318537567,-1.612297769980272 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.734723475976807E-18,0.6239084472833148,15.106814829231132 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.989743791551767E-5,-98.5,100.0 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-2.7755575615628914E-17,100.0,-98.49653022898129 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-2.7755575615628914E-17,-20.439759424461656,81.07029218881988 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-2.7755575615628914E-17,4.030988824903339,-5.601785151698235 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-2.7755575615628914E-17,4.71717954526283,-4.71717954526283 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-2.7755575615628914E-17,-9.43675603621879,7.9367560362187906 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-2.7755575615628914E-17,95.90350826618278,-97.4035082661887 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-2.7756242653553138E-6,-100.0,99.99999987477344 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-3.944304526105059E-31,100.0,-99.99999999999999 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-4.7758303982166296E-17,0.04824976794980385,-32.55552085616367 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-5.551115123125783E-17,-11.668204975339131,8.446367078088963 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-5.551115123125783E-17,13.413505419357634,-11.842709092562734 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-5.551115123125783E-17,40.34807101445361,-11.783605199765447 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-5.551115123125783E-17,-87.93237782119614,86.43237782119614 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-5.551115123125783E-17,-98.5,100.0 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark56(0,-10.868388531182699,-2.7755575615628914E-17,-83.34418878789626,81.77339246110137 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark56(0,-109.37400806228338,-0.04752066695604876,104.03289029423365,-100.0 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark56(0,-11.010971870127918,-0.04243317882299463,-1.7213066106157298,0.6849489332630787 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark56(0,11.031973405694554,-0.05765263617934216,2.6359285109929527,-4.135928510992953 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark56(0,-11.55914724994906,-0.04410462196098358,-0.08810364168540519,15.674294251168817 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark56(0,-11.595407696129612,-0.032026819922833516,100.0,-99.99999999316552 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark56(0,-116.47934071251906,-0.12575192084897027,0.009265283298240303,-165.22575886389438 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark56(0,-11.773020102579029,-2.7755575615628914E-17,-32.483024824818514,0.023664951570821713 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark56(0,121.02308155804903,-0.0016241197116013486,98.49017969019744,-100.0 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark56(0,12.253092262299269,-0.008489385047146913,16.203811692499507,-17.70381168198445 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark56(0,-122.84162620013018,-0.018701226463262624,1.562781930035655,-22.217386509539168 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark56(0,12.329710324690112,-0.03944166222166251,44.550856384880575,-49.18310618788189 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark56(0,124.34391645747134,-0.05685204423624418,32.67254643015437,-67.23006561580655 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark56(0,-125.24848644682484,-0.04195872823492408,-52.25678914716996,32.312044712549934 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark56(0,-12.834835180544097,-0.030327946552589982,-0.0026929758519820997,458.90406155855646 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark56(0,-13.016143957094123,-5.551115123125783E-17,3.5206554724539005,-3.52067618648628 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark56(-0.1302103008556239,-12.485407150289811,-0.05336847462842925,-2.6824951230266727,0.5855728546572563 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark56(0,130.3724527244798,-0.008985814363471456,-71.75082500890085,162.85113090898568 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark56(0,13.04174177882135,-0.033816582827998876,3.9013049347825124,-26.881400297282923 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark56(0,-13.520038270679322,-0.05079658912519186,118.59143374289987,-34.367504664257126 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark56(0,13.621547375363331,-0.05787762668071318,-41.7419894808342,43.3127858076291 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark56(0,13.64943391277851,-0.050004100352585484,21.786480156849546,-23.286480156849546 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark56(0,13.655498425033374,-0.02424019961214582,3.725743011459557,-5.296539338254454 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark56(0,13.725622456850616,-0.027335929206237064,112.10601331399708,-6.3617956616047735 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark56(0,13.753302114490499,-0.05545564245935422,5.468778158939038,-3.899854294170985 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark56(0,-1.4210854715202004E-14,-0.044126167612882336,99.99998102650056,-100.0 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark56(0,-14.263587392206617,-33.33000155024071,-94.66726207577585,-22.9886630788302 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark56(0,14.420547071143295,-0.020463428090450327,6.405361750648158,-3.260068332926437 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark56(0,146.9222535662191,-0.017871133639904446,67.87056080062172,-154.57870956381922 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark56(0,149.24845191601005,-0.04177294879773197,-403.23623316091033,23.118355821348487 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark56(0,149.31412456137969,-0.06078446140748685,-40.92820503538101,19.454465105007102 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark56(0,-150.03268769595476,-0.05544263911728045,62.34333631732335,-33.230866122837924 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark56(0,-15.012688683654149,-1.1102230246251565E-16,9.022085037893852,-49.92497727769912 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark56(0,15.069267983312159,-0.021660743261173558,-0.028345564522230582,55.41594790122948 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark56(0,-15.69420418572925,-0.0516238169823382,0.12617438463559924,-12.44713853563856 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark56(0,16.01957255992153,-0.0012289135864894407,80.85135492077804,-82.35135492077804 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark56(0,16.213682548813754,-0.012623460921477555,-33.32024535145046,34.82024535145046 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark56(0,16.298836657767637,-0.028202723543790754,-0.02041075421813826,76.9592495214601 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark56(0,16.413330433649065,-0.05950543084269059,-17.177497553613172,17.177497553872925 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark56(0,16.736317444167558,-0.04820692803706278,-98.50057760227327,100.0 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark56(0,-16.748448187878342,-0.015832076028317255,-86.83095085384537,16.90129867231865 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark56(0,-17.126581882500616,-0.015060787628022432,-0.3304502775247773,4.753502822151878 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark56(0,17.62219282032951,-0.002101240587711606,1.1203242851943542,-1.1203242851943542 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark56(0,17.719115567234972,-0.03484416168145181,85.31536190134196,-121.4840313821303 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark56(0,1.7763568394002505E-15,-0.05081503431241396,3.7192977996717205,-8.360890453261513 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark56(0,-17.822277746438935,-0.052070302129255286,-28.187919227039142,26.687919227039142 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark56(0,-17.923699977542398,-5.446284383948694,-60.49298747003773,52.11530328465108 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark56(0,18.149005243717575,-0.062399396071716184,-1.6136252829934428,3.184421609788544 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark56(0,18.328264390422653,-0.015893963303559085,-43.03690285426468,8.974796710066459E-19 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark56(0,-186.8471186060116,-0.059437906973228316,-6.855660095278972,-26.060266440618957 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark56(0,18.973040924922444,-0.022000104903624116,0.468676512541752,-1.6254987673643697 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark56(0,19.334505363057268,-0.05316621573085378,6.888114908713632,-0.22804444287185133 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark56(0,-19.3633450328053,-1.1102230246251565E-16,0.01578053228858524,-99.54013578687224 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark56(0,19.78150203256486,-0.03309210926152811,-0.5270673594912731,2.09786368628617 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark56(0,19.88456035344231,-0.004898484300316336,77.41322956669876,-96.63201846832041 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark56(0,-19.947492035829598,-0.05532165143780571,3.4796541464653408,-55.31592922930999 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark56(0,2.00608489940149,-0.03052519294927225,6.224380954293437,-4.6535846274985415 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark56(0,20.129082319337154,-0.0326250194431835,-0.4518891008995107,2.022685427694407 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark56(0,20.16828159422,-0.02189481780600388,21.542171447137033,-23.112967773931928 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark56(0,20.52577890375819,-0.002009711196950925,10.24041046016564,-0.15339193022634845 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark56(0,21.247943804872154,-0.021488329512262316,1.1198535611905803E-17,-62.67596844414254 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark56(0,21.256963268984094,-0.02026823825621729,4.610840262760928,-4.610840262760929 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark56(0,21.325557597425394,-0.055104266480168834,92.21978683208651,-93.7905831588814 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark56(0,-21.443243537705108,-0.04414448069759605,-0.22124305317183257,1.7920393799667238 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark56(0,-21.6639410703415,-0.030026860028644714,-0.44146298954436247,3.55816085152685 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark56(0,-21.69291317797568,-0.006667026079449467,0.030853006076412795,-50.91226193339308 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark56(0,21.947800600209476,-1.1102230246251565E-16,-0.5904819473275164,2.6601936501263426 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark56(0,22.01444010796143,-0.033829740199644964,-22.06050462856531,0.07120400703621854 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark56(0,22.025019873102863,-5.551115123125783E-17,-5.911759469790603,16.683074313223017 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark56(0,22.055526533157533,-0.010185859776884014,42.555985313321855,-40.985188986526964 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark56(0,22.358662862791874,-0.05750599489635584,-87.96351499074203,88.0481439552312 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark56(0,22.38028671952739,-6.938893903907228E-18,99.98529469435151,-79.6039557422872 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark56(0,22.409929019570157,-1.0034550730496188E-9,-99.9999999979996,98.49999999665927 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark56(0,-22.47537638899807,-3.5599270203535646E-4,1.892535869897336,-0.3217395431024384 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark56(0,22.993260555293425,-0.023114439618268826,62.55262961045123,-63.14375426229211 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark56(0,-23.647877812442673,-0.025309916049226902,-45.86658208586512,0.034247076092427164 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark56(0,24.260560264621397,-0.05634327630013469,-11.749134033537004,13.319930360331899 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark56(0,24.371548938665423,-1.0339757656912846E-25,32.566312157891176,-34.066312157891176 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark56(0,24.4833919823762,-0.01656482693663275,4.185924800042265,-126.92845181580114 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark56(0,-24.642108036042924,-5.551115123125783E-17,-1.9013190088193666,1.8635031574604268 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark56(0,24.73936762126006,-0.05827139564972475,0.3035235238542401,-5.175204566843504 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark56(0,24.799712866763315,-0.010417358063733284,21.622993879895944,-189.63509906923096 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark56(0.24817231719878602,2.5288252664979467,-0.0203302848668806,48.151679497733795,-63.36825130478972 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark56(0,25.013793740666202,-0.044883179924129615,-1.9262960821259645,1.9262943220738376 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark56(0,25.139716101306746,-0.018365869364034726,11.929717915117582,-0.1316708691665165 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark56(0,25.211948640161776,-0.00669934140991936,89.90806444414031,-89.90806462563435 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark56(0,-26.08948713905613,-0.015015311269766267,37.61444850539351,-8.12858786082503 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark56(0,26.125008757662826,-0.052927479007925035,3.141294437786422,-3.141294437786422 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark56(0,-26.18071990322983,-0.02552783776255474,2.9320909080512294,-18.272823485699792 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark56(0,-26.402232804699985,-0.008059663095798336,34.66753243081952,-13.363069717645011 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark56(0,26.53020249613397,-0.05982677586301355,-2.9456524536889397,4.44565245368894 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark56(0,-26.646882204033933,-0.03215136000851956,-61.82103101689141,62.07346415159121 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark56(0,-26.734553921833452,-0.033574270010486136,-27.242674028143416,25.742674034288434 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark56(0,-26.88947802344321,-1.1102230246251565E-16,-1.7108488725538502,0.1400525457589534 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark56(0,-27.122585897080526,-0.014985055074404896,-0.14358786461999765,4.468869466928307 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark56(0,-27.284346068554306,-0.0020906461446919605,0.05003054873402768,-31.396743920310797 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark56(0,-27.393922863780954,-1.7763568394002505E-15,-1.087287527948714,0.7361717686057748 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark56(0,-27.461716209227802,-0.049173984832419804,95.13052151832909,-137.5563723628942 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark56(0,-27.644053520589296,-0.023729599918549782,-0.029599974320041775,-1.4704000256798975 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark56(0,27.75748553748072,67.51416946192589,76.3208209064046,98.02662865129204 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark56(0,27.93012499878023,-0.026327817205854157,-39.11135951469249,125.22777087927435 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark56(0,28.21598829791965,-0.04446215270729214,673.5861984993818,-1.1613664429320596 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark56(0,-2.82546466219617,-0.06250541943106377,70.80898382752007,-72.37978015431496 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark56(0,-28.264913434661892,-0.003062661066971867,-57.328501901442415,55.75770557464762 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark56(0,-28.573153048354683,-1.7763568394002505E-15,-1.6440432155673648,0.07324688877246821 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark56(0,-28.573995848545238,-1.7763568394002505E-15,-100.38593605608735,100.36867449088071 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark56(0,29.697138117145357,-0.002225210163563176,70.35327405922187,-71.85327405922186 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark56(0,-29.734632653318688,-0.05522009924647623,54.584539436739476,-5.915942869776338E-4 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark56(0,-29.980388264980263,-0.038033162317922864,-69.99043996557538,82.02096796919898 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark56(0,30.09260458365369,-0.05952135680045492,100.0,-79.58719091551401 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark56(0,-30.136529114539407,-2.7755575615628914E-17,-48.57787500425596,50.14867133105085 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark56(0,-30.356090878512124,-0.027158581360996747,121.17831052673839,-16.10272297297278 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark56(0,-30.66795744888975,-0.002721574245594858,8.106551815110038,-6.600615822181021 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark56(-0.3101085438917133,13.51160548319244,-0.019001621626861222,-17.543009598216933,66.47365323625347 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark56(0,31.401379742439886,-0.025196395175926808,20.91033232237878,-22.410328778639947 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark56(0,-3.1448721332854106,-3.552713678800501E-15,1.8892939440831067,-0.3184976172882139 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark56(0,-31.48824682799664,-0.019204000466054444,-15.088682760378653,13.517886433583755 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark56(0,31.700852274785774,-0.0049588306951308635,-12.304081649243336,13.607935305092052 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark56(0,32.001654709814915,-0.0040665309374497685,-100.2426370786729,98.69125106327309 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark56(0,-320.8795385202718,-0.09793234645181226,-582.8935277747291,6.302283066916425 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark56(0,32.31621622052994,-0.04370377152209949,66.77822417410536,-0.023522583090851423 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark56(0,32.32416520993277,-0.019066100669784064,2.1464027478250305,-0.7318273927791971 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark56(0.32443769499934677,4.7010954091485075,-1.4210854715202004E-14,-97.68257436401466,1.262241497628527 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark56(0,32.513245379607035,-0.02368603959393717,20.15762694394837,-21.665163477462006 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark56(0,-32.64049958836724,-1.1102230246251565E-16,-0.47527448825009433,3.3050297578108743 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark56(0,3.270215336566281,-0.01786102569873549,-86.42457536943893,2.1316282072803006E-14 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark56(0,32.799184984513715,-0.04352462049256334,34.18839061739231,-35.7591869441872 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark56(0,33.15797180180047,-0.012446168232582058,-0.018409759582354468,85.32410864835443 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark56(0,-33.16162307382713,-0.020110845011973563,0.1380491610549887,-2.5632176979820884 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark56(0,33.3756225053503,-0.00990239603307714,6.425984881980712,-4.858024325771971 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark56(0,33.88592005733503,19.23786143419312,-79.70545317064,15.54172002293626 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark56(0,-33.94620325707476,-1.1102230246251565E-16,26.367276324871554,-49.95962390304496 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark56(0,33.978502578052364,-0.02737151011019069,0.7247700234728889,-75.08721456400204 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark56(0,34.06885287440929,-0.03666265872250296,-0.03324736096708845,47.17991738620875 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark56(0,34.09857477385174,38.953193758961106,-87.78900360781859,-4.330013806603432 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark56(0,34.10135304964986,-0.04331720389097722,0.4697235383165397,-5.173334438919131 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark56(0,-34.67386811780406,-0.026540529558249717,15.282791601130988,-72.60476564871495 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark56(0,-34.83400253889306,-2.7755575615628914E-17,1.9926755006859715,-0.4218791738910759 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark56(0,35.20544234573977,-0.017197376354711108,75.8578898885573,-45.271948276988724 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark56(0,-35.52716130168532,-0.027039051100060718,-38.46358056434029,66.09296392181862 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark56(0,-35.97696473207694,-2.7755575615628914E-17,-47.71628328544292,0.03291950291681893 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark56(0,-36.2148995855781,-8.881784197001252E-16,-24.219742694763717,22.719742694763717 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark56(0,36.27997216266958,-0.025260173882476703,-3.388900062826281,-26.385433819481857 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark56(0,36.90769868784315,-0.005055879739138902,89.5459528404424,-91.1167491672373 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark56(0,3.7225318006144956,-0.050604477220877235,-47.92981029008341,47.92981028535017 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark56(0,37.26149511453794,-2.7755575615628914E-17,-74.42291273342221,30.531010640741243 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark56(0,-3.7576201214097438,-0.029345821393545066,-79.2432015686605,79.33288883039833 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark56(0,-37.770490872994245,-5.281485238029383E-12,60.92372803772869,-0.025782997485349846 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark56(0,-37.79888667291265,-0.7004369959873565,-15.64401164955512,17.214807976350016 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark56(0,37.81114081131154,-1.1102230246251565E-16,3.054344680454213,-0.043921817435950805 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark56(0,-37.92637131272721,-0.010422301658572969,-68.68640779887129,67.11561147207638 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark56(0,-3.8027047640320015,-1.104359095298317E-15,-15.511189927679078,14.011189927679078 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark56(0,-38.16724450208779,-0.05477773949579867,0.02667970208595269,-58.87608196427153 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark56(0,-38.25699821575726,-0.021738186937308966,-65.64445357727669,5.551115123125783E-17 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark56(0,38.26334199874876,-0.00662667121345642,-0.013797078508195448,94.47545517383307 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark56(0,-38.31391185888502,-0.0070651004997784594,0.3550025321351382,-2.881846649772943 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark56(0,-38.74997550615887,-0.04855365774010238,2.8778430306512357,-12.246604708197976 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark56(0,-38.87336960170023,-0.0035614133818733574,18.293400527599037,-19.793400527624968 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark56(-0.3908307472581303,2.6452278608830415,-0.047007288441565764,2.9955483520105872,-0.5238651434866527 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark56(0,-39.33655483515595,-5.551115123125783E-17,-100.0,85.17604062856924 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark56(0,-39.58847909603489,-0.05923004797788756,-0.20373142359967455,7.710132776971406 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark56(0.408342441811343,-34.597460384008016,-0.03222527032837363,74.22565028613047,-75.72565028613047 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark56(0,-4.122149886766266,81.59101720603076,-8.161183124450446,33.170767339974475 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark56(0.41281199753652215,0.5441607282677846,-7.081804985138045E-17,0.01396466991186692,-72.7610605300037 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark56(0,-41.52484383184034,-0.05541269413474059,39.56197107328968,-41.06197107328943 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark56(0,-41.57146686790499,-0.011375485299386895,-54.01470943542418,100.0 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark56(0,-41.593215376035204,-0.017784719194369334,-0.022750677308543604,48.83553851163907 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark56(0,41.71301863153491,-0.06216920990569,-19.4988319856563,17.928035658861408 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark56(0,41.9901485171531,-3.552713678800501E-15,3.552713678800501E-15,-67.42995193384914 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark56(0,42.02321804545889,-0.06250415195901132,-99.96623953667383,99.98276535581329 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark56(0,-42.18580472139242,-0.05854529072392881,-98.48893614522558,100.0 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark56(0,42.59119543417957,-0.056792177711828096,0.28297994229704787,-5.092307616069255 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark56(0,42.98805052846582,-1.0426197548164283E-15,-4.35043540332455,5.921231730119443 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark56(-0.4385917169388736,11.327874587800993,-0.03597850137092995,15.406718228228925,-85.89191287978359 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark56(0,43.896076346909354,-1.1102230246251565E-16,-100.0,100.0 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark56(0,-44.10541564738142,-0.012062955347690914,0.014426803502505197,-49.02260008735933 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark56(0,-44.400145536555804,-0.03773085646649049,-85.43032212199716,55.65598823968903 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark56(0,-44.505164613829706,-1.3877787807814457E-17,0.07407086140244523,-21.206670167643566 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark56(0,-44.910376498413406,-3.723921634799976E-16,-85.56296917746474,87.13376550425963 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark56(0,45.234633840604616,-0.008774524713275778,1.6832436793838308,-0.9331160967541487 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark56(0,45.478623060885575,-0.021520635296863225,0.06405488436282193,-24.522662751173456 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark56(0,-45.692376336425,-2.7755575615628914E-17,-3.3313197884536763,0.4715237282950926 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark56(0,46.97680036057765,-1.2935304084313404E-24,71.00018167617766,-69.42938534938277 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark56(0,4.7109431064959715,-0.056228968916228264,56.77469329344272,-0.0023043104465926903 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark56(0,47.43917873334814,-0.025494374182551346,-18.96857117271017,17.397774845915272 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark56(0,47.47395554024092,-0.02085611069721112,-0.18123007798911686,8.667415167636937 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark56(0,48.087666494852435,-0.02433818813672195,71.97807340533299,-139.12185920380642 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark56(0,48.110911546068124,-2.7755575615628914E-17,-0.017142785016797415,91.63017125022256 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark56(0,4.821660719529615,-0.04332052681497685,-45.675680117482095,44.1048837906872 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark56(0,48.26104350228976,-6.938893903907228E-18,54.5096132833827,-54.82802425338947 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark56(0,-49.125597513044326,-0.11704576983971648,16.463335923510336,-105.92516392873364 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark56(0,-49.462162213329606,-1.623054476196235E-14,-7.393617516306376,8.964413843101273 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark56(0,50.27000713628684,-2.7346638595371976E-12,-58.549816036418264,57.05578503620762 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark56(0,-50.76213000801175,-77.25821821874285,31.45586055216566,56.02531690872635 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark56(0,50.99993616861322,-0.0064453022481678335,40.58934366799374,-39.08934366799374 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark56(0,-51.09841576364475,-0.006507076966154999,-9.371104307707625,7.800307980912728 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark56(0,-51.170930557583105,-0.015622646287280384,-27.501963466981927,72.13571447118254 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark56(-0.5124824208682356,-27.536240798540152,-0.048228950643775026,-98.5,100.0 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark56(0,51.38493055758444,-6.780626888483127E-4,52.218527709507626,-50.718527709507626 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark56(0,-51.86173491251278,-0.04534784646487558,11.627446327712416,-10.087260359929417 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark56(0,-51.993027106716156,-0.02457873824705691,71.6332728896735,-16.62254368964888 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark56(0,52.057922614772735,-0.057379017547860296,-93.89188390784584,92.79531046708041 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark56(0,-52.576386349981085,-0.04096834243643112,99.28740045108799,-99.38945294013155 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark56(0,52.719097017078866,-0.009837238408665063,-17.326127474382677,59.74504471633304 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark56(0,52.869830901990916,-0.006368976606707302,-8.901560423478315,24.479889580313568 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark56(0,53.03945255012855,-1.3877787807814457E-17,-3.423921087201998,0.45877118274315687 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark56(0,-53.77627643403105,-0.04598954697751695,2.4014767162470854,-63.591737134453155 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark56(0,-53.983404057640016,-2.7755575615628914E-17,39.56338281036054,-100.0 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark56(0,55.35088730554162,-0.03953946386027912,0.016321166507455215,-96.24289575609588 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark56(0,-55.56163854144249,-4.440892098500626E-16,0.18016143714956623,-8.718826579357572 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark56(0,55.78421465711878,-4.427491005202114E-16,1.0165088281203127,-1.016508828121058 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark56(0,-56.78151025376977,-0.057491728989350566,-18.694547146444517,18.694547146444517 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark56(0,57.20871131317992,-38.37658282573167,-15.22385351905389,-46.857103074523245 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark56(0,-58.05515835337831,-63.93873330606248,27.228895189596486,18.270289291149624 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark56(0,-5.821486869142893,-0.03668588032554196,-7.2529395093980025,15.09994840315081 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark56(0,58.35362077867517,-0.045639129076080864,0.1514414731446748,-10.372299570107103 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark56(0,58.35584432919058,-0.036776381159654314,98.61461292744252,-100.0 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark56(0,5.840896239184005,-0.008531768788402422,-20.87853404391811,4.694069838164761 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark56(0,58.502068808833585,-0.015960017010151945,-11.574266131023403,10.054191338721429 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark56(0,58.70653407046589,-0.04581071196766055,0.3857035091597017,-1.9564998359545984 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark56(0,58.87103576168874,-2.5049803142536996E-15,-24.768242498980214,23.268242498980214 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark56(0,59.071917960149534,-0.05841033687341479,-78.64285984556446,72.51032555849049 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark56(0,59.13271779960942,82.31451481707833,38.5841098769277,-15.402101096347394 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark56(0,59.18412769495621,-2.827366710715685E-29,100.0,-98.5 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark56(0,59.21670499156122,-0.013410474495611169,-29.142202546214865,29.14220254621486 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark56(0,-5.992229860065789,-0.0026863792798227926,95.99565306332953,-94.49565306332953 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark56(0,-5.995742584334865,-0.03180458409258166,0.06229225926278822,-1.633088586057685 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark56(0,60.082902822891576,-0.022730012037122105,81.58681128126321,-84.29593931383938 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark56(0,60.15907927215875,-6.934138417719266E-4,-2.716602948849409,1.145806622054512 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark56(0,-6.016843158474354,-2.7755575615628914E-17,16.464536666096265,-0.09540483031201702 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark56(0,60.19666620675517,-1.1102230246251565E-16,59.68324216236847,-58.18324216236847 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark56(0,-60.36291200561956,-0.05681665699206942,-14.11258715411949,0.08015319894931233 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark56(0,-60.47935764220486,-1.3334999816330507E-11,100.0133160898019,-98.49101713676542 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark56(0,61.2726378791018,-5.551115123125783E-17,-0.03397057689453941,1.6047669036894376 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark56(0,61.46616120969982,-0.05534231030552167,71.58236409274895,-70.01156776595404 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark56(0,-61.49917936671065,-0.032784657235148236,1.8184663627145632,-0.24767003591966685 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark56(-0.6214409693320231,0.2593095797421263,-0.03916374731043522,0.0013536050626375513,-36.54356894709751 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark56(0,-62.461614769527536,-0.021458576344505157,100.0,-98.68829351757626 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark56(0,-62.62020432175865,-2.465190328815662E-32,15.829913442133726,-14.259117115338832 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark56(0,-63.021720524292476,-3.552713678800501E-15,-65.47663624222396,82.67716522397248 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark56(0,-6.3792363218080474,-0.027028282503786333,-4.012536520351402,4.440892098500626E-16 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark56(0,-63.81953773163999,-0.3103835166057032,-1.7402526361252395E-13,2136.207803053449 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark56(0,63.87734283511412,-0.05634841453337773,-93.60510808968586,14.401375580284451 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark56(0,64.289465170364,-0.03606009091365163,66.03666695513837,-64.4685875732099 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark56(0,-64.35456822374906,-0.04820820571429523,1.1157693576075125,-1.115769339177318 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark56(0,-65.6294034775868,-0.0605528647808751,2.4630734475216625,-0.6377383217603305 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark56(0,-66.13269687199958,-0.01181231339791091,-6.1508454472523555,7.721641774047251 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark56(0,66.13667533027507,-8.84337576251049E-5,-63.867850679194085,63.41192683699845 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark56(0,-66.72295733613203,-0.017296324917995758,4.37789474185133,3.4033038494812047 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark56(0,-66.73805723261513,-0.034738100362527335,-22.826783675133143,24.39758000192804 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark56(0,-67.43909731484158,-0.023450066316081562,0.35987891370673303,9.011768175972776 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark56(0,-67.81529399179122,-0.012700046966123979,-10.365491922951325,8.865552356672547 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark56(0,-6.7891086432367675,-0.03450724338586467,-3.8896436993625647,0.04114800229123039 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark56(0,67.89537894794134,-0.021722292506566904,0.08005557926373363,-19.6213223518136 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark56(0,-68.03128832269503,-0.060505849539326785,2.8796681644297184,-1.308871837634822 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark56(0,69.70174572235274,-0.04407646747347149,7.280162882834534,-5.709366556039633 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark56(0,69.96027907603435,-0.04017894010515469,35.72663993397222,-34.22663993402847 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark56(0,-70.35348485132509,-0.04587094559563806,-5.214576942186044,6.7853732689809405 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark56(0,70.72586441111049,-2.7755575615628914E-17,-0.4612093322308439,2.0320056590257423 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark56(0,70.95839192378723,-0.04609018282532462,-33.74071614657197,34.015251429472436 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark56(0,-7.105427357601002E-15,-0.010960276687507804,-76.30556434251953,76.30556432918479 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark56(0,7.105427357601002E-15,-2.682700865539641E-17,0.02193542030697728,-1.5927317471018745 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark56(0,-71.06133698070794,-0.06070509922341452,-99.46598892143263,97.89519259463773 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark56(0,71.27463884914057,-0.1855850054000305,0.45230124999958105,90.55443038235681 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark56(0,-7.193633183455855,-0.04908789038266381,-19.00499004750119,93.75977269471869 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark56(0,72.06259702270401,-1.1102230246251565E-16,34.59551227833381,-0.04528586003030255 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark56(0,-72.92904123205201,-0.2750960743768582,3.2031147357200958,-3.2031147357200953 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark56(0,-73.13177377152688,-0.027272198487904388,128.37018196760798,-98.55881639727666 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark56(0,-7.3863562519923285,-0.0015015847434936321,-54.380568440282126,52.880568440282126 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark56(0,7.402746292109224,-0.002774576470634271,-28.65300022527013,30.186242766083097 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark56(0,-74.085850022019,-0.00529558564208224,0.6130687352200981,-2.183865062014995 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark56(0,74.34764367199344,-2.7755575615628914E-17,-1.4210854715202004E-14,0.5426039559934352 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark56(0,74.35449023780427,-41.17272329023709,-4.780569331546488,51.91154350883863 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark56(0,-75.0364461741604,-0.01802985029778803,8.458720846771952,-10.029517173566846 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark56(0,-75.06506830024998,-5.551115123125783E-17,0.01871410528678604,-83.93649082994258 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark56(0,75.83754609657512,-0.04004167287663845,-0.19746567147164562,1.768261998266543 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark56(0,75.96074862025239,-0.0557936389391166,80.8404033098282,-100.0 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark56(0,76.01359100650765,-0.030637594785205797,17.065830204776578,-7.228072126645628 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark56(0,76.03278373651344,-0.2559218460616333,-19.36476781422767,17.86476781422767 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark56(0,-76.03981020399766,-0.029636740096691927,50.35616767107608,-50.48137220292688 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark56(0,-76.33812789787694,-5.551115123125783E-17,-0.4813813935077981,0.48138139350733494 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark56(0,-76.51690076562441,-0.03853631377883607,-99.99999911961261,100.0 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark56(0,76.86490820514439,-0.0405834221201099,-1.0512466781021523,-11.444327609462123 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark56(0,77.60191329347722,-0.02812701258972724,1.4487439118127947,-3.019540238607692 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark56(0,77.65730333502046,-0.060449138858845584,0.07178228237872396,-21.8827860405352 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark56(0,77.67626478191998,-6.191962772120321E-25,62.71451615958013,-64.28531248637502 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark56(0,77.83690592702958,-0.01112459187078918,3.832999446323498,-0.04010913915247735 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark56(0,-78.36005062200294,-1.7763568394002505E-15,-17.379430091913967,-18.67808909757375 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark56(0,78.5763489172558,-0.028017963156641842,0.2214165946994378,-7.094302615064493 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark56(0,-78.76300394072535,-0.02134522464491645,78.15833752168294,-86.39630608777051 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark56(0,78.94854341750303,-0.049685974352197605,60.66737668765925,-100.0 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark56(0,79.12903792205593,-0.05600251738169871,35.638317364396606,-34.158729654460856 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark56(0,-8.012042712930986,-0.006304879081138082,52.251149172368656,-53.8127223372497 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark56(0,80.37895460168669,-0.96079266788238,-1.0502142633300604,1.798778489468484 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark56(0,-80.48471385547148,-0.006133792780632641,12.190031162366251,-18.40242014275094 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark56(0,8.095224239344997,-5.551115123125783E-17,-27.360922010838685,32.54697648882393 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark56(0,80.97032661383363,49.92821183621027,-62.59141890195572,-19.972608367668585 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark56(0,81.34069704724412,-0.18763844837874963,-0.4293765554846194,3.6583188036943572 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark56(0,81.49349993236021,-0.09151093358255152,4.17344762049191,-500.80734006308893 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark56(0,81.57224436821059,-0.013555558468090997,-1.1040037344373108,2.674800061232207 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark56(0,81.94764019223132,-2.7755575615628914E-17,-0.722567836999958,0.8629861740514873 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark56(0,-81.97148132365598,-0.012619737153578552,10.564381728857754,-22.996144193919037 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark56(0,-82.30910070942558,-0.05314450367356179,-48.029853346034315,89.8300300589062 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark56(0,82.54842856320599,-0.04368620580538718,-4.870921402405513,46.09644167383099 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark56(0,8.3027741449024,-0.043478688255109144,-1.0069605629343783,1.0074553860393864 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark56(0,-83.12705437908986,-0.03917883275171152,2.3864532567184886,-0.5789469783305609 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark56(0,-83.75968347838554,-9.60813917988041,59.95702561981412,-15.695993137054458 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark56(0,-83.91880864682125,-0.04205386887518059,6.000224595670245,-4.429428268875348 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark56(0,-83.93538969408007,-4.425779647668667E-21,49.45374874579512,-51.02454507258993 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark56(0,84.15036798717351,-1.7763568394002505E-15,96.7310309750228,-98.1177723412228 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark56(0,84.19512273157979,-0.03755157581164009,6.81808356186832,19.87856166606989 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark56(0,-84.205699001563,-1.3877787807814457E-17,3.1557731874519646,-0.007279314035838758 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark56(0,-84.5595411321153,-0.0374105134382976,-0.7490439284173356,-2.3297780097575025 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark56(0,84.57727461254723,-0.03907521307684081,-100.0,99.9999999361066 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark56(0,-84.84968594137754,-0.09440512787284028,-0.07551256123571193,297.80332911299 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark56(0,85.27803967209331,-1.1102230246251565E-16,-0.04251817835727019,36.94411161258762 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark56(0,85.32136402514827,-0.023156241054635665,45.56456563725687,-0.03447407661690734 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark56(0,-85.41980227756518,-0.05204105122881636,-12.438313145114051,10.867729441547874 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark56(0.8545252203166832,-7.535353307666661,-0.006170519113241234,27.160078476028456,-12.866074423129593 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark56(0,-85.65125805929961,-0.047179248634003246,0.10433934818409556,-15.054687940194867 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark56(0,85.79971367752944,-1.1102230246251565E-16,0.21611160179179478,-6.820023817108234 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark56(0,-86.28556641570555,-0.02857384049814271,2.5898910523567093E-14,-26.211312793275383 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark56(0,-8.661573625557176,-0.29725143657219727,-676.8011806397104,20.895032930346122 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark56(0,86.70380619946846,-0.03192726469460615,48.66862705656795,-50.17207038614883 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark56(0,-87.19776922398741,-0.028346822632628253,47.58359655152676,-49.08359655152676 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark56(0,-87.69688661893966,-0.015861755074490558,9.970546871902767,-0.15754364800404652 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark56(0,87.80888787375292,-4.535097808979635E-17,-4.029430435483909,2.4586341086890116 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark56(0,-88.09703875926313,-0.02345238597660363,0.11505774977695893,-1.6858540765718555 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark56(0,-88.1489987655852,-0.02509326600347417,0.023098187417882166,-68.00517713259238 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark56(0,-88.64287816437174,-0.02365441447163144,57.67219034513306,-0.0272366337639447 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark56(0,-88.83149737029423,-1.1102230246251565E-16,100.0,-98.5523867004798 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark56(0,-89.2602360855659,-0.0024901268701176815,89.89336410884356,-88.32256778204867 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark56(0.898377176210275,-15.753016923458832,-0.025819675479820538,43.99848210680796,-45.498416515303155 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark56(0,-90.03980143162094,-0.010567772147942163,0.01942147753152479,-80.87934217387014 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark56(0,90.20116650401337,-0.06064424491432167,-1.499999994960974,2.220446049250313E-16 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark56(0,-90.22399926729281,-0.0023687737356038463,22.12047913539834,-82.27933503731923 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark56(0,-90.44337730120625,-0.04696067950181216,-5.551115123125783E-17,5.485120901472665 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark56(0,-90.53701444132926,-1.1102230246251565E-16,-100.0,100.0 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark56(0,-9.057298354795167,-0.007160701007154675,-21.808496098447193,20.309088499304234 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark56(0,-90.65781234312117,-0.060986540841809614,42.70448672832515,-3.626046464193294 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark56(0,-91.27679071505455,-0.005059031330361272,0.03748305312899705,-41.90684044304069 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark56(0,91.58824524884507,-0.04909080524298761,98.4999999999858,-100.0 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark56(0,-91.8703853112688,-0.06051010528368733,-4.624950474315109,3.2590475082307115 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark56(0,92.14703181368861,-0.01546225490865594,98.49999997461835,-100.0 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark56(0,-92.34450114045154,-2.7755575615628914E-17,-14.504010251434483,16.07480657822938 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark56(0,-92.66943352354258,-5.551115123125783E-17,0.14780334087043473,-10.517051463700122 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark56(0,92.87415792260433,-2.7755575615628914E-17,90.99951741914333,-83.58303203981373 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark56(0,93.43733119164698,-0.044363946367041905,34.66434069078483,-36.164071112407356 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark56(0,-93.80603458281654,-0.03573334601112491,86.58375643800886,-44.230372218068894 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark56(0,-94.07693218466409,-67.82667051241229,-50.87110241063804,92.52907550320796 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark56(0,94.73568525105651,-0.049636517429438864,35.83491702204957,-6.06334575197635 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark56(0,95.19251517923561,-0.022719355931852717,-60.31135670306238,58.724675147952404 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark56(0,-96.3101540479906,-0.5907641268158782,-3.356605878210244,3.3389348665730183 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark56(0,9.684369957427293,-5.551115123125783E-17,13.316065352678965,-0.1179624975690645 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark56(0,96.86012793110658,-0.001711174240801111,-1.6123716263484562,64.37342837134942 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark56(0,96.96377776351417,-0.02243409965219018,77.70771415683069,-76.13691783003578 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark56(0,-97.06141345850392,-0.014254665753580698,-1.2046657094681588,1.303927151282806 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark56(0,97.23950266850905,-2.431678102058042E-18,-97.84054511300485,97.51739146701969 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark56(0,-97.46051197586286,-2.7755575615628914E-17,-98.5,100.0 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark56(0,97.52397636565541,-6.2914182169323715E-16,-2.220446049250313E-16,15.858485203140688 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark56(0,97.65242376939474,-0.03246860895351797,0.524499073740273,-2.994850525842377 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark56(0,97.7433962642827,-0.061249369678866294,51.37630664174782,-0.030574333374097762 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark56(0,97.86743504077545,-0.01830554005370823,-100.0068477860949,98.55318641828816 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark56(0,97.86774456289086,-0.04413337790606079,-27.77078606776591,29.34158239456081 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark56(0,98.23159123476522,-0.004469948878575392,-1.6618764395327208,28.365234710953704 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark56(0,-98.30923215127834,-0.03319988864485468,6.51508602173676,-100.0 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark56(0,-98.63205574906925,-0.059468582125648595,-84.8116815481213,83.24088522132641 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark56(0,-98.67052806566576,-1.3877787807814457E-17,-12.868573412803947,0.12206452699970523 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark56(0,-98.82491058997579,-0.007304385449542039,-50.92902759917761,7.982090519381657 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark56(0,9.88574150227456,-0.06017681719157819,9.365796766618647,-84.88866649622989 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark56(0,98.91705223761872,-0.04524643870726297,1.8537448353659465,-3.4245411621608444 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark56(0,-98.9468847592257,-0.04760782101453266,26.79214812350485,-28.292147622130855 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark56(0,-99.05557899352264,-0.14480935494358607,-51.01382842064972,52.56115674970927 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark56(0,99.36555385836498,-0.055324528581507805,32.74015202348694,-34.07100397525354 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark56(0,99.40691152038737,-1.1102230246251565E-16,100.0,-74.2483886383304 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark56(0,-99.56164175612876,-1.1102230246251565E-16,99.99999999999999,-0.015707963267948967 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark56(0,99.6528928756279,-0.01887674634844687,-100.0,98.5 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark56(0,99.79839484379289,-0.032631918402777016,3.7567278951675545,-0.4181288532543125 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark56(0,-99.97542831579047,-1.3877787807814457E-17,-83.26701113798944,0.01886456959755556 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark56(0,99.9894279651903,-0.018480823656552375,-5.391909356224641,0.7003330868901969 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark56(0,-99.9955910443783,-0.033604181687124784,140.88689261719136,-98.5 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark56(0,99.99999986875855,-0.04823901158600109,-97.19824434376626,95.64644008260552 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark56(0,99.99999999839807,-0.050774006409461066,4.817578068781636,-3.3175780687816356 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark56(0,99.99999999999996,-0.010344863349188216,-0.713513535740052,2.213513535740052 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark56(0,99.99999999999999,-0.008886557846451272,100.0,-98.49999999999997 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark56(100.0,-100.0,-0.046037307390637675,4.008221608515175,-5.508221608515175 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark56(-100.0,100.0,-0.9971627048304147,-0.507732062112298,2.2901466461686075 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark56(-100.0,100.0,-8.43769498715119E-15,13.942215669595251,-0.11213636137752163 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark56(-100.0,-22.041928168652095,-0.032979714356310724,-5.3455548215727475,61.71538336360738 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark56(100.0,2.2603478205006127,-0.006513930688541225,-3.552713678800501E-15,4.588445608862525 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark56(100.0,-38.65382627035332,-0.031222110084911377,-1.1102230246251565E-16,88.23525460960234 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark56(-100.0,65.91284914159225,-0.034952220158706304,5.3383454603452405,-0.02022450230626596 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark56(-100.0,84.70591135630656,-0.005384291240279166,-24.5294921166582,22.958695789863587 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark56(100.0,-97.0631639424041,-5.229211215942558E-19,42.78875811910993,-29.012623909333502 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark56(-101.55330787273175,96.58309575035096,-0.1820303850865803,0.3888957180489596,-2.670281443148564 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark56(104.8148066031628,-37.24258290479031,-0.049812396139219006,-3.907321153929501,0.40201362133112184 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark56(10.850883409197401,57.268462477119016,-5.693505552566181E-14,-80.680979875709,78.47779063946768 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark56(-11.023901648257368,0.9717251367922213,-4.440892098500626E-16,-65.43350017390085,0.024005995745607883 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark56(-11.858759376060561,110.42406258490695,-1.8507165402191618E-15,3.8728156692560205,-2.675354906507134 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark56(-11.976725583067491,-62.207460169093416,-0.04130501946760115,-16.579933224372496,0.0947408114096519 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark56(-1.2294668309175332,-100.0,-0.0013737068455057892,0.3200888035193279,-4.907376670237223 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark56(128.6143331925538,21.53091263448418,-0.02624009640456504,-5.3058562936081195,0.004573215223070398 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark56(1.5506823670459173,9.253541616121613,-0.047853258901091766,100.0,-98.49957053484381 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark56(-157.80132696564547,75.6327482639405,-0.0188361222527483,0.01769646937791336,-88.76326080925475 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark56(-16.240391682864583,-100.0,-0.00944863691678291,0.05770628986911919,-5.2465180151867745 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark56(16.391382349933302,-1.5592939997277533,-0.021260310017589327,51.98752679564693,-53.491921483596535 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark56(16.582704351329525,-15.959392424754896,-1.2988011922868424E-14,59.98372752324882,-59.98372752324882 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark56(-17.57536058298728,-14.6402701269436,-1.1102230246251565E-16,-25.379192602422183,25.379192602422183 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark56(-19.28187521774489,-100.0,-5.551115123125783E-17,9.62367211211518,-47.33967641954265 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark56(-2.0389667912964646,0.7629520209398066,-0.04210225409229091,-24.830230023373137,41.38975432878135 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark56(-22.450660336605864,-2.9012387087442164,-0.0388169310270491,51.73648533899169,-50.23648533899169 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark56(22.63796413315272,21.503375231046004,-0.006676684823668455,-42.340455295920606,61.67053532376741 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark56(-25.441321046539027,-35.06284246442228,-1.8413105030116632E-10,10.718173326405338,13.201579664642612 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark56(26.416585258027396,15.656452754014676,-3.537082102641417E-4,36.54093920149769,-36.7196184275404 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark56(26.65203659667588,-90.8039323904291,-0.04048604044583515,0.023647296285629074,-5.606736437014206 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark56(27.908672728680614,65.62377320870779,-0.024368789608317343,-100.0,88.24843786468065 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark56(29.966163133525246,-53.82933189015426,-0.032092350585245455,-13.872064798754112,13.87206479872123 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark56(31.3350313784972,79.8462098818909,-0.03777334294751677,-1.2144951053439461,2.7852914321388518 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark56(32.34896926548316,14.70786917522156,-1.1102230246251565E-16,73.48877010189918,-99.99861234397211 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark56(-38.13750601050959,135.14920162564823,-0.02089321734168026,-0.5511167907345378,2.2695661220583894 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark56(40.35896340839538,-58.96677775814578,-0.03058395433051884,34.76506049235828,-36.265074991487914 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark56(4.094946618146438,40.05204343028964,-4.583985272663665E-19,1.4677681065120067,-2.9677681065120067 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark56(41.46878299256326,-78.35443689311046,-1.1102230246251565E-16,10.232303390516506,-0.15351346288761733 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark56(-43.345228708196856,-100.0,-0.05442418406863825,-0.06009761826981174,26.137413961110994 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark56(4.702937216507406,-50.09995410249565,-0.04265672811284238,4.974296138980236,-68.93277304412555 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark56(47.28262776385565,-45.34483133839811,-0.013698270250563693,6.938893903907228E-18,-26.39461743004459 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark56(49.208199750725015,19.819531231088522,-0.01742757508288531,0.05927539507568882,-26.499972286800364 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark56(4.944330718411402,-1.7654996722795193,-1.3122240767466742E-13,8.678357184631691,-82.33869365337236 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark56(52.67745969812764,4.674900594510808,-0.054497578654740836,30.06399389607622,-31.284328949947213 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark56(-53.39946866023551,84.84493526221485,-0.04384202600879534,60.60629465001034,-9.61299179181853 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark56(56.74681780233931,54.53355601435628,-1.3877787807814457E-17,-22.821591248348142,24.39175525811899 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark56(56.87650833514337,-72.73113596640333,-0.00972638888580422,91.13930465071974,-92.15408642502649 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark56(59.47529975595438,85.17522072519995,-0.055732665330120446,97.9363936213054,-100.0 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark56(-60.84095547846351,-10.79904256081744,-0.00842014668664946,40.605119458481006,-40.632160120173076 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark56(-62.84093068065197,100.0,-1.1102230246251565E-16,-17.070144220248437,15.303573584532746 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark56(-64.0506206980582,-44.043263324041355,-0.019688112057993534,7.807900189482798,-0.201168610282279 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark56(68.31065516248589,18.551327574631703,-6.324865175563407E-12,-29.613881440325258,73.98924197940012 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark56(-69.24308865653059,82.60824292182478,-0.0617044209050435,-2.583104450363118,0.5180771418756107 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark56(79.31096635551118,64.26417737735242,-0.05213766141688403,-13.68136880905628,0.11481280482367495 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark56(81.06861397090768,14.495033302959285,-1.1102230246251565E-16,27.377304777994645,-27.22193989554117 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark56(-87.41118627513296,20.816642869929368,-2.4805405839231456E-18,-0.009006827725046842,1.5798031545199436 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark56(-89.98052149770778,74.78155292251901,-0.0513696451069805,28.27705300970814,-26.77705300970814 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark56(-90.091891604929,12.458260225307653,-0.028746795357285415,100.0,-98.49824842336257 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark56(90.73614555646509,-4.560113135289287,-0.030145160991567,-45.84601788082614,0.03426243759879175 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark56(-90.85658627143287,-100.0,-0.021796589181024006,-0.058481366325942474,26.859774753552387 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark56(-91.09903001571085,34.38464115034046,-0.025356600251843997,-50.68299052886442,100.0 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark56(9.388011191854552,-0.8915741637152621,-0.0517102286023996,-0.20551022173502967,7.6433975572279325 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark56(96.13775351208864,34.40412740116148,-0.053404782067569406,-8.51532273708377,7.0153227370837685 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark56(-9.63007128173741,21.021310676457944,-1.3368412215072106E-4,-53.74614302227301,53.74611371117047 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark56(97.57233976148196,-134.39213738084698,-1.1102230246251565E-16,-70.66469286623877,62.46516578766623 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark56(99.77903295185727,0.09113539187132602,-0.03969614375983893,33.571645132898254,-46.3243550986291 ) ;
  }
}
