import org.junit.Test;

public class Sample10Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark10(0,0.004262368592207949,-1.5707963267948966 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark10(0,0.0,-1.5707963267948966 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark10(0,0.06237516430124401,-1.5707963267948966 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-1.0663561288353236 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark10(0,0,11.92693999170531 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark10(0,0,12.548331046040204 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark10(0,0,14.983042049077255 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark10(0.0,1.5707907940935346,-1.5707963267948966 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-1.5707963267948966 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-20.739633488842173 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-22.94000461771762 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-2718.318327613134 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-2722.3266473673357 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-27.8424128103771 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-2.9674667015647174 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-3.6062680916063385 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-48.51348896476888 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark10(0,0,5.937436045961505 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-5.946964571513718 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-68.58228382265305 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark10(0.07941953156763688,0.8144843584261661,-2.377370234155481 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-91.37035957496622 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-94.95558721368799 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark10(0,1.570790794093071,-1.5707963267948966 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark10(0,1.5707907940935257,-1.5707963267948966 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark10(0,1.5707907940935348,-1.5707963267948966 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark10(0,-16.51441623101057,-68.0435918479904 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark10(0,-19.9121204727916,-1.5707963267948966 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark10(-0.23519128441787984,0.5070567598844227,-1.5707963267948966 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark10(0,2482.689943848875,-1.5707963267948966 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark10(0,2587.608588880186,-1.5707963267948966 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark10(0,41.71567316501148,-1.5707963267948966 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark10(0,41.72435005318577,-1.5707963267948966 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark10(0,4.440892098500626E-16,-1.5707963267948966 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark10(0,52.175771741487594,-1.5707963267948966 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark10(0,64.25271960729059,-1.5707963267948966 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark10(0,65.74119454986383,-1.5707963267948966 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark10(-0.7668943221113125,0.3474829325495563,-1.5707963267948966 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark10(0,84.38052517967334,-1.5707963267948966 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark10(0,-92.25717815694982,-44.579680155828804 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark10(-100.0,0.0013166703049862908,-1.5707963267948968 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark10(-100.0,0.029649067252271514,-1.5707963267948966 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark10(-100.0,0.08698238253065647,-1.5707963267948966 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark10(-100.0,0.5234285727630092,-1.5707963267948966 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark10(-100.0,1.4210854715202004E-14,-1.5707963267948966 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark10(-100.0,1.5063505998114124E-12,-1.5707963267948966 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark10(-100.0,1.7631994206368648E-4,-1.5707963267948966 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark10(100.0,-1.8508215627936868,-1.5707963267948966 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark10(100.0,6.123212428316163E-17,-1.5707963267948966 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark10(-100.0,-6.613795280641584,-1.5707963267948966 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark10(101.26736283965423,0.005994594751363719,-1.5707963267948966 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark10(-10.266525793628034,0.12001567425647755,-1.5707963267948966 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark10(-11.953396790284344,1.3104245938424928E-6,-1.5707963267948966 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark10(13.583471505534765,0.35850407201019774,-1.5707963267948966 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark10(-1.402757983365378E-191,1.5707907940935257,-1.5707963267948966 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark10(-1.4210854715202004E-14,1.570790794092801,-1.5707963267948966 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark10(-1.4210854715202004E-14,1.9532037868607998E-12,-1.5707963267948966 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark10(-1.4210854715202004E-14,3.8918746072168843E-4,-1.5707963267948966 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark10(1.4210854715202004E-14,4.974718794041516E-13,-1.5707963267948966 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark10(15.561225388239837,-0.0032035829897965546,5.288354280716704E-4 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark10(-1.570790794093536,2.8104190483296038E-11,-1.5707963267948966 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark10(-1.5709425071518963,0.013874351064820871,-1.5707963267948966 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark10(-1.5709654664459571,0.014888910407621483,-1.5707963267948966 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark10(-1.5715178143389577,0.557731251771144,-0.05607847388690304 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark10(-1.7372102294321523,0.44127745096644266,-1.5707963267948966 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark10(-1.7455513535072893,0.45128806092742835,-1.5707963267948966 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark10(17.94914975365692,0.45011543723509817,-1.5707963267948966 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark10(-1.859760064906219,0.5649336050921749,-1.5707963267948966 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark10(-18.832224873548498,2.1002664774736113E-4,-1.5707963267948966 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark10(1.8991135491519597E-65,4.5105882566153456E-8,-1.5707963267948966 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark10(-2099.098161371904,5.770822486539373E-8,-1.5707963267948966 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark10(-2.5269841324701218E-175,0.07652690459422816,-1.5707963267948966 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark10(-260.3308148526191,1.12294952617981E-4,-1.5707963267948966 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark10(2.7769123979218846,6.661338147750939E-16,-1.5707963267948966 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark10(-27.998178861609333,-19.880173669896806,-34.84387044756738 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark10(2.8706583674491647E-12,-3.4846791868207063,1.544012382038927E-8 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark10(29.589357945176584,0.3737140498864243,-1.570796326794893 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark10(-34.08449870509736,96.54990458878768,32.74309714582 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark10(-3.552713678800501E-15,0.1591975580082104,-1.5707963267948966 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark10(37.14461926565531,3.263470316682092E-9,-1.5707963267948968 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark10(39.37662689670255,-1.5514338261648133,-1.5707963267948963 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark10(41.100151749083345,1.5978639569493553,-0.36477620392066357 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark10(4.15425302386671E-10,5.116108010440104E-10,-1.5707963267948966 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark10(-44.24260941226044,6.167554486136717,-0.08700691416304866 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark10(-4.440892098500626E-16,0.3444832851756498,-1.5707963267948966 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark10(-4.675371201301459E-12,0.25966131597879044,-1.5707963267948966 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark10(-49.26592086010001,0.25126171417636395,-1.5707963267948966 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark10(52.8715970489977,0.19787272885975143,-1.5707963267948966 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark10(55.03202072222507,10.195381029683631,-75.77506766885686 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark10(56.33344833181975,1.4155252768917028,1.4100409562479015 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark10(57.21441916729707,-87.14337692590313,-0.08610299996457002 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark10(59.47544544638026,5.956005921119594E-13,-1.5707963267948966 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark10(-62.09227978123658,4.348878299159827E-7,-1.5707963267948966 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark10(6.254015016660976,0.17450728598717546,-1.5707963267948966 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark10(-6.3108872417680944E-30,1.2179718348874592E-12,-1.5707963267948966 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark10(63.97255025399456,0.2842048953364239,-1.5707963267948966 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark10(-66.16446307175227,0.8063009979545459,-1.5707963267948966 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark10(-7.010994667411602,-0.44686369216116106,-1.5707963267948966 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark10(-7.105427357601002E-15,0.10562293360484659,-1.5707963267948966 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark10(-71.66533918065119,28.275368969881413,-39.65653041051853 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark10(-72.35850605912177,-90.75875701133069,-50.25532858714037 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark10(-74.32081456984123,40.6264418681933,29.030161524887433 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark10(-74.5169727117883,0.14286375538805984,-1.5707963267948966 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark10(7.55363693838392,0.11361129335772457,-1.5707963267948966 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark10(-80.26862748487666,0.04124628911799455,-1.5707963267948966 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark10(-83.3554606197259,15.542804154940711,-48.503987651569844 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark10(83.59893267845379,1.6364853511772441,-0.328318485083255 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark10(-85.30043539847222,0.32585023118392265,-1.5707963267948966 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark10(87.7553945013814,-3.627213433333793,-94.47204562091672 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark10(89.85579237330214,0.06196168162184062,-1.5707963284137563 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark10(-91.57467238163153,1.263530289163422,-1.5707963267948966 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark10(-9.521272659185342E-13,5.057485412046003E-7,-1.5707963267948966 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark10(-98.62962257947522,0.11189056831381335,-1.5707963267948968 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark10(99.36517101644415,0.009556793072217042,-1.5707963267948948 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark10(-99.99999970677283,12.322891446506283,-6.004764928765356E-16 ) ;
  }
}
