import org.junit.Test;

public class Sample20Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark20(-0.008334633399427326,188.46615700011787 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark20(-0.009939660404939654,52.22204275229266 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark20(0.010433408618698278,-100.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark20(-0.015707963267948967,100.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark20(-0.015707963267948967,99.99999999999999 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark20(0.015707963267948967,-99.99999999999999 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark20(0.015707965346488145,-99.99998676761037 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark20(0.015777817815467308,-99.55726103358943 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark20(0.01605015106402754,-97.86800887596938 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark20(0.016175902328129974,-80.45979890834522 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark20(0.01682539260612237,-93.35867302278108 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark20(0.017011781284936522,-92.33579367645525 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark20(-0.017261498096647936,90.99999999999619 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark20(-0.01738745824169397,90.34076775110415 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark20(-0.01941851289474342,80.89169007478993 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark20(0.02026534965220011,-77.51143472742218 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark20(0.020633383529995806,-76.12887748203534 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark20(-0.023189455059925246,67.73752650658278 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark20(0.024137978149185963,-65.0757208033959 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark20(0.024486336751156256,-64.14991114261805 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark20(-0.028388981081357813,55.331197773293496 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark20(-0.03024100071940583,51.94260406160784 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark20(-0.03084724485318805,50.92177062395058 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark20(-0.0322116949815866,48.76478334011364 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark20(0.03856857731035812,-40.72735984412452 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark20(-0.04141105374703538,2.8421709430404007E-14 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark20(-0.042388858722588685,37.05682045074339 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark20(0.05119627277351002,-30.681849316336525 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark20(-0.05230503452986035,30.031455688995802 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark20(0.05480700950496953,-6.394884621840902E-14 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark20(0.06129347255713384,-25.62746506702979 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark20(-0.06281794156073328,25.005536440185637 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark20(-0.06399341036995843,24.54621995786394 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark20(0.06902775153757255,-22.75601177505969 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark20(-0.07438864991687232,-42.2321504302129 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark20(0.07812461787716282,-20.106291326310185 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark20(0.08169851777086892,-19.226742046903965 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark20(-0.08922521103174091,1.0568705292620761 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark20(0.08945466609278892,35.11938270867957 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark20(-0.11905104459785354,13.194309483809576 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark20(0.1205690610547965,-13.028187439238636 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark20(0.12157097545467188,-12.92081700356546 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark20(0.1336017059938288,-3.9734121268462994 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark20(-0.1520976976835806,10.327548350289035 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark20(-0.16217272647148878,0.35362938234560026 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark20(0.16548585935632637,25.026867369330386 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark20(-0.1791667402883803,8.767231709783855 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark20(0.1898843918140803,-2.000000000000014 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark20(0.19389382859743517,-8.101321935605304 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark20(-0.20709540883003155,7.584892082682956 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark20(0.21768032604516918,-7.216069340455469 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark20(0.25527931221638533,-6.153245686683077 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark20(0.26617223075007806,-4.622253132304737 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark20(-0.2667446036649555,5.888765152932184 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark20(0.273481066616776,-5.74371142480596 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark20(-0.28006635850174216,5.608657659556513 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark20(-0.2807982438518551,7.478413652328282 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark20(-0.28407027407012847,5.529724291850839 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark20(-0.2852989469071035,5.5057908338735135 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark20(0.28538989272249365,-4.00098325080939 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark20(0.33095004482545676,-71.19488861947869 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark20(-0.38848180038364677,92.99873373888656 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark20(0.4248935617793812,22.1815033423417 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark20(-0.4358286886360626,3.6041600008268047 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark20(0.49045917026041624,-3.202705591091018 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark20(0.5127071450697174,-1.4210854715202004E-14 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark20(0.6022429066566044,-2.1110576961935124 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark20(-0.6191195959274216,2.5371452254582465 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark20(0.6261618381120826,-3.1554436208840472E-30 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark20(-0.6594784864770206,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark20(-0.6775639831059408,2.318299623297456 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark20(0.7604045177748766,-2.0657377620419957 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark20(0.7850762407275061,-2.000820105496108 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974476,2.0000000000000018 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974483,1.2924419963881983 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974483,-1.423079093520812 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974483,-1.753752010761229E-15 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974483,-1.825111547402578 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974483,1.999999999999332 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974483,1.9999999999999396 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974483,-1.9999999999999716 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974483,1.9999999999999751 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974483,-1.9999999999999836 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974483,-1.9999999999999858 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974483,1.999999999999993 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974483,-1.9999999999999964 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974483,1.9999999999999982 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974483,2.0 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974483,-2.0 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974483,2.0000000000000004 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974483,3.730349362740526E-14 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974484,-0.732565671602103 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974484,1.999999999999968 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974484,1.9999999999999998 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974484,-1.9999999999999998 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974484,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974486,0.035075298098592 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974487,-1.999999999999999 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974488,1.999999999999993 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974488,1.9999999999999964 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974488,-8.791988207570069E-16 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark20(-0.785398163397449,1.9999999999999982 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974492,-1.9999999999999991 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974598,-1.9999999999999705 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633988667,-1.999999999996388 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark20(0.9196986507858327,-1.7763568394002505E-14 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark20(-0.9603570910301471,75.23933722929843 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark20(-100.0,100.0 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark20(1.0210185914276053,-0.23253598452191793 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark20(-102.90705741937398,0.003990910381690886 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark20(10.317568843230845,48.673978454254666 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark20(-10.408941927753313,0.15090835722761486 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark20(10.75028545351639,-0.14611670858294215 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark20(-10.846646343336857,0.14291040871776772 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark20(109.17034471224416,-2.95910629128225E-11 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark20(1.0950303629051064,60.72557714645009 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark20(1.0960280316387525,-3.944304526105059E-31 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark20(-11.11914437475781,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark20(-11.226345663216051,45.75401597923658 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark20(-11.277934940278328,16.53344004222012 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark20(-113.74824217237747,0.01380941188009273 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark20(-11.39317948739243,26.775999109953275 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark20(-1.176923801333986,1.3346627241410831 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark20(11.794680108117069,-0.1331783746906267 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark20(-11.849611115576238,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark20(11.939882401459641,-87.83480967032958 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark20(12.191203379224419,-0.1288467001930065 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark20(-12.451417589010276,81.00913470160788 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark20(-1.252513292223699,0.3648236303249348 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark20(-1.2862937387598734,86.703790466218 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark20(-12.947782592703305,3.552713678800501E-13 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark20(1312.923996737615,-1372.4054583875195 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark20(13.493210625426016,-56.34429368026902 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark20(1368.2995976938007,-1316.3227789561859 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark20(1.3684555315672042E-48,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark20(-13.711524653855381,13.174434557071805 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark20(-13.861438998193051,50.69558598868228 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark20(-1.4210854715202004E-14,0.3622730459659067 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark20(1.4210854715202004E-14,-100.0 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark20(-1.4548798058503536,1.0796742936965735 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark20(14.62528424510573,-0.10740278961214411 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark20(-14.73433690764439,0.10660787361119262 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark20(14.922565104523674,-4.48532369163186E-16 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark20(15.011487489898784,-58.001186654219914 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark20(-15.127886993262626,0.1038344831300279 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark20(-15.767870129525491,0.0996200700469726 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark20(15.776149804596589,-0.030520876278841147 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark20(15.969789174479047,-0.09836049240431421 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark20(-160.1907155301824,96.46936256565705 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark20(16.14229969879011,97.8577673341363 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark20(-1.6150146139591186,0.9726205033797584 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark20(16.43662259704621,0.0 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark20(-16.54332009794682,0.09495048862591053 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark20(167.2981577987608,-0.009389202770392261 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark20(16.791700945636507,-0.09354599226608332 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark20(-1.6947282568916222,6.048731274240771E-4 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark20(-17.36426742085419,0.09046142222552941 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark20(1.7427978639551895,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark20(17.459211989905256,-0.08996948589106513 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark20(-1.7763568394002505E-15,34.81151214725131 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark20(18.064157758141103,-0.0869565217391331 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark20(18.835260294257836,-0.08339658184993404 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark20(-18.984017113590653,-32.92329866604604 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark20(19.064726930430353,17.99075475586396 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark20(1.9399660176795308,-0.8097030115371749 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark20(-19.651025480646922,40.66084066856499 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark20(1983.652945413789,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark20(-19.848084068969055,33.47662393636546 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark20(-20.002649776205942,0.041908659961184536 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark20(-20.104699368160112,49.77733772883846 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark20(2.0128617852212543,-0.7803796258282256 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark20(20.43792811729365,-30.92498717414665 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark20(-2.0658805346265043,0.7603519663729656 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark20(21.064865222143453,-0.0745694933354556 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark20(-21.205750406954216,0.07407407409076028 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark20(-21.257423033120887,0.07389401454482329 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark20(-21.33209053930214,0.07363536751828749 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark20(-2.1660918098892097,0.7251753224971748 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark20(-21.707738225224716,0.0723611235080036 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark20(-2.18349382651971,0.7193958177104633 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark20(21.887192886691764,-86.12139537089745 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark20(22.01119922117789,-38.18916642571088 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark20(22.097333906462808,-9.860761315262648E-32 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark20(22.10840955022222,-0.07104972084159296 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark20(-22.17839219258685,0.029001752457403107 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark20(22.318848160684073,-27.80002554867373 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark20(22.630291433778126,-0.06941122837022817 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark20(-22.650206610954964,0.04585397797103376 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark20(-22.76559170911153,0.06899870413498688 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark20(22.77598314465139,-0.06896722379967923 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark20(22.932199268292393,-0.06849741310972934 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark20(-23.025839233854086,0.06821885234417036 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark20(2.308244654446434E-128,-2.2444127733846047E-190 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark20(-23.08726923681077,4.27039229305386 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark20(2.356194490190724,-0.6666666666671253 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark20(-2.356194490190801,0.6666666666671034 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark20(2.356194490192147,-0.6666666666667226 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark20(-2.3562749109135406,0.6663907004256778 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark20(-23.743082810988184,4.263256414560601E-14 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark20(-23.88259648462588,0.06577158927366256 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark20(-24.347343064992078,0.00368976268359833 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark20(24.50332659144314,-37.10311779242128 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark20(-2.456521339365772,-1.2788786334748048 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark20(24.569900026784296,-0.0639317345647532 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark20(-24.602276778477616,-0.12769519999620924 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark20(24.68547284545788,-73.60253080544354 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark20(-2.481194490190771,0.5732538037227215 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark20(2.4825346177633816,-0.17919764038148936 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark20(-2.4825346177633816,0.632738941707122 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark20(2.4825346177633816,-0.632738941707122 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark20(2.4825346177633816,-8.345652413795435E-4 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark20(-2.510405402564088,0.6257142074305939 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark20(-2.6061944901923453,0.5912079222085893 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark20(2.606194490193244,-0.6027164636812565 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark20(2.6061944902117617,-0.6027164636725825 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark20(-2.6061946042435093,0.6027164287829471 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark20(26.403293323408114,-0.05949243935423354 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark20(26.704720849009252,-0.002232024154931622 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark20(-2.709852181605129,0.5796612588161238 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark20(-27.21291826768963,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark20(-2.7357379668758313,0.5741764546948627 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark20(-27.450066011724285,0.05722377228980027 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark20(2.7558394510960085,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark20(27.59263017868817,-1.4210854715202004E-14 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark20(2.772221231561133,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark20(2.7850973943967148,-3.586886485006204 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark20(282.0290583945132,-0.00556962581726397 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark20(29.144961597909173,-0.05389598203854157 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark20(-29.198756352802917,0.053796685989418336 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark20(30.09645762139022,-99.99999999999999 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark20(-3.0098890362102395,2.1316282072803006E-13 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark20(-3.061616997868383E-17,7.511667700661175 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark20(30.630528372499732,-0.05128205128205256 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark20(30.63072637057183,-3.4988314338615663E-15 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark20(-3.0789276833033057,0.5101764277586724 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark20(31.99154748709404,-91.65940149230694 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark20(32.07498457172434,-0.048738193041219624 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark20(-32.07498457172434,0.04897262922394762 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark20(-3.22161920859998,0.48757976194136177 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark20(3.280873762796909,-0.47877377807301247 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark20(33.18659290309333,-0.04733225647421335 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark20(33.33229805458773,-99.99999999999999 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark20(-3.3549517159649387,0.4682023646778801 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark20(3.359522440720207,-0.32991879850360606 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark20(33.772121026083205,-0.043035303422614656 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark20(-33.77212102608905,0.009214366998243968 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark20(-33.86445788080245,0.04638480652263361 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark20(-3.395547269125771,0.4626047592025774 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark20(34.24224600755474,-0.045873051856713414 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark20(-34.48550342908692,0.04554946776476526 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark20(34.66414024482083,-0.04531473493070665 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark20(-35.11752106395612,41.152983681618196 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark20(-36.04950596399221,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark20(-36.06012341287065,0.04356048116669076 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark20(36.31409492305516,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark20(-3.654417459032008,0.42983494480430084 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark20(3.662918751502237,0.8576746777307876 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark20(-36.658312292973214,3.552713678800501E-15 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark20(-36.67600778390804,0.04282898880515831 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark20(36.91371367292233,-0.04255319392353408 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark20(-37.00350224412263,96.92608657856346 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark20(37.040053807251105,-0.04240804656950556 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark20(37.57405887028966,-0.04180534054671847 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark20(-37.92926669237158,0.04141383326851449 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark20(37.948434487546336,-0.04139291509667915 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark20(-3.828840282401669,-20.51269067052339 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark20(38.414586750290624,-16.135599429593668 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark20(-38.5323463505435,0.004779142902491519 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark20(38.62463002418111,-39.976895283375285 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark20(3.888729460510959,-0.4039356151529514 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark20(-38.9635942027025,25.94818980251128 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark20(-39.3124322188801,15.969502383108903 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark20(3.9332341426389927,-0.3993650695152806 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark20(-41.12747885204312,9.739305013376224 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark20(-4.122910232296363,0.38099212408025096 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark20(42.1231716238887,-0.0372905521174971 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark20(42.31144727076003,-1.9184653865522705E-13 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark20(-42.38722860575239,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark20(42.87438704503967,-43.480471258797884 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark20(-42.948618420374395,0.03657384997627133 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark20(-43.259728171418075,0.019740848902158357 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark20(-44.036668096409215,8.132803365712391 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark20(44.21846501806593,-0.03552353810004782 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark20(-4.440892098500626E-16,7.105427357601002E-15 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark20(-44.48952023247721,46.82112177272276 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark20(-44.49725573536859,86.66388335925623 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark20(44.641355186083516,-0.035187021546437644 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark20(44.65068444348511,-0.01847074613726831 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark20(-4.4888255467692094E-190,3.3265311250063677E-111 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark20(-45.2105909184503,0.03474399017761698 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark20(-45.33958654623758,0.03464514007407168 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark20(45.56236606192774,-140.3507411733829 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark20(-45.62444276557254,24.746225553593163 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark20(45.77757135242774,-96.7417011509694 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark20(-45.91508124081047,11.421778837512164 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark20(46.32760962557239,-0.03390626754737269 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark20(-46.59264629629775,0.03371339581796917 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark20(47.19494695303368,11.52819728530055 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark20(4.745762874055927,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark20(47.78294783967331,-0.03287357515206906 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark20(-47.843057838110894,7.105427357601002E-15 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark20(47.93492716069098,-88.18231643984686 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark20(48.22017202216311,-92.25380869510131 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark20(4.873173450355338,-91.41104799747572 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark20(4.884981308350689E-15,-56.2971329675384 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark20(-48.8875196319855,8.83597674254125 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark20(-49.49493245074614,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark20(49.53075411444627,-67.48433370131647 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark20(-4.96307022220563,0.3164968973775313 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark20(-4.9E-324,51.9213325513351 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark20(-50.131993211413196,0.03133321111255327 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark20(50.95274758555289,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark20(52.016455178035706,4.529709843025074 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark20(-52.773273687478664,-53.10483865347819 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark20(53.04414447076752,-43.73603723095096 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark20(53.15988637330608,-59.53004820852239 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark20(53.893223694787366,-167.4918196541587 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark20(53.93732092517979,-46.124284022839475 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark20(-54.15345285422101,8.673617379884035E-19 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark20(-5.451015286990842,10.357282455204391 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark20(54.701579818131734,-1.5063505998114124E-12 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark20(54.905321625754624,41.21135389607289 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark20(54.93916784853755,-63.45559715672504 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark20(-55.368988067932804,78.79624463715251 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark20(5.555267053100016,-0.2827580225721711 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark20(55.76326857240981,-0.02240814135066164 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark20(55.836853482770664,-0.02813189191041232 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark20(55.854046279429134,-0.028123232450097634 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark20(-55.889609728789864,0.028105337189100958 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark20(5.597333284113822,0.02227730522835605 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark20(-56.11554601197357,36.71376351620833 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark20(-5.622787143667602,0.001641137851646167 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark20(-5.624127271353175,0.27929601358700407 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark20(-56.92008995388909,0.027596518699590872 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark20(57.196250848916065,-34.92859002341278 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark20(58.032775443666594,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark20(58.20015541117866,-30.227923599183782 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark20(5.8208011900194805,-7.815970093361102E-14 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark20(-58.336936634934574,40.897944661767866 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark20(-58.61182462390373,1.5393935003114905 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark20(-59.07318513112035,0.02659068278286192 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark20(-5.925456937735646,80.13694306858991 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark20(-59.38992151109757,-76.12685987216628 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark20(-60.55334533244439,0.02594070266755793 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark20(61.05271205177036,-26.313229846994915 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark20(-61.601827365950236,0.025499183935948265 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark20(61.70785571134937,-95.72929130762671 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark20(62.09799343227894,-70.31121910045081 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark20(-6.217248937900877E-15,4.712256653088247 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark20(62.279913826460124,-0.025221555880309054 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark20(-62.36513992206909,1.3735553780462482 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark20(-62.79272187052972,0.02501557951307909 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark20(62.95298870771763,-17.929936016309043 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark20(-63.456821252806584,5.498243574288452 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark20(-64.52490982941686,4.357581240245855 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark20(65.31438768955924,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark20(65.4018460643934,-49.62986063099084 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark20(6.561681695512171,-0.2393892906858366 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark20(-66.60251439685302,-28.747647245637253 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark20(66.62248131225525,53.76017734912031 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark20(66.76191533543474,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark20(-67.1249601322422,36.01425672618261 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark20(-67.4370245065264,3.552713678800501E-15 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark20(6.747006683667535E-80,-3.458065414261291E-223 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark20(67.72187840987465,-35.41107878159018 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark20(67.81246326229858,-0.023163829349762105 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark20(68.06584235828882,-39.57902577807337 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark20(68.09619283465692,-1.857783178061366E-5 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark20(68.17213111630846,-0.023041619809639823 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark20(-6.843708499434115,64.91730130898137 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark20(-69.27666659647227,63.21303718078829 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark20(-6.942243343005998,0.0285108044112333 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark20(6.979248390146936,-0.2250666889879565 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark20(-6.9947097824794895,0.22456919238156914 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark20(70.19587635650043,0.02237733052604641 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark20(-7.0481305063852915,0.22286708870839228 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark20(71.6658376312027,-0.021918341830850032 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark20(-72.7296189227691,0.021597752745864243 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark20(-73.7143795712643,0.661451408595326 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark20(7.426922042270576,-0.21150031168425582 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark20(-7.606838769991242E-12,100.0 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark20(76.17938781112525,-43.36519085598041 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark20(76.60315079764804,-91.4141252929593 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark20(77.04164845960153,-0.020294960559036596 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark20(77.2750429812005,-80.5005738574844 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark20(7.768177116161084,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark20(-78.12186608919853,29.73825234380657 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark20(78.17467105932157,-0.020093417797727903 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark20(-78.76633886187321,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark20(79.19887437557124,-7.985302968492391E-4 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark20(79.2096841570442,-0.019830862141560553 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark20(81.27103992278828,72.18037855145997 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark20(-8.159771340793057,0.1925049442184772 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark20(82.47417425795786,-3.9234590249750387 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark20(8.290866665650071,-63.65891372849648 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark20(84.29455889291927,-14.826962802156544 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark20(-85.58778408466416,42.06517576681842 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark20(-8.584938453295308,0.18297118090485043 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark20(-8.639379797371928,6.975254663921238E-6 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark20(86.65980074046118,-11.29374586412672 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark20(86.78667402838266,-0.01809951060321985 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark20(-87.17919591248908,0.018018018064443607 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark20(-87.47625784430174,0.017956830407523192 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark20(-8.765719924942967,0.1790593310822694 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark20(8.765719924942967,-0.179197640381502 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark20(8.765719924942967,-6.142171937728591E-9 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark20(-8.76571992494297,0.14421657121298675 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark20(87.68893572706546,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark20(8.881784197001252E-16,-3.606490048160211 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark20(90.72418932737865,-59.0060260819713 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark20(9.25476382194465,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark20(9.30822044175713,-0.16875366635584044 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark20(93.47811038948497,-0.01680389473268161 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark20(-9.356944569447094,0.1678749206150011 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark20(94.50885128936912,-71.65065331943839 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark20(95.04598031522633,-97.11013159510516 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark20(9.543122594406356,-2.7711166694643907E-13 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark20(95.5759790079388,-69.34120428958039 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark20(95.69553276834645,-12.160196598613695 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark20(95.9077730308503,-0.01637819623118164 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark20(96.27485783261021,-0.01631574807958674 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark20(96.60397409788605,-0.00468243805858242 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark20(9.702931797901188,-0.1618888352007865 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark20(99.0401521980198,-82.17535679853043 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark20(-9.945246775363955,2.0179413695586845E-12 ) ;
  }
}
