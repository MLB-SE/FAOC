import org.junit.Test;

public class Sample01Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark01(0.0027835001581410037,0.07465727154716373 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark01(0.005959247909406167,-6.392425774347915 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark01(-0.0059819494816762495,-10.176121370164434 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark01(-0.010975320656640211,-1.5707963267948974 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark01(0.015530327112741382,-1.5707963267948966 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark01(-0.017337429850290357,0.0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark01(0.023976022072020986,2577.964513174238 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark01(0.02472929310180305,-44.07975827546417 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark01(-0.03224184043302824,0.33482337807701534 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark01(-0.042590580689065405,3.4706651991480366 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark01(0.04541137378862958,-12.498837606195728 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark01(0.04823144352262738,-0.3117868867700868 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark01(0.05374280064342418,47.43420116453575 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark01(0.05600535422294328,-61.89165442198958 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark01(0.06660939808898649,43.61538540178903 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark01(0.07264605748245344,-70.70328506978333 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark01(-0.07473129754420185,-65.66018224729967 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark01(-0.0764635681307535,-74.93452382161519 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark01(0.08282310616133093,-19.31837706151382 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark01(0.08729933105454979,1.5707963267948966 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark01(-0.09287384413818121,1.5707963267948966 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark01(0.12728105561546688,-27.245822025098448 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark01(0.1299654458668016,-25.027507489380117 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark01(-0.13278323491971378,15.32470251412117 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark01(-0.13384719198842654,-1.5707963267948966 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark01(-0.13464179779607832,77.78062464859548 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark01(0.13582668835994385,-107.53372695898425 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark01(0.14388055565664848,-48.09430522649869 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark01(0.14494713148669983,19.39372096077836 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark01(0.15805103876963886,-31.984618454493344 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark01(-0.1770609419222069,16.476826277129774 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark01(0.17818039597632884,-14.627181498528216 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark01(-0.17967997038926897,0.0 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark01(-0.18163755983188795,0.0 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark01(-0.1943263434214071,14.910912614388266 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark01(-0.20022789391806498,0.0 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark01(-0.20907763701109078,0.4781778966664968 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark01(0.2094009276336095,-36.61497322026986 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark01(0.2266084115248279,73.58531074782283 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark01(-0.2291920796986715,0.0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark01(0.23163355302642863,95.64503556549252 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark01(0.24321295863750336,-1.5707963267948966 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark01(0.2467338553396638,76.0133196252391 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark01(-0.26757840086678825,-6.123233995736766E-17 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark01(0.2744483893401366,-0.8506720505536308 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark01(0.28168571427093336,-44.16109927284036 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark01(0.2924689063104379,82.4603145200769 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark01(-0.29717626191042656,1.5707963267949054 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark01(0.3000646468963018,-78.59913219026757 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark01(0.3056784488490345,88.133883576696 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark01(-0.32885032604245645,1.5707963267948974 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark01(-0.3389313490681094,43.4928960439222 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark01(0.3391457936618451,-96.06553604704371 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark01(0.34272641992798214,10.589658980823339 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark01(0.3568323798623201,0.0 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark01(-0.3590222443704413,0.0 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark01(-0.36430790381794126,21.930868893676376 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark01(0.3811600784792758,99.59685229652575 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark01(-0.40448816758200223,9.735299498721629 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark01(0.4057272610418099,0.054798788749878646 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark01(-0.41670274400974006,90.64675097728373 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark01(0.4181348633870665,4.440892098500626E-16 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark01(-0.4195904083900679,92.96216578236246 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark01(0.42625233034863186,0.0 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark01(0.4302742020783512,-91.336529297915 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark01(-0.4363329735554755,84.7134476053414 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark01(0.43938905050406996,42.45880522075005 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark01(-0.46578321152357405,-59.86517376455953 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark01(0.46923377076272743,84.15744961282664 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark01(0.49004657711348654,1.1763954686668852 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark01(-0.4904968625359465,-1.5707963267948948 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark01(0.5062608830616045,-0.40625002627238216 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark01(0.5151510001315269,-100.0 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark01(0.5340841918618477,-77.77846307553185 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark01(-0.5443228611305094,-100.0 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark01(-0.5619251977953452,-1.5707963267948966 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark01(0.5653303816851858,-0.8664984073889296 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark01(0.5687224950775057,0.0 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark01(-0.5781667486289601,0.0 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark01(-0.5854679891286814,-45.52017732138078 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark01(0.6231231438557621,0.17639384518812135 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark01(0.6236211751189353,-1.5707963267948948 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark01(0.6428361052042764,-1.5707963267948966 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark01(0.6558797484682373,-1.5707963267948966 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark01(-0.6715102293975503,1.570796326794893 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark01(0.7064891764292016,0.0 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark01(0.7138260951856485,74.92883523548045 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark01(-0.7493826488800993,65.70160886564346 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark01(-0.7495132669021132,0.27630012088984 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark01(0.7827407634586804,-70.82190259169045 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark01(-0.7846933861635093,4.517472846339896 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark01(-0.7937572517589668,1.5707963267948966 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark01(-0.7984480869939663,6.645466504963417 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark01(0.8277664530000663,81.46533792690491 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark01(0.8636842518794657,23.567898513991455 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark01(0.8686429588420995,0.0 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark01(0.8725568486340187,-100.0 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark01(-0.8812451025648667,-42.56436219827449 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark01(-0.8984254627319359,53.77954927210834 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark01(0.9290981764931837,46.02505670167027 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark01(-0.9293282201825355,-95.67415170949195 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark01(-0.9504850490185217,1.5034515155193557 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark01(0.9564677281130738,18.164099370513995 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark01(-0.9967144333592202,-54.965912728383046 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark01(0.9979462696922914,15.615793031063447 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,0.0 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,0.5706476723653627 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,-100.0 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,100.0 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,-1.570796326794896 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,-1.5707963267948963 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,1.5707963267948966 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,-1.5707963267948968 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,1.570796326794897 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,1.5707963267948974 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,-1.5707963267948983 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,2608.7343299294266 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,2617.0200465442063 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,-30.41340654056273 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,36.128315516284346 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,36.64457934790548 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,-60.9980015682103 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,-6.429359112734013 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,-65.98960153475436 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,69.71481817223335 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,70.33872829613487 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,78.47322804389546 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,-81.81988444507662 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark01(-1.0011682821972363,-45.90246053515528 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark01(100.53096494573452,0.0 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark01(-100.53097274014661,69.11513659256258 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark01(-100.53097312724844,-25.1327412287113 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark01(-10.066938501796358,0.0 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark01(-10.083287608230563,92.41521290020003 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark01(-100.95148604304153,1.1363870142114845 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark01(-1.0145790866045434,-66.4136334628167 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark01(101.82067326748185,7.712599042040546 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark01(-10.190105797471432,-74.11524413703611 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark01(101.91750586546839,19.704219579390777 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark01(1.0204994236913683,41.340204227387545 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark01(102.09913140102941,1.5707963267948966 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark01(1.0217502047245572,33.97455838046318 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark01(-1.030529542167464,-61.26273205503008 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark01(-103.4699235932407,11.689054946613474 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark01(-10.355851629424407,-0.15651808490324015 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark01(-10.35743532122787,43.43874444455841 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark01(-103.67272635902305,-0.018547958016880445 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark01(-10.373471085377098,-27.86638785446825 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark01(-10.382033895502255,0.0 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark01(-1.0408632414192038,1.5707963267948968 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark01(-10.424777960768695,-1.5707963267948966 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark01(-104.40000751703447,74.11488201662262 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark01(-10.440599432943557,0.0 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark01(-10.451479825700389,0.03376994081075441 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark01(1.0453389844003178,1.5707963267948968 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark01(-1.0463243488492824,-17.25319567411804 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark01(-1.0463591778179904,-2.755645611702022 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark01(-10.498013915131192,-28.471934930715676 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark01(1.0500672747223765,-78.05517559394055 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark01(-105.24463568187089,1.5707963267948966 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark01(-1.0526163416938563E-16,-1.5707963267948966 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark01(-10.585431581894518,44.54538740057093 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark01(-1.059575479865708,-0.017802497492236898 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark01(-106.81415031051048,86.39379790123162 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark01(-106.81484107721394,76.97097313794994 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark01(-10.70351972501939,89.81011353861322 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark01(-107.45477390954633,-95.54997063864121 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark01(-10.747026679148437,-0.5080263594993593 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark01(-10.894971804148536,-0.5707121401711813 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark01(-10.929065950114692,65.52801892218957 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark01(-109.5110117689247,-68.79226655712252 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark01(-10.995527249777652,1.5707963267948966 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark01(-109.95574230785687,-6.203582300812905 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark01(-110.25011563027736,-23.033278482131607 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark01(-110.97096072748406,-6.52114366045393 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark01(-1.1102230246251565E-16,105.24335389525805 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark01(1.1102230246251565E-16,-12.319344680795636 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark01(-1.1102230246251565E-16,-125.66357814362148 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark01(1.1102230246251565E-16,-2.429209542158039 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark01(-111.07691043160531,29.629274501383804 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark01(-111.31471585029918,-111.54889115294529 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark01(-1.1133517652920121E-9,133.51817708222617 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark01(-1.114879110560488,-11.91228587519511 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark01(-111.52488957303366,-54.97787090593362 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark01(-111.5264463829884,4.71238546473753 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark01(-111.75293131533927,1.5707964468286315 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark01(-112.03173645585187,0.0 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark01(-112.6246474059264,-50.98778611959665 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark01(-112.72611547274279,115.81806569175498 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark01(-112.83718767188367,-4.392262668759982 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark01(-1.1285756039706193E-6,56.546504083530316 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark01(-113.00513497796832,-54.97258625138316 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark01(-113.02379199625625,-95.27710450401392 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark01(1.1302748277287833,100.0 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark01(-113.04389901442826,-18.20737204021726 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark01(1.1305170121234998,-63.159441823550026 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark01(-113.09801490418592,-7.611391867378565E-24 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark01(-113.1054591619913,-81.68141009720442 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark01(-1.1324440824873676,73.88510405243008 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark01(-113.60064328557475,-20.37197335133631 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark01(-1.1372883873126507,0.0 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark01(113.99955082240723,-1.5707963267948972 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark01(114.11250006805668,80.26161852129336 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark01(-114.15619404886961,33.77407857354197 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark01(-114.1622312640856,1.5707963267948972 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark01(1.142115914673198,59.649876419876904 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark01(1.1453613929197406,25.048908155386357 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark01(-1.1480994702976197,-48.36580051060524 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark01(-11.520694275482569,2.7781078893929276 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark01(-1.1555215650434518,-1.5707963267948966 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark01(1.159607308864889,78.98144350347152 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark01(-116.2331820696611,-4.712388980382411 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark01(-117.39514229602034,131.73233981052613 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark01(-11.741284057078644,0.45822954612777084 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark01(-117.81235435026751,1.5707963267948664 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark01(-117.82283708279651,-86.39379797370749 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark01(-1.1806118627027695,0.0 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark01(1.1810776537878014,-2454.015441365293 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark01(-118.25103189452977,1.5707963267948966 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark01(1.1855070693698337,68.59945018613857 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark01(-119.09797064654296,-73.9099017753515 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark01(-119.17505295641588,0.0 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark01(-11.963883105285213,-51.271938459127746 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark01(120.23940248364717,-14.979159964430224 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark01(-12.032050561033968,-0.02558756462449823 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark01(-1.2035358676158736E-6,5.551115123125783E-17 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark01(120.95007389630769,-54.97787072505152 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark01(-12.095754000095397,100.0 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark01(-12.107441087496465,0.0 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark01(-12.138507019143631,-46.72732058863922 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark01(-1.2185329755819794,0.0 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark01(-1.232595164407831E-32,0.0021833198416577144 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark01(1.2344005621173074E-8,48.374051797269416 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark01(1.2376901863616925,0.9976650672283379 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark01(-12.464325647385557,95.31214370043071 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark01(-12.483854582036003,-1.5707963267948974 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark01(-1.2486227242657293,0 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark01(-1.2507640434954001E-7,43.984879438349644 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark01(-12.539443634965153,0.0 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark01(1.2559108688118954,1.5707963267948966 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark01(-12.566370614830843,-73.82742732622478 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark01(-12.566370948986194,6.224319416822087 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark01(-12.56637156405869,-0.0022439632074938223 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark01(12.566384141011158,-6.289000524886524 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark01(-12.568323741439162,-69.11503837897715 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark01(-126.00965761066328,28.64668738426721 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark01(-126.13581438012434,-63.03119834859603 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark01(-1.2629255394543146,-1.5707963267948968 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark01(-126.53455678056532,93.5995714570112 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark01(-12.666917769830661,109.15206917984997 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark01(-12.683786463348977,-6.9096620610716855 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark01(12.709365941865585,1.5707963267948966 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark01(-12.714492771153031,-30.53425791207836 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark01(1.272672027290764,0.0 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark01(-12.800055150436913,-79.8432165758037 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark01(-12.833152763822516,15.513041764646758 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark01(-1.283362069516913,-44.48846162303907 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark01(12.896585474800652,24.146370287489248 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark01(12.900020964840612,-69.94824537422897 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark01(-12.909620081430504,-96.26544679232205 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark01(12.915025823127115,96.13754848440831 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark01(12.968072524070479,40.67274600446883 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark01(12.99409608427027,-2329.384420878316 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark01(13.0156637854871,11.113482417971724 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark01(13.039777848318252,0.0 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark01(-13.099201528862594,72.73193209323671 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark01(13.124120901059232,4.739334049683061 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark01(-13.187530054419419,-54.21049013163437 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark01(-131.9503473055268,-31.415926536294684 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark01(-131.96068530349652,-6.224436650423285 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark01(-13.252927367728844,11.341456604233947 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark01(132.73948147377615,46.7174062072493 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark01(132.76101206893975,135.2433678073362 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark01(-13.301917180877233,-1.5476503923640699 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark01(-133.21715810590584,-14.48418817425064 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark01(-13.3294699718938,-17.15571205835912 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark01(133.51765589004188,-186.92475936853762 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark01(-133.8974262830307,-27.242128562263957 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark01(13.432954566889336,0.0 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark01(-1.35433891717979,1.5707963267948966 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark01(-1.3552527156068805E-20,1.5707963267948966 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark01(-1.3552527156068805E-20,17.278759296537704 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark01(-13.616103276864873,97.73778783028021 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark01(-1.3618068138529156,0.29495768835177977 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark01(-13.624289663258565,-1.2528372951800435 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark01(1.3670199031584644,1.5707963267948966 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark01(-13.670305170499873,2638.7518546590227 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark01(-13.72641873338579,1.5707963267948966 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark01(13.780369348417864,0.5504013240562938 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark01(-137.98204416270866,74.2165803793427 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark01(-13.806259311343112,-1.5707963267948968 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark01(1.3814976323476884,-1.5707963267948948 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark01(-138.23398530725717,150.79644730342352 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark01(138.2775814424748,-24.265476413914186 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark01(13.851764998450049,-73.8678894441332 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark01(1.385371408500302,67.56138400581997 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark01(-1.3877787807814457E-17,50.26811229807557 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark01(1.3882559783639876,1.570796326794897 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark01(13.888465149276122,7.119245654631108E-11 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark01(13.893265839973209,4.484575452984851E-10 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark01(13.921786969985302,96.42516623266118 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark01(-139.33032870836388,-20.90366900958599 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark01(-13.982223505577156,97.07263845681268 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark01(-139.83898335723538,-1.5707963267948963 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark01(-14.009274952214975,-3.062028647223166E-6 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark01(1.40222952810422,30.302965068192606 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark01(-1.4035402928536613,-1.5707963267948966 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark01(-140.5742925708506,-87.08649415005473 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark01(-141.1726352169598,0.0 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark01(-14.132711845613471,1.5707963267948966 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark01(14.134537100515162,1.5707963267948966 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark01(14.135015633777698,10.995574195691525 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark01(14.135055959505854,-1.5707963267949043 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark01(-141.36909808864402,-10.995574286547457 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark01(-141.37098222688647,6.442160573707817E-8 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark01(14.137166941158288,1.570797423637698 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark01(-141.4247959064407,-73.77300410081749 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark01(1.4175545328794035,-79.95276178827463 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark01(-14.211220226318133,1.5707963267949019 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark01(1.42167115716029,61.89461155965958 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark01(-142.34844581329963,37.13997725700277 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark01(-1.4271319922832362,-15.632401186014661 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark01(-142.9426368654528,64.40655564859077 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark01(14.318940330754355,-46.462829059551744 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark01(-1.4401812647611116,1.5707963267948966 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark01(-1.4445205175464053,-1.5707963267948966 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark01(144.57321029974952,-44.3302067868293 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark01(-14.474514928466121,79.10113430224314 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark01(145.18893043929106,-81.25258016996679 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark01(1.4590425730624408,-1.5707963267948972 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark01(146.0847646497776,-86.39379756945678 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark01(-146.21820313696406,1.5707963267948966 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark01(-146.40407178464702,14.626487330516753 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark01(-14.646241399255024,-11.70237248822879 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark01(146.49145732515015,4.83800325501656 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark01(146.9998644655745,-1.5707963267948966 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark01(-147.65323502627575,-75.39822368615256 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark01(-147.6548525066279,-182.21223563330813 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark01(-147.65485389083642,138.22777971091386 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark01(-14.868535178338945,-41.32545690313447 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark01(-15.0496424377088,-96.11965196158638 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark01(1.505768409186181,0.0 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark01(-150.80427703499845,-1.570796326794898 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark01(-15.10686801181561,-71.87153719537476 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark01(15.164027203321794,0 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark01(151.7625745115261,-35.77394690967756 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark01(1.5184076192439495,-2.6185391816665913 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark01(-1.5190395731926927,24.49001775460049 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark01(-152.02705998068362,44.95732407157675 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark01(-152.37963520334807,1.5707963267948974 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark01(152.4720412174089,-55.32559833497861 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark01(1.5287653144163567,-23.562825460007144 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark01(-15.29637410658191,0.0 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark01(-153.49073222709234,19.411933383427364 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark01(1.537937117533355,-2536.710520320661 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark01(1.5394045142529578,-99.15448358749413 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark01(1.5397687404417335,136.4298541516933 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark01(-154.25944966963775,1.1512685725971548 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark01(-154.28409802679545,-1.5707963267948966 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark01(-154.92038065749716,63.31477433686803 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark01(1.5545899332687934,45.3520270403256 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark01(-1.555823945518279,-74.7442923857271 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark01(-1.5579424451013615,-0.1857684520125673 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark01(1.566756945028042E-5,-37.69294080170747 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark01(1.5681664861559768,1.5707963267948966 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark01(1.5681664861560431,-1.5707963267948966 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark01(1.5681664861567342,-1.5707963267948983 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark01(1.5681664861647866,1.5707963267949197 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark01(1.5681664873828833,-1.5707963267981526 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark01(1.5684599088473472,0.0 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark01(1.5685597916556964,10.995574239479293 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark01(-1.5688923569767126,45.230374630512195 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark01(1.568904339942565,29.84512957409219 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark01(1.5691663310348252,-1.5707963267948966 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark01(1.5702124741618109,-86.39379463629216 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark01(1.5704330700662612,-61.26105329767252 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark01(1.5704459192133764,0.570791962205977 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark01(1.5706635637288404,36.12831200612349 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark01(1.5707279344429543,14.137170459371301 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark01(1.570767618672631,-1.5707963267948966 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark01(-157.0775285671116,-0.057949018020106165 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark01(15.70787916898388,-0.07634028972415638 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark01(1.5707961381587732,32.99062911302379 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark01(-15.70796210810058,251.32605799143886 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark01(-15.70796240301472,-31.418191956252503 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark01(-15.707962733606495,0.0024983028166339857 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963115101444,-193.20793129211353 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark01(-15.707963261654031,10.99557428740362 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark01(-1.570796326571088,-58.896315866965224 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark01(-1.570796326682437,81.73768359353728 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267804148,-83.23270142148817 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267947989,-69.50087571792136 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948024,-10.83074371005604 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948166,107.35799308238316 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948308,0.0 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark01(1.570796326794847,1.5707963267948966 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948895,1.5707963267948966 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948897,73.82742383712065 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948906,-1.5707963267949054 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948912,-14.429511941193425 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948912,-152.36773198035863 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948912,-67.24341640454298 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948912,-73.82742383712065 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948912,-75.84258980755143 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948917,0.019560184372725838 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark01(-1.570796326794893,107.79029436474309 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark01(1.570796326794893,-13.457192965137281 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark01(-1.570796326794893,142.9856233574217 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948941,6.123233995736766E-17 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948941,84.48146840278997 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948948,0.0 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948948,-0.5651373948292525 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948948,-1.519918791764966 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948948,-1.5707963267948966 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948948,-16.705686134717578 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948948,22.776756873693465 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948948,2572.2517468830756 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948948,-2590.7763376093167 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948948,-35.304329121096984 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948948,-37.407336917027 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948948,-4.2162995217645523E-11 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948948,-4.231168251046281 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948948,43.982297150257104 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948948,-4.9147796143649655E-9 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948948,49.59537885429805 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948948,67.50653286469964 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948948,80.11499624788976 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948948,88.68508680475031 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948952,0.0 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948952,-97.3893722612836 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948957,0.0 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948957,12.967743694475445 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948957,1.5707963267948966 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948957,1.570796326794897 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948957,-2518.203298767516 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948957,-78.9017604353635 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948961,1.5707963267948983 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948961,-2595.2426937162513 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948961,73.70183491166455 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948963,0 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948963,16.70433134198741 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948963,-20.467071993255104 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948963,2497.9316883425554 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948963,-57.26303193852104 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948963,-58.40163822477037 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948963,69.11503837897546 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948963,-85.20774654898787 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,0 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,0 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-0.023451132075463413 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-0.044613189283012084 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,0.044794029331005465 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-0.04933093521472604 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,0.056826676244211845 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-0.1415292168121253 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-0.1912310953675807 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,0.21317085234559308 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,0.22378306503072953 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,0.3071664793688621 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,0.3088571666565448 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,0.3408887367453196 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-0.3534177270581575 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-0.3555155717125845 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,0.37786561813063835 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,0.497762264750989 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-0.546113124839812 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,0.5687686024230608 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-0.5701835318776226 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,0.5707936236519001 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,0.5707960056664773 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,0.5898531189522398 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-0.6305574609004454 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,100.53096491487118 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-10.141812746330416 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,104.4390264835787 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-10.922231113281773 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-10.99557076532479 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,10.995572441979368 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,10.995574287564269 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,10.995574287564276 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-1.1190111398501064 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-11.246937161473781 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,1.2422535079671868 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-12.566370614361457 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,125.66414841881598 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-135.2851958303326 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,135.6465129428101 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-136.12501870520006 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-14.137166941154064 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-14.137166941154067 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-14.213050991348581 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,14.429206327398497 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,14.429284633901595 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-149.22565152269016 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-1.5448157801496722 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-1.5707963267560536 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-1.570796326794762 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,157.07963267948324 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,1.5707963267948646 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,1.570796326794876 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-1.5707963267948961 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,1.5707963267948963 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,1.5707963267948968 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-1.5707963267948968 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,1.5707963267948968 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-1.5707963267948972 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-1.5707963267948977 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,1.5707963267948977 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,1.5707963267949019 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-1.5707963267949054 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-1.5707963267949054 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,1.5707963267949205 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-1.5707963267950105 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-1.5707963267953886 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,1.5708001414921624 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-1.5708001414929433 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-1.5752766275095382E-6 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-1.649327635874073 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,17.060290548215484 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-17.278759598469154 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,17.33427355085798 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,178.91796750665907 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,18.04581681349537 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-18.21853292578224 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,18.349181534402675 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-18.84955592153876 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,18.849555921539274 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-18.969464477742434 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-20.420352248333657 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,21.408202539976937 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,21.78283552920319 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-22.820624428154467 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-23.303859771371272 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-23.56194137968396 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,23.561975610619246 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-23.56243318317345 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-2.363864416562933 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,25.026123465323998 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-25.1327412287158 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,2.534402789880767 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,2544.121924404125 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-2546.37601714283 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-2559.5309597374107 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,25.713218459567926 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,2602.7434960262735 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-2623.926344115729 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-26.243501681820536 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,26.56233119676799 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,27.400448839214164 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,28.286603452092734 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-2.865933735772302 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-28.69701011583407 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,29.845130212882655 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,29.962783149877396 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-30.75803323262758 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,31.41592653590342 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,3.181744026669905 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-31.915990779081426 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-31.97378587205597 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,32.48149302806693 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-32.50672070386473 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,3.2865914073342104 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,32.88383782892059 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,32.95013254343045 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-32.98672286269282 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-33.5849902523141 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-34.45718460537016 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,35.976883199435946 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,36.12831551628192 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,36.12831551628262 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,36.56195789925769 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-36.68566619757796 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,37.32321733365514 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,37.70210521968225 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-38.167731578828224 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-3.8285686989269494E-16 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,38.4667525089248 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,39.26990816987241 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,40.597040664219975 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-41.386047991275014 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-41.647549529527566 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-42.411497302818994 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,43.870251532266145 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-43.98229715025991 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-43.99835818254691 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,44.311114835654934 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-44.40648229728558 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,45.156089258606734 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-45.5340817084009 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,45.55309347705188 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-45.553093477051995 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,46.76584302771123 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-4.70752115976293 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,4.712385458145202 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-4.7123889803846755 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-4.712388980384689 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-4.712395720785908 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,47.33930458773398 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,47.3513733804256 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,47.359215161547866 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-4.809491892220268E-12 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,48.694686130639866 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,49.48143272257926 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,51.83628220938924 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-51.898778784231595 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-51.98333123571282 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,51.9837691329163 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,53.8000610928859 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-53.89485419610066 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,54.90326869001916 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,5.541721005057056 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-55.766844969191645 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-5.598828150486674E-4 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,56.94491243871914 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,58.59483851646931 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,58.75359710061031 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-59.369691687820854 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-6.028178799562336E-5 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-6.063938983563977 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,61.05935471550852 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,61.26105322276148 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,6.253125936601824 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,62.83185218026755 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-6.283185307135389 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,63.32069110651432 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-63.76755602386082 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-64.29728902948747 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-65.04438407945226 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-66.08850888184688 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-6.66464170218093 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-67.54424020170522 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,67.54424205218054 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-67.54424205963115 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,69.11503837897455 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-69.80309624020646 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-70.68583900810536 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-70.87413725321373 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-71.574221580342 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-71.67363555680679 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,71.92529909777991 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,72.34183617757554 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-72.47193515362241 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,7.280545234547155 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,73.75346687948765 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-74.2807500533142 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,74.59885026518066 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-7.526974316173608 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,76.96902001294991 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,7.709389697209871 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,7.790971784570219E-16 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,7.815699018435993 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,7.853981633974478 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,79.24887624630674 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,80.11060914929482 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,80.11061269634206 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,80.51367941407713 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,80.88304544370322 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-81.68140899333522 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-82.11965290292495 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,83.2522053273709 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,83.2522091348268 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-84.21644971448572 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,84.31916867152725 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-8.500704700098844 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-85.08787405174661 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-86.0826167816668 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,86.39379797371932 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,86.39380560669741 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-87.53233068834551 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-87.96459430051121 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-88.21687151441772 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,88.33343041112134 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,89.53545166246536 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-90.79641346347438 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-9.173953648566265 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-92.67698328089888 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-9.317269944516902 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-93.24464820797446 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,93.3780989396659 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,94.24777960771193 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-94.30436528391874 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,96.0829486197681 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-97.58520782302473 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,9.817993707431768 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,9.860761315262648E-32 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-98.96016858807839 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-98.96016859028957 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-99.99999999999997 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948968,0 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948968,0 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948974,47.68729710140579 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948977,-1.5707963267948966 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948983,0.0 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948983,-0.04980626845809704 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,-0.5671671856334647 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948983,100.0 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,-100.0 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,-102.13301124167776 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948983,-113.09733552923016 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948983,13.220556545649348 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948983,-1.5707963267948966 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948983,2575.422634638156 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,3.4347641368807262 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948983,-42.29482537713509 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,-77.66290376790758 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948983,-78.71912172897605 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267949054,14.429207255314104 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267949128,1.5707963267948966 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267949197,1.5707963267948932 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark01(1.570796326984669,2496.692093209036 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963272745535,205.85231117887028 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark01(-15.728335430833809,44.184490491918005 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark01(1.5734261674338093,-1.5707963267948966 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark01(-15.736136695771748,-24.706939214069905 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark01(-1.5739419832189536,-2414.3548515864113 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark01(-15.782382076517376,-45.39744613762103 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark01(15.793239272083497,-11.746084333184854 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark01(-15.843302141652487,1.5707963267948966 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark01(158.58963427196164,-4.743638980385053 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark01(-158.61331776723802,-2602.167030864912 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark01(1.5950190190425306,-0.4580605218060026 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark01(-15.97830199309658,64.0622930343223 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark01(159.7868629225976,-44.93538588384664 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark01(-160.31351923271455,-1.5707963267949765 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark01(-16.042029613439396,88.43968312980023 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark01(16.099087190230648,82.04234776766822 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark01(-16.12163919952365,-1.5707963267948948 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark01(-161.2334547571429,-75.14731736746818 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark01(-1.6202607015498696,0.0 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark01(-16.232043333886992,-10.742324794238385 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark01(-16.251187640037987,-1.5707963267948966 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark01(-16.275678881437884,17.375971883505674 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark01(-16.341452456200983,-0.8197123664047831 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark01(-16.386642045210536,-47.63948860052567 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark01(-163.91967292984933,-0.5709665614157302 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark01(-16.549840336411965,0.0 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark01(-16.559603266003077,-52.84757070946111 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark01(-16.679553132426662,5.624255300003434E-6 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark01(-16.67988174573688,1.570796326794897 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark01(-166.85746918677745,-111.52654240274259 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark01(-168.06844098396584,76.9690201321605 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark01(-16.839587556797166,-12.861471105196124 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark01(-1.6865481597748637,72.72184984885679 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark01(-1.6940658945086007E-21,-67.54423288239866 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark01(-169.64670124906544,-56.548667764608545 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark01(169.81703441900356,74.99134894104087 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark01(-170.48394588547242,1.5707963267948983 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark01(-17.183349208678706,2558.020961427953 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark01(-17.187871475904515,1.5707963267948966 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark01(-17.219651960088953,37.28486841667356 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark01(-17.263185444613427,0.0 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark01(-17.276562524599314,-89.53539154285352 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark01(-17.2777000348911,51.83628171913809 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark01(-172.78401237994132,80.11061266653141 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark01(-172.7848330903812,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark01(-17.27875959482432,-48.694682608415576 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark01(-17.281212605162573,-73.82742690567585 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark01(-17.341159073164107,63.1732983787648 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark01(-1.734723475976807E-18,-1.5707963268240006 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark01(-17.416608704724126,16.559355325896234 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark01(-174.25985288498927,5.322582374085438E-16 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark01(-175.4026311903892,-31.633072978638623 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark01(-17.549533086286814,31.62703037593924 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark01(-175.6765845236964,32.71174177421386 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark01(-175.69836408484682,-43.29225588001059 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark01(-17.6196321197545,46.417819196393594 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark01(-17.7520357325676,-1.5707963264533673 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark01(-1.7763568394002505E-15,30.126491276861856 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark01(1.7763568394002505E-15,81.69286556777894 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark01(1.7763568394002505E-15,81.8784982941637 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark01(-17.788445617753062,51.50122230691787 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark01(-17.90274769709916,70.72267278836105 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark01(-17.916107271500707,1.570796326794845 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark01(-179.24539693909117,-93.84651466272635 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark01(-179.53627916957765,5.296109493521907 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark01(-17.98406198757985,0.0 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark01(-180.10160570369894,0.0 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark01(-180.26690204656583,-100.0 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark01(-180.5053678826198,4.743638980384691 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark01(-18.14926378938748,44.16359091090342 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark01(-181.6851659118459,95.29857887444257 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark01(18.171939346269838,0 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark01(-18.365372455829544,0.18169140541282713 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark01(-1.8446175516218503E-15,45.555046602052 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark01(-1.845376632697631,0.44669658946485985 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark01(-1.8505603434947025E-11,-56.54603793095006 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark01(-18.678807149893117,0 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark01(-1.8839159990443635,1.570796326794897 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark01(-18.849556058320534,-11.483837333107964 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark01(18.849579664966306,0 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark01(-18.85053248403968,-161.79202045901687 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark01(18.858144608895696,0.16205914352907913 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark01(-18.861049783154577,75.37809659395224 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark01(18.88937548001122,-1.5707963267948912 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark01(18.903248234462957,73.57917576863927 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark01(18.940460454523816,7.173704609718842 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark01(18.952215799488457,-61.63384636436759 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark01(18.988095311576743,0.0 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark01(-1.90182708753981,-15.75014693811778 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark01(-19.208441198412366,-10.301748812504087 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark01(19.225910543997756,43.544221917136895 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark01(-19.23978221431622,-31.61407158319494 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark01(19.334292922133763,0.256856847287676 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark01(19.36560861682561,-69.86357654926903 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark01(-19.378669999419863,92.33445038719317 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark01(19.417048000598115,0.0 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark01(19.49763395860725,-111.93407130297766 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark01(19.56291363774296,0.0 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark01(19.56601223053923,-57.907318494241395 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark01(-19.56763427362027,31.13794664552359 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark01(-19.621894984649053,72.30659328212994 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark01(19.63891054615834,1.5707963267948968 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark01(1.9697741493265681,-88.18551181211413 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark01(-19.75181422592594,0.0 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark01(19.771074659379394,39.76862485700201 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark01(-19.786213716455435,0.4323893185705151 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark01(-19.789937782079743,77.60135772429209 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark01(19.93335041931074,-80.11061266653972 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark01(19.984027294955325,0.0 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark01(-19.991534771860486,74.4080697512739 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark01(-19.993652815628053,57.54616277843374 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark01(-20.239248017337957,-45.052497430420715 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark01(20.24476123777795,-95.8031997536457 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark01(20.346231728621447,0.270177908856218 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark01(-20.35968375430162,0.0 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark01(20.393428303488832,1.5707963267948966 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark01(20.40783352245188,-64.64610430439193 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark01(204.15034604122116,-88.24422149990932 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark01(20.417722407698022,-1.5707963267949052 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark01(20.42040771446595,-58.119467610747044 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark01(-20.456395521979914,0.0 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark01(20.47480505617047,0.0 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark01(20.557185185545904,-92.8290791933332 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark01(20.560070598688448,-81.67863064865463 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark01(-20.562129871494463,0.0 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark01(20.599899345813014,-1.5707963267948966 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark01(-20.603256808957198,0.009055209209828224 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark01(20.61280301417432,0.0 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark01(-20.63888592218767,67.06060912803186 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark01(20.64449332095751,15.842833043222903 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark01(-20.65873172269464,-0.8628896530177167 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark01(-20.667727376281647,-29.339291190687277 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark01(20.670648399942316,-13.52457274054764 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark01(20.67235291575396,43.80494371217941 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark01(20.682180226474816,-1.5707963267948974 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark01(-20.705156676511308,-66.34672734135742 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark01(-20.71671911369546,0 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark01(20.716921835858813,100.0 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark01(20.71999307768398,-45.20417355840235 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark01(20.723254007381087,14.654812429824247 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark01(-20.751876122615837,-21.927281807625945 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark01(20.759123018634156,-0.4306865198365025 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark01(-20.775095470233993,-19.788588361301432 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark01(20.799458623298733,-1.5707963267948986 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark01(-20.814898277185485,-25.926662067030556 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark01(20.822375578233622,163.8895527411873 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark01(20.833689244876027,1.5707963267948948 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark01(20.85123424683343,49.79388343122595 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark01(208.91591241224623,-80.11052854905697 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark01(209.2152442638677,-48.73916700453913 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark01(20.960772916735905,-96.27743100799859 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark01(20.977626140835444,1.5707963267948966 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark01(21.036685472751678,-44.12941894510645 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark01(-21.098525155082832,-0.18229723540897658 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark01(-211.0778753523736,-95.36000271888463 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark01(21.308333718118593,-1.5707963267948948 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark01(21.42234012118098,0.0 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark01(-2.1431908072173655,-47.602605698149716 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark01(21.476568032601975,-69.5994616207799 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark01(-21.48317676325695,-73.66806747178568 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark01(-21.48660662105425,-37.82514158306954 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark01(21.486902521904117,-67.69455175359873 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark01(-21.51782002426131,0.5707945354246707 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark01(-21.528191990613067,-128.80565513396866 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark01(-21.54067379820274,32.70406083982604 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark01(21.569825565687832,3.713309633484535 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark01(21.572796432718675,19.451095781815255 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark01(21.578563150692336,-14.43076114622422 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark01(-21.629963598562195,1.5707963267948972 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark01(21.645191325630726,-0.812590152611328 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark01(-21.663460286178697,-16.50818838097007 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark01(-2.1684043449710089E-19,136.65927892190825 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark01(-21.710680296985416,86.39379797371932 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark01(21.71846395275246,38.818017724719894 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark01(21.72160712902904,1.5707963267948966 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark01(-21.728499128660868,96.7358750145134 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark01(21.817607388628346,1.42215843489776 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark01(21.828633717699987,0.0 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark01(-21.850446475764535,0.0 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark01(21.881150734364663,51.73622295091244 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark01(21.885717406962016,-2516.9244672599316 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark01(-21.89250033831949,136.69304244316524 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark01(-21.925392320036025,-15.370597228862053 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark01(21.957762247712317,-95.53319993309997 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark01(21.98845004440703,-65.74367877986116 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark01(-2.1989681059405193,89.63965278643738 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark01(-21.991014828274206,67.54424205216998 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark01(-21.991072079011495,95.83420093449047 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark01(-21.991141952145178,17.27875959474385 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark01(-21.991145052889067,0.0 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark01(-21.99114505373045,18.84953269840313 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark01(-21.991145065248368,87.96445978836908 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark01(-21.9911465549735,-0.0017089394857479083 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark01(-21.991147648672385,-5.212388491808541 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark01(-21.99114810811799,12.563922989259476 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark01(21.9911485585519,-0.0026360791030527286 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark01(-21.99114857512854,88.08959916643185 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark01(-21.99114857512855,-155.50169703348575 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark01(-21.99114952880315,0.0 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark01(-22.030845847484088,14.731747502038345 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark01(-22.116713957857304,-43.476449924112465 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark01(-2.220446049250313E-16,0.0 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark01(-2.220446049250313E-16,106.81620276271698 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark01(2.220446049250313E-16,1.327680571772952 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark01(-2.220446049250313E-16,31.45754406886637 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark01(2.220446049250313E-16,-49.918707555925224 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark01(2.220446049250313E-16,-52.21696725968604 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark01(-2.220446049250313E-16,68.98054679934737 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark01(-2.220446049250313E-16,-7.808385020086938 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark01(-22.25869702864245,1.5707963267948966 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark01(-22.290042052684136,119.93322275320014 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark01(-223.03182108240924,-69.11503837896983 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark01(-22.365298460557852,-42.103673442980515 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark01(-22.54278676471534,-1.5707963267948966 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark01(-22.55667827901948,43.14580306640724 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark01(2.2654160217596058,-39.05535576662245 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark01(-22.665780169942778,0 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark01(-22.69926818547273,36.1283159143701 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark01(-22.735857962061573,-89.5156842388144 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark01(2.276748869269113,13.094762069019879 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark01(-22.79861278094289,0.0 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark01(-22.92770537628219,-37.935474605183764 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark01(-22.947756724279376,37.797953087271736 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark01(-2.2958874039497803E-41,1.5707963267948977 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark01(-22.970992291610727,16.091786667776688 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark01(-23.21104701878127,3.0453663301302214 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark01(-23.42436221816044,25.477513735195565 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark01(-2.3503346015487017E-16,-0.021748461952350757 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark01(-23.54967247631518,76.22822501071246 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark01(-23.560728147655837,-42.411498071310135 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark01(-23.561944901917,155.50836104367002 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark01(-23.563016892925052,42.411497902109446 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark01(-23.564113049595868,-92.676982162106 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark01(-23.564574742562325,1.5707963267948966 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark01(-23.74631475289945,-19.36286259971247 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark01(-23.7658814125663,-0.5444926279692434 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark01(-23.865170353169773,-5.239188525139625 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark01(-23.881303654225405,-89.0423681795858 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark01(-23.919936524219167,-68.1852994367477 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark01(23.96023104188363,11.974739273351304 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark01(-24.187632138190068,-2665.906055495348 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark01(-24.25761322643936,-89.67922017079319 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark01(-24.297552595053837,-174.61994097447382 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark01(-24.437262215629378,0.0 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark01(2.4477669444011028,-1.5707963267948966 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark01(2.465190328815662E-32,0 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark01(2.465190328815662E-32,0.0 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark01(-2.465190328815662E-32,4.712388980384689 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark01(-25.0544102577681,18.284517559890332 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark01(-25.132741228718345,0 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark01(-25.13274122880739,-1.5707963267948966 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark01(-25.13275650050221,207.34252060036923 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark01(25.18423328522961,-1.3998512411554707 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark01(25.189388182865287,-19.980860098228824 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark01(25.24640083499406,-2629.4455092947123 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark01(-25.34624232752495,-2590.168930499757 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark01(-25.352281222674804,87.20866279889714 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark01(-25.36841401936121,-89.60885488724878 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark01(25.383154373595772,55.519801368289876 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark01(-25.396591760991047,0.0 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark01(25.401688468398607,38.729055224221256 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark01(25.431058226838175,1.5707963267949698 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark01(-25.432276512496298,-1.5707963267948966 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark01(25.448795982036422,-99.72052652212824 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark01(-25.506498623076325,10.895944454701631 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark01(-25.536207718177366,-17.95761191880574 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark01(25.560896027160695,38.61552289277418 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark01(-25.582580598636852,1.5707963267948966 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark01(-25.595864119331154,73.33186370888077 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark01(25.71407310400543,-24.911336611874788 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark01(25.774286003750667,45.08264861500467 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark01(25.793754773606466,-111.55460673133517 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark01(25.81721619623933,0.8495303862198149 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark01(25.87015867616871,2.252107306026872 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark01(25.957069532708168,1.5707963267948983 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark01(25.9683649797457,2.8036946252444987E-15 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark01(-26.083988213778397,87.34321486454142 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark01(-26.129488579949264,-86.91432896551107 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark01(-26.168040095268875,1.5707963267948966 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark01(26.175570324401352,53.68720679435598 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark01(-26.17644034063609,34.91165385965289 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark01(26.26230251544261,-58.02354207702638 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark01(26.265261747740738,-49.36177431301816 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark01(-26.337720148593817,0.0 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark01(2634.5212603900964,0 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark01(-26.379174210352588,122.77481401773889 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark01(-26.39230874014672,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark01(26.398607417593098,5.231419131166206 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark01(-2640.8294651219044,0 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark01(-26.4322080165366,0.0 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark01(-26.434554674996363,-0.5707958691610086 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark01(26.43727036899633,1.5707963267948966 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark01(26.497639835160953,-1.5707963267948968 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark01(26.508517769663605,-2.573886370692527 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark01(2653.4659695441546,0 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark01(-26.59972235035343,8.166637781112357 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark01(26.64817348736357,19.857258691827084 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark01(-26.692163107040006,-73.82753768042755 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark01(26.700907714998202,-1.5707963267952252 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark01(26.702985875739405,10.995570931059028 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark01(26.70401754478198,1.5707963267948966 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark01(26.705190424379644,45.55309379472313 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark01(-26.715127749940244,1.5707963267948983 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark01(26.717045814827355,-45.8641174372273 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark01(26.774352272019225,0.019522897517724624 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark01(26.8147325061109,-17.252670057793715 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark01(26.81544992920131,-4.718643113608283 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark01(2.6845682700993905,42.36730331875077 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark01(26.8523501307192,-4.665594925648236 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark01(26.867762289658344,0.9755474856013548 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark01(-26.873371947103237,0 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark01(26.88758891157454,0.5036753417130303 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark01(26.90144504347749,-1.5707963267948966 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark01(-26.9331838523581,1.570796326794897 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark01(26.954024711526458,65.06979541874925 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark01(26.973757440647223,53.3916114854552 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark01(26.978606453677443,0.0 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark01(-27.017092942335296,32.98672286269283 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark01(-27.038513930244452,71.71274547583013 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark01(-27.044609944369952,1.5707963267948966 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark01(27.04836929731517,1.5707963267948968 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark01(27.07616836419035,-65.800077052689 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark01(-27.088735410410948,-45.21625613051898 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark01(-27.125417004432975,-24.665863048127008 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark01(27.13463056239449,-1.785737490391739 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark01(-2713.6457561435614,0 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark01(27.139584925924368,1.5707963267948983 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark01(-2.722784675939806,1.1477005922077113 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark01(-27.29297527805891,1.5707963267948966 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark01(27.378420139794542,-82.9030149152633 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark01(-27.385037818681084,-87.54824545370124 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark01(-27.38790074549631,-19.649679565983675 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark01(-2.738931623333457,-69.46638040532437 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark01(-27.524458973278684,-14.280231372672441 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark01(-27.531377570959307,0.0 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark01(-27.531950137848995,0.0 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark01(27.548499050739366,0 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark01(-27.70659007767913,89.97378408228619 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark01(27.736259066608994,0.0 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark01(-2.7755575615628914E-17,-1.5707963267948977 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark01(-27.767808718083078,-16.605287230790168 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark01(-27.789135454806704,16.848703590623586 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark01(-27.800387127661423,0.36782821912518565 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark01(-27.848951820491862,1.5707963267948966 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark01(27.862960709235214,99.69080880062651 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark01(-2.7893798056843543E-14,1.5707963267948966 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark01(-27.950539771139294,95.71911078398367 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark01(27.954834973834608,1.5707963267948983 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark01(27.96523353095013,2734.2076377820445 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark01(-27.983316776967058,39.62043372875297 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark01(-28.005516130640217,-71.43114684774672 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark01(28.03183390012643,-16.868033586012217 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark01(28.050695987529366,0.22035451703111594 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark01(-28.066997162648335,0.0 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark01(-28.07730235007032,-57.15195819600978 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark01(-28.157761207224723,25.801133056176983 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark01(-28.161200401109348,-36.467045421514044 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark01(-28.17515070718852,11.15833049711853 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark01(-28.1904489648541,2579.0753183517027 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark01(28.206326587815283,-1.5707963267948968 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark01(-28.274330360730985,1.9321410386804445E-5 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark01(-28.27433036091647,0.0 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark01(-28.274330361545402,-3.504387504003095E-5 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark01(-28.27433055356878,4.384136971874382E-4 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark01(-28.27433272776398,25.13489300861951 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark01(-28.27433370653217,-6.224829844368411 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark01(-28.274333881249255,180.64021370748907 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark01(-28.274333882307012,-180.60787574249403 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark01(-28.274333882308134,1.5707963267948966 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark01(-28.282861772317005,-0.38772537510227634 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark01(-28.364367821272076,0.0 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark01(-28.369036338776702,-50.70386612480744 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark01(-28.37632255529915,-44.43746338405516 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark01(-28.38538285800693,1.5707963267948912 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark01(-28.450002711384492,1.5707963267948983 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark01(2.849965597184617E-10,6.42924726285688 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark01(-28.69980388546263,-2613.349780202577 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark01(28.73511740705942,48.16672850760176 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark01(-2.8822448447882062E-6,37.70021894091078 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark01(-2.8975349488405584,-31.641393684705676 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark01(-29.017719067476747,5.4513503956833165E-15 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark01(-29.067927673032234,-29.845130209103047 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark01(-29.17806899788677,-62.383415118865045 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark01(-29.398312415034383,17.143324971976142 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark01(-29.506197740631578,-3.6954226184579255 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark01(2.9548706404058454,14.429214328248996 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark01(-29.63710780247625,16.98769318684118 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark01(-29.84593673206544,-67.5442412685441 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark01(-29.847115402448853,-1.5707963267948966 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark01(-30.10594128246771,1.5707963267948957 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark01(-3.0201767029045907,-114.27313486795687 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark01(-3.0392134193694176,-0.5657093331589961 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark01(-30.432234324646345,-55.51808745280942 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark01(-30.619882394202683,-36.12839556814255 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark01(-30.789502318979864,1.5707963267948968 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark01(30.793533733896595,-7.092977231188485 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark01(-31.390402573208345,0.22641172260853118 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark01(-31.401405233887786,-1.3317219141594023 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark01(-3.1415048645354573,3.642007035945377E-4 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark01(-3.141570678502429,-10.995574287564267 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark01(-3.1415891313503055,6.938893903907228E-18 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark01(-3.141589189402986,43.981980117229945 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark01(-3.1415892422494105,6.283626921883332 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark01(-3.1415895380024272,6.284062922998961 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark01(-3.141592096820515,43.98229716242755 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark01(-3.14159256832932,-6.203309760443508 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark01(-3.1415926698246515,0.0 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark01(-31.415927602756817,-43.98216975716339 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark01(-31.415928443246568,1.5707963267948966 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark01(-31.416072350352025,42.41143721613483 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark01(-31.447176535898073,-1.5707963267948966 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark01(-31.447176535898176,1.5707963267950322 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark01(31.44812211755692,-30.014238518309845 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark01(-31.667726159419146,-51.59196706730176 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark01(31.67359953720694,17.126436187621422 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark01(-3.168682212160368,-82.5402941819904 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark01(-31.764373906968824,-49.234769099809974 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark01(-31.7652334298188,79.80273310962639 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark01(-3.17850468791093,70.2380150693801 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark01(31.921827306073897,44.758329359936454 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark01(-31.987155010484656,0.0 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark01(-32.01719166761941,-22.84710743073233 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark01(32.029471678587754,1.5707963267948966 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark01(-32.12337066641456,17.093914375059747 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark01(-32.12461682528094,1.5707963267948968 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark01(-32.154810217051065,-18.359127617987795 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark01(32.192684012314174,0 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark01(-32.25246830690787,-2618.018457567693 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark01(-32.301107509465666,-1.5707963267948983 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark01(-32.33863172726082,-96.5956024203372 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark01(32.40116467571107,84.52063433665631 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark01(-32.44101015755889,2571.030285562772 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark01(-32.46530783524491,4.528546482871498 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark01(-32.500802835399895,-79.59129376228049 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark01(-32.51515080802127,-1.5707963267948974 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark01(-32.54535968783745,95.70750416766697 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark01(-32.609308270352884,54.5102777029998 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark01(-32.613826724966046,36.45300020810984 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark01(32.61963471636639,0.0 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark01(32.622423335414446,0.0 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark01(-32.62313056741206,26.757360873457174 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark01(32.76615358059337,-94.40361587845727 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark01(-32.89702167225924,-51.06186207829609 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark01(-32.96283253911227,-1.5707963267948983 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark01(-32.968548359372605,19.944746412310394 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark01(3.3087224502121107E-24,0.0 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark01(-3.311517135539492E-5,106.81192215181476 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark01(33.22143478148676,-1.5707963267948966 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark01(-33.26848141383377,0.0 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark01(-33.29919574558954,-1.40860389772621 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark01(-33.41898336008073,-0.9875795412418427 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark01(33.45517172327655,-92.6769832808989 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark01(-33.57421015219608,-44.13519758481095 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark01(-33.7414526840447,-87.77041257669526 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark01(-3.3758593322704087,0 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark01(-33.93811590698522,94.11966801256992 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark01(-34.06174929069681,15.904842402316087 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark01(-34.12275722469337,104.41604799222273 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark01(-34.29099840619018,45.956309035534105 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark01(-34.40580981843165,29.98594542845845 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark01(-34.55751678976431,-42.411500818640775 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark01(-34.55751918920802,-92.67697978667195 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark01(34.574020102448486,0 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark01(-34.59439334327929,53.992907613946635 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark01(-34.626959238624146,0.0 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark01(3.469446951953614E-18,0 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark01(-3.469446951953614E-18,-10.995574287564274 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark01(-3.469446951953614E-18,-1.5707963267948966 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark01(-34.892666793361926,74.56310734423246 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark01(-35.015030173499454,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark01(-35.05974762339467,-1.5707963267948961 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark01(-35.12119622353199,26.219109821077257 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark01(35.16291703010464,0 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark01(-3.5175033741960107,0.0 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark01(-35.188782494563,-30.33076207316505 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark01(-3.5222394875855243E-6,0.0 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark01(-3.5222394876548633E-6,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark01(-3.522239487684392E-6,5.551115123125783E-17 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark01(-3.529946905415045,3.4210404662054543 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark01(-35.31048527188652,-67.37855330844316 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark01(-3.5318629904740533,-58.94637863865717 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark01(-35.40761757122522,0.16895748043180775 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark01(-35.444551385521905,124.31964722195448 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark01(-35.4749764063796,-7.487011810436937 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark01(3.552713678800501E-15,27.189348895605363 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark01(3.552713678800501E-15,-51.71732560950255 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark01(-35.76503439438547,15.066646027333988 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark01(-35.84025570317333,0.0 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark01(-35.84518330132612,22.11229111353788 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark01(-3.5849481165905122E-6,-100.53088999696418 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark01(-35.8519004738893,-73.57008306255256 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark01(-36.07363178233071,6.429219794635665 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark01(-36.126076139040045,-45.55309443714264 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark01(-36.126255596353715,-92.67698193067997 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark01(-36.1282408512412,-73.82742384174595 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark01(-36.12994102013266,-64.40265155988405 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark01(-3.615048797604217,-1.5707963267948966 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark01(-36.21034042454707,0.0 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark01(-36.25668437685396,0.007717007879715184 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark01(-3.6573112030044843,136.24282272783415 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark01(-36.70009979690105,1.5707963267948966 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark01(-36.706962800471544,17.058089169763832 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark01(-3.6950754669669266,-1.5707963267948966 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark01(-37.311629575574166,0 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark01(-37.43032264632813,99.00381337903306 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark01(-3.7459149424283993,-1.5461055955877914 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark01(-37.55808654431296,68.23225265577194 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark01(3.756592883647495E-6,-0.0037912041068478173 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark01(-37.6476232306414,0.32504515796405953 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark01(-37.699113817054204,0.0017353798292737933 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark01(-37.699172878233774,-10.995573033265977 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark01(-37.69960162865137,6.20299048391639 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark01(-37.71473746118669,-100.53078415833332 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark01(37.71976103488333,-30.230019113725618 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark01(37.79405742439158,-10.971318690595169 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark01(-37.8507868368673,-11.604246457990428 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark01(-37.89022788510803,-13.702273444628489 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark01(-37.927622071098625,-4.712388980747843 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark01(-37.96108264959705,94.3169703723271 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark01(-37.97015149690132,0.0 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark01(37.998283798927844,-95.36437331673471 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark01(-38.046733921975864,-74.1950347718819 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark01(-38.075118861976435,67.54424205916976 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark01(38.10153962581771,50.250262430880014 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark01(38.206315454630925,-0.005455681586918388 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark01(-38.36017812086798,8.881784197001252E-16 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark01(38.361901783298,94.25849886736097 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark01(38.530052177180536,0.0 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark01(38.64675978219732,-17.19006629254273 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark01(38.750940151031756,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark01(38.78384562417128,4.049289832158152 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark01(38.87847842133647,44.14761526364566 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark01(38.91056564797262,-47.029181342812535 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark01(38.93818578851415,1.5707963267936904 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark01(38.956386090420004,-1.5707963267948974 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark01(38.973389338925344,85.17556806630246 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark01(-38.9853919454982,42.432099539121566 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark01(39.00174914931952,67.35031094386903 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark01(39.02962872633032,1.5707963267948966 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark01(39.103914603888256,-1.5707963267948966 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark01(39.262907818939404,8.720983869455438 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark01(39.26754206840088,-1.5707963267949054 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark01(39.26792598817018,45.55309498627328 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark01(39.26990687895366,-1.6332982020415434 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark01(39.29050933029134,-87.29310268114577 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark01(-39.378605554625736,0.0 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark01(-3.944304526105059E-31,-72.36807246577457 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark01(-3.9452475060355283,1.7082087017834512E-4 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark01(39.51291613962519,0 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark01(-39.517706978846576,0.0 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark01(-39.539029752376486,-1.5707963267948966 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark01(-39.54191610471895,75.40249060047998 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark01(39.869764234411775,-2563.126560928615 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark01(-39.89523717329006,50.98999775088805 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark01(-4.0329468322049345E-8,0.0026146014525972403 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark01(-40.432894309888034,0 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark01(40.54939835016277,-1.5707963267948948 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark01(-40.60179206234315,-2564.2578998905224 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark01(40.65656779517562,-46.31064173938415 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark01(-40.816983221096905,-95.77033759425548 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark01(-40.840700974427826,-1.9259299443872359E-34 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark01(-40.8407044966673,1.5707963267948966 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark01(-40.85665483250769,4.579677396394356 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark01(-4.086251692539804,-3.6027060155254134 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark01(-40.888016092734325,-0.30877769087410123 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark01(-40.9137039032178,0.0 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark01(-40.92979850447978,65.04642692182912 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark01(-40.9885601880577,-98.0318159756116 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark01(-40.9929161451013,74.52580378732837 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark01(-40.999318203906796,80.11890774041747 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark01(-41.03309830175865,86.53720410033597 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark01(-41.03607207351474,-11.93272247804593 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark01(-41.06376611500995,-97.1861471175617 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark01(-41.065835938146336,1.5707963267950333 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark01(-41.07374246219477,-100.0 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark01(-41.239319604662576,-1.5707963267948968 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark01(-41.24632694993205,-13.8561663022289 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark01(-41.2920076763082,-11.794087902229137 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark01(-41.323679506672775,-33.38904255673401 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark01(-4.141592653589793,-73.8274255959135 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark01(-41.753465644978704,-29.52873050641496 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark01(-4.218315564518556E-7,45.56093469151205 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark01(-42.25265037317871,2583.7458772914742 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark01(-42.288896480760975,-1.563291196720636 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark01(-42.40700544507165,186.9247628861101 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark01(-42.408870982826706,-1.5707963267949054 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark01(-42.40901765869748,1.5707963267948966 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark01(-42.40920741506648,1.5707971631185567 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark01(-42.41149658279565,48.694682608515706 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark01(-42.411524353330556,98.96016311467797 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark01(-42.41344802740096,10.995572708771988 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark01(-42.41380676565394,45.55309428424791 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark01(-42.48999401461919,87.96459430051421 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark01(-42.53650082346221,-1.5707963267948966 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark01(-42.53650082346221,1.5707963267948968 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark01(-42.536500823462404,-1.5707963267948966 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark01(-42.53653241921207,-47.929360300830055 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark01(-42.55444692008339,9.506810262443622 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark01(-42.580967432017154,38.709642104219114 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark01(-42.63747573032178,-111.55196516662836 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark01(-42.65652221139253,29.625384172774837 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark01(-42.73675893220655,-23.78527088302773 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark01(-42.84071332472311,1.5707963267948948 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark01(-42.850675462228146,-0.15293310067314458 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark01(-4.2868104815232355E-6,163.3626973364811 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark01(-42.89130131471666,-6.516743122944316 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark01(-42.91846018529307,11.024726040028 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark01(-42.928518463567954,43.32445441399767 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark01(-42.936565691927306,73.70878720145876 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark01(-42.95731214780414,1.5707963267948966 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark01(-42.971503585338695,-1.5707963267948966 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark01(-42.974305295096535,1.5707963267948966 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark01(-42.98149293937275,0.5185826076595822 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark01(-43.20277004114594,-38.96829929291991 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark01(-43.311536024736654,32.42316749972831 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark01(-43.315199998312806,-1.5707963267948966 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark01(-43.37090609510737,-1.5707963267948966 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark01(43.56970160906684,83.88317015649184 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark01(-43.57135931354965,-16.830558048333273 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark01(-43.725743828047925,-57.96648199219598 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark01(43.75090298271749,-51.27638949633615 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark01(-43.84955706619671,-95.6424496553508 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark01(-43.859619646474,85.75397261582972 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark01(-43.88828121087498,-2648.987819349009 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark01(-43.98230067249659,0.0 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark01(43.98278561744776,0.0 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark01(-43.98428714448969,-0.009876311673190894 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark01(-43.98437017314317,1.5707963267948966 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark01(-44.05766182128928,-10.964279624116301 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark01(-44.08757089782904,-0.035287462704914306 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark01(44.10769889037101,93.09946764077733 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark01(-44.16759110940678,-0.001107433448608247 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark01(44.33292415043639,-27.436645506732567 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark01(44.36188409208861,3.35376858208649E-8 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark01(4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark01(-4.440892098500626E-16,-10.055561044760708 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark01(-4.440892098500626E-16,2504.334120259618 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark01(-4.440892098500626E-16,35.717895327478786 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark01(-4.440892098500626E-16,-37.70174168371619 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark01(-4.440892098500626E-16,6.280977412008638 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark01(-44.4563356451942,0.4263804799510479 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark01(44.47518158544524,32.43185494221793 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark01(-44.51537292442478,1.5707963267948974 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark01(-44.52388340738123,-91.47392934429817 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark01(44.5514806614614,92.08328137052766 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark01(-4.46239960196824,-65.17902257229481 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark01(44.6400856888119,-14.111308266112552 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark01(44.640513849678086,-1.5707963267948912 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark01(44.70107016648821,-1.5707963267948966 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark01(44.84183135460614,-69.81779475995633 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark01(44.89559001433938,-37.12723434456684 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark01(44.92467764332977,-49.92982270103816 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark01(-45.006704307178545,55.82516408406704 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark01(-45.025722387293435,-96.93110745591102 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark01(-45.027089865292425,73.48948076046052 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark01(45.13443060638812,59.64616485283551 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark01(-4.515309523378448,-0.26380681117319177 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark01(-4.515708208319708,-47.11215846509016 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark01(45.217822292250844,-44.29536771692715 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark01(45.217884886820855,-1.4987788763139065 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark01(-45.2990792502465,-1.5707963267948983 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark01(-45.30915345601486,0.35752881479277676 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark01(-45.353855225200434,-23.279581848998014 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark01(45.407424582965945,38.81437615947674 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark01(45.42179172034773,0.3955965205476133 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark01(45.42996122214504,-0.18790005173326563 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark01(-45.43136657877784,0 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark01(-45.47513719355108,-1.5707963267948966 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark01(45.509216512125974,-4.714342222366794 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark01(45.51971060159757,4.713052884089942 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark01(45.54361483568257,-1.57075470057572 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark01(45.55129839813611,-45.55309534419272 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark01(45.55146950830658,-73.82742528897403 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark01(-45.67798515723113,1.5707963267948968 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark01(45.694624204952376,0.0 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark01(-4.578025514343447,158.08646717509134 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark01(-45.81087481633912,0.0 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark01(45.93190329069378,0 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark01(46.01592334885812,-35.01954796674606 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark01(-46.09824608533338,0.0 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark01(-46.432512853385965,-1.5707963267948966 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark01(-46.503189300709295,-80.42434362400881 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark01(46.869967040112925,-2651.0117521759894 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark01(-4.70197740328915E-38,-29.845089649348186 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark01(-47.036547222136825,16.605276937405122 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark01(47.082959675759696,-1.202862984866357 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark01(-47.12388628161362,-2.509858039333316E-7 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark01(-47.12388775706688,-87.96441492228155 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark01(-47.12388980339947,-89.53545166246536 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark01(-47.12388980384555,113.09470569284719 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark01(-47.123889803846886,-1.5707963267948966 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark01(-47.12389075766929,0.0 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark01(-4.715018821023611,-1.5707963267948966 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark01(-47.23383807231709,-2593.057143846829 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark01(-47.23480738369397,1.5707963267953438 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark01(-47.23759545373649,76.86151643881857 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark01(-47.266034299219854,-0.5478849547569832 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark01(-47.31717357926593,0.0 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark01(-47.50060102360481,-34.800982852175416 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark01(-4.751882246748778,1.6372314447026923 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark01(-47.530557741280674,-31.51397054919808 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark01(-47.55344433007658,83.14447512700093 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark01(-47.6981080211286,-48.33466637001011 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark01(-47.79113203334584,-32.450649605282635 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark01(-47.83024681916407,2598.7712114727824 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark01(-47.84435368036597,0 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark01(-48.109276164535416,-118.11738452751392 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark01(-4.813651001996704,-17.032778359275326 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark01(-48.2146288544105,-32.86414311660056 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark01(-48.2376371885959,-29.845130209103043 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark01(-48.525617996507165,-20.65831271630015 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark01(-48.53827786039582,62.171474042170125 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark01(-48.56295791661216,92.80684943991923 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark01(-4.860065859815421,-1.5707963267948963 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark01(-48.617030863861245,32.308056233261226 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark01(-48.69641990743503,98.96016661128218 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark01(-48.7003036216337,-37.385873523727 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark01(-48.73214106956847,87.41325742954203 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark01(-48.73370486392654,0.0 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark01(-48.81394483029519,99.19495299782258 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark01(-4.893857889202853,4.743638982170168 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark01(-48.958465045618446,1.3626181779044866E-10 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark01(-48.965131612438896,-100.0 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark01(-4.930380657631324E-32,-1.5707963267948977 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark01(-49.46953709948672,-92.70956584932219 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark01(-49.47477187273704,0.23023845188455694 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark01(-49.584581114655265,-74.1092616779209 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark01(-49.6946861306418,-73.82658461551432 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark01(-49.715500082924294,84.5842276391234 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark01(-49.72605638488828,1.5707963267948966 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark01(-49.72775735767701,-44.288962024837595 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark01(-49.81148162661474,30.441249593996265 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark01(-49.81445571202131,-1.5707963267948983 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark01(-49.83231750774133,0.0 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark01(-49.83951594163944,93.10824092730458 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark01(-49.84881495761113,-14.42931891404664 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark01(-49.91456928018019,-0.8696722063706446 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark01(-49.94603463249764,51.06798460667213 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark01(-49.94630217692031,-28.067759821820864 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark01(-49.98613959896885,71.88156421921798 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark01(-50.01341581613669,-32.18076488484529 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark01(-50.02585898638445,-1.5707963267948968 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark01(-50.03462682053996,0.0 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark01(-50.0438624467199,-283.41916614554214 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark01(-50.06589413580846,25.78391496401606 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark01(-50.09631271644676,1.5707963267948966 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark01(50.10086133226747,40.93667027437215 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark01(-50.104979883559,-63.14214485142439 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark01(50.106315817927936,0 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark01(-50.10853511532133,-18.751750578987995 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark01(-50.14428893163909,50.044270206344436 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark01(-50.1780728522887,-1.3659952015888783 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark01(-50.195304456957246,194.4020331103637 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark01(-50.21130716233456,87.56722423087604 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark01(-50.22040284687812,2542.019798521582 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark01(-50.221809369002244,6.4293290216462085 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark01(-50.22728288488371,0.2772590656236385 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark01(-5.024596647809943,-87.47433864022464 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark01(-50.255841485058404,131.81202933593934 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark01(-50.257283927565226,0.5621707984771606 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark01(-50.26548245743668,0.0 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark01(-50.265482457465744,0.0 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark01(-50.26548312499763,50.265482378270896 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark01(-50.26549749892431,31.415926541826998 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark01(-50.27360284960131,31.41592798789799 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark01(-50.31151429202239,-70.9276971809441 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark01(-50.36442529334185,0.0 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark01(50.49705905159183,71.50459792162731 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark01(50.50249562264736,0.0 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark01(50.58087439365022,-60.1234870446842 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark01(-50.590977809829106,49.740002314997724 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark01(-50.60430367082648,0.45461225251118714 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark01(50.652508383829556,-70.45851116872583 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark01(-50.65834683981265,0.0 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark01(50.69932010889574,45.35742066177097 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark01(-50.73866416509373,-0.8779919915534625 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark01(50.77067382834597,16.24279195266253 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark01(-5.079872511376879,-72.46997357467497 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark01(50.808034440749566,0.0 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark01(50.83291247353938,20.530133534916175 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark01(51.01043595842031,-24.442592190678212 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark01(-51.10143862643189,-2618.9083487719677 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark01(51.116437775723426,0.0 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark01(-51.210621682317715,73.24196606207818 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark01(51.23050713258053,62.56399375750716 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark01(-51.35434250469657,0.0 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark01(51.35938053290511,10.767235064689757 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark01(-51.438175575728806,1.5707963267948966 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark01(51.48199800986305,2.455869394144997 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark01(-51.51799428992837,0.570788189495815 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark01(51.54871691726933,-4.850966043681893 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark01(51.606279765170086,-71.26410816133328 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark01(51.676457294284376,-105.66557823859819 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark01(-51.681084645062754,-2.429428061149126 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark01(-5.170845879512671,-18.558619024167825 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark01(51.78526499558238,1.3430238757815818 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark01(-51.81852130267645,6.43073533845902 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark01(51.83423009478981,1.5707963267948966 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark01(51.83466988176682,-86.39379578517367 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark01(51.83515120692444,4.71238737270282 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark01(51.83540722607974,29.845127089543514 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark01(51.83624178740819,-4.712385459740364 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark01(51.8362745767661,4.712385458257643 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark01(-51.84922714952818,-1.5707963267948968 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark01(51.8606220771826,-80.18146209980799 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark01(-51.93085998195904,1.5707963267948966 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark01(51.982181666048305,1.5707963267948963 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark01(-52.135768731435036,-39.4432868953388 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark01(-52.21369669868997,138.04421567717247 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark01(-52.22816837589341,86.61368010144386 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark01(-5.226828930372278,-31.76168324195585 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark01(-52.63552925648294,-77.23625927199703 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark01(-52.6556294827369,67.14250179767168 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark01(-53.17926689981969,-1.5707963267948961 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark01(-53.19131933063166,2.0496462931760107 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark01(53.19993298122271,-14.956021776228923 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark01(53.23630718326936,0 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark01(-53.407049826955166,-0.003665113958596685 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark01(-53.4070751047494,1.5707963267948966 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark01(-53.42317783913042,1.5707963267948966 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark01(-53.521003924363896,0.48146508459993126 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark01(-53.6694653804022,1.5707963267948966 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark01(-53.676979407044264,-43.23475319899341 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark01(-53.71527102680701,-51.27315978751121 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark01(-53.745167102934936,-1.5707963267948966 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark01(-5.381178363318178,0.0 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark01(-53.813058996038386,1.5707963267948983 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark01(-53.8242072481873,0.9337050623320594 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark01(-53.89838006497725,-74.38393389740214 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark01(-53.942636159220434,16.850901993628597 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark01(-53.95828588714809,-30.398780923766026 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark01(-53.968097325991906,-1.2535522263664598 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark01(-5.421010862427522E-20,1.5707963267948966 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark01(-54.24300983089254,-55.57240229080374 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark01(-54.27100624377074,1.5707963267948968 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark01(-54.45601813291188,0.0 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark01(-54.63350702061578,0.8708892144209273 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark01(-54.67289242199014,55.18568091866979 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark01(-54.785644106022175,-1.5707963267948968 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark01(-54.97743143257712,95.81857760901893 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark01(-54.97768991385075,-1.5707963267949663 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark01(-54.97806875447593,54.977867969274875 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark01(-54.97885932116057,-4.712387629151145 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark01(-54.97887179423294,4.712385983053006 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark01(-54.97956245258634,67.54424174847757 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark01(-54.97990296912576,-29.84512880011889 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark01(-55.03895157269909,-3.857954485654528E-4 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark01(-55.04356059131459,243.48582528147807 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark01(-55.050602801852484,16.738101267134006 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark01(-55.12021179542922,0.4432004642805547 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark01(-55.12108084445051,0.0 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark01(-55.15781873849764,-1.5707963267948966 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark01(-55.16856487749217,-2593.354629616699 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark01(-55.19097168508122,-1515.255745907711 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark01(-55.20927585092116,1.5470050769795467 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark01(-55.21951634461145,1.5707963267948968 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark01(-55.23650478011259,138.67085180425008 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark01(-55.246504834782954,-10.995629646313095 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark01(-55.25894890844651,-59.39920465688316 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark01(-55.260268400993986,-100.0 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark01(-55.28399064770211,1.5707963267948968 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark01(-55.31482159093892,0 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark01(-55.35278886535198,-12.349433269477558 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark01(-55.35914099974028,2614.3183593249196 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark01(-55.38730754130099,-41.67962290649304 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark01(-55.396354313224315,170.6411802777069 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark01(-55.399796888861914,-31.735590772861286 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark01(-55.43876667614749,0.0 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark01(-55.50993856592164,0.0 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark01(-55.516292148391244,1.5707963267948983 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark01(-55.57825007086641,50.49897162141809 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark01(-55.65818873542888,63.94995426078694 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark01(-55.78036417559296,-1.2607700793522676 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark01(-55.912286938353816,49.09415769264143 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark01(-55.96093848621527,0.0 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark01(-55.987925013966425,0.0 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark01(-56.03584629648478,-1.5707963267948966 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark01(-56.050308918402855,-4.641148687942225 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark01(-56.0769138059337,-3.9279463326298267 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark01(-56.07818383422513,0.993301015743174 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark01(-56.11769044209372,91.05814066287452 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark01(-56.1425169776786,-72.75579604808252 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark01(-56.14810747101966,-63.437566209553275 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark01(-56.182788218281786,-44.91696746010806 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark01(-56.18913949956058,45.04548118664194 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark01(-56.200727329111686,9.943251879819783 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark01(-56.20476031664694,-1.5707963267948966 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark01(-56.215225114448565,46.09829756881104 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark01(-56.21609894589952,0.0 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark01(-56.22191899847475,-17.57868154761269 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark01(-56.256117862416005,39.00468085278895 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark01(-56.286461984859905,-0.14141376086536184 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark01(-56.30007350886405,1.4087479009721202 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark01(-56.307761386286415,42.559765756288016 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark01(-56.31599051658691,1.570796326794897 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark01(-56.33899048778556,100.0 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark01(-56.3418872065714,22.490267491040527 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark01(-56.36127640400004,-0.05762172761405055 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark01(-56.408892439315906,0.49827036877559705 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark01(-56.43842428954086,0.018623823926667456 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark01(-56.44711316590001,-0.4541829528699718 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark01(-56.46529052379225,70.2409310908661 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark01(-56.47418225352252,100.0 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark01(-56.4966881023348,37.456171031115346 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark01(-56.50042326187552,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark01(-56.50236090676613,0.12546311293858045 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark01(-56.5479983490492,48.926748737750394 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark01(-56.548667764645664,-1.5707963267948966 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark01(-56.54866830578155,0.0060882321927649904 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark01(-56.54866893050528,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark01(-56.54867110660391,9.776320548050487E-7 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark01(-56.54868302349734,-32.99062911269283 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark01(-56.55052763018809,59.119528309438266 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark01(-56.552580951446764,-6.764408059629749E-5 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark01(-56.55648244158785,-67.5441954781299 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark01(-56.564292770117966,0.0 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark01(-56.616832733849435,0.0 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark01(56.62285918957173,0.3874475376010043 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark01(-56.67366776462598,-31.416301720399524 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark01(56.68251888860336,-0.5225523164155917 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark01(56.73781369644669,0.0 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark01(56.747549424135826,0.45665351606004734 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark01(-56.74954684321554,0.0 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark01(56.773389184419266,-44.11777757079554 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark01(56.79316305349979,31.74315591153467 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark01(56.83406653474617,54.46261661283279 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark01(-56.84433243042622,-136.57672904468495 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark01(-56.876870658851956,45.377516292490775 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark01(-56.94212083057613,175.74089299494503 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark01(56.97975123144977,-16.238214629491466 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark01(56.99251168073849,3.6547148978130775 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark01(-57.026914664781145,1.570796326794886 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark01(57.03910647694906,-0.021298344058473688 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark01(57.133280028823506,43.53703058754991 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark01(-57.14441829246352,-1.7839908512957786E-5 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark01(-57.15774652944374,31.62844580178927 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark01(57.26872351120648,-73.51828893858553 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark01(-57.44670493012365,-23.77140053196429 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark01(-57.44962603741885,0.0 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark01(-57.47485629578026,-36.65538859954249 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark01(-57.476277811778246,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark01(57.495098262207826,48.69469502515985 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark01(-57.50339502091624,0.0 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark01(-57.60349024287021,46.706358690777954 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark01(-57.65856816053236,-41.13726800430554 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark01(-57.667235344233546,0 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark01(-57.67331934361162,-1.5707963267948966 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark01(57.68821118848328,-23.461650939536085 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark01(-57.76620689821059,-4.594004428667887 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark01(57.79952618846937,0.0 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark01(57.800868254419925,68.0380525073789 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark01(-57.814318306793226,-19.171558210042434 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark01(57.85360346633394,-44.189462073638985 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark01(57.92479748221896,1.5707963267948966 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark01(57.933014661257324,0.0 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark01(58.11683994788157,54.97787142271719 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark01(58.183081226017464,-94.89595497829725 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark01(-58.25184531588443,-40.04591895407423 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark01(-58.277110017318144,157.3122110523256 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark01(-58.55729946302185,49.226558032751214 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark01(-58.65922978396436,-1.5707963267948968 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark01(58.78741886577608,-1.3345992742696462 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark01(58.81054196306008,-26.408957621312794 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark01(-58.82509762267623,-0.024799270456414047 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark01(-58.92406759522129,-80.40669899777097 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark01(59.049966420787136,-32.763469663466026 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark01(59.221269071555035,-3.0705528238633235 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark01(-59.2572602888352,75.03226180963676 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark01(-5.938800733261225,17.107530874649626 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark01(59.41029344627603,-1.5707963267948968 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark01(-59.65016155845368,7.364276075340271 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark01(-59.69025689606743,-12.566366811884443 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark01(-59.6902573961875,-6.283555929956139 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark01(-59.690257480117154,-87.9635376804114 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark01(-59.69026041818731,-45.55310816010511 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark01(-59.87427696126133,5.668613143175385 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark01(-59.87918877238327,-56.88284948703538 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark01(-59.911910493962765,3.552713678800501E-15 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark01(-60.08722477674064,1.5707963267948963 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark01(-60.26542837603749,-0.33186750809697163 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark01(-6.0334696923683415,0.0 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark01(-60.439895455005924,5.036671015692237 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark01(-60.495320248396304,95.53569015605581 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark01(-60.552511261086984,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark01(-60.56069072820463,52.92122688859817 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark01(-60.71214951776477,7.697922890342472E-5 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark01(-60.72425841717228,70.8877773188307 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark01(-60.728366767061864,-76.20866591156319 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark01(-60.744436758456345,1.5707963267948972 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark01(-60.848245308125,1.5707963267948983 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark01(-60.975661910133134,-93.28037219480984 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark01(-61.0156493013361,84.65161664768988 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark01(-61.02529876478358,-6.591445636045904 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark01(-6.107659781488465,-80.71151918355766 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark01(-61.12101174153864,53.73655120114896 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark01(-61.195658715724875,43.40073974391677 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark01(-61.25842690436213,1.5707963267948966 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark01(61.29459170387577,43.4672172961462 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark01(6.145972638098468E-6,-37.91481388097706 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark01(-61.492018054490586,-34.87329152905403 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark01(-61.931172943011084,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark01(-62.17397491572259,-1.2276861610102427 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark01(-62.200646437250676,-0.8265196408478346 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark01(-62.6240050563331,0 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark01(6.28318530601034,-18.84886856333874 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark01(-6.283185307179738,5.198438568436374 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark01(-6.283187332299311,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark01(-6.283188076392105,75.39740594979283 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark01(62.83209721292203,0.0 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark01(6.283221645906964,14.429210252755794 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark01(-6.283274937896321,-1.5707963267948966 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark01(6.28335241795152,-125.64525570893387 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark01(-6.284161869679587,0.0 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark01(62.84289897796575,-1.5707963267948963 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark01(62.861502401749895,50.50958564163657 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark01(-62.89435307179587,-105.23865603484005 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark01(-62.926569784192964,-1.5707963267948966 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark01(6.298810307179588,69.12439495234963 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark01(63.043169241213974,8.965071986693317 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark01(63.05302064895689,25.946104727291875 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark01(-6.3097012174614715,-62.397827659995976 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark01(63.12359780889457,-95.41015951212928 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark01(6.314435307179589,-37.942421996833424 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark01(6.3144353071910855,75.19605593201037 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark01(6.314435307214282,44.21008115358514 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark01(6.314435565897888,-25.30516696423191 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark01(63.146306845755085,0.44763643154911753 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark01(-63.14672438008064,-1.5707963267948966 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark01(63.163941554454766,0.0 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark01(6.317493267445585,0.0 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark01(63.3177362613617,-66.17053404525223 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark01(63.358341374043505,0.9067612057757953 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark01(6.336241795994303,150.50317200301325 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark01(63.368229109799046,-9.561646618542028 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark01(-6.337163353769249,0.53887216652402 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark01(63.4064463671574,45.39459189699005 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark01(63.454799766152966,-4.213076026823418E-7 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark01(63.48090564812159,-8.531266028843007 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark01(-6.35226555741267,0.0 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark01(-63.618290658366256,42.50472424294418 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark01(-63.64975487034632,93.6597206539351 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark01(63.660412889504485,82.64175752782587 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark01(-63.68459063901317,-0.5004914854412924 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark01(63.713206305316106,-1.5707963267948966 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark01(-63.76606799431839,0 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark01(-63.769199429391,133.723169342383 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark01(-63.813925429402765,1.5707963267948948 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark01(-63.84196204275725,14.048302269435922 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark01(-63.89413633504711,-1.5707963267948966 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark01(-63.91814547011134,-93.05284516515775 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark01(64.01973883350493,2617.983722091022 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark01(-64.05991724824588,-105.94112784739085 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark01(64.06249662907852,0.0 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark01(64.06535891397355,61.47048536700274 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark01(-64.07799280299963,-40.6625051990593 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark01(64.11265939358552,-1.5707963267948974 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark01(64.11552825843609,0.0 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark01(-64.1267457432061,0.0 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark01(-64.17869945868793,82.07524557740595 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark01(-64.31975118845511,0.20784390592969793 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark01(-6.436146453075519,0.0 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark01(-6.449452225541059,90.17116192690278 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark01(6.4608662372397845,-43.53713021676422 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark01(-6.462348535570529E-27,-54.9778714377863 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark01(-6.469364516075089,43.90218200035031 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark01(-64.88452872449163,-12.777264110950995 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark01(-64.91072262907201,14.387205176591621 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark01(64.93381556873894,4.9646371892645575 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark01(64.94529787474322,2.284322009376467 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark01(-64.97953802554365,-14.429235398653375 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark01(-6.498562255015601,14.429204184269139 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark01(65.07844078059449,-1.570796326794897 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark01(6.533185307699797,94.74490314103699 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark01(-65.4438040811212,-1.5707963267948966 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark01(-65.46161877261252,2605.19861441711 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark01(-65.56918921593113,-55.28200477653148 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark01(-65.6050885908118,42.70345330851393 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark01(6.577306375174089,0 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark01(-65.97344224232728,0.0 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark01(-65.97344509178365,6.225351973827335 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark01(-65.97344572532356,70.68589838897005 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark01(-65.97344572537911,42.41150025674185 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark01(-65.98409347483236,-0.09431658737848224 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark01(-66.05869518358293,0.09919087763445782 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark01(-66.11999730724304,-16.830247812364572 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark01(-66.18798478842827,-81.05362839504191 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark01(66.21362729583393,33.612996528300926 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark01(-66.23409464769409,2.985404675094074 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark01(-66.33965294725148,-71.55742505879473 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark01(-66.39273066141307,-95.26330004345152 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark01(-66.4569798414315,95.88837460545194 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark01(6.657278464563767,-0.883342435430965 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark01(-66.58338475644905,107.38032759763234 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark01(-66.65102713313813,0 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark01(-66.69885179580274,-2556.493747539086 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark01(-66.80043265165952,44.26446172515445 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark01(-6.693342289121134,7.709294332470037 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark01(-66.94408556025388,1.5707963267948968 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark01(-67.04935727389385,-1.5707963267948966 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark01(-67.33017704068133,0.5687501134484397 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark01(-67.3411867664743,-76.15132355535661 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark01(-67.40340340245409,-45.357388582670325 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark01(-67.5084441358145,0.6258116731498546 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark01(-67.54161221154173,1.5707963267948966 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark01(-67.54606901735602,1.5707963267949105 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark01(67.61969748161047,-75.52595446325985 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark01(-67.77412030464632,-21.64267314698442 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark01(-68.07279276849894,-14.029830749562194 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark01(6.809304500331011,-80.56096490090468 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark01(-68.16405062632661,-1.5707963267948966 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark01(6.828268948196325,-134.88278967959417 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark01(-68.29767934542342,-1.5034631672738783 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark01(6.829851401097601,-5.213223700441825 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark01(-68.55143031334596,9.694950510655687 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark01(-68.64793428017074,0.0 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark01(-68.81505759914106,9.68092264437665 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark01(-68.82505518211931,18.711450679947063 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark01(-68.94101924583254,48.6946861306418 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark01(-68.96961929066661,145.05832847625732 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark01(-69.03369958198844,1.5707963267948966 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark01(-69.04512086115028,-89.18175973353902 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark01(-69.04523850736945,2.4362270944182405 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark01(-69.04759363702905,-0.36922811550381957 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark01(-69.11503837897543,0.0 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark01(-69.11503838015027,6.224092248126346 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark01(-69.11503839518834,-106.81152649717296 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark01(-69.11504180426977,-6.283000385864348 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark01(-69.11504190121494,7.328012233225034E-11 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark01(-69.11506282040713,100.53037233434101 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark01(69.12817221200345,40.306168184174226 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark01(69.14369428443078,0.2399601509805994 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark01(-69.22140748588485,-35.055249541420736 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark01(69.30188295039174,87.05515786138295 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark01(69.37249782456846,-32.73240573416989 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark01(-6.938893903907228E-18,0.3848953637354652 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark01(-6.938893903907228E-18,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark01(-6.938893903907228E-18,-6.123233995736766E-17 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark01(-69.40688301624876,2510.7894560358604 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark01(69.49681911448599,0 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark01(-69.52523664224253,-1.2474850565033477 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark01(6.953677772431213,7.465668061589288 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark01(69.54444907410263,37.90823803851041 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark01(69.54599046365988,-3.846335962812347 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark01(-69.58994037517434,108.69441039720482 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark01(-69.63918793549675,-14.148949788597298 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark01(69.68594274727258,30.253840619179215 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark01(69.70419999636056,-24.240610044867168 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark01(-69.78434696228217,-66.87463436357226 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark01(-69.79493140904569,10.974650678267887 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark01(-69.8391547866423,-50.62152359962362 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark01(-69.85117423922313,2.725254742958086 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark01(-6.985174620417752,0.0 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark01(-70.00110394559957,100.0 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark01(7.003319842699398,-59.440299716043654 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark01(-70.14331842157466,-13.18186894282093 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark01(70.14922688728399,-1.5707963267948966 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark01(70.15689720719493,-174.51235709084003 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark01(-70.20918009962851,-66.22427534059821 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark01(-70.23052186575143,29.845130209103047 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark01(-70.37051508198957,1.5707963267948966 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark01(70.37616290261496,76.92143601137931 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark01(70.49985984169388,-26.50457291466917 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark01(-70.56340301888702,-107.9336696446042 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark01(70.68320486512279,1.5707963267948735 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark01(70.68320486513144,-1.5707963267948966 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark01(70.68535372113328,1.5707963267948966 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark01(70.68548534713707,42.411499732058594 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark01(70.68583470554479,-136.65139760051844 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark01(-70.77204058004467,-83.98026931204106 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark01(-70.81447705952485,39.66686423265506 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark01(-70.81666229999973,-128.99610683969937 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark01(-70.84177140055687,2607.8984584893115 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark01(-70.86534988580635,43.98481968820611 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark01(-70.9903528088345,-74.79540670689929 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark01(-71.02945343485267,49.409949034026766 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark01(-71.03686457517506,0.0 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark01(-7.115116239245694,78.93337788942489 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark01(-71.37020163310478,2.220446049250313E-16 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark01(7.153279691056014,-2619.5693347609754 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark01(-7.160838426391749,-1.5707963267948957 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark01(7.174709141962055,12.617025701286508 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark01(-71.8265778276606,0 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark01(-71.87497402217798,-66.33103244578746 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark01(-71.88155160996372,1.5707963267948966 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark01(71.96966098663222,-82.78631443228394 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark01(-72.22721242581689,-1.5036905148503623 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark01(-72.25662788155383,-12.567208067831602 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark01(-72.25662798314454,37.700060045165145 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark01(-72.25663005429027,73.82742735936013 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark01(-72.25663103225837,6.204521652845174 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark01(7.254395807832424,73.6779751138823 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark01(-72.58132478374436,-90.85023995628649 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark01(-72.58901297669745,-95.70603297248736 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark01(-72.67584366759925,0.0 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark01(-72.76470621034818,-43.6851154202598 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark01(7.3000797458261815,1.5707963267948966 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark01(73.05991444138752,0 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark01(-73.08366207704826,-77.96080380537124 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark01(-73.12243043454924,61.54358386000433 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark01(-73.15029341258976,37.18636036025484 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark01(-73.22095317477961,-4.899380846289517 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark01(-73.22155869641537,-0.41878990001824523 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark01(-73.25011180698691,18.286720593190765 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark01(-7.327578209079789,39.20925709760647 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark01(-73.49219970533977,-97.43311384290601 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark01(-73.62696699022402,-26.81920215826257 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark01(-73.66053770030996,48.540010471843345 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark01(73.74986864702944,35.13133293363674 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark01(-73.82479751872194,1.5707963267948983 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark01(-73.82636129665418,-1.5707963267948966 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark01(-73.8273861553793,193.2079451074363 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark01(-73.82935158661643,10.995572969774866 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark01(7.385551461845459,-87.48002227897273 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark01(-73.98145555266571,0.10273293502923884 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark01(-73.99101917036923,-0.8464750201603295 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark01(-7.404187091447895,2606.5704648128335 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark01(7.415852702026797,0.0 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark01(-74.57139389467358,-14.386639765052479 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark01(-74.66426789604182,92.58826016958623 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark01(-7.497036736213775E-8,-62.83445451298468 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark01(7.505663970002843,34.042167319602726 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark01(-75.19767249536595,-93.94230793890728 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark01(-75.22571679935994,-62.237208053270756 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark01(75.28461327524428,0 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark01(-75.30782336387085,18.42137520079515 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark01(-75.31253479980342,0 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark01(-75.39822368615502,0.0 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark01(-75.39822368617172,73.82742676590573 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark01(-75.3982271900071,94.24794674623315 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark01(-75.39830579045638,-105.23262009243606 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark01(-75.3992002486552,4.712388980240916 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark01(-75.40031314703843,95.8185769355621 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark01(-75.4021299443164,1.5707963267948966 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark01(-75.40213314175973,1.5707963267948966 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark01(-75.41039553871424,0.02771216918648462 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark01(75.4461680555431,2573.7637723437115 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark01(75.4485572700653,1.5707963267948966 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark01(-75.46517130544768,-0.5707913263236862 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark01(-75.46673158654524,6.123233995737021E-17 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark01(75.49756533843504,-1.5114143212367281 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark01(-75.52282366575683,-99.99850774335081 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark01(75.56295224573874,63.651655581889315 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark01(-75.56963797591965,1.5707963267948966 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark01(75.57035407008519,1.5707963267948966 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark01(75.57355445789953,-5.406961042542832 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark01(75.62447610458781,-28.151701133606124 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark01(-75.65276825517051,4.712388980384801 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark01(75.65327609620743,0.0 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark01(-75.72858773719906,0 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark01(75.74498383860046,0 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark01(7.579323475023233,-45.51560308891964 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark01(75.90918676586716,1.5707963267944614 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark01(-75.96317625896766,0.0 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark01(76.05908481223977,80.50712442049482 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark01(76.15541620515083,-100.0 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark01(76.15994698015635,-58.32700159272995 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark01(76.1898537714481,0.0 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark01(-76.22296380731235,-70.19302837156968 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark01(7.6260236404144734,-52.228088969960716 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark01(-76.28441029216327,90.36579138728514 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark01(-76.33654771766646,-29.83037121806026 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark01(7.636626449524115,2683.3210903558306 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark01(76.52025922527699,58.7576643105823 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark01(-76.62046946472414,-43.046480942698985 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark01(76.65711724195924,-2674.6300187092916 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark01(76.66711361531063,52.77464174365315 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark01(76.89306897888122,-1.5707963267948966 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark01(76.91548557355455,-47.595446969849654 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark01(76.91761776646658,-33.637761396505454 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark01(76.93598281865155,-79.91411745812289 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark01(76.96678866183503,86.39379699549255 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark01(76.96900951202552,-36.12831216574924 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark01(76.96901999722249,1.570796326795083 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark01(76.96938430296683,67.54423860525337 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark01(76.96938874936504,17.278756648407285 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark01(76.96979492228245,92.67698007793355 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark01(76.97164985358815,1.5707963267948983 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark01(76.97164985358887,-1.5707963267948966 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark01(-77.05113706057405,3.20339081611077 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark01(-77.05414137429516,0.0 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark01(-77.06041928165592,3.7010977209909046 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark01(77.09968495272656,81.53013521152846 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark01(-77.12834167009169,-74.92007457907441 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark01(77.13806323785121,-1.5707963267948963 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark01(-77.14363314737221,72.46312781752758 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark01(-77.15025697808011,0.0 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark01(-77.17343909031041,-94.79254479675079 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark01(77.19914048022085,-82.09215689896426 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark01(77.20000233758842,23.56197533122432 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark01(-77.33124666183083,0.5438108946987833 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark01(-77.34037499141117,-45.00043734979584 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark01(-77.3410601280737,-73.870392008447 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark01(77.34253407790848,0.0 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark01(77.346565093799,32.62162027538196 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark01(7.738186147931387,-84.99669099759673 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark01(77.4046862935698,-1.5707963267948966 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark01(77.41300188743463,1.5707963267948966 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark01(77.41967062919572,-68.55863869803214 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark01(77.43088223358666,-1.5707963267948966 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark01(77.43672417188111,38.58484202609043 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark01(77.46094499431703,-23.56194673208581 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark01(-77.48399183425184,-86.39379837525445 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark01(-77.49006127916223,-2424.8268439151 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark01(77.52542685858633,-93.29065072529494 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark01(-77.61031411015966,-1.5707963267948983 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark01(7.773566835244306,54.97787141111143 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark01(7.773937227734482,1.5707963267985008 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark01(7.782931027486441,23.779701050496897 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark01(-7.785181797400229,-1.570796326794897 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark01(77.86501869361382,-89.64434578131323 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark01(-77.89336580112135,1.5707963267948966 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark01(-77.8963869124879,0.0 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark01(7.793889777615307,-29.845130209100557 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark01(7.794366259910993,89.53545166320102 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark01(7.795031739912087,73.82742735935602 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark01(7.795200386523709,-95.81857974918597 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark01(7.795416949905998,23.561917445132423 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark01(7.796827315867558,1.5707963267948977 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark01(77.98461133809019,9.55730437626691 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark01(7.801205907636643,-14.747551385763686 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark01(-78.01631733847819,67.79979085275798 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark01(78.06050074253729,-100.0 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark01(-78.07186407257751,-50.0424112120445 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark01(-78.09974079301915,-127.3690031625885 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark01(78.1012498776332,0.0 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark01(78.1051273332546,0.003944642230554302 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark01(-78.10905135981518,0 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark01(-78.14513604187557,48.69469958869344 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark01(-78.14728106299734,42.45779704381288 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark01(78.15222459027788,-0.5574950167991096 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark01(78.19868630715149,-56.36127151797397 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark01(-78.22740655624499,31.536718204004057 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark01(-78.24935109372592,-17.278759594743864 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark01(-78.26471389062155,-31.848015241522848 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark01(-78.2672010996434,-1.1102230485775002E-16 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark01(78.27421342645808,-0.2375257059491485 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark01(78.2754032426902,-4.123774839333825 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark01(-78.28190581109548,0.0 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark01(78.28225893410043,36.96927126683062 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark01(-78.28437383471815,-23.549883495037523 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark01(78.35597607890692,-29.016990977090956 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark01(-78.43222241071224,-2578.005092431584 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark01(78.43327012766339,-44.09246576223564 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark01(7.843484657459438,-4.712440800898109 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark01(78.46140572277696,31.814360867893406 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark01(-78.4753338274631,-0.3215451811752672 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark01(7.84856636158608,23.65428408873555 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark01(-78.49021846000146,32.799351853496546 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark01(7.851444802820158,-51.83627902287241 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark01(7.85202101845238,45.553095029313155 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark01(7.85249309186216,0.3539285344086608 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark01(78.52589711049374,49.65184180453528 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark01(-78.52654762314864,91.12350224579524 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark01(78.53038378358558,0.137466899907107 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark01(7.853862871808334,-36.12831200401826 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark01(-78.53981561688009,-43.9841987139437 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark01(-78.53981617073619,6.203548912382714 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark01(-78.53981633970588,-100.53420134743286 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark01(-78.53981633973888,-83.25615288502479 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark01(-78.53981633974473,-73.82741110876827 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark01(7.853981633974483,1.5707963267948966 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark01(7.853981633974483,1.5707963267948972 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark01(7.853981633974483,1.5707963267948988 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark01(7.853981633974763,-0.02427744413521527 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark01(-78.54639011245388,-80.56699248781946 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark01(-78.54998749550673,0 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark01(-78.6894388828327,-0.16381614155443153 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark01(-78.71615554571552,1.5707963267948966 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark01(-78.71765520977654,-1.5707963267948966 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark01(-78.86463415632369,0.07964753303697591 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark01(-78.93187490372856,-17.278761976270008 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark01(-78.98791957205226,2555.6343956580104 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark01(-79.00912824426818,95.53176641076219 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark01(-79.11402531064095,92.3989750555375 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark01(-79.13930136083363,0.0 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark01(-7.927805801792417,0 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark01(-79.46151269178617,-13.932366443472871 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark01(-79.50932293855277,-8.131088872824868 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark01(-79.53832175963186,31.231359278911185 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark01(-79.64500302949904,-50.372470262611955 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark01(-79.64848822154617,-97.9338011832142 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark01(-79.65867593002314,59.79418471725004 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark01(-79.83382099069448,-1.5707963267948966 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark01(-79.90928854811484,1.5707963267948974 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark01(-79.93929953132442,0.13359080436181614 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark01(-80.10798282590082,-1.5707963267948966 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark01(-80.10904980870227,4.712386717695525 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark01(-80.1100513867028,23.561941550995968 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark01(-80.1102032561753,-1.5707997551591002 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark01(-80.11031055803127,-10.99557082181447 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark01(-80.11324250717794,-1.5707963267948983 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark01(-80.2989358955873,137.30702774470674 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark01(-8.044734624654055,27.43029133785678 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark01(-8.056183113159747,28.91919717759354 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark01(-80.70499673047641,-88.36264014112504 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark01(80.82934634000759,-14.86271471281296 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark01(80.8977011678538,32.06119331923125 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark01(-80.98541308719228,67.47328122341192 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark01(-81.06763327412692,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark01(-81.18012191254968,-9.606456735209278 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark01(8.128020129524538,1.570796326794897 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark01(-81.29710783383743,0.0 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark01(8.129832262028058,1.5707963267948966 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark01(8.130079697203298,-1.5329141297596005 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark01(-81.33859529651713,-8.116120947251275 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark01(-81.45409601602745,64.18248638288779 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark01(-81.68141251537425,-7.095458669291162E-6 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark01(81.68143951091275,0.0 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark01(-81.68143951091291,-188.49532101835953 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark01(-81.68143951509109,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark01(-81.6885808609743,88.7255669914235 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark01(8.171351595484838,0.0 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark01(81.7307047113797,-84.33281076656955 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark01(81.75602619337388,-0.27368685554551864 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark01(-81.76239619235946,44.1462203090864 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark01(-81.78583201536911,1.5707963267948966 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark01(-81.8169696500415,-0.08111763098862347 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark01(81.82394184535823,-19.129301914102616 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark01(-81.89528747393621,-108.33930790466336 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark01(-8.190203057392395,49.6331759718521 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark01(-81.90963502504097,0.0 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark01(-81.93700780665192,-1.5707963267948966 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark01(-82.10770316390126,-67.2707094825918 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark01(82.16107229904213,-0.28172111584707693 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark01(-8.218384147742654,-42.80137038816385 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark01(82.19810956717632,0.4996228357456777 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark01(-8.221338409502238,90.15903240291797 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark01(82.30959207724159,33.9327762306045 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark01(-82.3471548911465,1.5707963267948968 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark01(-82.35301843241217,-86.415307811173 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark01(82.38596548079776,17.63879141967021 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark01(8.245426985341922,-1.1605799675883048 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark01(8.24556940003578,-2529.45263780415 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark01(-82.45830023025007,1.2140419879317516E-16 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark01(-82.48781292114475,1.5707963267948966 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark01(82.5722859648348,-17.278759594743864 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark01(82.58677687144286,1.5707963267948966 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark01(82.59856826883237,-33.69627520551856 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark01(82.66352434093069,-57.82011599493022 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark01(-8.275654219251052,1.5707963267948966 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark01(82.7796490233105,77.03090601234717 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark01(82.82887726574094,-145.39899852096838 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark01(-82.84044112952174,-0.47311334448298226 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark01(82.86017868944111,40.870755705969415 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark01(8.287828408201747,-99.97206448277072 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark01(-8.289012507382012,-1.5707963267948966 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark01(-8.292229626131814,54.35207529269019 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark01(83.07926014344883,161.80693901390342 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark01(83.08479130918086,1.5707963267948968 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark01(-83.09002713983408,21.33494568127972 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark01(83.19236639152194,-44.53503219077184 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark01(-83.20739865805822,39.46217426484935 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark01(83.254402123154,-67.544240996623 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark01(83.25480703204445,-1.5707963267948966 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark01(-83.27228018817634,1.5707963267948966 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark01(-83.28574080978206,92.92435970113183 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark01(83.31471558757377,85.20419584522489 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark01(83.38518395960827,83.46127471634938 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark01(83.42796988333312,46.57143658983194 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark01(83.46487335511972,-107.19499705994394 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark01(-83.46650001465242,-1.6103991005654412 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark01(8.347797619671784,80.23036811143632 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark01(83.49442234694926,-4.481210002890549 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark01(8.358129128364126,0.014034060534496481 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark01(8.361898887947898,2126.3047581407923 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark01(8.37425960855412,28.43523037064638 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark01(-83.81921272099613,44.379743700612224 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark01(84.0001138970542,-61.9868323672327 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark01(-84.03867514318746,-71.75401694198366 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark01(-84.13772767050057,0.5414050505695515 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark01(84.15718251885482,-39.7713704509044 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark01(8.417251955569611,-22.266983324064256 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark01(-8.417714983747985,0.0 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark01(8.418813053551874,37.7533858874929 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark01(84.21952757504687,-51.41822076235556 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark01(8.42477796076938,0.0 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark01(84.26085723931004,105.93960896763485 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark01(84.27029542611014,-0.5704524430171164 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark01(-84.27267476553608,0.0 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark01(84.28249379450708,1.0639431230783791 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark01(84.28623226706604,20.772213060247108 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark01(-84.29730030431676,-76.32615381827995 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark01(84.29732736031728,-38.74838242121961 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark01(84.30086972978447,-70.16765425849576 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark01(-84.32466227238642,18.44759772882088 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark01(-84.36835731546654,-69.78243889533353 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark01(84.37631894266286,22.288628757410933 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark01(-84.38116404258449,1.5707963267948963 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark01(-84.40638483404595,74.46552338614302 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark01(84.42735556786354,-97.12287048011783 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark01(-84.4307212256229,-31.00150323496871 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark01(-84.43126022692066,1.5707963267948948 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark01(84.44720128806753,-66.1035733778235 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark01(-84.45599356317928,0.0 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark01(84.49551171718235,1.570796326794981 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark01(84.49799890829148,6.391086443304438 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark01(-84.56220957477586,-1.87666094331379 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark01(84.56710824354921,-40.2945893509234 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark01(84.61384365752899,44.08066377281354 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark01(-84.69173497189193,1.5707963267948202 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark01(-84.69699982493017,108.09277525540851 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark01(-8.471476944842664,-11.163728068630533 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark01(84.78513124711404,72.28103789913806 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark01(84.80132317368287,-14.430113040847147 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark01(-84.82299812478492,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark01(-84.82299903159684,-6.281862818752236 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark01(-84.82300027242555,138.23007511709912 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark01(-84.8230016458063,1.5707963267948966 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark01(-84.82300164690426,67.54412749059348 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark01(-84.89601254258986,-9.793058981005018 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark01(-84.89948007989099,-75.90906416789562 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark01(-84.9100388724399,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark01(-85.05614592975506,-14.458862539381897 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark01(-85.06788820574582,-87.25335538262182 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark01(-85.09367663255458,-1.570796326794989 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark01(-85.19318486600456,41.59247568000946 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark01(-85.24441923614947,0.0 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark01(-8.536641231674475,-86.23479206677254 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark01(-85.39465868903675,-24.527124723870372 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark01(-85.62014476699733,0 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark01(-85.75143884105567,0 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark01(-8.5867976433066E-15,-106.81259023607448 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark01(-85.94860247739734,-99.87773885870988 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark01(-86.00201327256435,83.17636184441554 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark01(-86.11819608782156,0 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark01(-86.32852072650164,56.35689802381685 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark01(-86.37873796598875,-80.11077490875815 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark01(-86.39234862494031,-92.67698084448537 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark01(-86.3935118964607,1.5707963267949054 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark01(-86.39379797371181,-10.99557076532479 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark01(-86.4876913352268,0.0 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark01(-86.61511406125024,-1.5707963267948966 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark01(-86.65505914331605,1.5707963267948966 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark01(8.668167289751185,-1.5707963267948966 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark01(-8.673617379884035E-19,-12.566791122358104 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark01(-86.78414912330751,58.044168617039745 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark01(-86.79690514195465,27.43966591162453 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark01(-86.96595067942646,61.74493986064081 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark01(-87.06632025411352,95.27016457855859 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark01(87.10555923357782,93.79305893247815 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark01(-87.49576209534939,-19.560410062962788 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark01(-87.66817705998085,-52.400955102401966 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark01(-87.75359467127717,67.12516458454323 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark01(-87.8400257545093,-1.5707963267948966 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark01(-87.96459749241481,50.26469382471751 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark01(-87.96459768420902,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark01(-87.9645978206278,138.2300316772314 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark01(-87.96609221511049,10.995533865772424 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark01(-88.03719370817531,0.0 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark01(88.05969211930743,49.49093716664433 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark01(88.08289101492532,0.5228777229045042 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark01(88.08597752193856,-45.54675717634836 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark01(-88.11508868599587,53.4471407018421 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark01(88.15017068083048,-85.818205750348 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark01(88.16840687795249,2602.0961003653947 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark01(-88.27614143736675,-0.5070914031811804 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark01(-88.3218544975056,26.02610667665462 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark01(88.35647633310646,50.156359731379055 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark01(-88.40595866255107,6.948154573119169 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark01(-88.41719036284803,7.016201553646036 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark01(-88.50780786595372,-1.5707963267948968 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark01(88.51526137363594,1.5707963267948968 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark01(88.54907512321287,0 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark01(88.65399400050174,0 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark01(-88.65729218459002,-32.202192404475355 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark01(88.66530418171311,0.09287416264566489 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark01(88.71568469355475,-72.03148295763431 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark01(-8.87231107187398,0.2907158963302954 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark01(-8.881784197001252E-16,100.0 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark01(8.881784197001252E-16,100.0 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark01(-8.881784197001252E-16,41.122586811304345 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark01(-8.881784197001252E-16,50.393540580399396 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark01(8.881784197001252E-16,-65.74614266873236 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark01(-8.881784197001252E-16,-83.64352048882446 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark01(-88.82932277551599,-1.5707963267948966 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark01(-88.83488442502951,-57.52245497358043 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark01(-88.8696823581135,-1.5707963267948966 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark01(88.89364148415628,0.013955370886940079 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark01(-88.90317528294167,-67.9172632668482 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark01(88.90536366430459,-130.4983187948912 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark01(-88.9127101038005,0.0 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark01(89.16318534236035,4.482658062093122 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark01(89.17189731083887,1.5707963267948968 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark01(89.36353760842547,-48.70941609995197 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark01(89.40617817339216,-1.3642089577368357 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark01(89.5327607866722,1.5707963267949019 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark01(89.53502726961172,-1.5707963267948966 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark01(89.53508776710079,-83.25611157012953 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark01(89.53539062731083,-1.5708001414951498 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark01(89.53539062777156,4.7083305385976795 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark01(89.53539062826158,58.15071409183681 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark01(89.53541138211072,-73.82742383784702 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark01(89.53802046794803,1.5707963267948966 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark01(89.54863280739121,0.0 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark01(-89.69153448062323,-50.099464011949635 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark01(-89.73616919514384,-51.24688218484415 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark01(89.76726382158598,25.45228210339758 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark01(89.77135262301715,0.0 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark01(-89.79161359219722,0 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark01(89.83370651405595,-83.7816574505516 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark01(-89.8660430540483,-1.5707963267948912 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark01(-89.9017812391185,2412.2987265493653 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark01(89.90652142827003,-19.452495852088077 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark01(89.91949013315693,-42.48442904415116 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark01(-89.93187476524587,67.49898663452333 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark01(89.98459783616958,51.736907062982816 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark01(90.01211971815641,24.655066201050577 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark01(90.03304769771408,0.02291376895526482 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark01(90.16161194324397,-9.629502823295752 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark01(-90.44910236316097,0 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark01(-9.046858846945753,6.260590199854562 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark01(-90.58341289476776,-83.3954242048206 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark01(90.59528646338225,1.5280407799115537E-16 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark01(-90.59878245737653,15.229147310581723 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark01(-90.60118006790225,-1.5707963267948972 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark01(-90.6277566468575,0.0 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark01(90.66016915584774,-71.82740621371042 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark01(90.68764789331155,0 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark01(90.71712585220803,-32.31711299275557 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark01(90.71828241502953,-143.36144683256322 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark01(90.73005457611382,-86.98589336936028 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark01(-90.78894622907148,26.194098085242246 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark01(90.81734451164414,-0.9394314267210502 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark01(90.82276787040377,1.5707963267948966 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark01(90.83169867041764,0 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark01(90.83867871239995,0 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark01(90.8469952746091,17.4440364922946 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark01(90.95259683489931,-1.5707963267948966 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark01(-90.9746982921892,-59.94500550534034 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark01(-91.05588696865578,111.69463412402271 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark01(-91.06015254514085,-0.24483906182208784 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark01(91.07761877409223,-0.34386907656289323 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark01(-91.1061834318772,-25.132740718891107 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark01(-91.10618343473827,43.982297150554764 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark01(-91.10618360986848,5.725939471937049E-4 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark01(-91.10618428390538,-25.1340223431192 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark01(-91.106186358658,0.002395108348068342 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark01(-91.10618689225946,50.26299653645441 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark01(-91.10618693042652,-1.5710404674203091 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark01(-91.10618695398522,6.224121194632177 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark01(91.10618695410399,0.0 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark01(-91.10618695513003,0.0 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark01(-91.12447353360518,0.36841796793228127 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark01(-91.18892848212398,44.53244358138092 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark01(-91.32880520074444,-87.31915969683745 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark01(9.141474052802394,97.77844481172608 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark01(-91.45647119678348,90.60990251558776 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark01(-91.48000276698845,0.0 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark01(-91.60528200999997,-1.0223420703735873 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark01(-91.61312585567072,0.0 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark01(-91.64739264031896,65.35313165905282 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark01(-9.176887781983396,0 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark01(-91.79202190973801,4.713601351139655 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark01(-91.80167803910265,50.4317191262372 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark01(-91.80893713695546,27.666135409103987 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark01(-91.89268685553365,-45.09641630900683 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark01(-91.94762671781382,-0.4066269932972145 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark01(-92.16026078378604,4.84331966160741 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark01(-92.1954730708181,-35.40078715672199 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark01(9.21956763202365,-31.87140241314573 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark01(-92.2572219028876,34.23325826939103 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark01(-92.36070335567108,100.0 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark01(-92.40617454901174,42.8718022823563 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark01(-92.60787816778755,1.5707963267948966 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark01(-92.67696450452833,1.5707963267948974 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark01(-92.70072236338885,1.5707963267948966 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark01(-93.71441727783017,-107.77858715155624 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark01(-93.77670221332606,48.516062251109474 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark01(-9.391249195652705,1.5707963267948948 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark01(-93.92991467099286,24.31993173113891 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark01(9.396571501990227,-0.23806249115550013 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark01(-9.424775101362657,0.001126688257811399 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark01(-94.2479016780067,-4.712388980224349 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark01(94.24868407667718,0.04259601930614931 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark01(-94.26188755352891,79.49588114112359 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark01(-94.2698220665158,-100.88804236118133 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark01(94.40376332019592,19.414444914623648 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark01(94.43400909974335,25.50334305523367 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark01(94.44106226022703,80.11084862732748 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark01(94.4544360972482,-1.1984769790506262 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark01(94.46359396404623,-0.3614451044135194 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark01(94.48785395567322,-87.91652006471212 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark01(-9.451243232939046,-67.48158738790076 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark01(-94.54014432813635,-1.5707963267948966 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark01(94.55355800529475,0.0 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark01(-9.472348248304897,34.67850800564901 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark01(-9.483926443619326,-3.2766554458172297 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark01(94.85281209801401,-1.0081713948177509 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark01(94.85425871497591,94.39004242911881 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark01(95.18684723456693,-1.5707963267948966 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark01(-95.2013070758761,1.5707963267948968 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark01(-9.531438154999194,-21.473285577159757 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark01(-95.3379778511742,-14.396412885775144 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark01(-95.4521463769564,1.0404910168830668 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark01(95.54570366561502,24.48962841160254 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark01(95.5463533567733,-18.417456378699086 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark01(-95.62749251796757,-1.5707963267949019 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark01(95.68148734488429,-44.08024509438617 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark01(95.69817276548596,1.5707963267948963 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark01(-95.75039604172827,1.5707963267948966 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark01(95.81594609385047,1.5707963267948983 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark01(95.85395296463423,-0.3022052570614441 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark01(96.00164504487057,-56.546127015597335 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark01(-96.03785101833151,74.66048412178543 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark01(-96.11588921621322,0.08916970231547769 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark01(-96.18895123380585,-46.59096269315255 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark01(96.20309726094553,-140.78687265974116 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark01(9.642435212943852,-79.5049296142758 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark01(96.52664362265952,26.681913151721176 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark01(-9.65798434351631,1.312507172887427 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark01(-9.673117363340651,54.590143572844596 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark01(-9.681986803649894,-23.563403667053763 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark01(96.88607432545817,-32.44258242623602 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark01(-96.89517047792397,-80.11061451961805 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark01(96.91380746307439,-1.5707963267948966 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark01(-9.692352116806178E-8,-100.53353559394724 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark01(-97.0077327627305,-8.420688908861705E-5 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark01(-9.712408114754467,-2571.1667782432346 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark01(-9.720936826397573,1.5707963267948966 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark01(-9.729744539502953,0.0 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark01(97.31572587639474,-0.3860063696617663 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark01(-97.38937066939954,-43.98423770253809 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark01(-97.38937085904142,157.07963267669174 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark01(-97.38937225227652,1.570796326985749 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark01(-97.38937226128357,-1.5707963267948966 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark01(-97.43270967134411,1.5707963267948966 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark01(97.4812841522591,-2.2752107473222054 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark01(-97.58581210753005,75.27280150346286 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark01(-97.80681960091002,4.2703759453826535 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark01(-97.84633274780302,0.0 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark01(-9.799196905083278,1.5707963267948966 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark01(-98.16731468735244,-71.75441297359797 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark01(-98.26677685612152,17.328051256012728 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark01(-98.5434629034269,0.0 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark01(-9.860761315262648E-32,-32.98673929940938 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark01(-98.86453908171127,-57.5741903773032 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark01(-98.90013327292463,0.06018903455277675 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark01(-98.91601060393684,-4.7143421054587975 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark01(98.95426813569861,-4.707479942793327 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark01(-98.95866230219703,-1.5707963267948966 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark01(-98.95965803836509,36.12831213699626 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark01(-98.9609977326359,20.420352248333657 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark01(-99.10437165824514,4.837388980384691 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark01(-99.11548892247978,-75.63058006358723 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark01(-99.24306468704991,-93.2166767876045 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark01(-99.26291295430424,21.204427699126175 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark01(99.3802248478516,84.97788874557816 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark01(-99.4659282162854,-5.924281852018211 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark01(-99.49290704736649,-1.5707963267948966 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark01(-99.50232828168326,37.69879149439083 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark01(-99.52086320822272,0.8590602254814768 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark01(-99.68866835041692,16.710619666347966 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark01(-9.981359658939375,-90.1080124765392 ) ;
  }
}
