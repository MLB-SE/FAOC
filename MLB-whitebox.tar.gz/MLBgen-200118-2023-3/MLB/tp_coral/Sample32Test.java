import org.junit.Test;

public class Sample32Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark32(14.180707146258584 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark32(25.000000000000004 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark32(95.97752888187583 ) ;
  }
}
