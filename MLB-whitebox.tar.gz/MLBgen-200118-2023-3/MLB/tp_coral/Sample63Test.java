import org.junit.Test;

public class Sample63Test {

  @Test
  public void test0() {
//    0.6097774439220578;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark63(0,0,0,33.49213606538203,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark63(0.0,3.5342128358253717,-14.58404224396132,-43.4898532559838,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark63(0.0,-7.105427357601002E-15,28.862236155575317,-96.11270529579966,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark63(0.9985095378429794,100.0,99.92544910296772,100.0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark63(100.0,-100.0,-100.0,65.15699598628972,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark63(10.270910830517593,-15.519795499837485,64.46107349302304,-0.3379528987827314,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark63(10.91524447245095,-42.41489494203839,-72.08053405785866,1.9451788027674155,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark63(11.349598641147992,-49.69618622324023,-33.1690506848262,0.8008906676487868,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark63(11.5711017136545,-5.435048974075585,41.55465317504394,-6.603631382397339,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark63(11.582894473377124,-0.07236038450129456,22.81710204640666,80.9180736553242,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark63(11.596076583223507,-22.093120533773188,91.64095524939785,-1.1728419832283379,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark63(11.610896863908394,-17.78526271324469,37.002620094836004,-0.16508340449932746,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark63(11.807303156702616,-5.920933644941087,7.443319570604174,22.562327511529418,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark63(12.105581251407258,-7.494219053725033,11.006606628609433,-21.649342037372435,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark63(12.270927032205265,-4.57492461790261,95.05992638271766,70.00770119372811,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark63(12.449589583517493,40.83402795933512,96.64699182764446,44.92219396397434,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark63(12.517466128773776,-6.656675373033892,-11.331115082234462,-59.676356029538226,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark63(12.631266458367278,-21.17507210943188,-72.64916701891482,3.050910694718283,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark63(12.661320469224592,-9.660930494412952,19.43510106067339,-16.002255695118734,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark63(12.702976003540286,-12.271537059954468,32.83555982634826,-58.905638989649425,0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark63(13.008163333538917,-2.8019223130094417,31.14818126401883,78.48808006971055,0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark63(13.740625188268666,-63.27140655922747,30.79238989507391,-0.4235188830990779,0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark63(14.086657233978414,-0.32411786737158366,5.5097757791653095,-98.63815789170161,0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark63(14.13635391852226,-11.370049265771897,-29.02569884109589,65.8647850242709,0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark63(14.309344172290722,-5.61645550808197,92.41575431891783,23.075794770733225,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark63(14.435136257051994,-2.7198961612945993,95.70112455442003,17.05928957509144,0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark63(14.450887870849158,-12.265153996918016,88.08954614634843,-37.046208619829926,0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark63(14.49178863136018,-1.2522682872994295,90.08998274975141,9.158122672917173,0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark63(14.564348987323925,-7.800666038737319,78.00450276363665,-49.27206978026353,0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark63(14.585641018083749,-11.887831295724325,11.593562164534106,-79.86135323499026,0 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark63(14.665528170208503,-67.86266576829334,66.93264296967337,-0.22878796997160578,0 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark63(14.667208750137632,-3.3624833213618643,18.389956104008903,-27.243756450219394,0 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark63(14.701065759210124,-9.174909882302742,25.93978832494666,-92.12411136176442,0 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark63(15.18349289099558,-15.062073494385515,67.31934042148711,-29.215836341811865,0 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark63(15.309769593013584,-7.49522360908739,95.40617605491175,-43.62947123510046,0 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark63(15.483376189834928,-0.8673306263324889,27.93190750283638,-6.621230777886723,0 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark63(16.001398575001986,-3.3649308728854237,0.3256052014317419,-10.401370986921137,0 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark63(16.01441484205435,-8.476955612221545,95.71039953002014,-66.0336011841494,0 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark63(16.143395621619987,-0.2693852447553269,23.869317046460452,-70.22869107477555,0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark63(16.17084984027848,-16.523201936067593,24.46218253915795,-68.66134573410456,0 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark63(16.27384035982591,-13.804059321219015,29.026753413050358,-67.70860552423296,0 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark63(16.31502237620424,-14.145329084050331,9.305574123395502,49.95091590482352,0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark63(16.353422309799527,-14.8128814957077,43.256961726535536,67.05681876542295,0 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark63(16.376468690735877,-1.2551402667182856,4.623951214258852,-37.789366225069834,0 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark63(16.69301347755352,-0.5529390310727251,27.339448979116355,94.11329797303293,0 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark63(16.938028003090167,-4.948960334471522,-3.688558992073723,-86.1110295938045,0 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark63(16.9538110897508,-19.381682104350745,91.6918977586823,-17.178156423328517,0 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark63(17.02406149774322,-14.22375067985746,-38.775605271960266,49.031552651874335,0 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark63(17.098943277861594,-6.412145305139333,86.26393220616399,-25.279089510775904,0 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark63(17.187420978274133,-4.794070035660411,-18.12333392582181,-67.76845710246606,0 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark63(17.261532718204478,-10.312755139253895,64.05702639525254,20.021236484486565,0 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark63(17.48131213932311,-5.209401384756205,5.551977016944079,-58.5559894664061,0 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark63(17.612390306694365,-9.330664409056169,67.84636956134878,-73.88835081068177,0 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark63(17.804703711329722,-3.9472269847641996,24.05856653634892,-79.2075081520502,0 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark63(18.184918238218643,-13.298714182616877,-14.28150076777186,9.842090522179731,0 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark63(18.187277731994797,-1.032988615766044,36.71008749655164,45.332339274327836,0 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark63(18.236360573839946,-33.93727103087423,86.86921098044144,-0.6640330931462586,0 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark63(18.5437816431689,-4.537125529103676,-13.648132290157108,92.0015010672916,0 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark63(18.559995210228266,-12.952300225921974,3.5603433024124342,3.7483713455982013,0 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark63(18.617170776321743,-11.598721283139298,-40.74402365860132,-6.16296085970518,0 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark63(18.762647925002682,-0.029312812107434638,79.06315369140827,-56.224189580546295,0 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark63(19.059365079117782,-8.088727807675909,-13.730379194858287,-20.011848793176227,0 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark63(19.22609795248323,-1.8980116737577362,3.8446374590461545,-39.53408687586033,0 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark63(19.42650789276344,-11.519037091905446,11.36570410300584,-24.02314753052886,0 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark63(19.48360147855574,-6.158008659874838,-18.738105115514657,61.594330725023156,0 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark63(19.72045549491517,-2.858354453867179,0.19142091709383635,-22.60498646109228,0 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark63(19.877014648735553,-18.229041147174854,87.24726569145156,61.10459441312031,0 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark63(19.934556800507977,-19.46524637225113,-17.5635083660018,99.98473732633713,0 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark63(20.023265750502844,-9.76270134852733,-17.25595036355176,-65.99693683347888,0 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark63(20.061608726748275,-0.6393314220784561,25.506758699697514,-26.030337683926263,0 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark63(20.592378866940678,-44.77054627351072,-88.5959800639408,0.9776727358288468,0 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark63(20.6605830003532,-22.049820981525016,90.04938996381716,-28.53323229744136,0 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark63(20.663232225376674,-18.987584619009112,2.1345073439828894,-54.104599465880376,0 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark63(20.758341434859233,-13.244385203731369,-34.13513101489612,-35.45182563346252,0 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark63(20.824591434552488,-34.01608716247884,76.9620942602042,-0.7577471301560621,0 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark63(20.833737593131673,-13.947697398771368,-18.34141499425985,68.81386431911577,0 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark63(21.05991300640453,-11.39079112784276,95.78708831413385,24.80744187180575,0 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark63(21.131202919192788,-16.973879097036672,94.68189063559763,93.59196498899146,0 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark63(21.25125974598727,-3.5161335157687006,88.44435919486685,19.012572442182602,0 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark63(21.276146885174214,-62.52647957800603,71.07527869683577,-0.7420527744189371,0 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark63(21.324465697059594,-17.23598521168472,4.002551746984565,-61.25604243005731,0 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark63(21.334236610076758,-11.723666787482529,-28.60403764380419,28.638228843336606,0 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark63(21.347764606408745,-12.967405479410374,62.49468287189234,-70.06883289268104,0 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark63(21.372152248864367,-9.755451742247374,25.038826901490637,-60.92656832114336,0 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark63(21.373877524585012,-18.882270161195976,2.5474549106516235,-30.362074339097106,0 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark63(21.473427962309515,-20.128535935466545,94.55240341409211,-80.67241395482274,0 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark63(21.68065074202225,-16.290656816821198,-5.0093840626863795,42.849563033773165,0 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark63(21.791620390679483,-11.061445016202299,35.19894698413509,-36.67512128719794,0 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark63(21.794080082055814,-16.727028961193824,36.863287247880805,-78.197530210352,0 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark63(21.794929772579223,-6.3675054524240124,98.7224866806477,-51.730875159156994,0 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark63(21.986973510835057,-0.1220827812543348,54.291343708158905,65.81382131478316,0 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark63(22.026209806522772,-7.046057633036625,77.20774190670517,-6.751338313211349,0 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark63(22.188617918534874,-16.51396518683312,14.031326217051458,55.887081360050615,0 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark63(22.246122264647397,-4.829653838469568,68.35984537487957,95.0949814948732,0 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark63(22.26051339528334,-9.317748357890324,31.961561763203093,-89.70145513076835,0 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark63(22.269040945610882,-14.99715102740771,86.93524913288951,-45.91684353793817,0 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark63(22.384902889894008,-8.193345162960412,33.1842632939599,-84.73699113947777,0 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark63(22.441575405817332,-13.143134590655151,10.588847957405648,-75.36642714071778,0 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark63(22.44257414242321,-1.1570715737634174,37.64823857447391,19.71422250236847,0 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark63(22.45271751299356,-5.601956574864843,58.94943168990366,-68.15083192339677,0 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark63(22.565478659626876,-5.765891986273019,-17.678030200924624,81.15138214513584,0 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark63(22.709326398049996,-10.212523641625083,97.00811030522837,82.800731592777,0 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark63(22.7504254387311,-2.964363781585533,46.22460276482926,-17.985713430372584,0 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark63(22.768729035455507,-42.06179418392557,-54.353148796321406,2.237539996301024,0 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark63(22.848276207351503,-19.830731067914712,-12.859737317070724,-4.682192397818682,0 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark63(22.856612204503207,-9.348985330227862,80.15076920101393,-58.114607038428105,0 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark63(23.154530232014125,-15.349256342745448,55.50927945444238,-0.32906125320310764,0 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark63(23.187125532674727,-13.006461453011298,-46.13914811764248,-96.21829832950075,0 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark63(23.222084893808173,-12.120232347523043,-15.881952651525012,-51.474794599488916,0 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark63(23.235810448538928,-17.083836123974194,-67.54337041567284,30.24506676312319,0 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark63(23.330121754586443,-16.18423405528928,-4.9942042725481315,-49.84290379960186,0 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark63(23.476937893415013,-10.500296139722835,80.66113229346277,-98.33123904753947,0 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark63(23.478911538481142,-20.1315477439816,4.6713568316632035,8.196309160382896,0 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark63(-23.537893469069317,96.4130100287004,14.673692317493405,-53.28138540578693,0 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark63(23.54801689359509,-1.8388232598185255,79.79325647133803,-45.48304221462527,0 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark63(23.567597296830485,-20.996013313734437,-19.764283403903036,87.58400253338982,0 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark63(24.099640027651304,-90.86434227989575,-22.547727590226202,0.30986606205338774,0 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark63(24.11099087457744,-13.615399249449538,71.72174246999015,-13.52896516941668,0 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark63(24.14641699035593,-10.604745162422162,44.796417556836076,-10.02766109854565,0 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark63(24.200197601773013,-22.94181048169837,51.573458623343186,-84.36894227939547,0 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark63(24.27493926855611,-8.504464565562003,20.778865065631535,29.328920537996083,0 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark63(24.45125773622361,-18.760752592935376,-83.67632634016722,82.2919643536687,0 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark63(24.517525594026452,-15.236836280028172,50.95045070409256,32.017467149185364,0 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark63(24.608639651172012,-23.57273918719551,-88.41364949576871,82.3375289212319,0 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark63(24.70724010963859,-6.331705265141082,36.65583478421789,25.679753379042026,0 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark63(24.808336983927745,-14.114483124579593,-36.98983372763918,-36.09866396992392,0 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark63(24.865084979385244,-14.150942098286109,6.385319587001021,-10.100406501078666,0 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark63(25.053304909291626,-5.187764950004876,36.41949201121719,82.89884322972472,0 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark63(25.071213250521524,-20.24062241698634,16.721228771919087,-51.88047020339914,0 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark63(25.0997990567097,-24.084883414583942,6.048912015300374,-26.55240807589763,0 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark63(25.14550897903105,-0.7985948933937976,94.02259821160581,-37.08766169443065,0 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark63(25.279981646797054,-18.86847198530353,-28.49922941145782,7.492447456449085,0 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark63(25.28931420345826,-0.17184360428612422,94.5643355370313,41.017034258325225,0 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark63(25.32365946830764,-9.580642251727213,-35.94470568851382,6.947146549727719,0 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark63(25.339211674511503,-2.065511112643435,27.34212191283831,71.0310871498609,0 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark63(25.38470836955888,-16.607546984986527,-28.65882519908824,42.96318701844464,0 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark63(25.42725191930215,-18.46946133206761,-77.55838252936344,-34.91913773681159,0 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark63(25.54975681699736,-19.583711940337494,98.68319748731517,99.76281965348556,0 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark63(25.606509985672062,-2.58416426187857,-6.3702507037500595,93.83917335620384,0 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark63(25.714120033683614,-3.0827611048800208,-9.834457748731083,-86.31471494688452,0 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark63(25.75794606584809,-22.025026331155246,41.37340766192642,-24.429566441807495,0 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark63(25.770262159054596,-15.054622420039834,-7.496978645183262,12.995034827523938,0 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark63(25.812717379323786,-1.124995097299859,60.93344041624624,10.555613222636978,0 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark63(25.873949376104207,-16.864472193784394,61.88634929760971,36.75368766702323,0 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark63(25.951134843396687,-14.33473919908414,-21.625558779436588,88.29684638276916,0 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark63(2.5956111157583734,-1.6906451555029065,94.23564767955952,-8.637564311120997,0 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark63(26.004258970258377,-14.40050915903457,-57.2459070302779,-95.1701076263117,0 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark63(26.20722980167662,-12.712526828725942,50.88946387499064,34.26309819660182,0 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark63(26.2186021842911,-22.01751618872069,0.05904370075870702,-74.78000451007523,0 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark63(26.239581020695013,-16.703861583899297,-50.35172879802885,-28.860441109060474,0 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark63(26.246575220061814,-17.098937811351007,-9.35315682054258,0.47609899230080543,0 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark63(26.29540868915703,-6.66908360953731,-31.23595599536644,52.446825937754255,0 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark63(26.317045216294346,-21.357969956568496,-89.30000849369898,72.6544613348668,0 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark63(26.367554055889173,-26.66343143176711,56.1044797757358,-46.94347467483977,0 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark63(26.38812783271733,-16.028473898503265,6.309465627716264,-93.03525319830577,0 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark63(26.46446494940197,-33.42515534940304,-67.74045349639184,6.8098241951768586,0 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark63(26.636582714018317,-22.463533081977033,-68.67229072895398,76.65403758936773,0 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark63(26.641043036272194,-12.208530575772471,71.19687629860056,-50.4779282463699,0 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark63(26.661903311404615,-18.52691697699491,-65.68284818453525,41.60030739976159,0 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark63(26.698402305552804,-21.999195615125274,-68.88323534989303,-35.20003137402885,0 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark63(26.73519255884196,-9.265050849474193,48.700102710322426,31.196871908337243,0 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark63(26.967945026110016,-27.540992638363008,-58.936980669829865,34.56380548449246,0 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark63(27.134527388377492,-1.6698076403891378,24.956712504681946,-13.124615251314765,0 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark63(27.20528544227004,-15.982282803709793,-10.253556682875796,-62.22053789413404,0 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark63(27.21976396276473,-20.32033262630391,-69.31591549648537,-42.756180399603295,0 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark63(27.440626430647157,-25.359816710822486,65.49794638571223,-86.7078849833937,0 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark63(27.52696173263854,-9.107877680831507,13.039780752659496,-60.682167594954414,0 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark63(27.536684011948196,-19.477027709718328,-67.15744336683476,-60.40228688615359,0 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark63(27.545052451288015,-15.086884679662973,-27.467361173301825,-89.88754901708805,0 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark63(27.566350905362995,-13.400511322509743,61.39622084229936,-27.798198246390243,0 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark63(27.624084444886577,-22.09373715799599,8.812306514141483,-18.715052973986346,0 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark63(27.675959928629496,-25.939708799812905,-21.837767861151875,25.204367535847737,0 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark63(27.852907539584578,-11.96010948186452,44.13312131565718,-60.966647203159056,0 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark63(27.857833056641653,-5.155102027609331,13.49956564142083,76.35114269700125,0 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark63(27.901969518381293,-21.445443219083458,18.205827391084867,-73.21167601522359,0 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark63(27.92481681175336,-13.552227413052137,5.843702628645332,-57.93796195636573,0 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark63(27.942288651811054,-24.79097608888854,20.294631772426825,-91.20787477957329,0 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark63(28.03178933386002,-6.7414503055749435,-1.57787941409633,-90.37004617857511,0 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark63(28.074197609669284,-4.958910362659282,42.94880056658815,77.74122796983303,0 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark63(28.15330098067861,-11.505730715440393,-37.46960013465823,49.19931917822652,0 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark63(28.169657691187695,-6.904771116003076,-29.738676530999044,10.91729444306084,0 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark63(28.181150053996674,-13.458862996732307,-66.03069083052713,-49.29143433045859,0 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark63(28.24054663655147,-10.29600530967869,-29.020734813592554,-84.55611999859079,0 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark63(28.5057068642854,-23.758702778409614,-23.727310732532672,64.14547398584702,0 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark63(28.632003933665004,-15.124459645836524,41.40733497240976,24.780640307807886,0 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark63(28.641069606593334,-11.442235426829654,38.897246595140814,-79.548265580856,0 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark63(28.81355472259918,-23.327376522416785,-91.1127950042611,86.2952924813429,0 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark63(28.853863737360655,-11.573736725001055,51.938260962898966,-66.80152368940654,0 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark63(28.87222337438436,-20.43329003877716,-65.1708319799031,6.74430803191764,0 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark63(28.880091209161975,-7.072179941480414,19.61672656852795,-63.69300736686372,0 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark63(28.896242440705464,-15.104420169032863,19.231171297535397,-35.001988489790506,0 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark63(28.921651852762068,-12.334822407760313,22.57139760585609,18.54192127975365,0 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark63(28.95513092727643,-20.14882965012265,-67.88007874195605,24.641756891159787,0 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark63(29.07274009251566,-1.9395472438259276,46.84920642110748,-65.4476252984082,0 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark63(29.242816466446982,-22.17121054034908,32.493997699251764,-53.30269537677128,0 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark63(29.249537668581553,-0.3351056061138564,47.777981347991016,-98.02657982601444,0 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark63(29.253137529263427,-28.376036813149867,56.2697212579161,-82.60058541670395,0 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark63(29.35636551857891,-18.874606364813758,-96.90864686257802,-71.08326599410815,0 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark63(29.415305328210763,-40.781883557687415,57.84344006798321,-0.38952399063096266,0 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark63(29.511441086323543,-2.899508725178663,-8.617952918894161,-39.062676286063876,0 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark63(29.511685514765105,-10.953987080762488,84.9807619722342,-12.799237536546087,0 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark63(29.528188146573797,-13.720456518440272,-15.597761355452164,33.07143350214602,0 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark63(29.542262602332414,-27.3550778238955,-2.9221168442766157,-63.23352311024601,0 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark63(29.742631854203978,-27.217662418981888,-14.583334552058773,69.44672388050367,0 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark63(29.748325668394386,-4.1091689725081295,84.94477736601667,-81.86791281533263,0 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark63(29.81862579653881,-20.6713825951733,95.2563718450622,69.35594304748676,0 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark63(29.89999456830631,-4.75955595805506,81.88936344192564,-48.6999404604505,0 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark63(30.058401437359237,-12.679543445216979,-57.162012945419825,-91.58410570059871,0 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark63(30.10588079886614,-3.2902266646256777,97.61706518513432,95.22236658341913,0 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark63(30.171924995767455,-25.158201904118258,65.11659215243222,71.10015482115878,0 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark63(30.205928063637174,-7.722799023050612,-35.81998753007636,37.087211557216506,0 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark63(30.241365003180675,-10.181431518558014,21.0852892036326,6.878842557917949,0 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark63(30.248428740418433,-21.13568876934795,63.855865710186805,-86.0857487101685,0 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark63(30.267333329747828,-15.479229467622304,90.67383281036254,-53.403155609860264,0 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark63(30.302223692112022,-11.243100585265964,72.14634091016052,-73.92168078986568,0 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark63(30.520401176874998,-71.04479274538677,65.15305132661169,-0.7402814137864624,0 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark63(30.56332843821633,-28.885391810926194,-32.06334285666152,-30.51529977861587,0 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark63(30.616057293291334,-22.232530720209297,-4.03961306436382,3.8598424477481927,0 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark63(30.79154111205534,-9.640267686017538,-10.306307723833115,36.668708120277216,0 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark63(30.88488623862935,-22.028078000457057,-94.43324207618524,16.297502080390558,0 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark63(30.88984970137352,-6.53141317650028,44.63296147137714,-55.490332273154074,0 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark63(30.90960637470019,-6.834744508969038,-34.37608146816021,90.21895075478164,0 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark63(30.97055550082547,48.683549692012264,-22.69951480646462,-61.16338808833734,0 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark63(31.01231328965318,-77.87497620221168,78.07037829236296,-0.4936391276542338,0 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark63(31.195351108574954,-16.628545440079122,51.21248141986689,-11.098677797474977,0 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark63(31.21811820812829,-30.383741757569908,-38.45354281012976,67.7635352235942,0 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark63(31.44283921614209,-32.55840035783828,75.0337583279329,-1.9403058437603704,0 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark63(31.53348019023784,-17.33656732101136,-14.19773856973967,-56.70456641767912,0 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark63(31.555143675720217,-4.128038089809223,74.06370725582815,14.816418722592445,0 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark63(31.66070622429325,-26.672968430983573,-74.83742905895478,-69.73568386375962,0 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark63(31.75933294732701,-18.62072846440455,87.35403570385353,-44.32228503338107,0 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark63(31.837963630848066,-16.85598362764958,47.65750949753641,-78.80949575780707,0 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark63(31.83816098262369,-25.06606611253015,-78.20100967908583,-58.10275625561609,0 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark63(31.894356293342724,-20.059167641349006,-73.78897780990516,42.704254276759315,0 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark63(31.909209139132656,-28.327394223391337,28.356068429561844,38.11607565168492,0 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark63(32.01394493573156,-7.434964735127124,22.903576204635925,41.64441208202763,0 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark63(32.03208555653393,-18.525587209266163,-99.87772521218278,-93.04631175159766,0 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark63(32.17039943912917,-32.063945229838,-66.92365119062751,59.73405697958049,0 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark63(32.18675727848097,-10.315008562556471,-41.41821447149172,-3.7565810246557874,0 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark63(32.24878164099633,-28.81919578292758,55.315586103258426,89.68058556213961,0 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark63(32.255590265193916,-19.392565755225704,99.07913583125821,-7.602712140019179,0 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark63(32.27554297989573,-6.220079748996213,11.055557210725638,-52.96623349384952,0 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark63(32.309385944055975,-25.904187994518608,68.2475743759694,60.83581723780412,0 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark63(32.3752130310061,-45.0908813092898,34.465646174886416,-1.9966063288910902,0 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark63(32.40052294600699,-21.94186947205938,99.56480141938579,16.55907001762212,0 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark63(32.439140162298486,-30.30887488648763,-93.93663522434497,18.3104453113188,0 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark63(32.45929121402503,-1.3936990472568311,28.9953804644513,-21.35154295678707,0 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark63(32.52218320899502,-21.161349787572405,-90.80777243696888,-85.33356527527356,0 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark63(32.553053286883795,-26.75844539320471,-14.991264386535732,-46.83916619916393,0 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark63(32.5649318191374,-22.86551158300172,-43.67005282432641,42.659066639425134,0 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark63(32.5914391414114,-15.86920642851939,-58.973781481656886,-11.231751915387278,0 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark63(32.679375896250974,-15.431412445487538,71.01137620744456,-79.59727954260657,0 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark63(32.702718898476576,-2.108260301773953,-8.777948877242196,40.04481106091572,0 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark63(32.7444066555029,-12.294998975900626,49.508524679017626,-54.610137138730465,0 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark63(32.752764988610494,-1.15765717815799,23.94793492101948,-32.9294564480396,0 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark63(32.758517107818506,-28.583481521751125,67.45497109529214,91.91474574374485,0 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark63(32.81524879355047,-8.414733993345607,51.68379654989232,-92.4207855829229,0 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark63(32.8768038222525,-34.5640704212568,-23.647243545523125,12.977878751552964,0 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark63(32.934045597333636,-8.275761757241028,-6.229593436727285,39.14948989943039,0 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark63(33.06886992754468,-11.107638609879913,91.42421054758657,-77.4239494629137,0 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark63(33.11426416540303,-31.23264169636674,-29.43918940162378,30.59015693798466,0 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark63(33.18266353559005,-29.586669317247654,-87.31773899796468,-85.69395574362622,0 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark63(33.37036421244659,-22.39142803634968,6.940680198008494,-58.79383989821394,0 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark63(33.53176223408872,-23.39670518889872,3.489181331408247,56.96035339545452,0 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark63(33.533734595234876,-9.552402365363946,43.13415453167573,13.738663216549469,0 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark63(33.64200729322201,-31.47781895290278,-57.24231979799037,-95.84625472204216,0 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark63(33.66267014959814,-29.841965608589476,20.043317371589993,-11.016549409181309,0 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark63(33.70617119502384,-30.06302446881348,73.25834922002903,-58.204885352203206,0 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark63(33.74923973878322,-7.500527946887956,-20.305447345994793,37.44438350594916,0 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark63(33.891225398328515,-27.715299795987562,-33.723515172582054,-91.70625029883162,0 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark63(33.936636812550205,-32.563664617395744,-80.92665376221007,-92.96305292290378,0 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark63(33.996749005081284,-29.72286901903449,63.049622096067935,68.94589912817045,0 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark63(34.07218972374537,-0.8573962444418726,35.32371565433732,94.6218912068104,0 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark63(34.082174425380884,-21.151622531248407,71.57649985354362,22.166484914888727,0 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark63(34.135394079001856,-26.961332504590445,-34.721585763367216,-47.82733330210283,0 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark63(34.17338756533778,-11.496513261944415,21.136513662318393,60.42550554134303,0 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark63(34.19166236850742,-50.69685656385899,-42.98796107548939,1.5383166256840042,0 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark63(34.240360598392925,-12.629352036589921,74.31987147773259,25.80822224071096,0 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark63(34.27222178133539,-14.672944411549537,58.3978620314941,8.655625439966059,0 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark63(34.318745320984476,-5.281570125430605,-30.30166190339665,-53.49934120434461,0 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark63(34.32977617848144,-7.56535972121948,3.821445326475697,10.165132522472064,0 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark63(34.33931435693742,-20.613808066026934,85.22836613422052,60.39171141166966,0 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark63(34.3685560304105,-29.852653081081897,-64.64885378786913,-22.788332200653926,0 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark63(34.37120390828693,-27.42995892190838,-14.477107817693891,75.08677352471048,0 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark63(34.375462318718206,-9.571366843694733,66.41836495761297,-6.607264700197874,0 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark63(34.43418257151524,-34.882294987583066,79.2856451422357,-67.06442519913954,0 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark63(34.501829303326815,-16.949548848065604,67.25327107848435,16.902969515881267,0 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark63(34.520234654614,-11.3900212996884,62.27420871769965,-96.94901110613145,0 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark63(34.54802632695666,-4.72793056241801,11.778704000206417,45.4944173898582,0 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark63(34.60140986131134,-4.128693484772256,43.79441540962543,3.65283702361981,0 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark63(34.65148166115256,-23.47951308205272,-73.67547040009943,-57.706657554281726,0 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark63(34.65730495963277,-7.330418571552059,99.05024249886353,47.8795531392953,0 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark63(34.666667338636216,-33.62828434227882,38.211407112468436,-58.097496398537565,0 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark63(34.670495790880096,-9.293147757113559,14.03258704033938,42.140512007203824,0 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark63(34.69534024303715,-34.39420859690354,-47.04529641551882,4.724176889342303,0 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark63(34.750629509176946,-9.880965216194681,-20.480608936953644,88.85367505860492,0 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark63(34.783148996390224,-32.014468163486455,40.521768918292565,-15.712120974319362,0 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark63(34.812518402071106,-6.0369790989169445,-27.21409040580629,13.711500114802334,0 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark63(34.89685079520456,-37.82074318007347,-18.92128959575497,1.8994069684301422,0 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark63(34.91848531068905,-30.953689011020003,49.8358056996708,-74.6787113262958,0 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark63(34.93312352850651,-24.167397054981947,-4.475523364100752,79.36677064258319,0 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark63(34.9762837304626,-21.93167459096172,51.29193294359345,-56.40992657655739,0 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark63(35.00852747788315,-29.598019800355786,-69.09140029902123,-85.12630450286625,0 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark63(35.02236590591582,-30.852523625371035,51.62152086996133,69.3214416956097,0 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark63(35.022529641623436,-4.220826967404648,24.23817388739134,-86.78207778886116,0 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark63(35.149294146938985,-10.966956967843714,44.77923199642359,-35.95716736849346,0 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark63(35.19023122427188,-33.358050645276165,53.22933490457186,-78.76043733119455,0 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark63(35.351313620720134,-18.77126569053202,-2.4645254952804834,-25.28481285863498,0 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark63(35.45250710923318,-30.877869759828684,28.493166202950846,-90.25013686195611,0 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark63(35.45637023604698,-13.360809470992564,55.75196719663967,64.02391593421058,0 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark63(35.48894349634617,-26.60173578173189,95.77999824910975,25.11259346203498,0 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark63(35.57268663959621,-10.816174612771576,38.33151676095065,55.446824433765954,0 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark63(35.59461794753287,-3.9197718257809555,-11.447524564414095,86.65890327832238,0 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark63(35.59849127729612,-22.356312887520488,-5.9467084904143235,-7.903053425299163,0 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark63(35.60850229495858,-13.9010512269423,11.88072772452881,42.760885811262426,0 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark63(35.68404962349342,-23.673500132676907,61.30357320594658,-27.781803971587053,0 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark63(35.70326346821162,-28.026628432185092,-20.308512767913527,-27.432789509434443,0 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark63(35.72066860989892,-30.740865359632693,-65.18128808829387,6.875218177147573,0 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark63(35.94858507364657,-15.687762011386823,53.722304696130635,76.32905934992033,0 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark63(35.953703032319055,-21.84791298242115,-17.519802211435163,-87.51625904696829,0 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark63(36.04787338887593,-27.271876624811654,83.16109069542571,63.05657084266679,0 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark63(36.06333589609022,-32.15650787352979,44.22609138042364,-26.4712695754054,0 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark63(36.32270296360812,-22.021823567295584,-53.87978154258122,-13.66871888691253,0 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark63(36.46964573038417,-11.437180992467404,3.2058435263193132,-62.492650601001046,0 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark63(36.48318469212879,-11.456557352179786,-33.33593972063005,69.17035184384582,0 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark63(36.58043216082524,-17.92521745174392,-84.0302543990816,17.135713009336897,0 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark63(36.586705482763165,-0.6002684577437662,16.03362835009392,-75.5088727324221,0 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark63(36.6177076935048,-26.591128708362533,26.254431435898468,-15.29563648104309,0 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark63(36.74609222060698,-18.265896490121136,50.437884311003614,7.247432346068393,0 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark63(36.839476130435116,-10.423061057732383,90.11341258199866,-94.98242193034653,0 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark63(36.85328229490494,-30.244223696766866,-59.849544901706686,-63.758468988471776,0 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark63(36.88911029871386,-7.856413247447904,-0.4679397944799888,-27.78514381496555,0 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark63(36.99786445968661,-24.28386149485462,-28.59882133880936,46.90077846378583,0 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark63(36.99886997121624,-17.014281706496433,53.7492110076486,-17.99435336322908,0 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark63(37.03303966884445,-16.05913152903821,-5.5141761977507,-44.942285403733415,0 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark63(37.048567153764196,-14.157200358838182,31.321370996290256,58.10736826122789,0 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark63(37.22426702326578,-23.351248706066357,-27.830411919955523,-87.88865567412371,0 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark63(37.24264651639223,-17.88110018817494,-61.71438457609246,-47.50641957647612,0 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark63(37.24452563327446,-0.6522739780057378,51.524839174806374,-62.916804788868404,0 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark63(37.26147876076479,-20.768991723056857,63.7113307612473,-79.07500875607968,0 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark63(37.27065802809719,-22.802258289607053,-55.45394318545722,-13.343983212419431,0 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark63(37.31596843227493,-20.153213670576392,63.59539264276043,-70.92398983146681,0 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark63(37.397524280286774,-10.955833754269136,21.091464931122132,-97.33392686921667,0 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark63(37.409789432838664,-6.161339070396195,19.9689409455668,4.980698992412442,0 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark63(37.43685029861987,-15.247232927216814,-63.89272985415584,33.246241362201744,0 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark63(37.448469619675336,-19.847586125100293,29.121053458948296,-85.02486939039657,0 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark63(37.450963513964695,-29.18862213851341,-30.326295221055588,-91.44942447858591,0 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark63(37.5562750528336,-8.9342745832204,11.914240125940495,-98.22679624637065,0 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark63(37.626323410210404,-29.02432037748339,-94.07715250714459,-93.76006459994295,0 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark63(37.66822249741105,-36.15056034324362,33.1456672184639,64.09534924636571,0 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark63(37.70287037484377,-4.848685918534329,31.19532200146645,8.392810541628009,0 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark63(37.88737426964826,-29.346278076128968,-12.672330347039647,96.95337376060479,0 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark63(37.8888359776947,-27.651475410069466,16.782471017329485,-82.51512552421256,0 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark63(37.90862813358282,-33.28537070662239,31.792994974438926,47.86503862017088,0 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark63(37.94599214727586,-2.1802567666594257,40.65259931701485,-1.7404324706838565,0 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark63(37.981161251588304,-24.818316298946016,32.2539646006465,98.03080476047066,0 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark63(37.996519706598065,-29.143139816124148,43.56966638329945,-64.93349458206976,0 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark63(38.00851953226754,-25.094657991132323,-55.80517761103776,-76.88911148675197,0 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark63(38.017978627111376,-16.63725678041139,82.56977294357347,51.613502783550956,0 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark63(38.06341329754321,-14.496743590568741,12.023463728965368,-23.297355238593482,0 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark63(38.1265556744176,-11.85585070362059,-41.33901474209558,36.560124521019276,0 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark63(38.19460787641614,-13.543902919371135,-59.39381483597226,51.90161942547081,0 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark63(38.23072101475543,-27.020087849209176,36.278656893092915,68.04245845031608,0 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark63(38.25573880356515,-14.60693628725835,-49.51467198879025,-87.19185722709162,0 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark63(38.324717396218915,-31.515633788757498,82.02274990315706,-38.491937899674845,0 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark63(38.37567260230017,-32.54343622965857,79.64263526806656,-98.44719925145988,0 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark63(38.39121639486547,-18.16221144328472,4.110661944844082,-66.5606730120017,0 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark63(38.39744364857148,-18.858833543796777,60.89511474030769,-62.852245835110466,0 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark63(38.450129452378576,-15.902206995557819,86.85975557069489,-12.954591435590615,0 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark63(38.541906160249766,-18.303261556453748,-40.12790388879637,54.94677200805046,0 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark63(38.559722802866645,-20.0441762941866,-21.868162535389658,58.503110543243025,0 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark63(38.58822169286276,-18.79674868521306,83.37493478713819,-79.78353234865602,0 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark63(38.65835398477,-22.695970891404542,-15.825975305152994,26.94603305796248,0 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark63(38.7388854672453,-30.528378829729476,-58.1165794990026,4.359247251454491,0 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark63(38.74207494812504,-19.134306066433254,-95.79537660725697,-77.02306160945183,0 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark63(38.80391470771758,-33.1296283059834,-78.61891403266344,-61.50979341394114,0 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark63(38.81283615590087,-1.6132882680173708,58.13479321697335,-80.95977530792115,0 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark63(38.825881603357146,-27.697642075312515,76.22450458879445,79.64003999923355,0 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark63(38.83714450410821,-10.000754522441738,23.222168902768317,62.009695345632025,0 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark63(38.86821231265688,-24.50492930396389,-21.690503665057832,-39.29392719300839,0 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark63(38.88066407534154,-1.362380036824689,70.44325577827675,-62.23043407181934,0 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark63(38.88553485706993,-33.066970993810145,23.872303687430275,87.88565089547967,0 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark63(38.90499539088037,-11.70272244831952,-47.296217508909066,68.02064397852268,0 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark63(38.90893589519314,-24.636079365768097,-36.106871637888084,9.58306887927695,0 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark63(38.91091227674539,-15.819085827348346,-90.67411230999215,80.29712872448499,0 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark63(38.9333182761724,-4.8851406474584,29.14852915822385,-86.73135590656382,0 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark63(38.95245284284454,-6.205376655998961,-4.760770325079818,69.20117888788567,0 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark63(38.996885616187996,-26.775130333417934,-63.61173752038467,36.5766302614428,0 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark63(39.14330162158774,-14.200503988209249,-21.69633218633706,48.2687167326346,0 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark63(39.21090218335914,-17.314996396093576,-61.51524065171301,53.675428394498226,0 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark63(39.21487318777167,-36.79900868557158,-92.03886514645761,-55.43713531611232,0 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark63(39.2383410622065,-25.74948332796805,98.04613405638423,-85.9834464748193,0 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark63(39.265280778599134,-15.108829948408868,-60.87935900038652,-37.11672211647223,0 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark63(39.30437959053154,-15.468132407185365,-27.812900979344676,47.84657088882244,0 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark63(39.533783607351744,-40.110334060283826,53.95195935500706,-93.57716931906151,0 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark63(39.60658851252296,-20.52918812856177,-67.91120356609122,37.77291956263474,0 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark63(39.75472628870628,-39.89177961813202,-98.01149909560249,1.0090024771990898,0 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark63(39.77873958766119,-31.53183804492741,25.891810679997192,83.89763215069334,0 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark63(39.77883325874117,-32.200154275415045,81.96499433575977,59.29421621568994,0 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark63(39.89584228681596,-15.048828511684789,-7.78998874082906,8.828530288399065,0 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark63(39.918776050608244,-14.244826910742674,-72.36456933790463,85.07443902316251,0 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark63(39.91959307546807,-38.37325328697572,27.620565493004648,-1.132293457884387,0 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark63(39.93023016858035,-6.705572133485276,-18.1642005244057,-58.99147853026305,0 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark63(40.01119974315756,-34.35450520462069,-5.0812096189176685,-46.52249559795869,0 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark63(40.01714308412022,-33.24198933284572,51.714826099686974,-11.688816570270362,0 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark63(40.07718585960524,-36.43958339928221,-97.53595147557739,-31.127514786253258,0 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark63(40.08204265242077,-18.177455330709307,85.62395001728666,87.75929558836273,0 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark63(40.112223000092655,-14.599321786913322,87.21686878721715,-20.259064460094706,0 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark63(40.125473510212174,-4.242747676682541,49.8271262615842,-85.21408743491341,0 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark63(40.125709537037665,-6.4391046038831234,33.36511483589476,-82.88876319692673,0 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark63(40.14500015784327,-36.13123550502721,-77.34443169526739,-52.28254929116378,0 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark63(40.18592023667085,-34.15234657492215,15.432341272905717,10.088447305739479,0 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark63(40.354063592084685,-3.6332246210069314,97.36302792608043,13.516014476105369,0 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark63(40.46086168126027,-31.625905213595274,87.26121681346143,90.16460470318066,0 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark63(40.48290074244878,-34.47367197805522,-65.17995576537541,14.29361085944214,0 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark63(40.505743245646784,-11.669456335059536,58.908270366445066,-34.0508752838669,0 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark63(40.62187874942137,-34.70963447892082,-76.8324802609933,56.12561836444908,0 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark63(40.646484615420405,-23.30937697053062,10.278134858261765,8.72553189954823,0 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark63(40.64975652181417,-29.076228655486673,-80.3836828975619,-76.53385772319005,0 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark63(40.66904601536214,-18.84960980195183,90.21556581361347,26.467007823617863,0 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark63(40.67546719523716,-19.947411660293696,-57.908028578070315,-53.03793749970538,0 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark63(40.6789360327339,-15.626988072598834,95.96872974422911,-66.13738248614482,0 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark63(40.72169116516636,-29.458312420106992,79.01918097537347,-77.25986761766639,0 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark63(40.72220022956637,-28.465196642296718,11.049982639916038,-14.20284153724478,0 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark63(40.85051805977545,-4.670812064117015,-6.558520008297265,-57.29428735055717,0 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark63(40.87800882814639,-18.55232123007052,35.8484066929835,-36.86541851388752,0 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark63(40.95042725152439,-25.233237386621155,93.78526266829732,13.792027843132317,0 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark63(40.972160260003164,-9.55103751095892,-54.00968539048638,-73.73114476792297,0 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark63(40.98330217505139,-26.582015838342457,1.3006710406409496,-61.175872715083116,0 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark63(41.01651618224818,-17.17888296795364,6.248433448054541,-90.11326372034114,0 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark63(41.135981673567045,-26.805371668954734,44.23287703928881,70.11372581987376,0 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark63(41.14897053049421,-0.6973468610619307,57.554923514655655,81.61189000703632,0 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark63(41.16845675081569,-34.64519056959054,-87.28615521295234,-88.03395458607119,0 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark63(41.18244279833209,-7.963978125100525,49.20497305587011,68.11404992233341,0 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark63(41.23995182322139,-15.362211579861665,75.57034701074184,-75.03534025861596,0 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark63(41.31105049861034,-32.111741057945494,79.33040334451283,-92.74322610162173,0 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark63(41.344363134247914,-9.95293376314119,54.026793448416555,50.02749874567388,0 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark63(41.34886177557357,-31.880755927056043,75.29557963982575,62.65323800774786,0 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark63(41.3987831896404,-19.555488202142968,-86.34986035068692,78.86021575062841,0 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark63(41.41148282622794,-1.5235609535744885,78.58871575310127,-91.71850114317871,0 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark63(41.411568716916435,-27.16673088325527,-95.58912898439358,-66.41035373301985,0 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark63(41.46794038447368,-52.752072403891034,-89.5494665166284,6.491560407104529,0 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark63(41.475762576415946,-19.583221415583267,41.96466696269448,37.32883628133621,0 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark63(41.51286686303274,-29.82504848443601,22.09429381294538,-25.23513467760594,0 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark63(41.526867372995724,-2.5068821333499045,67.82271649196846,20.95275522680238,0 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark63(41.562101201416795,-21.042442120213934,4.676061168339075,72.50845012065537,0 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark63(41.57908245640712,-39.04549542098661,-76.2506363616688,39.675381936643674,0 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark63(41.79679032558468,-16.52875688532849,-52.104601169417464,66.31215744116793,0 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark63(41.86664720624975,-2.950963835455724,-8.000893126985304,-98.50285367523644,0 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark63(41.89166430920727,-21.92456287338453,0.6100989777888799,50.122778726592145,0 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark63(41.91469892883143,-1.349074005899638,47.88164562615839,-83.9918195755426,0 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark63(41.9274000127003,-39.728075097318,4.2409569860462994,-0.8829296853337212,0 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark63(41.98773827216468,-17.322724756357587,56.40240050388434,42.375892034871555,0 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark63(42.00482426307639,-24.92305411590337,8.62696617579121,5.986114192893098,0 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark63(42.03234244435282,-1.504038831617322,65.40956063154115,14.380594113696148,0 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark63(42.07910588526869,-38.420111972416926,-60.634120168884564,-32.85808827036239,0 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark63(42.145141994369,-9.054616143264099,42.04138992449509,-39.149075815821256,0 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark63(42.17648707788783,-30.92141435587412,6.450223688638388,83.6073563006681,0 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark63(42.18164988196696,-9.314273233726155,-35.1111557659479,62.83131824030522,0 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark63(42.24711477172474,-40.557276437987014,59.47789342284142,56.835996328014915,0 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark63(42.254385061654745,-28.829090825376042,-77.74847840617821,-76.40643731049464,0 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark63(42.375518781451206,-40.009519573431064,-31.26670001355538,53.24669927364653,0 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark63(42.3783295329344,-22.56082532333774,67.96390858688736,-29.82181373190322,0 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark63(42.3805403902287,-35.6587667203834,-1.3493309721229565,30.46802647595365,0 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark63(42.40469097311319,-7.012877371669759,63.525414239942734,-75.52486266568705,0 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark63(42.44425638670924,-33.654157302305194,14.664143593884589,-55.624932343114494,0 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark63(42.45376852507002,-7.153296184150349,74.52846484227288,32.85256085265394,0 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark63(42.459131184626216,-42.82206484809576,75.53575803281637,-72.13101959858051,0 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark63(42.464601228605744,-15.751219952931521,-6.5753344385563395,8.649131133863918,0 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark63(42.478043206417254,-6.671964277361013,16.14810891322354,-65.2978438617144,0 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark63(42.497521775735464,-37.65749209178551,-65.08960613994435,6.588215282770875,0 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark63(42.49796722883863,-10.500912468727194,70.57845897057837,-20.39737357043721,0 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark63(42.4994385297602,-24.190845934420608,-7.73536021599574,-64.20716060938416,0 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark63(42.51345528403908,-21.758068265511582,53.90960309572773,-14.017220527316866,0 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark63(42.513940771149095,-6.962608636009264,-30.127711520459656,-69.22836273157569,0 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark63(42.531685165639146,-29.820979716250278,0.1390778389579168,-40.69322899187018,0 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark63(42.61270584599447,-58.66073934268981,-78.8449172153247,2.931907188067555,0 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark63(42.644553451358405,-26.541866702899725,67.39240976093521,-79.14622609882383,0 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark63(42.67349885158296,-31.208485922772496,87.9065523935416,68.94718976349608,0 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark63(42.734138826392666,-36.1650913735261,-9.164452465371582,-66.00633450521937,0 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark63(42.742544176014405,-27.24578479282212,30.512683510735627,-35.95132134934562,0 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark63(42.759720088809416,-16.012647680203656,25.663423056820008,-24.94583374172366,0 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark63(42.827190762900216,-33.930781138926406,65.97716549817986,67.5926409801447,0 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark63(42.84161721025674,-34.9316181371201,-61.87641300129432,-69.76556342676265,0 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark63(42.85935353511135,-24.339783015278726,9.92693241828782,13.370380764482249,0 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark63(42.898672204599734,-39.23736401066593,97.28552936030653,-12.441653445449035,0 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark63(42.91480055227524,-8.30769606135253,46.63782759192628,23.66432674200827,0 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark63(43.027159724843614,-20.486355329400837,-49.79967250914179,-63.49409387906873,0 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark63(43.083760544057014,-4.823036493656005,53.889298688891785,-10.84948036696045,0 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark63(43.1211010818115,-32.459178071454645,-35.82655987020928,-13.577910266334143,0 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark63(43.18448043921293,-14.139654101701595,57.06908957355802,-83.22331678412016,0 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark63(43.24964795482043,-12.824658228960956,-3.067327999539998,38.18940425181276,0 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark63(43.30447278441446,-6.792822784274506,25.703042167571894,40.009549052929145,0 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark63(43.36832380283249,-39.81318467658488,-23.18548302720764,14.655643910440745,0 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark63(43.415683025000334,-19.065645278596307,-88.60406251090119,43.87723841954036,0 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark63(43.50500242489392,-10.358779119136742,36.832717848778884,-84.5531514290178,0 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark63(43.55541780526397,-12.009959649312421,-45.02879068418897,8.132554487306138,0 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark63(43.56934118807476,-33.18338560607582,-79.51225101963071,2.718590902370053,0 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark63(43.57687470227586,-22.689226732408585,32.5780969846038,59.72011971246894,0 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark63(43.639865432098446,-29.31065317064254,-49.63105044045062,-63.29043415388795,0 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark63(4.369326297662425,-3.1338546133844005,45.0018630136297,-40.88029001409732,0 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark63(43.72645416529207,-37.21856851412719,78.4591718947394,46.5497049397093,0 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark63(43.77899836442401,-42.90319764312427,62.71585889891293,-30.01070431520256,0 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark63(43.79237804404232,-23.665197603548734,-1.0787682442235962,-48.7312985307313,0 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark63(43.89995271080059,-34.41212246888399,-90.10433937361634,-73.66177514086756,0 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark63(43.938139423367176,-33.17254937240004,57.90629030691957,-95.03329972873695,0 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark63(43.96568427785033,-36.751852523327244,-75.89426409538706,45.87955354848111,0 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark63(44.013527629920475,-38.436877982841786,87.36896375402097,40.54760331906891,0 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark63(44.04585010268994,-41.484071566505534,-70.90145205150269,-84.33285107994695,0 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark63(44.046528214882585,-0.4554461818718494,35.95376379689412,-70.6543133871514,0 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark63(44.11677450435491,-36.54624817705956,-27.48555269380597,-9.949992678737544,0 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark63(44.11829272514939,-4.842311946731883,-21.439110103782838,-49.755302530435564,0 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark63(44.16447239216225,-28.138289896167223,-64.60709817261937,91.47020763593792,0 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark63(44.16466648518232,-7.4253970576250765,-48.26732531885902,-28.298093953468467,0 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark63(44.22850647410536,-17.372229207082228,11.565617245778185,-30.822677832961404,0 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark63(44.30831822285731,-16.74009382588646,77.77599010600582,94.09524459108235,0 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark63(44.31251269678805,-4.677990531882429,15.83035423923856,-27.213915446992715,0 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark63(44.313724327386666,-24.60151162418873,84.53272095568349,-41.00642390842215,0 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark63(44.33429720006211,-27.00056135062394,58.857497576239666,35.20713308099121,0 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark63(44.346776571102794,-40.99092145663133,-20.492116516057493,59.21322339950149,0 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark63(44.35164797692789,-1.451119717349087,15.054458300174446,-50.44981485329447,0 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark63(44.37308871218539,-37.37555627077893,-13.753156821173633,15.529401642434152,0 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark63(44.41986096457168,-5.949264626842734,9.27704108528809,69.90573418029717,0 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark63(44.45712045495574,-22.09772576894811,-63.84476136938628,-27.087491866885813,0 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark63(44.45852265065557,-35.57436636563045,-13.225806801147158,-3.8317424756254326,0 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark63(44.53485799324534,-24.459480002579866,-93.36952293700102,-72.99198103879564,0 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark63(44.60875403288091,-36.79502492151303,-29.67873476915321,5.123833290453163,0 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark63(44.62068779014675,-31.80001571619941,-4.058617510416525,32.19312364863714,0 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark63(44.628639726058225,-52.36073159928447,97.02559788452405,-11.30411790727652,0 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark63(44.67318233041698,-33.4700092145992,56.996773141645605,56.390753592824495,0 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark63(44.67537275448669,-25.468787660975664,27.168320386512562,-64.00622328119903,0 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark63(44.707888925745294,-4.899045326167538,1.9104590190395072,10.949364026081582,0 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark63(44.756402989282435,-33.70891936289635,-80.43927597144192,57.17193657700142,0 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark63(44.76906642281398,-23.144975507772173,-35.066635456157684,-16.666692740155156,0 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark63(44.83336771403356,-14.26578437337993,-3.9067429817598196,80.99902389069527,0 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark63(44.83742306097497,-15.966649217412865,-11.894510563274153,-53.92936679081366,0 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark63(44.843759291906196,-24.095328145061885,-56.67966758994827,53.81226845765741,0 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark63(44.86168254489053,-14.967301565035143,7.287595170666265,74.62109186407912,0 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark63(44.91452719998887,-24.63714943898225,-82.70934628767357,79.04432767368576,0 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark63(44.92894003225351,-8.799227435443086,-37.02762825711763,95.19124773529367,0 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark63(44.97130141503183,-28.429853629271832,-76.01047424305534,-55.818167648794144,0 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark63(44.971691733546976,-26.704914937083444,-71.96982935487577,-26.404139148254473,0 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark63(45.00827010787012,-24.444511381909862,38.18651052001218,96.11727281054743,0 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark63(45.02557940280249,-24.655987731366437,-61.50114624628047,-91.94868808872121,0 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark63(45.07819117704628,-0.6019554879811864,65.80185010826207,70.99076359399152,0 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark63(45.096754478032665,-41.80666015969201,84.19034822989127,-32.69747229522093,0 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark63(45.12220668548406,-15.364617166841427,-21.0097807769192,96.53487996519047,0 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark63(45.20827467524373,-7.466619776910591,10.390349605993805,33.46093137493162,0 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark63(45.244932292064505,-12.965829726888984,-41.801790404221094,-47.69656806505673,0 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark63(45.2893164915788,-40.206681148038136,54.37445180047612,84.03222223111655,0 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark63(45.38141885554404,-25.994303192903416,-11.349576574256702,-25.660931953129932,0 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark63(45.386138228764366,-25.833966931703742,-25.032819131818187,-96.68481214543768,0 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark63(45.39167920857872,-13.749047648979797,76.5154107268439,90.56612790498764,0 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark63(45.41906014751683,-16.30841004164867,-95.90793232506051,-74.88579761889447,0 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark63(45.43362164294237,-41.499305783474874,-36.7651208648017,5.606050074177745,0 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark63(45.476404483844306,-39.813240226729384,-13.902903007499773,-53.88188350350944,0 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark63(45.478587314987436,-36.51357292062982,81.93994014064356,95.8750696789462,0 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark63(45.483705970404884,-27.116095381440843,23.447948902825118,-0.5134881915910654,0 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark63(45.488020662964544,-26.497763207735474,-89.06233253902893,-71.38946439738088,0 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark63(45.4992689254602,-38.494882052588466,-99.88750426069804,-83.13031785885462,0 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark63(45.50630418131988,-10.308234907998767,91.42223124355712,40.9586923737408,0 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark63(45.511828152202526,-31.668207792935306,-0.7904084681117354,-27.46318196195554,0 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark63(45.56680667163678,-1.8471794984246088,93.62572280648291,36.5630633593627,0 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark63(45.61856855751404,-30.860955335568207,-47.188711002028036,79.70305373699483,0 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark63(45.69518581547271,-20.637625462685662,-16.316704446604405,-13.605304855781597,0 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark63(45.76799304285885,-32.06810422912231,-80.7035876156512,-63.775243629748026,0 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark63(45.77746876998799,-11.860594972608567,-70.4949579035903,22.621615929910476,0 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark63(45.85706015225105,-38.13416545736701,-92.07370826925583,35.49072029399841,0 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark63(45.85771023854005,-40.6443111617441,-91.61797650989058,87.99769332786406,0 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark63(45.92690485246936,-45.32054983898115,42.226787402715274,-89.61111046379565,0 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark63(45.98054727112438,-23.685646038945023,90.09055795899602,-95.04523224095188,0 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark63(45.992813201786475,-14.5245330904105,76.00445190017209,13.63677232106457,0 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark63(46.00983790138767,-32.05783607602713,14.240377077205423,-30.104252835137373,0 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark63(46.01234688878145,-25.219865346847897,60.92198366860998,28.10780908655488,0 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark63(46.063736429001125,-42.70541037352502,-61.88537270101428,94.00669271775178,0 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark63(46.13135419309492,-36.10399202266101,15.195913516037464,77.76284183162392,0 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark63(46.17679387929962,-37.8313138690969,-79.64263318471687,-10.169827689537797,0 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark63(46.22783852264786,-41.62173325027385,-97.70452771590729,66.44328563421598,0 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark63(46.24496432661857,-25.041490398143537,-2.3874409704798296,-14.720720450604887,0 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark63(46.2539743607411,-41.163361549098276,-60.63931927925894,49.34726164525327,0 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark63(46.278380874896754,-13.062457687329228,-11.841270612523289,67.0503570322274,0 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark63(46.29448732450982,-10.270080653304461,16.621496290292853,-35.85429218561788,0 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark63(4.6311051013074405,-3.34874244458409,-1.912219245215212,-12.78229037350971,0 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark63(46.345847978999785,-41.476495214632195,7.510960395819836,86.76277717142932,0 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark63(46.34958137175275,-3.9598319835352953,88.9095889289535,31.008461015195905,0 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark63(46.38271797169844,-9.046390437545867,0.5447947628441057,-33.18579604042765,0 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark63(46.43938764233283,-13.274672654912692,-73.83715301243544,-82.41611637550207,0 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark63(46.462867415784785,-31.367350576643616,98.94527753341245,-94.70780981341711,0 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark63(46.50316358951895,-29.01941231222061,63.535700266154976,-23.331527382139996,0 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark63(46.570753130897515,-31.51017968799033,83.13337427822037,-70.94687067250402,0 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark63(46.59086258669424,-12.026461568856035,39.81074901325556,-60.99803469405125,0 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark63(46.64029422185021,-21.561189041554712,-79.04609385929074,84.64830826141889,0 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark63(46.64525247342638,-46.32893520382735,-27.359607080734634,35.451906840218555,0 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark63(46.66869726057027,-13.549650337970178,87.37392648421658,64.76067672303344,0 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark63(46.68538194612714,-2.351190145859249,16.416903866940117,-80.78409031842205,0 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark63(46.70541050566638,-27.245865040091772,80.96525910038002,57.780385805175825,0 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark63(46.77899591565861,-31.798581436205623,55.286965685593316,-88.74532193803948,0 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark63(46.817181866565164,-82.24787502326797,-24.169540015081253,0.3583412149503147,0 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark63(46.81970979765248,-23.218083746554214,92.68404237754686,-54.9833811193762,0 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark63(46.822427857241564,-8.077257113590704,49.3365965283561,74.69821784560378,0 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark63(46.83496483942665,-8.08130546878894,26.412502951221356,-88.2530725272924,0 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark63(46.84072297893914,-26.284699635274862,74.15016850872493,28.792849937768437,0 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark63(46.881590163381844,-5.23952478280674,-25.711033424934996,-52.776901895218444,0 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark63(46.912522035761384,-22.98160629389345,28.11740271715567,-18.913028151398308,0 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark63(46.996894764345086,-16.19057296528763,40.34373735516775,-26.218431945658267,0 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark63(47.03370488108038,-31.44362872724369,5.098936855306761,-47.15190264169451,0 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark63(47.06780278536047,-47.080021635867354,-18.214510435164243,60.959104984931855,0 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark63(47.145374453114385,-15.87185641229847,77.7325313165903,-55.82150941418544,0 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark63(47.151978688331724,-24.701620793661874,58.95949236215969,56.7773322525143,0 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark63(47.16109451620997,-49.027014832664115,76.63124218227313,-18.856736188238358,0 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark63(47.30871470851679,-30.242293431429516,13.009237501430874,-11.744571326798166,0 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark63(47.3403000203115,-12.43347356305415,-0.6610584362945815,62.86346699173879,0 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark63(47.36152211331489,-18.340391769782286,7.528239713571594,-73.68879760969149,0 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark63(47.41216433536874,-12.345411109544841,-6.985215742919621,-25.222086781648983,0 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark63(47.49286821155886,-21.982032808796845,28.402466326229273,2.195552333221812,0 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark63(47.50970899707053,-22.593035862217832,32.389325522287805,6.246987526411843,0 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark63(47.51497994064226,-27.92080342536829,39.88355061875501,-74.62069766041301,0 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark63(47.53821237013574,-2.5978549775322506,94.19042819902904,-65.55539012786618,0 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark63(47.55850250816539,-9.52730520882416,97.11890372788017,-29.769362740171616,0 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark63(47.64295658410887,-46.741519528576106,32.87567142699149,51.87184514108526,0 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark63(47.64897687142508,-29.06972496027305,-68.34306200131837,94.47010217927175,0 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark63(47.694910221263285,-30.300824624471673,71.26814188033899,73.58574949033252,0 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark63(47.72719530513129,-30.945739210262047,22.998260659606018,-90.66970575409286,0 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark63(47.75883191230068,-0.2077406721110009,80.75837776079041,-33.792931506322674,0 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark63(47.75922916863047,-46.17111145129598,86.19343525059259,95.54260176928747,0 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark63(47.77067459685867,-20.879715865408727,-56.23293260831779,76.52597512012775,0 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark63(47.77207051692318,-41.206378733128005,-38.31731959466622,5.746689281236755,0 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark63(47.830104548734425,-2.698441045182932,-14.34682468504505,17.81629544101895,0 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark63(47.852236607383304,-18.811027334667216,75.70418285844508,78.8777904856789,0 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark63(47.86959046417357,-23.453369273156483,30.64382535841264,-57.90369825449404,0 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark63(47.88831148665065,-34.17971135433362,64.27910214086091,-77.27704119358435,0 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark63(47.89007972588894,-16.267425836088307,-66.41795634240975,-46.024367054719974,0 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark63(47.923156595435444,-2.082421531553493,22.675245032325208,61.55576484038434,0 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark63(47.98836409987666,-24.009993728272036,91.16834607296721,55.52400605890492,0 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark63(48.03098112594341,-38.660002317474465,-11.064083645364306,64.99669703252462,0 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark63(48.074200113814044,-42.88559604271818,37.50702624670262,-9.45431072740881,0 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark63(48.17292433359694,-42.82432899765545,46.35410616329034,-21.78450970155859,0 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark63(48.17424351921625,-27.310308559944588,91.03936689271984,59.56164515545993,0 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark63(48.213555153141016,-47.088208372975316,-8.057849392689747,75.72269954425812,0 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark63(48.28240792381723,-8.07626326270534,-33.115211264611276,-44.242778840687926,0 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark63(48.3155778087056,-10.917665556389593,-73.94994412829288,41.09166536540627,0 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark63(48.39200101288242,-45.22787167373037,48.975794772390685,-82.86824606344243,0 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark63(48.395914494554376,-10.761655034234792,4.673706949044586,94.29100456816641,0 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark63(48.3994955979602,-11.102393415251456,-66.77107900411664,-36.88776439182848,0 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark63(48.4133373639267,-8.630591239057821,-55.35910166618756,-90.93853327502148,0 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark63(48.46677374125284,-11.992129140190812,25.619048755009445,87.79214631841009,0 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark63(48.48083875706038,-38.95875871477945,-18.0985532713339,-75.31981706453905,0 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark63(48.49705141581205,-49.09812487549541,-66.72979465561922,74.24586058175589,0 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark63(48.604392961202905,-38.21068776728942,95.24230374879622,-81.2187544815671,0 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark63(48.63268665716248,-16.406125508981134,12.854514735948825,30.216284160294265,0 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark63(48.66464767563863,-7.691289324508688,9.69321187702812,-65.19950588264285,0 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark63(48.687912357534856,-45.54747774275665,1.8655616525198155,75.4539980416128,0 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark63(48.74727332831088,-6.345880284995985,34.759040263809766,-48.372653438878956,0 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark63(48.75488499319451,-35.24282077004901,62.93048026571449,-80.6471516682131,0 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark63(48.772603982135706,-45.76448592591329,-5.687493105734404,25.89015599763522,0 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark63(48.79740337122624,-26.45387766304323,71.37841233077398,-18.24906124243755,0 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark63(48.80428082313128,-23.95461798602929,-90.0321653026883,36.97983237400712,0 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark63(48.82673018125925,-34.207374860202194,62.327262686956374,74.08204485481647,0 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark63(48.8783573985944,-18.276078249338838,51.97938443298736,-75.85846649225418,0 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark63(48.926574601483566,-14.457333431023955,80.65175203389933,19.456476660429175,0 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark63(48.93081767387295,-19.538143652955725,-17.05972597283764,-10.488086916663079,0 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark63(48.9549327477128,-7.20674984208091,24.650216792416742,82.10564330027506,0 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark63(48.96862796597327,-36.14546204610429,5.081897959438834,-12.573999400026949,0 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark63(48.96973572916667,-35.3202748148658,-75.67937434042153,1.469282854016825,0 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark63(48.9724781036588,-6.609458800928053,-31.652814708586902,80.53659050823507,0 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark63(48.98261210308618,-46.97470273458335,84.31826738907208,-39.021404312572415,0 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark63(49.01117430781173,-5.048219444411117,-27.476484950053617,-25.46956330236887,0 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark63(49.13884613653042,-37.61342757313362,86.25770629440345,72.52802747808101,0 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark63(49.14450908929581,-34.90647775784235,-3.0897626497128385,-86.64206386582454,0 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark63(49.1819715194199,-32.09083303474871,62.9404301050113,34.40346988001494,0 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark63(49.19613734115924,-34.703821491860936,-35.913247843716235,-24.330925251642753,0 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark63(49.21518888913366,-22.970525545136724,-30.65857827499896,-8.45823117370297,0 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark63(49.23851186647025,-15.883056157925225,18.674922147878917,69.38300415001393,0 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark63(49.23985858117959,-38.40315019265388,-12.443468769643445,-82.23468939645772,0 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark63(49.26347787067522,-1.7420079216136344,97.62936486222972,56.61017053475115,0 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark63(49.30110315320849,-30.96530038482082,-18.153362698781365,91.04718827091031,0 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark63(49.309596681550715,-13.969010987449721,-71.87473772610433,-3.579886267797235,0 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark63(49.32494478488002,-26.58243417346158,37.34143153505258,-6.35250140936445,0 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark63(49.32638403524379,-32.663507986888774,19.753194193292998,-92.80722834134947,0 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark63(49.331941405780924,-17.17502698693795,-50.149830675789616,11.297514904639002,0 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark63(49.346658834395356,-30.24528731836635,83.44454016019068,4.554470991254874,0 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark63(49.40668059048099,-24.184643424951233,8.178403485210623,68.98397700783644,0 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark63(49.49420683378062,-23.589142153600434,-60.7769554572605,33.01923192871158,0 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark63(49.502683576402404,-28.299965931804934,-48.31733852239939,-52.33867905084089,0 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark63(49.51532807199911,-44.427497735692725,86.1838808722685,64.19009295531129,0 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark63(49.546963540435996,-27.912827303055153,29.64058867988379,-84.0703449463674,0 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark63(49.59992113976679,-19.451421552051954,-91.38112161923652,35.36491010042303,0 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark63(49.614478474143766,-2.1844701689284136,34.350003938819526,18.234843732054216,0 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark63(49.61744468670241,-7.0308895843747905,-26.20413871887024,-41.165899146752885,0 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark63(49.65571768893318,-21.997742074031862,-32.13354193225169,-75.23901316230393,0 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark63(49.68740809812488,-28.387505504241275,94.34873246926082,16.941520436905265,0 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark63(49.697911375471534,-22.46648420766246,-10.193876898760351,45.58360459717434,0 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark63(49.73519518290095,-13.898807578994195,50.407774632626655,-39.43502573669926,0 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark63(49.742925525151094,-21.624004116634097,4.6611904693057795,-97.58517117009882,0 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark63(49.7595260852226,-32.847258271200076,86.57770883320981,32.113095744910765,0 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark63(49.82148986371877,-25.537822749362917,-46.529138893050145,-7.310569445911796,0 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark63(49.861752309707384,-19.49653168593852,-61.42041725087002,-60.88026317362045,0 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark63(49.90078554398869,-44.27692885082726,82.9503823457043,-19.582274827456686,0 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark63(49.91988743471816,-44.809009876852876,-40.47793480162576,-35.52490733919727,0 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark63(50.02835241771234,-24.16709521820522,-6.636516296292854,-80.20652913104644,0 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark63(50.05285316347809,-10.513712779234567,-15.414554666408193,31.158562114333648,0 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark63(50.0687565584839,-43.54197539092435,95.66139989342278,-19.87847261226709,0 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark63(50.0851621978866,-3.204659493381911,61.35691272841072,83.05672079544536,0 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark63(50.1577046104438,-31.573834808509858,28.942137438406718,-19.95895825607252,0 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark63(50.208190707685105,-49.56496563465957,58.61358495393043,-34.07140622356593,0 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark63(50.28829772592641,-38.18877195336585,42.56931934083988,14.627043937401126,0 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark63(50.34117796993414,-2.3593866525617955,96.34599787008969,99.2240240860636,0 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark63(50.38417143683273,-0.6515612740158616,99.66835203146846,-18.064313380287274,0 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark63(50.415352825689496,-47.60751431852756,9.58678812166174,9.684113280058554,0 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark63(50.44367163822855,-49.214659179539154,-8.865587248769131,-32.741691042804376,0 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark63(50.455909981056635,-38.598151955740725,-10.725603717978302,0.8808829586196367,0 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark63(50.45736701557195,-4.762568393286031,-10.24146730313798,22.637683076595977,0 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark63(50.45951818848832,-26.896865844235492,-17.33450006035926,-50.76668007370873,0 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark63(50.47951460748652,-19.823851694688344,29.765690658745626,97.36024106607402,0 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark63(50.501791435936326,-38.65332331348754,-94.04975025082389,-55.154261242095345,0 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark63(50.54559121935489,-45.87544436043336,76.51033456370448,-54.635152935749346,0 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark63(50.597367909751085,-40.36606849735536,-18.336899559216718,94.53016348162319,0 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark63(50.63438166955453,-44.66543585460037,-67.6992998048895,-11.583187887733274,0 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark63(50.652836718446025,-14.668706043557194,49.55608326219746,60.90762425502152,0 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark63(50.69920024201278,-34.341060690517594,-52.224133536280526,88.09339351834527,0 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark63(50.700938280746016,-12.83020007433042,83.23943296054102,50.45369286820463,0 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark63(50.72409685727871,-44.74163662172097,-5.531700228413584,-26.059328807306443,0 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark63(50.74824784111246,-34.24411066344494,-82.24489424593759,-6.258751308840971,0 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark63(50.87953236882086,-1.8395495788019218,87.1615322241449,-92.0839423099605,0 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark63(50.900395419745905,-10.079415414345178,53.74740540743619,65.06568205461645,0 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark63(50.92122301885669,-41.41843536834698,81.59472330307415,-91.50952232295813,0 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark63(50.924408863788045,-21.339534384983864,-29.97270258510467,0.14354338464086425,0 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark63(50.92623188472777,-40.835453102804095,-55.16350937081413,43.426951276941,0 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark63(50.93189738575407,-29.298413687688978,36.992125678415476,-81.58598149956194,0 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark63(50.95827108120122,-22.872897002313536,-88.27307102064226,-75.44482317865358,0 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark63(50.99280628385142,-17.353580732367817,41.42066385816426,-24.734613604720025,0 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark63(50.99784597317429,-49.01756105391826,21.208852519185868,-81.47206492806191,0 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark63(51.01937903903604,-21.846480480347182,-88.59770034498703,80.22230369235862,0 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark63(51.048916755767294,-23.870945527431743,-90.72624921848158,-5.249961656363027,0 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark63(51.06276779046425,-42.81074302587196,85.14240135250986,54.72420311644606,0 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark63(51.06805910691713,-49.83469951500099,37.679647120519064,-58.9783759771463,0 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark63(51.10492799335148,-13.454516608612124,1.0087841841347682,-67.14194314320628,0 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark63(5.111097536514862,-2.356584894764424,23.990910098204353,-17.64373659476395,0 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark63(51.14989294323408,-50.98721785804814,-60.0747447726536,72.12801709475721,0 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark63(51.18127247105869,-31.47074977485562,60.357774863185085,58.049399453300595,0 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark63(51.258876970797814,-38.91093652319664,-18.14836366381229,-5.892280655615451,0 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark63(51.31281054413242,-18.346189086238283,83.6907929064945,-23.232501191977178,0 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark63(51.33126924518359,-4.35342169716904,85.32457124210512,37.09296712151328,0 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark63(51.3330478316777,-2.927426956021634,3.1608483377739276,63.404589882702595,0 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark63(51.363385079961176,-47.13261879415504,-81.8717880445774,31.55982673457646,0 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark63(51.39072197991615,-9.455947843749968,-66.59129683113662,65.29020915177819,0 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark63(51.40858577859106,-25.15569189243992,92.65788822346835,-95.86441959620784,0 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark63(51.41897526534288,-41.706801296888486,-1.8631233605103148,-75.79876010744317,0 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark63(51.42445950114737,-27.855741875137284,4.6896111517988714,-51.83641237428023,0 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark63(51.43588550231283,-29.531122730755428,75.75465997546198,-67.24416178361341,0 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark63(51.43972972108068,-32.3349789837072,-68.29847458884643,-67.66559380701801,0 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark63(51.44332330222554,-0.5168396678402161,91.68760338902777,90.20788559079747,0 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark63(51.47160813783165,-44.47793919677474,-69.1688063491079,-36.663863716643164,0 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark63(51.48216407034195,-48.23311137106276,29.237103073777888,86.02820296179482,0 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark63(51.52939981777459,-47.17691157483132,-28.425510828945818,-90.56693278741577,0 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark63(51.57422950542707,-28.107270480744802,-2.305751154084419,39.19407213463117,0 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark63(51.58125560997584,-38.39791835725639,-88.72706202544909,-72.79752644913908,0 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark63(51.595553906086764,-7.3567473830337065,40.6624801047694,59.72066509660053,0 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark63(51.60069038230816,-23.55598802231995,62.5545860114278,-91.61025996160285,0 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark63(51.60108817726871,-48.36664724291353,56.9854714372824,-73.5595006985929,0 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark63(51.69095946725787,-30.40608814573693,22.18893456704909,-75.93915900322006,0 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark63(51.712479129223624,-26.069561677380065,-23.74741470209203,-32.39371181293944,0 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark63(51.76849266705713,-27.547575601505443,-75.27650101009328,38.433909686851706,0 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark63(51.81630694708181,-17.374876738908625,58.67631137619972,-42.73182630216623,0 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark63(51.821273898031535,-44.70877536596652,-60.1492655282591,65.9227733084231,0 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark63(51.85423815065619,-29.184637020606118,54.12373602943819,66.68484812857801,0 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark63(51.99753796204331,-10.94354898878423,-48.21526298024794,11.440589378242521,0 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark63(52.10502609618385,-60.30269573093181,-86.33541787068431,2.1983018003760293,0 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark63(52.15679285893202,-20.737294224247222,15.335583477566956,-82.3274724632759,0 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark63(52.15710157608427,-33.382765675699105,-35.17279343346118,30.741515182547886,0 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark63(52.17220762461727,-47.90451371391442,13.573412295562676,21.552424145584496,0 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark63(52.20610160062475,-38.583655794546814,-97.60228185746085,16.302439272100884,0 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark63(52.23626399035467,-37.73744876961012,96.69764998263545,-93.49128954171992,0 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark63(52.27112803180813,-42.960941726853164,4.05663849913509,65.01166205267046,0 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark63(52.297071587028995,-38.66939719155054,-91.54273098001346,46.24796606339595,0 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark63(52.403370750302514,-32.86213733519246,19.411285481564306,23.193198363234302,0 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark63(52.50982819939759,-50.434867758101376,-96.61940096642896,67.722081788901,0 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark63(52.51413299165176,-13.468730665004315,98.72215333009146,17.87897459315711,0 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark63(52.55406469394282,-0.5861355215555477,71.28630906117041,50.43603794323593,0 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark63(52.57386712751995,-48.26944114189124,87.16415379891117,97.05619713875691,0 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark63(52.610653527373955,-24.469537707488612,40.94798630379552,79.29622724118747,0 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark63(52.64535713036241,-14.813641824775445,-10.41883933432743,-14.122878950604132,0 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark63(52.64984718528481,-42.62291412824477,80.24220719730118,86.01833219921781,0 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark63(52.6610981530786,-9.125840803896196,-35.42060858317535,-88.56888130053294,0 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark63(52.67878732415264,-2.4745008451553048,3.5792474003038848,69.6445013819806,0 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark63(52.74606779558661,-29.349693389504267,-54.53871177409542,-68.23979668869553,0 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark63(52.78974389822545,-19.856470120690233,20.94315149398649,-53.50537836539884,0 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark63(52.823588097542654,-39.89282910677887,-59.10439910158593,26.579925361493096,0 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark63(52.88665222815206,-23.6105971696188,17.438442493610836,79.42711118813511,0 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark63(52.892699879329285,-24.88341472755738,24.43128074284313,-52.87048766897164,0 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark63(52.92339249655811,-0.11568325208179431,24.78398229689273,-68.30961155672327,0 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark63(53.014803948831656,-40.64262472864326,65.52701602684408,-86.33163049270769,0 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark63(53.043030401634894,-23.54046532738481,-43.0623225003844,6.650093386891015,0 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark63(53.068690536556375,-35.24876244382527,50.081346120253414,63.82823594465327,0 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark63(53.08151374358502,-6.940555665664917,85.70499857567893,16.399806812713337,0 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark63(53.136519170067146,-21.59933376347331,93.33738195922916,42.54497057508323,0 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark63(53.16367062123405,-8.00895096483056,-26.617200297442437,1.933615304036934,0 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark63(53.16581872597192,-28.266034052655115,91.00777605974918,21.173745747451477,0 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark63(53.214280736012256,-1.0312218987871944,3.8031417255172784,25.08563415235288,0 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark63(53.229669173121295,-7.737008090557865,-9.522787156120344,-8.03543653468219,0 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark63(53.23458700770561,-23.525947147845017,30.992990403869385,-67.53563179907275,0 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark63(53.25322560867855,-4.660377729245923,87.86346165734025,-19.622251788833324,0 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark63(53.28150943279354,-34.21757908169427,-82.53708467554834,-93.2409002534822,0 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark63(53.33958154969599,-48.85547351794561,-55.89663664367623,69.47953943426063,0 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark63(53.356614430804626,-23.898323926879954,17.241278650802656,-0.8156618646343503,0 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark63(53.362946465294925,-25.460720965870152,-70.84187575319778,-96.47856811804607,0 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark63(53.37751896338443,-37.20363206440691,17.55926555308369,-49.15707940828473,0 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark63(53.37787192958672,-42.15783146227727,94.32835463721514,83.53414170826667,0 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark63(53.41710427586267,-28.982243437829226,-70.80844853683526,-20.737962218999712,0 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark63(53.45868483426125,-42.260574829452715,-14.483185064760846,41.06836513521017,0 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark63(53.590719431724665,-7.6565645917724225,55.33725601474882,-9.339503927692803,0 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark63(53.5967390273878,-19.483124470817074,87.34077001942072,-54.926092800610895,0 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark63(53.64787648350068,-46.0246582983981,-29.171833544394588,-82.16108393124182,0 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark63(53.66194893673594,-6.83747804218055,96.30609685107845,24.45144391468699,0 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark63(53.67845421650199,-35.3680740713077,-24.868369563010503,-67.11383982316042,0 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark63(53.69509641701114,-20.585195274156447,31.63712150979191,15.751325559405288,0 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark63(53.73227470708488,-42.51636023476559,-82.29052746310444,-35.20882840995938,0 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark63(53.74635793174855,-49.27296821086671,-43.855907260504345,-82.51513151466733,0 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark63(53.774548794476175,-45.47875917566613,-39.161947208623424,-81.5608893339468,0 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark63(53.79530013093722,-13.961712280832273,-91.71462984613335,-26.581129680658222,0 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark63(53.80087223305193,-58.49449668336013,-36.331669084142895,5.611107216947971,0 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark63(53.813224159635126,-21.890525383755133,-63.91965411581999,3.4237397828082123,0 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark63(53.89820774584447,-51.16052353463794,51.333661637939315,-57.00858397318132,0 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark63(53.93660432648906,-22.939618197455985,-14.57492556768294,91.30331874546931,0 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark63(53.941777041992,-25.23973417071217,87.08289496746804,55.210940606635745,0 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark63(53.96585766996452,-51.15125642928611,28.606778193662564,-61.79228247770112,0 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark63(53.99276153638067,-24.05596946266057,-87.92675738412623,-25.25560800000987,0 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark63(54.01618112235059,-50.47762241648213,-36.145579679897686,-12.707902937817835,0 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark63(54.02677140243921,-47.87271973279603,86.73706262795173,58.099737993310384,0 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark63(54.05751993032354,-19.082813179426623,-99.64829692451818,-98.68249108228946,0 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark63(54.11303730674183,-43.80041102629395,-74.49206359440407,-43.02548949536944,0 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark63(54.16092644920906,-31.92210625985527,-19.847153872274575,-24.79414971612144,0 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark63(54.18986641846121,-46.178409698355736,81.26633833838224,-60.2552905263998,0 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark63(54.21127938266096,-6.893583707498735,-38.37642826202823,-60.63977050765929,0 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark63(54.24082160024639,-29.948862396467632,81.55208224725479,-23.200231216484596,0 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark63(54.247399041450365,-30.77759865293031,-99.60202340570767,60.909501899909344,0 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark63(54.27680960905843,-36.56100910990112,14.25118042996884,71.25224355661331,0 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark63(54.28208278709238,-6.751687230119387,-43.48213111914192,28.77444534403648,0 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark63(54.29439785677951,-30.847217829282414,82.25553834169978,-99.58241173003199,0 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark63(54.30965489191789,-31.158301590723056,-10.242030015692976,26.211100573307732,0 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark63(54.34922294001444,-21.0585252809816,-29.05109418078264,-61.47447140589082,0 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark63(54.38735728662601,-18.985692452502008,-22.478746286321922,-11.052208066136714,0 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark63(54.388382229557976,-33.892142674889556,-27.840452605070197,-96.56353572005526,0 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark63(54.400433528878324,-33.36741598027811,94.79535382553769,94.1960068713685,0 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark63(54.48574729955615,-4.532931007335719,49.48859065344038,-16.9662157018806,0 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark63(54.4990781508219,-29.59917039238094,98.70138037947359,69.49937853974038,0 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark63(54.547744142050135,-25.73309975139398,-77.1545855071367,15.895959783914961,0 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark63(54.56554030480797,-20.326444068663534,-25.98602397467957,60.670180543551766,0 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark63(54.56913242121263,-33.21697873753004,-81.32842583216184,-57.30051849650506,0 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark63(54.5719291527989,-13.594112908303273,31.918519694255565,-1.317377129041759,0 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark63(54.593068146571255,-67.68548547999625,-99.28770097298569,0.5400717032576665,0 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark63(54.599262364899516,-48.949682066532944,-78.99050809863522,-57.20416089058349,0 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark63(54.60920466127885,-12.511016100096882,24.946423487560395,-9.822963232950869,0 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark63(54.63973268472165,-9.291580430263522,29.44134806632411,-30.435340007114746,0 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark63(54.64745324949183,-28.692479857440276,-98.61481575050746,7.27446888573327,0 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark63(54.66199381705249,-21.098801572586055,98.52161608855818,78.42519461816099,0 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark63(54.664511772203866,-27.48830625837384,72.63258964166158,-6.889432122686273,0 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark63(54.759310086200514,-43.194151384317635,27.10342699754895,-74.46909451409061,0 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark63(54.77322897889454,-36.41358981819851,-11.219532771361045,6.468263520599066,0 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark63(54.80582350062275,-31.778476585488917,88.29896760619641,-95.75721570109098,0 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark63(54.80850909059578,-39.13099551209862,94.83150393008245,39.0154757898469,0 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark63(54.832409098201026,-47.777197124638946,58.3391401097353,-10.860266224146017,0 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark63(54.85557292818035,-56.26781443623328,29.964864583734766,-11.911515552749648,0 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark63(54.86377010109109,-4.864050874844978,88.64363152125415,-50.83674804013549,0 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark63(54.87428234669241,-49.44138929025863,-61.87244894166237,95.75785112336189,0 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark63(54.87546633953605,-39.63200298017973,7.6034967960250555,-88.86646584819505,0 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark63(54.96904194751778,-1.0842425037001817,48.932397994843654,-60.98760517527877,0 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark63(54.97743942629242,-5.337148917451515,80.92377191065415,-16.7518479059177,0 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark63(54.99944006766083,-34.15893324942401,-90.91262973992032,92.79327054832228,0 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark63(55.01299607741018,-55.350570631776044,-28.138481050082916,37.527801361760226,0 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark63(55.13761355069559,-34.9041702164334,3.1197864155736283,38.109196763028194,0 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark63(55.145713928280884,-29.60755046027657,74.80862702306166,-42.17354708710705,0 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark63(55.20940921491601,-9.550004528423116,-40.77494208342587,-79.66721134549913,0 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark63(55.21437136342831,-46.125952689713934,8.813600321091087,-78.83464201606441,0 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark63(55.220717227628455,-19.135541268947833,-49.40110933913768,-76.65841248238092,0 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark63(55.250740343744894,-17.603853211578866,-77.08937072926408,-5.665822545514686,0 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark63(55.28579458536504,-51.53374866156612,95.90632406025901,-53.86085039971553,0 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark63(55.29097672048508,-53.70230608550288,-80.90680403351342,74.96973322493784,0 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark63(55.385367119905396,-11.229872551757651,40.58329248787325,97.69774939053337,0 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark63(55.39595829497355,-18.593497895582004,-32.99869234705196,-35.24056609999762,0 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark63(55.42955653513428,-12.662513507244213,-55.02995063870715,-36.012327205725384,0 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark63(55.445632713279906,-16.337235265581,61.710648261197974,-83.79763914588301,0 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark63(55.460150730214764,-25.33792963614006,88.46311951901109,-65.60699652408402,0 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark63(55.4853824116727,-28.805997766436903,-86.95201531106427,-93.40279117044088,0 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark63(55.55236967909158,-48.13380288445364,5.469454899507653,55.10383537905784,0 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark63(55.57492986942876,-11.245722359926845,-67.61874909301639,75.26278636253062,0 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark63(55.637155706806794,-44.986863470094775,45.14780498501659,-61.075002713283745,0 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark63(55.647681769871355,-32.46137505502165,32.49796041491945,4.23158212841895,0 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark63(55.67814930344164,-2.0819013802152426,84.89482875003142,19.744094337716533,0 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark63(55.69925372909651,-22.948397089170584,33.3828324261205,52.92548332098525,0 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark63(55.74042935049758,-9.211017411281404,-47.88430223891007,-17.830095238833124,0 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark63(55.843379722466665,-25.784405509198265,97.55539974213946,82.54132014349909,0 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark63(55.94396180594285,-46.99460627364267,-4.053445386667036,40.38769489919065,0 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark63(55.949159809803774,-45.467805560827614,-52.46447492238775,59.32820852757632,0 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark63(55.95319495825032,-50.85608458321686,33.511637078970466,-49.28956069522508,0 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark63(55.974001317188936,-2.1995431703360993,84.61167469625539,59.43580835648939,0 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark63(55.97670900348635,-12.66917345296541,-75.73946270444767,75.7867434649275,0 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark63(55.98333632991759,-25.727888178804108,-24.230188093408486,71.54742249538796,0 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark63(56.00134003164402,-18.855474927994337,42.453306418234035,99.04691752404605,0 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark63(56.006656839022526,-30.150534360019037,31.249105101218618,-9.469431891999136,0 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark63(56.0356773761886,-46.33127769612049,-99.92002392390586,26.970180794116033,0 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark63(56.0368947500624,-28.29453103876706,-98.74657352442695,56.32181861657563,0 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark63(56.0378003734244,-11.133567024698408,-49.66189483882773,10.164289749589472,0 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark63(56.04888928405114,-48.664650732911866,16.097754756867715,-93.0459006505574,0 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark63(56.074721456574764,-44.34037276413774,-42.2154878314158,-20.673712114699455,0 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark63(56.090618065898894,-10.295268438552128,68.60793261645765,-13.966129370779015,0 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark63(56.141040966193344,-48.88457347680757,-27.527748065052208,-21.956618311507214,0 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark63(56.15064454448793,-37.57384182649732,-82.07840383785658,32.79992569569313,0 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark63(56.15525963130898,-41.28227857686919,11.089544071095574,-44.61671616399734,0 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark63(56.202702970051064,-20.2795935669742,49.331180091340656,-14.956355121328713,0 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark63(56.22330617290493,-27.88091604888794,65.6504571143308,-81.20752223655852,0 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark63(56.24642569431663,-10.896803227070635,15.692820192617745,-16.587815294963136,0 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark63(56.28098601930998,-24.195427065483187,-0.08213761563249022,7.2393310641937205,0 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark63(56.294089809368955,-19.688727420809343,72.79536534827128,41.523756928953134,0 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark63(56.33895537701554,-26.421066229879855,-95.04067436077858,71.26894084821853,0 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark63(56.35051636771905,-31.43962834337914,-76.5529347958115,6.5710621204119235,0 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark63(56.36965842215386,-12.00883663431631,-62.332478335491516,-48.30725324479204,0 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark63(56.43693087200603,-47.995617874182585,79.22035877310117,-77.92760735445101,0 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark63(56.442386168934235,-44.393517612917435,43.7288684995475,-9.6112843598451,0 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark63(56.45403782204235,-34.7011079239316,-33.44312795003772,37.46250564384039,0 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark63(56.455384987056874,-57.28042043507777,61.893909628756575,-35.27689029286924,0 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark63(56.48048837099563,-57.273683061485926,-87.5793109593681,22.862581210932348,0 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark63(56.60562438762918,-9.34882460800796,31.375133770229837,53.466060928715535,0 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark63(56.63295601005524,-43.52832187351989,21.339423172522814,-11.894633792702763,0 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark63(56.66899915826991,-45.18608463593758,-77.14618397546613,-84.1590923346837,0 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark63(56.69739866172955,-35.94337190261807,27.65664034090139,12.991691713418248,0 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark63(56.70702551366651,-22.250956451606,2.423427319566258,8.512539777993823,0 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark63(56.728942073501,-19.703909508688895,63.61844408731861,-18.820298135865897,0 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark63(56.81310810944612,-51.28138782534688,18.97037357642526,86.20253097108863,0 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark63(56.86732136272278,-23.2844624767679,47.71914664776841,16.834935468169988,0 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark63(56.890614066034175,-58.17461053101807,-86.80135094107784,31.28321648549496,0 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark63(56.9226348265378,-11.860598835997976,-80.20680841855841,-81.71424516316202,0 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark63(56.92544520443931,-47.77312920986701,21.05221138782447,-97.00903229309365,0 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark63(56.94648502923374,-49.02619165367139,-85.64614736105429,-74.26397341455247,0 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark63(57.00148902498262,-18.34701382420745,53.947806195158705,68.25251748102977,0 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark63(57.0275537892129,-50.69369543475799,19.47556695891801,12.589146810984658,0 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark63(57.04873451793975,-14.489120255950098,-26.489016675165118,84.64615234307058,0 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark63(57.05051074723153,-20.483420942038833,92.61676517028994,55.42008332594244,0 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark63(57.10252460438926,-36.79174593402392,-0.7006895433720501,47.6363034720315,0 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark63(57.22016471836778,-33.72367655377269,50.12284485772881,-97.37737290150248,0 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark63(57.23138064558927,-30.46194454900632,-10.306233558402454,27.2901843612902,0 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark63(57.248921371538984,-14.940408070916007,-29.874415505483526,38.863241527050235,0 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark63(57.282419818651675,-11.28935298080438,-64.64627032373573,-16.418196536067526,0 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark63(57.29013639297861,-14.055319375612171,-53.899443552476065,70.58799171075944,0 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark63(57.29570980387291,-58.59013914743969,-88.75826157373167,22.89728232740282,0 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark63(57.29724618595563,-13.435147052135932,-14.214962500013328,21.079232338667794,0 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark63(57.33012508905705,-16.628087515324893,-21.99179086703404,-8.84902254188657,0 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark63(57.33878284018783,-54.20346284790176,-17.19584144498573,-25.849929321137367,0 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark63(57.34479854258487,-40.015634746129834,-20.07239270904087,-50.211196405524646,0 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark63(5.736532067455613,-5.731680637164445,25.246288665537264,-20.419096404575626,0 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark63(57.40377264148927,-39.98591015660142,99.54575828557591,7.071599100230301,0 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark63(57.41465665388654,-42.76428360297664,-41.25736437219132,52.28226876176885,0 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark63(57.42566913971061,-31.045096842025586,2.380047083282605,81.75368067878065,0 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark63(57.44362514189572,-6.160755386659119,-18.909309832234115,-8.203099140611613,0 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark63(57.52607944041341,-20.532298601714302,78.80274008520789,-9.427765766625981,0 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark63(57.528200798523926,-43.21187422219972,-18.002267782655878,-71.4920108554063,0 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark63(57.578116575061955,-34.149204339331746,85.69743212368653,-91.85176458539621,0 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark63(57.58241435536465,-16.029004271760442,32.64957030222885,7.683624756386337,0 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark63(57.59998962337028,-8.63469176886835,24.182129945173884,2.951992652399781,0 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark63(57.611480826140536,-15.148170509995907,-68.09523575988663,81.71685051236699,0 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark63(57.62378962972289,-10.013049129610835,96.71062387625724,65.96699213354691,0 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark63(57.67271976936112,-38.49998054927901,-6.057403904750046,-15.956918992301851,0 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark63(57.6999377360313,-49.349814826894736,24.854224228333592,13.002149541320975,0 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark63(57.73424545186137,-18.28536394359091,19.735187579605025,71.30451628834834,0 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark63(57.74476560781386,-25.906060389012737,-26.920318673044562,65.47551662577911,0 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark63(57.7964361136398,-55.68470507665062,29.098134333036597,16.273620927697976,0 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark63(57.84286199109877,-40.7097236721933,93.2560378880624,-64.60170521806032,0 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark63(57.84364550298483,-1.0834847689707345,41.59637352375688,-80.05292653653538,0 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark63(57.86157747881816,-46.04650977799727,60.957992825866285,85.882681716305,0 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark63(57.895994568199484,-23.348605065919045,-95.51963208821373,67.26225865532024,0 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark63(57.922832787602715,-28.593248808545653,7.1703108847012516,4.354930793030178,0 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark63(57.94766789207392,-14.889652901398236,77.48287638653119,40.29065838048993,0 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark63(57.97267234680626,-39.67870498180561,93.73263486893626,27.81591879205429,0 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark63(58.023235872675116,-55.7538688671893,-55.11712225807231,44.7479337830417,0 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark63(58.1069713451856,-33.69462095689843,17.23903905741497,-91.94574355648766,0 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark63(58.22757402627653,-49.938896814407954,-5.705729841482025,35.62535429675117,0 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark63(58.2305743112515,-11.598140698366151,44.15442366569192,-38.63652538294813,0 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark63(58.253686506994285,-53.01181668956332,-48.29790935539611,19.115127491154354,0 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark63(58.2611775674238,-19.232604308878365,10.527217227068604,69.73714378646375,0 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark63(58.27182669510947,-18.728035379691093,-2.616928632867726,-23.363437401215563,0 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark63(58.28244180400816,-38.34786933406127,-32.62966733718132,-11.993984551187452,0 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark63(58.285833992259825,-26.07657133277077,-53.873817488891994,-75.63390025753176,0 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark63(58.29324938791527,-44.088823351706786,-71.6858277180801,95.15215760854693,0 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark63(58.2984093393309,-37.99268194162097,98.25668613917179,33.887214826171515,0 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark63(58.326376892838084,-59.19992014064137,-17.01242771546825,11.732446843526745,0 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark63(58.33799379361878,-40.45290963406276,-54.14276615065121,19.42090900290981,0 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark63(58.37741212070489,-31.637037162524393,-80.47440175181919,-14.361258239394374,0 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark63(58.39925676655017,-46.955472930984186,10.97309637163994,84.13466515533554,0 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark63(58.412495867427594,-42.60436460394346,58.65861333138142,11.810900836832985,0 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark63(58.41427017524728,-37.13229998653391,10.664978915441736,63.70182461117207,0 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark63(58.43047270522024,-59.23194112633634,-36.43815537420194,6.426394749605308,0 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark63(58.51360098105977,-52.884715036230844,-49.94663112040438,67.99347086591504,0 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark63(58.529777568003766,-11.940810100373113,93.69106986771936,-15.304562094560595,0 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark63(58.571642082034145,-12.803936311164605,82.72893088514871,98.30085888686469,0 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark63(58.63804832517562,-10.318958085371804,58.11976721094874,53.937742067713714,0 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark63(58.65591101296829,-43.826939025878595,34.796841271203704,-6.1473762737192885,0 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark63(58.67655231040817,-21.812130467180395,-89.01759985463647,71.2965560888725,0 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark63(58.7047942695026,-19.639756610993757,3.034526870976009,19.458651287846052,0 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark63(58.724771318674755,-28.39530157523606,-76.18226208291642,-58.67232605654995,0 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark63(58.73724292919127,-40.12520321391915,-73.54338016578446,-27.73963621103654,0 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark63(58.755563737329254,-18.642646979047427,-44.37518667507901,-79.37856621922306,0 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark63(58.78018071744086,-41.12872564658667,-81.1580198376143,47.1890145452449,0 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark63(58.83854641645999,-29.56347871407732,-50.39013572722959,91.13557881045494,0 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark63(58.8523251254997,-57.17145258700449,25.168511232989715,-37.4147797502375,0 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark63(58.86965827553021,-21.851571479027584,37.61911326984642,-24.651888774058335,0 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark63(58.91505245050746,-55.81848110781276,-66.6948584454731,34.09644486046176,0 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark63(58.91583312764678,-29.152353174027795,-94.19418310473813,-7.766137472849039,0 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark63(58.91935757809128,-21.710947585453823,-32.95154487658738,11.178078432591803,0 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark63(58.94193982505135,-33.13836294889667,-6.6880055494428206,34.888983687051564,0 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark63(58.94581429392079,-49.1545282413528,61.99278305852525,-36.78226375610494,0 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark63(58.95273231514878,-50.60231757945268,-90.68682547025699,89.97587380341835,0 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark63(58.976712991931265,-46.06198293327823,41.40913629674927,88.06703910252821,0 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark63(59.013037848194756,-51.058331631681206,24.29789779636684,-1.8581475009059147,0 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark63(59.09429909580791,-2.6137871533097154,91.54926426476865,-7.838398558829425,0 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark63(59.10927182562432,-4.054784843679698,51.74609717400534,-26.5318207237615,0 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark63(59.12469880009763,-21.720842102201004,-82.87131633452908,-49.718070236224875,0 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark63(59.14474794097055,-3.3195583163810056,42.20524117885995,-33.20928046708731,0 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark63(59.203659019781696,-1.8421881431874567,84.00470841951358,33.23237085323066,0 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark63(59.21099108983984,-26.78983857769765,-54.44254477479682,-15.286788305394623,0 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark63(59.254595194265335,-51.38519440476992,-21.666713142506723,26.242174290168535,0 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark63(59.26245897428126,-23.447839191473435,35.28523280409405,98.51227502214311,0 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark63(59.270035858467224,-33.33920663201559,23.28010267750888,70.97526915638738,0 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark63(59.34887891289506,-9.081959344473532,45.607405002161585,-58.44281052939366,0 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark63(59.352631412598924,-38.58007707250908,-81.60139795891214,16.31985544377305,0 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark63(59.45152377710366,-50.009772760384564,96.86035754265342,62.459307179213454,0 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark63(59.5243070134195,-37.771177913729126,73.20356615024761,16.005295945601944,0 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark63(59.52837408798089,-40.29488182955829,-45.18773073373319,33.50055114454747,0 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark63(59.53641337089985,-29.686618207319796,-33.84772524251933,-82.626335882493,0 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark63(59.552795757326095,-19.016923472271444,-29.054466400691624,-30.206860413299054,0 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark63(59.56980892379977,-48.09268833950699,-98.68155948333074,7.0223605168070975,0 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark63(59.691481057852855,-33.197886730195634,-95.16961305949998,-16.623500825213483,0 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark63(59.806088165377986,-20.530701428338702,-41.24525518005277,1.97336940135105,0 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark63(59.829209535451355,-27.94646538812637,14.505563884104646,-49.62139618579759,0 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark63(59.84198307518378,-49.52915114492493,36.754384826391714,76.71171783417466,0 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark63(59.848337977572214,-5.028366267336182,70.96681399050743,52.2422164877178,0 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark63(59.87055273672627,-23.419169836067,-70.99904879404349,57.351048665146834,0 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark63(59.872548828424755,-22.621483402982065,-22.94317233845217,87.69338548932652,0 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark63(60.021913465280136,-28.59034453379563,-69.98180646081403,5.0400019050026685,0 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark63(60.0496440648665,-50.36275364547607,-13.068516515636432,11.510715581323922,0 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark63(60.082323950664744,-55.80459266405005,-97.96633398072785,-82.38035261217019,0 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark63(60.084395695715926,-5.50584172061852,30.93095507134359,-98.26796597929956,0 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark63(60.27233165413651,-6.230096620470249,11.559308069283404,99.55680325671275,0 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark63(60.28038103034001,-42.119651428657036,-76.50906803211146,-49.70532385461854,0 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark63(60.28378111902464,-42.872369932966194,0.6606496816595921,96.11611398261232,0 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark63(60.305786075932104,-3.8776175052213517,5.614297599452328,-71.22035296417553,0 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark63(60.30834803620587,-53.24482708347655,-20.760581260463454,-78.84108811838044,0 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark63(60.34110645617102,-52.25356598323481,-74.79725874640211,-26.8264943064229,0 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark63(60.348505487978684,-22.097361463424065,-93.88082538541158,99.04960285328804,0 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark63(60.371192898909584,-55.97564986797323,7.395955434881117,-14.468486704955481,0 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark63(60.45826128144276,-23.177480789375807,15.943034023623454,40.244149304723294,0 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark63(60.4588320148394,-30.88146144441164,77.80236477982572,-2.8032443019573066,0 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark63(60.47063354861589,-16.66337542002232,-8.883833626670253,-28.157567908212158,0 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark63(60.50143500792453,-41.69409116548493,-0.8736508387607245,10.875158895348676,0 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark63(60.50620724735674,-1.7387253538190066,50.21405552417809,-5.203657696023512,0 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark63(60.51052476719542,-23.154449697489696,30.767370455885754,-10.150672914755617,0 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark63(60.52383670275384,-58.34513899031846,46.00696730595476,-76.49903777815435,0 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark63(60.586544540910495,-6.242563120357119,-1.893340673805838,-45.47487443679559,0 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark63(60.62348593998101,-17.699767461611728,46.48501437866304,-74.91321538408755,0 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark63(60.657047830509924,-41.751322286044214,43.658514021558574,-51.392013213491936,0 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark63(60.66285430158882,-1.7045764959829626,51.39168632324197,15.29787242552139,0 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark63(60.71862956357174,-6.984039583636871,84.8800523703976,98.77225668060652,0 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark63(60.755012600878956,-39.682878657116575,-95.93598184526353,-83.86305231421794,0 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark63(60.77929577921125,-34.535485879519314,-73.06526252948136,67.01199475616511,0 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark63(60.794522889939685,-30.18398536564291,-37.59757699497921,6.061586930677436,0 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark63(60.803001056647275,-32.63791133501522,71.06348586847406,88.01398028632931,0 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark63(60.81208931730427,-4.561511533289192,19.43740008806232,-30.504464893169853,0 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark63(60.81778036327782,-34.73513781906374,-15.877721514768695,-65.19830309790177,0 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark63(60.85043401957461,-60.090265480770896,38.432836970665335,-17.169207145029034,0 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark63(60.85365573955369,-55.093479749043325,93.95745404231849,-86.73148669321526,0 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark63(60.89894438514051,-30.147661978860214,0.7984528551398,78.3971264870076,0 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark63(60.924429717125406,-29.743745067105024,13.38585385503417,96.50296358316947,0 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark63(60.93023191146179,-52.99021570615543,25.508689154408074,-95.64340307661652,0 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark63(60.93082302744364,-17.944043588591143,-3.1979866776415946,72.96209611443828,0 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark63(60.95518057185575,-51.411272599329514,21.042065989295835,83.0852324721132,0 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark63(60.96266941199502,-35.96571687593959,-10.13940121894899,65.9125971217363,0 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark63(60.97502977095883,-23.652491452656093,98.3925634823309,-93.82953455579823,0 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark63(60.98608480490543,-12.642661588117704,-76.33660644693315,-99.09378967085804,0 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark63(60.99416868317661,-7.028742518715518,-49.56164781372081,-7.448538798227375,0 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark63(61.00272657352906,-36.76117550651357,-80.3861008319484,-93.32203022648909,0 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark63(61.08181601971239,-48.84743699443681,-61.691637964510804,92.45608707755443,0 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark63(61.08928972927225,-45.16207455395942,48.962936612910255,-21.78905642961304,0 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark63(61.13780122082656,-19.49057058537184,87.91080712281297,-80.05492839174283,0 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark63(61.225624801798375,-36.622671756184474,-69.12531178500302,26.026686424811246,0 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark63(61.228653280570825,-14.799298365483466,31.154471902722207,-99.75553936945396,0 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark63(61.286618510762764,-57.473883132904625,-49.765978405726145,70.66267967829617,0 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark63(61.29192441636849,-51.21827890545183,22.603681360676518,66.22457151730606,0 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark63(61.31415137757094,-43.49384961105554,62.41931413039171,-15.254828311888176,0 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark63(61.33444518958066,-24.638182926213176,58.65601233708517,5.017211497135008,0 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark63(61.33618623485313,-23.245320831647547,98.0252243412022,-76.0507545352404,0 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark63(61.373872148292975,-40.40304617852939,43.65001526545234,-61.14705256885231,0 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark63(61.3866744378133,-0.028946506653511506,59.71488513720314,51.05204358522096,0 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark63(61.38990281731077,-44.57802351999754,-95.57165195423292,-58.04068423887496,0 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark63(61.41214444364252,-52.91711608871821,25.20241164044272,-66.43230855812286,0 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark63(61.425481128071795,-15.750289150760935,0.018048643603634673,-26.40018692291291,0 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark63(61.45342512069627,-60.55373656765659,32.96460083814023,92.9600973112262,0 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark63(61.459865041585516,-36.42200405384794,43.694485608739654,74.53896930025809,0 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark63(61.47308252842919,-27.34807481521611,-73.62689348325893,-45.10309888614093,0 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark63(61.51187815525557,-38.28969323098364,-67.76825369123394,-77.92391784000247,0 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark63(61.582990856529904,-61.4262150059649,3.8717835430806673,25.541758657096608,0 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark63(61.58433731786272,-32.30324561631113,59.45300808118154,-28.094336273812104,0 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark63(61.598570473749135,-60.68626492231033,14.126701347588977,-94.20506185961656,0 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark63(61.61201059353402,-41.233832356863175,87.29742192104254,80.98910844358332,0 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark63(61.67217905071678,-46.454099286942906,96.41542499412375,-45.2083522958983,0 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark63(61.70046276187932,-12.534100015777966,70.82422940934521,49.963610864472685,0 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark63(61.71877840887433,-10.527654475228417,65.1715669547871,77.51632479021089,0 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark63(61.806701452801434,-24.7547302903818,-1.67545614158513,-87.11673816796528,0 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark63(61.83671387379107,-43.81648059542043,-61.44656777390591,35.917027174262074,0 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark63(61.83935919962144,-47.02382723109964,78.37883149310659,-18.08514734932689,0 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark63(61.87088287604223,-57.78005673484721,30.123010521331736,79.28087719195221,0 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark63(61.899467463445376,-52.982710049199234,-65.03705524735761,-42.67367075699655,0 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark63(61.932458783386124,-9.032496155653092,43.10811107834809,-56.80930561641937,0 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark63(61.94949810888568,-36.1171634383467,31.537646833308827,16.5014760516664,0 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark63(61.968210918898194,-51.26693013111381,-78.26762244106024,17.26792502650892,0 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark63(61.984592074201714,-37.45729415126926,25.91678184895254,82.18086253164861,0 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark63(61.99783643658017,-42.0950023644421,-31.114824483794052,29.432713602310002,0 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark63(62.050751513191585,-50.217153660138706,29.942779278911786,-80.0929701536776,0 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark63(62.15623068604742,-6.852448313207788,42.197647525325124,27.441226930370632,0 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark63(62.1588283338352,-27.078281875303162,66.91122503644527,83.01278101062323,0 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark63(62.21411466323619,-6.37698107854348,53.22474922779571,53.74519301835494,0 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark63(62.22263045036115,-59.12297349383495,9.86983973845588,-93.46029524413176,0 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark63(62.231754679220444,-27.35375319038917,41.942174033596444,-37.96388597528042,0 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark63(62.29067276783218,-33.110293023703605,-64.82885972016808,-41.529351981730734,0 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark63(62.320246844701046,-39.309822475335324,-68.22725175824485,-52.937886725518645,0 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark63(62.328882507711455,-46.40890280113881,65.63483579399184,12.919767770600686,0 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark63(62.361703831217625,-8.10830121227157,48.770049797621084,82.74180403973244,0 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark63(62.411911642128615,-19.389531894003525,-38.172085917570286,13.491175609762891,0 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark63(62.419417325156275,-22.472658712668107,78.90824445669256,6.8744005567154005,0 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark63(62.457445174769504,-45.64829064319442,-90.44319322958725,40.72245440140841,0 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark63(62.47843698492966,-17.93699175441725,64.94946706360878,-39.6937720699035,0 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark63(62.49772225530478,-15.963377133791411,88.82316859300576,2.024950137514736,0 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark63(62.50243631480103,-43.681529704845204,-48.399222013311416,-59.005172158472604,0 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark63(62.52528295664348,-60.401128049778976,-34.19732261099489,41.13221280912944,0 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark63(62.54913457528539,-56.88340848671265,-87.84860883594246,21.260869199463855,0 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark63(62.59247835372267,-58.16739750097093,-48.649901517864656,57.836504006963736,0 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark63(62.59839123890305,-19.44291575034302,-99.54061495520354,-15.331454920240773,0 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark63(62.605477794491776,-1.6002587272319033,66.3605405282623,-40.94092245324603,0 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark63(62.61563630674124,-48.65534278951771,-66.16621552977331,70.83622500780768,0 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark63(62.64159472138786,-27.056087610290035,30.32984127261352,-50.42749874619192,0 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark63(62.64428024254525,-7.05362704496946,82.74997689991838,97.16780328863607,0 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark63(62.66799844920686,-35.31086590474071,-59.45928861354333,65.6889823125081,0 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark63(62.6784147995906,-32.089560130244536,-62.05313308503697,98.03556037113182,0 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark63(62.68826099589765,-46.388697653173324,-66.12261578934427,-73.18874169247489,0 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark63(62.78232396571997,-43.36790275499811,-11.587289004836961,61.13873052214686,0 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark63(62.80664951286832,-8.994658981411675,79.38361071439735,40.65017981676303,0 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark63(62.84102298222865,-9.326714270336709,33.453928273201996,72.78289699727097,0 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark63(62.84367565202075,-11.710241266074163,-87.68905519635305,69.18782046749757,0 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark63(62.86315742885574,-2.579452397010897,10.65251791904069,86.30468101252205,0 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark63(62.88267093072619,-32.40107232828342,32.08078628450042,-9.458497971473776,0 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark63(62.90616975332492,-24.15570465696942,-45.16798988686459,-31.682488591316684,0 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark63(62.9948065226574,-62.68194486177228,-55.22709465047016,19.82053562117487,0 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark63(62.9977924714691,-59.77379760171759,-16.560299918339425,97.85667497042277,0 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark63(63.03099765863749,-29.797611664141414,-10.871694873059965,-29.043176730568774,0 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark63(63.06543083423989,-32.903717214389914,98.53074499976975,50.86445637790595,0 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark63(63.070714339654046,-2.3303207423171557,7.881286781028265,-7.002404068882569,0 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark63(63.09351258976241,-31.225358252032677,-92.32969762545122,-78.85844186929745,0 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark63(63.09863516685451,-40.282085625354824,-29.350420464257994,-92.28324167196014,0 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark63(63.15790149443404,-43.65778627586141,1.4441057851193762,-88.79405773609308,0 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark63(63.190700640547846,-17.12855520850593,40.652330407934556,-33.312220855422254,0 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark63(63.31478363214134,-38.37611468781616,69.64479933965066,-88.2760694237225,0 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark63(63.32239803001423,-7.005359089301891,4.054352211092763,40.59818167995695,0 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark63(63.35367688089724,-49.15729003122507,61.339979699791314,85.94722534250411,0 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark63(63.37792189524646,-30.389468811172833,-59.15872772284019,-41.985882943300126,0 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark63(63.40501252897724,-1.2882298304009936,80.23971015412044,12.03496676643347,0 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark63(63.44967859014264,-9.899552108344565,-59.87062613807057,-57.27654283894068,0 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark63(63.45070798365731,-27.60655495128286,-9.796900095840527,2.7544388557587496,0 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark63(63.504322228407176,-42.10420778272359,-6.748695871127694,-73.90231621518615,0 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark63(63.52275428901004,-29.819342624067758,-66.2010432530598,15.2594460121325,0 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark63(63.52607118473864,-15.131724084535847,56.43210716772518,21.504133192627492,0 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark63(63.566681935002094,-22.031337938699068,-53.98612500155831,-95.98903060656998,0 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark63(63.62694580937273,-21.281305690762608,-89.34220500382666,-52.706940506839,0 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark63(63.62738941870023,-63.01001190522237,19.377408310480007,-84.0434845584761,0 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark63(63.67256274471674,-58.82440374259967,-52.88316782754785,-47.807865780402615,0 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark63(63.68308228246457,-38.051568433352756,56.020537577431895,91.7883405188725,0 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark63(63.70649275493085,-55.82971261675538,71.56602743708203,-17.75095618376143,0 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark63(63.722866267700226,-53.40787524589843,-98.42653688342786,-93.00585905018188,0 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark63(63.82293151784546,-39.71390193101505,-56.59010173210204,-88.0976719185675,0 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark63(63.829656382099756,-50.21744124584826,-1.5515501792442024,1.8469546221533335,0 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark63(63.84801636338179,-32.10554648642807,-10.039883703423484,-5.94423963326642,0 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark63(63.84861994940371,-40.64359416751267,73.33790145404379,98.09977077882272,0 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark63(63.86429775590966,-65.05516505928807,-45.89962632997286,27.000369784835044,0 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark63(63.866007609836345,-27.063234265523462,-41.70100675624868,79.64400379926045,0 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark63(63.86723342517354,-53.40048444622063,-9.464711733551411,47.58987798990168,0 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark63(63.878524308957964,-15.732224326025317,-39.457150351484515,-32.80980639088358,0 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark63(63.91764277668835,-23.684778275660648,-24.212115499396702,99.1600553344789,0 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark63(63.93247050934556,-26.535973752220656,-51.36381682873888,62.30772141124376,0 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark63(63.96112812284875,-27.6850315944359,2.7325520330872166,86.58458280324601,0 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark63(63.997894302284976,-60.17475117152367,26.69046500104048,68.77952995662173,0 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark63(64.01531886673422,-27.877161731122555,58.826693567504975,-7.929528840701238,0 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark63(64.05240792400636,-48.417499474902726,12.590391579762056,-51.01439311657783,0 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark63(64.06030998735571,-25.534943836774687,-61.75385708337504,33.176159535131916,0 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark63(64.07127144712024,81.40669626786939,-66.8077558132639,28.365909672904593,0 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark63(64.10496778511398,-58.901401598359286,22.058894309368142,-80.29948258264866,0 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark63(64.10558995428886,-36.69915038863159,10.564615369762947,15.022165742397164,0 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark63(64.1087363005098,-18.941077232545837,65.61309779021505,66.52435844639152,0 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark63(64.11620520911634,-46.336392866285436,12.15691314018055,-60.14815910282918,0 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark63(64.12768235980857,-19.992789303716506,83.38426692791941,-94.09814939766537,0 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark63(64.16161748651476,-62.87430499619451,7.561693214512161,-47.106601924617465,0 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark63(64.20624410414891,-35.67713690215433,27.366953120210496,21.00068696697474,0 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark63(64.20670621141133,-44.056992846241805,-83.56010695562102,87.72900193671558,0 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark63(64.21711479878874,-34.89636217459349,-92.10449303009034,46.66320787721597,0 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark63(64.22519150685827,-29.33990135531812,-93.43467536122026,51.66380609334098,0 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark63(64.23869891034025,-33.904348577433325,-78.83653476240609,-37.12775006045557,0 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark63(64.29646470205282,-32.63822144848238,-32.51647955817356,-75.47523773546044,0 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark63(64.33898829310695,-14.694730999296254,-32.17324071694314,-98.09582213798349,0 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark63(64.45926851015975,-57.484670626093504,87.38410222853489,-7.780832951948469,0 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark63(64.47786590364731,-38.840826691627406,47.13689887457164,-84.53809034330611,0 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark63(64.50587919353347,-51.896708370700836,58.81079389567299,-42.11456442833068,0 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark63(64.51150094735587,-57.345448613382246,-7.001529012663667,67.37670269619875,0 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark63(64.53285524332085,-47.31614628105525,12.336684490752091,77.56241116753793,0 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark63(64.54756213686397,-11.640755220411705,80.5486293747222,-39.76808331329218,0 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark63(64.56761976911972,-67.22383293008193,52.64588730812537,-18.16003778443556,0 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark63(64.65598719832144,-32.706847647377884,84.17004480899487,-27.030141357416454,0 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark63(64.66487093710899,-37.24486904307944,-46.88413618765721,17.80849847700378,0 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark63(64.66894685544148,-13.907812166930668,-59.50280003697881,54.764389832904214,0 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark63(64.6724285134876,-46.17823529759204,51.13079161202111,57.715617726936074,0 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark63(64.67258620370976,-11.398892476999606,38.34415614709005,-6.691393593034945,0 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark63(64.68820308894217,-36.60248577514731,-69.24147677049284,-53.63423079648266,0 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark63(64.70842174366729,-63.81050106530808,-54.66974086427954,53.606853528223354,0 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark63(64.71816630173865,-34.50045107393831,76.14227977209481,-85.20796622667058,0 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark63(64.81312278074859,-14.846620211849043,-25.268710145804192,-19.447415255809602,0 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark63(64.82569837461679,-56.75862022564084,-95.7122675066185,-69.79464124511557,0 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark63(64.84154137434814,-30.506380910899253,-1.7722528527870196,24.91065329381523,0 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark63(64.91576851557116,-9.19167943975225,-72.20429008500496,-87.82997012028537,0 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark63(64.92300610738954,-29.469192371666338,21.001005929883632,-83.70300678582589,0 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark63(64.92871017352712,-10.65216453597668,12.388041592134329,73.86409598334586,0 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark63(64.99066181033402,-16.8481454613742,57.720962464031146,97.11301948783876,0 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark63(65.00255385607673,-48.45276949367372,-58.287257722259625,65.22281917569319,0 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark63(65.04808380479784,-54.38715329863615,-39.96484116928578,49.02671704871267,0 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark63(65.07505177744412,-40.15718139293316,46.09987599782673,-0.20112243019040932,0 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark63(65.07982235278723,-12.853302438813884,40.723131442896545,-92.49325999675668,0 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark63(65.09299933158798,-13.204217955468025,18.19390425286346,41.959968932685086,0 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark63(65.10888705273535,-41.040534634784656,60.823501888759324,39.359011673153134,0 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark63(65.12629505960768,-39.24526456246018,-23.400148661047453,97.5610559297877,0 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark63(65.13439041500814,-34.258450458805314,-53.96492087268632,-88.46554075338169,0 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark63(65.13732095792327,-53.814353424235726,-57.817628833957045,30.58135870269362,0 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark63(65.16007348032687,-50.379714172141796,-94.02743369324304,-39.27118311057991,0 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark63(65.19188020762107,-71.23661316641304,-20.87437783441908,0.5987714491610348,0 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark63(65.20992543608307,-48.7512907528648,-74.34501673760938,50.27259539520816,0 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark63(65.24567689435816,-49.750931243545,1.8796306282820723,-66.24052637709492,0 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark63(65.26323004261565,-0.327998734042211,20.014219479551628,-35.41807977257389,0 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark63(65.30062858599536,-11.878625308748568,59.58710183073978,99.08202170429911,0 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark63(65.3666758313434,-29.446816045082997,-40.137747872793895,-88.04596854798774,0 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark63(65.42421095050142,-62.84208865947567,-93.72177745506005,63.711056315796355,0 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark63(65.46503964708984,-33.204338428367166,92.61141900703512,54.95055169699131,0 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark63(65.4765462662599,-47.42571156771549,-68.0886212283886,-59.93818647004581,0 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark63(65.47861433187421,-11.873397666770998,-91.78568246672181,-81.927102491344,0 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark63(65.48800953145326,-57.89466221127899,1.7550800348750357,-97.3929297691204,0 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark63(65.51543471886916,-63.837648425769885,55.35153473727698,38.62230761375193,0 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark63(65.53726695148265,-28.85582602980807,-19.174240191190734,90.27218576058272,0 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark63(65.56595955793557,-4.415756666489941,-7.922515498593171,-64.56878291187165,0 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark63(65.57503688216295,-62.992087046833745,66.18269278631269,-51.39344937352419,0 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark63(65.64562814793788,-0.111734431953181,-0.49716185528738777,23.31321982549383,0 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark63(65.67802601623615,-0.9536702546151474,46.699522734425756,-98.35652558972372,0 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark63(65.690940592423,-6.154063835363672,88.16609281030813,15.010939500677807,0 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark63(65.719835813972,-44.7141517066713,37.43303781739229,84.36017430612185,0 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark63(65.80802230406175,-2.6005698683759846,55.03846106583808,-99.2075878700006,0 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark63(65.8095944518106,-34.839315746622404,54.56995934683596,-45.619582870982065,0 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark63(65.829786134204,-46.47514390715746,6.50186578267855,-27.567204164827615,0 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark63(65.83920096147901,-26.677673065877954,52.971807790244895,1.4137556720757374,0 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark63(65.85632005677022,-65.69654594707558,29.37879427119526,-10.214016762989033,0 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark63(65.87076836601986,-31.181654795260044,-24.864870602306425,18.79290994272749,0 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark63(65.93095111614662,-22.974986626439446,-12.083592179507008,-85.87350587346305,0 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark63(65.94697131176014,-15.427493668119595,86.86624823885847,-3.460178917617583,0 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark63(66.05969825876574,-43.27116302670677,-30.449980633014007,-25.06689578415417,0 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark63(66.06744992451371,-53.414319680347155,9.577740217554734,58.87096032001941,0 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark63(66.08895410638053,-32.53957570582796,-40.7024252246416,-97.32211125058295,0 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark63(66.08920839763817,-52.164340249722805,-47.29945046939326,90.4318060064679,0 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark63(66.09672164499472,-39.544989422895085,-96.06671734060316,52.1864421022602,0 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark63(66.17418655198608,-16.82056945158132,-15.403084128650036,12.304985241876992,0 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark63(66.18364486663666,-52.732989545079676,-50.01784159849556,-47.38580243061903,0 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark63(66.19792637226223,-54.25815070724154,-68.38002009391964,-72.7617438961192,0 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark63(66.2269878998751,-29.357613957366752,-87.03460515408703,8.184502535691763,0 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark63(66.2421098517818,-15.136435054122074,-92.57563865348126,-14.521420686569456,0 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark63(66.25425815683974,-28.87350485607614,-80.72452023411849,-35.95213467174847,0 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark63(66.26054236767763,-13.56973104845261,-36.52294421827196,-12.178194268274382,0 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark63(66.26363986329034,-18.017960316092527,82.38384911056315,18.740275468797947,0 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark63(66.2775075778801,-16.15172660816893,69.74405850103332,-3.335918222872806,0 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark63(66.31624074000061,-40.913411300540645,-46.078592606017544,-29.147198843446958,0 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark63(66.32728528299523,-6.202793174581075,89.11364901711252,59.67981437395747,0 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark63(66.34468258626484,-59.68108022604683,-99.67120262907127,39.49797819427221,0 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark63(66.3520143847376,-48.06215099560882,90.59303621275902,-77.61541851481104,0 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark63(66.36238256055529,-34.59204417935784,-82.09925008678647,-11.617803562812128,0 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark63(66.42336771270143,-37.57360061381383,84.8165106183086,-5.9047151184993965,0 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark63(66.42767108409885,-19.584684236043202,12.128235463558383,65.24720100367458,0 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark63(66.47197297267047,-55.10026626927564,-84.5295631263741,28.775448701839196,0 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark63(66.48881000192952,-49.81978702678005,35.84192541032115,-78.67047844636895,0 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark63(66.49162438702024,-42.207483497301034,20.327477459553947,12.0085913334174,0 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark63(66.49903702937746,-32.970573010445975,-50.96519196465938,23.79554671978576,0 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark63(66.5347414373015,-8.813889443260564,-55.58135757509142,-62.394785776399054,0 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark63(66.54536738273893,-50.747396707781654,-85.21455556725017,-73.15786503278841,0 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark63(66.55401417183734,-40.4589411750258,-57.96470201037207,27.242153389341155,0 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark63(66.56509475649784,-36.14975562372196,-76.88306780921006,-80.55252680056013,0 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark63(66.56846446130982,-27.20633635302339,26.612236091418296,89.93006841985815,0 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark63(66.58471777360103,-54.9890821660038,14.270037360342897,-51.394480137731534,0 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark63(66.62439061931559,-55.900474583127725,-80.34717872825283,-56.621524826880766,0 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark63(66.64335847450283,-28.347944922386972,-27.329090429573142,33.39996397194989,0 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark63(66.64567926050796,-8.079352109798904,30.452143732275516,12.039440367025065,0 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark63(66.65850794816376,-53.9408281958746,39.7172387503571,-48.22787584350778,0 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark63(66.67337892584376,-46.39466409369242,15.179488908065622,-2.1217831196468353,0 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark63(66.73240319622457,-8.328639641320905,72.13889535513601,-27.47880640236609,0 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark63(66.74006259562157,-40.71904370077182,-99.4685666801147,22.17217554233227,0 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark63(66.74074022424145,-13.737548540017158,-63.85548012387232,27.309197956078663,0 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark63(66.82342095952629,-62.57294722322495,4.209827728088825,99.89475760410315,0 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark63(66.82746804432139,-14.264321212764258,-92.0860475956353,-96.2122167412311,0 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark63(66.84345755168133,-34.559866350896385,-28.63580899494113,22.035364605654067,0 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark63(66.84634726007187,-59.65856986802574,-73.92027889472635,27.032831432879206,0 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark63(66.85585345214767,-21.566400314296445,-0.7348044825193654,39.60674948372707,0 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark63(66.90792451504856,-41.72592467034995,-84.84481633199267,52.65965410535824,0 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark63(66.91296278539303,-50.50269571447548,-54.5165551329027,65.08110460814561,0 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark63(66.91370520524839,-53.05150849261213,39.768992755832386,-47.249085639647134,0 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark63(66.92739985637272,-27.56458060761456,-41.59076576711931,88.71343395470777,0 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark63(66.93876302230657,-16.829458130118226,-99.56505382863938,14.401593019892971,0 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark63(66.9555097676629,-16.99935145793394,-59.566861670585446,-16.276707860206102,0 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark63(66.98621573668925,-56.176776314833866,81.65720734321295,-45.667435173832075,0 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark63(66.98760823770306,-21.698962494772502,-32.340806407968174,-45.30933968440265,0 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark63(67.02433448146175,-15.911005791946735,-47.23061236098785,27.61395654326381,0 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark63(67.05750269888915,-16.263113851043045,-70.25997545201939,-22.977674608039123,0 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark63(67.06532178783701,-28.824989222362603,-9.496192200125279,28.059664253339065,0 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark63(67.09298945825026,-53.31691376925416,98.14036095993495,30.560291363485845,0 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark63(67.15428380253456,-24.366007232961806,-48.048383261315266,29.539497057291698,0 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark63(67.21521844103583,-9.511890103362148,-46.946948608581884,-66.93819843094057,0 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark63(67.23598856998379,-8.732018152662206,82.16131177273448,-81.08694343297331,0 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark63(67.25082980713228,-1.2939754006364552,63.44612167945044,75.1293918229041,0 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark63(67.26753738445012,-11.54944092455608,36.26551313994247,-10.051946440400556,0 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark63(67.31011581762678,-18.128049734808528,-25.41020307033608,-36.601212563982834,0 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark63(67.33179936553654,-48.086656413142094,39.265195277165134,-36.93856600825518,0 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark63(67.33445307697068,-56.92748713449405,-23.269228455764093,70.33470353700517,0 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark63(6.739832019952502,-2.754778415863626,86.81370859338475,53.248201618564025,0 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark63(67.41219769196056,-32.4227783727879,-25.564180817295963,9.661382017199216,0 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark63(67.41297033883865,-19.39924737682084,-64.94971151805917,-26.616331517359697,0 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark63(67.43379545996737,-17.118307676828692,24.841270969085343,-26.979749679183357,0 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark63(67.52300055923905,-62.03127896619405,62.529795954895576,-19.073447965939664,0 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark63(67.55398194390176,-4.868669770456634,-33.761517228277896,-1.9054121279589822,0 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark63(67.57887170904488,-56.53362560165303,11.90228449529485,-87.85458744536427,0 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark63(67.6217776099561,-7.1677651686393915,40.10506529725336,-31.84621248425617,0 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark63(67.62420636862103,-8.275322378968312,28.01439938295175,-99.50034435255988,0 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark63(67.69943818893913,-36.83510998262034,-59.437346153355676,-22.43790212455164,0 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark63(67.72831453035889,-24.816832698451847,60.668924059018934,13.687635518275059,0 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark63(67.77257599250268,-19.70050491631406,-59.112163433217255,-54.86514803660141,0 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark63(67.77302270782923,-48.0874442706323,-40.84189061241017,-89.55090198731466,0 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark63(67.8129716324741,-24.54974247285125,-3.501751941051978,42.63695319617372,0 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark63(67.82016549908028,-10.121498594926237,-48.936664795143024,85.07308511844727,0 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark63(67.82985793397705,-15.804625194802327,-33.10622008517883,-88.7422243405911,0 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark63(67.83589312172697,-44.62494282957073,-0.31349091939331686,81.73496366004528,0 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark63(67.87402865726472,-62.91463302879894,-13.91888616538597,-15.465631969273176,0 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark63(67.88588819121725,-34.698776803759145,-1.482644162029814,-82.36432635777419,0 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark63(67.90091867295226,-3.7693157331874403,38.19268477524224,51.08769507140843,0 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark63(67.91566924154935,-47.392940732687336,-46.68398128661189,25.79514946931205,0 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark63(67.92442704756553,-41.64164679733102,74.06338799651445,66.41968951343728,0 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark63(67.95399281241916,-39.07219699488127,13.225710428199065,-73.12168648132484,0 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark63(67.96602382408736,-33.07093845414721,94.55919418393063,-6.229659472717827,0 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark63(67.9745611814864,-40.85722704827541,-30.61986296570099,-7.849379770283576,0 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark63(67.98000199487336,-31.576182332001096,49.76218953903145,82.8481756172088,0 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark63(68.00334114686294,-58.27786564147075,41.9311868230904,-81.21966268237217,0 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark63(68.04736701587447,-54.83051999241542,39.73075675256658,76.9204539606053,0 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark63(68.0749058838478,-66.20624517077488,42.81292579812907,33.695518742623904,0 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark63(68.104547860237,-11.528332263555868,-79.22133697931861,-85.38225584905597,0 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark63(68.14280031776792,-15.774471407271932,93.98878678950447,1.9117238313473024,0 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark63(68.18400340465675,-28.404794941942612,68.08700112210667,38.21385300522121,0 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark63(68.23437724888416,-26.416215166232476,-81.9444975380245,-27.377794888813398,0 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark63(68.28194087539629,-78.5104100655195,94.0087731469093,-6.902701921987358,0 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark63(68.28477740763205,-64.64711729647787,52.93061418118347,-5.600981626911178,0 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark63(68.29088142879041,-35.927169370946444,-32.73644333759049,73.78359518883286,0 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark63(68.29182802174756,-26.012545839873695,-58.409389364650856,-55.92742640292583,0 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark63(68.29412358730283,-33.45226134338688,-66.24106358287108,-23.381439176181033,0 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark63(68.2973444396334,-48.90618323242937,53.60119977348802,-24.894840558123548,0 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark63(68.31392303965646,-55.40494346149549,21.723217951060718,98.82761034728233,0 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark63(68.31928824003288,-21.672931956674717,-78.65022804354957,95.09986831286224,0 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark63(68.38321408393955,-15.647515986549877,-79.45301542444008,5.247075610060321,0 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark63(68.41826728013757,-14.018704935357789,-1.3029767930079714,23.141899290057964,0 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark63(68.48871406088492,-63.8045907772721,43.83333347989205,45.63065385707944,0 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark63(68.49333055378426,-43.6327125240626,-34.65792620684867,-86.70987935533296,0 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark63(68.50402341908824,-9.816272702084675,81.68648379865854,-20.355126012256903,0 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark63(68.50668860764324,-37.15770812044785,48.16956154203652,94.95014287589655,0 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark63(68.56291860664012,-60.23460943284253,32.64765768921151,-71.62546497877977,0 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark63(68.57277393457503,-52.486588360626676,21.10941324050613,14.077865999838423,0 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark63(68.59452863930923,-22.784591806185574,72.33160183125776,-24.72519227056189,0 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark63(68.6031990063683,-30.493716151160015,-88.11647695468683,-2.8781462732133605,0 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark63(68.62859056863476,-28.485879912607842,-62.68675839582636,72.89238239581078,0 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark63(68.63321139400526,-27.450726877606527,24.733975184246802,-1.64334580111489,0 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark63(68.63841159907716,-58.60775371895428,81.60129086320796,-52.946462450054455,0 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark63(68.66121058749778,-29.040579299019015,87.60729052735584,52.28990060486993,0 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark63(68.68344166011835,-12.737247974295698,-80.9773030434036,-63.53938078681325,0 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark63(68.68429605954287,-29.62065980045088,86.28693120915946,-79.4738817317282,0 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark63(68.70390822822952,-44.81265271561667,-29.00586984488376,59.53965759051886,0 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark63(68.71658295984474,-52.30753038849176,-89.79871781807131,-5.739663180137413,0 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark63(68.73705514956657,-51.26454133833347,-81.43080321771951,-94.43099195403342,0 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark63(68.75324121185776,-10.818006370783166,34.904242953155716,-40.916921759099935,0 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark63(68.77200038904303,-46.82659930497006,-33.36631167079331,-54.663717787052946,0 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark63(68.80092446806049,-13.653991872546271,89.15791681622483,33.71704663173739,0 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark63(68.82359305978446,-48.1788957736689,24.47378244707504,-59.49054297985512,0 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark63(68.82778006392104,-58.27809086393678,28.574047717647517,60.195652954318405,0 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark63(68.84059402109187,-62.31752357169882,-63.08997054090453,-58.063290231857366,0 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark63(68.85459161481145,-56.092447296077786,-83.64616029301979,-11.295774681551322,0 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark63(68.86395405414814,-21.974344791596636,16.879577835628766,58.30630247520523,0 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark63(68.86840116855325,-18.67236077503354,69.40858321934854,1.6175917030455338,0 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark63(68.92213005204255,-20.531488048615927,-5.293417003255101,-97.56299499976578,0 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark63(68.96223949584629,-72.93861472602461,37.055539008711406,-0.038795180917958305,0 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark63(68.97485794120323,-22.637525663219705,-61.37012527149472,-42.178132162162484,0 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark63(69.06294504355387,-29.38027590825473,-62.82506286279812,-19.208045789925322,0 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark63(69.06930738873194,-54.74349599492649,59.304195825698,-81.45225395535367,0 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark63(69.07380415482962,-6.738860372584483,51.845719443131316,-98.83568498512447,0 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark63(69.09566769736105,-60.04663676778357,74.97293038921799,-54.34035162151507,0 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark63(69.09879397166995,-7.5822458673155495,17.872018019103166,-80.26480442480361,0 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark63(69.11646031542006,-40.92230716009448,-14.878973194575764,-94.70403959362919,0 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark63(69.12640713718017,-20.077049107573146,-62.69734950753336,-64.24059793461747,0 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark63(69.23890009148738,-61.84161104716248,-33.18772653268536,96.49724699351171,0 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark63(69.300025217946,-5.373552947749019,-14.587265539016059,-14.240432312623483,0 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark63(69.30659469783726,-50.4966006453502,-53.721108017309696,-62.52551349411035,0 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark63(69.36898986032782,-65.25348763587536,77.81746701417669,95.73649234008471,0 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark63(69.37273248050639,-52.994721374000676,-66.98883611057032,-16.362978666999567,0 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark63(69.41247119741232,-51.95563297484775,-21.069010401154742,70.8061273694735,0 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark63(69.41959160738412,-65.06081732854395,-98.11801206959126,-33.81521846389984,0 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark63(69.43196971811301,-27.495717316626852,65.77818352558867,55.85333078970342,0 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark63(69.44718705491832,-41.364862248025666,-84.69802890650242,19.06793756231629,0 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark63(69.48684062597874,-61.69133650483764,-90.90803203660913,-74.52284604334537,0 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark63(69.4961776576437,-35.435110343525295,-12.060022994373526,-32.07014731093922,0 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark63(69.60007899193778,-30.767719268582724,-7.668039779206538,68.93587945991266,0 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark63(69.63129455811537,-10.071535462385455,74.04973984537045,50.94735203002031,0 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark63(69.65937036006946,-0.4560547208175052,14.567828148639833,87.75792218731596,0 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark63(69.69315339782966,-54.74350653321282,-99.69411051962129,27.644527799755153,0 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark63(69.71624520771255,-58.34485693310783,-3.6154863779986215,18.447930161164066,0 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark63(69.72275368880477,-22.479365651701173,16.02232637564802,69.71287828078766,0 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark63(69.73877067152671,-32.11663798034084,55.449577649758,-95.00946116664488,0 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark63(69.74873896841513,-59.896974905811675,64.17023724627825,-19.020877576767006,0 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark63(69.80400173677845,-14.847763544047325,-45.122734487736736,-78.10540042337163,0 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark63(69.82967073834106,-63.89055512345869,96.43103004710582,73.67292029633597,0 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark63(69.86196125600955,-31.16126481904638,99.91630346825556,-68.9418032340872,0 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark63(69.89006428309702,-26.566407846571977,80.15304945267866,95.20825358788551,0 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark63(69.93893327395193,-6.466407653371846,11.506548845560076,22.310240499024218,0 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark63(69.99961364338017,-35.398781183903566,0.9959262966764442,29.76627441574621,0 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark63(70.02474122992732,-13.921175322662378,-13.017412788831876,34.258096265176505,0 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark63(70.02984845407221,-11.361416134717686,-15.981301761561582,-67.60202757850104,0 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark63(70.03342343363812,-0.21683268158068358,81.90690463795704,-22.355165195948203,0 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark63(70.03588100483614,-14.605325328040436,-24.12224430909295,12.942048219470777,0 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark63(70.09750937101776,-8.132335694211747,45.14809900972813,1.7786626245580806,0 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark63(70.10334816387825,-71.31729474758723,-76.2699866914029,39.650242546203856,0 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark63(70.11589374332934,-8.513916624133941,-6.468512311953205,-4.517793267556684,0 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark63(70.11693964356078,-2.2389694149923542,74.19066099314944,-94.09194686681231,0 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark63(70.12071354046529,-16.34917259409052,69.84282520636563,50.68717960899082,0 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark63(70.15033784726288,-58.77463206547353,-79.62249420182137,95.17556951875306,0 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark63(70.17927650781479,-50.193237715579244,37.06587521978787,-40.01760337560882,0 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark63(70.18330344379635,-46.15278317867133,-12.697419848665021,74.61531803396068,0 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark63(70.18418616895667,-47.624959671055514,56.408219203141556,-12.972919946146845,0 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark63(70.22177311380071,-23.258115292956276,23.77597866033385,67.55265879943514,0 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark63(70.23039781713359,-37.048868960208914,43.53203821686452,-54.63566943210281,0 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark63(70.26160144039383,-27.59578407876957,-88.74580443418132,87.83494827344,0 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark63(70.29767906829863,-11.381383398671076,-33.0010896412021,62.71043670768887,0 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark63(70.32566165571058,-29.765677588384662,-91.12802994959328,71.24019438796304,0 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark63(70.34188023683888,-51.782173144834246,-21.696842492188523,66.2272896744991,0 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark63(70.34888483965804,-34.85078986300796,1.5025577446088079,-37.75917169893606,0 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark63(70.40765354871542,-10.040746137699102,70.11424411737721,12.765485143163957,0 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark63(70.42757854862393,-10.796152910488658,36.95461868424411,-35.53932372170354,0 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark63(70.44152267812734,-55.51426327003524,76.66475901619873,-19.581925762386106,0 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark63(70.48789913516512,-4.659547684884771,95.49095736171395,-57.083181458816924,0 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark63(70.49779674335122,-11.269299450326912,-14.23377891497934,-21.800383837450482,0 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark63(70.50465754526635,-60.98068826057561,-95.99536493899525,35.5395033403768,0 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark63(70.54038835736486,-40.435672113362784,68.41747118791577,-25.775913453201753,0 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark63(70.5453322777154,-8.354356423649307,10.089988304503578,-75.95366986700425,0 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark63(70.54802290443033,-49.972357442810946,8.42471120212464,80.65598154135668,0 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark63(70.57104782325845,-24.826014306464998,-98.62229838860108,65.36479407298026,0 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark63(70.60132820105173,-42.8086197437769,-95.11649421996353,-48.121959828332784,0 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark63(70.61014486389746,-58.27135397023318,-93.84542176582448,53.4433002477345,0 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark63(70.63034602256164,-56.91376136485751,-94.63475422374603,57.64845525644361,0 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark63(70.63637190300477,-27.06022307610752,-43.84382537902318,6.0939738647039405,0 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark63(70.67439641575547,-6.640570979685506,-1.2586485430881424,17.333335172066384,0 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark63(70.70365422844102,-38.99377607411605,-90.88260217663672,-28.788192780235605,0 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark63(70.71292764914409,-24.980798657279408,-58.51192939153955,61.7928119715707,0 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark63(70.77140431570652,-44.890105406426706,-89.92567048615896,93.59343182814973,0 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark63(70.79431115991116,-26.15885095866402,-28.788183008761564,88.32364448154928,0 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark63(70.81262149310612,-51.64410882783814,-65.81329781073875,-47.364239818501396,0 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark63(70.82887064859565,-32.23363293562882,-99.4564890617908,32.36617378670209,0 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark63(70.8667519936215,-40.36417797045284,9.010217396011171,28.360836087479356,0 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark63(70.87458464490345,-51.77636901416647,-54.33365282889373,15.366620773799283,0 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark63(70.9214246165325,-35.69014123943984,3.96329487332639,-83.15450150910462,0 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark63(70.95025975366559,-57.397214401930086,17.103775232396472,-31.716275265796213,0 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark63(70.96001514075485,-13.532084341615032,-75.70738372071935,3.791605457795427,0 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark63(70.98816823667335,-25.235644452368007,-1.5557423288730092,44.84023338438925,0 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark63(70.99984489850272,-31.487588033747954,-8.19890582107405,-1.9901113572757083,0 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark63(71.00227346110148,-72.43420102092573,-82.83612320323937,15.06471430602518,0 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark63(71.00651287216525,-38.384094397966706,-20.725685451283198,-6.344045215326759,0 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark63(71.01082653314467,-35.96702610328606,93.57040218822857,50.5364802441874,0 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark63(71.04044909260773,-29.445860876446318,-18.90348618764388,-97.1898408722887,0 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark63(71.06997572805881,-18.408876216937216,-6.360048630362542,-31.137882113678046,0 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark63(71.07388561177194,-15.419811053378837,73.80959646552563,65.66271949909915,0 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark63(71.08565624728607,-38.08002838346305,-23.866139117271075,37.41760679089077,0 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark63(7.111116417455804,-0.5105389080961515,72.80804044533971,-36.97987414063044,0 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark63(71.16457960328731,-60.524220424667405,5.937537245801039,-89.66148001967349,0 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark63(71.19164133566994,-0.9069583295045618,6.653902525632944,-45.65294552022037,0 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark63(71.21631711595577,-8.656438255946625,72.59397358982855,-84.3642641705839,0 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark63(71.23458532737828,-34.53492142494834,-7.3630342361686445,-66.40395170316727,0 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark63(71.29662098353523,-50.01068207348911,-98.40691482404105,-34.7462632129494,0 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark63(71.30589288254319,-23.58932800647308,-80.69675902894144,66.82475818829607,0 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark63(71.3095139776074,-46.73308571334096,-61.219354457869635,-68.65404462214877,0 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark63(71.34519080051714,-33.20244618478951,-58.014818578111104,16.009433679931504,0 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark63(71.34863680893199,-64.91358219680964,-26.047273535169552,-20.60297290416493,0 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark63(71.36582879574408,-69.94486407102696,89.52848493140175,-85.42413797394386,0 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark63(71.37402537443782,-49.61550644398691,-8.758123424445529,6.623032402965606,0 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark63(71.3859522774562,-46.702524853558145,63.85292143457565,-34.44953690089423,0 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark63(71.43388162293536,-33.91964075123708,90.37597058671943,-42.082963614777235,0 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark63(71.50166921039408,-47.02270304248637,-29.41567495493453,35.70726687264104,0 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark63(71.51268143847506,-20.04799236060728,-26.590961140041443,75.76070232541576,0 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark63(71.56999827501912,-64.24469488697218,-57.43615066960754,42.666268089844294,0 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark63(71.5904531225849,-65.03754179669619,-89.9016650677686,-66.66108790701561,0 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark63(71.59366442316536,-42.01411228070076,50.833050814143405,-51.66604200108409,0 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark63(71.59532283451338,-52.71103988159138,34.153660779870734,8.172360996942714,0 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark63(71.62867815736499,-10.199185944699437,35.779137603123075,64.14407354134354,0 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark63(71.63592512936324,-46.9365201804655,-78.38942360484427,18.738129697583815,0 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark63(71.677105946956,-0.2960780336437949,62.7644748123424,-82.38699108932911,0 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark63(71.6871364124151,-25.100270641192026,66.87338203010634,-20.143580960208766,0 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark63(71.68826665381283,-42.49744823872399,35.818597695338156,47.007460807993766,0 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark63(71.70440714877003,-61.62385536351982,-45.584432059291146,-61.980250859011306,0 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark63(71.725151604916,-58.04086346473767,-21.971473971203665,51.60756673652617,0 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark63(71.7305737569352,-37.350655711343435,37.23348580691555,20.54232222381222,0 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark63(71.79790809070658,-50.62682364152229,-8.711039585636883,80.56032161023424,0 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark63(71.86973744999776,-1.8139251416021693,6.50671138123262,-76.74176399726376,0 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark63(71.87787168503124,-41.67318934950273,37.72826154495283,-60.60066812720575,0 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark63(71.92422470292607,-44.01933958722495,22.792214970262265,-70.04407691710104,0 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark63(71.96552024684479,-9.24046612817611,34.619744404311945,-18.83385652077348,0 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark63(72.02761230772282,-0.887296797066,-1.64708146359105,-81.46248729387366,0 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark63(72.06723047689863,-69.8443906454753,27.681308865965775,25.208421413137103,0 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark63(72.10296060106685,-25.737830622600868,35.85547023549492,-44.34628811788623,0 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark63(72.14156928501998,-8.518110820414847,26.038790943269447,-18.949178926600553,0 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark63(72.18942867832757,-37.32059319700332,-96.12352574220276,93.01646788622207,0 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark63(72.20243271764323,-48.82291490099484,57.728604473136016,-95.89761762583282,0 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark63(72.23417716368203,-71.19586169591705,58.60482282009366,-48.33200583934128,0 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark63(72.24093732162848,-35.14422457292481,9.11474074909448,6.845379302679234,0 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark63(72.24903130759935,-48.33330980787196,-60.96730691518437,-15.315439455471406,0 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark63(72.31208399137353,-34.67709575324905,13.505835661489513,-34.085730944029606,0 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark63(7.23129768076835,-8.698297797290095,34.11173498658539,-2.9529732843678715,0 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark63(72.32317917139486,-73.0098125068667,67.57209058483505,-42.52157404884858,0 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark63(72.37329731855942,-53.67844304751601,-82.04304411106607,-69.80585187601974,0 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark63(72.39201280251532,-54.60161538057902,-23.602483951801887,98.50815509521146,0 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark63(72.40238787839809,-58.972923288847646,12.005833284815438,51.876888347789276,0 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark63(72.42051065912355,-14.902321425838736,13.213787856034457,76.36057260819194,0 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark63(72.4443812958454,-71.61897440087537,52.770779363931695,-82.5498409644881,0 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark63(72.46632243400612,-48.937924441725954,46.846444936771775,18.031721034001208,0 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark63(72.46797709151568,-60.91889838535243,-14.643687279038005,88.05811234726897,0 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark63(72.51617023445465,-14.093857328902246,-59.2276643642285,16.7446394999547,0 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark63(72.52344849033085,-52.38206066450755,-9.523887918408008,46.31597780137059,0 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark63(72.53564533266004,-59.53233558880744,-40.055219971738175,3.33458131491777,0 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark63(72.5898399620994,1.7554392189378092,58.49326936150803,95.68895938097,0 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark63(72.59083960208329,-48.31439929501031,-32.852164554981584,45.47074119708216,0 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark63(72.61007011718084,-13.400880388886051,99.42308398391398,-49.614104514103886,0 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark63(72.63344096023837,-41.286920862210906,-58.18977054156021,-98.27366417398022,0 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark63(72.68926877040428,-32.33542736453437,46.50629033296207,-99.82917106466887,0 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark63(72.6966564902977,-49.4852389502211,12.451246893252161,-90.01513681255739,0 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark63(72.71983562566689,-35.07846046205229,74.34199635617037,70.90495281395712,0 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark63(72.77688038830595,-59.602623882217934,60.294884314763124,55.54284823835221,0 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark63(72.78467371816822,-43.37103406237968,-89.17783089793471,-56.5274856213922,0 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark63(72.78500851824344,-22.750440812916125,69.86490210493679,-66.6986578662697,0 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark63(72.79073821987811,-71.69536913213517,41.91674080093398,45.08002673996384,0 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark63(72.81809497820183,-18.707061268734932,55.045469727442565,-0.263493500721367,0 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark63(72.85158217882619,-35.70648423983582,-22.910435241952925,22.53970228855306,0 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark63(7.285619302000228,-1.5849244025610005,-0.5631842322403742,98.4189376745999,0 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark63(72.8846211472902,-18.00662410450296,96.12329693140029,-85.11447508220016,0 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark63(72.9295709090305,-44.51306873405254,-71.19935531169199,11.3284829908457,0 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark63(72.99514058953974,-53.064006899719864,-27.402134981190912,-38.038172955565244,0 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark63(73.00154332626519,-2.2896948457867126,67.37643381617602,12.88581470806345,0 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark63(73.05154651598627,-4.879096103832296,76.36488891337098,-38.591573352832434,0 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark63(73.08343226126888,-46.46571722830717,-57.760312260939095,-90.3163693580756,0 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark63(73.10161226590762,-35.11696054437998,16.324588829332697,76.39318540536348,0 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark63(7.31231432827127,-0.9425499304712446,19.325596112218776,76.81984784328347,0 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark63(73.14128427948384,-68.16965482120041,32.58672208475687,-23.733184923814733,0 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark63(73.15496236011256,-9.398835623987509,-33.76561002949691,6.77652300286357,0 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark63(73.17683974731682,-39.58564138452165,-47.89639062666438,43.22629737961719,0 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark63(73.20998910734264,-93.15483922095402,93.5883535749665,-1.4880903996043315,0 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark63(73.23968458282312,-35.81887539525444,68.07188478863307,64.61518286926932,0 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark63(73.25008714600796,-25.822381334487616,-99.71841832887432,54.855146817410315,0 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark63(73.25380066957806,-42.3688752841384,16.381491236918905,27.854303943156552,0 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark63(73.28873616381642,-70.79224350155295,2.015625989806196,-7.3809722911693,0 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark63(73.2942086576964,-2.846385485240603,48.993213348901094,67.94018248819614,0 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark63(73.29537591823927,-26.28771578438038,-88.56071986050229,24.215508752252333,0 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark63(73.30391299708762,-26.23165883224796,-76.71562647407262,-34.95331119273936,0 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark63(73.31085020386035,-29.86095433547422,68.86124144232804,-63.15046635348425,0 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark63(73.31610864156778,-57.86786678779878,91.38729654589878,-77.22206879534122,0 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark63(73.36063871478834,-16.076820040153407,94.06150166560528,-55.239676641035174,0 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark63(73.36137256959867,-49.54372947239021,-68.2696507877258,-79.13275647940537,0 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark63(73.37379026988705,-34.879060842681625,-13.5055903120562,43.73827468451398,0 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark63(73.39045777406773,-40.346921229958156,-87.82902443046882,-66.84006778298598,0 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark63(73.39958454118158,-45.084923303545324,-98.31595516429168,-71.77519583080621,0 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark63(73.40207720964517,-39.365610071636105,17.558964046303657,-1.826838141089084,0 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark63(73.41138669529664,-33.40827743941519,76.15958628875615,-74.78064141720044,0 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark63(73.41646036126272,-15.70586255486586,32.57421736830608,50.455891191394045,0 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark63(73.51843827646991,-46.17019558084925,-99.82967141007637,-94.6840944841932,0 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark63(73.56387646234191,-13.796630996878378,-20.124523023410035,-44.36265431866304,0 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark63(73.62817778032414,-74.71530461014568,-85.1459008009208,16.299299224504992,0 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark63(73.6437479744701,-43.460719949964634,67.48859793722454,-63.125510772657755,0 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark63(73.68345093667324,-37.523503149048,-33.241324205447114,-47.19475514408964,0 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark63(73.72171596148326,-8.153601045465734,88.16678576686706,-61.57447143647532,0 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark63(73.73112531352945,-40.522724187341595,-42.77471136010096,76.95045839820699,0 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark63(73.80227250296682,-30.640917044853992,-64.80638352672713,55.29091220175249,0 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark63(73.81091147708571,-24.491429820549328,29.614546524213296,24.04994827510471,0 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark63(73.8291555327948,-14.548543315037051,-95.79483799312018,-82.78713887451059,0 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark63(73.84375626394547,-8.335734975776248,-54.97562626108545,46.27128101339278,0 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark63(73.90430869089047,-22.152658411791208,88.36478314143608,-74.77500977710704,0 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark63(73.90874288375707,-41.53837156489877,20.55478682380057,2.4000532664334173,0 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark63(73.94122341180213,-3.4051557124042517,-22.475752568757784,91.3552147184443,0 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark63(73.94649058733677,-14.188242088214082,-23.26120135884402,63.29897561163958,0 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark63(73.96473572645911,-48.8028235740861,-54.780386734495835,-73.80730210332834,0 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark63(73.96763823779736,-32.04680272050501,81.78996187976446,-87.00528974106135,0 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark63(73.97546238670506,-4.876235310564354,91.04783375737483,48.973842928525926,0 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark63(73.99940394495451,-35.777673079065124,27.864097831522756,-99.50415726149026,0 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark63(74.03683871893855,-38.166580663904796,23.97757755452308,3.963460017134082,0 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark63(74.03743635426653,-36.43082187981908,30.024293022265624,58.20118841800635,0 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark63(74.04329992895595,-44.207877467207,24.53505192437737,26.1744994716032,0 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark63(74.04413396580952,-44.619821900923704,-91.80113021458575,-13.03403112501691,0 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark63(74.0448552378848,-52.71287928552428,-85.6778526601208,-12.156019294807209,0 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark63(74.05692956678465,-20.29325938706836,-12.080863496804795,-75.28013807346643,0 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark63(74.06218825013019,-8.629921004642654,59.5944437321902,-29.914050386130484,0 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark63(74.17090570842208,-60.48005135608865,41.5047935239092,-59.268623663710706,0 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark63(74.19380946482968,-36.81372569168595,-72.60376144010026,-98.14010485886344,0 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark63(74.19607419308699,-19.08208390301644,-49.35415566204979,-51.20226661580438,0 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark63(74.22563044815956,-23.07371199632304,7.343268600383212,67.1300676123399,0 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark63(74.26300444959159,-55.374713873213175,-66.53923300962848,-23.32749514922665,0 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark63(74.28587273000235,-45.78600514693427,-77.13263061687023,-40.02638636575706,0 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark63(74.31973343595811,-2.310465012802439,48.57997551139621,-30.372460267721465,0 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark63(74.32508567505388,-10.280936530009072,-60.7491190620397,-56.84720035113957,0 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark63(74.32567359175826,-43.70104197128111,46.48350615546394,-0.2817015458492733,0 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark63(74.34801824849441,-54.77224975251795,73.8122027552194,-8.993137419643375,0 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark63(74.37211083587695,-10.476284145915898,80.18319579639598,64.62108732394432,0 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark63(74.40333002445337,-18.84772438788201,-98.37061956430865,-21.43105767392069,0 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark63(74.44658367849814,-18.299423037430813,70.76487244236714,41.53526126780116,0 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark63(74.45255774372535,-49.37950371336501,-13.29120666114008,-69.94717731279874,0 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark63(74.45930183389422,-34.81047244606765,73.95362011220371,-22.395781050736247,0 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark63(74.48139049590688,-43.95124581923022,51.46415541217371,97.39867469337645,0 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark63(74.48759897247527,-55.79048449815698,10.44723776049672,5.428148532362471,0 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark63(74.56186685418868,-59.04237728219219,0.036237655456133666,-40.67619223401127,0 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark63(74.57330168585327,-18.531344350155038,-27.862960150874045,27.76765445131298,0 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark63(74.6079081640022,-48.192457362757125,85.89109049263996,19.38387284622256,0 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark63(74.68509646665697,-18.56941873091759,21.7251971462521,-78.7730474653774,0 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark63(74.72831487457299,-40.551521700355806,1.9643896166093384,-67.71785814141845,0 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark63(74.74898895095319,-63.414691915506616,-10.673984501078635,-60.863290803360904,0 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark63(74.76435327787632,-18.18883196644319,14.712789751576437,52.84762616850696,0 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark63(74.80185840127086,-51.137673095049905,10.480576839041504,-97.38055462608706,0 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark63(74.8060663923797,-37.62025243967846,44.8229769118316,-89.00648738707275,0 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark63(74.80862595269403,-68.34484916612145,58.07709690923767,49.35635386696856,0 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark63(74.8122914924719,-3.426787345362257,34.46453998683705,-85.78959915790851,0 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark63(74.82437408012487,-2.330432279572122,33.85884387921084,-54.335514132099384,0 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark63(74.86067709489001,-65.30039464515396,-65.99258386637578,-76.9890202378163,0 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark63(74.92678634965517,-51.470297210949155,-59.39319714595377,-94.77723103731273,0 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark63(74.94582984525888,-67.46571236360082,-72.90938302014452,59.5416326986406,0 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark63(74.9464435868598,-24.261893599709623,45.63496281611316,-28.381552714552384,0 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark63(74.95413275637401,-39.86557964411954,96.87911940562918,-15.996958946250345,0 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark63(74.99031225264469,-65.17620238694018,-79.35826241984867,-61.45497574733292,0 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark63(75.00984431238419,-58.367597978657116,-83.57025146864103,52.00692827200666,0 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark63(75.01373222190722,-31.607267254645734,0.3832962018328203,-46.06200445537372,0 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark63(75.02803605179838,-63.025615435385674,-62.50013344605432,10.057178080618215,0 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark63(75.03041686114216,-10.113391852708276,65.87399331373163,-37.53807605625133,0 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark63(75.049378194996,-35.85702855263773,81.43127458742697,-69.06092899077791,0 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark63(75.09321729799768,-59.03834925282781,25.109689434547704,-63.43241679193217,0 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark63(75.09617110604276,-65.26199893660711,8.279966825351977,31.24441928669401,0 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark63(75.10039513447256,-44.740139339340736,29.702151899088392,36.515342118985785,0 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark63(75.10726090014603,-9.811674133421917,-74.08107873819671,43.73615597621978,0 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark63(75.11645443291283,-41.304451364811136,99.99234063843957,11.09706759767461,0 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark63(75.11954972536796,-40.67143624823266,-48.124518239043844,17.64136476284115,0 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark63(75.12345621435412,-45.83868338647632,-57.01252924857067,68.94860944603738,0 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark63(75.13367819000939,-73.40822408119405,88.05513700547084,-11.831932387292255,0 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark63(75.14182950926102,-36.53726245930331,-95.77339945770346,-25.379195817370316,0 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark63(75.16349534648697,-43.895934320957195,-61.93032005230727,30.000317458693303,0 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark63(75.18731785800253,-69.90592324048428,-40.59674587540654,-79.40280610134587,0 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark63(75.19475813889284,-60.28844904565489,79.80661043750874,20.281058286280683,0 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark63(75.20176886939251,-66.76951985929547,-99.08935309642237,86.68158750124911,0 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark63(75.2427017166261,-26.700633613425495,25.630690439216693,-50.19262273911798,0 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark63(75.24620190573344,-5.956452041711202,-39.28793168845686,68.75909507952,0 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark63(75.24632583415979,-38.396674967378395,-40.84621607807142,-69.71386878956989,0 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark63(75.32800514072372,-30.79033333569015,44.80135656634178,88.28766022206418,0 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark63(75.37781591965239,-68.59211687470072,88.28582887418912,-80.10564870540563,0 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark63(75.39367236171057,-36.13960649734685,-75.29657736979883,26.20011917670142,0 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark63(75.50862425440826,-14.323348310158735,-30.373407540368476,98.77294346798678,0 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark63(75.518984883234,-31.770384116753263,-29.310738700676836,-48.58076602991177,0 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark63(75.52418835603103,-14.655725228142202,-74.0698727998581,-57.20567346958565,0 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark63(75.52496554777625,-59.725864370089845,37.77919309027229,-20.282218589684348,0 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark63(75.5361663507573,-45.189702542973635,13.368512627307723,-54.138995522307745,0 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark63(75.55299856356342,-13.729496783949372,-56.77280310487747,84.88982278722861,0 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark63(75.5661086991397,-10.842880801893571,-42.578939641498394,-9.798379018326543,0 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark63(75.58127949497882,-71.44621717779873,-18.179679338176058,50.268511405500135,0 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark63(75.60656826674153,-18.48608930140496,77.26642546958323,3.018300034573599,0 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark63(75.61694845045358,-42.442895494073476,19.412025456555227,19.53194099022582,0 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark63(75.6243460786788,-29.359593385670536,32.16725725852271,27.163423974250932,0 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark63(75.64802987800303,-40.757559861072544,-84.34629361031925,-3.1720930460104455,0 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark63(75.66716575575992,-16.865411671998217,-15.933352648650498,-18.79134386465114,0 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark63(75.67857168419769,-45.61669138652758,-15.567357233966604,86.13706996641005,0 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark63(75.69850975320605,-33.52768677997247,-35.98869489517449,-96.78798384968013,0 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark63(75.7299735622936,-7.680658172116338,8.414422758798395,97.95270096860992,0 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark63(75.730374435036,-0.7734694207672987,90.00449188729164,58.78868881726024,0 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark63(75.75101510496737,-28.424558603748466,-78.10529001675607,-51.058961511975795,0 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark63(75.80084609137194,-70.25701347073729,-87.39426401499892,-54.310635231478166,0 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark63(75.80580797935829,-49.23283024194001,61.21036099885225,-12.072334132121028,0 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark63(75.82800881293707,-46.82925812707977,60.07326051480081,-40.738224537778734,0 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark63(75.82848365102802,-39.566334592544685,-35.37969485807784,27.122187467277854,0 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark63(75.83459658047462,-47.92152783951069,25.04409317734273,-25.060008643322632,0 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark63(75.8555051145502,-61.73918721185796,-15.179596263516103,-27.95415306672031,0 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark63(75.863450311149,-52.916162974301905,-50.458200502291795,0.13034495115557831,0 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark63(75.88790101296081,-58.7142381039349,-26.576550698005946,25.128243276797676,0 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark63(75.90317081424365,-70.82570001044732,-37.723401379445384,-87.50952262424451,0 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark63(75.90328892636984,-27.15716148806868,25.9332528357441,-93.48977728254215,0 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark63(75.91407104738653,-59.147389963306665,8.648325132487415,87.46275302406477,0 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark63(75.93842094217047,-76.20447617337405,33.679166532465445,-23.30476529075827,0 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark63(75.95208689795993,-50.871147504169834,-61.52038239776745,-36.34508033985102,0 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark63(75.95333659220987,-21.89684871013276,-11.107683421310696,23.066823801407637,0 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark63(75.9624005775996,-62.629642925404916,3.4619120843754274,-95.89320814562853,0 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark63(76.02802768634552,-33.28834562563753,65.49037128286821,-92.30398712462164,0 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark63(76.07588816843545,-34.81270317990088,98.17054840571359,-96.88667061838909,0 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark63(76.09591647315236,-20.11114787793285,35.10055334002453,-25.05695156099901,0 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark63(76.10074834279052,-32.41532834514001,-48.458765742131014,-91.23572953320985,0 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark63(76.10982136599225,-51.830075233043395,-70.2151729183498,-87.01508660716932,0 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark63(76.11979795229504,-43.38914831518987,82.8177033214001,34.329063160271005,0 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark63(76.17703737006454,-51.80446542141346,46.88929683152645,82.40580926601166,0 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark63(76.2066732013212,-31.048837214378835,-80.22905276165596,8.84917888661289,0 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark63(76.23987036564284,-19.543131374820376,3.8240399689915705,-10.69531382254587,0 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark63(76.27512092325748,-27.76269258105357,-11.311602256920366,-3.075444151975887,0 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark63(76.28550113998455,-48.275958587572276,-69.14057278434034,-10.502809815192293,0 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark63(76.28841370959739,-2.8233726351994903,-20.932426277149148,66.81149326358997,0 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark63(76.29733674662015,-50.35641831414046,-98.55848717567525,53.58594201164982,0 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark63(76.32538250628411,-56.253260670858296,45.22760392989116,-92.84917025219013,0 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark63(76.3726459028027,-71.23973667079318,-10.394906357282622,-61.38418081165542,0 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark63(76.38355573763567,-23.71369628964024,36.73205510508933,28.69289874321649,0 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark63(76.38803335773679,-36.562230191438495,58.02703642611169,88.27690764774621,0 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark63(76.4142945304979,-5.478160848392051,27.704906352127296,3.6606857643767228,0 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark63(76.42185948330217,-31.726024923410407,59.36431064874773,82.8445260729024,0 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark63(76.45551563551618,-55.07317223296517,81.1588311662895,-4.294282761417207,0 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark63(76.45990469829314,-23.134716096650763,17.627431546508006,-9.47570280394541,0 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark63(76.47126674945181,-61.19760856953435,-12.372545092841804,-66.18188104649423,0 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark63(76.49254057983941,-29.07676023905745,53.519046230436174,-92.50807344623315,0 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark63(76.50436045472858,-62.7639049226915,-34.208473114040984,-46.72837242712777,0 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark63(76.51120460342361,-15.953538413934993,38.49125259073321,-25.57176375525303,0 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark63(76.57312709518595,-37.939214373197785,-99.44024454717851,23.279055895689837,0 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark63(76.57439976380661,-75.65524390990335,43.18382153943162,-56.51654910085302,0 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark63(76.57522526389002,-23.786561794787247,94.67940728498954,-71.72256816815474,0 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark63(76.60301174891757,-56.02347271141457,24.213731206459556,-52.5634169576195,0 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark63(76.62810419206141,-50.558962324828684,61.50487369039851,-0.5544851908454262,0 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark63(76.67255901610457,-17.538060694157465,-74.07937582915616,-75.3887748590105,0 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark63(76.67919246613309,-29.689691305092296,84.0144708062565,58.91857603108838,0 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark63(76.68452089750798,-70.24489410797818,-24.586466207772986,53.57135208669365,0 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark63(76.7207955402717,-11.416010734571145,75.32260942074322,19.56431848217038,0 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark63(76.72816668666363,-27.1814488485427,-60.086783009700696,76.545581347455,0 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark63(76.73511338441077,-50.877364810175195,5.933266307477723,-31.0405961176115,0 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark63(76.75284144093806,-78.79105316392923,98.06833290146855,-24.644771291745585,0 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark63(76.75568045214288,-31.076251180238202,-26.501626697089023,-40.30786967289954,0 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark63(76.79060589357664,-5.260500654223591,57.731978775735826,3.3420866207032276,0 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark63(76.7967313900316,-29.37434896240194,79.06552785558748,5.72523090724755,0 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark63(76.81909038332029,-23.147893288441395,22.118355306871322,-43.38359182922979,0 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark63(76.88771536865522,-35.164309882061346,43.86328739960953,92.34177574091484,0 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark63(76.91230929088132,-30.779970694977308,15.280593679672535,-22.43392522453766,0 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark63(76.9264386378475,-16.908845133136623,-48.27441003770338,86.83238513123854,0 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark63(76.93243194367477,-71.0130812195498,81.92545212955648,98.45699683560383,0 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark63(76.93514878935576,-48.02619991204069,73.34526931674682,63.952567760854436,0 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark63(76.98977276344016,-31.90301886777472,-45.91787092011064,-67.97485279699245,0 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark63(76.9936190568904,-27.211328990798563,-9.17747363806268,-22.756221557552664,0 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark63(76.99823123459012,-48.58523917195778,5.208665027247264,-14.33139993273231,0 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark63(77.00624718144093,-16.72548563420216,-5.654988599077939,-69.61837937011215,0 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark63(77.01013627533752,-48.82833110525755,-5.629652437305481,-7.1408356175662675,0 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark63(77.0104623061647,-47.471340121045394,20.69313510292892,66.98671627314096,0 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark63(77.03870339256292,-19.814753076585006,42.0782365593075,61.205392668312754,0 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark63(77.0831451607543,-55.80187101604328,34.96429898799332,28.666223071191325,0 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark63(77.08436667567497,-44.85275399118562,75.61704105195128,32.27236481772039,0 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark63(77.14211643636989,-64.39441799698898,-88.33458819153574,-18.403953526228833,0 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark63(77.16878161686887,-21.94203622487538,24.39968492863555,58.32259948439963,0 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark63(77.1694871881104,-20.446265855735305,99.92417083304875,-34.28987689857989,0 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark63(77.18094960219096,-75.33821399951717,36.38691178010657,-65.25053181750889,0 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark63(77.18936975520606,-31.478753136470218,-32.42719351626617,83.82339135358777,0 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark63(77.19128711478064,-69.80678476208803,-58.55254759979529,-98.21907028902288,0 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark63(77.20378586453572,-40.29493152651933,-58.28566465117648,-49.15843355428227,0 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark63(77.23080704776189,-63.453255739680614,78.34842742548616,-42.24016913197484,0 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark63(77.24712240749659,-43.25305631808782,49.031544806535834,-90.83865747490304,0 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark63(77.25830860782273,-23.222356899622085,-39.53343944741694,-17.743714653486293,0 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark63(77.26654389754245,-28.983052855388095,-77.23123640869346,74.42393371843303,0 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark63(77.27402345093526,-46.68265718909845,99.10503955270175,86.38941566729795,0 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark63(77.3134526684951,-21.707905292650807,-63.552832512984914,-37.793281560829485,0 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark63(77.31844827394988,-14.89025002230153,-54.14895186305741,-47.44983437034618,0 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark63(77.35653099258306,-77.31014806240684,86.1573903456302,-70.57952687653462,0 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark63(77.37894307587356,-25.612269007621364,-60.97598484898914,-64.0774158701312,0 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark63(77.38253243359728,-1.6023888831922477,67.00349996923535,-67.34086129815887,0 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark63(77.39424582086784,-48.6711034419065,-10.897618918426772,60.38382941036528,0 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark63(77.4000245271877,-40.51786535065878,-92.43667234112236,-42.346275201163785,0 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark63(77.44719005133808,-43.19706525969973,-92.42529732100311,21.049782133410105,0 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark63(77.44747013126292,-10.707875006581745,7.266928518895298,-54.72187807313353,0 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark63(77.46896476151363,-40.49856689546709,88.91583368640718,47.258012682204054,0 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark63(77.60294258525062,-17.54989524879946,35.45605291544962,-70.64022187139365,0 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark63(77.60663198299201,-61.00167147570923,51.42546606580271,-96.0291147909932,0 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark63(77.6141049100614,-32.22116839706446,-75.3954047975073,-42.60134290554931,0 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark63(77.62078519416988,-36.20661034165622,12.88552657652518,-91.27921672489927,0 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark63(77.73854114995137,-68.3422808807563,-62.7095633665995,68.75414335211298,0 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark63(77.7410609458095,-21.144031291003373,-17.33328030055101,61.1242516986695,0 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark63(77.74312218363099,-41.928293522801695,-35.69710947966888,34.22447087896495,0 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark63(77.7657324112873,-55.495767201437744,78.39871948275683,63.47000106681537,0 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark63(77.81577431219694,-73.41422154903864,-89.57825485094095,22.00584216906188,0 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark63(77.8318728163398,-44.28746361692251,-28.475639932266745,-53.156248621691304,0 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark63(77.867257823151,-43.69895310280887,-61.96890152391366,-21.167139874529113,0 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark63(77.87421994584304,-16.79353111862794,21.821906668188547,-46.98662308675807,0 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark63(77.90186854523625,-43.89684181147268,-36.70734313326272,-21.054481892950804,0 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark63(77.93186063131722,-14.572401143744827,49.94657953064831,-67.93758605792041,0 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark63(77.96651141851038,-66.43071538788632,-59.15431992376718,88.23905101283492,0 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark63(77.98156992392094,-61.452277860854586,-8.352558529067196,33.66010360682844,0 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark63(77.981684707173,-72.45209569640227,-31.1384886921132,-17.758461200389092,0 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark63(78.01180943375502,-25.487407159808924,-4.554994461344421,78.73239062979539,0 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark63(78.07566977677081,-61.2083686436478,-81.77821283444754,24.590808984518418,0 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark63(78.13692592012413,-69.78490930354964,65.09848763111387,36.67989027050743,0 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark63(78.15253892694406,-18.215223389836638,-68.6556065886057,79.79734983759576,0 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark63(78.16271164850889,-8.996425910855564,-38.591032847947496,93.36315023609038,0 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark63(78.20692915103155,-33.991832205880115,-7.458445640200907,6.746064279088543,0 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark63(78.2219452677748,-7.858660472846154,43.35944813278002,-93.45274419707337,0 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark63(78.23619189181531,-3.5567342642126363,92.15221326072717,8.88054581927733,0 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark63(78.2617646818465,-6.801495118753124,-53.20919994097319,89.98361944734884,0 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark63(78.2791524315742,-6.971978795117835,27.5695878778222,48.759711153048784,0 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark63(78.30963588598308,-57.09722086664646,86.726870214115,-96.09454033892166,0 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark63(78.31091495919506,-4.0333047635938755,21.83336696245688,-13.33240508136808,0 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark63(78.32879143639343,-46.09521482911105,-71.59905963658302,-68.14561426924789,0 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark63(78.33894003949419,-9.454086959321174,7.168048443249276,29.918130001468825,0 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark63(78.35366510492358,-33.9509870343701,-55.74916897755746,22.57591238503464,0 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark63(78.38102330848784,-29.533861352215666,10.041396385126362,98.10838929045474,0 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark63(78.41418714284978,-44.07515923819447,17.021287253468344,43.161770047546014,0 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark63(78.42661298569297,-71.18478006373846,-15.441064013905418,-68.60600930713505,0 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark63(78.44696989802313,-25.469041085940276,-81.49333328975379,4.883472995707862,0 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark63(78.47298892034019,-45.79769896003836,-58.28184066398732,-27.00813536318067,0 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark63(78.47475567947419,-7.881316920570754,-48.11637512669486,-47.95951134934511,0 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark63(78.47480042718081,-33.91166106768402,74.96201303614413,86.53207038617617,0 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark63(78.49026728801107,-64.22883679345735,74.01303449552049,-89.4418891338893,0 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark63(78.50685255127613,-54.594274785486085,-12.053254330844169,37.04600920114714,0 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark63(78.51233442416552,-65.41772758688873,-54.48744855284608,46.94016734672363,0 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark63(78.52449992982514,-36.501197276440365,-6.216384120866735,97.44609315815879,0 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark63(78.56275611640595,-35.922910657526046,-67.8622001973041,-57.325948334402256,0 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark63(78.57787696208177,-15.267215226808545,-83.88491436397206,84.50574130283971,0 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark63(78.59449314374268,-46.98454125609119,-88.95923777444183,-47.92433570433814,0 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark63(78.59965535293455,-15.575193422089527,25.44795169987934,-47.59960216598409,0 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark63(78.61631107570108,-53.75977268549772,-51.8308968608999,40.760340087560564,0 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark63(78.63056299673411,-77.48383254120961,93.23718279881516,-82.60097969893576,0 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark63(78.63340396570263,-56.62766313624188,-4.932304211907137,-12.991195138645395,0 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark63(78.63536831789827,-28.734267494548746,74.97783768364948,-84.83901293919622,0 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark63(78.64994288966415,-49.60916522648277,23.29143110950031,-82.85129081577074,0 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark63(78.67034818541578,-63.71969556159183,-87.23693605086011,-67.90308604524422,0 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark63(78.69094830742793,-72.97945926089886,-9.870884456357686,-55.60185930828092,0 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark63(78.6928098801026,-44.280369317878424,33.553302870645695,-60.31490610098997,0 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark63(78.69859630794954,-57.73001635057808,-21.09185860356139,24.735118610616055,0 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark63(78.70250683751635,-14.866711417363206,-32.99261726039846,-87.44419632103653,0 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark63(7.870279657145616,-6.541609395670591,51.41109900601879,80.80862211319396,0 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark63(78.70280567886121,-27.14817068593578,78.21598137764556,51.4727786405785,0 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark63(78.72513728159348,-67.56722516168037,29.615747556373805,69.78157557137564,0 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark63(78.72953226605702,-70.96060579011849,-15.201024100146228,-83.6679214089604,0 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark63(78.77497200104455,-30.47191305882697,-46.78430695368594,45.008637094053284,0 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark63(78.78375893137974,-43.387765392215314,-49.81971451288349,3.7589271737925856,0 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark63(78.85076487940131,-51.50171046264123,-97.68822787935218,-55.673281055193115,0 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark63(78.88158529720513,-67.1085373971153,30.42745355398435,-79.47411104750299,0 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark63(78.88814365824061,-47.59317413580997,82.81392639663653,-65.92518423293924,0 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark63(78.96274365056377,-5.090902064222249,97.25347919806342,79.4215345845746,0 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark63(78.9640268287178,-29.87135358126669,-56.492224876632726,30.493898170326986,0 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark63(78.96667113766554,-54.99840524117814,25.010463541149747,-99.91788796448631,0 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark63(78.99159970275608,-56.12087163682573,8.95373517764395,-17.175924632214645,0 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark63(78.99203570877546,-74.53379110753451,22.124029597907253,6.994672421035574,0 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark63(79.00482477681848,-58.6570334472271,-1.7591927105309964,-43.407801830073936,0 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark63(79.00824915343276,-48.33654533575906,-18.452564061404118,-33.76665938435714,0 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark63(79.01248285750574,-42.1559214704049,-42.56463904653416,-5.8474146032977785,0 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark63(79.01449497079466,-67.76581472086457,-60.83906569896549,-85.23870846255221,0 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark63(79.01455063700149,-64.19772677055121,-85.32700076235606,-74.4059415312368,0 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark63(79.02072610468701,-6.598599445201685,-14.562325701746602,-92.93335675271803,0 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark63(79.03816342061697,-54.24134731430665,-74.4015602521237,11.568938294567403,0 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark63(79.1044343474554,-67.0396180178328,27.918206058533485,-12.807212645262297,0 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark63(79.1065534423484,-3.6178125219440176,-18.846257667759602,39.77156705301738,0 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark63(79.12838118932711,-14.585856719704339,92.78753513879559,4.785800373341331,0 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark63(79.17254153807144,-11.974839863699088,90.40564462409577,62.41875149710273,0 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark63(79.23837778204526,-57.59840220982599,98.4175891723118,64.80034811911054,0 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark63(79.24637881881188,-20.602949451964207,61.52315283203461,6.835757787103617,0 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark63(79.25253002722727,-61.06069240062975,95.22933864721986,-11.012151132270787,0 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark63(79.2811445649975,-19.986174117260006,24.56592111660825,-51.158457265207424,0 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark63(79.30231131867251,-81.82262934996463,-91.3550622902419,28.81988648679601,0 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark63(79.30835247365852,-32.554304043548754,-60.89807207552693,-99.07055264667865,0 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark63(79.32018984509813,-75.70483650996276,-94.24771256285021,-38.19295196546415,0 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark63(79.38613110177576,-2.052911691643928,29.546698519128825,94.58126295755389,0 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark63(79.40346359530369,-19.018519152602778,82.77354771068616,-25.644798101479125,0 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark63(79.40559739665593,-76.26810800019933,-82.92712669208389,-55.05944485849545,0 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark63(79.40658153276965,-27.063069219503873,17.764622892835646,-45.13330688807267,0 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark63(79.41890151814744,-32.04599801180581,-48.7484586355752,75.04508964450162,0 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark63(79.42599556028011,-53.651601463046106,23.89727906256867,66.45168114186149,0 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark63(79.44043759803347,-20.577196390190593,74.75362750743798,-33.45878998242439,0 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark63(79.49221803878808,-13.591559960690233,25.344955745571767,-1.5814168456075066,0 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark63(79.52019092686834,-53.99136431105613,96.15522090768158,30.615130964938828,0 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark63(79.54474060436644,-50.24312140607381,51.92856393909392,77.66889830197127,0 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark63(79.59082750368685,-7.758284816065327,45.67636567985758,33.701290272404606,0 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark63(79.61453520284763,-48.91577227252317,-27.45201947694609,96.21535774319727,0 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark63(79.74080912302895,-15.589865940638134,-46.000713486945564,-79.5400806695454,0 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark63(79.82440738346409,-29.327993957360434,-86.58079529975673,-27.74167810948896,0 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark63(79.84475496280714,-77.78920417391382,64.21376784920085,-82.67797154380861,0 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark63(79.85717715947874,-50.12243384106918,45.28017802479661,-26.870139299687025,0 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark63(79.86682285565357,-62.87679626145084,-47.20362479496896,46.00311504468891,0 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark63(79.88935638080841,-0.8825805249556424,64.53401157591009,-99.66836381102593,0 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark63(79.9021559252763,-78.30077379954548,12.6773295986998,82.97318246888057,0 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark63(79.9098295307306,-38.55628960702728,-8.40059380048757,21.630273726451946,0 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark63(79.91189553943764,-61.34558706630027,85.2709247583011,69.0955079655748,0 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark63(79.95782956512735,-13.389899126618474,49.87307948427909,-54.928646326196564,0 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark63(79.95916698458856,-1.2913081639049437,80.37856536081259,-92.2716299980625,0 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark63(79.96201440221603,-36.70295166686009,88.68479536813223,19.61411387943197,0 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark63(79.99112550626882,-5.586220156167627,56.792571095706194,19.947526860952763,0 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark63(79.99156459551327,-40.65775841777908,-66.42843293105574,-46.091905652809494,0 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark63(80.0674530920781,-57.74665621916915,-88.82775818707754,11.061071245957095,0 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark63(80.07776636668862,-31.402480204369084,-94.91746482884176,-87.1903600571071,0 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark63(80.1174441263397,-48.66511196645915,-58.783300663093584,79.52003360481962,0 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark63(80.1210228362626,-14.939667762626314,89.25659205822078,-69.29822269660512,0 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark63(80.12135205730081,-19.42113989144532,3.3094896386595565,-80.46312263508815,0 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark63(80.12824551948427,-71.48991325895908,15.192762230516493,86.59481569155471,0 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark63(80.15353116900553,-27.45679896974869,-67.64196749128801,10.128575494606821,0 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark63(80.1555998485932,-67.41209419296395,27.09821068451457,12.973218622878562,0 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark63(80.17856367348907,-73.66799245007012,28.463016973857236,99.22778763868772,0 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark63(80.18511321501686,-9.527630565098207,-63.35894760019514,-98.80241433226233,0 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark63(80.20190995160738,-77.74456403402345,63.64001430048742,-77.65528218944795,0 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark63(80.28047933543883,-38.33245253888804,-44.80382922393724,-83.3006466698051,0 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark63(80.28447650660087,-66.90752364626482,-59.225477284634785,2.171754981416967,0 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark63(80.29088301487809,-33.4056996450786,83.26091083390591,-94.40848496540566,0 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark63(80.31354999813075,-26.50289898653864,-11.824891970193477,-12.844097912341695,0 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark63(80.36560428046039,-80.06464254196979,56.66972868452214,-10.943217356914772,0 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark63(80.38162908518325,-58.28525662528068,92.01015740362897,54.85296142100427,0 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark63(80.39309836498123,-32.35479118905609,-80.6123134883846,52.49486889530252,0 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark63(80.42353191960353,-27.13507914568835,50.07117841852042,-54.52964252934655,0 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark63(80.4487990950982,-33.23160115276322,73.97501764175826,83.84797429150117,0 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark63(80.45164851125847,-9.490175725846896,-67.71344982626842,-96.77497365521191,0 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark63(80.45368611159489,-9.84109738897449,88.33036427389263,-19.26620498323453,0 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark63(80.46895100061832,-59.849276934770955,-53.46324564860767,68.70590711736983,0 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark63(80.51361245203447,-51.91507112333578,77.8001921445354,75.1668230963221,0 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark63(80.53581843291394,-75.16974957269792,73.3765585091725,-48.28083123854623,0 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark63(80.5444773139888,-23.221655088443782,93.42840669674496,50.38419691942261,0 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark63(80.58728411648727,-45.58197336876801,25.684734099975913,-79.9315095799485,0 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark63(80.6242114888407,-14.997290961872054,74.3545642496722,49.70528946497424,0 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark63(80.62942971565542,-43.93210476915199,24.872376858672055,78.41255405742163,0 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark63(80.63477811836862,-71.1142015554278,-66.63439641366031,-98.07407482697359,0 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark63(80.65736402875137,-67.42332262724668,62.14099576659419,23.573808787272796,0 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark63(80.68861726137698,-78.76332139556577,-62.304487688074886,17.77555477818757,0 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark63(80.69296105910493,-80.14492765619923,-34.48608964746815,44.59869023235618,0 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark63(80.70623181338237,-55.9784048571438,-19.782382443720792,19.086328169221446,0 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark63(80.73424237285104,-48.86174648190897,-77.29651731328384,76.93380294643154,0 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark63(80.74748245902049,-50.407381847335905,86.3583444560401,-62.61551849059528,0 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark63(8.077063391446899,-3.4712040025497686,84.34208170050627,19.804805344252287,0 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark63(80.77629413908508,-54.29322030256765,-74.76931414090593,-14.97205190240021,0 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark63(80.8217496717451,-79.70810923036831,65.26679707285263,92.80182800202354,0 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark63(80.82692185499008,-49.81309368798601,55.838323491352156,-2.3297581939172716,0 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark63(80.82767110733627,-10.223358529788285,31.331634212706064,33.576796301618884,0 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark63(80.83873038654573,-5.640987018082356,15.589472790788463,37.39498054587534,0 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark63(80.84077629985441,-10.279811528600362,50.485643080306204,96.40949427512643,0 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark63(80.85142314128197,-71.26722963556509,6.304823077261034,-57.856030731338,0 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark63(80.8594613414538,-16.32411033147349,53.11150953491085,-74.98785870861866,0 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark63(80.87304695316908,-43.585087258305236,-77.23900488063569,-85.04428361015626,0 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark63(80.94189383478039,-64.35409174062126,35.46922716983457,39.756985753605534,0 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark63(80.98384491135042,-75.8219129179339,-5.757082185947908,96.7319432306214,0 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark63(80.9840469500939,-60.13721852476168,-17.836782822509463,69.18319030765738,0 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark63(81.02822918938182,-51.1663820796445,-7.120731998321659,-43.457167447245396,0 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark63(81.0521547875419,-28.52759787095873,-10.903977527969502,-93.26086172771578,0 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark63(81.06338220513422,-64.09000261488593,8.046639030738419,-94.23171993872384,0 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark63(81.1344184165882,-71.11053814366923,-51.14961620919185,94.1880188698668,0 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark63(81.17021545962692,-57.20220354396124,-29.333997615572585,-99.76890487243554,0 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark63(81.18470565544558,-27.65056094131819,-10.24255288727909,64.92529757939448,0 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark63(81.18626612003371,-19.116909860404036,33.69493445324429,99.80873371240972,0 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark63(81.2005165360622,-55.63426401113401,62.02296665110538,-7.5011243928857,0 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark63(81.27591900212443,-71.24005864367436,64.79662511095054,-19.15936620287924,0 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark63(81.28783467673799,-28.856456477461705,-49.39072153834052,47.69669773867113,0 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark63(81.29112431695836,-42.907656583569405,14.793867290621975,-53.029684453431436,0 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark63(81.32687003817384,-65.3279970829708,45.675561094175265,67.06441456672329,0 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark63(81.3370312308667,-18.051808712449542,-84.50066820280632,-60.456097030869046,0 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark63(81.34477265102737,-9.656878573535295,81.55287429425411,-1.6569528248172816,0 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark63(81.3830701276566,-34.988976234051975,8.695189193325035,-68.71988791090268,0 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark63(81.39938248455522,-14.349342976661617,-57.746228223872606,73.64604631773659,0 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark63(81.40348367584892,-39.14456227231498,-40.82863026817658,37.561763735778214,0 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark63(81.4244720777493,-79.5444022918391,83.02680770832927,-36.38390770554034,0 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark63(81.4285936926035,-67.39157206525027,-47.838493572700024,-31.930539493623613,0 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark63(81.44230763356214,-37.637757588328455,2.7599890360773003,-57.29642251353686,0 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark63(81.46827784007209,-53.38618477321697,-30.135166763175732,9.567499922595758,0 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark63(81.5211461070511,-12.814874542360073,-9.940813076856998,38.10861837983671,0 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark63(81.60483279645854,-78.51685290711737,-48.60321290001299,31.40969537651256,0 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark63(81.6058349811203,-31.072347498558585,40.76568053511966,-42.033631767416125,0 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark63(81.6129062295673,-65.36446998687728,-9.184843952323106,78.57034164640487,0 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark63(81.6559979746489,-20.279830793003,18.99566169026508,-16.005566248046037,0 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark63(81.6824243929417,-26.794223240915315,-43.981049130170625,-87.5600262541266,0 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark63(81.6914146350336,-22.884788285430034,-0.5168621279796071,-14.733714168588435,0 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark63(81.6919501029814,-75.9493171333238,9.867852688531073,60.66687242457601,0 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark63(8.169607535574585,-0.3408781821013065,90.53899717556291,25.551266530443087,0 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark63(81.70525161988064,-41.95172255935573,35.79219483641617,-18.724634003463578,0 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark63(81.74104737178959,-10.878601987673235,-36.39955611174002,-68.71036271951816,0 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark63(81.77841264599135,-54.45604903257786,-38.07200190989608,90.5760424229251,0 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark63(81.86044395534063,-61.80108301260463,45.64760056542937,-82.81526127638907,0 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark63(81.8922343145079,-31.8593605057966,-99.94095854810013,47.20573997877503,0 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark63(81.90726471009185,-68.76735130672627,68.63671796553072,25.414209314526232,0 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark63(81.91552493335004,-34.476494662951396,-88.92107457063516,-32.22944045527112,0 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark63(81.929654847395,-67.63128622843723,-49.31560303270275,80.62670551539193,0 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark63(81.93852451682307,-0.40735289732216984,11.486927134297147,-13.04064630866317,0 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark63(82.02260109257304,-64.674882775654,-34.04605233309526,6.744477259651731,0 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark63(82.03953782319405,-18.93892252354084,30.08668765091349,65.39293875564874,0 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark63(82.06651889884654,-13.425818992025796,-86.54124357796194,98.43155437227179,0 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark63(82.08146431711464,-55.703197695437744,77.6424329500986,26.765209009484508,0 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark63(82.08486215902815,-32.61738329988455,70.93177945345818,92.3575843414593,0 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark63(82.09880309049703,-19.201951551944504,74.39127737632182,76.03864704366177,0 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark63(82.10180324820172,-50.66366675685112,27.283668031641355,-67.3672449287065,0 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark63(82.17043684512458,-82.74958415580758,86.67867201549728,-38.712903606862305,0 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark63(82.18790343667601,-24.375537547736002,59.00599881147798,51.66907456026135,0 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark63(82.25490199449254,-20.252623356584508,-45.455195967949756,-75.50146892592821,0 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark63(82.26789438855687,-68.48724977029067,2.533115178562781,-25.306688165394746,0 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark63(82.28133258422613,-78.15457690207519,-31.01974823157434,17.5325960707942,0 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark63(82.32923372006147,-21.1119415929911,38.68414725491354,80.52931354341305,0 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark63(82.33866271152382,-52.151255606367556,96.24916497355724,-48.01063865146262,0 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark63(82.3495457092362,-12.78879600860516,23.62490313941015,-0.18976542066080526,0 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark63(82.39059376604905,-56.89766595483887,38.514000042051066,-84.62102428885365,0 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark63(82.4058698448577,-79.44780997937997,52.97886173374201,-61.30126711923383,0 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark63(82.4297068432601,-75.7578096722423,2.2089385024272445,41.91404231116388,0 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark63(82.44383826454907,-25.91836316743077,76.84979859357927,55.82661121760927,0 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark63(82.48540777451657,-52.20898086951815,41.057262561048674,-12.938634940613468,0 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark63(82.49321386436586,-78.3548437015169,43.22968415827293,70.38236974684605,0 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark63(82.51146357346187,-42.57305902250885,94.68478940682084,-82.03378958657822,0 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark63(82.51698153123232,-42.0907508816478,16.85362570235452,34.196581659875164,0 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark63(82.51854539554847,-69.09149425993728,-1.2778763230571855,-4.678854589729454,0 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark63(82.5380520539673,-73.66378728542537,77.01595971475297,24.303117354785314,0 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark63(82.54057344436018,-58.13863621494082,-37.00951770917173,75.81962422075748,0 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark63(82.54342444605518,-38.91820027969934,-13.131055277267635,31.13392840993427,0 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark63(82.55926906034392,-52.08342706031157,-81.88465540045686,43.01835627830252,0 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark63(82.592812926671,-38.85294576564804,-19.572583586290776,67.37015476822842,0 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark63(82.61335820190669,-26.61822916963554,62.064286704173156,-92.81738111127997,0 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark63(82.6197352672641,-32.42134338304645,39.78556243198821,15.093888034145508,0 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark63(82.63995919475173,-80.23999958371127,-28.572913563715645,38.377108170453255,0 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark63(82.64693358412285,-10.74815014530219,64.32315944590763,93.04965782672946,0 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark63(82.65209420662549,-10.579440480013645,11.818697634089403,20.88879999708122,0 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark63(82.67545122237595,-48.971476682966816,-58.621189865681124,-83.25959585350198,0 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark63(82.6815922342212,-26.465328821271243,-23.263808311454184,-65.72969251540832,0 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark63(82.71798117799253,-41.8249473110625,-2.1575149322472953,-43.516537587561,0 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark63(8.277552061682925,-9.08722701120577,61.862966655105055,-46.287705567257944,0 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark63(82.82257829065526,-5.116360197899866,20.429463779769947,43.43138660818437,0 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark63(82.84321164264853,-80.85455672699982,-52.80959637492722,7.910964190192374,0 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark63(82.8518722638664,-80.18889697789709,80.04763290478968,-79.96743049698637,0 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark63(82.86006371086202,-13.485595688762103,-63.20087138594528,-40.681073160649575,0 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark63(82.88749738655468,-46.87972422752766,68.73157252918753,36.823571474980184,0 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark63(82.88807905331507,-24.05493636148657,6.30778222221015,-5.873663913797515,0 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark63(82.95552041472305,-65.1286250100381,-9.915633756723551,-86.50131288799786,0 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark63(82.95937833192966,-9.832097233095155,8.90652536184362,-11.033952976279778,0 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark63(82.97343315414588,-26.45881377300637,51.35718092787266,54.44627269960671,0 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark63(82.99447437639034,-19.393144442133178,-73.80818914104657,86.60892300975627,0 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark63(83.00931496314547,-51.248212031260486,12.61052056668413,-42.79826814536083,0 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark63(83.0173325353708,-33.94127393619446,79.62894390441241,21.783337609030085,0 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark63(83.03234945355385,-76.60510462936179,26.831129930263458,19.80617398609195,0 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark63(83.03330773669512,-67.4720024284873,-85.4324651784721,40.84198024336976,0 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark63(83.08659137400446,-40.845170221506976,65.70202091066824,29.762285513816806,0 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark63(83.09913187474646,-65.17973128613272,23.87774595556094,46.83835541163421,0 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark63(83.12693692017231,-58.84835408251996,61.75264514473153,27.26926556827449,0 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark63(83.14580044566426,-15.074924305450395,-71.49863535756162,70.98113167617879,0 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark63(83.16895828004493,-46.95362203439202,-49.432662014539815,47.321050625380934,0 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark63(83.2085024976455,-20.795999453736428,69.96190738599711,96.26862102501096,0 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark63(83.28626524039052,-3.6575527854050875,45.304169183304765,43.45213544777931,0 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark63(83.29207909717883,-45.42113279934878,90.37009482597682,-93.27493421085171,0 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark63(83.29633779998105,-4.111014594098705,-12.057613203011996,94.60354054669688,0 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark63(83.3007247759783,-41.99408997469312,56.9216119816634,25.213017027902637,0 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark63(83.32208859840313,-71.63028911531603,23.418623459357207,-81.47845632924731,0 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark63(83.33537105084272,-37.98077075049579,-24.84800803742742,-83.38999672609206,0 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark63(83.35126891370507,-19.662283583359425,-73.50054681528708,72.66397739815449,0 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark63(83.35391109718591,-38.70599692170869,-3.3841663446499695,-95.51838437905866,0 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark63(83.36545180201307,-3.218067722959276,45.588265043773504,-68.28569370877106,0 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark63(83.3764280563039,-29.026965084599453,15.949072758623245,-79.86302579989078,0 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark63(83.40921081754894,-32.34047122578947,-56.11378901341937,88.96645638788786,0 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark63(83.43688030061972,-61.40155420288331,-33.38352052022398,58.58717209934264,0 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark63(83.44969848127363,-7.766874108474099,17.11108472456185,-24.72849646988942,0 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark63(83.46510046501626,-20.405073703522277,62.37728208642818,-7.515700996371095,0 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark63(83.52151009648964,-72.15029655290317,8.270482866912147,-90.71401228654601,0 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark63(83.52982013774147,-34.32576522209881,46.04911385387342,28.681018595034914,0 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark63(83.53099007193836,-51.91850973427885,29.507215196446623,-78.06098969334268,0 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark63(83.58059939962405,-73.07747817159833,76.00953940171834,-81.98716814493794,0 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark63(83.61919395902146,-35.011926658977075,28.623095431999843,-51.953311799645086,0 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark63(83.62463328913236,-23.88455978736779,-19.557995050608028,-44.61118891876992,0 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark63(83.6338168511439,-14.178994150155532,-10.7413615015044,-51.74784798786531,0 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark63(83.63731502016049,-22.20630539487499,7.07732939317647,-71.04888062572199,0 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark63(83.64148686557002,-75.65954771609981,95.69024061775204,97.34011639089417,0 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark63(83.76192848756833,-18.12624727691761,63.71334728140857,42.171176265722124,0 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark63(83.81616516611942,-48.5691766093689,-80.30454843899521,-55.254412607691236,0 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark63(83.83717690014595,-74.07967802225286,-22.848862151788225,-74.948432652349,0 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark63(83.87591644760045,-33.03306032679309,-40.6991471965292,26.68485387616215,0 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark63(83.89112221869189,-27.63816939653448,63.085778765802246,82.27634922089081,0 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark63(83.9104056258384,-21.81240406746865,67.03477010691083,-27.329972766258592,0 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark63(83.91189569912888,-56.00824486559124,-91.50774968054711,52.88967494361302,0 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark63(83.91742522650688,-67.41454464528746,21.78702372802674,40.342208689639534,0 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark63(83.93776483642131,-72.92304328754739,51.15621095998563,-7.275705713468199,0 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark63(83.94072804746199,-63.61795047194501,-46.907753821619465,-40.575595582156375,0 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark63(83.95581169477657,-33.47231844020946,-7.210421212220794,23.527602325640814,0 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark63(83.97132450091834,-76.46628054459714,-86.59004271370854,-42.195199613348656,0 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark63(83.9923510484293,-1.0132008446154543,63.89126025271872,56.24795571827693,0 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark63(83.99416438348933,-72.47998447842281,2.984404927507839,68.58020987925806,0 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark63(83.99460793012184,-78.44602808567767,-61.01542710470724,-16.97975921285051,0 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark63(84.02416909272316,-73.2486514895635,-6.866924175316797,29.556052832829153,0 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark63(84.04501197390482,-22.85599231874467,49.80785645787924,52.21864617070952,0 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark63(84.04741217034245,-66.0950193976862,48.63319654798042,-5.431481176033998,0 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark63(84.05097772823868,-18.69247999838784,13.50505451978377,-7.1146929053966375,0 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark63(84.052136167274,-27.56724053149904,-27.90329214381906,4.528463300853474,0 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark63(84.07632531441183,-60.47804833274555,-27.38141245996073,16.648411833541417,0 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark63(84.14532456351893,-31.220620222873706,44.525014234211994,-30.869664137308604,0 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark63(84.18212050146917,-22.57060100299438,-49.77284099170649,-14.946556724176261,0 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark63(84.20500640780224,-57.38213244025454,-95.14796369500198,83.03786800155717,0 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark63(84.21075843980685,-17.284492787604194,-31.605848972062915,28.518279648488658,0 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark63(84.21645078976024,-53.63508637250129,-57.442309037781136,-34.54510280919669,0 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark63(84.21647595128505,-69.69421524732462,-48.970133853763144,-47.429733460090226,0 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark63(84.22140070124118,-25.499333858952824,-71.93763775934592,-11.336793569190291,0 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark63(84.24780853466643,-35.52951851273416,54.84917498660812,96.2296698194389,0 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark63(84.25282785592356,-4.230779975430863,48.73358322318771,-80.70527178126447,0 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark63(84.25577681894126,-57.434746069071,61.4345760228874,46.827008652784855,0 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark63(84.28189273201093,-77.56410635893863,-5.10119575629065,-98.44492236350078,0 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark63(84.28414199682985,-72.74088708338063,-42.34543450707415,10.202543157597702,0 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark63(84.3222958623551,-59.56733681305049,-58.749672312585744,54.39264240933147,0 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark63(84.33639327573727,-35.52930267328898,-46.709760385155484,37.46406815929106,0 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark63(84.34460073233234,-45.63108225161863,-24.933989895606757,-51.88329871502564,0 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark63(84.37358627205879,-24.220210227018256,-87.69289518649313,14.241181894747257,0 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark63(84.38136056945493,-39.73628056967004,-23.41733324812587,33.59045159172908,0 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark63(84.38841098067164,-75.82408670085917,59.32715150742649,30.436260487329264,0 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark63(84.39813138663962,-41.369029362228375,72.64364434551538,14.888177803625055,0 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark63(84.40134856249432,-7.746706305076188,17.759248318921394,73.56019453102132,0 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark63(84.40505946142983,-11.70732075310606,95.78416665127924,-92.33766537044971,0 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark63(8.442623545150823,-0.8463989726857903,25.792292942266414,49.48899716719589,0 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark63(84.44942896534377,-65.28051419435057,86.57038811257885,31.592185952919152,0 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark63(84.46895323174115,-21.335134019479128,-35.78246493849126,93.78555249451301,0 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark63(84.4939378714167,-60.08801210530778,-2.750382867543564,1.1263176447555878,0 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark63(84.50190415589108,-47.69421439703605,50.28692067917703,-46.448832031244145,0 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark63(84.5068643703251,-42.49272721679653,-99.5347740379714,71.33626844131692,0 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark63(84.53823401582028,-54.13308771267342,46.69420141787592,52.02987197321184,0 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark63(84.54329297622559,-73.11392486359365,-67.26514760687148,-58.323894745779285,0 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark63(84.55843711833637,-21.930063597466827,-65.34517641531663,-8.603608790635747,0 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark63(84.56426521693285,-2.27259209831044,40.89630667886365,84.93654722525491,0 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark63(84.57363466188133,-76.93776963286618,-80.99724610471665,-16.187415344873557,0 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark63(84.59287502954439,-4.00828920577348,-20.091997665055473,-96.8416110987017,0 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark63(84.66545819883862,-55.34150784111675,-18.466195303902253,84.63797803917566,0 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark63(84.67849767045678,-31.095935716790166,32.166676325338926,-72.80499587958668,0 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark63(84.6812755642114,-70.09940823076282,77.2609114751846,82.18831938557895,0 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark63(84.70465335684213,-63.73687517582531,5.276521703436913,-5.9680115907227105,0 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark63(84.7196508066925,-57.144131138636254,76.57144288586579,-22.415801626892474,0 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark63(84.7634633377383,-68.78994847851217,-59.115426963704195,-70.740935118806,0 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark63(84.77486978652769,-26.43588212896826,-36.01979281006218,-69.1652209207722,0 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark63(84.79291016993528,-64.18016201577288,-79.67235730844202,-28.73499610837402,0 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark63(84.8307469439543,-31.11611858195822,33.412931173741924,-18.674239295733514,0 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark63(84.85976206624039,-29.217913558261614,23.76504772230794,-1.2260892190165436,0 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark63(84.86044280162417,-84.93187410566551,38.639614172681206,-82.35228014720654,0 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark63(84.89729021597435,-74.01235043069174,-67.63405468879473,22.264944813875175,0 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark63(84.91260780418801,-8.902589246022785,48.92067719545915,-33.45045713428743,0 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark63(84.91839892192209,-51.584458990169104,-17.935468423302623,67.02305374375436,0 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark63(84.92747013197527,-46.72104464409232,-97.70807955585745,-51.51140212179257,0 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark63(84.93558387351078,-56.635989502900784,54.15253404120082,80.50755757246458,0 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark63(84.94640204731172,-26.175054380028143,-56.303855662095174,30.801565949535245,0 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark63(84.99219692223704,-43.03294614778934,31.045363324958032,20.236637625447855,0 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark63(84.9936623349223,-23.294997156481884,6.894363499589701,19.111189245917416,0 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark63(85.00276491287289,-27.01619864615172,-15.915576466346863,-45.69845067619171,0 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark63(85.00542482527223,-21.649645436034575,16.194136142059108,24.245906017806632,0 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark63(85.01150040062794,-20.81283006589514,31.21295237276837,-88.64640528350839,0 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark63(85.01522076679888,-30.309287548528843,52.7159207541757,66.61871792520424,0 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark63(85.050717271893,-27.28509607850181,-83.16646938121839,34.3642698720399,0 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark63(85.10504528125608,-16.206651556531256,90.28136629699398,91.57347062654878,0 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark63(85.12434859484702,-57.80535842898353,86.80251183570022,-37.040588835512,0 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark63(85.13356804540265,-53.60907481255106,42.18795062798185,27.555894959781455,0 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark63(85.18804703369,-28.610066741977832,12.003241412277333,-17.503073937478632,0 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark63(85.20750359795932,-80.75067652954749,61.03746032976977,74.08905397735376,0 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark63(85.24434988330006,-66.90839514279429,32.37128856808272,-60.71755212528376,0 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark63(85.25128808372224,-24.21412841728774,-63.026201726304244,32.839336874945985,0 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark63(85.26779454092585,-28.285939269282736,19.395929471960912,-46.31401029679629,0 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark63(85.2718629116037,-72.65766162419192,23.6133708643421,-74.30875377763317,0 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark63(85.27623288074122,-13.896088836272398,-47.563286311071565,78.4088931373044,0 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark63(85.30203650884499,-55.26918363477022,-73.15780453779017,-29.50468435636482,0 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark63(85.33793588598331,-59.678416204840204,-54.29228427155566,6.098403961129506,0 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark63(85.37084975596031,-26.44245919996355,-10.018639810325823,24.111841715708564,0 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark63(85.37455152751488,-74.87267084699482,-74.5423348397849,32.871021216420985,0 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark63(85.41167867675534,-84.27508328822317,17.941756131191468,-51.26373429120819,0 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark63(85.41733006023483,-81.07959513218405,-96.36714270346675,-84.299227922895,0 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark63(85.48227516013262,-72.28259617888537,-83.56391279334059,-65.52441165842075,0 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark63(85.48907202350034,-13.200432506177833,-25.51844008690891,63.82938312249888,0 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark63(85.50538693649244,-34.18176062555915,-65.80308418620132,80.57492563261013,0 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark63(85.51053520985852,-10.36787432298918,33.368610900179874,-93.50354416770492,0 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark63(85.51058584411527,-20.38693807324428,-69.52572483810718,-8.477092550054735,0 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark63(85.5154906759413,-64.74439924447219,-39.72455596608518,13.900278915591002,0 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark63(85.54194467674313,-7.777640634179022,-45.78459847858791,12.56165755355731,0 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark63(85.5464553642569,-76.5739565204633,-0.22785468533514575,4.84885984623746,0 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark63(85.55565038630189,-50.39072337733788,-44.36591950555871,73.03517472007172,0 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark63(85.5613105470268,-20.266379913563142,-1.4952879521751754,34.65049376497831,0 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark63(85.58574998784368,-32.722835391810975,85.66420491257529,60.122391681312024,0 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark63(85.59053237101949,-65.2059865288081,66.99033217777216,-72.00779699031885,0 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark63(85.60493807522434,-59.99167079196091,-27.92288709871444,-12.22996289852047,0 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark63(85.60581732890995,-61.215904833953914,51.40710003937477,-50.29563509638126,0 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark63(85.65986258391604,-2.954653117171219,75.06755033048321,-91.40849793289696,0 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark63(85.66170309956891,-35.1255015896577,-93.36440975659974,-45.96523142850897,0 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark63(85.69081071258921,-42.370618566953745,-49.52341523796986,91.3283427121273,0 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark63(85.741671852564,-71.08912752722934,67.47453232658174,55.68237248795589,0 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark63(85.77754949467538,-17.232056059071326,-40.9919162519953,10.447089907996656,0 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark63(85.78445068020352,-0.6360793988955606,16.46528596895665,37.01123250348917,0 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark63(85.79655575290104,-34.66501228246209,26.321992575089695,18.110068868694356,0 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark63(85.83560512164087,-69.27125164185979,85.06926582346972,88.05685889232925,0 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark63(85.86581232867948,-36.589332787403265,-34.07899181046699,14.110537022814441,0 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark63(85.86891353146214,-25.61406225590173,43.21459570991357,-50.56054545781612,0 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark63(85.93456705321498,-47.955525126526965,-32.6186083407527,-21.941577874551086,0 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark63(85.95370951309053,-34.641340118013275,43.328528487135344,-90.5813435583368,0 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark63(85.95721262804807,-39.11092779741803,81.2121651328055,4.422548859232037,0 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark63(85.98257055349484,-28.888172631477048,38.82221141283958,29.270798984245772,0 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark63(86.0029602345015,-37.87149094931719,75.51703288444952,-78.38349806664462,0 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark63(86.07283914756479,-41.66513724996275,66.99716288707899,-62.60738266645616,0 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark63(86.11119786354081,-49.07179530918868,96.50813695856218,32.2634536743856,0 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark63(86.16848659496995,-10.606898231817638,-58.71143830351011,-67.1260807505893,0 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark63(86.18612619639916,-31.47846375814818,-4.588836266060994,-34.39434458707342,0 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark63(86.19655170938032,-1.9957062210142595,69.65166739810277,-93.93186085313879,0 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark63(86.24124252784728,-56.593899494652256,79.61705897673679,35.87557833321006,0 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark63(86.24850074435417,-53.571207427283674,-86.72105123550054,68.19159270513501,0 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark63(86.25234959102877,-3.594936391560097,40.39901127367324,-73.22499801186572,0 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark63(86.26842894922831,-32.237166855986544,-97.40566691641905,-11.969648897488256,0 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark63(86.26928529332801,-38.30458490616362,-60.02145886793837,88.81116643355242,0 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark63(86.2781732816758,-9.831307416803341,-76.11803838985121,72.86660713201263,0 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark63(86.27867556549432,-42.459277777941764,-65.35266301080614,16.439779043177083,0 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark63(86.31952745453188,-86.36390652965468,99.60890228632212,-71.11741685217791,0 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark63(86.3363686660401,-22.653232127273697,91.01038636869342,-27.101901372094943,0 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark63(86.35868609591162,-62.721148682850504,-34.42748579472905,-78.5940294998548,0 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark63(86.39747397251526,-66.02196029914668,-33.508948656453,79.7586743357055,0 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark63(86.45810065739656,-16.05434606461212,-73.06435309999013,-16.254347760171555,0 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark63(86.46597420894463,-11.511012249466049,-86.50119297773209,80.02114723312215,0 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark63(86.47960453160053,-72.66803754296217,83.86348964057879,-39.20150059871199,0 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark63(86.49782128837288,-48.82116232818534,-68.35386153127266,27.31206703955054,0 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark63(86.50157953016364,-48.226268303699115,69.64496077925148,-27.504605834249944,0 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark63(86.51326965096294,-14.825369422300483,-54.8458288732232,-6.555567346491856,0 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark63(86.52373173725348,-31.17580923472434,92.74490106618086,-32.25251684478869,0 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark63(86.54443632638836,-45.5862114682867,66.12137701003425,-66.73754243612814,0 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark63(86.5616953191911,-49.20426445729855,-1.682469281482497,21.72058069577723,0 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark63(86.5689556093341,-22.252101204580526,40.11096576486466,23.28124731308472,0 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark63(86.58207504716447,-60.35528821200351,-48.03181549039059,44.530817146825456,0 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark63(86.61437370569368,-12.253435035926799,-4.591349714544776,42.9470681285417,0 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark63(86.6196435843743,-36.868853584158586,47.794901395454474,-44.781018034284315,0 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark63(86.66229174523411,-1.5468279669839262,47.65569206462027,16.845431919457425,0 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark63(86.66915051244032,-47.895206184956464,-63.843218263708536,-71.99555404059508,0 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark63(86.67678204639063,-25.24035586845001,25.89127840027841,-15.943614330681854,0 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark63(86.73482573317875,-58.738283741753115,49.066572638668305,42.09497625088218,0 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark63(86.76100006626234,-22.663557061040976,25.319581249204035,84.64851584251159,0 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark63(86.77721884801088,-42.87745092421913,21.628959688513433,-40.123608205592,0 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark63(86.77734388355339,-7.066812506584014,85.84071709780628,-34.43522287283032,0 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark63(86.78480218069598,-70.62621934985458,95.58439321948543,-6.69115154184945,0 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark63(86.84098253912126,-58.78361539857595,90.05379968195527,3.8358569676590406,0 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark63(86.85291811775448,-53.117568609000855,-56.41720719324594,-86.68234154374173,0 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark63(86.85915333749284,-67.8935054072488,82.23439687972427,54.97215402045873,0 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark63(86.861538114218,-86.14560972600687,-77.74877341572648,87.26310808482302,0 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark63(86.87627540844741,-22.63350651312362,1.3348965420427135,-50.73526090399023,0 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark63(86.88712424741925,-51.583359400175866,22.775206406896544,-96.03773301078174,0 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark63(86.91034193087302,-55.751285348429704,34.46800149505145,-85.94687293924117,0 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark63(86.92217254427575,-22.17077163515968,-43.165632711943694,36.28413805144777,0 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark63(86.96504268453481,-45.25780646811306,17.130328277702205,31.67432916744241,0 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark63(86.96701367283538,-17.245121607143133,-10.214393023346574,-39.783103903773,0 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark63(86.96959172746662,-89.82264552570047,95.60631802151804,-29.61638407486508,0 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark63(86.98188830123539,-50.69316720178454,-61.83310728843681,-57.76402641509111,0 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark63(86.98553549052846,-42.40846660834465,94.54917310937924,4.293824458548386,0 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark63(87.01113446896349,-70.7612655172779,44.1069705126188,18.883763108582244,0 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark63(87.0218243080543,-28.513504595827555,65.43515575790983,-20.920620121441402,0 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark63(87.02462878849124,-70.42938476610303,-91.88307374623108,15.25913504284766,0 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark63(87.02474294386414,-66.21679791384693,24.42117819201887,67.80362412746413,0 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark63(87.03828922679534,-86.86182685539244,48.04820271446167,-4.300016163371595,0 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark63(87.07432150747468,-81.99683789852841,98.8577141191499,88.00267124238573,0 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark63(87.0843333024689,-83.38823847525933,-91.0298869936494,-76.39838683401751,0 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark63(87.095834482041,-58.91770805116645,-48.283753452668996,-89.9537079979853,0 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark63(87.11255826505368,-32.110133945015946,-43.62304780827735,48.467003251516644,0 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark63(87.13302808706246,-20.405910894155483,-29.971389271616317,-30.154490439547985,0 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark63(87.1370027128603,-42.08809437511043,-48.52584894266707,-38.147282039113726,0 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark63(87.15687416278627,-4.437671961964099,44.64277576982792,-98.3758301308566,0 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark63(87.18844396646816,-87.68866134794773,-69.17330734472648,48.552348011398635,0 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark63(87.26608965911694,-63.82754327996554,27.7200102090638,84.5283033460376,0 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark63(87.26968476912234,-17.965026626292783,-90.86029737944064,-6.735714735603466,0 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark63(8.727424805482926,-2.3150721414795186,54.29277520094587,-60.47851864893319,0 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark63(87.31860867328973,-82.39690536048198,31.848454214603095,46.33145427822481,0 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark63(87.34328037588867,-50.3340504637745,-64.08975750081889,-69.79913244756462,0 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark63(87.35154083142837,-78.66317430482499,38.98300673860112,-44.31274226062199,0 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark63(87.43517058690887,-67.86585415364614,-7.476115393222045,93.42757733143216,0 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark63(87.4724786748045,-38.867799578844384,-90.72639282994892,-62.552225027067834,0 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark63(87.4856160878492,-39.19876946590573,11.769239899840215,-75.44035478083914,0 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark63(87.49024862475366,-26.520187305075922,92.3938948132427,-12.038004905083312,0 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark63(87.5477083542848,-58.117232361495596,-69.31999104833622,-29.518855428826015,0 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark63(87.57953189033933,-5.547239554622735,63.16896748333309,-94.62776337003358,0 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark63(87.58669022737891,-38.45712435014577,-72.2143153549776,-95.6488732697406,0 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark63(87.59187050473585,-9.262707520553562,-26.836853588401198,-53.07596855039161,0 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark63(87.59552678251185,-7.609504994591276,7.463137643754365,-65.48017794503349,0 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark63(87.61994299874792,-21.371744205448636,-1.3603486057801177,69.05150806404558,0 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark63(87.62073362030412,-70.2656930661247,-61.00241747716515,-22.55959425507379,0 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark63(87.66257325501289,-78.43701275272457,-64.68242105065687,-36.56171343624559,0 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark63(87.68479400128396,-30.526799667220743,94.3462473435093,75.15674815770848,0 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark63(87.73416892267215,-17.896760043427236,77.47783000535003,81.43490926181366,0 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark63(87.73740379289984,-17.186907452014793,-75.83163442542111,-99.23666351349385,0 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark63(87.75868919996162,-26.807612409596018,-29.520677818973425,-73.68115588452076,0 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark63(87.76067884134497,-50.11761744488679,58.067928437508215,81.83681276580856,0 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark63(87.7651349647571,-27.107862312502036,83.81147889464413,32.474855042618145,0 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark63(87.77021860036572,-63.12957856731305,-67.70271497976117,50.69348172880868,0 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark63(87.77822876148994,-73.81540705486411,78.62804424637562,79.50705811649254,0 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark63(87.80220833447126,-83.92918983308448,-22.577512658799037,22.99653966120212,0 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark63(87.91719689368128,-42.310254599768186,-40.80650907591428,-94.97242991140142,0 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark63(87.96817522334845,-57.72845952374301,72.96775172102414,-68.87091881105093,0 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark63(87.97737931001555,-13.012911819108908,-75.03583359048378,-12.882978397206983,0 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark63(87.97927622732945,-86.97217076028802,-88.06178878590387,91.52146861851688,0 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark63(87.99494418088014,-54.81068351161207,71.51287940318008,-98.42467324117825,0 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark63(88.00315768469159,-17.401389059435516,82.36599164614216,27.413719794790197,0 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark63(88.00537143343576,-79.35616063243056,75.6708780648531,-64.18964713581117,0 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark63(88.0370032285856,-2.3581093285091015,92.29748943259816,-5.050918828155162,0 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark63(88.04982918768661,-32.11304070230399,60.21960946994017,7.427199307473643,0 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark63(88.06822186082559,-7.485840608473438,92.13782484532359,19.057930303126923,0 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark63(88.074121309188,-28.065040548138924,-55.74372484891996,-84.64670698284493,0 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark63(88.1196630979563,-87.01754735839044,5.3132510883926045,-21.46825894639865,0 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark63(88.12144368168208,-46.05455716348739,-44.43739762637233,-81.48665914010152,0 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark63(88.13803222121584,-37.831267640605894,9.699021925783853,43.430817064450196,0 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark63(88.16888339514219,-25.874016965252864,-71.78699985572314,-78.13703640539656,0 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark63(88.18461819952356,-15.54022500311882,31.73560479414502,-67.86541018365648,0 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark63(88.19436154941408,-58.081424272562224,37.22749630069126,9.674545127967463,0 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark63(88.24014507094407,-71.97849591767636,-3.1614605197434003,75.30011703183405,0 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark63(88.25998374851747,-74.10342464237357,-99.3959281748052,-40.510870225260696,0 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark63(88.27671300977957,-51.72488864174647,-46.322528444734324,-73.32239622832108,0 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark63(88.28165124486443,-33.91436715934684,55.708780017747586,49.96658960976649,0 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark63(88.29333631001194,-86.66477517717527,83.29419269355597,-97.02093835659934,0 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark63(88.30434944092329,-56.652288550727484,26.39134916946037,69.7302249021156,0 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark63(88.32178241074783,-43.539678711647746,54.09396316075481,-59.388742299987825,0 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark63(88.33942451316554,-8.33542013189819,22.72344152621399,52.39595222122921,0 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark63(88.35143167232062,-15.81062600376653,51.698865763249415,79.67678307735457,0 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark63(88.380093230438,-58.06277383110117,-88.38645325532826,45.68739836559564,0 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark63(88.38376153007187,-68.71572081482755,-58.44463172343137,59.263032134578054,0 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark63(88.3964541781043,-6.9067255430411905,90.50652206411092,94.85065036375047,0 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark63(88.39969256480782,-9.60714885695866,-70.34089016611145,-66.43959149488924,0 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark63(88.40413488017745,-67.26370347635904,-48.99074881977019,83.37469851373999,0 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark63(88.42235262766067,-17.134901395096833,16.17574071014836,-67.28176867373833,0 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark63(88.45806646103304,-64.5262253529791,73.35018077576512,-46.87397569803766,0 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark63(88.46534141475595,-22.776242039687645,43.747580509606564,-92.11231514522898,0 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark63(88.48872682049497,-20.297678607873124,-5.2127211563214075,17.333484670336844,0 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark63(88.53786672160732,-88.97790613783236,-72.32587482693668,95.27395430164967,0 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark63(88.54756469068388,-15.324391162087963,-61.683964221645816,-47.867457567159754,0 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark63(88.56145067618144,-2.454971122587125,46.731372746451115,35.825593096569634,0 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark63(88.56339270073653,-9.086794249960988,34.48540179861769,-1.0812201766920282,0 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark63(88.58804573593488,-13.355188795545828,3.154240079919731,-44.550880094293554,0 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark63(88.62222019834434,-35.264165841563795,90.83713097262361,7.27601815861685,0 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark63(88.651582616859,-81.85526925231159,-11.297180176747617,-26.198709939105044,0 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark63(88.67615585549652,-48.259604455561586,-46.260658529826685,-90.26343377091948,0 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark63(88.68174156047016,-43.286038282372274,64.86360922558742,49.50024405977621,0 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark63(8.868731602415366,-83.93794771193006,22.712507490234685,-0.07784054350111091,0 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark63(88.689429068349,-21.359713771728337,58.049096815703024,29.10907793197589,0 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark63(88.7208832067902,-10.470562361725584,5.278499552603819,-47.41770101061689,0 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark63(88.73200159954837,-39.30342024789939,80.07833037230756,94.86166770525045,0 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark63(88.74467686383284,-73.4042594600742,-9.732388576039085,-89.55266380741516,0 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark63(88.76318380016878,-69.0182115546584,-6.580280396294654,-64.06302666410076,0 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark63(88.7679125505187,-63.7374168534752,67.87123326939434,-63.416115896995116,0 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark63(88.77094560018418,-37.52892210447276,-93.60028513721379,-2.6743071287343554,0 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark63(88.77377980036474,-56.229079513259016,-69.85090669663425,77.06211877719414,0 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark63(88.78463321097507,-65.91206127957753,41.56639831663455,98.9396151675179,0 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark63(88.80015242999951,-28.762935609942986,-83.46272552759649,11.493779291038877,0 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark63(88.82095353521194,-22.084642800207746,-10.782253102193266,32.980527306118006,0 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark63(88.83440171873076,-26.2534140321483,94.55416054047748,30.232402693345193,0 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark63(88.83669730937086,-52.792014016498534,-93.34385645042904,-22.124553058490164,0 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark63(88.84581178216612,-79.31219828166113,13.714624856456979,-43.755976241573016,0 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark63(88.86101552456714,-15.212747403122435,-47.40096401351022,-34.01568742921212,0 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark63(88.8839911831378,-12.890233974515695,56.85893635224096,-69.10863800492237,0 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark63(88.93005838064428,-37.35590938904401,24.886867197491867,-27.67296917319051,0 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark63(88.93349564520668,-66.49144973687098,-26.224734075825822,-97.90296561327602,0 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark63(88.93660902115101,-66.67646645440999,70.51516844710352,-73.78423595963162,0 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark63(88.94916261396475,-20.240703031131787,-81.64869115632473,73.41631726183476,0 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark63(88.96097659055465,-60.880533791094436,-85.581246441446,-80.91437722917054,0 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark63(88.96265694786425,-51.933231029968276,-23.318512061010054,16.117818259854587,0 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark63(88.98761195365134,-73.09818708603255,-11.10950664506079,-12.97920267562536,0 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark63(89.00137483404586,-5.1245315398306275,37.407437858522684,77.22043651532067,0 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark63(8.901769438558787,-95.03415406142082,-47.38357422374053,0.3146242282114855,0 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark63(89.02240990660826,-13.26880526425289,32.12442475231032,6.234688251668572,0 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark63(-89.04787682512925,43.77957940573421,-45.77367692347809,91.83788910649682,0 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark63(89.05751283136166,-67.34697646203125,-80.23675073138858,8.131746448747663,0 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark63(89.08073431501276,-16.20550149688482,-43.764487251983766,85.23355116687719,0 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark63(89.08895434115982,-86.78401149781838,-53.48099806567148,90.9163653459151,0 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark63(89.11893861406173,-5.474223039677909,48.083328175153184,-24.59356095691672,0 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark63(89.1390569973741,-60.65736902406638,-22.876482981862267,-47.39786752281452,0 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark63(89.18394667880335,-36.722735955888574,-8.780625806282785,47.089845616456046,0 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark63(89.1950695427372,-85.80970415421218,96.78659161894345,57.504318374043976,0 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark63(89.20957900394833,-84.06779876308465,71.37540411450541,-62.19033053727259,0 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark63(89.22244194975326,-78.64070015169602,53.28610610803318,-75.59146193249484,0 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark63(89.22475744794019,-55.79555843304591,24.777465041947153,-78.18724880417791,0 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark63(89.23847001692332,-27.40526178509448,27.538437767073347,90.60008682101065,0 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark63(89.25093133485655,-31.793500089896185,31.27895404379558,-12.932328252107482,0 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark63(89.25532477171834,-88.51133525502615,-20.314439766009855,-31.582687842882606,0 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark63(89.25846093539712,-77.14018187571314,23.94870075713939,79.50998122612955,0 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark63(89.26263266881998,-71.90574232691789,-66.51467427216681,-4.589952705534216,0 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark63(89.30054518662041,-34.68589630554068,53.47524841019222,-14.241356634449588,0 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark63(89.3016081648939,-27.359194217917477,-59.01556452889025,-69.8163966051736,0 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark63(89.30644853089967,-75.44349961635264,-76.79803892207212,-49.620544275857355,0 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark63(89.33190713756949,-30.810297559506353,-87.91798941494,-55.90794539176345,0 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark63(89.33945738236585,-40.756577772307054,-39.6366737211558,-84.87941477376538,0 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark63(89.35495371896087,-23.756934484062086,98.78910730811344,63.024888558273716,0 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark63(89.37390315305967,-9.774205707461434,-69.85580381165362,4.327582153718652,0 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark63(89.41058071238484,-35.922537902214984,-78.52395349911541,66.23054102123649,0 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark63(89.41552318161118,-44.89329036861787,-33.62202779074062,-2.0461658084831527,0 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark63(89.44058713057399,-30.54631589120669,-10.543023809375953,-87.53850858322632,0 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark63(89.45712648073032,-58.94900859200958,17.457105237577792,30.494719271994143,0 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark63(89.45984539797698,-64.7665993373542,64.90468104974335,-53.77141151857492,0 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark63(89.46055790047922,-44.641118536004434,-12.807348036570303,-51.22481221333801,0 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark63(89.475122649756,-78.88756908904054,-15.153530292283392,86.36971596601532,0 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark63(89.48188386114296,-67.07184557347263,18.90840330289079,79.58730382238559,0 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark63(89.51639849172531,-28.803632625891623,-91.70468039463802,58.33767489414237,0 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark63(89.54497740644891,-82.47026986319032,-34.490692303424254,-37.702900221090175,0 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark63(89.58772501985248,-22.73505426545124,71.05476133607522,8.090183076287815,0 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark63(89.59131057892452,-74.72347852266361,-45.61333591545158,65.12843920186765,0 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark63(89.59361386607634,-1.6490852469464699,71.62743291026737,18.020788084242014,0 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark63(89.68149052333104,-23.96029639763752,82.53035653339998,1.5856878062657813,0 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark63(89.68270335694345,-95.45697473061662,71.19629888547146,-5.7370692196244875,0 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark63(89.72421738654478,-16.749759564741424,19.023219215924357,17.161618327941966,0 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark63(89.72733371122314,-38.84838658488965,-13.47081692523895,82.2654711664004,0 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark63(89.73479371560643,-28.078577824051962,-93.54717963819968,-47.48669208279681,0 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark63(89.75020791959722,-25.644606491172567,-6.024069583540538,61.75210341629142,0 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark63(89.76696634183185,-6.187488490448928,22.453627977171834,69.88439873507431,0 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark63(89.77162657859733,-90.02517743828594,-42.63905327619997,70.1715620712306,0 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark63(89.78411176357565,-13.657637488136459,60.025191739442704,50.40801819569384,0 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark63(89.81300360040296,-78.64966245279314,72.9199395854773,60.33414989078403,0 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark63(89.82302870308214,-50.052341673686755,58.88535234351542,4.59844657755329,0 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark63(89.84427578589637,-30.133957092382474,-94.34821148683203,-26.416364957290142,0 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark63(89.85584474381602,-13.659688657125884,7.102876552709688,-44.75221385745698,0 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark63(89.88258198432527,-11.920745589827163,88.51610921580297,-27.22939994687637,0 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark63(89.89575220655769,-50.72612035994442,-84.88588823607492,96.16219183514957,0 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark63(89.89853050531136,-17.473098165128505,61.847008846151596,-97.96719020945493,0 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark63(89.90425791786942,-76.05330569020828,-30.414584089350555,-77.61706340805554,0 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark63(89.9397386012327,-21.175875745332178,18.240488299436834,69.87834196688024,0 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark63(89.9435011181258,-32.551578988642945,16.760183747317342,91.86784317971438,0 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark63(89.96597790394074,-28.996246785138325,34.39394405709379,-90.68739142846458,0 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark63(89.97332394379029,-58.768107582849936,23.622840337940403,-77.35483108884753,0 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark63(89.97951325118942,-76.71559833319779,-43.16957960185965,-21.993819499259786,0 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark63(89.98684841855496,-97.47514918218255,78.46380125152498,-4.561893848988149,0 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark63(89.99243946382086,-74.85773585336645,-25.720972445700724,-35.31096793761519,0 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark63(90.00314200661944,-49.28018343735121,-24.58450302330739,59.53036709475299,0 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark63(90.0335896537645,-42.766120044903985,35.3818407061062,94.51747755156526,0 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark63(90.04976798847363,-70.58138271201217,28.230046362015884,95.25044104310953,0 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark63(90.05685646024469,-31.301156238331146,-34.24439437131548,-42.3616862761734,0 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark63(90.09439585130485,-37.57047102079656,-80.16894162792237,-30.77087643815888,0 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark63(90.11892588496292,-90.06372551956177,-88.43602071777656,19.58286856504185,0 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark63(90.12546326898467,-20.7795929076009,-75.78864980750662,-84.37934548566027,0 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark63(90.14855336343274,-16.964254804447435,-64.83276942679028,70.34952169620951,0 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark63(90.16607168372687,-4.784875506814373,-27.37172591250578,6.871141689365473,0 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark63(90.16712306805721,-46.45137303963725,67.3667126942072,-67.58733818041122,0 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark63(90.1681898315,-73.38803971204561,-46.60682162743428,60.25465387603589,0 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark63(90.19772249153971,-33.824453987164986,73.42037679662724,87.9813143295519,0 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark63(90.23381322455117,-46.476112789327,-64.03874480490612,-98.44921729256552,0 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark63(90.24465285718975,-51.00371560398178,-99.71620373141327,48.91222576447859,0 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark63(90.29092736613617,-36.05242748489916,-3.9176967849674327,-51.7471362961033,0 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark63(90.29708152416814,-64.2396326511454,33.82929715154529,19.31601291018177,0 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark63(90.31320891675983,-11.564396728947557,38.89339990353065,30.636609356381314,0 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark63(90.33542014720663,-84.24711697220425,53.369576474822935,87.1568968040531,0 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark63(90.3378234662963,-20.798754874341356,-37.723971424785276,-72.24583245134906,0 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark63(90.3744244800721,-88.77107176205689,-50.16542752379301,20.03120946855516,0 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark63(90.38961307190564,-20.99173358411639,55.46651964485318,-85.5863436184319,0 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark63(90.39462986069807,-25.915890693709215,-38.594474335026455,30.75957072818622,0 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark63(90.4282530361871,-45.90749426359666,87.23062911820429,-14.114674238060815,0 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark63(90.43743110288418,-62.40994846001264,-0.6042689105940866,-33.844226891632516,0 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark63(90.44574848459672,-44.73082517990823,93.59760154801296,46.02450754901267,0 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark63(90.48618221735026,-8.137008071343772,-16.060213920681733,-71.49624521917153,0 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark63(90.53915715724324,-6.170254705419211,-11.578759629347445,70.3099099620812,0 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark63(90.55778743085364,-86.05010255843781,74.11137738749821,28.987678392957122,0 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark63(90.5586494181945,2.465190328815662E-32,-31.1104241189106,3.0298561101402157,0 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark63(90.56675778865758,-39.24251557068759,82.51185680726076,79.15799819803527,0 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark63(90.5722034221728,-5.3803021110961,73.64309400034327,-17.99409267512118,0 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark63(90.61132314673316,-33.076720782166774,31.299058321818364,-14.403387109624589,0 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark63(90.62857681462404,-59.69229374605012,4.322992767288952,7.6549556431975105,0 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark63(90.63866198487094,-45.56206010281918,-11.819430215293764,-86.9183500577497,0 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark63(90.67870745946254,-16.483341404080235,-35.24025956199441,37.068225757349325,0 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark63(90.67907785678179,-12.274131610263169,-73.53754613829311,-3.8604197013796266,0 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark63(90.74683034478255,-0.8531388290390112,39.90728381396406,-8.232440708119299,0 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark63(90.76166508156967,-25.65902549281944,-51.59815799706649,-2.045876834826373,0 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark63(90.78565607090073,-2.2758844197052355,91.7906629853147,-14.620381292569277,0 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark63(90.80659267353715,-6.93823317989164,-49.862297626069996,60.35695735104258,0 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark63(90.8066842223615,-74.22404094196857,46.3705650739343,-53.05304835889957,0 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark63(90.80798236891346,-21.70131550014942,-63.134688075631495,-50.57977194942731,0 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark63(90.87104015823681,-42.03405446030777,-7.069012487121668,72.26237996382079,0 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark63(90.87303566865799,-28.220826785996906,-29.482466612726313,1.3169966576975725,0 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark63(90.91944135505031,-22.725473753233246,-89.78964929777678,46.13311085376665,0 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark63(90.93221113531195,-38.49157712757771,-15.747513317031007,44.51764973143784,0 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark63(90.94935507681592,-55.43202988713383,44.65170476635328,72.3677827217569,0 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark63(90.9756118444086,-58.00850713168353,68.27499389729613,14.14805042100555,0 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark63(90.97682036217017,-6.192721902805374,-10.508086049968554,-52.7404790256629,0 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark63(90.9889323834505,-43.84672929330169,-91.67443673166093,99.17551948071525,0 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark63(91.03275304109849,-51.79522028222843,52.32207953767488,73.15972225462727,0 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark63(91.04159111630227,-84.97321565868101,48.61179836265424,23.19335754792604,0 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark63(91.06033538534922,-6.4103864193786535,-10.413288493550638,76.95692735209025,0 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark63(91.06122264538052,-50.35715093726603,-30.199938674556066,9.499338259392132,0 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark63(91.06898922509393,-5.9765120040465405,-14.660754848320877,59.86803071167091,0 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark63(91.07659467953309,-58.71633449762352,-84.55943221618215,69.59321260147567,0 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark63(91.09013922656175,-72.92299946993927,64.26031588694445,-18.90789417480576,0 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark63(91.09111800568655,-68.03285233440953,-77.50764876345372,-68.13960238917997,0 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark63(91.09358555661134,-66.70905385641117,-83.8339851789325,36.825021534523756,0 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark63(91.10231922922972,-61.83116513880837,-32.63887163138341,-6.942499865531175,0 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark63(91.10276405760354,-29.74345730282309,-28.813889751647764,67.62716576342365,0 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark63(91.11299790746679,-51.464707744059446,-53.014296674105196,-33.20618961114508,0 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark63(91.12380070843807,-83.54450594441126,1.9272762784976862,-41.28873918242966,0 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark63(91.16565762192656,-83.79378404821627,91.27329625489,39.68526712624711,0 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark63(91.16759989780633,-64.44325909928226,-84.2325735831844,-91.7029450678719,0 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark63(91.17180889255238,-50.5735996696659,-8.43558523851567,-38.697938981493074,0 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark63(91.1787639204963,-47.94277045019868,25.870486075877324,51.98899303480542,0 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark63(91.18099345909894,-52.933483194494244,-69.87882739258188,-63.29479949679075,0 ) ;
  }

  @Test
  public void test2476() {
    coral.tests.JPFBenchmark.benchmark63(91.20561636141053,-84.33933720891302,-22.26078312586938,7.49686692945653,0 ) ;
  }

  @Test
  public void test2477() {
    coral.tests.JPFBenchmark.benchmark63(91.20811639387253,-14.716878498339852,-50.15363670810948,51.615969644647066,0 ) ;
  }

  @Test
  public void test2478() {
    coral.tests.JPFBenchmark.benchmark63(91.21825441851112,-58.66728773636052,-81.07876032791019,18.026664631834706,0 ) ;
  }

  @Test
  public void test2479() {
    coral.tests.JPFBenchmark.benchmark63(91.2201189614743,-55.18169442639902,60.78628876989595,-66.78849531518264,0 ) ;
  }

  @Test
  public void test2480() {
    coral.tests.JPFBenchmark.benchmark63(91.22493528715185,-20.583526454026483,14.452106411656302,-33.13220033908961,0 ) ;
  }

  @Test
  public void test2481() {
    coral.tests.JPFBenchmark.benchmark63(91.2347343973916,-22.198532914164474,51.99225663338268,8.19492678606828,0 ) ;
  }

  @Test
  public void test2482() {
    coral.tests.JPFBenchmark.benchmark63(91.23795070678241,-92.06375512926857,83.65793370040709,-51.460800876340464,0 ) ;
  }

  @Test
  public void test2483() {
    coral.tests.JPFBenchmark.benchmark63(91.23924139814702,-50.70797331964123,10.968310908242614,-24.607018937118625,0 ) ;
  }

  @Test
  public void test2484() {
    coral.tests.JPFBenchmark.benchmark63(91.25915656979862,-67.77613652780357,66.5972783057841,-39.29011936671725,0 ) ;
  }

  @Test
  public void test2485() {
    coral.tests.JPFBenchmark.benchmark63(91.26441048263305,-12.302986709665433,-20.22691574025741,-30.803562983016036,0 ) ;
  }

  @Test
  public void test2486() {
    coral.tests.JPFBenchmark.benchmark63(91.28944055476302,-39.326418952093036,-40.727626265838836,65.30183361397118,0 ) ;
  }

  @Test
  public void test2487() {
    coral.tests.JPFBenchmark.benchmark63(91.31103067211933,-77.88833353658822,94.05965777209107,60.86410646859889,0 ) ;
  }

  @Test
  public void test2488() {
    coral.tests.JPFBenchmark.benchmark63(91.31476933483748,-18.803372181265686,91.13932022471153,-33.853606546316,0 ) ;
  }

  @Test
  public void test2489() {
    coral.tests.JPFBenchmark.benchmark63(91.32352147383861,-43.36429562322643,10.84826350415264,44.35090837046059,0 ) ;
  }

  @Test
  public void test2490() {
    coral.tests.JPFBenchmark.benchmark63(91.33726353700379,-75.43309376524836,-97.33227256485839,13.34049809552728,0 ) ;
  }

  @Test
  public void test2491() {
    coral.tests.JPFBenchmark.benchmark63(91.34174374052199,-6.715394394568477,-4.697414220336611,11.255355276941543,0 ) ;
  }

  @Test
  public void test2492() {
    coral.tests.JPFBenchmark.benchmark63(91.36364008880952,-77.93770780665562,90.67545716794251,68.74837642406507,0 ) ;
  }

  @Test
  public void test2493() {
    coral.tests.JPFBenchmark.benchmark63(91.36370406043622,-49.0489900404856,42.80428542768422,-67.47623040395452,0 ) ;
  }

  @Test
  public void test2494() {
    coral.tests.JPFBenchmark.benchmark63(91.38630462774279,-10.575508174145767,98.11705921565112,-48.8479843326336,0 ) ;
  }

  @Test
  public void test2495() {
    coral.tests.JPFBenchmark.benchmark63(91.40933158543899,-68.52897022962621,76.81117450542922,28.17016032355889,0 ) ;
  }

  @Test
  public void test2496() {
    coral.tests.JPFBenchmark.benchmark63(91.4184182990802,-77.74651539723818,-32.187578993034705,80.28172688968755,0 ) ;
  }

  @Test
  public void test2497() {
    coral.tests.JPFBenchmark.benchmark63(91.42734409033159,-65.03271532582009,42.76873047875597,79.07350745899089,0 ) ;
  }

  @Test
  public void test2498() {
    coral.tests.JPFBenchmark.benchmark63(91.43659186487187,-69.61995993071959,-92.2578002290072,-15.740530048083997,0 ) ;
  }

  @Test
  public void test2499() {
    coral.tests.JPFBenchmark.benchmark63(91.4392506397023,-41.24717287110704,-54.64954355126981,95.30523458719492,0 ) ;
  }

  @Test
  public void test2500() {
    coral.tests.JPFBenchmark.benchmark63(91.44143634378105,-77.08486744010852,52.97438849009694,59.74779532746942,0 ) ;
  }

  @Test
  public void test2501() {
    coral.tests.JPFBenchmark.benchmark63(91.45316177048255,-89.56178623105804,64.62765526623716,-58.31027994945883,0 ) ;
  }

  @Test
  public void test2502() {
    coral.tests.JPFBenchmark.benchmark63(91.45471252887748,-30.774802002499683,-52.38929815014581,-10.662178164344098,0 ) ;
  }

  @Test
  public void test2503() {
    coral.tests.JPFBenchmark.benchmark63(91.47312003202654,-47.724360160660886,6.068628548720696,79.19039145094217,0 ) ;
  }

  @Test
  public void test2504() {
    coral.tests.JPFBenchmark.benchmark63(91.48045652050914,-24.723442219578047,32.16808303332948,45.814921917648576,0 ) ;
  }

  @Test
  public void test2505() {
    coral.tests.JPFBenchmark.benchmark63(91.50217343791229,-88.38833081324016,-4.2880800756121715,78.41191513875256,0 ) ;
  }

  @Test
  public void test2506() {
    coral.tests.JPFBenchmark.benchmark63(91.52779092028334,-16.443550669163272,22.032916048836327,-45.01032485816203,0 ) ;
  }

  @Test
  public void test2507() {
    coral.tests.JPFBenchmark.benchmark63(91.54772805961096,-26.682771490900862,60.8496716972046,-46.20205033716731,0 ) ;
  }

  @Test
  public void test2508() {
    coral.tests.JPFBenchmark.benchmark63(91.57437004303003,-23.739625041066347,-64.18274633742072,-84.96539416245837,0 ) ;
  }

  @Test
  public void test2509() {
    coral.tests.JPFBenchmark.benchmark63(91.58275300847026,-24.718014079018417,-18.35698270588412,-73.7404648862288,0 ) ;
  }

  @Test
  public void test2510() {
    coral.tests.JPFBenchmark.benchmark63(91.5928429571023,-77.42188246350446,52.86926466859089,-19.10635482987273,0 ) ;
  }

  @Test
  public void test2511() {
    coral.tests.JPFBenchmark.benchmark63(91.61834703356405,-38.555728049767765,78.120986496277,18.045980195525814,0 ) ;
  }

  @Test
  public void test2512() {
    coral.tests.JPFBenchmark.benchmark63(91.62582980029163,-62.061345512465316,-27.41369621538159,58.45233009585405,0 ) ;
  }

  @Test
  public void test2513() {
    coral.tests.JPFBenchmark.benchmark63(91.64936043832833,-14.938302457824634,-59.738749929372425,47.564782969063,0 ) ;
  }

  @Test
  public void test2514() {
    coral.tests.JPFBenchmark.benchmark63(91.70841058616224,-28.259654181227617,9.325437868813808,66.27481790555063,0 ) ;
  }

  @Test
  public void test2515() {
    coral.tests.JPFBenchmark.benchmark63(91.74231849945116,-24.608042659269174,-71.67390877210627,-33.25796611852412,0 ) ;
  }

  @Test
  public void test2516() {
    coral.tests.JPFBenchmark.benchmark63(91.74351988324955,-0.06433888467778104,38.95348491477202,16.606017453733728,0 ) ;
  }

  @Test
  public void test2517() {
    coral.tests.JPFBenchmark.benchmark63(91.75226110503255,-26.501147056076093,-94.3976658917008,1.2550342344696617,0 ) ;
  }

  @Test
  public void test2518() {
    coral.tests.JPFBenchmark.benchmark63(91.7610023423106,-54.57407642360559,-72.27356579442592,-66.53454844887752,0 ) ;
  }

  @Test
  public void test2519() {
    coral.tests.JPFBenchmark.benchmark63(91.77795987925194,-53.17036008268623,-76.49067238952354,77.99205696280342,0 ) ;
  }

  @Test
  public void test2520() {
    coral.tests.JPFBenchmark.benchmark63(91.77847158450655,-76.03448878717163,-48.956983160825615,95.81700517914561,0 ) ;
  }

  @Test
  public void test2521() {
    coral.tests.JPFBenchmark.benchmark63(91.80940901340728,-62.4184537104979,25.609420713328348,-95.2860968463442,0 ) ;
  }

  @Test
  public void test2522() {
    coral.tests.JPFBenchmark.benchmark63(91.82277221064021,-66.4104246354067,-4.799091544336335,-56.99551295248888,0 ) ;
  }

  @Test
  public void test2523() {
    coral.tests.JPFBenchmark.benchmark63(91.82833586719727,-17.863769694863677,-6.195693175124475,-52.363812041900104,0 ) ;
  }

  @Test
  public void test2524() {
    coral.tests.JPFBenchmark.benchmark63(91.83231002476134,-30.833416011798704,80.85061617947878,66.53271072866016,0 ) ;
  }

  @Test
  public void test2525() {
    coral.tests.JPFBenchmark.benchmark63(91.85476324510188,-17.724742685198564,-92.99354430420333,-71.75149474114644,0 ) ;
  }

  @Test
  public void test2526() {
    coral.tests.JPFBenchmark.benchmark63(91.86806656186135,-8.273488901556021,72.16405940460393,70.34511618015557,0 ) ;
  }

  @Test
  public void test2527() {
    coral.tests.JPFBenchmark.benchmark63(91.88671266738098,-44.363522597213276,-23.85780523601055,46.356671423215516,0 ) ;
  }

  @Test
  public void test2528() {
    coral.tests.JPFBenchmark.benchmark63(91.91824583848006,-53.06863183245716,-54.511463578199184,-59.68935375568054,0 ) ;
  }

  @Test
  public void test2529() {
    coral.tests.JPFBenchmark.benchmark63(91.93119287434908,-71.13635226368498,88.03939536673434,17.332660534709348,0 ) ;
  }

  @Test
  public void test2530() {
    coral.tests.JPFBenchmark.benchmark63(91.96387504362136,-59.2672086922071,-0.4245246545140162,-96.82567529661918,0 ) ;
  }

  @Test
  public void test2531() {
    coral.tests.JPFBenchmark.benchmark63(91.97195506935944,-89.72394290664639,58.18963942907121,61.79255513776562,0 ) ;
  }

  @Test
  public void test2532() {
    coral.tests.JPFBenchmark.benchmark63(91.97228631798907,-24.145592901873684,-61.484853808450765,-87.18462534575818,0 ) ;
  }

  @Test
  public void test2533() {
    coral.tests.JPFBenchmark.benchmark63(91.9775982357063,-79.09022815810825,53.7445857889021,89.15770855564816,0 ) ;
  }

  @Test
  public void test2534() {
    coral.tests.JPFBenchmark.benchmark63(92.01904329487354,-28.544449834817613,21.618259001984768,-4.2347220844620495,0 ) ;
  }

  @Test
  public void test2535() {
    coral.tests.JPFBenchmark.benchmark63(92.02482934873208,-53.26238824391329,36.154924997213186,-97.66814466781828,0 ) ;
  }

  @Test
  public void test2536() {
    coral.tests.JPFBenchmark.benchmark63(92.02794249585841,-89.0827991527861,49.23418438203754,71.70127521500063,0 ) ;
  }

  @Test
  public void test2537() {
    coral.tests.JPFBenchmark.benchmark63(92.03201705225587,-41.393417366901296,1.7949906731126646,6.199421519564538,0 ) ;
  }

  @Test
  public void test2538() {
    coral.tests.JPFBenchmark.benchmark63(92.03288885768629,-64.91651219440335,99.30016844870352,-22.527604989133664,0 ) ;
  }

  @Test
  public void test2539() {
    coral.tests.JPFBenchmark.benchmark63(92.06240899948637,-18.134972562605014,59.280210612949986,44.93844887499935,0 ) ;
  }

  @Test
  public void test2540() {
    coral.tests.JPFBenchmark.benchmark63(92.07250399615859,-33.51568862388983,72.52247256352095,93.09342047606651,0 ) ;
  }

  @Test
  public void test2541() {
    coral.tests.JPFBenchmark.benchmark63(92.07559022539141,-27.994163640759623,-39.682629149812485,33.818438126112994,0 ) ;
  }

  @Test
  public void test2542() {
    coral.tests.JPFBenchmark.benchmark63(92.09183217414687,-9.525698545911496,16.620853150023237,-35.81622867919671,0 ) ;
  }

  @Test
  public void test2543() {
    coral.tests.JPFBenchmark.benchmark63(92.09995852284186,-6.003990827738519,55.811548750531585,50.22224914062551,0 ) ;
  }

  @Test
  public void test2544() {
    coral.tests.JPFBenchmark.benchmark63(92.10537840475433,-36.32269032332231,-57.81459934183684,22.9438956474238,0 ) ;
  }

  @Test
  public void test2545() {
    coral.tests.JPFBenchmark.benchmark63(92.10615416148718,-76.7166819025397,16.028124156084147,-9.334979808877137,0 ) ;
  }

  @Test
  public void test2546() {
    coral.tests.JPFBenchmark.benchmark63(92.11968797248366,-28.909378647191303,24.737172753583422,-89.70359939363416,0 ) ;
  }

  @Test
  public void test2547() {
    coral.tests.JPFBenchmark.benchmark63(92.12903666249755,-70.42723633416654,34.79241788809719,-87.0285393550831,0 ) ;
  }

  @Test
  public void test2548() {
    coral.tests.JPFBenchmark.benchmark63(92.12995117283361,-88.73787757227298,-29.85168260392416,43.63276516092205,0 ) ;
  }

  @Test
  public void test2549() {
    coral.tests.JPFBenchmark.benchmark63(92.15143113866026,-60.42784617643515,-15.045265299177629,-23.799626478335753,0 ) ;
  }

  @Test
  public void test2550() {
    coral.tests.JPFBenchmark.benchmark63(92.1583408975475,-53.394554048542076,81.05462131919157,27.324507185971896,0 ) ;
  }

  @Test
  public void test2551() {
    coral.tests.JPFBenchmark.benchmark63(92.159311188999,-24.857915851633678,-40.32230882018475,-81.4926791346788,0 ) ;
  }

  @Test
  public void test2552() {
    coral.tests.JPFBenchmark.benchmark63(92.16054649834876,-33.29677669390398,-25.180993231235306,-31.775141388575108,0 ) ;
  }

  @Test
  public void test2553() {
    coral.tests.JPFBenchmark.benchmark63(92.16429621697063,-37.15898093311707,-88.61487992600645,63.07720187918494,0 ) ;
  }

  @Test
  public void test2554() {
    coral.tests.JPFBenchmark.benchmark63(92.17264124407211,-14.651708206089324,28.196884980451244,-3.639714604715664,0 ) ;
  }

  @Test
  public void test2555() {
    coral.tests.JPFBenchmark.benchmark63(92.20303114893952,-23.23189962479006,-63.27279164606638,19.85541163217954,0 ) ;
  }

  @Test
  public void test2556() {
    coral.tests.JPFBenchmark.benchmark63(92.21900947695732,-50.46909572818705,-18.697886491946505,77.94901512922945,0 ) ;
  }

  @Test
  public void test2557() {
    coral.tests.JPFBenchmark.benchmark63(92.23732333384848,-16.21015218009738,-51.26751014470558,-54.58536011368524,0 ) ;
  }

  @Test
  public void test2558() {
    coral.tests.JPFBenchmark.benchmark63(92.2687943865078,-79.58393006276295,65.37762316676151,-23.876187752058755,0 ) ;
  }

  @Test
  public void test2559() {
    coral.tests.JPFBenchmark.benchmark63(92.29993529383896,-70.39910026938901,-91.94573036155083,49.660384314150406,0 ) ;
  }

  @Test
  public void test2560() {
    coral.tests.JPFBenchmark.benchmark63(92.30925374297868,-78.05753621931133,-49.01669209006649,-78.3663016876908,0 ) ;
  }

  @Test
  public void test2561() {
    coral.tests.JPFBenchmark.benchmark63(92.3755278760488,-92.18134428702025,-89.33377928544913,60.008266995888704,0 ) ;
  }

  @Test
  public void test2562() {
    coral.tests.JPFBenchmark.benchmark63(92.37652158504577,-41.73618633177571,47.55704517478395,51.32877750644329,0 ) ;
  }

  @Test
  public void test2563() {
    coral.tests.JPFBenchmark.benchmark63(92.39700407475547,-50.08091861974062,-0.8704442503169503,22.796308068860952,0 ) ;
  }

  @Test
  public void test2564() {
    coral.tests.JPFBenchmark.benchmark63(92.41544006576066,-50.83899392594813,-47.63133966380428,94.71167376712509,0 ) ;
  }

  @Test
  public void test2565() {
    coral.tests.JPFBenchmark.benchmark63(92.43088579159635,-20.08739123536469,-49.82390799705465,-49.8234395165317,0 ) ;
  }

  @Test
  public void test2566() {
    coral.tests.JPFBenchmark.benchmark63(92.43620309855837,-86.77565309915084,89.91230502650907,-3.819281615076548,0 ) ;
  }

  @Test
  public void test2567() {
    coral.tests.JPFBenchmark.benchmark63(92.44032205929739,-48.08307221092652,69.38547105167933,-59.1330021224107,0 ) ;
  }

  @Test
  public void test2568() {
    coral.tests.JPFBenchmark.benchmark63(92.4491510690994,-83.51915055770516,62.88857696769617,39.48097978857032,0 ) ;
  }

  @Test
  public void test2569() {
    coral.tests.JPFBenchmark.benchmark63(92.46056172821838,-3.087887084345951,85.82382302373836,37.6708430634437,0 ) ;
  }

  @Test
  public void test2570() {
    coral.tests.JPFBenchmark.benchmark63(92.46514091466463,-70.69390682190175,71.43170872423477,-2.3629887714228204,0 ) ;
  }

  @Test
  public void test2571() {
    coral.tests.JPFBenchmark.benchmark63(92.49056867048765,-42.799769450408284,-57.03769127779672,85.90789949333782,0 ) ;
  }

  @Test
  public void test2572() {
    coral.tests.JPFBenchmark.benchmark63(92.49714651817143,-40.64000230757194,88.7690487630014,-80.590840561031,0 ) ;
  }

  @Test
  public void test2573() {
    coral.tests.JPFBenchmark.benchmark63(92.52116735429496,-10.400954725118766,-49.560969475555304,-58.80152583612792,0 ) ;
  }

  @Test
  public void test2574() {
    coral.tests.JPFBenchmark.benchmark63(92.53411907490917,-26.516815613335936,70.38099173575728,61.54959153003088,0 ) ;
  }

  @Test
  public void test2575() {
    coral.tests.JPFBenchmark.benchmark63(92.54127140786352,-42.151175639096316,-18.512676841722026,-90.46816770584664,0 ) ;
  }

  @Test
  public void test2576() {
    coral.tests.JPFBenchmark.benchmark63(92.5549542244313,-24.75261748740492,25.096974541543744,-42.541836046217554,0 ) ;
  }

  @Test
  public void test2577() {
    coral.tests.JPFBenchmark.benchmark63(92.56196694181455,-37.23850572299392,-79.8484456576835,48.735000049746276,0 ) ;
  }

  @Test
  public void test2578() {
    coral.tests.JPFBenchmark.benchmark63(92.59007931341827,-55.413526169199436,-63.94042832178415,-57.41706255725083,0 ) ;
  }

  @Test
  public void test2579() {
    coral.tests.JPFBenchmark.benchmark63(92.61052510060355,-79.82060827092354,-38.090494282303844,-74.06782585057046,0 ) ;
  }

  @Test
  public void test2580() {
    coral.tests.JPFBenchmark.benchmark63(92.61527814441402,-46.649551463066686,-14.765673054318711,90.45743217812787,0 ) ;
  }

  @Test
  public void test2581() {
    coral.tests.JPFBenchmark.benchmark63(92.61838373073181,-11.050422193121562,83.04964452720759,9.699241679155747,0 ) ;
  }

  @Test
  public void test2582() {
    coral.tests.JPFBenchmark.benchmark63(92.64080667965314,-25.672854351044606,52.900182705640844,-13.178010032033967,0 ) ;
  }

  @Test
  public void test2583() {
    coral.tests.JPFBenchmark.benchmark63(92.67953666118734,97.36098201742462,57.736074701247816,36.89031176977599,0 ) ;
  }

  @Test
  public void test2584() {
    coral.tests.JPFBenchmark.benchmark63(92.74159674177434,-92.52788340646066,-42.620875688741336,61.574227329431096,0 ) ;
  }

  @Test
  public void test2585() {
    coral.tests.JPFBenchmark.benchmark63(92.77088543836302,-21.99374315271669,-85.09783722408312,-19.189038841503333,0 ) ;
  }

  @Test
  public void test2586() {
    coral.tests.JPFBenchmark.benchmark63(92.77951307110419,-53.95854788434169,89.57108080060607,74.82231528863295,0 ) ;
  }

  @Test
  public void test2587() {
    coral.tests.JPFBenchmark.benchmark63(92.82397371576354,-40.60340179881976,3.2225482889886194,88.64443054009936,0 ) ;
  }

  @Test
  public void test2588() {
    coral.tests.JPFBenchmark.benchmark63(92.85734630924779,-67.56327272820263,-53.36174456558742,-88.47327184174137,0 ) ;
  }

  @Test
  public void test2589() {
    coral.tests.JPFBenchmark.benchmark63(92.87131079628611,-60.695405276335414,57.33018959884319,-10.153820868573575,0 ) ;
  }

  @Test
  public void test2590() {
    coral.tests.JPFBenchmark.benchmark63(92.89009142198822,-12.940914392250718,52.96072636852426,-38.11769106265028,0 ) ;
  }

  @Test
  public void test2591() {
    coral.tests.JPFBenchmark.benchmark63(92.90825421665494,-53.3769212405113,57.374355874370906,-42.24374809804996,0 ) ;
  }

  @Test
  public void test2592() {
    coral.tests.JPFBenchmark.benchmark63(92.90969771359863,-74.11176040621355,7.276758447321015,4.631236570955636,0 ) ;
  }

  @Test
  public void test2593() {
    coral.tests.JPFBenchmark.benchmark63(92.91169771019955,-20.768984544531534,66.35547535998313,88.34200461549818,0 ) ;
  }

  @Test
  public void test2594() {
    coral.tests.JPFBenchmark.benchmark63(92.94250872498651,-88.03573437584265,51.49264830790406,15.536811513617295,0 ) ;
  }

  @Test
  public void test2595() {
    coral.tests.JPFBenchmark.benchmark63(92.94358988397153,-43.64012252003047,1.5463016503990445,-61.70541858429994,0 ) ;
  }

  @Test
  public void test2596() {
    coral.tests.JPFBenchmark.benchmark63(92.95821456531823,-29.197673717749367,-4.571567311970838,-78.14408993566171,0 ) ;
  }

  @Test
  public void test2597() {
    coral.tests.JPFBenchmark.benchmark63(92.98548984196503,-18.88625073995118,-86.43318173981913,-2.7640376402445526,0 ) ;
  }

  @Test
  public void test2598() {
    coral.tests.JPFBenchmark.benchmark63(92.999730254952,-57.41334486825915,-87.04123335540643,-90.47243665169482,0 ) ;
  }

  @Test
  public void test2599() {
    coral.tests.JPFBenchmark.benchmark63(93.03483428175815,-63.59158646267722,20.57696953670562,-42.20531576780695,0 ) ;
  }

  @Test
  public void test2600() {
    coral.tests.JPFBenchmark.benchmark63(93.05920464141656,-50.66090936380731,-46.89924705087041,-9.06785948908042,0 ) ;
  }

  @Test
  public void test2601() {
    coral.tests.JPFBenchmark.benchmark63(93.06666975504226,-72.95993423449451,-44.04280045820084,19.841625482447284,0 ) ;
  }

  @Test
  public void test2602() {
    coral.tests.JPFBenchmark.benchmark63(93.06871766147964,-37.0669744097349,-62.11333552344398,-54.75816729759646,0 ) ;
  }

  @Test
  public void test2603() {
    coral.tests.JPFBenchmark.benchmark63(93.0860886372109,-50.80885416556698,-21.496106598529607,20.753066105174867,0 ) ;
  }

  @Test
  public void test2604() {
    coral.tests.JPFBenchmark.benchmark63(93.12844098202268,-43.2286869061367,98.75776724916471,-93.79410246158331,0 ) ;
  }

  @Test
  public void test2605() {
    coral.tests.JPFBenchmark.benchmark63(93.13625563512872,-4.125938141784346,69.86370243141607,43.883421501748046,0 ) ;
  }

  @Test
  public void test2606() {
    coral.tests.JPFBenchmark.benchmark63(93.1577121756331,-27.493242359410658,48.95796065142878,-22.25755532072162,0 ) ;
  }

  @Test
  public void test2607() {
    coral.tests.JPFBenchmark.benchmark63(93.1719415375374,-27.50978243566226,66.8885890113842,98.66031883381979,0 ) ;
  }

  @Test
  public void test2608() {
    coral.tests.JPFBenchmark.benchmark63(93.17759846477159,-51.21258124548689,-72.44196034242592,-91.79176849902322,0 ) ;
  }

  @Test
  public void test2609() {
    coral.tests.JPFBenchmark.benchmark63(93.19014606903355,-84.63451759763308,-76.56612559301006,-67.89082302984343,0 ) ;
  }

  @Test
  public void test2610() {
    coral.tests.JPFBenchmark.benchmark63(93.2086718023296,-83.55286268476137,-23.922896745388343,-47.054324192387796,0 ) ;
  }

  @Test
  public void test2611() {
    coral.tests.JPFBenchmark.benchmark63(93.25012772583835,-81.38229420152834,-43.289032280759955,36.38697645080805,0 ) ;
  }

  @Test
  public void test2612() {
    coral.tests.JPFBenchmark.benchmark63(93.26552854941275,-60.74040433256081,-36.65750945767261,-16.26424417046151,0 ) ;
  }

  @Test
  public void test2613() {
    coral.tests.JPFBenchmark.benchmark63(93.29445191407376,-88.62873459727467,34.20192262255159,-56.22077701145061,0 ) ;
  }

  @Test
  public void test2614() {
    coral.tests.JPFBenchmark.benchmark63(93.31962411700559,-74.16927177310248,-83.93294911317575,55.49135089875392,0 ) ;
  }

  @Test
  public void test2615() {
    coral.tests.JPFBenchmark.benchmark63(93.32638695986489,-28.034430061804613,-1.6043638129440012,-27.607365713300098,0 ) ;
  }

  @Test
  public void test2616() {
    coral.tests.JPFBenchmark.benchmark63(93.32693180487772,-9.32466009193709,-68.86637353436977,-31.119018378688068,0 ) ;
  }

  @Test
  public void test2617() {
    coral.tests.JPFBenchmark.benchmark63(93.32981793558531,-18.012403414693352,55.57086353341731,-55.4644952325507,0 ) ;
  }

  @Test
  public void test2618() {
    coral.tests.JPFBenchmark.benchmark63(93.36523769615718,-84.24784618904373,-90.10607921097262,97.18542924290358,0 ) ;
  }

  @Test
  public void test2619() {
    coral.tests.JPFBenchmark.benchmark63(93.38275671443012,-9.011520866112093,85.1387138967466,-78.12792679304441,0 ) ;
  }

  @Test
  public void test2620() {
    coral.tests.JPFBenchmark.benchmark63(93.38371590478883,-64.12174669869944,13.269460092901568,15.622893909272719,0 ) ;
  }

  @Test
  public void test2621() {
    coral.tests.JPFBenchmark.benchmark63(93.39053758472275,-60.99282483487818,85.61183424395645,30.56058790561815,0 ) ;
  }

  @Test
  public void test2622() {
    coral.tests.JPFBenchmark.benchmark63(93.4195464602416,-61.00083945711936,95.0278949804256,-72.92208119368826,0 ) ;
  }

  @Test
  public void test2623() {
    coral.tests.JPFBenchmark.benchmark63(93.41972583509735,-65.94565767510818,-28.35688914315675,83.81350973615156,0 ) ;
  }

  @Test
  public void test2624() {
    coral.tests.JPFBenchmark.benchmark63(93.43210713421055,-56.46380817853327,-46.79944762288004,7.3362904781254485,0 ) ;
  }

  @Test
  public void test2625() {
    coral.tests.JPFBenchmark.benchmark63(93.4718934947116,-91.20018383045682,93.04635141836212,-93.04751468424037,0 ) ;
  }

  @Test
  public void test2626() {
    coral.tests.JPFBenchmark.benchmark63(93.4953396719529,-18.863375366784865,-88.09755209775409,85.26410025480297,0 ) ;
  }

  @Test
  public void test2627() {
    coral.tests.JPFBenchmark.benchmark63(93.56530064340419,-57.921897413833115,-87.88474532161368,50.31149145950579,0 ) ;
  }

  @Test
  public void test2628() {
    coral.tests.JPFBenchmark.benchmark63(93.58911274346045,-30.243197538360334,-60.13667066195689,97.37303392809835,0 ) ;
  }

  @Test
  public void test2629() {
    coral.tests.JPFBenchmark.benchmark63(93.59532368528158,-56.87584459972375,-36.21378239320387,-45.527333948804305,0 ) ;
  }

  @Test
  public void test2630() {
    coral.tests.JPFBenchmark.benchmark63(93.59969810837373,-41.82510312348913,83.53163307215303,40.52969359939536,0 ) ;
  }

  @Test
  public void test2631() {
    coral.tests.JPFBenchmark.benchmark63(93.61596720981024,-46.114814796075535,71.59986417563042,-60.4766177524638,0 ) ;
  }

  @Test
  public void test2632() {
    coral.tests.JPFBenchmark.benchmark63(93.62183444168514,-17.455335226381578,62.81068032512164,-0.11443291457425175,0 ) ;
  }

  @Test
  public void test2633() {
    coral.tests.JPFBenchmark.benchmark63(93.64589151759489,-25.187719347426736,52.15739617328353,65.42061557393603,0 ) ;
  }

  @Test
  public void test2634() {
    coral.tests.JPFBenchmark.benchmark63(93.65024021599964,-41.73952654596707,-62.35682953135275,16.51417943207774,0 ) ;
  }

  @Test
  public void test2635() {
    coral.tests.JPFBenchmark.benchmark63(93.66458920966883,-57.49081818474551,79.73542229472781,20.42069813602916,0 ) ;
  }

  @Test
  public void test2636() {
    coral.tests.JPFBenchmark.benchmark63(93.67677707801121,-72.520515942653,-28.471571407656256,-24.124188539675202,0 ) ;
  }

  @Test
  public void test2637() {
    coral.tests.JPFBenchmark.benchmark63(93.7376842040826,-86.56400488234699,-41.777984446513706,-25.768525424192518,0 ) ;
  }

  @Test
  public void test2638() {
    coral.tests.JPFBenchmark.benchmark63(93.74044576194947,-11.58097263154157,-31.25779567431121,89.23537837986203,0 ) ;
  }

  @Test
  public void test2639() {
    coral.tests.JPFBenchmark.benchmark63(93.74103110195361,-42.41359568745049,-63.88462686358709,31.47514222914782,0 ) ;
  }

  @Test
  public void test2640() {
    coral.tests.JPFBenchmark.benchmark63(93.74336655580373,-63.85869419829919,36.12645544013256,95.02315655228378,0 ) ;
  }

  @Test
  public void test2641() {
    coral.tests.JPFBenchmark.benchmark63(93.76929647721303,-21.96938889732114,-8.369751635058535,33.18748059686459,0 ) ;
  }

  @Test
  public void test2642() {
    coral.tests.JPFBenchmark.benchmark63(93.77773182058638,-8.675405263964137,34.45295275732943,-98.59882913015416,0 ) ;
  }

  @Test
  public void test2643() {
    coral.tests.JPFBenchmark.benchmark63(93.79906772206147,-34.6819964089605,-13.088303680526977,17.99810979659739,0 ) ;
  }

  @Test
  public void test2644() {
    coral.tests.JPFBenchmark.benchmark63(93.81205228648253,-83.62310002251014,10.441742148491358,15.410881923312928,0 ) ;
  }

  @Test
  public void test2645() {
    coral.tests.JPFBenchmark.benchmark63(93.82563664793128,-26.92458800558002,-32.43997160526722,50.76447467701317,0 ) ;
  }

  @Test
  public void test2646() {
    coral.tests.JPFBenchmark.benchmark63(93.86664967063919,-53.45837738526047,19.688690916544928,61.58492046534752,0 ) ;
  }

  @Test
  public void test2647() {
    coral.tests.JPFBenchmark.benchmark63(93.91714783276046,-51.969427002393154,42.70494507001635,22.322051709357638,0 ) ;
  }

  @Test
  public void test2648() {
    coral.tests.JPFBenchmark.benchmark63(93.92759730112942,-3.8324331395280637,76.84939036472463,-60.64232862443366,0 ) ;
  }

  @Test
  public void test2649() {
    coral.tests.JPFBenchmark.benchmark63(93.93458386581216,-59.13145463802798,-81.9955244887444,-44.71881166834617,0 ) ;
  }

  @Test
  public void test2650() {
    coral.tests.JPFBenchmark.benchmark63(93.95348828950921,-33.92347325515483,48.469365662897644,97.71339946069335,0 ) ;
  }

  @Test
  public void test2651() {
    coral.tests.JPFBenchmark.benchmark63(93.9616015314536,-44.78170771018186,-62.26911987815369,55.095961216516,0 ) ;
  }

  @Test
  public void test2652() {
    coral.tests.JPFBenchmark.benchmark63(93.97970053014001,-52.3477044361371,82.81995848316066,-39.071767893456766,0 ) ;
  }

  @Test
  public void test2653() {
    coral.tests.JPFBenchmark.benchmark63(93.98168060605917,-70.25209271188368,-56.61247086026009,-89.71267711196032,0 ) ;
  }

  @Test
  public void test2654() {
    coral.tests.JPFBenchmark.benchmark63(93.99292589764653,-54.69311423491647,-13.58509955747526,20.403216071274954,0 ) ;
  }

  @Test
  public void test2655() {
    coral.tests.JPFBenchmark.benchmark63(94.01578743224579,-79.32224350675618,-81.45150086880504,-55.51340630227062,0 ) ;
  }

  @Test
  public void test2656() {
    coral.tests.JPFBenchmark.benchmark63(94.01819608300178,-27.108975226590545,65.64562875708526,79.1611221052172,0 ) ;
  }

  @Test
  public void test2657() {
    coral.tests.JPFBenchmark.benchmark63(94.0223795623784,-32.367929659474086,-40.9381174391658,21.68343978062326,0 ) ;
  }

  @Test
  public void test2658() {
    coral.tests.JPFBenchmark.benchmark63(94.02358459505305,-76.00543666406851,-99.74354074843772,81.65310669074935,0 ) ;
  }

  @Test
  public void test2659() {
    coral.tests.JPFBenchmark.benchmark63(94.03032713456614,-65.72874990920157,-5.860437406804991,-46.4329357067333,0 ) ;
  }

  @Test
  public void test2660() {
    coral.tests.JPFBenchmark.benchmark63(94.04171808695295,-67.99734391317247,-41.21453653537368,86.29531058500288,0 ) ;
  }

  @Test
  public void test2661() {
    coral.tests.JPFBenchmark.benchmark63(94.050047553311,-24.463165812838554,-93.4431229576335,-2.410737587116074,0 ) ;
  }

  @Test
  public void test2662() {
    coral.tests.JPFBenchmark.benchmark63(94.0540617182651,-70.23812461713612,29.883782067999988,8.015582393910776,0 ) ;
  }

  @Test
  public void test2663() {
    coral.tests.JPFBenchmark.benchmark63(94.0709755244014,-24.981426208042336,52.580662567652865,66.9101753826894,0 ) ;
  }

  @Test
  public void test2664() {
    coral.tests.JPFBenchmark.benchmark63(94.08597613719354,-50.497962364527396,29.2459359770329,76.87545784104807,0 ) ;
  }

  @Test
  public void test2665() {
    coral.tests.JPFBenchmark.benchmark63(94.08724268455856,-77.79886434575363,-59.76021263245672,88.11581833194927,0 ) ;
  }

  @Test
  public void test2666() {
    coral.tests.JPFBenchmark.benchmark63(94.09157477509288,-17.202923039482073,77.59027858262263,88.58921227414095,0 ) ;
  }

  @Test
  public void test2667() {
    coral.tests.JPFBenchmark.benchmark63(94.09388620141434,-42.51442661315039,9.296832157782319,-13.053237428285769,0 ) ;
  }

  @Test
  public void test2668() {
    coral.tests.JPFBenchmark.benchmark63(94.13183120432322,-63.12881578300802,25.017043742259034,-39.747505620784686,0 ) ;
  }

  @Test
  public void test2669() {
    coral.tests.JPFBenchmark.benchmark63(94.14662318364134,-35.31058659027542,-44.11553501420058,62.61946517774601,0 ) ;
  }

  @Test
  public void test2670() {
    coral.tests.JPFBenchmark.benchmark63(94.16733621751729,-70.2594590610664,-47.6274810613394,-14.719894966818984,0 ) ;
  }

  @Test
  public void test2671() {
    coral.tests.JPFBenchmark.benchmark63(94.17437229356568,-38.504716178777066,6.567517799218763,18.246667268071576,0 ) ;
  }

  @Test
  public void test2672() {
    coral.tests.JPFBenchmark.benchmark63(94.19862312016033,-80.75054163678246,-92.8053736034469,-15.783101270538253,0 ) ;
  }

  @Test
  public void test2673() {
    coral.tests.JPFBenchmark.benchmark63(94.2046407337804,-22.068806579882462,29.857131536218844,32.821559966380335,0 ) ;
  }

  @Test
  public void test2674() {
    coral.tests.JPFBenchmark.benchmark63(94.20882313699684,-36.57260924709313,-46.479283199166964,2.492180499996465,0 ) ;
  }

  @Test
  public void test2675() {
    coral.tests.JPFBenchmark.benchmark63(94.22681180589669,-67.7609039455589,-43.16480886294325,-92.0123681764736,0 ) ;
  }

  @Test
  public void test2676() {
    coral.tests.JPFBenchmark.benchmark63(94.2273235824176,-19.137580061810922,-60.99024238108868,-59.82206801975516,0 ) ;
  }

  @Test
  public void test2677() {
    coral.tests.JPFBenchmark.benchmark63(94.27084771047569,-22.778373708760412,37.19891669312102,54.606377978782035,0 ) ;
  }

  @Test
  public void test2678() {
    coral.tests.JPFBenchmark.benchmark63(94.3051047303774,-5.743942696469716,-34.024197505065246,-83.15147744224024,0 ) ;
  }

  @Test
  public void test2679() {
    coral.tests.JPFBenchmark.benchmark63(94.35598465839695,-44.29837182013121,13.37627681788949,26.653118136237325,0 ) ;
  }

  @Test
  public void test2680() {
    coral.tests.JPFBenchmark.benchmark63(94.37983010064352,-87.02856708730556,22.04222166203158,81.9477122675618,0 ) ;
  }

  @Test
  public void test2681() {
    coral.tests.JPFBenchmark.benchmark63(94.41602485288968,-46.132512315754546,-63.68871618980363,-82.61046813034645,0 ) ;
  }

  @Test
  public void test2682() {
    coral.tests.JPFBenchmark.benchmark63(94.42775655450157,-16.217923835605546,86.85102477308487,-63.222863656330034,0 ) ;
  }

  @Test
  public void test2683() {
    coral.tests.JPFBenchmark.benchmark63(94.46673042406849,-28.346513759482022,54.83611322248581,-67.90117126977104,0 ) ;
  }

  @Test
  public void test2684() {
    coral.tests.JPFBenchmark.benchmark63(94.47236564062885,-59.841054792191926,9.086325525055727,-50.32488843681904,0 ) ;
  }

  @Test
  public void test2685() {
    coral.tests.JPFBenchmark.benchmark63(94.48888092060423,-74.46969467555036,-78.65180905261873,87.97300381529419,0 ) ;
  }

  @Test
  public void test2686() {
    coral.tests.JPFBenchmark.benchmark63(94.49594071043995,-81.55808918550973,-15.0685054099783,-60.44597518862076,0 ) ;
  }

  @Test
  public void test2687() {
    coral.tests.JPFBenchmark.benchmark63(94.52639576399375,-22.29566854362399,48.8072796643734,42.486112534601006,0 ) ;
  }

  @Test
  public void test2688() {
    coral.tests.JPFBenchmark.benchmark63(94.52966313781067,-66.28002942052669,7.515047650982808,1.5777427606989818,0 ) ;
  }

  @Test
  public void test2689() {
    coral.tests.JPFBenchmark.benchmark63(94.53266091262859,-81.03719675049324,-91.0618203078422,83.69181435627524,0 ) ;
  }

  @Test
  public void test2690() {
    coral.tests.JPFBenchmark.benchmark63(94.598412247324,-48.566050733052045,84.93372780845948,54.475246020616936,0 ) ;
  }

  @Test
  public void test2691() {
    coral.tests.JPFBenchmark.benchmark63(94.61538933087965,-47.952127990759806,-49.55602491311224,-7.477755662083553,0 ) ;
  }

  @Test
  public void test2692() {
    coral.tests.JPFBenchmark.benchmark63(94.6375302094873,-26.507107905917763,-40.780972540641855,37.27069781442887,0 ) ;
  }

  @Test
  public void test2693() {
    coral.tests.JPFBenchmark.benchmark63(94.6729641125929,-51.8769165125824,98.84136500909389,70.59803790629516,0 ) ;
  }

  @Test
  public void test2694() {
    coral.tests.JPFBenchmark.benchmark63(94.72934090494951,-90.84772666505951,53.8844695166876,89.68929442184933,0 ) ;
  }

  @Test
  public void test2695() {
    coral.tests.JPFBenchmark.benchmark63(94.7643860052431,-86.58811796822592,13.862147976562085,86.20124148864846,0 ) ;
  }

  @Test
  public void test2696() {
    coral.tests.JPFBenchmark.benchmark63(94.76457007226455,-71.61147489817961,18.148875454354013,-37.94365488225422,0 ) ;
  }

  @Test
  public void test2697() {
    coral.tests.JPFBenchmark.benchmark63(94.77497801931568,-98.85498277153806,-34.79872017145071,5.797766694901682,0 ) ;
  }

  @Test
  public void test2698() {
    coral.tests.JPFBenchmark.benchmark63(94.79270854362949,-18.05306979850785,3.8017118577436975,43.49915506198499,0 ) ;
  }

  @Test
  public void test2699() {
    coral.tests.JPFBenchmark.benchmark63(94.80730601996504,-64.89413666964572,-52.01878509994633,-27.820809525066807,0 ) ;
  }

  @Test
  public void test2700() {
    coral.tests.JPFBenchmark.benchmark63(94.82034937294753,-21.13292199046961,74.4978336758328,-33.1577437013505,0 ) ;
  }

  @Test
  public void test2701() {
    coral.tests.JPFBenchmark.benchmark63(94.82569255336566,-82.06907132477198,83.22009606473,64.3548501680884,0 ) ;
  }

  @Test
  public void test2702() {
    coral.tests.JPFBenchmark.benchmark63(94.83259397539746,-84.12838022295574,-36.562031881376164,26.092635974880167,0 ) ;
  }

  @Test
  public void test2703() {
    coral.tests.JPFBenchmark.benchmark63(94.84211597801021,-48.81708538393947,57.58567233160477,99.56710001170597,0 ) ;
  }

  @Test
  public void test2704() {
    coral.tests.JPFBenchmark.benchmark63(94.84535293548666,-50.01633426001864,-96.31240409829212,3.66857013968405,0 ) ;
  }

  @Test
  public void test2705() {
    coral.tests.JPFBenchmark.benchmark63(94.85212271548951,-19.990648511366544,-8.491210645323747,-17.224702866089274,0 ) ;
  }

  @Test
  public void test2706() {
    coral.tests.JPFBenchmark.benchmark63(94.85543427207955,-89.86583373690611,99.62421365403446,32.85776609174556,0 ) ;
  }

  @Test
  public void test2707() {
    coral.tests.JPFBenchmark.benchmark63(94.90064268661493,-94.06580047786602,-46.95516429259017,2.330511848394906,0 ) ;
  }

  @Test
  public void test2708() {
    coral.tests.JPFBenchmark.benchmark63(94.90759590721001,-45.60021919711601,-81.74354749725548,73.70093006257827,0 ) ;
  }

  @Test
  public void test2709() {
    coral.tests.JPFBenchmark.benchmark63(94.91190229392635,-3.3023304781793428,47.81727506167513,8.2183425642761,0 ) ;
  }

  @Test
  public void test2710() {
    coral.tests.JPFBenchmark.benchmark63(94.91354896395143,-44.49152091774704,54.72550108388677,8.962803394182245,0 ) ;
  }

  @Test
  public void test2711() {
    coral.tests.JPFBenchmark.benchmark63(94.91645795070559,-51.8238107284599,80.72109662157797,-6.4543689576997565,0 ) ;
  }

  @Test
  public void test2712() {
    coral.tests.JPFBenchmark.benchmark63(94.91651213823263,-57.95345178730391,-89.97199807771665,94.98477752649151,0 ) ;
  }

  @Test
  public void test2713() {
    coral.tests.JPFBenchmark.benchmark63(94.92522310870254,-46.431625531837526,15.154149918354108,53.70034412512149,0 ) ;
  }

  @Test
  public void test2714() {
    coral.tests.JPFBenchmark.benchmark63(94.96462088666843,-51.80461283153968,34.028402255251734,69.51038297066415,0 ) ;
  }

  @Test
  public void test2715() {
    coral.tests.JPFBenchmark.benchmark63(94.9795871870084,-79.92546423475007,57.27182280967719,25.360194418619713,0 ) ;
  }

  @Test
  public void test2716() {
    coral.tests.JPFBenchmark.benchmark63(94.98752274987464,-90.5821491155797,22.58412538696801,-21.772905641821126,0 ) ;
  }

  @Test
  public void test2717() {
    coral.tests.JPFBenchmark.benchmark63(95.01102935769697,-54.91391217393809,37.604883819119806,-40.38417755301873,0 ) ;
  }

  @Test
  public void test2718() {
    coral.tests.JPFBenchmark.benchmark63(95.0154149477255,-88.63821656071242,61.7356213955473,-66.545937880884,0 ) ;
  }

  @Test
  public void test2719() {
    coral.tests.JPFBenchmark.benchmark63(95.03882407827561,-18.964971175196354,-85.19967311402795,58.891168289221895,0 ) ;
  }

  @Test
  public void test2720() {
    coral.tests.JPFBenchmark.benchmark63(95.06514413743764,-32.61485195345146,19.99374966118627,19.31882741390541,0 ) ;
  }

  @Test
  public void test2721() {
    coral.tests.JPFBenchmark.benchmark63(95.08139333025136,-48.79402344826338,-64.58435110341264,34.49056694578982,0 ) ;
  }

  @Test
  public void test2722() {
    coral.tests.JPFBenchmark.benchmark63(95.08653267072285,-94.54089219696601,20.257033493556122,-44.266390245153,0 ) ;
  }

  @Test
  public void test2723() {
    coral.tests.JPFBenchmark.benchmark63(95.08709720073142,-22.08068317901899,-71.06892363797823,-97.945902322747,0 ) ;
  }

  @Test
  public void test2724() {
    coral.tests.JPFBenchmark.benchmark63(95.08859235863284,-83.79177427916147,15.956785156416402,53.860945153566206,0 ) ;
  }

  @Test
  public void test2725() {
    coral.tests.JPFBenchmark.benchmark63(95.1194671432797,-19.949253965695306,23.45199580364381,95.3206155069631,0 ) ;
  }

  @Test
  public void test2726() {
    coral.tests.JPFBenchmark.benchmark63(95.12781989692726,-5.631332797098338,90.21647677945941,-97.92094161378759,0 ) ;
  }

  @Test
  public void test2727() {
    coral.tests.JPFBenchmark.benchmark63(95.13315375792226,-67.67495484672108,-45.68696508339731,-67.62676628782177,0 ) ;
  }

  @Test
  public void test2728() {
    coral.tests.JPFBenchmark.benchmark63(95.1720364945343,-92.38334620256046,-45.44120650348802,54.7422681637112,0 ) ;
  }

  @Test
  public void test2729() {
    coral.tests.JPFBenchmark.benchmark63(95.18849928054692,-63.29104840492494,-82.26916368937086,-86.21432088944343,0 ) ;
  }

  @Test
  public void test2730() {
    coral.tests.JPFBenchmark.benchmark63(95.20615545098883,-80.70282423467631,-6.715177735206865,68.49441432403395,0 ) ;
  }

  @Test
  public void test2731() {
    coral.tests.JPFBenchmark.benchmark63(95.26609302025096,-95.3956345977159,-58.389405570481756,86.70086422199452,0 ) ;
  }

  @Test
  public void test2732() {
    coral.tests.JPFBenchmark.benchmark63(95.26626396422651,-29.473902483850907,97.08830028369002,15.268315743846955,0 ) ;
  }

  @Test
  public void test2733() {
    coral.tests.JPFBenchmark.benchmark63(95.2791992361893,-66.96780666560021,23.660888180264948,-15.198401125910692,0 ) ;
  }

  @Test
  public void test2734() {
    coral.tests.JPFBenchmark.benchmark63(95.28519458481287,-53.94346976713922,15.554927142242462,68.08581614137947,0 ) ;
  }

  @Test
  public void test2735() {
    coral.tests.JPFBenchmark.benchmark63(95.30298526639024,-88.86659157880659,22.470634214279457,-56.550670326601264,0 ) ;
  }

  @Test
  public void test2736() {
    coral.tests.JPFBenchmark.benchmark63(95.30406783006887,-51.15858620080316,-21.630175603260724,98.80970745939851,0 ) ;
  }

  @Test
  public void test2737() {
    coral.tests.JPFBenchmark.benchmark63(95.30440275746938,-11.973873455019017,-11.243483981636302,86.45025540745871,0 ) ;
  }

  @Test
  public void test2738() {
    coral.tests.JPFBenchmark.benchmark63(95.30697799705493,-26.0503689370871,24.86567661766155,-7.7551584561779805,0 ) ;
  }

  @Test
  public void test2739() {
    coral.tests.JPFBenchmark.benchmark63(95.31657215533636,-28.458121390236713,61.929192762838056,-7.895662272465216,0 ) ;
  }

  @Test
  public void test2740() {
    coral.tests.JPFBenchmark.benchmark63(95.31799465330502,-82.05896732685969,-82.79461832818605,-79.75071319710656,0 ) ;
  }

  @Test
  public void test2741() {
    coral.tests.JPFBenchmark.benchmark63(95.33039388949493,-93.8383329895107,-19.748775418660472,14.798241580918287,0 ) ;
  }

  @Test
  public void test2742() {
    coral.tests.JPFBenchmark.benchmark63(95.33248982786819,-18.95920772738164,70.83295042405493,-64.8403216164312,0 ) ;
  }

  @Test
  public void test2743() {
    coral.tests.JPFBenchmark.benchmark63(95.3847752363379,-22.75738489905072,93.96122425437483,-57.12097242385133,0 ) ;
  }

  @Test
  public void test2744() {
    coral.tests.JPFBenchmark.benchmark63(95.38531651562278,-12.400193533457752,-0.9091650599122971,-62.83110906095726,0 ) ;
  }

  @Test
  public void test2745() {
    coral.tests.JPFBenchmark.benchmark63(95.47692057905607,-62.73220117115612,29.70635547107213,42.07822041516306,0 ) ;
  }

  @Test
  public void test2746() {
    coral.tests.JPFBenchmark.benchmark63(95.5003936939807,-72.07937087623199,58.276954927737904,-79.14523682101395,0 ) ;
  }

  @Test
  public void test2747() {
    coral.tests.JPFBenchmark.benchmark63(95.5210042950921,-61.163828357763904,-49.343606198242384,47.306100202254356,0 ) ;
  }

  @Test
  public void test2748() {
    coral.tests.JPFBenchmark.benchmark63(95.54824521799588,-94.48297259131667,-41.51717011242955,-81.13557358484394,0 ) ;
  }

  @Test
  public void test2749() {
    coral.tests.JPFBenchmark.benchmark63(95.55330170154403,-51.46230321722338,73.4356000239425,54.78286794730306,0 ) ;
  }

  @Test
  public void test2750() {
    coral.tests.JPFBenchmark.benchmark63(95.55647718774463,-48.107522610371966,93.63288562524914,44.85379794577804,0 ) ;
  }

  @Test
  public void test2751() {
    coral.tests.JPFBenchmark.benchmark63(95.564336279896,-62.483494564127405,-55.54632438242761,-20.331291582979944,0 ) ;
  }

  @Test
  public void test2752() {
    coral.tests.JPFBenchmark.benchmark63(95.62472707438954,-5.314159985980211,43.3752077168682,-78.94502062816142,0 ) ;
  }

  @Test
  public void test2753() {
    coral.tests.JPFBenchmark.benchmark63(95.63728803191134,-33.12610965476608,-61.43395464205279,-50.232019299334475,0 ) ;
  }

  @Test
  public void test2754() {
    coral.tests.JPFBenchmark.benchmark63(95.6503518537308,-6.518984421528785,7.565821356954089,3.52083073867486,0 ) ;
  }

  @Test
  public void test2755() {
    coral.tests.JPFBenchmark.benchmark63(95.65906747946715,-54.02318531964816,5.332672081752918,34.24041134515366,0 ) ;
  }

  @Test
  public void test2756() {
    coral.tests.JPFBenchmark.benchmark63(95.66020532372525,-40.929203387357546,90.86748488098686,35.90824387911729,0 ) ;
  }

  @Test
  public void test2757() {
    coral.tests.JPFBenchmark.benchmark63(95.66178958259181,-93.84501514005872,-48.83502183692976,-74.7704690133121,0 ) ;
  }

  @Test
  public void test2758() {
    coral.tests.JPFBenchmark.benchmark63(95.67804823513163,-87.1774842942208,-57.35743140730201,-19.11781106266774,0 ) ;
  }

  @Test
  public void test2759() {
    coral.tests.JPFBenchmark.benchmark63(95.680210043756,-29.382646306663702,-97.76806589139156,92.31737580951582,0 ) ;
  }

  @Test
  public void test2760() {
    coral.tests.JPFBenchmark.benchmark63(95.69468922919009,-66.4140312985227,37.190304269029355,16.38158441415318,0 ) ;
  }

  @Test
  public void test2761() {
    coral.tests.JPFBenchmark.benchmark63(95.72816680415633,-72.85872554041796,-72.6664754847352,16.2170286566282,0 ) ;
  }

  @Test
  public void test2762() {
    coral.tests.JPFBenchmark.benchmark63(95.7602143047672,-46.46911735843757,-24.44459233358201,-45.26485527159218,0 ) ;
  }

  @Test
  public void test2763() {
    coral.tests.JPFBenchmark.benchmark63(95.77618300252496,-69.73579147269409,83.37973579027582,67.02934215452362,0 ) ;
  }

  @Test
  public void test2764() {
    coral.tests.JPFBenchmark.benchmark63(95.78430023301411,-3.9211273053372224,-24.915404813978242,-70.16366509655154,0 ) ;
  }

  @Test
  public void test2765() {
    coral.tests.JPFBenchmark.benchmark63(95.79264122072291,-2.2412367862659153,-1.663503460558374,-9.067670785956494,0 ) ;
  }

  @Test
  public void test2766() {
    coral.tests.JPFBenchmark.benchmark63(95.80599142613622,-92.14576519609751,4.653586367704051,19.618304759229616,0 ) ;
  }

  @Test
  public void test2767() {
    coral.tests.JPFBenchmark.benchmark63(95.80955142589417,-88.75286862560048,-3.039704519659182,-88.17711715431189,0 ) ;
  }

  @Test
  public void test2768() {
    coral.tests.JPFBenchmark.benchmark63(95.82822441868245,-82.48972745841706,-79.95301196247762,-71.26893703755385,0 ) ;
  }

  @Test
  public void test2769() {
    coral.tests.JPFBenchmark.benchmark63(95.83252833561323,-21.719879770515433,-87.09546228025269,92.22029727825557,0 ) ;
  }

  @Test
  public void test2770() {
    coral.tests.JPFBenchmark.benchmark63(95.8355999347308,-8.667537656423605,21.507691119823676,-77.88530034179911,0 ) ;
  }

  @Test
  public void test2771() {
    coral.tests.JPFBenchmark.benchmark63(95.8618656521293,-14.065931004550023,-46.859072800754234,-44.993760944770834,0 ) ;
  }

  @Test
  public void test2772() {
    coral.tests.JPFBenchmark.benchmark63(95.8818696039589,-34.17098531947124,-63.56989815150218,67.8341427425814,0 ) ;
  }

  @Test
  public void test2773() {
    coral.tests.JPFBenchmark.benchmark63(95.88352302593665,-55.26492127467009,-36.64843103905871,22.016027140917856,0 ) ;
  }

  @Test
  public void test2774() {
    coral.tests.JPFBenchmark.benchmark63(95.88568185680973,-33.09678725130203,-64.23757337705675,-4.524977208103692,0 ) ;
  }

  @Test
  public void test2775() {
    coral.tests.JPFBenchmark.benchmark63(95.90296722150103,-19.173500279738292,43.040833417416366,48.02502044211619,0 ) ;
  }

  @Test
  public void test2776() {
    coral.tests.JPFBenchmark.benchmark63(95.91819814674687,-76.15325015511523,51.32509724463472,39.98656254598524,0 ) ;
  }

  @Test
  public void test2777() {
    coral.tests.JPFBenchmark.benchmark63(95.92024377686838,-58.13780728439786,-78.47352679567749,99.1682670011871,0 ) ;
  }

  @Test
  public void test2778() {
    coral.tests.JPFBenchmark.benchmark63(95.92657956868223,-67.01902678761195,7.680616306527256,-4.311436651923259,0 ) ;
  }

  @Test
  public void test2779() {
    coral.tests.JPFBenchmark.benchmark63(95.9335421814421,-48.42318682771554,93.88142328226655,55.37045437300151,0 ) ;
  }

  @Test
  public void test2780() {
    coral.tests.JPFBenchmark.benchmark63(95.93584767720913,-76.0927305807511,19.309091349854697,35.012055651031744,0 ) ;
  }

  @Test
  public void test2781() {
    coral.tests.JPFBenchmark.benchmark63(95.93845066218728,-83.67139781351315,45.2485883728701,-57.37843354328227,0 ) ;
  }

  @Test
  public void test2782() {
    coral.tests.JPFBenchmark.benchmark63(95.95714404949825,-10.56412028858469,-63.168775868293594,22.100738298505647,0 ) ;
  }

  @Test
  public void test2783() {
    coral.tests.JPFBenchmark.benchmark63(95.98270428258138,-55.05340288292733,38.61992904822279,15.798668633355021,0 ) ;
  }

  @Test
  public void test2784() {
    coral.tests.JPFBenchmark.benchmark63(95.9834394647801,-38.26355889533912,26.313937470558812,19.717154045060965,0 ) ;
  }

  @Test
  public void test2785() {
    coral.tests.JPFBenchmark.benchmark63(95.99902787690752,-91.72561019076812,-11.012281682218415,-47.701400127238756,0 ) ;
  }

  @Test
  public void test2786() {
    coral.tests.JPFBenchmark.benchmark63(96.05029018830811,-7.98890818321631,9.509562224620822,34.39496043339332,0 ) ;
  }

  @Test
  public void test2787() {
    coral.tests.JPFBenchmark.benchmark63(96.06428823740609,-58.05023490112606,75.64304760094018,-93.50300905991034,0 ) ;
  }

  @Test
  public void test2788() {
    coral.tests.JPFBenchmark.benchmark63(96.08777075002106,-95.00256472586553,-74.6633416885067,42.58324412657575,0 ) ;
  }

  @Test
  public void test2789() {
    coral.tests.JPFBenchmark.benchmark63(96.09177713646582,-93.69057550475175,36.38651958607366,-43.28072718687967,0 ) ;
  }

  @Test
  public void test2790() {
    coral.tests.JPFBenchmark.benchmark63(96.09794251158107,-14.54861289450264,-89.0718597212917,-78.78518421107835,0 ) ;
  }

  @Test
  public void test2791() {
    coral.tests.JPFBenchmark.benchmark63(96.1423361861008,-43.08667276446063,-50.53664109341061,-49.881436891620126,0 ) ;
  }

  @Test
  public void test2792() {
    coral.tests.JPFBenchmark.benchmark63(96.16756654361217,-46.3447236964887,93.15700051339763,54.450320332236515,0 ) ;
  }

  @Test
  public void test2793() {
    coral.tests.JPFBenchmark.benchmark63(96.17304142797877,-48.12076072740916,-86.60302678605014,-24.236940027153395,0 ) ;
  }

  @Test
  public void test2794() {
    coral.tests.JPFBenchmark.benchmark63(96.18963293882493,-7.640353162325567,-58.88989187440961,-85.28534467450012,0 ) ;
  }

  @Test
  public void test2795() {
    coral.tests.JPFBenchmark.benchmark63(96.26551183610886,-17.05909384740339,42.05896720199229,43.41307833000465,0 ) ;
  }

  @Test
  public void test2796() {
    coral.tests.JPFBenchmark.benchmark63(96.27680140939216,-8.168078534429227,53.44165506260666,-98.51487140992346,0 ) ;
  }

  @Test
  public void test2797() {
    coral.tests.JPFBenchmark.benchmark63(96.27809583453887,-76.71050123433204,12.027559263566758,-43.01516320287839,0 ) ;
  }

  @Test
  public void test2798() {
    coral.tests.JPFBenchmark.benchmark63(96.2905197439,-72.49330615114562,96.20174276856605,90.3009345907337,0 ) ;
  }

  @Test
  public void test2799() {
    coral.tests.JPFBenchmark.benchmark63(96.3041150964444,-79.87658496243277,-49.425107120300304,33.13337730976269,0 ) ;
  }

  @Test
  public void test2800() {
    coral.tests.JPFBenchmark.benchmark63(96.30532621083958,-90.5004484012828,-52.92513697630501,43.917627944966114,0 ) ;
  }

  @Test
  public void test2801() {
    coral.tests.JPFBenchmark.benchmark63(96.30921660016483,-78.78092606738022,19.652932907730758,-47.98566288198207,0 ) ;
  }

  @Test
  public void test2802() {
    coral.tests.JPFBenchmark.benchmark63(96.31193417992446,-72.06299203287061,-26.268174232241904,90.9690204829408,0 ) ;
  }

  @Test
  public void test2803() {
    coral.tests.JPFBenchmark.benchmark63(96.34226290507166,-27.337892615452432,-49.023585040978816,-42.44138708698604,0 ) ;
  }

  @Test
  public void test2804() {
    coral.tests.JPFBenchmark.benchmark63(96.35457187931218,-33.43877029914573,4.280402057597385,-1.4602710606822882,0 ) ;
  }

  @Test
  public void test2805() {
    coral.tests.JPFBenchmark.benchmark63(96.3671778062062,-33.33339691593086,6.371605536044484,-22.16284881672921,0 ) ;
  }

  @Test
  public void test2806() {
    coral.tests.JPFBenchmark.benchmark63(96.40799107255248,-13.01216942090116,19.01046627839807,46.78098867042894,0 ) ;
  }

  @Test
  public void test2807() {
    coral.tests.JPFBenchmark.benchmark63(96.41082122230176,-38.065612146345096,93.5821491901996,-14.042120434200768,0 ) ;
  }

  @Test
  public void test2808() {
    coral.tests.JPFBenchmark.benchmark63(96.41930617124089,-86.24025998202904,91.48469069005765,-20.87071496085224,0 ) ;
  }

  @Test
  public void test2809() {
    coral.tests.JPFBenchmark.benchmark63(96.44438303497515,-17.77931286224583,-76.1428049749496,-32.46297045644151,0 ) ;
  }

  @Test
  public void test2810() {
    coral.tests.JPFBenchmark.benchmark63(96.44886869256516,-57.09869206819056,-51.84073543492098,-69.01485868491402,0 ) ;
  }

  @Test
  public void test2811() {
    coral.tests.JPFBenchmark.benchmark63(96.45856575375595,-56.25452880063329,95.03904386908454,15.131258527516536,0 ) ;
  }

  @Test
  public void test2812() {
    coral.tests.JPFBenchmark.benchmark63(96.48918751160687,-50.51568181642434,-94.61209187955568,48.97891950912401,0 ) ;
  }

  @Test
  public void test2813() {
    coral.tests.JPFBenchmark.benchmark63(96.49204171575681,-10.265526992577364,71.24512755962385,-65.666609258806,0 ) ;
  }

  @Test
  public void test2814() {
    coral.tests.JPFBenchmark.benchmark63(96.55221222340376,-87.64038943554881,94.69955856915743,49.81631309005445,0 ) ;
  }

  @Test
  public void test2815() {
    coral.tests.JPFBenchmark.benchmark63(96.57814844473114,-31.570962610300214,51.99688665149503,-24.777412785323236,0 ) ;
  }

  @Test
  public void test2816() {
    coral.tests.JPFBenchmark.benchmark63(96.58420962375925,-52.35176340124759,31.175780340135162,48.35616806735507,0 ) ;
  }

  @Test
  public void test2817() {
    coral.tests.JPFBenchmark.benchmark63(96.63928303129978,-25.298615085708747,-23.27512039243649,-48.80911133492643,0 ) ;
  }

  @Test
  public void test2818() {
    coral.tests.JPFBenchmark.benchmark63(96.68131147150777,-92.25193675911636,30.24842559057845,17.01906330629241,0 ) ;
  }

  @Test
  public void test2819() {
    coral.tests.JPFBenchmark.benchmark63(96.71852911725469,-85.87248119433593,-80.53251682511336,-81.42367865493503,0 ) ;
  }

  @Test
  public void test2820() {
    coral.tests.JPFBenchmark.benchmark63(96.8395082992532,-68.86578047753315,-81.25609463794605,59.376440050779735,0 ) ;
  }

  @Test
  public void test2821() {
    coral.tests.JPFBenchmark.benchmark63(9.684172806343668,-7.094717452020788,41.037964237534,31.174454461146524,0 ) ;
  }

  @Test
  public void test2822() {
    coral.tests.JPFBenchmark.benchmark63(96.95506588119747,-49.27908369743259,92.64617481573922,27.508611377566766,0 ) ;
  }

  @Test
  public void test2823() {
    coral.tests.JPFBenchmark.benchmark63(96.9567205127384,-11.080293587213077,-95.17024277533568,82.8460975930372,0 ) ;
  }

  @Test
  public void test2824() {
    coral.tests.JPFBenchmark.benchmark63(96.98747351427417,-31.25269327189642,-64.41450345990734,-9.552803124276295,0 ) ;
  }

  @Test
  public void test2825() {
    coral.tests.JPFBenchmark.benchmark63(97.00624895769641,-22.121173535709417,-21.858546284140886,16.268841499919432,0 ) ;
  }

  @Test
  public void test2826() {
    coral.tests.JPFBenchmark.benchmark63(97.00842116450127,-31.27210655078639,21.401959417755933,84.19186114256922,0 ) ;
  }

  @Test
  public void test2827() {
    coral.tests.JPFBenchmark.benchmark63(97.0260489541433,-57.197364701339026,75.7481808884217,-44.84561916126195,0 ) ;
  }

  @Test
  public void test2828() {
    coral.tests.JPFBenchmark.benchmark63(97.03724636184756,-75.02183295787114,79.01543502660135,61.376595917661405,0 ) ;
  }

  @Test
  public void test2829() {
    coral.tests.JPFBenchmark.benchmark63(97.06247604115819,-32.146993025148916,-18.998186837019617,27.076850326952368,0 ) ;
  }

  @Test
  public void test2830() {
    coral.tests.JPFBenchmark.benchmark63(97.06999559056331,-20.48162196524123,-32.88972967877788,79.81443629275142,0 ) ;
  }

  @Test
  public void test2831() {
    coral.tests.JPFBenchmark.benchmark63(97.08246853596884,-17.02525117175189,94.3987310191836,88.6784778634588,0 ) ;
  }

  @Test
  public void test2832() {
    coral.tests.JPFBenchmark.benchmark63(97.09518475016537,-31.446082298635787,17.91977415118356,-7.156705064837567,0 ) ;
  }

  @Test
  public void test2833() {
    coral.tests.JPFBenchmark.benchmark63(97.107075428446,-81.50546772441405,82.62738622073127,48.388750926741494,0 ) ;
  }

  @Test
  public void test2834() {
    coral.tests.JPFBenchmark.benchmark63(97.10953595886173,-94.59905417545227,-26.222603129329443,59.895661897302006,0 ) ;
  }

  @Test
  public void test2835() {
    coral.tests.JPFBenchmark.benchmark63(97.13020247870043,-56.46677372809423,89.92003848638734,-98.39678395791043,0 ) ;
  }

  @Test
  public void test2836() {
    coral.tests.JPFBenchmark.benchmark63(97.13044727454835,-9.028819939771864,-79.40796018563961,-81.91263707964048,0 ) ;
  }

  @Test
  public void test2837() {
    coral.tests.JPFBenchmark.benchmark63(97.13949611019927,-80.1930727935628,47.589666200017376,-71.03119290322772,0 ) ;
  }

  @Test
  public void test2838() {
    coral.tests.JPFBenchmark.benchmark63(97.14015367587183,-43.58566257148628,-98.87341201290336,75.10283490618113,0 ) ;
  }

  @Test
  public void test2839() {
    coral.tests.JPFBenchmark.benchmark63(97.16385302134074,-83.44877573334483,-59.2873784406641,-19.414623195066085,0 ) ;
  }

  @Test
  public void test2840() {
    coral.tests.JPFBenchmark.benchmark63(97.20131816456748,-12.591533198329415,49.752667775161825,36.146430733485914,0 ) ;
  }

  @Test
  public void test2841() {
    coral.tests.JPFBenchmark.benchmark63(9.721646462496764,-8.973705976332582,0.46535640717368665,-46.98220395275114,0 ) ;
  }

  @Test
  public void test2842() {
    coral.tests.JPFBenchmark.benchmark63(97.23872685707622,-85.26603363615224,65.02962697513632,75.82772345819825,0 ) ;
  }

  @Test
  public void test2843() {
    coral.tests.JPFBenchmark.benchmark63(97.25147084538645,-14.512674966733414,-45.8027639076249,-28.314615006906394,0 ) ;
  }

  @Test
  public void test2844() {
    coral.tests.JPFBenchmark.benchmark63(97.290641971164,-34.87202987230131,-13.354901491966203,43.95963556821826,0 ) ;
  }

  @Test
  public void test2845() {
    coral.tests.JPFBenchmark.benchmark63(97.30145604441333,-5.930345031722823,-0.7241059945649653,67.03968271085213,0 ) ;
  }

  @Test
  public void test2846() {
    coral.tests.JPFBenchmark.benchmark63(97.32970121148713,-46.278273767929235,-37.01707656976119,-49.8385416586379,0 ) ;
  }

  @Test
  public void test2847() {
    coral.tests.JPFBenchmark.benchmark63(97.33295938145903,-23.41850006771142,37.36274085636896,-38.90394353567845,0 ) ;
  }

  @Test
  public void test2848() {
    coral.tests.JPFBenchmark.benchmark63(97.34738027604905,-5.019289890247265,92.95094399347974,72.55557759983989,0 ) ;
  }

  @Test
  public void test2849() {
    coral.tests.JPFBenchmark.benchmark63(97.41339220284192,-72.66664179061107,-77.39187578481634,8.596263823828835,0 ) ;
  }

  @Test
  public void test2850() {
    coral.tests.JPFBenchmark.benchmark63(97.42676030617383,-48.75671392539373,-32.692000836358346,92.97783968582905,0 ) ;
  }

  @Test
  public void test2851() {
    coral.tests.JPFBenchmark.benchmark63(97.4314945688273,-94.076727249415,77.31902564127691,74.27158093640156,0 ) ;
  }

  @Test
  public void test2852() {
    coral.tests.JPFBenchmark.benchmark63(97.43849596670404,-80.13222060692964,35.93961009682721,-16.735861876629343,0 ) ;
  }

  @Test
  public void test2853() {
    coral.tests.JPFBenchmark.benchmark63(97.47110259515452,-32.924896987862454,-64.43083398370513,-71.37874973166359,0 ) ;
  }

  @Test
  public void test2854() {
    coral.tests.JPFBenchmark.benchmark63(97.48576495558396,-73.52207360453903,97.49356260334898,12.727643406496298,0 ) ;
  }

  @Test
  public void test2855() {
    coral.tests.JPFBenchmark.benchmark63(97.4939976948728,-49.089484653833246,-58.93452207148917,-55.44333982257912,0 ) ;
  }

  @Test
  public void test2856() {
    coral.tests.JPFBenchmark.benchmark63(97.4988959352992,-10.720971177096189,21.42203814336112,35.046696170892375,0 ) ;
  }

  @Test
  public void test2857() {
    coral.tests.JPFBenchmark.benchmark63(97.52407268836848,-76.94940833603228,-64.65356149642659,-80.59824033565069,0 ) ;
  }

  @Test
  public void test2858() {
    coral.tests.JPFBenchmark.benchmark63(97.53725693184745,-69.55560846709696,83.29659081502217,73.22407290478984,0 ) ;
  }

  @Test
  public void test2859() {
    coral.tests.JPFBenchmark.benchmark63(97.55253738873714,-67.27903795067094,48.944656399542,98.92028642156833,0 ) ;
  }

  @Test
  public void test2860() {
    coral.tests.JPFBenchmark.benchmark63(97.57150519366093,-44.53781551720968,86.56003147478498,36.43158634892802,0 ) ;
  }

  @Test
  public void test2861() {
    coral.tests.JPFBenchmark.benchmark63(97.57850204643125,-42.171894979254446,40.53966736065934,81.59886556768154,0 ) ;
  }

  @Test
  public void test2862() {
    coral.tests.JPFBenchmark.benchmark63(97.5825814490828,-16.28395348541767,99.0476190915773,-11.753731744821351,0 ) ;
  }

  @Test
  public void test2863() {
    coral.tests.JPFBenchmark.benchmark63(97.58662175299986,-38.408802194007684,34.977119985136824,-90.68623224223778,0 ) ;
  }

  @Test
  public void test2864() {
    coral.tests.JPFBenchmark.benchmark63(97.5931901102233,-15.039718519410044,-95.93063901041315,-57.90257202190714,0 ) ;
  }

  @Test
  public void test2865() {
    coral.tests.JPFBenchmark.benchmark63(97.59843503315093,-16.49430863222841,19.355212697053275,46.43873907551165,0 ) ;
  }

  @Test
  public void test2866() {
    coral.tests.JPFBenchmark.benchmark63(97.63374750920673,-47.75216105858466,39.54387757095154,22.27469492759468,0 ) ;
  }

  @Test
  public void test2867() {
    coral.tests.JPFBenchmark.benchmark63(97.63715706255167,-50.52497283886525,-82.89108114302306,16.38059256088151,0 ) ;
  }

  @Test
  public void test2868() {
    coral.tests.JPFBenchmark.benchmark63(97.69664382418253,-46.66610616717346,59.7148245751149,-75.66007731479188,0 ) ;
  }

  @Test
  public void test2869() {
    coral.tests.JPFBenchmark.benchmark63(97.71589205167965,-20.967908212432107,47.24660528440708,-47.51983569585838,0 ) ;
  }

  @Test
  public void test2870() {
    coral.tests.JPFBenchmark.benchmark63(97.72336672740022,-5.29819816631219,-33.26500726909663,82.77934130904202,0 ) ;
  }

  @Test
  public void test2871() {
    coral.tests.JPFBenchmark.benchmark63(97.74177641271521,-43.537789946561325,73.57408225343653,35.7479190130812,0 ) ;
  }

  @Test
  public void test2872() {
    coral.tests.JPFBenchmark.benchmark63(97.74781246199103,-8.15708011809187,-42.56682438275696,22.138905724987268,0 ) ;
  }

  @Test
  public void test2873() {
    coral.tests.JPFBenchmark.benchmark63(97.75188411036925,-83.61672375978308,-33.78754304129592,-7.934117599891692,0 ) ;
  }

  @Test
  public void test2874() {
    coral.tests.JPFBenchmark.benchmark63(97.75196360129931,-79.08912464845726,90.88042892953007,75.98395664611755,0 ) ;
  }

  @Test
  public void test2875() {
    coral.tests.JPFBenchmark.benchmark63(97.774808206507,-42.27314361690419,29.114369372076453,-40.23042252773239,0 ) ;
  }

  @Test
  public void test2876() {
    coral.tests.JPFBenchmark.benchmark63(97.78192986919677,-56.42202059165942,-59.27484520213606,-4.744142361175392,0 ) ;
  }

  @Test
  public void test2877() {
    coral.tests.JPFBenchmark.benchmark63(97.78875848253318,-84.11405281339233,44.76342691122784,-14.625806415485869,0 ) ;
  }

  @Test
  public void test2878() {
    coral.tests.JPFBenchmark.benchmark63(97.79544625096904,-55.74496519159755,-48.79500653664066,-87.35003330694934,0 ) ;
  }

  @Test
  public void test2879() {
    coral.tests.JPFBenchmark.benchmark63(97.79577613069807,-18.796125293240223,-1.7770253978935955,-37.42410955122206,0 ) ;
  }

  @Test
  public void test2880() {
    coral.tests.JPFBenchmark.benchmark63(97.82175365978071,-83.87277492639878,77.69292873582324,-43.71959058913439,0 ) ;
  }

  @Test
  public void test2881() {
    coral.tests.JPFBenchmark.benchmark63(97.83262590361159,-72.2231986157829,1.9286591959261727,-31.12471909331458,0 ) ;
  }

  @Test
  public void test2882() {
    coral.tests.JPFBenchmark.benchmark63(97.84027123186155,-12.246602867300552,2.945564560095775,-15.291896162142564,0 ) ;
  }

  @Test
  public void test2883() {
    coral.tests.JPFBenchmark.benchmark63(97.88606916948157,-97.33350107874227,-16.660431671506615,64.91723100549555,0 ) ;
  }

  @Test
  public void test2884() {
    coral.tests.JPFBenchmark.benchmark63(97.91748760389589,-80.43045267224444,-99.56703750781473,-79.59244925479857,0 ) ;
  }

  @Test
  public void test2885() {
    coral.tests.JPFBenchmark.benchmark63(97.92174299575484,-86.59124514593262,3.929595828373067,-10.544441077690124,0 ) ;
  }

  @Test
  public void test2886() {
    coral.tests.JPFBenchmark.benchmark63(97.93034308164101,-83.87916819088417,-43.808757930142825,-43.33370666540182,0 ) ;
  }

  @Test
  public void test2887() {
    coral.tests.JPFBenchmark.benchmark63(97.94861433301497,-71.42206566377033,-89.74932678185301,34.080884532771194,0 ) ;
  }

  @Test
  public void test2888() {
    coral.tests.JPFBenchmark.benchmark63(97.95268506869888,-25.11597705689806,-61.80508950136841,-66.70662283312512,0 ) ;
  }

  @Test
  public void test2889() {
    coral.tests.JPFBenchmark.benchmark63(97.9663133896214,-7.020889705476037,-55.33917680376981,9.272903320958378,0 ) ;
  }

  @Test
  public void test2890() {
    coral.tests.JPFBenchmark.benchmark63(97.97230480038297,-30.408219501044826,-72.29043387418817,87.02200548348392,0 ) ;
  }

  @Test
  public void test2891() {
    coral.tests.JPFBenchmark.benchmark63(97.98593365817263,-20.662498335397615,78.60566726546307,-19.40563213777253,0 ) ;
  }

  @Test
  public void test2892() {
    coral.tests.JPFBenchmark.benchmark63(97.99661245428993,-31.165127217383798,-52.866710176739694,60.135132421020415,0 ) ;
  }

  @Test
  public void test2893() {
    coral.tests.JPFBenchmark.benchmark63(98.0012251450168,-53.20817643100823,87.92481759981791,85.3093415158985,0 ) ;
  }

  @Test
  public void test2894() {
    coral.tests.JPFBenchmark.benchmark63(98.04083621749513,-1.5094268046428994,-13.19098107621761,-49.36763635589217,0 ) ;
  }

  @Test
  public void test2895() {
    coral.tests.JPFBenchmark.benchmark63(98.05407461076106,-23.151718440156955,-81.80451180628768,24.273735402546663,0 ) ;
  }

  @Test
  public void test2896() {
    coral.tests.JPFBenchmark.benchmark63(98.09940676319053,-22.69933576019021,-89.81087606495497,-38.1640515042847,0 ) ;
  }

  @Test
  public void test2897() {
    coral.tests.JPFBenchmark.benchmark63(98.11322398093878,-65.12151693896789,-95.03365351805289,-88.60860538347058,0 ) ;
  }

  @Test
  public void test2898() {
    coral.tests.JPFBenchmark.benchmark63(98.1155709381404,-22.739912303731245,59.2031752681398,22.024033608822037,0 ) ;
  }

  @Test
  public void test2899() {
    coral.tests.JPFBenchmark.benchmark63(98.13217693106563,-58.439799403162596,-45.476031481781696,-77.32551440077427,0 ) ;
  }

  @Test
  public void test2900() {
    coral.tests.JPFBenchmark.benchmark63(98.13296871563944,-65.43829335882643,17.03125754224672,72.7502062966675,0 ) ;
  }

  @Test
  public void test2901() {
    coral.tests.JPFBenchmark.benchmark63(98.13823929080675,-86.28425573596923,-0.1913076264965099,-77.32220272143124,0 ) ;
  }

  @Test
  public void test2902() {
    coral.tests.JPFBenchmark.benchmark63(98.14509330771696,-19.967506997432466,28.936957876454755,-87.79305284130086,0 ) ;
  }

  @Test
  public void test2903() {
    coral.tests.JPFBenchmark.benchmark63(98.14676364389007,-4.60149160600929,3.672781005774283,-70.1014077809504,0 ) ;
  }

  @Test
  public void test2904() {
    coral.tests.JPFBenchmark.benchmark63(98.1725437886256,-37.116134779851606,-86.8576408193519,64.85004166990726,0 ) ;
  }

  @Test
  public void test2905() {
    coral.tests.JPFBenchmark.benchmark63(98.190656061189,-72.17251695264078,-58.532389813557415,-27.22185477212706,0 ) ;
  }

  @Test
  public void test2906() {
    coral.tests.JPFBenchmark.benchmark63(98.19679344386006,-25.21989393385624,34.01899755790919,-5.080262784153788,0 ) ;
  }

  @Test
  public void test2907() {
    coral.tests.JPFBenchmark.benchmark63(98.20423974685531,-82.5618833016087,-92.0324689896326,76.68470360219189,0 ) ;
  }

  @Test
  public void test2908() {
    coral.tests.JPFBenchmark.benchmark63(98.25718494873692,-84.08634335520529,88.77410159985001,90.04518225559778,0 ) ;
  }

  @Test
  public void test2909() {
    coral.tests.JPFBenchmark.benchmark63(98.30849351862179,-38.857978222328256,97.09730602204127,2.56175594621007,0 ) ;
  }

  @Test
  public void test2910() {
    coral.tests.JPFBenchmark.benchmark63(98.31612295343791,-24.657872950016085,9.39045688314495,-34.032366369155625,0 ) ;
  }

  @Test
  public void test2911() {
    coral.tests.JPFBenchmark.benchmark63(98.34669754174922,-7.595605598501336,48.771303799615055,44.9255991353358,0 ) ;
  }

  @Test
  public void test2912() {
    coral.tests.JPFBenchmark.benchmark63(98.37706288766174,-40.30740999650162,-78.25971107554992,-39.04292916236298,0 ) ;
  }

  @Test
  public void test2913() {
    coral.tests.JPFBenchmark.benchmark63(98.41522937191334,-47.03396588663804,22.31803382529054,60.92719814696784,0 ) ;
  }

  @Test
  public void test2914() {
    coral.tests.JPFBenchmark.benchmark63(98.41552002168851,-12.747057871312634,78.10066605241019,-67.03481711878854,0 ) ;
  }

  @Test
  public void test2915() {
    coral.tests.JPFBenchmark.benchmark63(98.41566741742062,-33.89490386218701,-8.186953030832072,-82.20192464090303,0 ) ;
  }

  @Test
  public void test2916() {
    coral.tests.JPFBenchmark.benchmark63(98.41663855378565,-6.33198677812257,-32.009307402001696,-33.54753963680149,0 ) ;
  }

  @Test
  public void test2917() {
    coral.tests.JPFBenchmark.benchmark63(98.42245344797246,-79.43653917690207,21.961267536560072,-47.06706491840578,0 ) ;
  }

  @Test
  public void test2918() {
    coral.tests.JPFBenchmark.benchmark63(98.45103208847814,-67.74588193038345,78.86661833766544,-78.66120591728259,0 ) ;
  }

  @Test
  public void test2919() {
    coral.tests.JPFBenchmark.benchmark63(98.45411389934654,-70.39205148839827,-3.474784416883807,55.27499351068076,0 ) ;
  }

  @Test
  public void test2920() {
    coral.tests.JPFBenchmark.benchmark63(98.46231728943607,-60.75448027725354,77.10085004998191,52.60345464643913,0 ) ;
  }

  @Test
  public void test2921() {
    coral.tests.JPFBenchmark.benchmark63(98.4722098099059,-54.75217585340053,-42.29936192973975,85.94045059813152,0 ) ;
  }

  @Test
  public void test2922() {
    coral.tests.JPFBenchmark.benchmark63(98.52810743351489,-8.44455145272724,-9.507853242002767,-10.12910221110161,0 ) ;
  }

  @Test
  public void test2923() {
    coral.tests.JPFBenchmark.benchmark63(98.53543421009147,-84.8529410099589,-30.965391783581907,-28.59834756889559,0 ) ;
  }

  @Test
  public void test2924() {
    coral.tests.JPFBenchmark.benchmark63(98.56649581174455,-51.02925171674462,66.46730885346935,-75.9997925228723,0 ) ;
  }

  @Test
  public void test2925() {
    coral.tests.JPFBenchmark.benchmark63(98.58140592201218,-81.9055443337385,-7.476202833096693,-90.23738747016867,0 ) ;
  }

  @Test
  public void test2926() {
    coral.tests.JPFBenchmark.benchmark63(98.58293475119382,-8.225704829801316,-74.14828271558132,48.80102961012733,0 ) ;
  }

  @Test
  public void test2927() {
    coral.tests.JPFBenchmark.benchmark63(98.58995681131915,-40.05223723919118,-92.94981612169384,96.93391069598201,0 ) ;
  }

  @Test
  public void test2928() {
    coral.tests.JPFBenchmark.benchmark63(98.59098796795507,-87.8567167834551,14.315293383771063,-56.33209456675132,0 ) ;
  }

  @Test
  public void test2929() {
    coral.tests.JPFBenchmark.benchmark63(98.60658139050719,-17.41468588363165,-54.889582298233506,-46.42661540209034,0 ) ;
  }

  @Test
  public void test2930() {
    coral.tests.JPFBenchmark.benchmark63(98.62409699194114,-98.23498528059862,57.33263905342335,-58.44707633545643,0 ) ;
  }

  @Test
  public void test2931() {
    coral.tests.JPFBenchmark.benchmark63(98.64228823964808,-14.628175764559941,-97.21462576870212,94.28364480299655,0 ) ;
  }

  @Test
  public void test2932() {
    coral.tests.JPFBenchmark.benchmark63(98.65150245036702,-13.814741492776264,62.36343391231165,-99.76945589600001,0 ) ;
  }

  @Test
  public void test2933() {
    coral.tests.JPFBenchmark.benchmark63(98.66452308708301,-82.25565048198303,-49.29166776825375,-7.6115439044190225,0 ) ;
  }

  @Test
  public void test2934() {
    coral.tests.JPFBenchmark.benchmark63(98.68554156264457,-83.90838570493813,72.25016606152735,68.43183980858367,0 ) ;
  }

  @Test
  public void test2935() {
    coral.tests.JPFBenchmark.benchmark63(98.69060377208768,-49.92149832407533,-19.158827933098735,31.483504490755905,0 ) ;
  }

  @Test
  public void test2936() {
    coral.tests.JPFBenchmark.benchmark63(98.71519037150753,-53.07543528826355,5.07985481999485,69.1075950595858,0 ) ;
  }

  @Test
  public void test2937() {
    coral.tests.JPFBenchmark.benchmark63(98.73294559987872,-82.16604452386211,49.72267552716906,-46.935003212758055,0 ) ;
  }

  @Test
  public void test2938() {
    coral.tests.JPFBenchmark.benchmark63(98.73300084330862,-59.48807772689724,36.54965754271552,81.12800842474655,0 ) ;
  }

  @Test
  public void test2939() {
    coral.tests.JPFBenchmark.benchmark63(98.73989055111502,-34.552067169325994,-18.902174200890357,-29.117956156985315,0 ) ;
  }

  @Test
  public void test2940() {
    coral.tests.JPFBenchmark.benchmark63(98.76316951411809,-68.53887171885728,47.53291318230103,89.72591752810291,0 ) ;
  }

  @Test
  public void test2941() {
    coral.tests.JPFBenchmark.benchmark63(98.78308822580107,-44.99099965511597,97.68168389897909,68.84514019472391,0 ) ;
  }

  @Test
  public void test2942() {
    coral.tests.JPFBenchmark.benchmark63(98.79063104449381,-26.563924544850323,14.176496235511308,-45.57725991820718,0 ) ;
  }

  @Test
  public void test2943() {
    coral.tests.JPFBenchmark.benchmark63(98.79223788017987,-49.61564211317337,-50.163170962466786,18.554237685360576,0 ) ;
  }

  @Test
  public void test2944() {
    coral.tests.JPFBenchmark.benchmark63(98.84850940157614,-53.117002467603356,-80.10267468093517,-7.383508736152166,0 ) ;
  }

  @Test
  public void test2945() {
    coral.tests.JPFBenchmark.benchmark63(98.88766213746206,-16.10159392509121,70.97407085841468,88.14544208453182,0 ) ;
  }

  @Test
  public void test2946() {
    coral.tests.JPFBenchmark.benchmark63(98.96978841490244,-10.754298935468796,86.25322487082732,56.15711511330491,0 ) ;
  }

  @Test
  public void test2947() {
    coral.tests.JPFBenchmark.benchmark63(98.9861390601302,-92.02074637295861,-55.63562792825279,-30.884987506016913,0 ) ;
  }

  @Test
  public void test2948() {
    coral.tests.JPFBenchmark.benchmark63(99.007232817572,-48.019120969491546,-1.9044236785004358,25.057782145631464,0 ) ;
  }

  @Test
  public void test2949() {
    coral.tests.JPFBenchmark.benchmark63(99.01608312259555,-99.84014662505423,-96.326307620478,13.13707032467839,0 ) ;
  }

  @Test
  public void test2950() {
    coral.tests.JPFBenchmark.benchmark63(99.0174369283697,-3.056690336348879,91.02046304361858,-59.68309811930857,0 ) ;
  }

  @Test
  public void test2951() {
    coral.tests.JPFBenchmark.benchmark63(99.0210508325253,-97.32473789594734,97.14577240237523,-26.348595610425818,0 ) ;
  }

  @Test
  public void test2952() {
    coral.tests.JPFBenchmark.benchmark63(99.02561261597788,-93.2908015456227,-14.864933462869033,91.05144763912332,0 ) ;
  }

  @Test
  public void test2953() {
    coral.tests.JPFBenchmark.benchmark63(99.0381484808324,-4.291060602464,35.23443405735949,-96.92924955972846,0 ) ;
  }

  @Test
  public void test2954() {
    coral.tests.JPFBenchmark.benchmark63(99.07776591770227,-70.11600460911453,97.22082867944474,-22.507863774721997,0 ) ;
  }

  @Test
  public void test2955() {
    coral.tests.JPFBenchmark.benchmark63(99.09611945480046,-85.28527926570935,-83.40301410289727,54.621917446459264,0 ) ;
  }

  @Test
  public void test2956() {
    coral.tests.JPFBenchmark.benchmark63(99.10613832277514,-35.80768520880031,-30.038214672682173,-1.4005923211672524,0 ) ;
  }

  @Test
  public void test2957() {
    coral.tests.JPFBenchmark.benchmark63(99.11275231798103,-30.135934726751373,-41.26073568135109,-57.849194368398216,0 ) ;
  }

  @Test
  public void test2958() {
    coral.tests.JPFBenchmark.benchmark63(99.11788326205138,-62.685225154611366,-10.930358223881868,-1.1930074699233302,0 ) ;
  }

  @Test
  public void test2959() {
    coral.tests.JPFBenchmark.benchmark63(99.12706900368627,-58.94535805966772,-38.804946309661005,88.66364287943361,0 ) ;
  }

  @Test
  public void test2960() {
    coral.tests.JPFBenchmark.benchmark63(99.12780279667885,-60.4512135208551,-50.40592463322619,82.6875973274366,0 ) ;
  }

  @Test
  public void test2961() {
    coral.tests.JPFBenchmark.benchmark63(99.14863807277322,-29.807885494608158,82.71471904526325,99.00485223898951,0 ) ;
  }

  @Test
  public void test2962() {
    coral.tests.JPFBenchmark.benchmark63(99.17114224510698,-54.96096952279794,-76.7956981776532,81.75564162361582,0 ) ;
  }

  @Test
  public void test2963() {
    coral.tests.JPFBenchmark.benchmark63(99.17173126451843,-44.2118447102416,69.38015967719332,69.62819711287929,0 ) ;
  }

  @Test
  public void test2964() {
    coral.tests.JPFBenchmark.benchmark63(99.19686815994609,-71.92774418303327,-77.26228470890524,31.572246214444647,0 ) ;
  }

  @Test
  public void test2965() {
    coral.tests.JPFBenchmark.benchmark63(99.19815036527723,-32.07294222431017,46.050705607831276,9.763995000853896,0 ) ;
  }

  @Test
  public void test2966() {
    coral.tests.JPFBenchmark.benchmark63(99.20264293883452,-46.1475124501072,-97.41494414879888,-63.31851367390466,0 ) ;
  }

  @Test
  public void test2967() {
    coral.tests.JPFBenchmark.benchmark63(99.2057464369986,-93.90060136519863,21.194909779663007,-5.756578259316925,0 ) ;
  }

  @Test
  public void test2968() {
    coral.tests.JPFBenchmark.benchmark63(99.21359310021919,-54.57678048531562,-84.11899768922547,-87.05726929201059,0 ) ;
  }

  @Test
  public void test2969() {
    coral.tests.JPFBenchmark.benchmark63(99.22635961897274,-11.598288779358,11.563076529945505,-56.29963003353602,0 ) ;
  }

  @Test
  public void test2970() {
    coral.tests.JPFBenchmark.benchmark63(99.2277253883845,-33.522996604681694,79.79328355819712,54.6050184642246,0 ) ;
  }

  @Test
  public void test2971() {
    coral.tests.JPFBenchmark.benchmark63(99.24507368829626,-66.9444800605105,26.53002866059559,92.35177620435232,0 ) ;
  }

  @Test
  public void test2972() {
    coral.tests.JPFBenchmark.benchmark63(99.2972425356985,-95.69939731112757,-28.162414421271293,56.18547643306607,0 ) ;
  }

  @Test
  public void test2973() {
    coral.tests.JPFBenchmark.benchmark63(99.31370640141753,-40.938554866337725,33.08604680873498,-52.572613980182695,0 ) ;
  }

  @Test
  public void test2974() {
    coral.tests.JPFBenchmark.benchmark63(99.3223143553858,-12.500792291426862,42.05906945993013,30.3654701488567,0 ) ;
  }

  @Test
  public void test2975() {
    coral.tests.JPFBenchmark.benchmark63(99.32463682194341,-96.71357437396632,-14.854379375519812,45.034069942878546,0 ) ;
  }

  @Test
  public void test2976() {
    coral.tests.JPFBenchmark.benchmark63(99.32534838722773,-74.50437308603107,-95.08949914674913,-24.874637005438288,0 ) ;
  }

  @Test
  public void test2977() {
    coral.tests.JPFBenchmark.benchmark63(99.33390430783913,-87.72624630898545,-29.914278205569573,51.63090087853885,0 ) ;
  }

  @Test
  public void test2978() {
    coral.tests.JPFBenchmark.benchmark63(99.35775257094787,-2.631257073230927,82.48587299383789,-7.825320170707826,0 ) ;
  }

  @Test
  public void test2979() {
    coral.tests.JPFBenchmark.benchmark63(99.36438795721668,-74.78184503392492,53.08711580219955,-67.82366685874237,0 ) ;
  }

  @Test
  public void test2980() {
    coral.tests.JPFBenchmark.benchmark63(99.41105208637404,-63.72137109783817,44.81494142049277,89.67221846369677,0 ) ;
  }

  @Test
  public void test2981() {
    coral.tests.JPFBenchmark.benchmark63(99.43170850556612,-14.809294637166644,-9.521037564954653,22.359905201442402,0 ) ;
  }

  @Test
  public void test2982() {
    coral.tests.JPFBenchmark.benchmark63(99.43256586018703,-36.722730463209665,-54.21503285393534,-28.910946467663365,0 ) ;
  }

  @Test
  public void test2983() {
    coral.tests.JPFBenchmark.benchmark63(99.44083211367214,-30.131889918404298,76.09852763614342,60.24117382113971,0 ) ;
  }

  @Test
  public void test2984() {
    coral.tests.JPFBenchmark.benchmark63(99.4469173882456,-63.46309022792438,46.17361588472423,-16.090901460025947,0 ) ;
  }

  @Test
  public void test2985() {
    coral.tests.JPFBenchmark.benchmark63(99.47470981826913,-6.65618598935194,7.5851178419714245,60.2268722814444,0 ) ;
  }

  @Test
  public void test2986() {
    coral.tests.JPFBenchmark.benchmark63(99.47674527335226,-4.168827940240334,71.64902587066172,76.55224734114296,0 ) ;
  }

  @Test
  public void test2987() {
    coral.tests.JPFBenchmark.benchmark63(99.49498524799387,-70.83028690523832,-29.20280455170598,-40.15129539979472,0 ) ;
  }

  @Test
  public void test2988() {
    coral.tests.JPFBenchmark.benchmark63(99.50109063575684,-6.430314639323683,-21.07740288394359,-96.25427711270429,0 ) ;
  }

  @Test
  public void test2989() {
    coral.tests.JPFBenchmark.benchmark63(99.5464729213306,-98.04994465366946,46.11227818246962,69.20987392903311,0 ) ;
  }

  @Test
  public void test2990() {
    coral.tests.JPFBenchmark.benchmark63(99.54961347962876,-51.38858838506517,-21.20943967255471,59.916228005462216,0 ) ;
  }

  @Test
  public void test2991() {
    coral.tests.JPFBenchmark.benchmark63(99.56954772423606,-32.052888251502935,82.7111291871642,37.36765992033557,0 ) ;
  }

  @Test
  public void test2992() {
    coral.tests.JPFBenchmark.benchmark63(99.5708843897414,-55.130100833102325,4.663516842685183,39.82957733896768,0 ) ;
  }

  @Test
  public void test2993() {
    coral.tests.JPFBenchmark.benchmark63(99.57219935199458,-65.7894733102324,54.014942743041615,-5.504459428158341,0 ) ;
  }

  @Test
  public void test2994() {
    coral.tests.JPFBenchmark.benchmark63(99.61271335115822,-22.14390210255202,-65.890606326708,58.229389541790084,0 ) ;
  }

  @Test
  public void test2995() {
    coral.tests.JPFBenchmark.benchmark63(99.61332362765611,-95.5655555596648,20.66846589836082,24.076593555601235,0 ) ;
  }

  @Test
  public void test2996() {
    coral.tests.JPFBenchmark.benchmark63(99.61397264867239,-47.85913078591353,-64.54322558309443,91.2450536202152,0 ) ;
  }

  @Test
  public void test2997() {
    coral.tests.JPFBenchmark.benchmark63(99.63867120806523,-26.183368914509273,-21.15991946186311,-28.29947790893921,0 ) ;
  }

  @Test
  public void test2998() {
    coral.tests.JPFBenchmark.benchmark63(99.6760993103579,-46.359579628211044,71.32465367133202,60.22590959525641,0 ) ;
  }

  @Test
  public void test2999() {
    coral.tests.JPFBenchmark.benchmark63(99.67949887615103,-77.76041336495553,-22.37749745171132,26.667821127983316,0 ) ;
  }

  @Test
  public void test3000() {
    coral.tests.JPFBenchmark.benchmark63(99.70736062687294,-23.71414772770224,-64.20650057709203,45.22927175318239,0 ) ;
  }

  @Test
  public void test3001() {
    coral.tests.JPFBenchmark.benchmark63(99.71017416607873,-36.73987857420433,68.74825653625768,-31.46946370371522,0 ) ;
  }

  @Test
  public void test3002() {
    coral.tests.JPFBenchmark.benchmark63(99.71802376784999,-16.488678387396476,61.97308831659225,93.70969299740804,0 ) ;
  }

  @Test
  public void test3003() {
    coral.tests.JPFBenchmark.benchmark63(99.72895109680212,-10.184897629505869,95.89310353682666,-95.85182843500273,0 ) ;
  }

  @Test
  public void test3004() {
    coral.tests.JPFBenchmark.benchmark63(99.7318468545148,-4.412620433080221,6.509867163649119,53.93858532048458,0 ) ;
  }

  @Test
  public void test3005() {
    coral.tests.JPFBenchmark.benchmark63(99.75977118983175,-76.47213682336557,-47.12921236380161,-50.648364238209844,0 ) ;
  }

  @Test
  public void test3006() {
    coral.tests.JPFBenchmark.benchmark63(99.76103567506166,-17.995632718842458,-95.06406790242889,-34.85345923467045,0 ) ;
  }

  @Test
  public void test3007() {
    coral.tests.JPFBenchmark.benchmark63(99.79398038451953,-49.46205782117594,9.220272023145014,75.76466039511814,0 ) ;
  }

  @Test
  public void test3008() {
    coral.tests.JPFBenchmark.benchmark63(99.80471235022134,-88.63438993085254,14.503038154555242,-38.440681233516386,0 ) ;
  }

  @Test
  public void test3009() {
    coral.tests.JPFBenchmark.benchmark63(99.87666113598263,-9.052796849354252,-41.186789250656105,-94.8487761362664,0 ) ;
  }

  @Test
  public void test3010() {
    coral.tests.JPFBenchmark.benchmark63(99.88227383144675,-26.463710459267162,48.13877117201653,86.73036014165726,0 ) ;
  }

  @Test
  public void test3011() {
    coral.tests.JPFBenchmark.benchmark63(99.88699531798463,-8.559137290844902,-42.621150848935294,-79.6096057098304,0 ) ;
  }

  @Test
  public void test3012() {
    coral.tests.JPFBenchmark.benchmark63(99.91820372289632,-84.11384935482732,44.49416291413664,-91.8419092748928,0 ) ;
  }

  @Test
  public void test3013() {
    coral.tests.JPFBenchmark.benchmark63(99.93483762533478,-69.98776607004045,99.92909902317913,-99.78083192874931,0 ) ;
  }

  @Test
  public void test3014() {
    coral.tests.JPFBenchmark.benchmark63(99.9545658415422,-85.18812095377955,16.33400094277289,-65.84082143653029,0 ) ;
  }

  @Test
  public void test3015() {
    coral.tests.JPFBenchmark.benchmark63(99.9581363761512,-73.98846706408321,-77.93359519810643,-10.831906917277223,0 ) ;
  }

  @Test
  public void test3016() {
    coral.tests.JPFBenchmark.benchmark63(99.9846493855369,-73.87982918560299,-51.98767975395884,17.062335196644838,0 ) ;
  }

  @Test
  public void test3017() {
    coral.tests.JPFBenchmark.benchmark63(99.99540773071948,-11.830844535400814,-71.23647586573898,-18.915157483842776,0 ) ;
  }

  @Test
  public void test3018() {
//    	UnSolved;
  }
}
