import org.junit.Test;

public class Sample13Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark13(0,-13.527477370481748,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark13(0,-1.6234286534948694,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark13(0,-22.148411798021513,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark13(0,-2.465190328815662E-32,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark13(0,-2699.66205491244,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark13(0,-2732.81885662637,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark13(0,-33.58534228441063,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark13(0,-34.55753857778711,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark13(0,-39.70346053126945,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark13(0,-42.3955114304327,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark13(0,-4.71238898038469,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark13(0,4.930380657631324E-32,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark13(0,-5.15864331150631,0,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark13(0,-54.623252412032855,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark13(0,5.4828675858605465,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark13(0,67.53246476618867,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark13(0,67.6878447698474,0,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark13(0,-68.9798215097535,0,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark13(0.6989237697968669,-66.0514901136662,0,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark13(0,-72.10912619692454,0,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark13(0,-80.74673666367204,0,0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark13(0,-85.67408770757933,0,0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark13(0,-9.244445962095142,0,0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark13(0,-92.97016857108305,0,0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark13(0,-96.03363541748406,0,0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark13(0,9.860761315262648E-32,0,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark13(-1.0000000000000036,-66.88951714754627,-0.07446767955383393,61.82778826595115 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark13(-1.000000000000007,-3.758870780079704,-1.5707963267948966,86.12663656621703 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark13(-1.0000000000000142,-22.42564590324882,-0.20828123026082698,1.0000000044050406 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark13(-1.0000000000000142,4.141592653590028,0,0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark13(-1.0000000000000142,-42.34232196771389,-1.5707963267948966,-0.996050139723343 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-10.082942932741176,-95.69867061203003,-78.79369670293391 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-10.30410384788594,-14.835171630126197,-0.9842735734402637 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-10.306304246353958,1.6188661717034571,-1.0000041815750367 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-15.992159321587364,-0.02412497559348524,-0.6924303918048798 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-16.019515032424408,-4.452294360004828,-0.8608119610092676 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-160.85399846827508,-92.25360272114932,-2314.8501188774912 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-16.15895061710539,-1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-22.463053109529238,-0.359904693037557,-29.31537014085 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-28.36906994111261,-1.5707963267948948,0.0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-3.143545778590248,0,0 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-3.2841259809869614,-2.2483746554546418,0.007090370418146044 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-3.2928192226293156,-14.977553369316183,-1.0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark13(-1.0003386129309009,-47.57871212170163,-77.50264815049492,1.0 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-34.59322222895693,-1.5707963267948966,-0.06255254909506403 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-34.66339528586717,-1.5707963267948966,0.9999999948921563 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-34.894620262370395,-32.23828881484478,3.394987852948617 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-34.89575818241276,-10.913897582416876,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-35.05302434788487,-0.5857985605205154,0.014419698709404084 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-35.1884015172565,-57.20983129299559,-0.6767749960598382 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-35.35463559936535,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-3.5423216073980592,-17.235429582935502,0.4653344164489397 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-35.592779818258094,-47.69168799377566,-39.41266323328292 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-35.75357423764591,-57.79599138396787,-0.9820621129195096 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-35.82057225974677,-40.23523412557138,0.057267296673887746 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-35.85946131870766,-10.088413473389807,0.746447755150911 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-35.939100974990396,-0.19163793200581225,-64.03122806208458 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-35.94015561137141,-84.75966974425688,5.293955920339377E-23 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-35.956464014701616,-1.5707963267948966,0.6508756517634143 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-35.959689947730794,-52.10277187963706,1.0000000870613297 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-35.977225072862836,14.431132114051763,-1.0 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-36.00579789178205,-1.5707963267948966,0.33292354189068574 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-3.606075140672581,-64.94169240546957,48.31503964567716 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-36.067137482168086,-44.45663848039393,6.4215208890303E-16 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-3.641690257017956,-6.626464706696973,10.86019110011604 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-3.7178219766310465,-3.8688593996701153,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-3.7518341772040884,-0.19695182447772336,0.8595684428698724 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-3.7738089797466046,-73.81550941476968,1.0000593776345987 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-3.93394023069618,-1.5707963267948966,-1.0410750147594525 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-4.007834905723155,-1.1638274898019887,-0.06255547576325192 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-4.027004211734946,27.786892016476884,0 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-4.100053640416686,-15.31152129416364,35.14847662962299 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-4.106941826827629,-21.88629504810713,28.81369988309436 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-41.41926534138746,-95.35306485463919,-0.44924218167118823 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-41.53810858961722,-1.5707963267948966,-98.29480351547018 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-41.5493367546297,-32.157588574492195,-1.0000000049476105 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-41.574040471984816,-66.13688398013606,1.0 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-41.62371519047019,-1.5707963267948966,57.851307470097936 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-41.86779602673849,-10.662070108439766,-0.9282216528769887 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-41.893084204785005,-1.5707963267948966,-1.8423985017890828E-4 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-42.00343299438121,-1.5707963267948912,0.024813995402161417 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-47.139684436666485,-53.71763066586581,0.9645224549247884 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-47.24814801194796,-1.5707963267949054,0.3137429834986776 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-47.25550500057043,-18.942160928034674,-1.0 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-47.34939200576418,-13.120802321898978,-0.4192577396226874 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-47.50966044009339,-46.312552897682465,0.027238827610619007 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-47.55559651763368,-2.0697796176505967E-14,4.007057698893806E-17 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-48.42827124766553,-44.07841237394245,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-48.460580601135966,-9.698425089217366,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-53.58671741703142,-53.69573063537408,-1.0 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-53.608604929091804,-0.08704028697138323,1.0 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-54.43509484898532,-38.6051190735238,0.8206237606923157 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-54.467562300256645,-19.144227949077443,-0.8509692063749603 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-54.512089008195254,-66.21740565901068,-5.293955920339377E-23 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-54.51325507404344,-1.5707963267948966,-0.9999999999999997 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-54.648047039012326,6.714763431833991,-1.0 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-54.9320299302224,-1.570796326795417,-15.121368906816784 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-60.72790749355333,-31.584755958272247,0.06255256084317853 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-60.785523845072404,-1.1102230246251565E-16,-79.25406565713223 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-60.83370629175351,-1.5707963267948966,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-60.877593016485,-27.037022798162223,-0.044063255357921646 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-60.96786330256733,-39.03582776737501,-0.9999999999999999 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-61.13698207953586,-1.2465191238188047,-100.0 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-61.253534652773865,-19.79005722475425,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-66.44434250111742,-1.5707963267948966,0.9999999999999964 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-66.4897010581006,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-66.60968952046576,-72.62175468401567,-1.0000114407129344 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-66.6259052701322,-1.5707963267948966,0.05924720471054243 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-66.62918072501769,-45.389411395723855,-1.0000000000440212 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-72.41280065717409,-66.29452330932247,1.0 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-72.43613125869932,-65.88013967917149,0.06255386377740971 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-73.08460314735115,-1.5707963267949125,1.3234889800848443E-23 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-73.1367139828981,-31.483616636067012,1930.1283520509699 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-73.14843724680185,-78.86650740742284,0.810292850943223 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-78.59436572954954,-60.6304097725485,0.0625606538751221 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-78.69838263318105,-0.2012674338725874,1.0 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-78.88862944817829,-1.6544727638166492,-1.0000000000000018 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-78.9960785460759,-39.811979428792135,-0.6744761415835612 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-85.03015495590674,-14.721260398435016,1.000000349328488 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-85.03128748223138,-0.9436660614393286,34.89422677640661 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-91.10970730633962,-34.94326798145609,-2.710505431213761E-20 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-9.607828926362124,-1.5707963267948966,0.3620964201929241 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-97.43292046468446,-1.5707963267948966,-9.10444299502927 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-97.7545671508567,-1.5707963267948966,0.06257241481728645 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-97.77821630202729,-4.462147002499151,-0.05572703320973396 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-97.9305988112934,-1.5707963267949125,-99.20374510101924 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-97.98423732157862,-1.2895996403310543,5.551115123125783E-17 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-98.037487165929,-0.589739552923322,-0.0546973739068477 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-98.23315353825564,-60.00010301633216,-1.0000000001218101 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-98.37725214346193,-9.573484067863362,0.9999999999999976 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-98.50001586833251,-1.5707963267948966,0.0038994145204921653 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-9.944142083924628,-3.2082133238556594,-0.7469342954751662 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-9.982305103877138,-10.560215698361276,0.0605698802613836 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark13(-1.0020808064087285,-35.62422151612007,-10.562959636939382,1.0659032378643851 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark13(-1.0027263547016527,-3.615347703402337,-41.07399228929084,0.9696088460061663 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark13(-10.031564543703295,-3.5870451308475757,-75.95940630309823,-1.0 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark13(-1.0040650599254686,-16.10232249278061,14.433004834518123,0.0 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark13(-10.071163482085382,-3.667894777757905,-38.919000236517746,-0.14940778815939115 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark13(-1.008909220835205,-66.48056796782434,-20.787062943455073,1.0 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark13(-10.106410426604356,-35.38452397677898,-52.08355885171219,-55.989402999028954 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark13(-101.16560553718745,-22.244672644955173,-27.27527620108738,36.57218043628666 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark13(-1.0169863233965089,-97.93381960525939,-63.6534040111474,29.735114280558008 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark13(-1.0222586499957853,-34.83886436480961,-91.3159556663511,3.552713678800501E-15 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark13(-10.241268264949234,-3.401996183602371,-72.95203985712308,0 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark13(-102.67114967778905,-54.504999151624325,-53.88301217521324,2027.969338791849 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark13(-10.273743721270694,-66.34743104621968,-1.5707963267948966,-11.764799202156098 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark13(-10.336915971555129,-22.31715369436672,-65.00840789040143,88.83351910296037 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark13(-1.0,-35.88385390168271,0,0 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark13(1.0,-35.89602284266418,0,0 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark13(-103.82334348525457,-53.601596306847455,-38.80640182882797,-5.619906154985372 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark13(-103.90946092875117,-3.416761745214412,-0.21219426900598157,-1.0 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark13(-103.99953246952485,-35.83969377229128,-88.13964004915368,1.0 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark13(-1.0411193468539608,-42.34836622508756,-1.5707963267948966,85.95914043932694 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark13(-104.18911736918295,-34.96604545361267,14.43359236184957,-6.758469193568728E-8 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark13(-1.0435871595725261,-54.94903975305728,-39.47449217990554,1.0 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark13(-10.481078215500233,-35.22323970025383,-148.12617454604322,-61.481702979408944 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark13(-10.497015839300852,-97.81356019082004,-84.21759285065312,1.0 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark13(-105.31798174779823,-54.703439522922906,-90.73102225718387,2198.693778017542 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark13(-10.536153777508364,-73.15787140836072,-1.562257929851256,70.58042763315527 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark13(-10.548507279147632,-73.15682189744831,-41.59197222336202,-48.20546598085286 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark13(-105.88277590427103,-160.38452483838591,14.506685011656394,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark13(-10.592980366373595,-79.00079003265864,-1.5707963267948966,-1.0000000000000004 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark13(-10.59533416684286,-66.73120286357448,-40.601336530229595,-1.0 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark13(-10.602654116786368,-72.99238745800902,-39.95187507741439,-51.33560853938049 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark13(-10.620066933089676,-78.73559043979182,-72.48580386266812,1.0 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark13(-10.641361468578031,-41.72731301728329,-45.03895677535872,-31.175005584298603 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark13(-106.62715877227264,-42.38788917151466,-32.444981296707596,-56.28107638170627 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark13(-10.667781052150332,-41.36508460556945,-3.02659095105712,0 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark13(-10.68829059541163,-21.998134870996473,-39.031549981146554,-23.58225702779464 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark13(-10.709030984178419,-42.380326948503,-88.09851024297252,-1.0842021724855044E-19 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark13(-10.736218741786814,-61.11479744386693,-1.5707963267948983,-0.3573088330836214 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark13(-107.58537850632291,-186.14876985785648,-0.3554631277274751,-0.999995106625138 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark13(-107.78150324913025,-61.05734714468258,-88.49485001704593,79.11696805067857 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark13(-107.93300331660566,-186.22580587915212,-1.5707963267948983,-1.0000001192041297 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark13(-10.829763461640159,-22.45335376874769,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark13(-10.966148096369729,-10.411726581140478,-16.34080549283216,1.0 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark13(-10.991787239952089,-66.76773494224642,6.4394826892526895,0.17011119271923292 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark13(-10.996224250935303,-3.6506951571615076,-35.689693228183714,0.058741916692557086 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark13(-111.74761240366126,-35.09961456893767,-60.802544953142885,8.769808404354269 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark13(-11.219177623885106,-60.896549526184145,-4.353510914176594,-2.4308653429145085E-63 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark13(-11.300275717417941,-3.9596062649469,-3.250002822012064,-1.0 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark13(-1.131215528250983,-72.86064872099371,-4.686826518229161,0.5179001655953144 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark13(-11.416904436854097,-72.80019543566789,-59.671582713088746,0.11548830850946701 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark13(-11.481681458031915,-35.59093680383488,-53.88737370480117,-0.8087224465523137 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark13(-115.84467065139796,-47.508369167519405,-53.8611891374119,-1.0 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark13(-116.34253742339526,-3.64047083394002,-88.28987280660573,-46.61608344095001 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark13(-1.17806129029957,-79.03539155048378,-0.07522369101083692,-1.0 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark13(-11.875390760644555,-73.14308294808657,-0.38025425339294305,1.0 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark13(-118.91323426793734,-36.09417939794034,-90.62396644117088,85.55083271059854 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark13(-119.02288202804783,-60.76972082014336,-2.6763772484185395,0.027199901714930252 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark13(-11.90452178212668,-16.001051969523132,-38.483951866016476,-1.0 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark13(-119.6628334130141,-47.19057364567985,-1.5707963267948983,2220.923908466844 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark13(-119.79992805656127,-16.18542723816377,-66.69211652391937,1.0 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark13(-12.005122124931233,-9.606394170977481,-90.11151746634556,77.26781829493146 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark13(-120.51175740009975,-10.007645596366146,-10.132678461137587,0.7986529699061774 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark13(-12.097918329745454,-66.50771185162884,-58.136339069246404,0.9225876140772937 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark13(-12.134374821470137,-41.44298355145301,-3.2516447354298705,-0.23620805968387734 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark13(-12.154107429308755,-3.359344665108793,-64.42384241917728,0.6830325351401709 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark13(-12.227014951289064,-66.23667792081599,-96.8454161534615,0.7858333257261623 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark13(-122.63223803339919,-72.40464479969341,-8.66138076907834,2360.305944976583 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark13(-12.315961936695036,-54.56823278403694,-39.83393489239558,-1.0 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark13(-123.32073790529574,-110.1247401378921,-40.64051083944287,-2309.806158762376 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark13(-123.79595192349682,-103.76925777981214,-45.46214220981648,-7.33364533624497 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark13(-12.427746860590283,-66.62104961201993,-19.363183376078293,-91.89584504016108 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark13(-12.490232653363748,-66.70224534284453,-28.244399090735712,0.5135726123986861 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark13(-12.534252591584101,-47.50671476082834,-138.65852130028023,9.817412138935812E-5 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark13(-126.04684923872472,-9.519729130087079,-76.9425059670659,79.76207871562328 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark13(-126.55208192512633,-3.315478336867767,-166.83999251864444,0.6837482340284824 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark13(-127.77264462399441,-48.26492310950206,-12.893884237625635,26.72249160743239 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark13(-12.803400054880132,-66.72239844314552,-27.67612368802199,-30.40525644935122 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark13(-12.841454592287675,74.84749917917031,0,0 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark13(-12.910771141459081,-47.28999802162049,-164.47110308033612,-0.6925502125487448 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark13(-130.2663407998242,-41.51397513888797,14.469575837460567,1.0 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark13(-130.94581309702556,-66.66218148154454,-27.51963790282312,1.0 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark13(-13.139077467491713,-9.995941852179712,-10.924819718466708,-0.5745655289692291 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark13(-13.213303929393645,-98.60859992687067,-57.094869893925114,1.0000040143040814 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark13(-13.229565136999945,-36.06407468615309,-1.5707963267948966,0.09275910792730024 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark13(-132.40797160027654,-22.457105609708236,-192.94926511570372,1.0672259006220728 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark13(-13.28867463949912,-98.6236993668675,-1.5707963267948966,-45.580496704940046 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark13(-132.99922750621369,-48.175228635534026,-136.11727470661089,0.38116134185774087 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark13(-134.52148402217034,-72.80331725226756,-71.21621460157526,24.397187681409477 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark13(-13.466388428206722,-28.350041183344743,-40.099736906145544,-84.06318653098161 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark13(-135.20601630344458,-98.08330399358911,-1.5707963267948788,-2199.5633167587243 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark13(-13.53275424823904,-9.93915497767258,-172.64090632658886,0.04219731388626944 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark13(-136.10411010147993,-48.242309091054544,-157.4679671689982,0.6993701427793733 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark13(-13.630509406159918,-66.56487621250085,-4.445779706337721,0.00803854225442889 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark13(-13.641823133328955,-36.109170297435966,-4.162269176170487,-1.0 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark13(-136.55521177450441,-35.195679977458354,-1.5707963267948963,2334.922037186623 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark13(-13.660620787676683,-35.12071375402652,-1.5707963267948983,-0.023946155181920864 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark13(-13.672213470893979,-72.81316710907805,-3.8138126486081605,1.0 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark13(-13.696301675625051,-61.020219120814744,-3.1847239158719556,-48.74002353329576 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark13(-137.02914065550857,-98.61574761238252,-82.29233616287581,2224.808621206556 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark13(-13.777975269296277,-16.05830540385287,-67.00153400726978,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark13(-13.934938043419262,-97.73382469437675,-64.92617813385311,-0.9602198160527334 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark13(-13.984049993951643,-10.276322337402348,-32.53192506455839,-0.038706065780303334 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark13(-1.4070444559565,-98.1043714312021,-1.5707963267948966,0.9140741634283974 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark13(-14.164206805013762,-66.33651699249873,-1.5707963267948983,-0.7354760046563138 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark13(-14.178994571796965,-60.8103828135154,-31.78463913307673,0.6612122508248324 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark13(-14.288391057331472,-16.180369548556676,-13.804132558583838,-0.8856736915441321 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark13(-1.4351294287968042,-16.14997301155067,-123.8897625191617,0.5124735699099121 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark13(-14.458354533789446,-47.341120535279686,-1.5707963267948963,11.379759845214295 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark13(-145.13098865157764,-34.908548205836766,0.6568876435345595,0.0 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark13(-1.4547940082134776,-40.97901435660751,-21.195472098543803,31.16324080964862 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark13(-145.8073659434933,-78.74927050518824,-0.1079409631634084,-91.27408533136344 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark13(-14.58866361948214,-72.87477096762089,-9.508476933912206,1.0 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark13(-14.594313982747002,-60.984885585944745,-83.39305973622996,-0.8678084439454092 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark13(-1.4599473074601912,-35.602707487225274,-4.6326011585799725,26.43195676636796 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark13(-14.621808639011775,-42.242424764738715,-1.5707963267948966,8.974845113273645 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark13(-14.703128505884296,-48.34584257118094,14.497264528659258,732.5214437862709 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark13(-14.721152944588857,-41.50593707749412,-0.8612116940497998,-4.535143158798087 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark13(-148.36142967858848,-619.5137777977848,0,0 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark13(-14.86138122302723,-9.498442951969785,-34.51636602855862,100.0 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark13(-14.906273955546457,-73.15824349729905,-0.9058961832420983,1.0 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark13(-14.919431009011728,-10.42316301861057,-0.1435534350855149,-96.28414884059433 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark13(-15.117120437668973,-41.772575710556126,-95.74696249696169,-55.86862357269675 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark13(-15.305464131739384,-16.121587971247287,-0.6518845359864229,45.54622257703603 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark13(-15.440286843948698,-22.382431141622973,-83.28984623466742,-13.378094150217464 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark13(-15.467908628601249,-10.117980556979738,-8.55646338923977,-0.05691211003117448 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark13(-15.578900969538623,-41.9518110166096,-1.5707963267948966,0.07861546750682358 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark13(-15.596962425829483,-3.596398572422526,-0.893939696440583,1.0 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark13(-15.66299162593815,-3.591762270446438,-1.5707963267948966,-24.46408440271344 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark13(-157.295102280056,-173.26330609615027,-47.10032300501372,-0.9999990350830654 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark13(-15.73064279013521,-60.713134867599635,-1.3120580161686242,0.6783896981491424 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark13(-158.1564120554333,-104.31251497856161,-154.49634407944302,0.04784484458686067 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark13(-1.5915458805526184,-9.637901138657739,-1.5707963267948966,-69.21855997856856 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark13(-159.4692694272496,-22.350674185506364,-191.66892723352007,0.06314109576331361 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark13(-16.000799827761295,-22.410381302391905,-31.547699539022517,-1.3269371747676352E-4 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark13(-160.5883746545623,-47.33694649549629,-1.5707963267948966,-47.06740749231657 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark13(-16.113868877910114,-66.96592483034858,-29.290232549730696,0.034470013677007805 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark13(-16.174613170629783,-98.68493329485639,-67.13250810216472,-0.8878665735149323 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark13(-161.81801809527786,-16.100462828755653,-0.27145406535383937,-1.0 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark13(-16.26475386493727,-54.66987383373322,-9.588629845119423,0.8184267959055316 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark13(-16.316163373282766,-35.461586891384755,-31.0324966742002,0 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark13(-163.30577372576136,-104.47260936297042,-10.425101607687946,1.0 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark13(-163.82826805317683,-280.1857884571689,-10.916480191067048,0.9753715956619544 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark13(-16.427576476693346,-40.98452298104836,-32.73713844296498,-60.97638859512442 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark13(-16.4653877126035,-35.533999636717354,0,0 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark13(-16.470341896014176,-97.94264098896299,-65.77044262038486,71.49881043970922 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark13(-16.675879924174932,-36.1240595918521,-0.05106984556874772,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark13(-16.717102357427546,-3.6834808462283632,-38.02181226822632,0.06239427909165751 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark13(-16.74416372706565,-79.03528429320463,-9.642602400077848,-55.39397466346983 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark13(-1.676992418123399,-54.722634139445404,-1.3094707753242762,-0.7616522527004164 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark13(-16.772745292350073,-9.959403597124165,-1.8209167534508826,100.0 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark13(-16.83572765418107,-78.83931645344558,-18.849692144022264,48.90685431460139 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark13(-16.856575647016253,-48.27454372238208,-100.83169546530665,-1.0 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark13(-169.06745019360045,-3.7587689135466036,-38.01519780019177,-2274.432537869438 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark13(-1.6953920195499697,-3.3083880449919505,-9.249389554666156,0.9999999999999991 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark13(-170.53536715379204,-72.95732026754487,-138.59227669030076,-0.04158736371655569 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark13(-170.83450886867803,-41.636906893168494,-39.12049803330202,78.76434697948818 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark13(-171.0039485502858,-85.01666328535194,-38.000959713611785,-2281.8401562762683 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark13(-17.111156725519464,-48.31924513254917,-10.995094678978177,-1.0 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark13(-17.16826356443471,-73.05255624300088,-96.57799042699237,19.339908441593096 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark13(-17.196453025539576,-3.770459852503908,-15.425362752464508,-1.6940658945086007E-21 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark13(-17.286286804950223,-40.99597630170694,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark13(-17.3273788849447,-47.289090984329654,-1.5707963267948966,-43.36715671956111 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark13(-17.33454202489702,-41.49502680144437,-90.75309186078165,-25.15456386861471 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark13(-173.5205406175382,-35.39752209293603,-133.4225844973818,0.9999983178937656 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark13(-17.3581739075875,-16.180650691302972,-0.5826147915438487,-0.9745296314422582 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark13(-17.40768187566897,-35.255832914041605,-52.36017471583334,0.4442724632155908 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark13(-175.05589362254375,-48.16506190017202,-1.1788163549535504,-1.0 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark13(-175.5818630723197,-3.450089217293069,-10.719764379034311,60.86193090405635 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark13(-17.83694840155881,-4.044730404093478,-73.75860680220467,0.9722238143848713 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark13(-17.958757222480642,-61.08073110284702,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark13(-17.983975953163977,-15.789552534529047,-6.801242984723733,-1.0 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark13(-18.130013547129522,-41.34632314959357,-3.412144112557968,-1.0 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark13(-181.34117443846628,-47.51393144869138,-33.972416716194516,-15.292581316459211 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark13(-18.268538533748316,-73.07638155359383,-67.32658542182867,9.300236635372794 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark13(-18.28503916083665,-167.4914240468339,-185.70263244044264,-0.942698589630178 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark13(-18.381584431762946,-72.83234196269036,-95.43837604418583,-0.04159766730900499 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark13(-18.48599023404094,-10.215754289880639,-58.937817793655924,0.9763937329429084 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark13(-18.512578290374158,-16.126628536084393,-103.86270841923417,0.4969639958588561 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark13(-18.566844100214382,-47.151666912327684,-10.256117423792574,-39.1765819264502 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark13(-1.8619848341605387,-42.076613876816516,-9.435187467383892,-0.19517762074650327 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark13(-18.62912081558977,-97.40219089985526,-57.827322941452195,0.06256925128853966 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark13(-18.693785699898484,-15.76997481950876,-53.70984258665427,-33.443438041742375 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark13(-18.747326720361123,-60.98150380447462,-1.5707963267949054,-51.258356605663714 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark13(-1.8791694568683823,-42.383305222386625,-38.81108393326996,0.6625617936185506 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark13(-18.834256313944707,-35.5836565617347,-58.67334139634159,12.037376237910252 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark13(-19.018780476152727,-22.394924468586225,-20.203311420418885,-1.0 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark13(-1.9025195989027415,-61.19713908671622,-66.45422617800037,-9.704457365635605 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark13(-19.03428073158862,-72.40750903855033,-4.173952563932161,1.0 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark13(-19.07166756594959,-72.26054818905683,-71.81739615289955,-0.5273107273584796 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark13(-19.243017170665937,-78.84502039044929,-34.50791921507938,0.0 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark13(-19.255021163605093,-3.4522680487111472,-1.4575007567645173,1.0 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark13(-19.399603490846573,-98.53612584937854,-2478.148555387749,0 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark13(-19.59199077248502,-15.857999797135228,-1.5707963267948966,1.0092966440373176E-14 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark13(-19.59931765958987,-48.682074484375164,-0.018506759906717324,-24.563292952216123 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark13(-19.69411042281743,-97.79134292484204,-183.64443670674032,0.01436173872183466 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark13(-19.93643999972906,-3.682330011759632,-32.585101061069494,-61.07727755283184 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark13(-20.169403364848918,-174.32046202073457,-1.5707963267949054,-30.165774763051804 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark13(-20.24227491996075,-3.483998011404921,-32.36479325178675,10.195127313539373 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark13(-20.281478204498043,-54.430417298637224,-1.5707963267948966,34.2779873635438 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark13(-20.3754951469104,-48.31217177153651,-34.1105736449978,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark13(-20.415014657427413,-53.41910637988262,-0.22277683720930383,0.8873417433302686 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark13(-20.48501673539653,-35.30388270988975,-65.95565449858846,0.0 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark13(-20.54439245307275,-66.60225772515906,-18.92676204640063,-13.908033909747765 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark13(-2.060717555143976,-22.48371659381381,-71.01332290738726,-0.06184698080375054 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark13(-20.60756993173124,-72.95267627791766,-21.354929772063798,75.40183883748837 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark13(-20.60959076663569,-10.113876180679057,-38.19676265146226,-0.6035976865786091 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark13(-2.0685863606019605,-98.12982056726864,-79.66918914458263,0.8543499640642436 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark13(-20.808442261426833,-78.68546463779082,-65.30294840153832,0.051395350653204344 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark13(-20.813824287612974,-60.74999506617371,-66.48786999353192,-26.003672111041496 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark13(-20.92110037546155,-78.95936967664178,-1.2410284011026758,-0.011825333532214266 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark13(-20.92967174320352,-54.482944167240625,-10.897064910336624,1.0 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark13(-2.094334492062149,-34.58873666300221,-28.24675530424539,-0.5920811973138882 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark13(-2.1019478333084662,-35.27462739524047,-10.619859463317889,-0.013364825187771368 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark13(-21.130895435887094,-22.298520744996445,-64.9889740969114,0.3490257771219817 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark13(-21.75585409959273,-53.453404448909296,-117.23271897148588,-0.32924293789358217 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark13(-2.180765422696055,-41.377318924979924,-76.93592978687933,0.746566101267522 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark13(-21.842071849341533,-78.80580396737,-88.36088645825146,1.0 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark13(-21.863515322449828,-35.81040934646447,-96.7503478634611,54.71369188712556 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark13(-2.1965269655533373,-60.734155638718974,-9.626683157261311,1.0 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark13(-21.977448212621738,-98.92010807815747,-115.72099642079044,0 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark13(-220.85265356039253,-174.1635209782122,-29.352924244958324,-0.00836965322884635 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark13(-22.174766827560056,-4.0921464764744835,-38.79798252665364,0.0021682615128692183 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark13(-22.21463064040679,-54.67140148360784,-1.5707963267948963,-100.0 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark13(-22.27328542943761,-54.4557800320902,-0.02568255964655134,-0.8145264411186527 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark13(-22.61661543302435,-41.395159734918614,-0.21677909726856034,0.9334159083121029 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark13(-22.667979232982145,-22.303171671788945,-44.0829165053058,1347.124124016617 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark13(-22.733614575488502,-36.07507768758837,-13.567642797534148,-1.0 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark13(-22.798490368568736,-78.562553899092,-163.42506181588874,-1.765785304605831E-8 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark13(-22.85190225635567,-66.69690875957035,-38.096563193005856,71.08071532673091 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark13(-23.077689979733165,-35.565715161703636,-76.96644925216332,-1.0 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark13(-23.167414307262995,-3.4748268117572536,-123.87962628658006,35.93272053710044 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark13(-23.16754297838972,-34.99778043022322,-1.5707963267948966,-8.372928463361774 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark13(-23.169620097436813,-4.010709929880728,-66.21409229736136,0.3895582235079532 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark13(-23.199158200605453,-34.88498180658655,-0.5433956658936436,94.75522948084947 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark13(-23.323068642801577,-98.10976866300177,-2.399986157455569,-0.05186233536501712 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark13(-23.326394952452667,-84.93734567595132,-42.403062487512905,0.05885174394660467 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark13(-236.56916422457363,-54.47098886405082,-1.5707963267948983,-2268.463286249211 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark13(-23.714758702305375,-42.082313219943956,-89.65015497580329,2406.620712102298 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark13(-23.76398487681209,-54.76755433438877,-140.54960549998125,1.0 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark13(-23.811788208219753,-41.97547437007193,-1.5707963267948966,0.05698930225705189 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark13(-23.85450911977129,-41.61375562401519,-39.140678659895656,-39.200984068399 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark13(-23.867040657528875,-42.319641773355784,-0.5262908041851176,1.0 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark13(-23.877358075773067,-34.881990906465525,-35.83584444865548,-0.2592411432887989 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark13(-23.898192615474514,-78.58107291013015,-22.592335813274403,0 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark13(-23.928133469690856,-42.317739092254456,-66.87651035798498,-92.06189470375297 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark13(-23.970569879786325,-60.94916096693717,-91.45902395406304,0.6623168620384501 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark13(-24.05000737161451,-41.823426695938366,-46.16203668026235,-1.0 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark13(-24.152806319435523,-47.38601671488662,-1.5707963267948983,-0.027773258207066054 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark13(-24.222786484842914,-53.64973580717045,-128.81427074007624,-32.062213940448814 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark13(-24.261304336320094,-47.60880192633519,-7.105427357601002E-15,0.5373785488177503 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark13(-24.267318337790158,-16.001492207354495,-96.55922553335446,-0.20709987600901858 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark13(-24.26734067958155,-60.83637212500188,-1.08123645876607,-1.0 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark13(-24.285019524164213,-9.937903024966749,-85.16479113182324,0.673601005907936 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark13(-24.322733964749403,-42.10622167704667,-1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark13(-24.400493913616014,-66.45698265853764,-1.5707963267948948,70.16386938652248 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark13(-24.492705144122617,-60.74266689269354,-22.760824611070746,-0.9646331426984676 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark13(-2.4592642797308804,-47.415200758956004,-27.660284398398268,-1.0 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark13(-24.661881532889794,-9.531619275889039,0,0 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark13(-24.738852162745616,-22.256377545130874,-1.2886529926392536,-0.05462695807317146 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark13(-24.847032111433265,-66.94449297572528,-0.45823047405031775,-1.0 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark13(-25.08203498487309,-35.90983478181839,-0.24442199417991617,-32.30271617543208 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark13(-25.142005043020355,-35.04766927406398,-1.5707963267948966,-54.64751545903929 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark13(-25.18008025694296,-9.969426461369196,-1.5707963267948966,82.967295712153 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark13(-25.2006197817293,-73.07446855718133,-6.943947687844101,6.83087360214674 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark13(-25.36668408950615,-66.56572741047027,-19.996799603511903,0.9311060752185215 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark13(-25.40275643957419,-66.60095641007055,-2.626800326858813,-0.02870387873046748 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark13(-25.554020111323002,-16.03503046078061,-76.15545874252837,0.03754867656227727 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark13(-2.558543870004926,-72.92550308162411,-88.53210364987959,-1781.8652714243003 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark13(-25.596114959686243,-22.402373739447484,-53.58809230418088,5.421010862427522E-20 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark13(-25.59751342420273,-66.66826813334782,-31.493109211409255,4.303254743490896 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark13(-25.68117406735678,-47.417471661137256,-32.48625595867618,-0.530188037234737 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark13(-25.6907298850996,-73.00001953254338,-90.36955306310516,-70.57979753868294 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark13(-25.700670819115558,-98.25990986215096,-66.44713688906148,72.23321607613674 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark13(-25.819176272128644,-53.41737769878246,-0.6668220806938336,-94.51049170605937 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark13(-25.8396941029468,-35.07216265940931,-20.22439472455188,-1.0 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark13(-26.011477503664743,-22.489280570535712,-72.58920262123252,0.016731369455301542 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark13(-26.12304754106771,-98.92022101543934,-1.7763568394002505E-15,1.0 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark13(-26.153463473648202,-61.246274053308916,-97.2742299899902,-77.24683892695813 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark13(-26.227685807961254,-97.87567511777925,-1.570796326794893,12.440784460541266 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark13(-26.289600769951463,-3.3876259356238805,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark13(-2.6309867958792594,-47.57089228612796,-32.87665734397576,-0.3717714152334963 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark13(-26.363255699842938,-41.96044005675578,-0.45487540114131897,-1.0 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark13(-26.37875618128812,-78.77842823649867,-0.7232769625263366,2166.240288759078 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark13(-26.50480181120645,-41.46861233746654,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark13(-26.578738433475642,-35.84826253499863,-1.5707963267948966,-0.9388686325046114 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark13(-26.58731998350124,-41.72920535734477,-1.5707963267948983,0.9999999999999991 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark13(-26.590946861307504,-15.868521038879074,-60.71303824467001,-0.0439437886701584 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark13(-26.70952576117267,-10.015815370252994,-92.20002878195504,-1.0 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark13(-26.816167996527174,-35.919319683283874,14.429295652242786,-0.17789787030630874 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark13(-2.683255051041371,-10.21193239381924,-73.76512244741396,-18.619052138892414 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark13(-27.142077176936407,-3.891426245809143,-77.63697607790665,0.03618345167011566 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark13(-27.159241684490862,-66.41021281724741,-40.82129659518638,0.9494728929989937 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark13(-27.19172728807951,-84.99290662332098,-1.479012529245113,5.551115123125783E-17 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark13(-27.193196393721777,-47.347682496713446,-1.5707963267948966,-1.232595164407831E-32 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark13(-27.440677707221916,-16.008838290118614,6.450303792866149,1.0 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark13(-27.44214166650289,-35.90866156149879,-15.539625500711495,1.0 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark13(-27.483491412470883,-48.39666840140614,-23.444897672264545,-17.67228452019873 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark13(-27.55079581022554,-4.10985536664495,-60.26798600345669,0.39995444069130603 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark13(-27.57274272301795,-78.67837229499821,-71.92578543292558,0.08269895497608193 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark13(-27.612516520094715,-72.4445118821431,0,0 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark13(-27.647371580441046,-98.92191310231513,-29.420491936177484,-0.8448921385632389 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark13(-27.75056991324854,-3.9381131055866234,-130.3561627656232,70.087750278183 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark13(-27.757631181511798,-48.18489715829528,-8.457840837916548,43.294752614464045 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark13(-27.796037548004204,-42.212501293391455,-1.5707963267949054,0.04066383933763613 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark13(-27.946509513827753,-66.0806540367119,-157.48257652121373,0.13690289334589512 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark13(-27.959994598379538,-35.45506395494985,-64.67450281467868,1.0 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark13(-28.051366100438543,-35.71749419129183,-77.45027514863786,78.72925759746784 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark13(-28.10917376934938,-98.73132531917017,-1.5707963267948966,-0.9996883771569449 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark13(-28.130523986403887,-41.8946493397829,-31.664812562239565,-1401.2245971051564 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark13(-2.8302440721687603,-98.76001542017478,-0.66149788336086,-1.0 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark13(-28.40925298055616,-47.56692293518679,-32.61707997213321,0.40357402142468857 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark13(-28.417066481989295,-54.6620958035071,-83.80480263963494,0.8266236646694005 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark13(-2.8436369194987723,-78.89094534060688,-0.09452849927238569,1.0 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark13(-28.60397021426296,-36.04265040602343,-53.9002781170721,0.023851900990880137 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark13(-2.861072486603163,-35.881741907212714,-31.64947028272765,1.0000000349550469 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark13(-28.682005632418893,-15.96711711291662,-51.22914308727591,-96.95492428826917 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark13(-28.83176164391878,-98.73575545617118,-0.6544613766303371,1.0 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark13(-28.85901520966884,-98.43883092609222,-4.560704878628872,1.0 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark13(-28.907861869485203,-54.74212756696348,-84.22279015769473,-68.62880907331466 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark13(-28.925558870995363,-97.83049459814221,-54.50834730180465,1920.2673377802373 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark13(-28.96115809705651,-72.85014113132951,-32.673484517858135,42.17573769927131 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark13(-29.089666332610847,-35.80214145427401,-20.060815300548683,-29.552769533666662 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark13(-29.099117324534237,-41.6994840435222,-0.14405504530491975,1.0 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark13(-29.189568157208228,-35.40661437850742,-67.0280962560715,-0.028579091632938952 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark13(-29.339619728778946,-3.844012854906662,-35.92554642612266,-69.68401415072971 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark13(-2.9344297143020697,-3.3323668820305983,-22.90332636277124,1.0 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark13(-29.365070994905224,-22.456037869037193,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark13(-29.38838918830687,-3.3354852108549267,-3.2063441812324065,-1.0 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark13(-295.28700194404894,-173.25396191751912,-1.5707963268056437,1.2584288775804446 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark13(-29.572461162129443,-98.17240529223125,-88.41019148037036,26.76849779966493 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark13(-29.596295658597995,-3.9393824132583077,-72.61916530757074,0.14150729875512003 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark13(-2.9692736508305444,-3.1639163618456934,-14.659376154371635,0.023082473408187004 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark13(-29.720605710874008,-61.01250952624716,-1.5707963267948966,0.03174146591540927 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark13(-29.809086787850944,-15.86864953950358,-1.5707963267948966,0.8026478465656963 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark13(-2.9863224056241022,-35.81920274689443,-0.9928634460931534,-1.0 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark13(-29.868572886684174,-173.8567417336742,-1.0325556479759759,0.12534898069042777 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark13(-29.961708283199222,-41.414513544691275,-1.5707963267948983,-0.03927869286376559 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark13(-30.002451624270485,-129.3533068159011,-103.4975544436955,1.0008565012817305 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark13(-30.041388185754244,-3.9854503307907834,-31.519720190586867,43.0920280983961 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark13(-30.089619819756592,-97.67566583209195,-25.964127664471764,-100.0 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark13(-30.143393249084063,-48.44726222710982,-51.00092444014321,-32.38410803726283 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark13(-30.20534659773303,-42.17843332738585,-65.49331355259254,0.05621681637815579 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark13(-30.35585026057973,-41.40123163690426,-88.15935452965594,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark13(-30.386973750783724,-4.086199449823155,-3.8747162489037805,-79.80458958936049 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark13(-3.0422242104688735,-98.14192164055102,-37.76913362673184,0.19752980710671864 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark13(-30.494090359855683,-79.03637071767757,-31.87381287543444,0.9999999999999964 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark13(-30.498832833911518,-103.78246538858961,-0.6569693686230096,-1.0 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark13(-30.641469307390466,-15.738050911023137,0,0 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark13(-30.753681742743822,-10.332602218458035,-136.5318085026199,3.6839368927581333 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark13(-30.754588205556303,-34.58235680887054,-1.5707963267948966,0.018229377092005117 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark13(-31.19342972283406,-35.637068240336916,-27.677519066266402,46.13026322911534 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark13(-31.325072622745513,-42.05898718574099,1.5408098534704473,-1.005351252029967 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark13(-31.329122668524946,-98.56380156207638,-88.05341321799419,-0.06265759928262477 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark13(-31.377682809692434,-3.601771143122619,-6.922341707594853,-0.08395897770048766 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark13(-31.671182696754414,-9.673687481126734,-40.335435550642174,0.8275926141906629 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark13(-31.738249054790415,-60.769871492479,-13.048967436271482,-0.7000194110927297 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark13(-3.174785829291611,-72.89939457300102,-8.545433948951782,-1.0 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark13(-31.846196704052083,-72.76313908168166,-2.6485209899528,0.6920762443999298 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark13(-31.89916428027435,-73.13087409865321,-53.667824800832065,-1.0 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark13(-31.905274076120232,-98.08420445144077,-0.728114684948352,-0.9999999999999996 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark13(-32.00016098311494,-54.47572637360596,-100.90733737446362,-9.526456548085392 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark13(-32.117832346328335,-35.297281415447934,-53.7529486145831,1.0 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark13(-32.220039509339244,-22.40482138981828,0,0 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark13(-32.28846575442101,-66.78541289863279,-12.816714514640907,35.510040898266595 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark13(-32.56229270892017,-10.164848028249665,0.0,0 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark13(-32.75814153638743,-35.83585969032893,-1.5707963267948948,72.24709233413917 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark13(-3.277099666083112,-84.95136418798059,-14.023898804852887,-1.0 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark13(-32.84382649270704,-78.77299988111504,-101.97537103611018,42.84897703700133 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark13(-32.959174624927236,-10.281909372606897,-196.1662587751924,-0.0021823879795636845 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark13(-33.00248111385041,-98.297389747359,-1.5707963267948983,0.9999999999999982 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark13(-3.308332645111264,-36.09281406364697,-21.157297604191456,-2215.0530383477694 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark13(-33.087366718529545,-78.99863588772308,-7.404680006387018,-1.0000000000000002 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark13(-33.18215031550721,-9.49384389066352,-0.42577118017123683,-0.362786754243604 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark13(-3.336518440045708,-3.2815941583322945,-1.5707963267948966,6.938893903907228E-18 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark13(-3.3485684054623785,-4.007476592154692,-0.23616485551943356,-0.8722583056574497 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark13(-33.58227360158911,-53.474596235827,-85.49278424458274,-2.788233172622384 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark13(-33.60991743861158,-60.9052693494923,-34.72947063037284,-11.917664526334818 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark13(-3.364782441079223,-34.92234718720199,-5.1950936048457965E-15,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark13(-33.700552448404835,-41.35084405587819,-159.17699217827516,-0.8603362668871739 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark13(-33.71376176879696,-3.835732792608192,-186.69530641058668,-0.04897730234294362 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark13(-33.798821481084346,-53.6172321797499,-66.72419796548863,159.90077322492368 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark13(-33.81214913964091,-42.201389178620396,-1.5707963267948983,0.6782574294561459 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark13(-34.00191176411914,-53.56331811524111,-0.24120938590570873,-1.000000076002076 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark13(-3.403084833781463,-72.50486163390008,-50.62046947823503,1.0000209102428121 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark13(-3.4131246809423974,-72.88690109879917,-1.5707963267948966,-63.3002169263411 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark13(-34.224422612118374,-34.995977442346394,-21.902067195728346,-0.3786599521117324 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark13(-34.33866728206684,-35.481185959519195,-66.44120732902893,0.038624303752792556 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark13(-34.49448985459222,-3.375143576947906,-89.2066660712059,-24.95124377340927 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark13(-34.57088970318148,-72.93280292013893,-0.866697317853233,-10.346582812637832 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark13(-34.63619127946503,-60.83853934481972,-1.1102230246251565E-16,81.55900784053587 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark13(-3.4703477433923666,-10.382389904741274,-1.0333082523617696,-52.25780618299471 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark13(-34.71398190234951,-35.78321340464302,0.5660041374727486,0.07362556513945819 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark13(-3.484643323448419,-3.8393954284608345,-0.5149727320166981,-0.01771704386354496 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark13(-35.13619097604553,-36.09278364839913,-1.5707963267948983,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark13(-35.167343982865475,-48.38834915976917,-48.15461111890882,-0.9999999999999998 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark13(-35.180219981444665,-53.60970027016914,-65.11403470164925,0 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark13(-35.2496128389738,-3.730110765189261,-0.21631644300984,10.530931541275216 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark13(-35.29805457691393,-10.349103352897032,-33.41365880703356,-7.565897273614141 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark13(-35.3839240965339,-111.35170853451683,-46.12860857286138,-86.87052780143034 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark13(-35.43894815441006,-98.41706481930368,-0.4931011981228534,0.9013832854108663 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark13(-35.444534338131135,-72.92398253580726,-7.272675576164443,0.934960561571035 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark13(-35.46553833263067,-98.18379116806956,-69.15204769405175,82.9199316778384 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark13(-35.48350723892756,-48.69183985607826,-70.79101768561623,-1.0 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark13(-35.55528595953288,-48.60469782421642,-0.9841280945103392,1.0 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark13(-35.73353037508715,-35.028020337941776,-95.38541217342326,0.037311796207287556 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark13(-35.75987252947053,-66.51588083491268,14.434382662619178,-14.591765074565657 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark13(-35.967269866193625,-3.8816357672641004,-27.323299833241407,-1.0 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark13(-35.97314786756603,-78.96174984658556,-96.90437032374525,-13.86632709761102 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark13(-36.026391901547356,-66.88339922021548,-1.3609761836039818,0.33656736615017546 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark13(-36.12898746992719,-10.27568981172216,-0.08934409480736205,-0.6361908254200976 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark13(-36.19106022933152,-35.732992235721355,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark13(-3.6271144208271977,-78.96454049057841,-1.5707963267948912,70.48575760481157 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark13(-36.27349640105111,-65.9967799670266,0,0 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark13(-3.6332662676607015,-15.960709150013855,-0.5677247022505069,0 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark13(-36.72337415245248,-66.60385103874664,-32.61047013945576,-0.4027893965698821 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark13(-36.78850933753661,-3.7701731014752156,-85.2593197637737,-0.015452169734578443 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark13(-36.80943270254824,-98.37957258550584,-57.771077813588036,0.6301576812071357 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark13(-36.90655460191481,-53.513333283649914,-1.897524120388205,-0.9999999999999983 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark13(-37.16051733679389,-10.38439637757844,-1.5707963267948912,-1.0 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark13(-37.20090827874225,-78.55939126429425,-48.42521529839159,0.0 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark13(-37.260903984053975,-34.57843212400773,-66.38730333831944,-14.047728957194556 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark13(-37.548380302193436,-3.2679103811328787,-1.5707963267948966,1.0597503111678954 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark13(-37.84670575299321,-10.01276267228614,-107.60593918291778,-46.046830015965384 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark13(-38.01232510200717,-22.264186331809128,-45.46058283753564,-0.5972836894963107 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark13(-38.018493814608064,-41.651118522089384,-1.5707963267948966,0.4313400778162235 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark13(-38.30079658480298,-66.68021432248754,-2.6304042944836334,2057.6277070035044 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark13(-38.31044155513474,-54.73803171640624,-39.76900148681804,-0.014206615490681251 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark13(-38.44968524068713,-3.9541777932373674,-15.518432617866942,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark13(-38.45980534413414,-54.868235739258814,-2.7434058658330116,36.353889743541714 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark13(-38.62826794442758,-98.04050254051731,-1.5707963267948983,-0.8262713159301516 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark13(-38.67279602440836,-28.360959406352038,-0.32862918497388965,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark13(-38.77206436066856,-3.599648613133378,-1.5707963267948957,-45.25841267385053 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark13(-38.827962005496936,-41.48462163280409,-15.198876961249518,-1.0 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark13(-39.18446352119478,-54.66684143757101,-19.3434871713404,-16.922390450785038 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark13(-39.27875412925339,-61.1202307035247,-73.48290978866314,0.9095010166382764 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark13(-3.928114316501393,-42.231343083205964,-1.5707963267948966,-0.27751715197173465 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark13(-39.282205696248916,-47.41379311475204,-23.167175939904958,3.573506316701355 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark13(-3.935936406172061,-61.05817087068,-85.15466500689323,-2123.664728699772 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark13(-39.500971849422065,-362.8396865283413,0,0 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark13(-39.55364033185987,-4.0593437014797935,-154.19610975890117,0.5300209074924709 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark13(-39.704499081638424,-34.815247070425734,-1.1643009189100322,0.9924190813015618 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark13(-3.980228331145942,-73.21675169708988,-0.4730244737941379,33.90696232933133 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark13(-3.98999986268835,-42.1879735840206,-122.58645922293628,-2.0879869816039847E-6 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark13(-39.96094082388808,-15.810808129214848,-10.920304128694962,-1.0000000874408244 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark13(-40.05913688137615,-15.842172001228057,-48.09939224749535,0.061148635500077014 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark13(-40.15171042082801,-35.18208873308781,-67.20392789113993,2238.05464567725 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark13(-40.15211321880443,-15.95083230654086,-9.178118336492957,44.510754279444 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark13(-40.1743329914346,-41.853102079879825,-33.70528902392297,0.9210621668359784 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark13(-40.63385611989455,-54.4854861069624,-123.08053851425119,-78.29390799644943 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark13(-40.696699554889605,-60.87372111781953,14.4292995068108,23.097459324204586 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark13(-40.836648944532385,-9.632723156742145,-14.453222725815422,-92.64926350875359 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark13(-40.874719951186066,-98.1218183249972,-78.86709958980265,-0.41517528792152114 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark13(-40.906031731152986,-15.809622372603114,-0.3063906642732541,8.366420791336447 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark13(-40.90739818813891,-47.334932432568536,-47.321860547695685,1.0842021724855044E-19 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark13(-41.01165577871029,-3.1435457785897936,0,0 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark13(-41.11018268862179,-98.43458064299604,-2.88539102475805,-0.0075845428130140585 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark13(-41.18203372453482,-161.51301201828304,-1.67590051983872,1.9663411564529E-12 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark13(-41.25743328221021,-3.7330787953673905,-31.649108718471297,-1.0 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark13(-41.39952818753713,-3.9820038109768676,-0.06857123229065074,0.010894701046720828 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark13(-41.404216717583644,-54.721838710724214,-29.170037964121178,-23.782259967981158 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark13(-41.54609268784243,-48.34151910035007,-10.426164612513926,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark13(-41.66489437560928,-35.63237384857633,-0.3237545982585854,3.217223493417518E-86 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark13(-41.8030413262925,-41.04717005566234,-37.814531681412745,0.6877739136182572 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark13(-41.91028881832513,-98.91752909654461,-126.69842454476996,95.56539147174433 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark13(-42.00605221578395,-3.5003964130443936,-0.4617417481383167,-100.0 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark13(-42.08377990295737,-98.11013633471465,-9.523200023350313,1.0 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark13(-42.093874182820734,-98.4344602953577,-31.803687482659242,100.0 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark13(-42.14783022786912,-3.8464892264456125,-83.53548146185915,16.09565775173381 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark13(-42.62798732062625,-160.4515796331682,-46.472104000618096,47.98611035165251 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark13(-42.64632246532185,-36.09075556189922,-0.33680895339508654,10.482889361396445 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark13(-42.723167622833095,-28.393022745491734,-1.1240876096796635,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark13(-42.74754340214809,-66.67190461153969,-0.7382011530702657,1.0 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark13(-4.291868171416299,-98.85578233015111,-19.41199329525843,9.576796896118385 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark13(-43.008211339234144,-73.05609613770382,6.70014257448164,0.9999999999999893 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark13(-43.085107401498085,-72.96727360070304,-73.02815545288466,0.3620892957993232 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark13(-43.117589807787006,-54.49663677221899,-1.5707963267948966,-0.022874844306061383 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark13(-43.146321688859366,-3.7364725368586047,-66.57448972752618,-53.342808580409745 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark13(-43.30135082188506,-84.90250735817746,-0.7382289662984738,-0.668567305829538 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark13(-43.33759190080486,-3.4977378017068905,-0.4347475708093924,25.618061767508223 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark13(-43.57396780409475,-91.11815223580761,-53.94462470593817,41.079543453842774 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark13(-43.59363870185465,-3.5680435755155173,-0.8945822431393806,0.024995680463084126 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark13(-43.66200256546775,-42.14921006824368,-73.36702727805097,1.0 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark13(-4.370243225954923,-22.310957125903947,-84.02363721719877,-82.5749723865839 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark13(-43.80190965752439,-60.89992062515739,-88.47858460445852,-0.3542358860101258 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark13(-43.91345164580165,-72.81636684492887,-1.5707963267948948,1.3910564524017202E-8 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark13(-4.400756868012664,-34.63960363965224,-1.5707963267948966,1.0000007114208407 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark13(-44.00910856904709,-35.11091241395728,-1.223909167972331,27.204478786501966 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark13(-44.05842242887136,-47.53540084370974,-1.5707963267948966,0.21917104360637088 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark13(-44.21918318199601,-41.56853081370168,0.02383908527293837,61.78901008008819 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark13(-44.46677756427353,-98.82223841321272,-0.2736329902488982,-43.596651476156254 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark13(-44.67579270761182,-3.2809579695750557,-93.56582861725644,0 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark13(-44.67769677328184,-98.380239452734,-45.093719276293065,21.502735438283025 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark13(-4.469654403788772,-117.51430355065912,-50.680682718063245,-0.05719885828506149 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark13(-44.79939676317779,-3.7952313159846427,-20.579918723554712,-40.55619877487304 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark13(45.00639656839982,72.92637620590239,87.20123598773165,0 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark13(-45.06576526774117,-73.01601531914592,-94.35172121734296,-0.011094616566144508 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark13(-45.07698941807605,-16.03224322927008,-0.23735477489390777,1.0 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark13(-45.253713479866434,-3.279894102064297,-0.018865064868826692,-0.04913875212851279 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark13(-45.29708984290901,-35.00124297009886,-1.5707963267948966,0.010582692612774766 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark13(-45.30888676210685,-66.09327856163287,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark13(-45.351444361868346,-53.424040251474715,-29.370993119109514,-17.678288728869305 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark13(-45.352095980705364,-41.370858218326674,-1.5707963267948966,-0.8458900735181443 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark13(-45.35241370005937,-3.6646624091042383,-64.82830822539367,-0.04041585074382148 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark13(-45.36296394585247,-97.72737463263057,-28.36621970327269,-0.07744689769396229 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark13(-45.379854460669904,-42.00397121197029,-180.4313996097639,-100.0 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark13(-45.430836171288874,-54.520528351608675,-134.07817603709623,-0.41281196655468566 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark13(-45.460128170851114,-66.83273079393692,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark13(-45.51065239638665,-72.48013176959081,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark13(-45.546197538563085,-10.280220676445467,-1.5707963267949054,1.0 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark13(-45.61031558001952,-22.389072823258502,-77.2033652210418,-30.712033890727945 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark13(-45.678494135691274,-54.87234978345177,-13.932560845983154,-1.0 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark13(-45.687625487917686,-48.51510316435013,-1.5707963267948966,0.014302626053265932 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark13(-4.570879367606665,-3.3397786019109796,-1.5707963267948963,1.0 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark13(-45.7215205632714,-16.05405987296767,-184.63959437136893,-0.056473261324984314 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark13(-45.8824253270966,-72.50331553237021,-97.71465448316648,1725.9765137551042 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark13(-45.909109063206046,-66.82767677614848,-50.46257194884183,76.81499117291821 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark13(-45.94745864305459,-34.84061210185519,-41.72766707966279,-26.28312116973778 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark13(-46.01566884949986,-78.81848215158115,-78.18207988038985,93.27370795397002 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark13(-46.25254342933041,-9.605376856902813,-90.8478006269925,0.17433663853755776 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark13(-46.49153879920499,-35.789221811786405,-1.5707963267948983,0.7448059704628633 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark13(-4.653541375243564,-78.97479617016745,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark13(-4.661336772085852,-15.978985567808023,-66.21072676681764,-0.7001572479513223 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark13(-46.73185060501979,-54.66682435955905,-1.5707963267948966,-0.017628429811730725 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark13(-46.90452660626731,-22.25762588848243,-65.87330423934586,0.9999999999999999 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark13(-46.92494769358555,-54.66126638987269,-66.24119496917643,-1.0 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark13(-47.08430333075761,-4.040978396146983,-95.12753268032527,-0.2904237939661689 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark13(-47.1224024759167,-4.0371166793263455,-37.719130182191186,23.58037899040049 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark13(-4.720638537962323,-3.1586954043559388,-66.13153735891547,-0.8274812389083184 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark13(-47.219264009048985,-66.75445734900697,-41.18027155871155,-84.43362375218939 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark13(-47.339172054645935,-35.03022477057382,-8.558358872972963,-0.6649558072906254 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark13(-47.5031761902739,-10.00448701291306,-0.238144959032062,61.82422727181502 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark13(-4.7967488179219515,-42.11500551562452,-1.5707963267948966,-0.01845682236845006 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark13(-48.029004857516526,-72.8460598936516,-33.1049104917416,51.353445077371106 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark13(-48.163498483519376,-42.24983395281421,-27.70989179611378,-7.15543922533136 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark13(-48.16444392320862,-61.057764303955565,0.044265708626719906,1.0 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark13(-48.38380783830508,-78.75588418986013,-0.09751150032521347,-81.32699641415442 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark13(-48.456082074503534,-60.9395175646554,-38.868178005651416,71.09938473504883 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark13(-48.53566107927166,-161.58282530147142,-1.725712842630208,-1.0425722252315393 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark13(-48.53598499520244,-35.69994570849913,-76.31086384507155,-0.6585846501282646 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark13(-48.68848651334726,-47.54571764670076,-1.5707963267948966,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark13(-48.68937456742371,-3.507746493091629,-7.605068872656265,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark13(-48.776070450812675,-41.605966546485654,-2.838179525861439E-16,0 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark13(-48.90148440497277,-47.41746345254065,-1.5707963267949054,1.0 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark13(-48.94216383516165,-16.181052301393766,-1.0012486532290779,-1.0 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark13(-49.05459402055156,-110.08368564993671,-88.15103694987697,1.0000000000000036 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark13(-49.08855351463587,-34.66109474183132,-73.50734978359517,0.6344840245093608 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark13(-4.923019305630904,-61.17826697587512,-69.30660423620361,0.9281645540619974 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark13(-49.2512522241904,-47.236393846615826,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark13(-49.484527187279035,-35.99253111961609,-179.45289223440923,75.64735303968168 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark13(-49.60472912081444,-66.94756975317115,-65.12312651381178,-1.0 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark13(-49.6569903553619,-40.972795252506174,-15.485886939096824,5.293955920339377E-23 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark13(-49.879764491118635,-53.65010751426732,-0.9135280827993927,1.0 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark13(-4.989278082889243,-35.866686598661964,-0.04409749326583742,-57.63673181722759 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark13(-50.03469425279001,-66.78396743619209,-65.67974941074868,-3.490226167918351 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark13(-50.30161537359727,-72.79593050585162,-29.219701347433784,0.005760707245796359 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark13(-50.336047905890894,-3.950485316630477,-83.482365432792,72.68076755012075 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark13(-50.38843107425458,-78.96536307682449,-1.5707963267949054,24.62500986892495 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark13(-50.49802447934584,-54.67203434965865,-44.04138784615459,1.3552527156068805E-20 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark13(-5.050834113182285,-98.03519386090802,-14.321958397519907,-0.06264997545364731 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark13(-50.5364830487336,-66.07919545519293,-0.07976686757270407,0.06255425743815084 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark13(-50.63087136117193,-54.905330518428975,-58.96954245361538,-0.7122234816212334 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark13(-50.664263855647185,-9.985155043429543,-122.72466773091644,1.0 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark13(-50.84731957629183,-60.89983897979166,-67.14847670976067,-0.06255268882533792 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark13(-50.97328870207819,-22.389700801101174,-1.5707963267948966,-1.0000000000000022 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark13(-5.103981596524928,-53.548782384051194,-0.004948859852470365,0.7443550517042858 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark13(-51.056722823400904,-66.2289059468315,-157.3817626025303,-0.9999999974727384 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark13(-51.27783979986647,-60.9048579019226,-4.348259056691618,2.1684043449710089E-19 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark13(-51.392957022377736,-78.71410525625578,-0.6040026069950121,0.35627481396452065 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark13(-51.395673190069196,-9.984582722471629,-67.31427153447748,2.6420464400917467 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark13(-51.47952928062108,-47.587040620072926,-66.49753704122843,-100.0 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark13(-51.602047360786834,-66.4055443844092,-17.151857957587215,-0.3643466158541442 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark13(-51.673660171195486,-73.21356985121027,-4.500030591344608,-0.038207595714020354 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark13(-5.170643111530122,-35.77977180614748,-8.06829818199769,0.4619839515347728 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark13(-51.73192780935074,-41.921252804165256,-15.36802379798226,-0.307247432071339 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark13(-51.749207593257054,-54.60621427674508,-72.81317766586153,-95.76054203761981 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark13(-51.791171133126625,-60.90190034807317,-1.4237859413515963,-0.8956935786467211 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark13(-51.80555086128763,-35.13923032792813,-1.5707963267948966,16.48868126745566 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark13(-5.187829056928682,-34.92493900192858,-1.5707963267948966,-0.8621312670586174 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark13(-52.042055603664735,-16.090707161735985,-92.51125490281011,4.1002661789349907E-143 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark13(-52.20823990670545,-9.948113154878104,-38.00101789904659,-8.271806125530277E-25 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark13(-52.69036523378867,-66.35879233564496,-1.5582910897251252,-1.0000000000000036 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark13(-52.72941776647987,-185.72583118695675,-63.90247087352153,-0.04219435407352032 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark13(-52.76527840346654,-98.41572329584072,-53.6848966756193,-0.6904335461384075 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark13(-5.28517225021092,-97.78862013991414,-1.5707963267948966,-2305.962310834512 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark13(-53.010203419453305,-22.27963671155551,-15.692520252091557,-1.0 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark13(-53.039287419908014,-36.117397452568724,-23.420985817802432,1.0 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark13(-53.03946926104963,-48.39845516312522,-110.52612291461367,-0.4479963309032655 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark13(-53.28788163259437,-98.20061765392099,-18.98421066812142,-23.94171565649357 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark13(-53.34099220951249,-10.033412519631833,-37.71411453189346,0.4382349726246275 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark13(-53.41666793175445,-41.69269950668453,-38.48231321156145,-0.9669283526524608 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark13(-53.728857531162745,-111.15056758962217,-96.00836729024316,58.17230072426054 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark13(-53.785964317942536,-66.3765458216173,-9.847643765274626,55.19263939299334 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark13(-53.81009344388508,-54.58499963199815,-1.9318074809913586,0.8890938002889106 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark13(-53.83314228967586,-78.73205963767533,-0.5830264130789855,61.14615060777598 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark13(-54.27653150140331,-72.87307351819268,-90.53523926147417,1.0 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark13(-54.30283785183623,-53.48420591076144,-27.66334494141671,1.0 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark13(-5.442455336305819,-9.492646761362252,-9.817793785876418,0.7881109342229624 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark13(-54.49538698660185,-9.54595956970595,-7.105427357601002E-15,-1.0 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark13(-54.69626918180156,-66.75398304716897,-56.67588108708414,-1.0 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark13(-54.74365019848342,-78.85483325141561,-1.5707963267948948,-1.0 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark13(-5.516113197818819,-22.371967237119932,-9.43871315262058,-0.6993911738087042 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark13(-5.53014790561687,-10.011368975846452,-44.09208172203711,-0.06255256743780868 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark13(-55.31251506199786,-98.0364468675562,-26.114328777958733,-1.0 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark13(-55.41979267517649,-48.580041484489264,-0.3458074627826778,-16.15827078981077 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark13(-55.519259102442085,-61.19144245521272,-1.5707963267948957,0.6369114613773661 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark13(-55.54095407694879,-141.8064323096057,-59.28019333570083,-0.22936970101615073 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark13(-55.58596140365697,-35.560301697205944,-82.7752914196507,0.9999999999999933 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark13(-55.62113840745101,-98.51916784600625,-1.2706676276918694,0.29173323859653166 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark13(-55.621600799755285,-155.1015211522647,-101.56431932533147,67.30776218426399 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark13(-55.628655673820845,-54.814530355395554,-104.89212989348225,-0.010868678946739763 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark13(-55.75161881086657,-47.607543008536915,-1.1103539475749797,0.8994683504034517 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark13(-5.5751769347489715,-54.54256585206328,-33.744844625348435,0.7054517976556745 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark13(-55.86438659626285,4.141592700526669,0,0 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark13(-5.58977708398592,-22.39556668337464,-27.056339749416253,-1.0 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark13(-55.9135871627267,-98.34752178059283,14.475100670734037,0.32209963450595325 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark13(-5.602453243704553,-22.442547646713056,-19.982480523120127,66.96436783636645 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark13(-56.330465952250904,-66.40857955449832,-0.5579734803350643,-2100.4661471940008 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark13(-5.637734063762352,-60.878120404472135,-59.20957919797183,-17.161576338484494 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark13(-56.65596309662012,-72.8289869390868,-96.48199015543554,31.466885200923368 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark13(-56.75967543084981,-54.5441306063494,-69.75253437942035,-1.0 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark13(-56.83785049880057,-53.511546888459534,-14.981403350902994,1.0000170064589649 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark13(-56.88543371098891,-48.66116526775504,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark13(-57.03270756133107,-34.81061443488494,-14.397754183358206,-5.564626800747519 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark13(-57.16425077185096,-78.86608193697766,-0.34654466217698476,-9.080522240631202E-5 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark13(-57.45933560782153,-78.96558121822652,-82.81643811198708,0 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark13(-57.47663680642645,-35.869711179999214,-1.4375213729945315,46.77355899962825 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark13(-5.749635218626605,-15.940640818785852,0.2823451829490907,1.0000002767306126 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark13(-57.57194058823241,-35.76707617164996,-33.78925357099302,11.057895454962072 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark13(-57.79388050478757,-48.34195295911519,-1.5707963267948983,-37.24058281533833 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark13(-58.064912401120374,-98.00297270690635,-4.683001505282661,-0.9611697492170934 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark13(-58.14607895836593,-9.662141534855303,-1.5707963267948966,-0.039071328494506924 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark13(-58.159306731361056,-47.4132982842971,15.129544163748314,-37.361756696682626 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark13(-58.16395763300228,-66.70131564350703,-31.701137942953565,0 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark13(-58.17848733612225,-78.8450585863345,-29.829516151342137,0.0 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark13(-58.25201904196551,-35.12530117958883,-73.42891062705273,52.37014841001448 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark13(-5.829132228909824,-3.9268349236247744,-0.2326736574015591,-43.67515387418557 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark13(-58.44158965376396,-66.41506372352148,-32.65172920973073,0.03278811387901062 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark13(-58.50618307156674,-9.524015238429158,-67.1987932742182,53.575753335701194 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark13(-58.55674041042731,-28.395026013730615,-15.381961722589246,-0.014392045435951406 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark13(-58.773348058732736,-3.7126602860604976,-91.61524292146964,-1.0 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark13(-58.90620033699762,-10.00935192663392,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark13(-58.97101308191601,-3.6700118023678954,-123.75074709120415,-81.05522348026378 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark13(-58.9924370802716,-61.00109615378335,-12.653327822475035,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark13(-59.11684894642298,-3.8648504668411334,-66.5914306631107,-40.04867574656055 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark13(-59.15427536592717,-4.114916057585887,-3.4061850229327675,-0.038583540755388945 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark13(-59.32596838322368,-3.9720858217107478,-1.5707963267946567,8.673617379884035E-19 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark13(-59.489072253696825,-10.022338065763472,0.2679883092551484,-1.0 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark13(-59.6946936952364,-98.52180296494092,-164.43022708120657,-0.8157602618755854 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark13(-59.759079439240956,-35.878514100570044,-0.3793973249648218,-0.9999999999999982 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark13(-59.98449501599479,-60.964551894344474,-31.89767686919759,-0.06027788766124732 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark13(-60.009926119368096,-84.94127379612942,-10.649084890808929,0 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark13(-60.04379311214578,-35.39717999883656,-17.23467620305677,1.0 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark13(-60.07665411703551,-54.570929046359694,-98.01704439131534,-0.33982739445782584 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark13(-6.028171827254377,-41.63650491818427,-0.4031246619913712,-27.52252127728967 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark13(-60.29089749349483,-48.648656346297244,-64.98109221912078,-6.077163357286271E-64 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark13(-60.35458752992746,-36.03836616893567,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark13(-60.35976686685912,-66.60574777658196,-1.5707963267948966,0.4554904162256306 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark13(-60.49361760728987,-78.70320303142968,-34.012296891147145,0.8384340506847182 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark13(-60.52469988704001,-72.45481101741309,-11.876868736188229,0 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark13(-60.613836000545426,-98.34417205634021,-35.26065283172905,-97.59473645615047 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark13(-60.653168529653534,-66.65825063377551,-0.5414220573928682,-1.0 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark13(-60.653806717461855,-35.08259778985314,-50.85976488062955,0.6420184628625927 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark13(-60.69786754750819,-66.6554093602316,-31.656438815245693,10.451391783854007 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark13(-60.78463731460623,-154.60602496312168,-80.00398267208351,-0.06258689025254797 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark13(-60.93457309305519,-60.9445972280378,-0.2820697370439467,-2049.8609784041505 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark13(-60.97729716825224,-97.90434006972359,-94.81751106755875,-1.0623063069525749 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark13(-61.0997675791269,-191.6633548637225,-1.5707963267948926,-0.5374042087814388 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark13(-61.421031544523274,-16.115284832895327,-4.450256579113574,1.0 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark13(-61.438847257841694,-47.53380573429803,-19.324884370485766,-21.98550403537207 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark13(-61.443294367082274,-10.340287619082702,-101.10414087113645,-53.66009433576794 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark13(-6.14660734413327,-10.132551036059255,-4.223993565424478,1.0 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark13(-61.66182183117623,-3.3741338909632503,-9.4696711707862,-1.0 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark13(-61.71324037088424,-42.13373276878025,-0.7258064037130045,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark13(-61.73543881607759,-35.05873378920236,-38.1409892831581,0.0 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark13(-61.806294937753606,-98.35623562300255,-67.33704148177549,3.2220752225955636 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark13(-61.899029977855356,-48.32786566539823,-0.928352174479907,70.3439735148458 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark13(-61.98930976087888,-116.45999315053935,-101.07284985369343,0.021014229243376592 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark13(-62.25399467284294,-40.89299527294106,-1.4210854715202004E-14,0 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark13(-62.4022237274954,-54.66998146061166,-19.5316808320081,14.48085027292825 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark13(-62.468255122352026,-35.355537000989926,-60.55374796285393,-2.4308653429145085E-63 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark13(-62.61140750343235,-16.02280774722854,-84.90448327361304,1.0 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark13(-62.64259441843057,-78.70603133450726,-133.9092219326252,-1.599218102467314E-9 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark13(-62.65725625305038,-54.95718129112855,-1.5707963267948966,9.56880259595342 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark13(-62.7672494548031,-15.731128132571449,-73.52716187913043,-60.48704787728374 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark13(-62.82746307743608,-54.942981442449124,14.437189836310267,61.36580821727315 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark13(-62.859865470417866,-3.9022628932091843,-2.7755575615628914E-17,1.0 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark13(-62.86972203391267,-22.383946342080066,-32.48416739216162,0.041330185645788754 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark13(-63.07953942096069,-73.25460694879064,-1.5707963267948966,-13.18068872991104 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark13(-63.214315279904255,-78.77895121867276,-89.4726813273522,0.035468526717262416 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark13(-63.398895379190186,-60.86574950274052,-0.13441540637039207,7.298400750678013 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark13(-63.46838170329903,-78.86203663087335,-1.5417174259596433,0.9999999999999929 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark13(-63.52701099670652,-41.92394184907767,-0.945867260125911,-38.487601772621446 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark13(-63.60232721903066,-47.349275959739266,-1.5707963267948966,-0.9999999999999982 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark13(-6.38126621922341,-66.50174738129276,-1.5707963267948966,-0.05645946149510073 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark13(-63.86394047806794,-22.336488686867895,-0.776476920359854,0.4802375583132332 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark13(-63.887284608152314,-47.47077660890146,-2.9650895063226006,-2.020552501226489 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark13(-63.93378781382858,-48.39646673264861,-32.52023308763441,-0.710019304683227 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark13(-64.01508246167116,-15.917053605871828,-33.51850276505334,0 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark13(-64.14386645980214,-35.69673509250259,-0.37534360990768156,0.06251737709856531 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark13(-64.15621503706417,-85.05862692999148,-77.30755631569082,-0.7487433127825283 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark13(-64.17986830913807,-61.05028123166312,-1.980760427637993E-15,-1.0 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark13(-6.429184939255791,-3.26944197490419,-1.5707963267948983,43.883436359777185 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark13(-64.30520294164509,-42.106804554322764,-1.2590658673697792,-87.87604795185703 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark13(-6.436522884559435,-3.820438539202371,-33.72603116092637,0.0 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark13(-64.38840007258206,-35.426358810753335,-45.29771555979105,-100.0 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark13(-64.54841588287498,-66.7850379174064,-27.936882393772308,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark13(-64.55586943538763,-36.117777487538646,-50.59404604881486,-100.0 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark13(-64.65971228458875,-54.752219569679625,-178.22177466495222,-77.7876532488692 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark13(-64.72298941670113,-47.543002477587784,0,0 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark13(-64.82639938444396,-66.70426030800596,-57.117935133150766,2.7369110631344083E-48 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark13(-64.91309365697032,-78.87948111447407,-21.218579033890947,13.815369241701987 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark13(-65.06072500743112,-15.737868212831785,-31.815036976249107,-9.011559479630577 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark13(-65.17394408308131,-3.7242560840904786,-31.674789211250474,0.03469625008465964 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark13(-6.550412929340835,-41.769686560198515,-1.5707963267948966,-50.74466747603998 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark13(-65.88647632673158,-66.58482961949943,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark13(-66.3814110555819,-111.01626794190553,-33.74516317042345,-6.760050781264609E-9 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark13(-66.5606110513549,-53.64020422106846,-6.391412727532142,-14.59567411069385 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark13(-6.657957750546499,-3.455783935211258,-2.518557086245181,-1.0 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark13(-66.7403294942627,-60.69756179709738,6.840527184630852,1.0 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark13(-66.8814329121708,-72.96912804632302,0,0 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark13(-6.692370052853304,-3.766824994795769,-22.043750217954653,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark13(-67.09622751890132,-97.42206292021957,0,0 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark13(-6.711941448624589,-16.19524076126217,-3.0509274215864117,1.0000008764359678 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark13(-67.28621804853766,-3.5437453754161936,-1.5707963267948963,62.0697984796612 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark13(-6.7421720175155135,-35.99242787233027,-76.7721649136509,0.49362555734922375 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark13(-67.4955671177609,-54.49803013316274,0,0 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark13(-67.51006259782609,-22.386740336817333,-58.92877241029888,90.7283853010575 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark13(-67.54627085816321,-66.65831005947618,-4.411866222857249,-38.55001052781082 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark13(-6.758042710546135,-48.153474311563386,-85.79636283569701,0.26058668635788307 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark13(-67.61437352849376,-48.53209907105194,-1.1226868014574667,-0.15486516628032865 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark13(-67.6200511913785,-155.1382978971723,-86.13053570095825,-0.11700934993328094 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark13(-67.72390773984633,-16.089500715296538,-1.5707963267948983,-36.51752248877329 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark13(-67.74990943484366,-10.249505564394129,-10.538229521796618,-1.0 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark13(-67.98699274270895,-10.364301316209541,-70.05827103884582,-1.0 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark13(-67.99180931566565,-16.097924865700676,-0.2840788975391161,-100.0 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark13(-68.05660911561033,-16.084483108886698,14.58748477239206,-0.05605857607714593 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark13(-68.17982254797464,-3.7867543468111347,-0.3749284424512316,-5.0758836746312984E-116 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark13(-68.5717684123666,-3.966236973912764,-7.413694146966421,12.16479296227865 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark13(-68.57465578957516,-9.551202295749498,3.6537760951537357,-34.86465823473321 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark13(-68.63423523757947,-35.03641038377974,-26.73633118551191,1.0 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark13(-68.65101515369166,-129.26362206777424,-13.119312154849865,-1.0000229913352574 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark13(-68.78764532889677,-22.400264795518943,-67.16342535717777,96.18128951831227 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark13(-68.85148203673285,-22.272037754872755,-1.570796326794897,0 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark13(-68.85461385977207,-98.40010983397735,-155.0512061799478,-1.000003940535052 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark13(-69.14485442895187,-66.79898612654924,-43.19930728640933,0 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark13(-69.23532632525502,-10.402941894267073,-1.5707963267948966,73.07287853499724 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark13(-69.23933355384175,-154.1213174685338,-19.874161731221847,1.0378284122916552 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark13(-69.4857519532966,-3.528461064091619,-1.5707963267948983,-2145.3652000466823 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark13(-69.52986144520243,-15.707963267948967,0,0 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark13(-6.956183570700318,-66.49398271887236,-58.19966353199815,-75.56362599023605 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark13(-69.64008217743331,-66.9276480088791,-14.006676166219686,-100.0 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark13(-69.68139339535387,-3.434102998379366,-1.5707963267948983,18.075188650970816 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark13(-69.69554960901196,-47.29727691905368,-0.8938167536020225,1.0 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark13(-69.75922662900071,-22.404225840909046,-52.84369128620517,-0.979779679405238 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark13(-6.981630850966003,-73.03152059111235,-88.33941096064535,1.0842021724855044E-19 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark13(-69.81955012621519,-3.9819872694382474,-1.5707963267948966,-0.9810539294608832 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark13(-69.95102577268797,-47.33415761003191,-0.17024278387857505,5.514728195561009 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark13(-69.97852620686824,-10.120898036552546,-0.011042089278717533,-0.987220424999223 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark13(-69.99124827006597,-79.01109178609312,-1.024878477003874,-1.0 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark13(-70.01153728693399,-15.875002194945068,-191.8722497528947,-99.77333193220484 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark13(-7.0037934189559365,-16.044901043862268,-0.8256829378025756,88.38845906304252 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark13(-70.19706296120492,-66.31344986932868,-0.07330147836917611,63.58933546231768 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark13(-70.22817765830871,-15.975575368937285,-1.5707963267948983,0.6661261149918171 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark13(-70.37076361556313,-35.09603659111834,-10.641174715423489,-1.0 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark13(-70.3721276504095,-59.731192416941596,-7.4582878690072985,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark13(-70.40295399442523,-72.40131370288844,-37.79498251261292,-1.0 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark13(-70.6164931234576,-48.32986894595504,-136.2474268308335,-1.0576518717773737 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark13(-70.73615014601762,-3.972430743055308,-1.5511391942634922,-0.517958379514445 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark13(-70.89472688100619,-3.6114884012900603,-15.344713635235784,1.0 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark13(-71.03418159226658,-47.326435141174095,-0.29628874648668735,-1.000000000000007 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark13(-71.1214715220118,-16.160498799276212,-35.279809645970644,-0.5863874310224295 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark13(-71.28973189593702,-98.46920780171557,-100.99073680851909,-9.672373137403559E-4 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark13(-71.29590260598788,-42.2093550765981,-38.45364446974501,-45.08131275287282 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark13(-71.33080561033314,-54.82887295240082,-13.668810229155218,0.4390783970190425 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark13(-7.144063949113871,-174.04628536325743,-45.20559999958835,-0.6079369630338396 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark13(-71.44203178494641,-35.030262273237156,-4.195962044134974,7.31511930420656E-99 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark13(-71.49665822641018,-22.020278707473132,-0.042767363509565115,0.7696679537082143 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark13(-7.158656613317476,-54.964872562085375,-1.5707963267948966,-0.7842063937425058 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark13(-71.63235568357364,-41.777391232942584,-0.5716407082078365,-1.0 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark13(-72.05833566558167,-53.50287690570805,-84.04609634204152,0.04964629035988111 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark13(-72.4878301571752,-98.15105296141725,-59.435119978412516,12.463211973059792 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark13(-72.49901869344626,-3.3137382440604863,-100.76416600045255,1.0164043266191185 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark13(-72.50921946255546,-98.37033414217638,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark13(-7.250936050851319,-47.29857579109385,-70.21767554968775,0.11742911048169702 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark13(-72.53813696564566,-98.92105533480657,-88.33341897165889,-0.038934711880316386 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark13(-72.58330611367685,-22.353096323691624,-81.83141868634416,-0.1083794332431296 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark13(-72.75778662920001,-15.737708725182316,-1.5707963267948966,0.9487376185562686 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark13(7.281988841197375,36.66626657408602,0,0 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark13(-72.86430118568981,-40.87604619073628,0,0 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark13(-72.97064241588988,-3.8337492326183735,-73.65874896305256,-2129.763986477569 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark13(-7.297752676328255,-66.5047484966095,-21.91071606863143,-0.4599717857261215 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark13(-7.29781513915324,-47.433564334600774,-18.90711528252264,-0.9385919912936871 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark13(-7.304615669502937,-15.802438278981263,-84.72814251726521,0.9015287815749211 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark13(-73.06942097547199,-60.87693619293245,-26.855333482056864,1.0671983792198552 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark13(-73.26626580922057,-3.9441412463646657,-31.607861132995865,-0.9999999999999964 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark13(-73.34165012108261,-41.369298299974716,-32.915953687565526,77.95914835769423 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark13(-73.41631137352287,-35.344919704789675,-1.5707963267948966,22.470129415968856 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark13(-73.596307418322,-35.113868945508635,-76.74928627637493,-0.30172343275293934 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark13(-73.6663404076806,-15.893104818168268,-57.928067854685466,42.56859076121272 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark13(-73.69722329793683,-3.9679057190658042,0,0 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark13(-73.73880813806713,-48.55531438134588,-52.0740054615949,69.67932993799135 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark13(-7.383730770303475,-34.63240033111394,-52.03379630886498,1.2994262207056124E-113 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark13(-73.89251911909766,-66.31142440160204,-44.97567168904394,-55.414350465462405 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark13(-7.39489568219896,-97.66243317559145,-0.8450776361737408,-1.0005340080397194 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark13(-7.396472051766921,-98.33888184102607,-92.13320132764142,0.26157748580546425 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark13(-74.09259088172335,-3.4563209348230117,-63.98807312524741,0.05318574205124293 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark13(-74.12333922946978,-54.49120799296882,-0.09087002593609701,0.0 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark13(-74.19554980723103,-3.3506578512305225,-89.13133445770309,-1.3234889800848443E-23 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark13(-74.626559934175,-3.4438639589303364,-1.0687997871098958,-45.2526946440091 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark13(-74.74797935137664,-72.76195454207792,-129.57876681867404,-0.9142797206306987 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark13(-74.77582382754497,-53.62415825604798,-32.21822328573112,0.24150931002038578 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark13(-74.81427569451826,-78.7019047243027,-64.16102817243194,0 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark13(-7.49033653887544,-22.387252158469707,-78.2498752959506,7.916269138303107 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark13(-74.91292886294839,-97.75474676764269,-59.1402965067517,-0.06255253065399388 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark13(-74.94433583883595,-3.41429568755372,-73.30869309583403,-100.0 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark13(-7.4964381678371375,-66.36545778653868,-45.05996043345802,1.0 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark13(-75.1301126545893,-98.5081416291328,-3.1143956134929596,0.6464132177408275 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark13(-75.53682368165798,-15.967798425759817,-0.26605016300507167,-29.640464354789643 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark13(-75.58067646739067,-47.479201169372104,-1.5707963267948983,-0.7552957202498423 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark13(-75.59157314814908,-66.83193025283262,-45.054126670478446,100.0 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark13(-75.7282342296501,-54.70169851840099,-1.5707963267948966,35.74054258954013 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark13(-75.73630121492492,-35.12031911516699,-1.5707963267948966,0.7618988859615753 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark13(-7.574292859710059,-42.18291691915334,-73.27502225053522,0.742835983613274 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark13(-75.8018641095379,-78.92436375118065,-0.17783177394520921,-0.7823575261122002 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark13(-75.88128607936909,-35.235292392770546,-1.5707963267948966,32.93543147960281 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark13(-76.07058111291113,-42.36370793628844,-53.732042506703294,0.4822971456040257 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark13(-76.12039909058808,-36.09413871604843,-0.08542742792446963,2119.8515178841258 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark13(-76.23931923817074,-35.31355215361039,-126.76313057563006,-2.916107746778664 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark13(-76.44098659241276,-66.33098013458525,-16.13579216267017,-0.0077407696523994485 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark13(-76.44660456304968,-84.979540157276,-39.10155921103838,-57.91434370537871 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark13(-76.54638801091295,-73.18433290314314,-8.555087641837648,6.629151736930783E-7 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark13(-76.68407338781282,-73.20717384559099,-0.2516263912592631,-63.02271187135462 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark13(-76.73462343506729,-41.730914941528496,-66.96008282766239,0.044337578950922205 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark13(-7.679220957356209,-174.002759468779,-21.078181359240666,1.0008075909772791 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark13(-76.838712243514,-28.354655327332722,-0.9630141727566921,0 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark13(-76.86208863309862,-66.78007598438411,-18.967743070058418,0.9856681792506992 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark13(-7.703980804915119,-73.0530113157179,-34.25578535300784,99.30069596312606 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark13(-77.11911982237834,-60.71472231015999,-9.331911236302211,-1.3234889800848443E-23 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark13(-77.14099559586023,-66.25729725060272,-0.005096459594557043,0.011344775225806175 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark13(-7.728150316455457,-72.92453341527951,-85.91767663328082,-1.0 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark13(-7.769293271018242,-66.67087986911754,-90.2749439136381,-54.062671139052185 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark13(-7.7857191143255715,-3.141600282984325,0,0 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark13(-77.88062257814624,-35.65614553353407,-247.5061550294937,-69.17136899908385 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark13(-7.799857433788726,-3.998473755045419,-1.5707963267948966,-0.9727216223239776 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark13(-78.12772726276113,-22.313571786760036,-34.45296311898623,0.06256006791862008 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark13(-7.817149146222518,-3.7618368089689898,-1.5662295428927961,-0.9629443592576334 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark13(-78.23654510389814,-35.15915886878143,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark13(-78.32252980867338,-35.38665858881811,-82.23249624095821,-0.023871106623429242 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark13(-78.47955026305274,-98.15778606389526,-1.5707963267948966,1.0000652692731988 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark13(-78.6915583195476,-34.61166048800564,-1.1036961996551646,-0.43286933467524236 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark13(-78.76773491466189,-60.89313064059117,-9.024463456086714,-0.9275980344935144 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark13(-7.877321102918265,-53.42053270959341,-9.61619859386846,-0.41331779671402546 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark13(-78.80019090301249,-48.5799934343059,-38.765118124253235,1.3206754299820555E-9 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark13(-78.88225933019343,-22.30489008082455,0,0 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark13(-79.10647891667244,-9.536351888486298,-1.304113671652543,1.000000003029176 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark13(-79.11105878947953,-41.72399281809436,-77.91142762514467,0.0 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark13(-79.21081909488194,-47.50476083166055,-136.46563433653495,-34.219956874943556 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark13(-79.4095267162661,-10.096951670451958,-71.31863007162222,-0.6894734318983802 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark13(-79.48195545794142,-66.5703453429047,-44.0891877863793,0.6487325838099185 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark13(-79.60205570864694,-35.474721318997105,-1.5707963267948912,-15.934445948076604 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark13(-79.64893863346254,-72.81589121125984,-78.12006253588206,-2161.9613415079243 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark13(-79.69838094436064,-35.38861501802289,-0.00900114975009311,1.0 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark13(-79.84481667025975,-98.6753852070271,2.516950174913269,0.36587929820087833 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark13(-79.91858845880468,-41.992144928866374,-44.346754686709545,-0.7033128248578091 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark13(-79.93953853265357,-59.74629368633039,-16.264054706233644,0 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark13(-8.035284511906404,-72.91349324820663,-41.94013208702027,0.0 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark13(-80.35939665519084,-98.41288346692095,-2.201343554336596,-55.034819419493836 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark13(-80.41702429852131,-41.89062783995463,-0.610007854331684,2202.08507111978 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark13(-80.43845956609468,-66.52073012657165,-72.73308888779906,-5.4995416109747035 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark13(-80.57663968399038,-72.91230095644619,-104.95450225030191,44.949459137548246 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark13(-80.60282512971222,-48.5437134569991,-4.574093211210055,1.0 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark13(-80.6723883166609,-10.14702494868164,-9.658922625217189,1.0 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark13(-80.6799830201632,-41.94361816268679,-15.369948072913786,-0.14091760993066815 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark13(-80.70775044724425,-98.04296081685192,-1.5707963267948966,-17.116351915494747 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark13(-80.9858618673087,-34.609901940450975,-1.0514079768290026,-1.0 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark13(-81.00495629371049,-53.52586428016991,-44.294598777657505,0 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark13(-81.02381726712994,-66.09439078559207,-58.558747380324505,0.7917273762803629 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark13(-81.1741117422873,-66.43283793356076,-34.38825642648541,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark13(-81.44928899768283,-9.657480341932127,-73.80576440687162,1.0 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark13(-8.152291020869015,-72.83348668019775,-67.23518371663485,-1.0 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark13(-81.54012697934945,-48.31171653482582,0,0 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark13(-81.97361423562907,-97.91135039044876,-1.5707963267948961,72.608125135087 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark13(-82.33380726642493,-48.63300122311742,-4.6191646086220395,1.0 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark13(-82.42304197409507,-54.93701954873611,-13.11558119203836,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark13(-82.4943301289192,-53.60549300727274,-27.18603385570802,-0.4112614645751339 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark13(-82.5344478467603,-3.6548744226092924,-42.15236209946001,1.0 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark13(-8.25945364961639,-72.46629841125831,-73.68107162017223,62.883255337754775 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark13(82.60200393002415,-34.679959123014044,0,0 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark13(-82.83284309793319,-78.69075097295665,-0.5116674605406022,1.0 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark13(-83.0814147497817,-66.47327140323067,-0.9026074673343341,-25.46058928560734 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark13(-83.12113177897459,-34.828245131403165,-0.647290209088784,-0.8311124148983878 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark13(-83.24593616307948,-66.93325433724053,-121.31149371018432,0.8703102181574565 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark13(-83.2526937171876,-47.584499764811916,-2.023492304443609,-1.0842021724855044E-19 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark13(-83.26675538445183,-47.603706607855926,-79.70984570279799,-71.00583365484874 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark13(-83.47646137334513,-42.10050065055552,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark13(-83.50974594859089,-35.71731978365911,-1.5707963267948912,1.0 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark13(83.58886472571686,-47.59190748576969,0,0 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark13(-83.72009956187887,-22.310174294131954,-83.12008320553954,-28.642964014120437 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark13(-83.7499274037675,-10.37236950013153,-0.4334746628831212,1.0 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark13(-83.92476623105344,-3.839250748048002,-7.2818139729091635,0.28598235422341034 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark13(-84.01210260546267,-78.82221916240157,-91.39660240490683,-1.0 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark13(-84.12741567416384,-66.08342133231625,-46.50253952353248,-0.5657697102134973 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark13(-84.28098388149579,-54.569712127997576,-0.1567722416897649,0.9292597639203427 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark13(-84.28337895216926,-41.95698119267515,-4.549573438009844,0.017467143296247656 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark13(-84.49332275788785,-3.8800554538518517,-18.95659254613003,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark13(-84.58765041632846,-53.55763003306983,-73.4076216270797,71.4310017584646 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark13(-84.74430615175758,-60.90235433269171,-6.398690334203442,-0.39949157794201895 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark13(-84.78114799896005,-10.214029960298227,-31.708416123848984,0.1604772858462843 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark13(84.90307898367791,40.284001197456945,42.37681268907059,0 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark13(-85.20544168947598,-35.67443419507857,-84.64244330403312,-1.0057031461344792 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark13(-85.21018386248997,-61.13900346673579,-1.641216447639124,-95.31128709355387 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark13(-85.21864582483293,-66.92514016043195,-25.956501282681348,-1.0000000000000002 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark13(-85.27858692060923,-10.14382936872353,-7.105427357601002E-15,19.55976240609023 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark13(-85.44915125681858,-15.939907394059432,-82.09008304195453,1.0437182758038688 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark13(-85.54520121883378,-41.073152731452886,-27.196886308267338,-1.232595164407831E-32 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark13(-85.72847249104747,-35.6495125271164,0.2864502567856143,-1.0 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark13(-85.77418312581793,-98.39868919454801,-53.15964897564229,-1.0000000000000142 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark13(-86.05591933532331,-22.490801196384123,-30.570192984975364,0 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark13(-86.1333053433916,-10.007396963713731,-70.36655999527073,-1.0 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark13(-8.614650470750764,-34.911604505314116,-32.60890654792642,-29.124105476461615 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark13(-86.15978854134462,-98.27353802832398,-85.49296861476572,0.08990427555077929 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark13(-86.2140294962047,-98.12348244528211,-1.5639025960501494,0.931045765051016 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark13(-86.43029159508009,-66.56562594381936,-101.79650131475523,-0.02532087512920315 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark13(-86.48760457332696,-10.401672902558289,-1.5707963267948957,0.0 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark13(-86.50259621327334,-53.48218825868389,-0.322214246980899,-47.04397611798051 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark13(-86.51399515537052,-41.84915258286995,-10.92927036016669,48.775246202778895 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark13(-8.66632238628975,-78.77863150051682,-33.522968809093676,-14.734484542941033 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark13(-8.671561809169486,-53.54484526836156,-33.30763414761714,1.0 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark13(-86.78320104500187,-98.73249805268027,-46.7293870689724,-100.0 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark13(-87.01787126630609,-35.04794858660203,-145.28153828816372,54.575062897886 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark13(-87.0922249502693,-48.45890373029727,0,0 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark13(-87.09385933840746,-10.353308494553351,-8.15150319864952,-1.0000618452041468 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark13(-87.50874210416376,-84.93028723633856,-15.164097280457938,4.004166190366202E-146 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark13(-8.787899194449636,-47.52066452184279,-32.92415069771883,43.006320440876806 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark13(-87.94830890616004,-66.07114718499443,-139.85005321068152,-0.9087111364927978 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark13(-87.9673747474031,-15.854801338881302,-31.439251039051037,28.37576926998375 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark13(-8.800366552330528,-41.02805602046847,-1.5707963267948966,30.70715603484334 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark13(-88.00557306120871,-3.68661043862717,-1.5707963267948963,0.2803556700964771 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark13(-88.12327030957951,-72.83139852347236,-91.03853330346027,-0.9673327593026297 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark13(-88.14390104684418,-66.04149136193158,-32.180526774811796,-0.4954574633719342 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark13(-88.15900689563084,-35.08680895363672,-0.23918002617518763,1.0 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark13(-88.16171138135678,-15.794463523581141,-1.029313313017821,1.0 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark13(-88.21352980454786,-72.80775387206964,-69.22677665338122,2260.627389995625 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark13(-88.22781885901476,-78.714855980908,-46.91120187257554,-29.26014786303452 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark13(-88.25937952219638,-72.26375690323098,-0.9795530693083976,30.04627541373773 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark13(-88.60265741172594,-97.42007758808347,-8.903239786164129,0.8992756020467407 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark13(-88.6241545982593,-72.8788120571133,-1.2579045472788866,-100.0 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark13(-8.8691599549084,-97.41577612053965,-73.3594217804542,68.52995294786697 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark13(-88.71869554938007,-72.97793327917432,-1.5707963267948966,-1.0014190528443423 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark13(-88.83954928195891,-15.912348939817129,-16.931840455644444,-1.0000000004416871 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark13(-88.84845138862056,-35.76489388458924,-163.54430399730003,-0.9979766581208881 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark13(-88.96385909570202,-10.316609504532309,-1.5689907300596753,1.0 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark13(-88.97823715982625,-98.50241978456567,-14.036114148417084,0.15566549287030373 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark13(-88.99327150936986,-84.8958006330129,-45.52267356438196,9.127868305589203 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark13(-89.0187923925129,-54.689555087600176,-1.7544518130189886,32.253861977065824 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark13(-89.08568419015117,-42.17649449358256,-0.4050338311635989,0 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark13(-89.08679900317931,-35.591373220377065,-88.50740219739141,54.41995681432995 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark13(-89.28420139927519,-35.34375013990109,-85.04731897374194,1.0 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark13(-89.4533550026154,-98.71448695206554,-64.10655443652698,-16.220784527749956 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark13(-89.64196608400137,-104.19895802339492,-33.24248656651429,-95.17525259498383 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark13(-89.6633820759316,-10.321522332846019,-1.5707963267948912,1.0693787022800194 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark13(-8.968421954944334,-66.40555435662664,-73.73329269138256,-2222.154695483145 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark13(-89.84192921281186,-97.64628394538245,-77.90651803747954,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark13(-90.01361457832752,-9.640168223080671,-72.02939488159781,-0.9230774631782322 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark13(-90.18309108627554,-42.32631668054053,-9.328671978898697,0.0 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark13(-90.21310492710657,-3.1415928920083758,0,0 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark13(-90.43726890400931,-104.77506375350681,-60.50218956579805,-0.3129358040105359 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark13(-90.67067514812796,-3.85657035860794,-95.81116303824811,-1.000961138334058 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark13(-90.930709578974,-73.25561109838364,-85.29803568971434,-0.9999999999999991 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark13(-90.96590927021552,-16.16758679376733,3.1171266717414166,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark13(-91.32624248936503,-48.26785309753867,-1.3813580741616156,-0.9429133769345817 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark13(-91.32827125814289,-54.91993493825173,-1.5707963267948983,1.0 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark13(-91.34393947093534,-61.10554290504142,-103.55068008419994,19.717330826827208 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark13(-91.4579721716998,-84.97743353458353,-1.5707963267948983,0.7064809176954145 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark13(-91.5710389331701,-48.34269361941381,-44.27735842058087,0.44432362574288087 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark13(-91.6139082763527,-15.769460357949406,-1.5728313328484214,-0.36209363394436395 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark13(-91.85456035674608,-73.12896165473626,-69.2240723053106,-1.0 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark13(-91.90485295986723,-61.16657832570513,-1.6882140229406888,-7.97003408188823 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark13(-9.194483652458757,-15.966654167631491,-44.070782844995435,-1.0 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark13(-92.17300556135248,-48.50480589897555,-78.99887825167772,0 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark13(-92.19635645612104,-97.43288323559727,-1.3976802730437896,-1.0 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark13(-92.22097192931628,-10.190073060928299,-123.79170667589847,-1.0000026118816057 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark13(-92.36824083058117,-48.50089926455345,-95.32646465500521,-1.0 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark13(-9.238636952566686,-47.60041897334351,-0.31093835241983925,-1.0 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark13(-92.56998538973318,-73.1002453123806,-88.37596772100534,-1.0 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark13(-9.267259755859783,-48.64791754858914,-59.33089671166304,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark13(-92.75840186479599,-41.82736374542177,-1.5707963267948966,-0.7540939149762591 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark13(-9.29316068535537,-41.58599364703245,-44.08367974375558,-29.766756408795374 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark13(-92.9388724319295,-110.154593357032,-88.27894510422179,-0.7590946341874858 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark13(93.00895926525595,-35.20771263085554,0,0 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark13(-93.05181281284693,-3.894732814979804,-1.5707963267948912,-81.96379118287746 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark13(-93.23053748449084,-16.144263731718112,-27.487986827705924,-0.5989196096066746 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark13(-93.29502957601407,-3.37119268388643,-1.5707963267948966,2.039157646249539E-56 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark13(-9.33278954762011,-9.939175386299425,-1.5707963267948983,89.7368418511216 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark13(-93.38372889573401,-16.021637225214192,-44.28700983231013,0.5909874656294458 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark13(-93.39595854050378,-3.525343951762011,-45.127107963788305,0.2822950290635314 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark13(-93.41708651504743,-22.332714071436662,-2.360086423152822,0.6558726760383935 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark13(-9.350589338958486,-3.4948214365529227,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark13(-93.58981180071822,-98.72482467144167,-61.00739078146938,-0.7459574143450545 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark13(-9.364136618875971,-72.93839120828945,-46.30270747624401,0.06096485174926913 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark13(-93.96859215121192,-22.299049364088845,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark13(-94.038954841257,-98.32288245007906,-2449.033079634945,0 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark13(-94.30340386141945,-97.70905277330985,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark13(-94.56586193002529,-224.4336652453683,-83.4390880305004,0.23408464461225376 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark13(-94.6243701290164,-48.31871247598324,-1.5707963267948963,-0.9999999999999998 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark13(-9.469109019701918,-98.65807739008054,-78.57010371634314,0.9985799377863426 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark13(-9.475895209657551,-78.67854789842661,-1.5707963267948966,2.1684043449710089E-19 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark13(-94.81674823988214,-54.75923109414978,-71.24881856490099,-1.000000101904048 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark13(-94.82577257351986,-35.65675090780113,-19.357590626078093,-1.0000000000000004 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark13(-95.14407013484808,-98.22795524709728,-3.246618501431065,0.9312729727361684 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark13(-95.17021531364476,-34.81931901743553,0,0 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark13(-95.19379541359837,-47.5383781683574,-9.513043786407536,-39.732904810371885 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark13(-95.21829436810214,-48.599557614874314,-88.8364648737712,4.630799821557844 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark13(-95.28718997806409,-98.00672692625707,-32.49237338486451,1.0 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark13(-9.530655932614536,-66.6655970603959,-59.31072370185773,-78.18522074245831 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark13(-95.55239336512997,-9.981509636007123,-67.02464270033386,-0.9999999999999982 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark13(-9.556667622068161,-61.076494404100245,-29.393999830102317,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark13(-95.83540373351092,-10.054457558710482,-108.02413337195767,0.5939973288276071 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark13(-95.86960393220888,-3.505340823014749,-88.3513869898947,1.0000000004414293 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark13(-9.589169278151564,-79.03164220152652,-34.30804071264046,0.002701409468939086 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark13(-95.89648389183424,-66.62528290195283,-1.5707963267948948,0.0 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark13(-95.95530023906782,-3.294680368476205,-1.529983002738971,-40.495981489172884 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark13(-9.616674181808676,-34.58253866483025,-31.62939873254281,-1.4562795061539964E-6 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark13(-96.17207427299437,-98.34990281960151,-45.313803734794654,-10.555994719751254 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark13(-96.1826894334941,-85.01011551170158,-9.86863327738058,-44.8297740318103 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark13(-96.24698235100375,-10.152109860518589,-9.739875141911561,-22.137954671636194 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark13(-9.631489668333023,-47.55479980485209,-1.716695922645072,-63.2245262543238 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark13(-96.32667998666508,-35.43609541612433,-0.9106502109129084,0.0 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark13(-96.44943906084691,-22.39704673161473,-96.29179757646992,13.570326535694132 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark13(-96.48702442514939,-154.32216104288744,-1.5707963267948966,3.517586338194847E-15 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark13(-96.64208377613457,-47.24750973982099,-88.26167515200288,-0.3816812450074274 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark13(-9.669690295646426,-54.675942599171236,-122.26605935281331,-0.07656945924005498 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark13(-96.70903191986127,-3.6431064882825694,-1.5707963267948948,-57.03166265948627 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark13(-96.94934969983096,-10.116904838518282,-31.685446441859796,0.12415275048944097 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark13(-97.05933762062607,-47.29332781612143,-83.86231093307812,-0.16800747725464027 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark13(-97.17680016790686,-72.80863833050867,-1.5707963267948963,-80.71350009268043 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark13(-9.728169294711549,-98.91470601681823,-0.03025588862302339,60.64948097684098 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark13(-97.28843323451564,-54.63728436332355,-89.8642500663159,-5.275620326208966 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark13(-97.28962685277419,-3.6255257382608503,-29.13343231597173,-0.9682664342130687 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark13(-97.31396911458145,-3.4505346499942107,-66.0734024871465,24.327060246090262 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark13(-97.54912754780476,-22.291335426985665,-77.19016690077301,-1.0 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark13(-97.86441608781925,-22.321781177659545,-126.82443475832295,-18.043593528065756 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark13(-98.15051707187524,-97.89539905556109,-9.665239310013462,-0.03722504122377679 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark13(-9.822011699297326,-41.87620467637316,-0.16884331181359358,0.0 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark13(-98.23226666111928,-35.627677270789746,-95.77570909116062,0 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark13(-9.881238803604933,-35.68380957406676,-50.56819371171444,0.0 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark13(-9.88155123733516,-48.43335331954468,-134.68399283395584,-9.072379229250004E-8 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark13(-99.0365007616054,-53.47487623829657,-1.5707963267949054,-98.65193427064492 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark13(-99.15132659925534,-35.62060857265778,-8.826090053571022,-0.8656861570837586 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark13(-99.18372604133387,-3.6469828658355965,-69.49417048105579,-1.0 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark13(-99.26519373199156,-72.45083025845096,-64.17403699908093,-0.031774937333423084 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark13(-99.28546088921853,-3.7230397445051393,6.874503806874839,0.0 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark13(-99.3976703530556,-98.62558326385545,-88.11351925953866,-19.9695351108695 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark13(-99.47129590906725,-78.89517097680455,-164.14410543882053,-1.049044874088837E-5 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark13(-99.4881554023349,-3.467625106961547,-51.961650541121344,0.9709689485973821 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark13(-99.51257290425055,-53.45219798679004,-14.351624435533523,-1.0 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark13(-99.807162824477,-66.29989007657954,-32.721448041727164,0.16505150273183455 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark13(-99.81395945942276,-78.85847352171244,2.429913305508163,0.015161796005161439 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark13(-99.8519025466299,-42.036185314769305,-73.47780384154288,1.0842021724855044E-19 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark13(-99.90459291303476,-97.68570812319348,-1.5707963267948966,-0.9758514051553462 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark13(-99.90809203312081,-3.460615853268024,-1.5707963267948961,-1.0325382869825999 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark13(-99.93368485120429,-98.0824493992077,-0.49722216494702665,-1.0 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark13(-99.94266801365382,-73.25094325556894,-44.90341846852112,2.7075933226925683E-6 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark13(-99.9766554239466,-35.7529836368698,-0.13778941892204133,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark13(-99.98243202895733,-22.410399601620995,-0.22685402507175312,1.0 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark13(-99.99088904737772,-36.03967425379011,-31.717887603477298,1.0 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark13(-99.9998276210243,-15.892665711809999,-0.00677439697481251,0.05052736290722243 ) ;
  }
}
