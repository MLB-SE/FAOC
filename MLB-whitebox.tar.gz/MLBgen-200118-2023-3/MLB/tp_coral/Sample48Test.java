import org.junit.Test;

public class Sample48Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark48(18.723497823553487,89.84072949511676,-29.702042001030932 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark48(25.605357288161414,-57.91422351531783,-32.308866227156415 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark48(-31.204559707809267,-84.79983214903012,-88.11419608998938 ) ;
  }
}
