import org.junit.Test;

public class Sample45Test {

  @Test
  public void test0() {
//    0.6730165725319744;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-646.1565739894487,78.6944389948087 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-646.6967498252768,100.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-646.9574161974509,100.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-647.5719966306244,100.0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-649.3372563142561,61.96624610673774 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-650.2286271544643,100.0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-651.3764162542648,18.808067861542877 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-653.1249831423853,86.56154189371024 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-655.2271060603231,39.796591467128906 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-656.8494034462124,7.105427357601002E-15 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-657.0399264228378,100.0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-661.245895256085,100.0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-662.6247145976758,7.105427357601002E-15 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-664.9051823237878,92.12893668416478 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-664.9709841026535,7.105427357601002E-15 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-667.4555313437885,29.997527136704747 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-668.0219664134949,29.2737077553885 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-668.5160531770375,100.0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-669.8647633133396,100.0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-670.6980918483629,57.19355111901149 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-675.7520610148047,94.73805145734323 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-679.2849272517336,83.31072075657528 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark45(-107.15335963309323,-706.6274475528595,91.06924217747951 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark45(-107.60375418776641,-647.6447560672628,76.80211486805405 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark45(-108.43974225948911,-639.2624040870139,37.83722303175398 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark45(-108.48485225033275,-646.2322550849045,37.145517190540545 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark45(-108.7830871506633,-638.5926591789057,61.905085402314825 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark45(-111.71264959026715,-681.8663491419542,100.0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark45(-117.04123227164183,-634.7782403477314,0.07549876032746283 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark45(-117.79216306873326,-670.8348696106264,100.0 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark45(-117.79996973273568,-635.5793448784699,100.0 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark45(-118.92852490201042,-655.4634993196128,10.280017069779433 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark45(-120.03901751074599,-629.2959241508662,36.25856428283532 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark45(-120.06731814257961,-690.9185465034149,38.76832055226262 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark45(-120.14946216307865,-654.053368549161,59.70607983578137 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark45(-121.58929403010927,-630.8161504113955,44.159724284820754 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark45(-123.44493724481237,-704.5408771324429,19.562666315853335 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark45(-124.40131281452716,-657.5256688039162,51.264885349368114 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark45(-124.90922408091176,-650.0267118211874,36.48605992658116 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark45(-124.9350605483857,-645.0817647619052,100.0 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark45(-125.36049542986659,-620.7778053486833,18.525233361674324 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark45(-125.93812985255461,-634.3131965145534,67.7586465529761 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark45(-127.85271700019209,-631.1382227609724,76.70332210257925 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark45(-127.89254488170569,-635.4858551828529,55.52233313425788 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark45(-128.1297045079148,-626.559387378424,77.60091729402566 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark45(-128.23936080920748,-629.7947007276518,9.99089647410058 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark45(-129.67813959118985,-617.470378334884,75.01339407289655 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark45(-131.5596522109989,-647.5189481827255,68.38737030547958 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark45(-132.25131658650776,-632.3333884995847,11.840671379710834 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark45(-132.81238210467606,-631.6179229838041,92.5938144344903 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark45(-132.8636498421208,-635.3418794327893,11.882745193188143 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark45(-133.17082162287096,-615.9960478351168,85.77626011662974 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark45(-133.76780285077734,-619.0222413755258,68.12581858337009 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark45(-134.29695929360255,-630.3082690488214,45.069212776218734 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark45(-134.54044360776595,-626.0115490757764,78.31492459688215 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark45(-135.15449575601258,-619.1501323699264,95.74587450686548 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark45(-136.72326122451508,-627.8677647063271,48.32850846821671 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark45(-137.2293726381384,-642.9993768769566,100.0 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark45(1.38428933699754,-26.772515948889207,-88.92232211618315 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark45(-138.75345448458768,-657.8837892582103,100.0 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark45(-139.62279409712053,-668.3785566024835,78.65510823689905 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark45(-139.69245183391746,-620.8098222155179,49.20018505007576 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark45(-139.69726017812712,-625.1142618630946,89.8041129031561 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark45(-140.11110788454513,-636.3444468910527,12.167871272979625 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark45(-140.13857964107456,-631.069773209884,11.130565353031272 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark45(-140.92414050701532,-650.2588415710002,64.12589352932793 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark45(-141.49925391402905,-621.8042790019966,43.84693582410594 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark45(-141.66685540611928,-636.2490627726681,99.56192394768755 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark45(-142.01461517788158,-610.2633181858179,70.18545024508535 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark45(-142.9805306204887,-635.6298936596709,96.04596410313376 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark45(-143.22872455479813,-605.0025747677759,14.480151352045993 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark45(-143.31329097338633,-610.2053468756618,60.07603518854705 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark45(-143.84180405243325,-638.0235989588843,10.100308875370828 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark45(-144.10306525611054,-609.8976602637301,2.6279302633518142 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark45(-144.17039819766433,-603.6145186923201,97.662949023968 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark45(-144.39072449432834,-620.349975168281,97.9198010615263 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark45(-144.64702206558118,-620.4251420868565,99.91643216181572 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark45(-145.07231077125235,-643.7992986397937,30.700122054744668 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark45(-145.2286799009332,-623.0079520363811,55.63361551277791 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark45(-145.52723484862202,-627.8075689382748,100.0 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark45(-146.0107798361455,-616.7296556412291,54.4025876569622 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark45(-146.0165307065729,-640.9290036641405,100.0 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark45(-146.52698669604558,-618.5880826579905,83.59117752697563 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark45(-147.24048568919724,-617.934027215439,15.436774198294543 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark45(-147.25806086597242,-633.5665100347557,46.65963041329749 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark45(-147.33087860446142,-618.5083592383884,83.88303732180441 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark45(-147.8522151132579,-651.3068830053563,100.0 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark45(-147.9888097679251,-611.2176000293318,55.857792592938864 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark45(-148.05884603094154,-622.1625019580626,58.5776907679641 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark45(-148.21874257589715,-657.9225534136054,37.83402609491253 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark45(-148.4551019131323,-609.3636363903971,38.65597263957457 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark45(-148.47877305852379,-617.66230792022,11.986479402020706 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark45(-148.92377453259925,-603.5088971648033,13.944631643766584 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark45(-149.95807510874567,-600.4948105239016,76.43541589638994 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark45(-150.10908312103692,-619.9770543930503,93.70643138662157 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark45(-150.55867577752076,-604.7300405729587,82.78027468084542 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark45(-150.64474358117016,-621.3998548883194,57.352240478934476 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark45(-151.1204285651852,-600.396758545554,90.05382617912412 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark45(-151.37762747684468,-657.2022391957059,21.215067194674873 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark45(-151.75321070782894,-632.867264801675,100.0 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark45(-151.75706239997527,-614.4600354720934,100.0 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark45(-152.17492548674323,-667.7414627557872,7.843719874096024 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark45(-152.18126153442975,-608.7703239800042,51.16884895147419 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark45(-152.2433485919668,-629.7119884366268,81.51886766276937 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark45(-153.32827813433846,-662.4961337856458,70.45246640251213 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark45(-154.2243117902263,-606.1968296113446,79.21838310984498 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark45(-154.24983179415446,-610.4709551931314,100.0 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark45(-154.81228017968928,-599.4086158808724,42.72848214117363 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark45(-154.9343611007988,-605.4293359697201,33.341649057377936 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark45(-156.34778467717982,-609.110188617125,100.0 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark45(-157.303205405473,-611.8018718525423,100.0 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark45(-157.78772788502135,-650.3340441194935,42.22446945025638 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark45(-157.90264015765655,-590.7337339978478,12.870905667929549 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark45(-158.1356847437211,-620.4496503812593,82.94300733311383 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark45(-158.40415495461198,-634.2117169642345,16.71587244330152 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark45(-158.6712072530239,-655.2656740455953,17.957796336178006 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark45(-159.1043378487086,-595.1012277007694,65.84997602300777 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark45(-159.27998566487608,-597.074664098991,77.86411402077965 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark45(-159.29616223813258,-622.2688825123479,48.50445300556735 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark45(-159.46643463428683,-587.6365232368288,100.0 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark45(-160.00852012200937,-588.6575665534871,57.21273956895311 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark45(-160.5476765242991,-632.968611509643,42.25423395536686 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark45(-160.865742840973,-596.2782471280759,22.01516770316823 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark45(-160.96888103735463,-595.2012591078374,100.0 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark45(-161.10084059184595,-605.9711953298014,82.25144285774851 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark45(-161.36184935160102,-645.891302610847,100.0 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark45(-161.68531503358483,-750.4154658385312,79.85812104126649 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark45(-161.99533871475944,-597.7075347208123,100.0 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark45(-162.36413652488545,-583.9357529242253,3.6096580516277106 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark45(-162.5578566647822,-591.4138356445026,38.55348341900972 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark45(-162.7909654987223,-603.0819740025146,76.0330138117204 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark45(-163.62164067552445,-618.6327601892147,87.56972158685699 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark45(-163.640714848368,-640.2013536642671,64.94392794782402 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark45(-163.65766865966555,-612.3419395216724,75.5490287870866 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark45(-163.98747595534388,-628.818309166236,100.0 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark45(-164.05813322286198,-597.0833212455552,100.0 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark45(-164.7334905478641,-605.0757204292643,29.56907771989566 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark45(-165.0273548284442,-596.465104804139,74.97505763426605 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark45(-165.15000116414558,-582.7468362081729,97.45606740899501 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark45(-165.5416977334756,-589.2510098956852,88.82440964257026 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark45(-165.5796291876221,-617.6766662313998,28.33487466957888 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark45(-166.57618790456462,-635.5535347326974,80.3348786754745 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark45(-166.64462945901022,-631.5577281115885,10.088932729561634 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark45(-166.86405118711866,-592.3946477151023,1.3976856245982816 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark45(-167.99399086141642,-583.9727262681033,42.43677289296889 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark45(-168.1243239682571,-590.4390340670951,49.64342151162717 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark45(-168.18216121304962,-584.9051998879338,83.69384152652052 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark45(-168.64356866927812,-584.2991808842064,100.0 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark45(-169.20557577929958,-577.7937170769344,25.474991989195843 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark45(-169.34319383443568,-624.4747982018146,35.71710933997764 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark45(-169.61386755322155,-620.71074356748,83.7527042500484 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark45(-169.68754393490738,-590.3976679813215,44.44134893754455 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark45(-169.77180613469977,-596.3742525718657,97.76159167733562 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark45(-169.9189453980659,-675.0197285003688,100.0 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark45(-170.00857453683244,-577.7589909560428,100.0 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark45(-170.724695034037,-653.4074648706604,100.0 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark45(-171.00293106222333,-584.1895196182613,5.020278802035321 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark45(-171.2416603280281,-578.3092898642853,66.02384552816005 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark45(-171.2488456318879,-587.400805470203,97.38780872236376 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark45(-172.56215716928872,-582.6995427787632,100.0 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark45(-173.28107166966112,-603.38967618295,70.7242568368872 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark45(-173.54244494800466,-591.5896743211878,55.21516021570616 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark45(-173.65863846191323,-603.8503824269916,59.03814075703937 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark45(-173.8384143994511,-579.908856556219,100.0 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark45(-173.91578591314257,-575.6130124234297,4.3318914817674 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark45(-174.09053711553162,-612.9039709871245,100.0 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark45(-174.12296590234675,-625.0546297777914,54.934704568253835 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark45(-174.13707527068084,-577.6174420778793,100.0 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark45(-174.24110743905888,-620.2816442328111,42.02529560873421 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark45(-175.00238901364153,-590.9112816207794,26.792768291330617 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark45(-175.4222239240403,-573.7745522105414,100.0 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark45(-175.5929728529528,-573.2943984624413,100.0 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark45(-175.61497225761588,-583.709609000648,9.19381893817588 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark45(-176.39984050852877,-604.3673202048162,10.21658337196611 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark45(-176.52807607305988,-610.6615624660556,52.74948538653064 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark45(-176.58737011881254,-588.8578416513822,49.78731978550874 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark45(-177.0829403497832,-580.2342636175554,74.09205373617093 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark45(-177.24578065015905,-608.3238578114752,0.49178525778296844 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark45(-177.32101273297667,-570.2518524421216,78.47094330609227 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark45(-177.46701982451626,-610.2980122858793,3.1990853890632565 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark45(-178.17022559862306,-571.2532959240356,52.258517705684426 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark45(-178.22334420955298,-583.0850838570514,99.78766970074312 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark45(-178.73444636502535,-581.5875781532087,51.67831601017127 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark45(-178.77575184881783,-582.7689395246229,39.27177797252321 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark45(-178.7810595745839,-573.2816272437187,100.0 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark45(-179.31998526775035,-585.3097264756158,24.30198404183494 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark45(-180.29385940503272,-583.9710282665953,20.32189208914137 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark45(-180.32767927719115,-582.6890015175059,26.644453315696495 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark45(-180.360289341374,-587.765683298597,67.91089007945394 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark45(-180.50647488748155,-635.2738056692424,100.0 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark45(-181.08775143839253,-577.9442546549137,67.12968112327283 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark45(-181.69681564823708,-636.837917053205,85.14094319672725 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark45(-181.8255101702244,-618.9526491466897,100.0 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark45(-181.8344728022451,-613.0049325548838,52.93851661865483 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark45(-181.86184350885162,-566.9136004497561,33.506330663313804 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark45(-182.59279541694227,-645.0887780297065,100.0 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark45(-182.65626209815935,-569.4102850843536,15.883014295801075 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark45(-182.80441651440708,-608.2579236283985,1.2232532808157757 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark45(-182.94073683546395,-578.3513573093311,3.5661242085130027 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark45(-183.13875207729163,-591.1629968428247,79.16441613089361 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark45(-183.28273398121712,-581.7419865588722,32.19439060415971 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark45(-183.51552108191885,-566.4070864635801,61.018496360406544 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark45(-183.69844889831384,-577.0241119443799,71.49111883953483 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark45(-183.90143518203087,-578.6064522023331,24.248664394056064 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark45(-184.16113959313356,-625.8427958782746,37.841631892190065 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark45(-184.20980401849144,-609.4118698548685,70.04122917980257 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark45(-184.35491181970224,-610.7198416001208,58.16263717107114 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark45(-184.71965379743148,-592.2688673764885,7.9636430115638746 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark45(-184.71974023531044,-618.678493750337,42.33353573041191 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark45(-184.8106404587417,-585.9574041865569,16.485107633209054 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark45(-184.99137365180093,-590.9575524310859,45.2838420597169 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark45(-185.13460856828286,-637.1015025062416,100.0 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark45(-185.4233927693926,-577.4250626257153,82.81772503250389 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark45(-185.4532949757319,-561.0645471546796,100.0 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark45(-185.5127658383786,-584.2299998127941,100.0 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark45(-185.64012458670683,-565.5312866736642,15.808429860592383 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark45(-185.8455135591234,-585.4633067828714,100.0 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark45(-186.1618845477551,-585.4098101805031,89.06080948025388 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark45(-186.17409359798316,-588.564751519906,54.39273608802716 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark45(-186.19784935747032,-569.3437203493866,22.647264538990527 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark45(-186.27275239155261,-560.3204384809821,96.91938192934157 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark45(-186.33617693405864,-561.570499012447,64.13851990014606 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark45(-187.12763444920273,-620.6604296810817,41.46417618248802 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark45(-187.18249151697242,-560.6723488145512,81.84358746972829 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark45(-187.68142925511484,-562.4961231549338,7.654453223490393 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark45(-187.95859607476714,-640.474548001859,14.96171170140994 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark45(-188.52009236800816,-594.3716760326771,30.86107624617219 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark45(-188.55339374820997,-562.0596309200803,100.0 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark45(-189.04797284853896,-557.417280750673,27.13086307135984 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark45(-189.0926777268153,-564.0441596561818,51.44696087479289 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark45(-189.29727074208114,-616.9102476548375,85.84711591199198 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark45(-189.65096718853826,-561.2492120865044,77.18860864429539 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark45(-190.43375799856983,-587.4228336284259,99.7342249781232 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark45(-190.77573499508082,-569.8809492085674,100.0 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark45(-190.88250738672852,-563.983384314989,68.17466709646338 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark45(-191.10712830399416,-557.3462887628244,46.65315684148831 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark45(-191.13784226665382,-598.3034896262726,85.79078162279436 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark45(-191.49108352097008,-610.9462884605304,78.92219528237248 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark45(-191.56268867342428,-571.6645653227453,68.01170029784228 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark45(-191.7601286457422,-560.1826336133034,83.90019734703219 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark45(-191.88979136774748,-559.5684884735794,58.0540951368223 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark45(-191.99883602748739,-559.0745202328119,100.0 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark45(-192.00061314668375,-561.5628963373947,95.20303256136322 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark45(-192.35089484228664,-592.3945187400006,56.621853035112224 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark45(-192.56729620325,-566.1662318511807,1.3664593577350246 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark45(-192.62012084327407,-560.9615571835203,5.578111405676593 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark45(-192.96386957258147,-583.7908795494727,5.155380984451654 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark45(-193.60266638254024,-559.1459293016645,32.62516985181672 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark45(-193.73061538324197,-566.8208857705299,22.595091262097597 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark45(-193.92166345178396,-588.0114303655264,83.75537830406805 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark45(-194.18519723077782,-555.2117326976452,100.0 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark45(-194.26192867640762,-611.291775761121,79.32342567696244 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark45(-194.34285602857364,-557.2111207342166,57.29506932730942 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark45(-194.37359716749893,-569.6757168642118,68.78610743980161 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark45(-194.54430792471427,-577.2746625899779,12.698395598708032 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark45(-194.69073130929988,-556.9420430251826,94.54877286515611 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark45(-194.85386498680086,-572.5675553039548,95.85798421366783 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark45(-195.42947480403083,-552.4617256460996,100.0 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark45(-195.454980447001,-567.308887925818,92.41927852284314 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark45(-195.57842193762676,-586.0735093767673,2.199443213975954 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark45(-195.84465447953895,-577.929420775534,93.1521486737519 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark45(-195.90938092574382,-551.2367862021883,7.105427357601002E-15 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark45(-196.7386371625329,-550.9742463190789,72.8492843733842 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark45(-196.8512284609514,-554.1930256521616,100.0 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark45(-196.8809830196387,-549.738770002641,100.0 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark45(-196.90293236681836,-588.7956655106976,35.81286830197959 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark45(-197.12187293630657,-561.7705194894589,100.0 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark45(-197.21713377885376,-572.8123565623468,92.20125235844424 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark45(-197.3835559397103,-623.2739967941355,21.80110013406049 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark45(-197.4593274208977,-554.0570521665302,92.7732205178583 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark45(-197.47439690068464,-576.2352244738794,59.34703438635481 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark45(-197.56834127306917,-574.0767202817158,50.15652053802816 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark45(-198.30183474171258,-594.4255202484433,43.35650429116353 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark45(-198.31539512805608,-573.8943911208976,100.0 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark45(-198.65958762368228,-577.8087871940406,49.14367056292606 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark45(-198.70745056400216,-554.4104945610978,79.34493094477898 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark45(-198.79806944022,-609.6254118926089,79.23031578182344 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark45(-198.86342126356138,-577.9435177392661,7.105427357601002E-15 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark45(-198.8753591506903,-567.9838103141641,100.0 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark45(-199.04495244907096,-627.0574378936107,36.29791977839102 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark45(-199.23296530986542,-588.24911816377,100.0 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark45(-199.36770195877577,-553.3799927112564,24.109248157145 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark45(-199.6014838728641,-553.3548339568412,36.168284424994056 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark45(-200.02430638671794,-559.9065667438797,21.30431725911022 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark45(-200.03191972190405,-593.7573847460251,55.60173947485174 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark45(-200.69217192024965,-557.3958617896902,100.0 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark45(-201.0621344243931,-625.3458446457073,98.56874916077768 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark45(-201.1707518292493,-549.3611088585104,48.97902628296259 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark45(-202.24948290465193,-589.098693043317,29.00838366558702 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark45(-202.71250492239332,-552.4590450553516,27.910527634336674 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark45(-202.86634579193128,-556.4927228604594,7.601958418648195 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark45(-203.30730613022334,-567.2050198270845,91.30790797254281 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark45(-203.4161110579093,-594.032973072906,39.29450907736066 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark45(-203.46745914195714,-549.7149627074327,65.36582437147783 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark45(-203.49366445559014,-560.5489779693578,100.0 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark45(-203.57971319585266,-576.490391620859,40.22584287578027 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark45(-203.72881146054857,-564.2849369874301,99.64384246590447 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark45(-203.94149098267098,-588.8263424668029,37.06601660227108 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark45(-204.17748437583774,-570.8747836954686,100.0 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark45(-205.00669026308978,-594.6652258291572,95.51301103915256 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark45(-205.09829129598802,-546.1830798295638,64.9425873813988 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark45(-205.17073899299058,-583.1268119028213,58.55266693979152 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark45(-205.3567271602132,-562.240531725739,13.327750668813579 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark45(-205.58085862529688,-582.6946465167824,24.562379617812297 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark45(-205.9047273852798,-583.2504044664867,100.0 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark45(-206.07263378394748,-554.0364475388915,79.82191731278854 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark45(-206.08226132215046,-564.5279713772239,100.0 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark45(-207.1577801251994,-576.053996546788,18.09245654976614 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark45(-207.4726181311613,-568.1825735373571,61.66420483576752 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark45(-207.81219391315275,-550.1151508924899,84.95474552074549 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark45(-207.95584081271716,-541.2679919503375,57.18269312218467 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark45(-208.0081317638449,-570.3805969347159,91.12649301203584 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark45(-208.5666816920891,-540.7291686423956,55.7148775857282 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark45(-208.73659890814568,-597.9093882739663,32.127237676945356 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark45(-209.00841708979118,-552.9498365982404,72.55807688974866 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark45(-209.22139431097082,-537.1520342075372,44.93692870865621 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark45(-210.2778575756799,-549.9744734246486,83.8734995240059 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark45(-210.63956507713576,-555.7026012262454,44.53133973861608 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark45(-210.88066332078097,-552.3233752744513,61.98162234234218 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark45(-211.27527869239037,-539.0326708767169,32.107589695880165 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark45(-211.60325757463937,-545.1869808207583,78.03217435300775 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark45(-211.75897769303822,-537.9084880337068,20.400292199353927 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark45(-212.14936508030183,-541.6680741323423,12.0252403371366 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark45(-212.278829671861,-542.1850251747196,7.300089131801229 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark45(-212.31276841817302,-557.1256623616875,100.0 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark45(-212.40111312309432,-538.0368239187948,18.918902333500647 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark45(-212.50359748019162,-550.620261743876,20.30490191697372 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark45(-212.58642730272203,-603.6784827867439,85.6320886995814 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark45(-212.7398991364129,-533.6074178257329,89.1722868220806 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark45(-213.31030861721257,-537.0280145052027,44.88442447104387 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark45(-213.58588523258487,-538.1717416968647,23.381323609421912 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark45(-214.10937039594484,-549.0107822276918,26.741670582927156 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark45(-214.14543337863554,-555.2250074320575,31.428195247508853 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark45(-214.22561431478817,-534.4236111777105,3.7403630212361634 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark45(-214.64921842401924,-543.1710583444411,81.93551397007343 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark45(-214.6767733030567,-548.2512393261011,46.313195345327216 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark45(-214.68170378573058,-566.8098632924119,98.48522718696745 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark45(-214.73553647503684,-550.1718602118373,97.44398792835051 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark45(-215.00765484122027,-543.6194237398993,20.447004196507024 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark45(-215.0612370967038,-568.8731359815687,69.29326052649375 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark45(-215.15929556958278,-546.2436609507369,32.43686708874887 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark45(-215.2014360729557,-542.7181897419871,58.884816319739656 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark45(-215.51356746403857,-611.117957226156,76.08596194067968 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark45(-215.70158968440128,-539.9151294395419,35.609895629321386 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark45(-216.26526995236003,-532.7644812045487,47.03083584117866 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark45(-216.41172823963694,-582.0676944784044,16.220947028763888 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark45(-216.47517798288283,-545.7536212979601,23.281313477063264 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark45(-216.57405069470363,-570.2850516909998,84.41895303479248 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark45(-216.80864113938492,-535.9284826712337,62.97739672682658 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark45(-217.278725784954,-575.07984669038,100.0 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark45(-217.37343324944644,-540.9557781247894,78.6311991697545 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark45(-217.3780443508613,-542.4861738022637,57.847363768475645 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark45(-217.4006957257729,-548.3090667043002,100.0 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark45(-217.48104529700515,-532.2387810568077,8.907749704225992 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark45(-217.53336238274355,-529.1431047109204,95.22864214174805 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark45(-217.5627427664873,-542.4885283919058,67.03225327321357 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark45(-217.81340707384123,-535.4626632961251,95.89773674263338 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark45(-218.05732613627788,-528.8616564583565,62.50678501765162 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark45(-218.22418297797606,-534.3817324264743,100.0 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark45(-218.42812512985626,-566.4023544902793,100.0 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark45(-218.48062930348257,-548.9657199254129,80.16946747274812 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark45(-218.60468114401388,-565.3458662560968,51.51494589899079 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark45(-219.16443137659033,-553.5184191322376,36.17097642139379 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark45(-219.43945840880883,-537.5448930542929,48.53501368979863 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark45(-219.8227230645942,-557.8905899332482,23.787972617520765 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark45(-219.9613630675681,-527.3595275697871,30.772727139950575 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark45(-220.01956368659788,-572.4171406640587,19.698708728169393 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark45(-220.06539050755168,-564.0590819901132,29.283802629033573 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark45(-220.2035220707645,-528.7074724893326,100.0 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark45(-220.30228473513412,-551.9996025314298,43.640774063274506 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark45(-220.44593453177185,-541.911858755498,1.5390253867568333 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark45(-220.913716269029,-539.1765855844043,18.057780857498543 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark45(-220.98219751627602,-605.470268679347,29.038052572878854 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark45(-221.58446979035548,-549.40573238332,20.397521285020375 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark45(-221.7083907470023,-528.4030381674667,97.3669488834276 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark45(-221.75258661290508,-544.9102592743166,99.98630639813533 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark45(-221.8406967604004,-548.3433881509471,68.0539566643983 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark45(-222.07666331731625,-550.8561918873172,33.12669868422449 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark45(-222.1371612247731,-548.9249551236416,48.211847253832076 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark45(-222.17977320285397,-576.3998437718298,100.0 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark45(-222.25400715240824,-567.7598922329859,7.362782899252892 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark45(-222.6275315389762,-523.8426811855632,99.20006743341231 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark45(-222.89554944011064,-552.6388341899947,98.93092857871906 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark45(-222.933734205566,-562.7897386925674,15.784446312130868 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark45(-222.96701648258704,-558.9062873766027,100.0 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark45(-222.99066908925755,-526.8827793483209,13.135167150265751 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark45(-223.0709438247319,-533.071847191688,8.201354340376525 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark45(-223.151586618635,-539.8204503047044,48.46837675063256 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark45(-223.1624217714991,-559.0077652445544,81.40135031303902 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark45(-223.24600405628217,-569.364333452724,91.61571853190054 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark45(-223.41795844646742,-544.9896287191748,94.16873142694479 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark45(-223.5270143910182,-590.3201702189655,57.26854814303516 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark45(-223.92585103020053,-535.4411297186717,100.0 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark45(-224.14735468633415,-532.8881285759403,74.19091522684761 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark45(-225.01842431600338,-525.4568283239215,93.39296666445958 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark45(-225.05029155452922,-557.2070736089785,6.993818861214379 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark45(-225.0957207273336,-524.3779111393981,20.178892864589088 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark45(-225.10193786569772,-545.2996794489023,6.253144326053416 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark45(-225.38362298391596,-622.1643786372075,7.791798766615216 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark45(-225.4319031025698,-521.5977622573364,32.243831347481375 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark45(-225.54199102782079,-562.76569591384,38.39470028736429 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark45(-226.44198696386763,-572.831639872304,31.024444734767144 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark45(-226.45839755336127,-529.5381830314548,37.6816672725148 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark45(-226.46068378851356,-519.9975809630257,30.87393998389817 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark45(-226.47205393252918,-546.903247597664,11.944535019677119 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark45(-226.49461745401183,-542.6585346951972,45.66541995582426 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark45(-226.71774740296337,-563.2530931493293,53.99451640708455 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark45(-227.00537968032563,-586.2744584242486,81.1879451711483 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark45(-227.5094871207854,-530.3166364648832,86.6801631668813 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark45(-227.65831711361645,-565.4646606415324,21.271986239747662 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark45(-227.7100737031266,-539.4419806597053,42.9410349519585 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark45(-227.81867219392183,-529.5448410892437,68.51356176474803 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark45(-227.86851529567443,-540.0458154344036,14.038464263722489 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark45(-228.06016743224052,-525.3204167400479,77.17606710815767 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark45(-228.09421335149167,-534.5286270955387,63.465681777765525 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark45(-228.263449273854,-600.9493055699346,36.61202051225362 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark45(-228.3243807312174,-552.8809981470266,100.0 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark45(-228.37889362870808,-538.6489647522394,21.61882452239847 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark45(-228.97988615597887,-527.872762222496,81.36487426477171 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark45(-229.05387597055957,-558.5041130863273,3.830289005444328 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark45(-229.23058504039608,-556.7518755807599,91.24159959115804 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark45(-229.64065501088726,-569.7611148134384,97.06431660772967 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark45(-229.73180682651753,-557.801157408921,8.446912660634112 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark45(-229.751134417733,-526.4594852364453,68.20550001410462 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark45(-229.94733871877003,-582.1309268974135,98.98058546945637 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark45(-230.1567074484867,-542.6982466398969,26.52636035753592 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark45(-230.18146660189828,-531.6664004006502,89.44997574925767 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark45(-230.19203213316797,-534.8945282167145,21.741286001511767 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark45(-230.26445696598878,-541.7328303667081,49.8966368498331 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark45(-230.3733961153193,-532.1771738609555,38.21611420322047 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark45(-230.59053739584581,-523.1279235563286,100.0 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark45(-230.70960493854017,-547.4563520264583,29.574266629971703 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark45(-230.96162200910516,-549.5142765067952,86.71058660310948 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark45(-231.2130498794023,-582.0636313175213,11.084007167245488 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark45(-231.2319615972198,-526.4704984679084,68.66030202315955 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark45(-231.2674095694576,-538.2629594298197,100.0 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark45(-231.6801372862968,-539.3014236252264,17.090013712419832 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark45(-232.0425508552344,-527.939281543336,25.09310766402595 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark45(-232.5303445941906,-574.5583599332298,92.75503289249326 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark45(-232.63837739133106,-521.232511693894,6.2250336279370515 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark45(-232.7572615485297,-528.2321687206959,88.3860701516642 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark45(-232.7814080578782,-522.2660749591689,100.0 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark45(-233.09613316521165,-515.9646922680495,36.682706872672185 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark45(-233.20392463265043,-532.4234720108412,96.48616851156345 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark45(-233.41000924992164,-512.5912442218917,6.904511537973846 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark45(-233.62059172020605,-514.5433151241155,78.47041149262421 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark45(-233.68668692134912,-516.8155740678058,14.310642300579872 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark45(-233.71859329774895,-549.0185315191178,63.496228363011795 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark45(-233.9043064695766,-538.1151105256866,40.90284105863424 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark45(-233.96408958321013,-513.2518389900742,81.52704385423871 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark45(-234.09399809838592,-520.5494879758062,88.16549984330356 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark45(-234.32727111445678,-596.02908385929,37.94250274879771 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark45(-234.35816661794073,-521.1719495275782,82.72291333749843 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark45(-234.522649196994,-515.2749128990436,55.899569701987986 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark45(-234.63850978909818,-543.5662708569479,100.0 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark45(-234.6540275514069,-520.2770445254235,0.3867655753266632 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark45(-234.66780117322583,-558.6061877998471,29.10954045916816 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark45(-234.6685208695519,-596.1382946112188,4.440892098500626E-16 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark45(-235.2481018467907,-567.5657708407098,23.54129475349454 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark45(-235.67051968582092,-585.4545035932754,3.6367804123363783 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark45(-235.7637748198518,-559.172490218817,90.25812851111772 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark45(-235.86853090449074,-524.3983896065102,71.72017869335096 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark45(-235.9419017742365,-540.2359423483618,90.63551906391481 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark45(-236.31523498630938,-520.093278873469,87.12242879211325 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark45(-236.49518191147914,-531.0320517511753,96.00078736272138 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark45(-236.62476576327342,-512.5584698814229,40.763028996027714 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark45(-236.81311627530326,-512.7927632017115,5.551115123125783E-17 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark45(-236.90403284879477,-510.4074364688174,17.735988426131428 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark45(-237.36733373179734,-568.9930770328752,31.890520829015543 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark45(-237.73377400688497,-549.2627627558895,14.152760797301681 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark45(-237.8119255213161,-509.1569421811069,32.18475865531468 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark45(-237.86860537386943,-547.1613053990901,50.06751808290812 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark45(-237.94745223610724,-554.8009632194343,2.236505215236811 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark45(-237.95479824612738,-541.9152389948566,68.94904533198869 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark45(-238.2815183444176,-507.7806101654321,100.0 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark45(-238.40470189976145,-539.4633423867965,75.68508155831876 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark45(-238.5005259747894,-534.4677353516124,39.21397322632109 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark45(-238.55896246633355,-512.1430118631,91.97028622509669 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark45(-238.56654399667562,-523.4253659917717,20.41702343070952 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark45(-238.70445327172672,-513.3651934108901,73.3001702859012 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark45(-238.89358028846084,-513.2463376658483,27.458723119905002 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark45(-238.89974317521663,-511.67159558698415,63.39586499597908 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark45(-239.04499893364007,-560.8102992183965,57.10357187133769 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark45(-239.08637894993635,-507.4461253952,76.46772345275363 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark45(-239.181706216925,-553.1043347159713,25.33854390107942 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark45(-239.59997669839012,-551.6997677145781,28.552330513318026 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark45(-239.7970040506865,-586.3048922821152,41.65690158957142 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark45(-239.82345497501922,-513.924377000183,62.97458156637629 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark45(-240.1763310128705,-554.2420069651578,7.105427357601002E-15 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark45(-240.40078723690414,-623.11445964211,71.06089029127429 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark45(-240.8588905661257,-510.47999655367016,95.45138199687787 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark45(-240.99134154219388,-518.1944613200775,97.96288030927656 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark45(-241.13495325498653,-510.6366347877351,37.15363279740632 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark45(-241.38718115021757,-639.0225058913876,100.0 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark45(-241.56236562611068,-529.7838370237022,100.0 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark45(-242.00481812574844,-522.2095129986742,55.21866862509509 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark45(-242.0294918719952,-567.0024175104367,14.243603726028908 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark45(-242.1525313727743,-504.33816518377944,100.0 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark45(-242.3616255250462,-603.9630746375645,6.777720373981339 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark45(-242.63260013685996,-549.5912097063392,100.0 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark45(-243.0948450008176,-535.5631675176328,20.007185043601098 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark45(-243.3449123515882,-526.8279188567818,90.38937489815015 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark45(-243.4603666857148,-548.5439234887757,100.0 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark45(-243.90184759127735,-522.0342528519635,17.654050007507124 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark45(-243.96639330719026,-535.6241588377214,100.0 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark45(-244.5525527318138,-555.6932611710927,100.0 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark45(-244.56261172225373,-508.8245088188601,82.87388694106198 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark45(-244.5896335319627,-536.3670106195224,30.719360450295426 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark45(-244.665630230494,-515.3754406895223,57.72004616208818 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark45(-244.91384766061398,-567.3033314524582,100.0 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark45(-244.99828742626613,-518.8058238273677,30.99612084925377 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark45(-245.09801495655938,-511.60965669445926,88.62711094385332 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark45(-245.25833281070396,-502.32024390218595,54.74647235891629 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark45(-245.3347997725272,-522.2479008007899,4.086479904704788 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark45(-245.57740168721784,-520.9618154761058,25.5045874599318 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark45(-245.58167877780082,-511.0018234857949,27.519002318436023 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark45(-245.84168743859283,-533.3010488704239,14.933544018068375 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark45(-246.28093904830658,-541.0635968714791,100.0 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark45(-246.39864197060936,-513.203217874735,80.30161364011133 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark45(-246.94213409880064,-548.9155963372918,88.92835706135543 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark45(-246.96807623580094,-505.3800343125801,55.39953833538672 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark45(-247.3168748530742,-581.2933631687357,2.204886684281533 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark45(-247.32615258103297,-543.4852797723648,11.554533311738552 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark45(-247.54144059591414,-518.9406133967461,62.54249253346137 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark45(-248.0410433418718,-518.0715574237591,73.78818830726507 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark45(-248.04622698931897,-502.64940514602466,19.51795040103508 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark45(-248.28550330989083,-521.8113099182277,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark45(-248.41980642326047,-500.06117068384924,43.352069537233206 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark45(-248.46543304370013,-517.7103526080238,32.980370537513465 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark45(-248.48556364952654,-531.6883966293137,100.0 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark45(-248.51588208096481,-592.0224377573737,58.19057162440774 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark45(-248.59965150715036,-519.2183502456792,36.944938745645004 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark45(-248.70812277603824,-518.5761645167626,84.2797658234972 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark45(-248.8453857411171,-508.8906314152794,79.46153989289942 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark45(-248.99097860985285,-523.8588042889036,44.71406748477176 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark45(-249.30143943461886,-499.34147011721797,8.075136182068789 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark45(-249.56393973007158,-540.1686015628678,83.63426996027044 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark45(-249.58869371831008,-510.9775675553394,29.821760655236005 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark45(-249.69927204618708,-512.5946908654502,5.193279699294635 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark45(-249.98086997053096,-521.0237331168125,51.85381531751324 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark45(-250.25948497199096,-500.33605613892394,12.463692020524192 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark45(-250.39959092718482,-548.4973615747159,47.1904878408572 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark45(-250.42302977318724,-499.9141827614955,27.33267655800364 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark45(-250.42806710842262,-534.8521873473823,15.417363460293217 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark45(-250.95116345485772,-499.029210748128,38.19618280850847 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark45(-251.1490474026524,-562.4533045677659,8.892789293070962 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark45(-251.17517684326364,-497.34252042318894,16.659238486387068 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark45(-251.23992274416693,-507.92775929320266,76.61877875740123 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark45(-251.3931666094387,-499.4371849693598,21.514816750095676 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark45(-251.52405941848514,-511.5691867953393,100.0 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark45(-251.564011040889,-508.9256630194674,85.42187139160944 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark45(-251.7228104686721,-511.02116675984786,79.34862783276628 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark45(-251.77056460353663,-499.83404892436994,10.022349956273487 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark45(-251.81815492651782,-531.4785788932418,100.0 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark45(-251.82896199555674,-501.8604953572784,100.0 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark45(-252.02224647698515,-506.5989122714142,100.0 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark45(-252.8165291713978,-510.04483225500223,64.23915681815404 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark45(-252.91495993984674,-495.83104248543964,74.91943539273572 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark45(-252.92333850303334,-529.082457562243,45.22290386426741 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark45(-252.93859149559674,-495.12476772106356,79.38223899826923 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark45(-253.07173379468398,-552.6121310616314,43.86837733022935 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark45(-253.09863664014702,-518.9871674144247,100.0 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark45(-253.35104716489286,-587.4251082541468,44.253989727613686 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark45(-253.48322911115596,-524.0601975552742,53.32590648869541 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark45(-253.50641373037138,-515.734536237416,100.0 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark45(-253.57501779548846,-522.1980984129525,91.34961179230439 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark45(-253.66227432627457,-504.25698531296086,100.0 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark45(-253.9318921581617,-511.44329565996327,39.12807761326394 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark45(-254.22706543496548,-534.8383305172213,92.9225527219418 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark45(-254.29060433619676,-503.4367688641391,30.21159497095408 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark45(-254.34814202659112,-510.4195820734537,67.16865840742307 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark45(-254.58274122388363,-496.69984295460745,100.0 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark45(-254.8420973364333,-494.5128276822566,71.07926019958703 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark45(-254.99588433421457,-505.52065516538164,9.013860861134248 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark45(-255.16249938729592,-549.9965412829387,78.87742965526905 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark45(-255.19424911639996,-522.8668139771919,33.3818997877832 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark45(-255.2644066557208,-500.4400363418949,89.64573892228262 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark45(-255.40941852832253,-507.64078714977984,63.888781993730476 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark45(-255.47951902776893,-556.6254352621381,91.10977443092273 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark45(-255.51987910202664,-562.4008260672758,100.0 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark45(-255.64384597051887,-506.35347472638995,100.0 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark45(-255.95442312959017,-527.0948862124853,15.806414612751183 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark45(-256.293635658442,-515.4619319992854,45.022133398959596 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark45(-256.51155020777185,-550.8758821900982,56.8143770266052 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark45(-256.6693926529206,-543.7480564791193,100.0 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark45(-257.4305180581061,-505.38995463419405,100.0 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark45(-257.5467172372247,-503.2837783486951,78.51660480349523 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark45(-257.55001441875186,-518.347452860665,54.35197335633049 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark45(-257.74022706166755,-512.8334959249889,100.0 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark45(-258.00507294915883,-527.7204005074042,90.91016355229749 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark45(-258.03463552775276,-542.9177800510273,82.27353175038951 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark45(-258.1345940682488,-515.315106222529,44.0510340616496 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark45(-258.1744411299504,-495.46980571788123,40.83966791294455 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark45(-258.2726857995189,-519.4005751318239,68.54128022518381 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark45(-258.5600559439289,-512.2806029652199,100.0 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark45(-259.02023283053506,-489.3513144968498,100.0 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark45(-259.093582076528,-566.7038013964177,90.20892803357467 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark45(-259.1123155378326,-499.6831610914669,8.106808532615332 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark45(-259.11821596460027,-508.56620020501117,0.37941828897440644 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark45(-259.9133707350917,-523.4507148293981,99.24131400262601 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark45(-259.9767445215574,-519.0948421545942,51.90851885021925 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark45(-260.0125029191935,-514.4671405026634,11.546196115645913 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark45(-260.0462713437071,-549.0030671975877,30.161074589005324 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark45(-260.0536383291865,-502.72102845192506,100.0 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark45(-260.35010590126547,-509.2384861137067,100.0 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark45(-260.42463479633545,-498.0080021844021,34.66944432320966 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark45(-260.48612693227227,-564.7633261360885,38.82076062657595 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark45(-260.52570089863633,-561.7589278856506,50.895470449678584 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark45(-260.6353718537713,-531.5015209472857,41.7768012313542 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark45(-260.73459863793363,-513.9135240572136,27.700010014161364 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark45(-260.90799018393557,-488.085091777533,57.76023697050812 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark45(-260.9094699262461,-545.7162332707502,63.967969160861884 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark45(-260.9248277921231,-541.0013691485447,100.0 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark45(-260.97168557383924,-526.8855475367824,44.8448067677279 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark45(-261.19610001750743,-503.85171671127785,56.09849737624452 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark45(-261.30824181293906,-505.97165870760625,68.91355921996046 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark45(-261.4249128895375,-492.0996516457592,100.0 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark45(-261.57530045008116,-513.0891762724187,41.30697288813272 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark45(-261.6998977484046,-541.6979780149807,53.61285823554519 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark45(-262.14702900115975,-485.79603751220213,24.365309066627418 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark45(-262.172405624009,-541.8111439310177,17.09989023192297 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark45(-262.45387069559524,-528.2523796591516,87.03361928275584 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark45(-262.49410754192456,-486.80695807849776,32.34228740632713 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark45(-262.6641485757763,-492.7456664601159,9.9133309148351 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark45(-262.80486730142013,-507.7075546578079,100.0 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark45(-263.1643969976855,-505.7113690211642,59.418066361038186 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark45(-263.39664934897644,-508.4576710477565,23.380303414384002 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark45(-263.6055272185921,-523.5214905888787,46.94064417019425 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark45(-263.72274251861126,-512.624659767453,84.92280983185702 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark45(-263.72674546243957,-492.77852158305603,9.816023320844721 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark45(-264.1692497265393,-526.8631851491637,69.58500508911169 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark45(-264.469390218399,-499.2945600197583,63.44720480195832 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark45(-264.8279792565958,-511.2349829908193,52.741746109254706 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark45(-265.0637480500742,-497.88710140599323,88.8860312988659 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark45(-265.1226700606116,-482.61259507636703,70.73430681607815 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark45(-265.1955398627824,-552.7155724157174,17.233379691825817 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark45(-265.21576326690615,-519.8168876772671,45.18978481237025 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark45(-265.24643528546653,-559.7204965545851,19.76842306796796 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark45(-265.25536402767966,-514.7984732039887,37.63656165445076 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark45(-265.7793798762136,-498.36824867852846,100.0 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark45(-265.9052832716763,-482.0493348893268,46.05968516113151 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark45(-265.9821937334894,-508.1825888162891,88.09884039899816 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark45(-266.0445924883094,-518.3399934536845,66.59737886551386 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark45(-266.11354698624746,-483.5655129940712,22.39928981176496 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark45(-266.207975460775,-564.7054385092271,100.0 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark45(-266.3305919757789,-504.2265436621968,1.581941575984331 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark45(-266.3763228571256,-497.7915828515752,30.634313499052496 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark45(-266.62616811920566,-483.0457470492165,44.47046445343432 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark45(-266.72166751322555,-486.11918859680344,8.626275750689445 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark45(-266.7254390638748,-557.969542970328,0.3642716209490686 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark45(-266.8402080188941,-501.5650873380165,87.70668520335283 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark45(-266.91763117514955,-516.6864464389317,3.8277975566957565 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark45(-266.98526308949835,-523.1962748714077,18.218610531223234 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark45(-267.1288701940855,-493.9399906262474,32.132734931112225 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark45(-267.25861406164756,-497.5775565013869,52.542117641803316 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark45(-267.27420819041185,-518.8626336217765,100.0 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark45(-267.303940884307,-483.10224062716804,100.0 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark45(-267.82025127294935,-503.8312953871965,17.843706951705627 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark45(-267.9321991769487,-529.7688310091291,3.59367882313515 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark45(-268.02211017805064,-530.8223581390411,34.078445088915274 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark45(-268.13968157832164,-488.86357220044937,16.576874195933343 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark45(-268.2421929103886,-509.826459652782,66.5123215733485 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark45(-268.50821842904406,-483.33276255756414,19.139272228454416 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark45(-268.5861474043441,-498.1419437667629,100.0 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark45(-268.65197897266785,-502.7252586803679,95.40939392286614 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark45(-268.6828634332712,-515.3216616504286,66.69802498005035 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark45(-268.9207380259687,-542.654211685869,17.818541219472706 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark45(-269.1666075079004,-531.5032353103816,65.48060565469834 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark45(-269.21611098132564,-499.7940230572,100.0 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark45(-269.2925720626868,-540.5025807309465,20.991280610311037 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark45(-269.487838107981,-508.11582395418714,28.762392157140937 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark45(-269.5382510866433,-532.3476212614497,86.85957719690845 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark45(-269.6844665479138,-482.5141218786735,75.4063621492142 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark45(-269.74386887217526,-521.0757961536124,100.0 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark45(-270.00228634533164,-476.0998110176016,100.0 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark45(-270.01963618095243,-490.82729529277003,46.613823364607356 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark45(-270.02381453050134,-528.6775808438509,89.55317393101433 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark45(-270.3163785604665,-521.1557801535427,31.603657297535193 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark45(-270.4851862695268,-537.6483333601542,22.93915573991599 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark45(-270.6072230838167,-476.0599245341596,28.04792766090725 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark45(-270.69460344548736,-591.9804328291413,0.0019556366572578004 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark45(-270.73481290306415,-529.9975648761721,100.0 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark45(-270.8700315534194,-490.4417162702802,100.0 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark45(-271.14418136527297,-485.72972697669417,78.9706168131296 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark45(-271.14928938456944,-488.7622981680569,100.0 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark45(-271.2894552207262,-475.84695178283926,100.0 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark45(-271.31375361180903,-492.00286286066853,77.05595019381695 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark45(-271.605370329071,-477.98739847758907,59.65363466410005 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark45(-271.6344247439316,-504.8359791742756,69.6605675506336 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark45(-271.6620165138025,-540.7442134443188,100.0 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark45(-271.7670072638985,-494.84034395608853,37.333991412597754 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark45(-271.9844911000711,-476.8039118305315,1.2786498386564915 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark45(-272.6380254728621,-534.3136956650004,33.67255509724072 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark45(-272.71292718592855,-507.2265740671583,4.102148949170953 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark45(-272.79003178556627,-480.3774192680025,47.01550444175149 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark45(-272.9004618832828,-484.8192736102199,100.0 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark45(-272.91629398015203,-526.3615665787408,100.0 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark45(-273.0467051402923,-473.66926829812627,80.11171142334689 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark45(-273.24823889747705,-512.381336115245,65.3807589712676 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark45(-273.4286609766782,-502.2568705516288,19.369289680368524 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark45(-273.7132536172793,-487.5811304434749,52.42165742129404 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark45(-273.8350270948913,-503.4772035949762,100.0 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark45(-274.05045881075233,-525.4014658197624,30.601366067512572 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark45(-274.1359389771758,-487.0118856459694,3.040764123646042 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark45(-274.1914394077462,-487.6228825342274,-1.1065871599016302E-4 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark45(-274.46025819529774,-510.0584306252009,81.41603670115055 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark45(-274.4932253213998,-477.4677909085819,32.85034237735047 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark45(-274.6103730327194,-482.2711017267896,44.65449640725046 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark45(-274.62016571553266,-477.40338403963176,76.48675498232879 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark45(-275.17048377716884,-487.2674745881007,82.71387942379098 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark45(-275.3012033038873,-537.6980829896664,71.92411749943122 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark45(-275.413163298528,-483.72702395188963,94.25664353478075 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark45(-275.51237960421605,-482.6923131046676,100.0 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark45(-275.6215875566545,-532.1936157004188,25.88477244667638 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark45(-275.6844191671453,-503.62940021817406,72.21922632188492 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark45(-276.0938068407503,-501.7900152960358,63.14340901432027 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark45(-276.1183347309449,-534.6037533018384,36.423051979571824 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark45(-276.18938037549646,-480.05767082739993,49.99104204698247 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark45(-276.43456916783794,-499.462778051312,53.579416546352604 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark45(-276.49721276528464,-479.7770984161926,86.89644939425077 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark45(-276.74815413393526,-476.8702364845372,23.001398952973602 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark45(-277.3130054056527,-486.25971964619924,87.32574433545653 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark45(-277.5391068499871,-487.79125189761754,67.71002331100561 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark45(-277.75877112118985,-495.32106061869956,100.0 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark45(-277.8620183144178,-503.4925233027236,35.773895583445665 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark45(-278.3898354553567,-473.1755340031065,90.05343618195582 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark45(-278.80537145167006,-506.6630577735923,85.15024759974277 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark45(-278.9150222594935,-483.2298454160363,69.59045409725832 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark45(-278.9362600141959,-526.7744570947776,19.608851016918976 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark45(-279.1175898144171,-476.1139182807592,63.17273017840478 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark45(-279.1699441193293,-516.8673524111418,100.0 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark45(-279.22531739183114,-498.23490835714085,24.873849910522623 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark45(-279.287811512184,-469.86464534490517,100.0 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark45(-279.29854034190447,-530.948773308833,7.026628372854773 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark45(-279.2990997053098,-476.0778837901723,100.0 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark45(-279.5553877717166,-528.3662754402533,8.72714371988377 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark45(-279.6008436292492,-482.02885290693234,100.0 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark45(-279.71940768513394,-476.0334703045342,31.805447841222502 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark45(-280.0393213372667,-474.3543213110531,73.63044250719052 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark45(-280.2004287979689,-477.43952810703166,89.87729618677318 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark45(-280.3102778114858,-477.147342768572,100.0 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark45(-280.321818179626,-477.84110723880207,34.49306644290829 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark45(-280.3665966697244,-473.72052059990824,100.0 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark45(-280.63097480777304,-477.7830742071625,39.020896244425956 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark45(-280.6445578718693,-497.90872843994936,0.8684429185451563 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark45(-280.8591851853678,-476.3315455511484,100.0 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark45(-280.88615398381376,-474.6028557274688,24.971432987892953 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark45(-280.9976139279595,-497.41987326258294,67.69854086781004 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark45(-281.1665664519089,-489.8523799668131,61.82906829644415 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark45(-281.17664145601964,-524.4634195166035,96.54462001169571 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark45(-281.2269192486561,-529.5572066096383,46.43575085872024 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark45(-281.5022257477574,-469.9590026348409,61.293428042684724 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark45(-281.558689400111,-471.5408163180307,100.0 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark45(-281.6552767823527,-489.90757084294887,80.58747728204173 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark45(-281.97121350003175,-472.0336354822501,3.241239074547991 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark45(-282.0783467249284,-496.7185179579723,26.05391215405531 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark45(-282.22108278555095,-475.0794138722348,24.112445750676898 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark45(-282.28219444157645,-467.78873779223363,83.49405842594965 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark45(-282.39413613795364,-487.53494500977445,100.0 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark45(-282.59804023999055,-472.4607143721362,51.29488281855507 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark45(-283.1106344862008,-487.19567010482706,100.0 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark45(-283.3408502679135,-475.07210374961073,19.842252130612096 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark45(-283.59427638273934,-469.09714848490563,68.32339946064207 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark45(-283.74862863628675,-487.79530519392534,81.76511058467077 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark45(-283.7983259893319,-482.87371234461455,56.32015600345514 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark45(-283.8264081330954,-494.3745599289858,12.973247686085429 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark45(-283.8334027248722,-489.90685828208416,100.0 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark45(-283.88045959642085,-511.40257122487657,68.62267016960132 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark45(-284.0921049720712,-472.40032787179547,73.39324861915014 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark45(-284.3727259214587,-502.2228286909345,21.44938819755609 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark45(-284.4059169155317,-473.36756221536876,9.83989049418237 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark45(-284.8441453758373,-478.66393793238564,100.0 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark45(-285.1165459701668,-465.6055757938415,53.86285477899682 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark45(-285.19159128105144,-460.82830410427374,5.430380384924206 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark45(-285.2376230868124,-513.288959152293,20.00520822451857 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark45(-285.6091900072154,-464.27844627590207,41.9462327293283 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark45(-285.849021919984,-469.83182710003234,100.0 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark45(-286.00775333457113,-462.2919336582086,84.57607318120998 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark45(-286.15033262522553,-520.9694745097986,96.44541605482792 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark45(-286.3389246264822,-465.6127462996738,99.95315465667079 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark45(-286.35819314289375,-467.0211778224577,70.32287394449624 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark45(-286.47343738129695,-470.7744563584448,100.0 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark45(-286.4740700290074,-464.90730149807655,100.0 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark45(-286.89282174973283,-522.5985713853953,79.91593876492087 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark45(-287.02005007181236,-491.8340133361163,63.52954175306277 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark45(-287.12424827129183,-534.4671009983014,100.0 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark45(-287.19249565834843,-557.7959009671041,82.34880295747084 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark45(-287.3108361782675,-458.97049836603355,45.43873211278509 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark45(-287.3211132598446,-459.8719874032608,8.561273299842824 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark45(-287.37669510080184,-489.81584887638104,34.568682106403486 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark45(-287.7946151030788,-534.8068797580368,72.38258428966884 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark45(-287.81063928771994,-472.83251413076516,15.84728573898795 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark45(-287.97030314439866,-491.3094923444663,14.029618308949892 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark45(-287.9738364486477,-463.45537070134947,100.0 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark45(-288.0153339264029,-458.1183203957172,8.770965049538916 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark45(-288.2235799263439,-506.8448381488977,32.51214787616894 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark45(-288.49965705412365,-463.613661741913,79.33582333371209 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark45(-288.5290182696853,-480.00833149154005,76.12125023427043 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark45(-288.5505981001831,-476.9812180021319,100.0 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark45(-288.8964867881175,-539.4356620350119,16.97297565129932 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark45(-289.05971192544695,-467.70715214705626,34.54372765992139 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark45(-289.13274489658403,-469.76589012048925,54.81146706577934 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark45(-289.37928535411913,-503.0314825931938,13.564596796522977 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark45(-289.54847906641027,-509.771894930669,100.0 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark45(-289.5869243995347,-504.1707314467334,17.282988308031406 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark45(-290.2207090997937,-461.2493849069679,11.64863055912899 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark45(-290.3764418323219,-485.87468155620235,100.0 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark45(-290.4522526094669,-456.67242625563,100.0 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark45(-290.72208653703314,-471.61587465145493,80.25167116160861 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark45(-290.7645530792559,-514.951792745249,62.87977181916423 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark45(-290.79893270268474,-473.1469908325437,81.02652879183475 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark45(-290.9046337488172,-462.8962817833495,54.38934031089187 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark45(-290.9366436605857,-486.7763557910339,52.63383117310687 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark45(-291.1524584086356,-506.972514955458,86.94700425242584 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark45(-291.5474072037923,-465.951790347959,96.11341361529085 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark45(-291.6981452385444,-519.7623874441972,98.30111779134117 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark45(-291.7316532342727,-454.7428740683601,0.6759455675137458 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark45(-291.76645699796586,-454.24124715237,16.529728048881836 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark45(-291.93598190488103,-485.25001421545176,45.822634964663195 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark45(-292.02209518481675,-454.092288355535,100.0 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark45(-292.189539239597,-478.87625291608003,8.777581790432151 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark45(-292.39916695213606,-454.67771421992046,47.18769234195864 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark45(-292.9392414859559,-456.02437598481964,16.057260101997926 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark45(-292.9436264616991,-529.5911089665726,48.111566948423985 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark45(-293.28954070568034,-477.57790200231346,47.71258543899384 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark45(-293.3340012077958,-490.35120037080304,35.90617752105396 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark45(-293.46980860622466,-517.8574493318021,100.0 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark45(-293.5661534901892,-453.66438958705663,3.8606150129328682 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark45(-293.67230011911084,-480.7697067591712,13.197052844119497 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark45(-293.7651874101496,-466.19746869930424,38.7393003719873 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark45(-294.4152889963658,-452.70953248698027,100.0 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark45(-294.4733709139296,-490.8674026798624,27.1389196599591 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark45(-294.547262516141,-469.8331868091076,51.13106052149136 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark45(-294.63307245766214,-459.2710122024171,12.924266314832792 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark45(-294.6802532273483,-467.90390120264567,100.0 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark45(-294.8265970059192,-466.8545876326458,33.47341450386213 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark45(-294.8321073201582,-463.7717541619126,5.621214378897307 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark45(-294.914195331139,-471.19120711256556,13.282710334543708 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark45(-294.9446625914558,-519.6309800115046,81.90524669861227 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark45(-295.0198780323738,-460.2841087944741,96.41493990365538 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark45(-295.4840349971324,-461.6460325703523,22.081733672598446 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark45(-295.5295558698465,-453.2500055120128,100.0 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark45(-295.557609613921,-463.12407471835047,56.25497718194086 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark45(-295.6028299215352,-470.6612611579627,46.80633808699835 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark45(-295.6423272461459,-459.07202140069484,19.77241916693488 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark45(-295.8092269613593,-469.14275517255743,74.43995470827659 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark45(-296.4261926088881,-463.0786300244631,38.3223294905013 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark45(-296.4381583641871,-460.33865358522553,18.74165678620379 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark45(-296.5553107558386,-453.83941243286245,32.45604827048993 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark45(-296.57508997671226,-463.6802825538414,53.14893278244125 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark45(-296.59408307700676,-494.86644411060956,41.66652978140576 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark45(-296.6724080933391,-482.60707864575556,100.0 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark45(-296.74362822028854,-449.7046670591008,85.3442012474136 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark45(-296.8987988129021,-467.3977614054903,11.738816526641642 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark45(-297.00490834439086,-468.98799211844926,87.31628055977532 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark45(-297.1129004032776,-454.4630159812629,83.57170148341552 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark45(-297.1177708705941,-464.23806263134713,100.0 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark45(-297.22245141039343,-478.42633629434647,20.23218313784689 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark45(-297.3023394589496,-461.7590285617088,36.471907046875685 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark45(-297.36931352394953,-473.5090492941052,30.914922076109832 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark45(-297.42922946957157,-504.80267155563234,86.60552991255366 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark45(-297.44500959922306,-481.77241410124043,8.695263406709472 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark45(-297.7363213700702,-457.18602959543654,100.0 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark45(-297.7757656489201,-520.5453069804277,22.274609570741276 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark45(-297.80963131923585,-458.9496372023167,100.0 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark45(-297.9687092486281,-481.38966722347345,92.7765984391117 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark45(-298.1348849413086,-449.3074217848632,85.89070792404604 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark45(-298.1774613893555,-449.66841941247816,65.82950933191802 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark45(-298.2681717840831,-455.5197052784694,44.63158683997787 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark45(-298.80536790575746,-448.3311950789144,49.44006253353771 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark45(-299.04769945539846,-458.8327523102959,0.6365492734909708 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark45(-299.07674017106206,-471.7433004193841,16.78363489628372 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark45(-299.44112393587005,-453.68531148613204,95.10464377373361 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark45(-299.51673486768425,-478.6812904862107,21.487332578541302 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark45(-300.05256634913627,-465.35968204110907,10.309971082686136 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark45(-300.11176867405305,-453.07257399887493,28.20412661200072 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark45(-300.18185697687494,-480.50679773003543,22.44734486294317 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark45(-300.3419834734285,-488.716163691045,44.15126279146793 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark45(-300.3715364381591,-448.9253352977849,10.355824423969011 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark45(-300.59315179826126,-458.04415694571986,97.38630196390787 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark45(-300.6012979311788,-448.84567105629526,67.06009241987817 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark45(-300.89799063840354,-473.9943822519001,8.493576905346828 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark45(-301.02940235529996,-465.32862997940333,35.15372748303548 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark45(-301.2655047266718,-462.9876781721477,60.561040642343144 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark45(-301.3886352557515,-457.25980524755784,2.455013849758984 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark45(-301.4492861526471,-492.2642877531555,87.04006956870379 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark45(-301.839845150333,-457.1677665794351,100.0 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark45(-302.0700838274009,-503.046330311906,3.6869230783153313 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark45(-302.45283238020767,-447.91350198400175,8.068247269047959 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark45(-302.4574620439122,-445.9079977070682,79.33266710122169 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark45(-302.75298053519293,-485.0700114982132,0.19488569371814712 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark45(-302.80783257856353,-446.1786352714499,81.97388458841422 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark45(-302.9077577283347,-462.60534631038445,77.3269646621078 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark45(-303.35069315343065,-445.51938865089335,100.0 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark45(-303.3636330704151,-509.8178360725398,59.90497018230295 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark45(-303.3981328796507,-476.6703656962294,30.900295144959614 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark45(-303.4264848836265,-449.36033344411476,9.9646458778352 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark45(-303.6139569544366,-444.39527014848767,83.23400749400872 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark45(-303.746214273686,-462.0805675815668,66.47734560141808 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark45(-303.85762499911027,-460.24542776983185,12.054705988963946 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark45(-304.0521165609949,-468.1413606330216,33.31282054786065 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark45(-304.1139788501697,-446.88432486743625,14.126740705099422 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark45(-304.115302625547,-456.20879059948203,78.2761859515422 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark45(-304.32419035144073,-452.172277655696,14.911711702254209 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark45(-304.4959348457123,-459.5744832406042,23.709322664050887 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark45(-304.5135171910923,-465.5681383552706,32.390049462421274 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark45(-305.0210963082421,-470.69743877041117,68.77587511207628 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark45(-305.08531213123433,-441.5772856753792,92.72049763660792 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark45(-305.0936886425943,-456.6014818735191,96.79241746305621 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark45(-305.50914335447374,-444.4440332319179,61.12864763075797 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark45(-305.53502087651896,-458.56631114918974,25.144708963099106 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark45(-305.81894413449834,-458.610491985779,94.18368302931272 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark45(-305.89294721963734,-511.3488832451338,68.96977808966983 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark45(-306.05786400246643,-456.3354275537436,85.59663301853348 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark45(-306.1343981594472,-453.4900588532704,33.72589782656962 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark45(-306.2615380708969,-464.3394733660427,100.0 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark45(-306.38922407200084,-518.6076367527448,96.61603171712753 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark45(-306.4515472887805,-471.33775428365357,100.0 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark45(-306.6775282848231,-451.78763465453864,35.41309386012583 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark45(-306.77058460843676,-442.833839890173,37.38165669520697 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark45(-306.95296135515457,-439.06109378625297,33.67577863500827 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark45(-307.250322954448,-506.7293886967485,100.0 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark45(-307.29205905765923,-517.0188112170653,92.83308442860803 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark45(-307.46421146308154,-442.35864172788115,34.883726157874776 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark45(-307.51101249147933,-471.6999655575199,18.86757380450517 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark45(-307.72983170668175,-460.7544518307984,100.0 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark45(-307.75439608220535,-444.45985100580083,25.92092001474083 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark45(-307.84857446444425,-467.5727403181992,74.3673615239623 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark45(-307.85354605971435,-457.8153159168867,66.57977108448151 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark45(-307.8757702641955,-442.1504839824296,27.345311780389792 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark45(-308.1103147456696,-477.60515613790363,98.77664852605409 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark45(-308.2894571504017,-448.19285336361963,86.25811565960723 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark45(-308.34532609308167,-444.92547373083914,81.36230455489388 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark45(-308.4507613237172,-451.97649022139,97.99701213130464 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark45(-309.00445337914005,-486.3200127155302,55.98795682655026 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark45(-309.06277919667184,-437.2809738446524,88.79087647043195 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark45(-309.0928423661614,-465.8081795147443,100.0 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark45(-309.4406556257057,-442.24741992247124,66.10710473935774 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark45(-309.6258037746754,-452.61053531617296,30.11893522406845 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark45(-309.7109011353675,-475.3569547921327,27.59952412944176 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark45(-309.739866475811,-466.9136937702268,100.0 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark45(-309.76139968602035,-443.67723188578316,7.330010367218648 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark45(-309.9031342828352,-453.62309307827684,100.0 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark45(-309.97920312171675,-441.48475106040155,75.26123762891274 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark45(-310.01018095248133,-452.7176484323716,100.0 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark45(-310.0469857255477,-509.9430925521695,72.85673678254417 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark45(-310.1006528085926,-465.92658611631344,57.274699749401236 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark45(-310.14370161702334,-488.60263771795775,91.16933171397804 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark45(-310.1669403815113,-485.12547926404034,100.0 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark45(-310.671942044973,-484.1219144686079,100.0 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark45(-310.7816010032904,-484.8901586210174,18.319743013813067 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark45(-310.9630731740947,-456.28311004190016,82.86843475070057 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark45(-311.30277633778,-443.7168981399541,9.793373318676487 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark45(-311.3121139785227,-443.3080358144084,70.66642665221153 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark45(-311.37165814640457,-464.63180395304164,15.453543295131396 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark45(-311.3829443240147,-443.24557935760447,15.270059627698274 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark45(-311.4526050228645,-449.26752978313937,85.8316420255945 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark45(-311.4676630720518,-515.2704497172266,28.200922355959364 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark45(-312.2450452737143,-439.7809139100564,2.433908071001298 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark45(-312.28302252493734,-468.22201445164444,100.0 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark45(-312.3986277228622,-450.6132582602995,68.88791553274672 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark45(-312.69226225613636,-463.6483338336349,82.8168980192184 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark45(-312.7064700438002,-466.3199510826893,48.46406171791412 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark45(-313.02021620574504,-450.2802850663956,25.417606673185787 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark45(-313.02551585245374,-442.2926561201442,18.564099859818924 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark45(-313.05870732751373,-472.8518759666162,42.94036437368226 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark45(-313.23217688027256,-450.70370480867683,78.00167825953889 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark45(-313.5138331760337,-433.4072932125729,47.399849883029134 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark45(-313.5884487270252,-453.1191067107412,33.95288266475549 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark45(-313.7087792172619,-444.61725678773774,4.160208890510788 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark45(-313.75420845162336,-460.9052849900111,52.6088414913701 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark45(-313.8608906937127,-453.0579841923607,70.76613980085818 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark45(-314.00261574851885,-439.1904175328214,95.52583156116432 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark45(-314.1435340269877,-454.5641642892754,90.48634116409485 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark45(-314.1924250398739,-495.20543966051065,88.26147436366176 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark45(-314.54739721134547,-462.7930307293326,40.14216220934097 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark45(-314.58677073478555,-465.2108367786711,0.5923314505089223 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark45(-314.6296562552764,-480.57733552615286,3.367643315233778 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark45(-314.6461969552651,-488.745236079928,100.0 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark45(-314.6757972339844,-451.9388326445311,16.142653589116108 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark45(-314.79827358827833,-436.44156300708596,1.4541173506247702 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark45(-314.8598564453074,-444.3006803353695,46.094831581635816 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark45(-314.9502242954025,-435.9234835564389,8.235289881816229 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark45(-314.96516746854735,-431.9709528354399,82.68621540385462 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark45(-315.0607643047731,-452.26424567589464,81.40120463677408 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark45(-315.2008219920882,-443.9177146789696,61.224441945706076 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark45(-315.32709065838554,-439.8788206027159,100.0 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark45(-315.35363779365207,-465.39404356960284,20.791186023561174 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark45(-315.47414425165,-520.7517063095761,8.20425984539935 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark45(-315.5595128187433,-449.91465835091975,53.760737568461764 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark45(-315.55953463879837,-508.71610265752497,48.856733261910335 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark45(-315.6449647707132,-465.29668434663733,74.67169470710596 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark45(-315.7378891465551,-432.5946490910054,54.02887191052142 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark45(-316.08866447702616,-503.26289056671055,54.53270681743393 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark45(-316.2950475662605,-461.7870465103649,52.72871066144987 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark45(-316.3790326975242,-458.1377357887579,15.496734172297437 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark45(-316.3804126142198,-476.03309643571197,44.155108944896625 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark45(-316.3949228550566,-456.98718915205734,8.557016745145177 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark45(-316.5422961589819,-474.43359632476313,46.538803468440534 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark45(-316.9412314004777,-467.422049582154,81.79291338327573 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark45(-316.99572952958107,-435.40322846754805,16.988373698539434 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark45(-317.0635657749108,-430.41343340781754,0.6711139844576053 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark45(-317.2143750231112,-456.1011259880066,28.653879766704478 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark45(-317.2172616239661,-451.39094229048663,20.60924786305212 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark45(-317.43749793836804,-451.68955876647976,91.31856842146036 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark45(-317.4458736766505,-445.8914981359799,78.77710738127259 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark45(-317.48055453398786,-489.20648753950644,64.6448974678782 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark45(-317.50888638271863,-464.0742885819056,92.20046584399805 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark45(-317.60113557987256,-470.2660134555281,45.09529520583661 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark45(-317.90101051839974,-429.520861929946,51.84071411191189 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark45(-318.0709246929891,-436.4610683954249,15.18005409756779 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark45(-318.1981144753555,-454.9489263074354,6.816164792167385 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark45(-318.2137323912773,-447.38368769644404,38.0341171557788 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark45(-318.25814699798093,-436.38932771948,8.336120836102612 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark45(-318.2947367355697,-460.7840470079551,9.219987948974792 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark45(-318.69784024668445,-442.35619497280385,100.0 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark45(-319.0718872450502,-434.7648392822883,39.01770888879821 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark45(-319.09245736413027,-448.64449928503376,4.584392554479706 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark45(-319.153128305009,-428.27345062027996,43.60704991040791 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark45(-319.18337519580234,-464.5376202572019,25.102558650407374 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark45(-319.4629291271589,-442.91845217465885,11.707467288289422 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark45(-319.54048050400706,-469.6491350687339,72.54317894973545 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark45(-319.6356906640955,-438.50048498110726,15.135824220515289 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark45(-319.9719339434713,-428.43637786998534,76.62290302337698 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark45(-320.07043500493836,-428.73241908770024,92.00242158904456 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark45(-320.15932945799796,-442.4020724404778,51.805382924451976 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark45(-320.2547918177643,-489.9644778149861,26.82845820593569 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark45(-320.8832314529977,-442.61067064240893,96.817328407014 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark45(-321.0797072651653,-438.9104256030083,91.84318002482354 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark45(-321.3161951369746,-501.21998181264814,48.29132263586044 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark45(-321.320876621264,-444.1790400521515,39.731593964967665 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark45(-321.386887370657,-430.6145769289789,9.941712155570045 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark45(-321.513899023668,-430.7462976591594,50.79981835859277 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark45(-321.5179313818782,-488.2985402317163,69.50548447171278 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark45(-321.5365822552475,-445.0815889096112,60.00997368571643 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark45(-321.60653563520475,-434.833515183522,17.694708515837505 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark45(-321.7096167138282,-450.60733936890136,47.92304373038917 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark45(-321.81862694217216,-465.83029542603856,47.277135486487424 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark45(-322.3112020681,-455.68573669841226,88.2515164342424 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark45(-322.66582565744113,-447.6521196314704,100.0 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark45(-322.6722752459865,-456.14639137441924,95.5625495975537 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark45(-322.8292166633385,-444.67014597047825,21.896272965466437 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark45(-322.86266182424663,-477.56495624253506,100.0 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark45(-322.97011398946984,-501.1234594474029,89.5455178312088 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark45(-323.0142050907664,-443.1545580512362,86.29606526889151 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark45(-323.0900552088168,-485.3815914808291,66.74373566663542 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark45(-323.1443333556986,-450.8039710889057,6.88700514511109 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark45(-323.25808620948834,-479.69226955785285,90.71575852757573 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark45(-323.31759390554515,-433.869401841053,82.78801851738649 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark45(-323.52712454465944,-452.90718704959556,100.0 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark45(-323.62005836684483,-433.68796793167274,28.636402872133942 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark45(-323.8327171485789,-431.36785855913604,10.752120880195989 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark45(-323.8897978875226,-429.89005845442654,75.6599788341467 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark45(-323.90934059665886,-440.96640304203385,44.16988196373944 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark45(-323.90961994912146,-438.38338241965727,7.105427357601002E-15 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark45(-324.1489891139307,-447.7377001762895,28.347962694947398 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark45(-324.26607302461434,-434.4684689621009,30.621483524686198 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark45(-324.3661419787541,-451.1209456149187,95.90573214801691 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark45(-324.3985501938255,-462.0672796370597,100.0 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark45(-324.4351068954181,-428.6406933795424,62.20134719996949 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark45(-324.75937809853167,-424.3154708510344,39.71650479042802 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark45(-324.7732527355973,-458.1904567799093,61.08173445074172 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark45(-324.840948437395,-427.6989239269377,0.3105514807281793 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark45(-324.8633021142913,-438.5894398651297,37.49898585856903 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark45(-325.2840846943161,-474.73737993562355,78.4735331443153 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark45(-325.36362694344757,-443.32678393344304,55.62981148949129 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark45(-325.3691919955412,-434.14464300661933,6.695618346822079 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark45(-325.57140947218045,-480.0085727989601,76.79440420489766 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark45(-326.0337574146815,-429.5310255547811,70.23534231844931 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark45(-326.07673556007705,-453.12557510037396,27.43578527467608 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark45(-326.15283211883195,-435.7981939765241,1.4210854715202004E-14 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark45(-326.1619279381947,-428.8507428490549,-4.0306522562707505E-6 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark45(-326.25603969136506,-430.62656627827675,16.67834028007084 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark45(-326.3424264437493,-421.8505551202804,31.40672859018335 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark45(-326.85603052932356,-479.46380950492187,95.97786754964008 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark45(-326.8701573801758,-481.63737260278197,37.52012160929701 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark45(-326.8966845427492,-421.92316413724615,83.69200145450262 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark45(-327.0465493695077,-446.7642118378096,30.65850308926781 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark45(-327.1526761692752,-420.73962195580987,22.11149306968477 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark45(-327.2791819964697,-465.8663555360572,100.0 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark45(-327.3430948464358,-449.58956980359517,5.766611161851159 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark45(-327.60684125556793,-484.6517583413177,13.552785610499399 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark45(-327.7571631316729,-427.12680554473053,40.525702060726445 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark45(-327.87300269750244,-439.226615572982,37.395713132271425 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark45(-327.8917703323929,-471.62981192083004,100.0 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark45(-327.930790370939,-425.3888068472854,67.08334031059903 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark45(-328.2370592187351,-424.47290183632117,65.6853324117348 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark45(-328.3915554055742,-468.38351531343136,96.792920304884 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark45(-328.4589475838923,-513.345614220936,58.07800721143573 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark45(-328.45991667297665,-437.2858339192447,54.32342055382014 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark45(-328.4631508688856,-425.81060121293586,7.38780164604762 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark45(-328.645309734431,-428.84118332179503,25.76353074381916 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark45(-328.64625648033723,-471.3616030884371,100.0 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark45(-328.7404641006633,-417.405488763733,54.68596896145988 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark45(-328.9827078672333,-419.2775079831651,47.10256898167847 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark45(-329.0047937920178,-417.9333497939297,58.47735050833646 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark45(-329.3816956808644,-441.5266024924224,79.92459980259369 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark45(-329.4068317792779,-419.5803403270219,99.40147785064806 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark45(-329.4071486910072,-484.76648724393965,75.61056206229009 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark45(-329.45204133144546,-420.31510581844657,29.7762176194405 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark45(-329.57567911727654,-430.7443975018302,15.455863250255632 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark45(-329.5944449178985,-424.8863672129106,0.9007857735063851 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark45(-329.7004143841606,-427.861399196959,61.70456605273864 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark45(-330.2123447652573,-490.86087568776276,34.67180951032981 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark45(-330.2129189614036,-437.1139250493337,30.548896742860506 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark45(-330.2204679312376,-453.25336946027187,27.18536351417997 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark45(-330.51347459288996,-424.58269169506264,4.497043088400403 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark45(-330.5459309401939,-473.2585729559498,54.54004354497292 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark45(-330.5733828378487,-439.79415894617983,100.0 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark45(-330.6275110044487,-421.3209176281804,100.0 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark45(-330.6869976664165,-427.6063796176164,83.39142760180485 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark45(-330.83159131438606,-415.3643852509293,95.97092462937965 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark45(-330.9747935348249,-415.4159216278783,71.98195106605439 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark45(-331.12090263737457,-424.26011953283364,88.4825713404893 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark45(-331.17151409515884,-461.71453968709307,2.354915877531141 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark45(-331.278706967266,-434.30597772050294,100.0 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark45(-331.43087128040554,-438.46072623840877,94.73972475867654 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark45(-331.4980050322606,-450.3894514139947,17.239394917199107 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark45(-331.6071198195167,-420.2995361347458,96.78198285671021 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark45(-331.7384792521168,-433.4919377005748,41.01477022533564 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark45(-331.7508780470131,-423.2463687161779,19.599568258809086 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark45(-331.7645002160992,-429.1408313519737,1.99317833979927E-10 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark45(-331.9278333590959,-423.6026283167794,43.06031313279007 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark45(-331.9290784048485,-430.64892892414804,78.11424752578446 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark45(-331.93829200554524,-528.6111771942855,0.44816548942783196 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark45(-331.9685559726481,-422.4902805965918,9.02423923705014 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark45(-332.21354765505424,-494.3482253342458,61.803767600019256 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark45(-332.3291033305742,-424.40590283934307,6.39807716318974 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark45(-332.55614266480586,-505.87525120135746,98.8000884943537 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark45(-333.0362386391398,-427.9854374868641,29.532293920777022 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark45(-333.3644545968179,-513.90498719186,82.95151518691193 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark45(-333.39256070522055,-421.5837233323276,89.16622132847877 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark45(-333.49697626439456,-433.7047888833379,69.3035002144594 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark45(-333.88863878132145,-449.46019795203614,60.98615838065081 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark45(-333.9045284066589,-429.72589744170983,38.94073825689361 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark45(-333.98443798088823,-454.8937281220718,76.05582678747217 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark45(-334.13582787769957,-427.01646850649524,38.53864772061141 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark45(-334.21135525175987,-428.802234813269,25.477389319565134 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark45(-334.27909616055007,-419.8925133696985,42.73385838595678 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark45(-334.31145694874834,-420.6490589759403,10.637727730619702 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark45(-334.31821714111317,-426.3929502317559,100.0 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark45(-334.7527717003733,-421.97668430980684,72.43927472220096 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark45(-334.85406891798397,-419.8504074549851,30.351829767554364 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark45(-334.93511629618,-433.02663505226985,39.4814204820608 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark45(-335.2138371945635,-421.1557565261857,46.265278893877706 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark45(-335.42678448938256,-492.23871314965373,43.20468517335135 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark45(-335.4512182398169,-470.6994651300206,46.53682802598064 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark45(-335.58786820184514,-422.0142951941292,0.3628055639500758 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark45(-335.6151210775377,-488.33585792250307,95.15028584030429 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark45(-335.84635051463437,-424.0533603918895,64.65052877070455 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark45(-335.94908173101754,-410.59720868242584,100.0 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark45(-335.9838515631804,-423.39852749307795,78.1230553423807 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark45(-336.1699580144201,-420.2529779384367,60.562174286558935 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark45(-336.23179767090926,-413.2714792702827,22.148577321631052 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark45(-336.2377654700273,-428.8190247402168,100.0 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark45(-336.64913522336144,-461.6790649603833,65.08090821487897 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark45(-337.28598917640153,-415.6270849856478,100.0 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark45(-337.5262316748836,-475.96695970202063,93.11433233700694 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark45(-337.55344772554525,-445.7404324324198,97.22086014046872 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark45(-337.6259591820307,-477.38797652602125,41.942204065662594 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark45(-337.75303731848885,-455.5720534321609,100.0 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark45(-338.01453533500165,-414.8743777706439,50.16917941512534 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark45(-338.02989535207007,-440.93934650368834,57.93191657231068 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark45(-338.0306532005068,-461.1557647725486,50.1015652017517 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark45(-338.1148228493532,-483.5051153207592,10.175236371492737 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark45(-338.2357398961719,-432.9520779406101,92.79984364402881 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark45(-338.30720391741096,-435.301338816683,91.57347363665201 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark45(-338.3992163976722,-421.83702227978614,51.75650180862223 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark45(-338.5126136261585,-419.1450987432826,95.65304041630668 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark45(-338.6925291420915,-485.26898497022745,-38.62153709426393 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark45(-338.82095886785584,-417.9220808016905,83.37098476523454 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark45(-338.887975121086,-436.40784489220874,26.315962030882204 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark45(-338.90680940744,-412.0700334427144,1.3216458631627006 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark45(-339.05299836744285,-443.8889049929431,60.66483131683631 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark45(-339.0576057053432,-427.5984752739948,76.78372143037217 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark45(-339.12217418154404,-437.79814077175394,100.0 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark45(-339.16069172515637,-460.03760676086864,25.903684085675692 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark45(-339.18139195147944,-417.73887029564435,83.23285387449062 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark45(-339.2141233093044,-418.7535440232088,100.0 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark45(-339.27972352448825,-415.2731542677428,65.36860300494178 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark45(-339.3758184233872,-421.5729340645637,43.790091762668254 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark45(-339.4294976980181,-416.7892102418258,100.0 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark45(-339.58984053181877,-436.0173237905094,81.0478003760991 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark45(-339.8546137131899,-438.99875217891304,66.94936919819872 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark45(33.99299672643005,67.75457432394185,0 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark45(-340.01294848235574,-406.90622464699203,27.29901595630635 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark45(-340.08288824628227,-424.28710603465856,52.68129147043322 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark45(-340.3026657314895,-449.79965056785824,100.0 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark45(-340.3764562420419,-440.61787398849805,7.47249675283193 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark45(-340.41545860200284,-453.2144465268495,58.608880387839136 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark45(-340.4637942921972,-448.3497862322464,7.537015724354987 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark45(-340.5203997776771,-408.774393132092,33.46880936507631 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark45(-340.71693071838615,-415.7553634916319,100.0 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark45(-340.7307155355886,-425.12405596369314,50.59984322584569 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark45(-340.7901751635601,-406.83536021632773,4.247269408097182 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark45(-340.9492845085111,-468.81306994987716,32.00314338749908 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark45(-341.0363093335174,-419.22943991782853,88.06565048396527 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark45(-341.04514106808807,-421.5398482644717,96.68747731476981 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark45(-341.0821544223097,-418.65798970358,27.305672060138406 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark45(-341.1982785078959,-446.08989281759955,81.41079525519581 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark45(-341.2091476477623,-406.9040136723867,25.880624702242343 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark45(-341.2165667885998,-448.2816073565341,86.65066855670449 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark45(-341.2346426734821,-515.7195605882027,99.24437346467906 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark45(-341.5891743252862,-421.22157127620494,86.29706902088793 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark45(-341.64053960164574,-424.53157000543774,79.3270338526965 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark45(-341.65741422273675,-429.06902881540304,9.072657437370445 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark45(-341.89915707546123,-468.67911405893517,22.479258076698088 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark45(-342.04700499932187,-490.1071979437118,76.93098327496838 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark45(-342.06324456492206,-412.9275320102554,48.62649366266817 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark45(-342.2755969458132,-433.6371795702125,60.57207246948428 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark45(-342.3512114750629,-409.2825366834469,64.83030980429336 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark45(-342.53728346443705,-415.31062604462176,42.00644395363929 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark45(-342.9409580235284,-404.5433900527439,6.210176516872561 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark45(-343.09331081039204,-451.8521822607869,67.86123458361732 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark45(-343.12364488285925,-432.7008562247917,29.760713539395056 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark45(-343.20220527119284,-407.86312204642905,53.51149354890225 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark45(-343.24888718098856,-427.9464649855858,52.69374510536167 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark45(-343.4429090054319,-433.9116443723033,59.9443059838907 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark45(-343.4698721059608,-418.9241939595826,99.50571944702088 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark45(-343.5013901652991,-460.9726491640769,67.26707676446907 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark45(-343.5081599960582,-455.98857501917627,2.358255869148863 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark45(-343.5965316307169,-434.0944503059627,40.740614973799865 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark45(-343.7205334741835,-487.8918746268933,9.305298947891062 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark45(-343.8079598174391,-425.7867796815715,79.44478503110989 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark45(-343.90225105295366,-437.90728484925523,36.94731471477708 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark45(-343.9044151131127,-447.92877895268293,99.44616312694546 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark45(-343.98181170068506,-465.08606646281186,21.325776753215372 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark45(-343.98360921283796,-422.52500913397404,80.71530099067667 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark45(-344.2681136262699,-446.17986607759804,100.0 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark45(-344.4187196708561,-422.1480379760834,46.45627828516866 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark45(-344.44918489483007,-407.57396939610123,6.137205562328489 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark45(-344.50322430219904,-422.69462515139065,100.0 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark45(-344.5046464715478,-460.46730174117505,63.03261205472498 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark45(-344.5790108403232,-409.0192096205818,43.05900117721808 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark45(-344.65578164204584,-411.4279921751056,60.52341042833493 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark45(-344.7159340641334,-435.8458982824114,12.156181191251477 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark45(-344.7449951424907,-455.6479039598877,13.926617037454818 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark45(-344.881154447387,-411.2396431442351,46.23594060847148 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark45(-344.93081476481825,-415.8185308057327,24.397120278245495 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark45(-344.9938298557906,-402.10258593276495,100.0 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark45(-345.27870749152146,-426.6135108860059,100.0 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark45(-345.40512378501614,-464.6050173579184,37.768718364023215 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark45(-345.59609182189854,-403.188983212595,32.27092226526557 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark45(-345.851782227902,-413.1640968203095,46.28416700291399 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark45(-345.94935530698393,-412.1873323056759,33.857887217573506 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark45(-346.19278950397506,-413.8320624089006,89.3923147846289 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark45(-346.20133828427737,-422.33325444603213,81.81401521957179 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark45(-346.30337267064533,-415.34960507459573,19.790248633324197 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark45(-346.80481939410157,-478.6137456452792,87.02359165531408 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark45(-346.80682311943946,-410.0220632384344,18.967361767542258 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark45(-347.1034783789926,-403.5574400114258,97.32849059775481 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark45(-347.2888859218936,-459.10639947005956,77.27237400283738 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark45(-347.4016505209885,-425.10265251855077,15.58175993322257 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark45(-347.7092292537299,-418.70586832566454,31.963880824386024 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark45(-347.7192213153352,-437.98926713643107,29.17262619857479 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark45(-347.86276332978406,-410.62375222368047,68.96259982262737 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark45(-347.91783324224,-402.4040529104866,18.55717974427668 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark45(-347.99519406489594,-451.81386282175833,60.15083550324573 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark45(-348.0266793398926,-401.8491718419567,39.92822354885706 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark45(-348.2879834490489,-450.3233433199328,49.61382156371383 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark45(-348.4327479532342,-441.85078071113395,64.94096961797479 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark45(-348.4768212707987,-406.2916951440774,100.0 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark45(-348.48624834053055,-434.63239178117874,33.01249760254339 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark45(-348.59437634151635,-436.50687689530423,43.78915579418495 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark45(-348.65847359562645,-422.03824614319905,100.0 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark45(-348.69085742944975,-464.81594331354194,74.9743366038349 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark45(-348.9612929838574,-397.1837999681506,47.1617538794639 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark45(-349.0318670045225,-415.06121429706,75.10387502249438 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark45(-349.08888013826106,-426.4285619347539,100.0 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark45(-349.29944897270894,-411.6945734890699,79.72512675677831 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark45(-349.30253357965034,-428.8469210759082,42.5194053047459 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark45(-349.33652395248504,-403.58249310886197,70.55177815906916 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark45(-349.39554125463,-451.4802368552133,16.66658146520171 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark45(-349.42092843199595,-412.94285681257526,17.67415839459352 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark45(-349.79134670195634,-422.79455927757544,66.65369627762198 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark45(-349.89784064303853,-400.165240808005,3.4705685945872062 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark45(-350.01231330538633,-402.7649822006476,36.3844073773939 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark45(-350.0678857069027,-404.76198839193916,10.046065931614294 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark45(-350.26842921159556,-418.1518798335661,69.25104187073069 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark45(-350.31450119924165,-420.0597370324949,62.552924932176026 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark45(-350.4168625096548,-407.31895860173057,41.971093225675105 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark45(-350.4234285043641,-398.74191862751286,28.198187584666584 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark45(-350.45200168201814,-407.018985162775,31.238305410700633 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark45(-350.4807560560845,-439.98190062242793,51.391234025954304 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark45(-350.48257725211334,-440.2688300341665,86.96319881002586 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark45(-350.4841896332506,-428.36281759885196,81.76241060056978 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark45(-350.6445039543025,-442.317433772994,37.18184084865649 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark45(-350.8105598059634,-432.6289569738142,14.39049297889909 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark45(-350.97181213979644,-400.7337702879664,29.200506537993363 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark45(-351.0845172700172,-405.30708785635073,71.42100453907605 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark45(-351.42238620288396,-412.8726801623929,100.0 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark45(-351.5024384664236,-396.11423551634306,100.0 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark45(-351.66758199282606,-396.80737454918415,4.8738600399084175E-4 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark45(-351.67127892720225,-402.5158763309145,32.674586642182334 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark45(-351.80676176840234,-454.95992037716877,31.042877553500517 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark45(-351.84041328277647,-438.78208314115454,95.47201821690743 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark45(-351.9156332300469,-401.74204622236067,59.07622520735592 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark45(-351.92272563272604,-463.38167363292666,3.6562891056028235 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark45(-352.0236002695735,-396.2528674491659,19.539115825927823 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark45(-352.0578358872102,-403.7024712528636,1.070768284849862 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark45(-352.1128370994693,-394.3279102633124,80.23370913731742 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark45(-352.1449975605624,-454.10100737260194,98.50184784331003 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark45(-352.16860769310813,-432.09921475178095,3.5894583751943827 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark45(-352.3856450742803,-453.99228095878254,0 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark45(-352.57522474060147,-406.9460184588155,100.0 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark45(-352.5958285603293,-472.6492284693084,26.01422123740258 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark45(-352.6564830632059,-445.77137428739894,56.67723556315559 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark45(-352.80894681067014,-439.67380709712,82.91892546414363 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark45(-352.9530661157645,-500.2462227460721,86.40957661935165 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark45(-353.4155905318492,-401.0337659547994,1.3327668835856881E-5 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark45(-353.43409758773646,-419.6683308828359,100.0 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark45(-353.463612630906,-397.918396132135,39.195593051390745 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark45(-353.5788051103667,-438.6873894025093,191.676228777279 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark45(-353.6035749067407,-455.60070323328443,40.128814281890214 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark45(-353.609764980274,-392.9677911290884,96.794175908152 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark45(-353.62653314543275,-393.70691145043327,47.16961294215366 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark45(-353.65127998486497,-436.71082449052034,14.493359728323867 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark45(-353.827972224809,-435.3929053341013,100.0 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark45(-353.87076680223896,-443.85486309598474,9.07554360677807 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark45(-353.91684037956367,-410.0762008890282,10.269846613213957 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark45(-354.27265546674175,-407.4771251504586,12.463253654541191 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark45(-354.44297257637453,-403.76366262181574,39.76242409454498 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark45(-354.92189980570475,-401.98821864253625,33.32121242386157 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark45(-354.9512741714629,-435.6691521669431,46.603250312017934 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark45(-354.95379725224427,-422.59388669851234,80.30709673473078 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark45(-355.1660229907166,-398.1900279483159,24.812519310201964 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark45(-355.1683017456093,-391.3100154637799,99.04246657911844 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark45(-355.18572080891494,-402.9838841960339,100.0 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark45(3.552713678800501E-15,-778.7506006258268,0 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark45(-355.56080056308537,-438.740766975519,43.04104183390274 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark45(-355.6458647652261,-499.550672563502,77.93701242170178 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark45(-355.8190029830707,-405.99102094263327,55.56321606765326 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark45(-355.86739135504774,-454.5391027375917,95.49845794683517 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark45(-356.12863514532444,-403.1396629061735,38.97168928727325 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark45(-356.15727969615267,-417.7528087773354,72.59576290466009 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark45(-356.4639008589923,-399.7320477511053,60.1992738115091 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark45(-356.57104563421706,-455.3896814907159,100.0 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark45(-356.8814995107598,-430.51003525744596,12.019242697121584 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark45(-357.0347521354466,-426.152665762651,62.853719006484425 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark45(-357.13324872539715,-392.0094380979782,76.47303366490186 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark45(-357.45182980494945,-398.29969286808995,100.0 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark45(-357.8412139085759,-482.65158649393106,80.8008648952351 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark45(-357.86051469082935,-397.5129503692046,0.5257163153491291 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark45(-357.96743558920224,-407.24547615892834,30.285105909763786 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark45(-358.1807485277826,-423.379141215136,89.88087482014214 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark45(-358.2044606101434,-397.11266103080635,46.76533997165518 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark45(-358.2485814672521,-391.665624400536,100.0 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark45(-358.27648784302323,-398.73251329464387,16.930597548396463 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark45(-358.49251385967796,-401.6741783842581,14.611767518450819 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark45(-358.7311655495692,-387.9164707780361,77.38779603479215 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark45(-358.78379814099344,-415.02238142407816,0.17058326074746333 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark45(-358.8749531374801,-443.61158751540154,68.58540932717995 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark45(-359.29318098249985,-440.3903381598081,70.97492941569854 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark45(-359.31213833068824,-408.3548364677498,19.598326977381646 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark45(-359.4066779093346,-422.81354316309233,53.1626934159701 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark45(-359.49675419888405,-415.9948310682654,17.235394520314017 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark45(-359.61450981624023,-398.4884943605813,100.0 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark45(-359.7821798057541,-395.6105090704949,80.62083499953253 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark45(-359.9565498693838,-453.46848235949506,32.123791651174884 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark45(-359.9603846733091,-443.6092215128657,27.39354135042494 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark45(-360.2441436701696,-394.2248892309641,75.18898935572082 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark45(-360.36730320085576,-389.1288390772823,1.6504855407942784 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark45(-360.707151391281,-386.7863907751938,70.83548378697446 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark45(-360.7104375691462,-395.1646340461777,15.676722043944551 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark45(-361.03616618049637,-427.20963368857366,0.7646136762992057 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark45(-361.2121779845487,-399.1318319295365,64.78908565010866 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark45(-361.48665338615365,-416.2886691210657,95.74435722666259 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark45(-361.5157784869688,-453.7825330162216,100.0 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark45(-361.5734471405851,-395.1864351580085,64.57203546731131 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark45(-361.5751689480607,-387.1248826850161,14.05991193333918 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark45(-361.64234644518825,-412.32348443628825,100.0 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark45(-361.7515340212141,-386.841366942805,97.23523044039871 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark45(-361.95262020117883,-399.74580564807616,33.39450212145252 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark45(-362.06610700007815,-401.91476960750185,47.370557286910895 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark45(-362.1590918371636,-419.3647555460326,57.38442394955098 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark45(-362.4615643438182,-412.6736033225457,2.1094584145611402E-4 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark45(-362.5198985272831,-446.5058196601781,30.54244631318872 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark45(-362.6846008117528,-395.81449752279207,31.238444598229847 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark45(-362.81250669171413,-402.1483074357817,4.577590694743833 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark45(-362.82053088069114,-390.9555008902781,100.0 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark45(-362.8961641221641,-419.44779450569314,17.081991554954783 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark45(-363.01605442364564,-434.8900663695196,53.51784489905188 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark45(-363.1085491350518,-459.4401334275865,34.24780585968696 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark45(-363.17179950247913,-455.8541041039134,99.69541046008493 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark45(-363.2974874502144,-412.12840842775927,64.89756135231875 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark45(-363.30633922241566,-388.5317808372603,19.98103580004849 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark45(-363.3968378005236,-431.43638040807593,38.94069595937998 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark45(-363.4144293566974,-411.1238935349255,66.69577824035304 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark45(-363.4282907351529,-408.5462752231084,100.0 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark45(-363.49979214083413,-385.15884071484146,86.06718592255058 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark45(-363.55860304669824,-385.8449725630247,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark45(-363.610313346924,-441.2137800132121,100.0 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark45(-363.6387827373136,-387.73428916364225,4.952328938745154 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark45(-363.9719152847842,-425.4005029603504,30.8836144035331 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark45(-364.0136400299293,-383.97893559231204,42.50637391324048 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark45(-364.2288794982052,-409.05193435706633,98.90395296805013 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark45(-364.37847462913356,-393.57326441357884,88.28097793690564 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark45(-364.49140220632455,-384.3974063482791,31.16491659887201 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark45(-364.6632580945425,-409.77309991504467,23.585318863028547 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark45(-364.7174486286666,-437.23812806711453,2.5044324641589526 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark45(-364.7267706768922,-392.26220321828976,21.811909206876663 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark45(-364.84833672514986,-392.45744531423543,87.52105594914451 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark45(-364.8584053919292,-385.78214278687074,25.179258320959462 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark45(-364.8893680345427,-440.8417323558702,100.0 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark45(-364.95846923906424,-474.2774505116482,17.02849873862104 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark45(-365.07052759761024,-393.709877782979,69.22609443514321 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark45(-365.1075260621632,-388.192052061923,66.0133617272848 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark45(-365.1511756026687,-416.92984371340134,100.0 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark45(-365.2742053342177,-403.42529506007645,90.15866369612456 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark45(-365.30812630326426,-398.7368479164559,18.808006772580413 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark45(-365.3256512884996,-399.1502241296689,36.36778409203839 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark45(-365.4739437282979,-409.88273372598894,20.560969650530012 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark45(-365.5715761892228,-406.5489071327627,53.26511067398587 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark45(-365.9498844085803,-392.6956346963343,84.42171819104588 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark45(-365.98104567342614,-387.3045900385993,100.0 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark45(-366.06177165328893,-432.87988592355185,36.75914079491389 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark45(-366.27201964331385,-398.753637491533,8.881784197001252E-16 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark45(-366.3789766028746,-392.4228417621034,22.51478338008191 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark45(-366.55557501121973,-500.68152475096963,52.26521577222263 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark45(-366.6772516603848,-383.0794349034621,92.05230962468866 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark45(-366.7060031070991,-390.634785224727,84.96826140756468 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark45(-366.8155767552976,-424.8166360929452,88.85653985402232 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark45(-366.88830259237943,-380.6773964922387,75.28742028802327 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark45(-366.95295476931386,-393.3105727881145,67.41092890560012 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark45(-367.36882272288403,-420.13572997043167,67.35267339436965 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark45(-367.4550003548737,-489.29473075372,92.88194167746286 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark45(-367.6414206951034,-385.88684389176484,94.5388473679284 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark45(-367.749350022677,-466.5824870133129,100.0 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark45(-367.77548065663376,-474.2323301712336,54.624271577389806 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark45(-367.9767397577367,-401.3552974248339,100.0 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark45(-368.15030208059613,-409.3776468841644,55.32678069591961 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark45(-368.1820656934304,-381.7541154075919,25.94314174779602 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark45(-368.44466568669003,-386.8829161200517,100.0 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark45(-368.6738985931388,-407.76371891805707,46.00864685666622 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark45(-368.71193387760127,-383.48149709669906,20.140305855785343 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark45(-368.75528714861326,-385.5329124301277,49.925056812168066 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark45(-368.8421813620839,-405.8621451221754,54.662673723198225 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark45(-368.8761302260778,-407.6340090359416,26.91916843188673 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark45(-369.2617807084735,-445.06639304269856,41.33117066179909 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark45(-369.2694757730698,-395.30523388559936,56.58158987345519 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark45(-369.3106289438878,-403.5790215539923,83.07600987797687 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark45(-369.5389238267763,-436.39798277902037,46.95843396386127 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark45(-369.54985227879774,-437.4898369381979,55.28547100279019 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark45(-369.6669682603161,-378.9212104335143,100.0 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark45(-369.6820628559908,-463.4318537437169,100.0 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark45(-369.69139149905664,-388.5419794467251,100.0 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark45(-369.69268526827216,-388.80318180924667,37.013178397137324 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark45(-369.7167879614845,-405.6111264401624,22.881528508200958 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark45(-369.91205971834046,-384.6481093408388,100.0 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark45(-369.9420436191593,-411.4431951120874,38.38725066605758 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark45(-369.9714716566779,-378.56950046935896,100.0 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark45(-370.3094610347451,-387.50810595939384,97.95179926126445 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark45(-370.34657237954735,-409.92795780819506,84.91829788823406 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark45(-370.62036913341404,-398.65787886746375,33.652659157523686 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark45(-370.7502408263144,-406.15617360020224,67.18780096937309 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark45(-370.7917221733148,-396.20737395951613,70.93823516821732 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark45(-370.8140814722069,-377.28807232396827,43.07966953292393 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark45(-370.84761784551745,-417.05514538434926,19.35106291383471 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark45(-371.4084954216003,-415.6716248173839,52.81941530383111 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark45(-371.51130651122,-397.4606081454697,94.97291001726816 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark45(-371.53187312390986,-433.50751691118666,75.67069593416042 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark45(-371.5319397803758,-424.5457310234252,62.81694429561898 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark45(-371.6065221278611,-418.86623391778346,100.0 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark45(-371.6359663945121,-375.9910199172845,77.7406346361866 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark45(-371.7343120227041,-434.98865568593095,60.74057837476326 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark45(-371.7354426675747,-407.12785384954276,62.439845458392796 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark45(-371.78728204763433,-418.46491849605405,23.46076315185421 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark45(-371.8941960724383,-389.87571588141043,95.84011609275024 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark45(-371.95684540845525,-419.5095127218105,81.78752018736495 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark45(-372.1108325136695,-408.358659353365,57.967798335193805 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark45(-372.2444761898466,-381.5040075533707,80.38617153762002 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark45(-372.3195510153156,-374.0344069536406,75.2905415628515 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark45(-372.4175755971421,-386.3695638684989,17.14677521910943 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark45(-372.4760613227833,-406.9454581191541,42.54756504220035 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark45(-372.9340015839194,-389.40500690194153,100.0 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark45(-372.9770921678011,-410.81357930149835,69.56238538585143 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark45(-373.08592818549835,-419.9297327023594,69.30096634638178 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark45(-373.2433656267469,-384.98117003859375,59.48511715828795 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark45(-373.42789343201173,-381.3960077521966,54.116165547827734 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark45(-373.46574360727607,-397.012251041413,98.2280483001812 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark45(-373.48097764358465,-395.79032091661696,54.08833412116854 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark45(-373.5600467340865,-456.17201477304735,73.77937342512519 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark45(-373.56289696876985,-395.44714476370376,91.37805601119543 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark45(-373.7444845782118,-377.8794438837444,2.7610820422297166 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark45(-373.74572733834685,-380.16306197860314,74.99580131800923 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark45(-374.07776484591056,-385.38210814040275,38.469469857605276 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark45(-374.2099607130053,-420.91539649778207,7.554502883210091 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark45(-374.25064013869314,-413.8194498590505,88.13135559587147 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark45(-374.35373592198545,-450.3529079837235,17.27374313352928 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark45(-374.39828972557336,-416.3719333713136,77.19198689723811 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark45(-374.68208521321634,-377.53175447316016,0.8259537486008668 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark45(-374.71736508299927,-382.55745103844856,55.93436862422806 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark45(-374.7958122106737,-418.7670418405496,45.00708229030755 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark45(-374.947637827172,-381.6141533575814,31.029272961271033 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark45(-375.2876327628624,-372.48643717983896,7.823797503068988 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark45(-375.372058640152,-375.80090508782615,100.0 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark45(-375.37618906708946,-377.4073079893797,58.443382654842395 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark45(-375.7012603881114,-375.57942031399153,100.0 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark45(-376.01861183431316,-422.61368000238326,34.27490310589957 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark45(-376.1321219814723,-407.14959302913707,29.567625306439993 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark45(-376.22577931394085,-383.9324097063443,0.5743995827443058 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark45(-376.39303596588906,-426.9402028597489,67.12103837791511 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark45(-376.4373198743436,-411.3167963469169,35.408457802356686 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark45(-376.52783352723816,-378.5413945297242,36.96927251896358 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark45(-376.8140581211121,-402.3351058523905,55.778529212251186 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark45(-376.8482174796477,-385.13892954603654,99.10874186980215 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark45(-376.90908822375934,-399.3159270771706,2.6808988475896456 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark45(-377.0311151394527,-415.40910373434957,33.42875475815545 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark45(-377.2017423227201,-387.5742959450805,94.17288821049036 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark45(-377.28977933287746,-372.94645197594224,100.0 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark45(-377.44416085782444,-442.9570091563122,0.3172741334404492 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark45(-377.48949408570024,-371.96225842023466,100.0 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark45(-377.8035718092535,-374.7111794259133,100.0 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark45(-377.87655649829617,-428.89246750375446,26.238413050197522 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark45(-378.0738227369119,-387.69014507926755,74.72899864839718 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark45(-378.1705828005846,-416.9563335853603,100.0 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark45(-378.2144240108162,-375.26355207441486,39.89244899581314 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark45(-378.2732933599858,-392.6972104305736,2.6847224279576523 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark45(-378.29517842784276,-374.5783383584294,64.33051006372787 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark45(-378.39612179875616,-376.3449073966222,88.35790732354212 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark45(-378.4282999077709,-393.31337158077463,17.988628709436668 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark45(-378.4795050114778,-401.8714981836011,46.91850375473186 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark45(-378.58237678652637,-464.82193369264223,71.20067730948259 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark45(-378.65506566629216,-372.1322772546109,73.49364753727775 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark45(-378.72931975088056,-386.57589034841084,18.748653501530057 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark45(-379.2808001019509,-421.275109625255,57.71720507709534 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark45(-379.29797499591916,-379.76916566662334,73.11068410553594 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark45(-379.32437227491846,-370.1527410924918,100.0 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark45(-379.36414507801396,-388.0019546080166,61.79464479801956 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark45(-379.4487695278104,-371.7949023971312,19.704756104769842 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark45(-379.47536050137523,-400.93169906012196,14.882136331056458 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark45(-379.47974558199235,-402.13647745625,29.413672526487034 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark45(-379.53930511422396,-384.41261955859835,96.41759870641428 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark45(-379.65282981201887,-376.9202623715602,86.06183522402372 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark45(-379.71832075695283,-413.271728328906,3.0015428854907213 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark45(-379.8409335817935,-417.2754115171016,81.635425900104 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark45(-379.8865504575611,-367.3695030319201,56.2483744370046 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark45(-379.91456361801005,-403.42957979067484,49.651667712459584 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark45(-380.16647068058467,-369.47927704451644,23.212800977530662 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark45(-380.3798309509561,-429.32360008430885,2.714788210011317 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark45(-380.3844430968401,-387.2938361348044,10.876116126637257 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark45(-380.39625742051186,-369.6813047131741,23.409683535801435 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark45(-380.6107430743415,-436.3363255032463,48.02567343447282 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark45(-380.6406153731449,-373.91432293069386,53.42839069923278 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark45(-380.75557573492904,-372.45573201309577,100.0 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark45(-380.7870057649781,-379.3878979450176,46.34904707344026 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark45(-380.80000496979,-441.7385786015734,15.975440292328202 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark45(-380.8250923511617,-420.58329919569167,67.40228806051945 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark45(-381.15481997978037,-398.7473039042296,17.23114455367221 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark45(-381.2135510013462,-373.41102209740455,74.88987921399475 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark45(-381.4586174231991,-428.2028889080153,55.5744560898994 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark45(-381.6170133963415,-408.6812673777955,16.907844953558524 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark45(-381.6521264138515,-364.79290587834817,90.13881340383888 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark45(-381.9331942013008,-440.85447036520276,62.96809159466349 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark45(-381.9562287475114,-439.4055081323173,99.49095638251734 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark45(-381.99046256404995,-382.34415751758286,34.931212136627806 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark45(-382.3023443603467,-410.2265331724829,52.80043795885575 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark45(-382.38804144978064,-373.4740520429536,18.921426171838675 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark45(-382.5908497778212,-383.1416040704147,92.08197350470004 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark45(-382.61687304296004,-381.0439536424191,28.028990243244124 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark45(-382.6276501688048,-363.4484395750842,100.0 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark45(-382.85778684289295,-369.48859988289024,71.00495188959485 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark45(-382.92543830594695,-370.9865866254584,99.9453350988633 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark45(-382.94090612983115,-376.0703535415816,68.75464021159996 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark45(-383.09583879367756,-373.3490024363522,21.288540244529017 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark45(-383.1020078425148,-381.27478467165895,80.62237721364642 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark45(-383.19298793426117,-392.89110506961987,65.0271142780336 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark45(-383.2845471007583,-383.5491742282335,64.99060936500635 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark45(-383.76526492388234,-364.4098039985284,64.60286052505873 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark45(-384.3346293475946,-368.7045251342757,97.2427248458491 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark45(-384.3647707026465,-396.1331667837833,95.30871185747026 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark45(-384.6929507034112,-437.9450199767281,6.9947903717181426 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark45(-384.8011866051556,-449.11620771265837,66.21618032257018 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark45(-384.8991937899652,-405.99483001818254,7.365049848787805 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark45(-384.9481432449809,-441.1728319497211,67.9451194162923 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark45(-385.06804048125423,-382.78382185551413,27.646355546896444 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark45(-385.13382424326653,-400.27424737124056,78.84157142928984 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark45(-385.2100493158797,-402.00440890559986,35.472731431212196 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark45(-385.3028141342879,-405.44795568543,100.0 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark45(-385.748968786514,-370.7812760945172,100.0 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark45(-385.79759151320104,-429.74917261127104,100.0 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark45(-385.8676919861132,-426.8054209630118,64.79491776650002 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark45(-385.8695865325324,-369.9253122445222,21.925222420226362 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark45(-385.8735143208111,-361.67089474294784,90.21511749252414 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark45(-386.02123877421,-419.92022506724174,26.247687476672127 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark45(-386.1763669277399,-361.48303379015215,67.11206754085521 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark45(-386.3017037054088,-368.03012205730727,100.0 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark45(-386.3402477342952,-378.7300043402628,48.661446865412415 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark45(-386.36547867919256,-370.08728437739273,40.94227334642028 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark45(-386.5770100341799,-413.4916297660283,9.059972542205344 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark45(-386.6369519037574,-413.3065683737036,6.831770323236114 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark45(-386.87367300809456,-366.01990751516956,100.0 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark45(-387.03327835117335,-372.39023728300367,77.00864935848654 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark45(-3.871274980569991E-9,-774.4117210119923,0.0 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark45(-387.1820293276558,-375.35571938903024,19.138965429131943 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark45(-387.21093280549593,-376.46414109252197,75.02792032238204 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark45(-387.33086293884867,-388.54694169190856,88.64997331952483 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark45(-387.38008841788434,-369.4860229986716,39.52153719413121 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark45(-387.4353366307934,-361.0467705312843,99.61935899191519 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark45(-387.4778834432314,-391.21624961913125,8.71179603359353 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark45(-387.95384260398924,-390.4712332967522,69.59055723473756 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark45(-388.30115959573214,-365.66052258228973,13.367353485726408 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark45(-388.321023526515,-384.38224688000474,57.59217135645973 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark45(-388.39702657997316,-367.3906216608235,19.101835683771682 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark45(-388.5812028565206,-358.6333668206047,29.359348202235125 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark45(-388.8550170695503,-454.02430387354144,88.8809942640384 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark45(-389.11896947385236,-373.01671605312737,13.247157402566302 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark45(-389.1810049882082,-370.2868479768399,31.18948579097409 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark45(-389.2503123918398,-398.9882473709214,15.391216071908318 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark45(-389.4695119875443,-356.8468568903018,32.75217503038613 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark45(-389.5107722946983,-390.2510932295956,61.45258264364736 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark45(-389.6090183724031,-368.2877382757696,89.71563492056964 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark45(-389.61632350365403,-412.45164024828125,56.269531045019676 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark45(-389.6426249218526,-413.3871485037258,8.369881720998777 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark45(-389.7271630411069,-383.31700302998775,54.40107165777687 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark45(-389.7865456197151,-371.6254101532521,56.177010615584294 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark45(-389.8571362209502,-384.54814626363725,18.072834905900862 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark45(-389.9672908128218,-356.25407289052106,2.196823592210791 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark45(-390.0559354326656,-408.1784525396507,84.97145576710741 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark45(-390.15614067962656,-370.26329513492624,55.86195522735812 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark45(-390.30050821628345,-364.7834412685789,98.13655406384929 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark45(-390.3201536986587,-374.76602624762626,73.47484602223736 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark45(-390.3810711232348,-362.4010862355936,90.84928939494887 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark45(-390.6315637848851,-363.5460429205318,89.65036332814475 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark45(-390.66426670390115,-390.6190333221057,46.40231481945912 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark45(-390.75720833861413,-368.86894532367165,19.752721084205092 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark45(-390.7951022295536,-356.3651215416707,94.11119956920106 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark45(-391.0671618855568,-364.2997771090099,85.83708138396163 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark45(-391.18694968346637,-375.39088605979055,100.0 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark45(-391.22169527922654,-361.15183458642844,100.0 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark45(-391.7053777966959,-425.3198997942474,86.09523910293731 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark45(-391.8192704976975,-371.2999400566313,69.8494753309702 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark45(-392.00660360026995,-359.20431567820356,100.0 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark45(-392.1048573056677,-354.7119506806881,5.710661490799879 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark45(-392.1861348376355,-366.59905950635846,13.507178271611124 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark45(-392.3564637159523,-384.07551228762634,5.1490888281250164 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark45(-392.45973447647054,-394.78116926993766,100.0 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark45(-392.5726544066495,-360.6295257697484,31.52111159974487 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark45(-392.64790834634044,-406.53301559852633,100.0 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark45(-392.72447774634253,-444.84604833163115,43.81154149938234 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark45(-392.792401563994,-430.9481584907488,55.48400257325466 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark45(-392.9001936146839,-397.0352852548101,53.0749348195653 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark45(-393.0069987472895,-369.0687391512216,68.73335427793327 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark45(-393.05185471743624,-402.6461397529949,12.182258275330701 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark45(-393.1471444198377,-378.42020715625705,24.185229467149895 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark45(-393.2862815715555,-432.2996386101722,19.23934749532326 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark45(-393.54464813658535,-354.2893606367874,97.16648808633605 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark45(-393.7083758978334,-453.56492775873585,60.145241404210765 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark45(-394.0082476224201,-354.70713185396346,32.90174543441054 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark45(-394.01093032169814,-380.1008984653168,100.0 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark45(-394.0259394362838,-360.3090090524312,1.6225646554449042 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark45(-394.06292828627807,-417.29534889162454,99.53252908661156 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark45(-394.4994048173031,-402.0642253805331,65.02903151750255 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark45(-394.56861013330433,-402.8609941722029,11.071189044542606 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark45(-394.7350449412227,-378.3255047568718,59.74976711319168 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark45(-394.8343776463178,-362.5049883024209,13.978475298363136 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark45(-395.0883103163311,-354.3156386145604,100.0 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark45(-395.1153964897837,-389.44721971594095,100.0 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark45(-395.27890661760784,-399.0303088039891,81.41480959060982 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark45(-395.32724534899336,-395.8357398114818,43.3096600737195 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark45(-395.49520901934534,-363.564612533028,35.12103793639528 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark45(-395.93531101685835,-350.9649789895318,62.736934105267764 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark45(-395.97616853163294,-389.2260151086756,88.81572454533992 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark45(-396.0645572612414,-427.8806656081678,84.30167593040571 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark45(-396.0722797061275,-356.56842229018974,58.235089569890306 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark45(-396.138047282631,-353.29352836421003,85.07017621741883 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark45(-396.20893895364804,-383.6522200744912,100.0 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark45(-396.90624317642346,-391.52107783803643,62.861783500805075 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark45(-397.13971742731326,-363.8496444718575,0.2619167044498454 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark45(-397.3657607107172,-356.0087268273237,0.7450181827651363 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark45(-397.3782660254014,-451.11615688362605,100.0 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark45(-397.39713785040027,-391.01675095848447,31.178203879305755 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark45(-397.56043733152853,-362.8377996055347,100.0 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark45(-397.6832419459851,-435.99894639032993,10.182990362882066 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark45(-397.70977054234925,-434.53042892064434,13.168912712728925 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark45(-397.8352257256782,-375.1133419029263,29.352398687820767 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark45(-397.8626385510158,-390.1740956733268,98.40198650175469 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark45(-397.9636408372028,-358.76449131581546,100.0 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark45(-398.0204257749573,-367.03338895707475,84.32569169318506 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark45(-398.03594955171036,-365.79379013528734,28.131708733586066 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark45(-398.1613537936857,-374.2574857509318,37.94438052719574 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark45(-398.26689196113506,-354.4378199377773,55.28895497628062 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark45(-398.31633031081293,-359.91653346622917,44.627395248193096 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark45(-398.39134012273064,-355.3836241043615,65.43794013348851 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark45(-398.43853916470266,-360.6336133798677,3.0402770610130005 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark45(-398.47256014829037,-401.1301541330324,15.573884518080263 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark45(-398.75444833147037,-357.7281340875824,90.80833258810947 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark45(-398.9080797049261,-364.99179720378567,72.46246730858786 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark45(-398.9655838105118,-352.975035627602,38.27247989119769 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark45(-399.0715419421447,-426.4332874419773,10.319636725005438 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark45(-399.1189845388693,-402.65654145807946,70.71180321176385 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark45(-399.14470509564234,-348.5062711235763,91.63179525479296 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark45(-399.22093851669297,-393.3204222918662,38.6597671819444 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark45(-399.37165311881523,-400.20014605007253,100.0 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark45(-399.48475971693387,-408.1660546333333,42.11173533364952 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark45(-399.6741130367824,-424.8049918657352,20.79675916917634 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark45(-399.9406445862326,-389.3676763238282,9.467206031687624 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark45(-400.1915645404168,-360.6590598786458,7.503734877372027 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark45(-400.31689104319764,-363.20864483603265,82.38783826030172 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark45(-400.3927583922323,-423.2301696604048,100.0 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark45(-400.5092564516141,-368.09133794756633,95.50906299180724 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark45(-400.5705746626373,-369.9990891307927,12.524478196939754 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark45(-400.60712338763943,-360.8143145979168,62.83655074625014 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark45(-400.88690161361006,-358.6587331359917,69.64541884160778 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark45(-400.9631078474104,-351.45620895157566,18.365553804605582 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark45(-401.073938403641,-417.71715112479234,97.63274118600225 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark45(-401.0749589696087,-405.4355056353098,11.388677554438203 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark45(-401.0777259739349,-359.4167536238073,25.87922700200862 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark45(-401.17800242126486,-378.6677448841144,39.50893482345816 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark45(-401.19898100978327,-362.54698461209586,59.78363720015497 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark45(-401.54348425415486,-365.24620677692326,80.12250374632328 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark45(-401.68949161062574,-358.7670691858834,98.19010841315182 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark45(-401.80169735174104,-373.1308628183767,0.027170165853050432 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark45(-401.93892427097984,-356.627807947971,57.531573636254365 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark45(-401.9666051866109,-388.5587039699264,100.0 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark45(-402.1129979278391,-345.30548007620365,0.3066113610501304 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark45(-402.15473007078924,-355.7498343343147,66.37644707408532 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark45(-402.1843724631158,-349.5660377775593,16.416927144982424 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark45(-402.2456867416015,-478.1591222033914,100.0 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark45(-402.3695451507551,-382.0072549088318,7.219223502294085 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark45(-402.56971070259635,-368.95176866250927,100.0 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark45(-402.5865441858424,-347.827363231415,92.08248692756897 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark45(-402.9692556303935,-482.7682034699858,26.102625778064066 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark45(-403.00085350609737,-365.8578594536021,10.176310909911379 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark45(-403.00720355821784,-400.9680667980738,84.25234045468079 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark45(-403.2560793667869,-381.56511794918777,94.39967289201277 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark45(-403.31839618316144,-399.3895418392857,89.03311953044971 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark45(-403.3310211586641,-385.32227828931667,85.05999504942285 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark45(-403.37562906145683,-343.75642705936656,33.738719806971204 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark45(-403.5927017376598,-387.3382537583449,4.820453223285853 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark45(-403.61302453075433,-348.06374615832544,32.58784714446185 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark45(-403.8472181167746,-374.8735753901519,10.359325592121678 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark45(-403.88230552746126,-385.94478476475126,100.0 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark45(-403.92063643826606,-349.3543462874849,13.309879355226386 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark45(-404.069486878097,-348.1663042530654,83.19028843278386 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark45(-404.1968753445089,-347.26310699724684,30.042376817604776 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark45(-404.2796789376358,-353.41200781076884,85.91851789659142 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark45(-404.28716618085576,-393.2477869266201,89.41670049334192 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark45(-404.29058619367004,-349.0954451680344,80.26636772181689 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark45(-404.4182204420393,-360.7729947204011,51.307471365811296 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark45(-404.42261893613045,-386.83659321511016,66.21389539795837 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark45(-404.4810549113264,-344.6741394508965,90.117364830208 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark45(-404.49604163026953,-351.5944790017086,44.43758252433051 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark45(-404.5213794437246,-354.0867130719351,43.980024456088984 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark45(-404.81966899622205,-364.0912555043091,93.72647659224748 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark45(-404.86875703142465,-381.7211434804042,11.242751084241135 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark45(-404.94031163107303,-344.2604940148992,23.692563599078852 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark45(-405.10080125080486,-344.8357741100665,26.1251939708703 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark45(-405.1826324391269,-359.1689126008856,11.42927464682569 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark45(-405.3073567408522,-445.9938732656609,45.886173289595234 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark45(40.573602670906695,-834.1482860026817,0 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark45(-405.79933393736906,-341.02441535202206,35.20229753133165 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark45(-405.82791251612394,-369.15668964631107,60.21601808761034 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark45(-405.8340568918941,-342.21103257547156,29.75441523489627 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark45(-405.9183218717372,-366.4966460190666,43.748846991021225 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark45(-406.1991417235199,-344.25190435968955,3.280136932874626 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark45(-406.2369336158107,-359.1051280243611,4.492788066703753 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark45(-406.31164300234735,-372.3789801702257,68.38134049794792 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark45(-406.31591087665896,-369.86014655940727,100.0 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark45(-406.54897466552995,-371.0423247159104,38.15654950225817 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark45(-406.64912491843637,-362.4419342866013,22.67544774384021 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark45(-406.7684619566564,-344.2879000606759,8.268278806168524 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark45(-406.77540605568527,-350.58971484343107,81.83236075469956 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark45(-406.8727866415295,-368.47005738300805,83.10933056148039 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark45(-407.30258942780733,-406.09154528538784,74.61061529212029 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark45(-407.41384318607015,-362.308518205287,65.52302221769583 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark45(-407.61310718492325,-398.49638829771544,92.3974680807988 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark45(-407.79994058944686,-359.61381527028755,7.800532909847746 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark45(-407.85827202459905,-353.42665195908756,96.48483093665362 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark45(-407.99352882978235,-416.71830357086685,62.73720862928823 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark45(-408.1628875038831,-338.12679075865753,6.287050626070865 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark45(-408.42020220549665,-347.8274257436184,98.2386533432666 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark45(-408.4301425643137,-344.7638826857325,100.0 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark45(-408.4345298228904,-392.97521452366124,38.113376452993094 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark45(-408.6574009379805,-338.8593449374063,80.85818322329791 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark45(-408.6940270134056,-343.69542871514284,12.656863431111475 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark45(-408.74068770736636,-349.8592311303121,90.24596657944477 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark45(-408.8739556669146,-345.53676538275926,39.606999580912344 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark45(-409.0156394485457,-351.8119291402145,100.0 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark45(-409.017925886856,-370.8655434752513,12.41195566838664 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark45(-409.2518889652823,-339.94386388272045,41.70767047169386 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark45(-409.32461768948474,-340.8460970006886,22.26964886371401 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark45(-409.407780418595,-354.43546118284763,16.90182084869214 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark45(-409.4440735881583,-338.61834745164055,23.10366108698632 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark45(-409.51902622051864,-424.1590142035215,100.0 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark45(-409.57033245230195,-369.8729554065447,20.552469834085713 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark45(-409.97622552316886,-354.60830657703787,88.13768259757623 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark45(-410.080571725613,-379.64440675924175,65.23103704032661 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark45(-410.096907507958,-347.4336614642559,21.663016853776924 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark45(-410.3715374023391,-346.3792961252938,4.474364604236939 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark45(-410.44776345349646,-349.2861578308343,17.65338049874974 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark45(-410.6132553237542,-406.6847559288183,47.65014021010833 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark45(-410.81648651287173,-345.26567312345776,17.188975319187477 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark45(-411.2826400713916,-345.691187881753,27.405506610115808 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark45(-411.3643312064627,-359.0350536386258,31.78574028930825 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark45(-411.43100724650475,-362.5927395717136,30.40113603996275 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark45(-411.5168453368725,-334.9015674149921,69.52238506017926 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark45(-411.60916067651004,-402.1724403571434,10.477916606482097 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark45(-411.84854379852084,-338.77531465528176,43.55952866328469 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark45(-412.23181292252184,-351.2238423385809,20.593502390794157 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark45(-412.25258031173036,-351.44676233428396,100.0 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark45(-412.37987925346306,-372.0894522620552,12.466924611364078 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark45(-412.7756486511159,-344.0222671384819,47.925566633871 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark45(-413.1732704537916,-358.9772523532087,43.30031004216383 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark45(-413.176861314862,-448.6712395082373,5.502751376303223 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark45(-413.4635063651894,-346.4491161553166,54.80280207274802 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark45(-413.75584667375324,-351.2358795348239,34.78706325923065 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark45(-414.04457152849227,-339.5842027875919,100.0 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark45(-414.10785308816594,-338.19222693476206,89.72906374164918 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark45(-414.1426156037429,-343.04491904959866,51.512061477856065 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark45(-414.2209184012639,-388.62848131530757,76.63316974074544 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark45(-414.2658958394221,-373.5214162443811,100.0 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark45(-414.418083260625,-352.4171296714338,20.348983330114635 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark45(-414.49351851003985,-354.2296695498956,100.0 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark45(-414.57447417575713,-341.959240015327,87.98550747316403 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark45(-414.6073077195057,-339.52838043143254,12.862658934361448 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark45(-414.6193375694447,-370.28476605906485,93.56232899963803 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark45(-414.82428555366096,-421.137051745754,2.442316993495524 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark45(-414.91100413573776,-340.2277205668858,100.0 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark45(-414.9649510646963,-339.33549324047647,98.26709250361995 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark45(-414.9868560058842,-336.191210586939,44.52124149341415 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark45(-415.03510408322484,-331.42260586984384,36.61650735794191 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark45(-415.1146434616468,-386.12794751473564,70.32205657734244 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark45(-415.137473235215,-402.3817743584751,65.02701254023015 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark45(-415.16537160038104,-340.56543818241767,100.0 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark45(-415.17772162045594,-356.1256975000342,100.0 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark45(-415.39027064666976,-379.6344545262611,100.0 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark45(-415.41039349165555,-339.7138220630749,92.37952574661108 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark45(-415.4732792647973,-353.00756529700243,38.86479334081784 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark45(-415.6428969777562,-385.1318640095575,73.73495121279046 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark45(-415.7982628780666,-331.9290059986243,100.0 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark45(-415.838055040413,-380.6531198711792,87.15171643064735 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark45(-415.8908886086315,-406.59719043615723,100.0 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark45(-415.97733345455697,-334.7640502320838,36.198213198508256 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark45(-416.01125478061033,-397.3558243284687,100.0 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark45(-416.1673669115414,-367.59042559325377,20.667582090173113 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark45(-416.3842860004825,-343.0954181862098,53.87082495002275 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark45(-416.41138815273104,-334.31251577878015,100.0 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark45(-416.43619265226624,-355.06598722971967,64.79212036906935 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark45(-416.5690863146184,-339.6232154009345,5.87858575651326 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark45(-416.9479141987765,-333.2689196556812,57.589317845597776 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark45(-417.0366770442822,-390.41911597373075,50.35155542437553 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark45(-417.04324569876815,-345.2490390011482,100.0 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark45(-417.05812190840817,-358.4278035402594,39.5654878500861 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark45(-417.0599582829144,-350.0389441359475,80.18042892561735 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark45(-417.080269560252,-371.71865391403844,90.85612233712251 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark45(-417.18924397429686,-343.12813158622015,12.071809733696654 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark45(-417.195630983715,-330.88772686271506,63.114163764512796 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark45(-417.31885189420757,-337.0185424183485,17.29716864734516 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark45(-417.4296645908112,-331.7406791191256,75.47126003856755 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark45(-417.4363373070258,-367.09500679585835,14.970361661522773 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark45(-417.7948238866716,-335.35186685610313,30.101549614617284 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark45(-417.8022008952536,-367.01221718242147,42.33372703235074 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark45(-417.9179099929165,-352.1966398900505,83.56952052928145 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark45(-418.08160756982056,-361.39662806081265,9.689862171542572 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark45(-418.14383254675647,-374.8710550877996,100.0 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark45(-418.23039874517366,-386.8529240721032,100.0 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark45(-418.34017157690744,-351.7258479824633,57.335606356710656 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark45(-418.3403220337789,-363.1484255912311,40.02237960457006 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark45(-418.4342147043432,-332.75917941326014,3.431133975057051 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark45(-418.450441902061,-341.74578782611826,73.58520630329983 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark45(-418.5067662012663,-336.51714142924754,62.11454820015854 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark45(-418.563907279711,-358.4884019587123,95.30871904250964 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark45(-418.58855946418925,-327.62112382964824,96.72349188774919 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark45(-418.6023058356458,-333.53582354189183,49.051020510196565 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark45(-418.68095681846347,-338.5971981239985,100.0 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark45(-418.8008971308655,-358.01709810842664,16.505987126616347 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark45(-418.81378841337954,-347.9252930267508,24.305425034756837 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark45(-418.8544534455291,-330.5512831620783,100.0 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark45(-418.92799718890643,-330.50745303497,8.668361283697323 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark45(-419.02000747394857,-417.59196177680764,54.24324689660867 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark45(-419.0414656673691,-382.0468778949492,28.667657505109048 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark45(-419.1245862979684,-361.1233944273023,55.858923753629284 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark45(-419.223551584099,-328.28912046770716,95.86819235632765 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark45(-419.2392777617848,-336.2670576268993,48.006131131457266 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark45(-419.44752053377726,-331.120790735489,94.58886610896579 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark45(-419.4987146155412,-358.8698200413701,93.59299181493083 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark45(-419.5349953091357,-339.9979152088076,83.40972053824184 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark45(-419.84501564882237,-340.19610059593106,35.94526031609243 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark45(-419.9885919207709,-347.5618164064773,15.033503576785842 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark45(-420.01320792036967,-410.3354302460056,87.58987555430744 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark45(-420.1411945188221,-372.19060189960726,100.0 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark45(-420.32065734685847,-403.04976746361325,100.0 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark45(-420.3219020637032,-334.1678046397477,5.2524892348307475 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark45(-420.3817558347069,-376.56526906579234,100.0 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark45(-420.4048547511643,-386.836897096491,50.762598667215315 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark45(-420.4260994237326,-357.4387614075813,38.15045230672837 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark45(-420.5275984434392,-340.52791832806224,2.979609154071442 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark45(-420.57112361187296,-354.8223461853854,100.0 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark45(-420.9494995062857,-343.6832373245007,89.96612387388603 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark45(-421.01294604807856,-427.59894699252084,21.71428912353182 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark45(-421.0311842440449,-355.29469974929316,37.19871866834322 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark45(-421.1141777470509,-326.9936357076591,76.40946820735823 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark45(-421.2336532564349,-368.32593692734787,1.8270775447210248 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark45(-421.28614091995405,-366.0092715288107,57.60622364045793 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark45(-421.3326290092689,-360.6856547898011,100.0 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark45(-421.4735051166129,-392.15036929284645,16.441215914269037 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark45(-421.59839932109486,-341.36552704040486,54.75760017303958 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark45(-421.7013625362044,-370.31601385668665,53.4971732613912 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark45(-421.8389250168592,-336.11098560786587,100.0 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark45(-421.8708786595802,-367.53281519965077,47.300904945001776 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark45(-422.05276555965105,-344.36836496855074,41.15935635286746 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark45(-422.0571019558121,-357.4664073928925,69.49449290236487 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark45(-422.07587347523605,-342.4165425464409,40.86280365289733 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark45(-422.25474409803365,-339.1460493353139,100.0 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark45(-422.27441730738275,-400.60531924000185,4.495627714003092 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark45(-422.3304113765528,-360.7215393378512,64.60354259880165 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark45(-422.58129786835485,-349.26508704127707,100.0 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark45(-422.61248187891744,-393.07977133353444,84.96228367046234 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark45(-422.7147881086025,-328.21711125943204,10.761798132856555 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark45(-422.71647080138894,-350.91313174263166,15.436809383916113 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark45(-422.83143298211695,-328.33231221183587,4.661783212404612 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark45(-422.9444174954807,-341.9383754138528,34.887855516442926 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark45(-423.14473819004877,-332.80909343701535,64.64717121072917 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark45(-423.1754280327574,-330.578678400916,100.0 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark45(-423.31340781747525,-329.3367333894782,4.687175321185634 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark45(-423.31919353059044,-361.43965707797224,56.13077714049397 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark45(-423.75658133326726,-325.4212610348377,14.28906013771639 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark45(-423.7721332326528,-373.7076191333956,92.39295201604529 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark45(-423.7769798389854,-332.42992396563534,61.17874979972416 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark45(-423.8690796842815,-331.7252458541816,43.81925451194067 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark45(-424.0034668892576,-328.61308946575855,70.01054387850743 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark45(-424.49762229539715,-379.6978459459164,0.5088932841255485 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark45(-424.5123732868857,-339.2364486287138,6.3234039389929535 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark45(-424.52585828777234,-334.8015558858826,35.77790846277878 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark45(-424.5466640234339,-344.97927318542355,32.56518019658401 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark45(-424.58186121577813,-328.8732655664148,48.991702801556926 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark45(-424.58975021907753,-344.8658383068059,4.679103573667646 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark45(-424.81768636628567,-322.9809728562323,38.87572734220757 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark45(-424.9034589268374,-324.2253596890468,77.51297250512715 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark45(-425.0996460220831,-373.4753184805885,81.50117175802404 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark45(-425.2505642650423,-360.84330566017263,73.74306079074398 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark45(-425.3930738854965,-335.27630263794174,32.92373276214764 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark45(-425.63478449757946,-341.9882238783298,14.750346518900216 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark45(-425.6397039025759,-359.7585957691358,27.499266913889812 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark45(-425.96560888733916,-391.73797078167587,36.64775400342876 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark45(-425.9667577658954,-329.21792389615524,84.80231393182126 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark45(-426.0743200219459,-353.875298017633,100.0 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark45(-426.10140807048407,-345.0390252147323,8.262902289951313 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark45(-426.11486994214937,-335.8919692202247,25.00875758724746 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark45(-426.18373683652646,-372.51430096275556,100.0 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark45(-426.36257886255794,-328.1753199753605,16.216867250408967 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark45(-426.5375687866449,-322.40171690487705,78.211523504566 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark45(-426.70927687161185,-356.9749958725221,100.0 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark45(-426.73019667326685,-358.8484983164565,67.68551245301722 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark45(-426.9390246458013,-365.2780958850614,63.05709642912899 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark45(-426.96142590310114,-334.13612822073253,100.0 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark45(-427.07103413414995,-321.4029821165152,70.90454995379568 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark45(-427.0877565164781,-380.1138429923693,18.949316739486363 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark45(-427.1028438523423,-356.9763003075869,99.27917939042206 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark45(-427.12233570850776,-320.29099688998014,26.98670385941979 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark45(-427.18713769273046,-321.4400110926756,70.00753663572942 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark45(-427.48603539870714,-338.11111529831567,18.322372813321337 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark45(-427.6277892692586,-342.8613093334673,54.49175623627167 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark45(-427.8585667990113,-332.0087686485401,73.06499081608466 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark45(-427.964128720235,-402.7349604372271,100.0 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark45(-428.0977159559584,-355.1512649864736,55.38174745371279 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark45(-428.14416121961483,-331.949767624783,100.0 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark45(-428.2056259629246,-355.63948199724484,66.95089224852856 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark45(-428.4736319209694,-351.44506416671095,5.843124077760304 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark45(-428.4889261408276,-321.8777928288675,48.55165639958665 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark45(-429.0089418476317,-377.115027703812,46.66569663213676 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark45(-429.0333190755402,-354.4804074525706,64.30640718014098 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark45(-429.1347985765333,-363.78604902383734,46.01694430347223 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark45(-429.21308233412356,-322.04562931172893,38.12177690277977 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark45(-429.24073608575173,-324.10632036342105,32.08178740796734 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark45(-429.4607990273579,-331.8163904081878,44.77111897538148 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark45(-429.7542730762169,-321.7961347178742,30.22329330101121 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark45(-429.7831416998092,-331.02166995010805,94.27364349100625 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark45(-429.9194992073153,-343.29285650080334,11.117982553283657 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark45(-429.92506723162955,-358.07769454827104,12.030840311580011 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark45(-430.2621699065688,-327.5585153754175,43.5418205637028 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark45(-430.34688545266766,-324.5389084391051,50.6171735632264 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark45(-430.3623193555592,-333.53238807680503,14.024344628088087 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark45(-430.48605598794927,-316.39056704071766,96.15405205030602 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark45(-430.70112977480215,-350.0406118809454,7.2385988442188705 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark45(-430.7916922347123,-367.5209481568982,86.88520324680323 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark45(-430.88678354041133,-339.85783154377145,81.70674931678136 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark45(-430.9170149997562,-360.2096807581877,96.92149677931502 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark45(-430.9448988496365,-339.3892984413063,2.9477152635475363 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark45(-431.10764787513756,-391.08063086510026,75.88261458524187 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark45(-431.3890603882768,-315.5339567035786,3.5680494223076806 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark45(-431.4077625147426,-317.1379813186747,12.083253542808688 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark45(-431.4603512501601,-351.3095763752455,96.28877078679113 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark45(-431.58625030711875,-326.11480470296647,29.447301299897077 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark45(-431.6733003286539,-326.15811955411704,29.600057560974353 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark45(-431.68746369880665,-321.6832683888301,100.0 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark45(-431.7758087851644,-316.04783754038533,54.988045513956564 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark45(-431.8196368721446,-314.81845979579214,16.561868204795147 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark45(-431.86142790321117,-326.83421428791246,100.0 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark45(-431.9940070863848,-372.28779991889337,57.44822052970329 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark45(-432.0465868153402,-316.9222360693183,100.0 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark45(-432.06966907873317,-366.89239824232374,10.963149537750212 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark45(-432.0888286875439,-326.8494053333343,39.69327224624246 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark45(-432.454296616761,-348.7685779227594,11.725794495827728 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark45(-432.6235982041272,-327.07872006859606,24.169439647717653 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark45(-432.6596023723212,-392.9286527474982,56.21398504359064 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark45(-432.8640675645176,-396.6855712425865,100.0 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark45(-433.0991684075384,-354.87702516922997,85.51728054986975 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark45(-433.1060958361948,-343.5945346525951,1.9054321747116205 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark45(-433.18127237192385,-367.9762752922303,80.02171698597718 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark45(-433.1974478633528,-356.60387839106556,76.04469024288608 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark45(-433.47729095161617,-336.67196595489224,0.557722874239758 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark45(-433.580612299278,-320.83187347543225,100.0 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark45(-433.76303930206404,-314.87925035999365,68.94702707825203 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark45(-433.7770255948359,-338.41761236441056,92.94735825340709 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark45(-433.7777672447308,-341.30248861366255,100.0 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark45(-434.06805913111947,-327.96660610160023,79.04456704853914 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark45(-434.0718412039078,-354.586186809751,100.0 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark45(-434.13311159650544,-329.05837369616273,89.06884084483181 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark45(-434.2492134912761,-367.81216039114,30.485803838325495 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark45(-434.3890117115692,-341.04462404967217,3.021082968302636 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark45(-434.4108262777514,-359.51586667643164,46.36769871314087 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark45(-434.50759167542424,-344.23731841736054,64.8483557058878 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark45(-434.66098460454117,-328.22879200060606,100.0 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark45(-434.9830768320908,-313.6441935319626,60.17474323556658 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark45(-435.02272484401107,-316.4349287407791,100.0 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark45(-435.2192954471342,-312.0532903532004,77.05777939191765 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark45(-435.28589920760567,-359.4393497365403,41.77508261273897 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark45(-435.48929294859227,-338.9255832969599,64.26937034940761 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark45(-435.84250021333264,-335.49880264129547,66.25875999286671 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark45(-435.9062284266749,-341.8189395601451,100.0 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark45(-435.9385801898651,-323.00940678274696,91.51401943949963 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark45(-435.9749092192767,-319.5155360140877,51.256779679962705 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark45(-436.13605341854964,-312.27889060858377,58.017088929194244 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark45(-436.2909364299788,-324.6241247317433,81.51774108724382 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark45(-436.81049997814796,-338.99008972004907,86.78734989819728 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark45(-436.8556295477686,-335.80156815039805,43.04849087527424 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark45(-436.8979037313772,-365.8723579550902,100.0 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark45(-436.9107063857242,-383.90100229916396,74.15473370078001 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark45(-436.9261843955591,-347.1961052016038,10.806763115754919 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark45(-437.16381622639227,-323.9117069570136,66.5472072678042 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark45(-437.40012268639435,-328.16612180922266,6.977634343472786 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark45(-437.6182840222034,-330.97374379308553,53.85048236810016 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark45(-437.64521843407357,-324.40421974742287,10.465834523107702 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark45(-437.7421178164861,-325.9228544226282,70.37982087251385 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark45(-437.77164645500636,-342.0986522933177,24.988068388361583 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark45(-437.84334942228026,-326.8936678950852,64.29177222654957 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark45(-437.84755738348963,-332.7756189919063,37.93880979104759 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark45(-437.8895294663526,-314.2462171598452,6.862440595937144 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark45(-437.92319366419537,-315.47893927606816,23.598140416639986 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark45(-438.22371290297093,-317.62617357355924,81.95401340148791 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark45(-438.2642116709161,-360.47928116921406,63.383346358298354 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark45(-438.4398707637138,-337.96351623037066,90.91585750917784 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark45(-438.4549582312938,-340.6607557033384,72.16629664933467 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark45(-438.73551819478666,-315.63794135353675,100.0 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark45(-438.827520232028,-357.79910921936084,54.76672453926136 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark45(-438.8966418698379,-335.77073496745646,59.916372702125074 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark45(-438.8993821603509,-347.62582867373527,72.2498084791518 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark45(-439.2093227583187,-318.42455094002185,77.23540083581378 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark45(-439.35980065887776,-331.0201652096018,96.8334258492576 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark45(-439.51451302195557,-313.0185624255867,41.653914503456846 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark45(-439.5152375041438,-339.8645025616636,0.6420743625392902 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark45(-439.69329851781515,-331.7885852114874,53.03899050593236 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark45(-440.01285969959235,-321.0174813502735,43.39078428374759 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark45(-440.12722045708125,-318.03347233490035,21.33044591567537 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark45(-440.19236863992097,-336.12656787485923,5.346525782211302 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark45(-440.2373933595714,-383.2369950687304,45.427415121305074 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark45(-440.3160354573636,-317.4831716015943,91.20130429918575 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark45(-440.4577441800264,-356.34643109694196,100.0 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark45(-440.51011029907335,-324.1567295589544,50.86105608725745 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark45(-440.5831693999276,-313.984757026607,100.0 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark45(-440.61491173349634,-343.25968091986044,17.488965149273696 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark45(-440.632953488003,-310.2781711788834,34.62710514190405 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark45(-440.8402151873528,-312.89578665918646,50.63720933528768 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark45(-440.91638969472973,-305.5527540840093,53.428508399115145 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark45(-440.9360567247667,-336.0799834547905,79.8944659615199 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark45(-440.98877388813617,-318.14575706618336,34.914846381835886 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark45(-441.24076763603205,-314.16515753808875,9.639050354071003 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark45(-441.4893884904756,-305.16787085051186,74.4542460728614 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark45(-441.629502705162,-375.383682908231,77.93189624946874 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark45(-441.67586269299255,-318.68324559650716,7.259842770458832 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark45(-441.71868238452555,-329.01521295297965,90.93613154345272 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark45(-441.7375854624512,-321.8202683125428,100.0 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark45(-441.8090435075505,-310.05693515435274,53.596443468037705 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark45(-441.91691380277325,-321.0122137643839,41.56747912969868 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark45(-442.01747687789987,-349.4395503925392,100.0 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark45(-442.49377993158896,-318.5715545163467,68.19590952770355 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark45(-442.9157960457771,-345.513758346291,11.748491994523818 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark45(-442.91840326233705,-327.1906024255604,100.0 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark45(-443.2315879973127,-337.4018070007567,73.69240581247162 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark45(-443.51797768407107,-321.0705846659155,76.06221811508726 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark45(-443.5609094054697,-327.00282077698006,100.0 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark45(-443.6911237791636,-406.67850476532334,65.34406283215571 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark45(-443.7604003764991,-313.4343545849153,70.21217541869726 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark45(-444.0279804459001,-335.4222279107688,100.0 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark45(-444.1120082849539,-322.48369064555646,100.0 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark45(-444.13262144971134,-315.14479334830423,37.50259304800315 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark45(-444.1557532379462,-302.0766643172244,8.94854549982746 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark45(-444.32617792952504,-340.8815470778713,59.88691302541426 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark45(-444.3504030316121,-355.99854289499353,77.67564335657869 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark45(-444.61100183267376,-342.4446672862723,11.170193545968914 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark45(-444.66364853377434,-337.4296342278447,10.864399495828977 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark45(-444.7349235064064,-315.3975256849269,27.424749078591958 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark45(-444.9184584373054,-362.4103428455527,27.3827330347672 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark45(-445.07283262342065,-314.8935446071122,7.316055153673844 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark45(-445.17773909452416,-318.19230962839805,85.91914127747856 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark45(-445.22657372627526,-315.442441629693,25.989108568452068 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark45(-445.2381962603087,-302.9946643329792,82.75913754894103 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark45(-445.3145529439613,-368.7916749249673,16.465596048628356 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark45(-445.3698567270099,-314.3720829414074,89.27853111035917 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark45(-445.69759926044253,-315.7112874260021,19.890644084105503 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark45(-445.8969507474325,-320.27932058434175,7.930942557044645 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark45(-445.99926099148286,-338.7595548328203,45.40821344812096 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark45(-446.0896338081367,-335.22958460715085,63.079675228251915 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark45(-446.10602816721035,-334.43315427543644,54.33109547902808 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark45(-446.13953001888314,-313.1249943490547,53.32907458911441 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark45(-446.2998287296324,-373.41704432045157,100.0 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark45(-446.3336363249629,-301.92390401045486,14.41349973895494 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark45(-446.3715499753436,-303.53959278683277,100.0 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark45(-446.4254837483358,-300.2402922464118,58.458469796389785 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark45(-446.44599588534004,-299.7650263824846,71.01158627955084 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark45(-446.6893500175059,-307.37667184774193,100.0 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark45(-446.8236981940204,-306.47786942431844,100.0 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark45(-446.94873460419734,-326.7884989148369,30.886079591893434 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark45(-447.12937190791735,-348.5954701240802,47.839256616214726 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark45(-447.38559246086004,-307.0759649678411,76.6914191178702 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark45(-447.6796116988712,-375.3592377756821,68.62827531070488 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark45(-447.77275466777485,-314.92863287329266,28.93299471890964 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark45(-448.00227430797185,-304.9361651869995,32.46722382860804 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark45(-448.08109046778713,-349.091895318698,56.92959263425169 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark45(-448.1751168840306,-311.5041368305528,46.49305841670321 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark45(-448.4033354005199,-363.07895019254147,60.89693329434979 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark45(-448.5339151084776,-298.54506731846607,66.66135819953612 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark45(-448.58286443135603,-315.0961578349246,100.0 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark45(-448.60580381287747,-360.60949999028657,2.2004544832600743 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark45(-448.8347256246595,-349.58481738641865,76.77281853146755 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark45(-448.9725762576431,-310.9014004085764,12.08953586526303 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark45(-448.97372652487445,-308.50352783805573,39.091257712198086 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark45(-449.2600220776556,-335.7739343145879,56.87459768511502 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark45(-449.2804967890197,-354.89283230990395,67.22004450666526 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark45(-449.42027572438883,-312.6766744064163,47.692364652966745 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark45(-449.51976659187045,-365.32366661790786,26.50136158510486 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark45(-449.7083759581058,-304.0318225854386,100.0 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark45(-449.91531487321396,-369.3036270709436,94.09792726545496 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark45(-450.010145940559,-328.76308880940246,57.6536055478372 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark45(-450.0380261707879,-388.4980929026454,94.4163119197959 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark45(-450.388132972988,-378.80665276448696,26.587342515651116 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark45(-450.4153569270383,-303.42221772391963,100.0 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark45(-450.5211903951916,-296.38943568209686,8.16940605296395 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark45(-450.5477553149678,-302.80393046740147,13.026362266832209 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark45(-450.749745210858,-355.7057143215522,53.19689713160713 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark45(-450.8951516707344,-403.8597682082958,18.08751297033237 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark45(-450.90985186459267,-317.3835864291732,5.745742088234394 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark45(-450.97954040803745,-317.96645401293466,95.29892632157922 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark45(-451.1163863807209,-335.81452781130577,81.1880353106759 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark45(-451.1564135002171,-310.4007685593986,83.43448149332633 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark45(-451.2370782169516,-299.40943501138423,44.72535483163014 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark45(-451.2381949282503,-363.96986479241116,37.7800611013522 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark45(-451.26864836737116,-333.05426757848227,100.0 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark45(-451.48457123535604,-334.3903932919976,61.0520646308197 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark45(-451.57176923387277,-361.9821750883085,60.8546540548779 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark45(-451.5966839867372,-297.0416663889261,100.0 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark45(-451.6883697080077,-329.81214554036285,21.599789912633064 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark45(-451.9740276407969,-313.26913832700717,59.71720776741384 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark45(-452.24985604381556,-300.7018754009327,32.49971606744995 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark45(-452.28303543727947,-354.68289629257566,100.0 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark45(-452.5257514354861,-332.4996613416622,31.158092935861532 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark45(-452.53500178150165,-310.80607212013865,51.97684663987573 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark45(-452.7937016285622,-299.08500388231937,2.5226657489504873 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark45(-453.0094171699844,-347.81846318263393,21.196409395682792 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark45(-453.2352047081926,-294.4484669497812,100.0 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark45(-453.3407515902578,-315.99875867737893,100.0 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark45(-453.3749933105689,-297.88017668123285,71.22922817869889 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark45(-453.48384466556263,-328.68246391261823,86.81231797277133 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark45(-453.56058136332797,-318.06639646603173,93.2944412455231 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark45(-453.59748911982285,-358.01071016585314,97.5588257429358 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark45(-453.6920960285245,-377.7010710775414,59.20047078647298 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark45(-453.74686864620554,-346.76529461849793,9.98853675826378 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark45(-453.76829476934375,-369.07028561461976,100.0 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark45(-453.92216692441536,-305.66623082273316,51.17197187081203 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark45(-453.95213061746415,-326.1741741972688,29.468186645777678 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark45(-454.10588265191075,-380.6542992146912,51.03720822306303 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark45(-454.3245200654223,-354.6225753166257,20.281885914752877 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark45(-454.59755186221946,-303.8425610479674,66.39552349021227 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark45(-454.60838730093616,-319.2886863805955,3.484532310409506 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark45(-454.8564771975979,-297.85844284032765,100.0 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark45(-454.939746439345,-310.40231113884664,19.185554663106984 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark45(-454.993484381797,-310.16904928454073,52.61273299895336 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark45(-455.0139006915969,-328.3597434034649,89.69830347558805 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark45(-455.3910358878122,-304.90979406255025,52.12116034895581 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark45(-455.4262747451208,-317.9962091074931,6.242215226690789 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark45(-455.6082905060947,-320.4044236248225,57.04570744728949 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark45(-455.61159489057263,-351.7894335965429,14.438135609766874 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark45(-455.6728501280774,-315.8804036438882,12.65800371308083 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark45(-455.67548721931246,-295.91546836786324,81.35846734957687 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark45(-455.73778458199456,-328.61493358438884,42.764203888623825 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark45(-455.9067601006844,-328.64030197320506,6.052624264029433 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark45(-455.97989885880867,-346.33536237514664,44.118454809747135 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark45(-456.06827128106767,-297.2910099845046,28.709709975030137 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark45(-456.1793117739044,-302.393957040576,45.887005519979 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark45(-456.3017348306942,-328.83092652592876,17.355462400067893 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark45(-456.5992154085781,-343.0109923841622,54.226674953050775 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark45(-456.65686946378696,-388.1857630491232,81.88102296959437 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark45(-456.7853440233405,-356.3026420301866,27.76514110145017 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark45(-456.8307667634713,-292.6655117677205,44.08114758928423 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark45(-456.85830594075344,-304.5279100432307,33.473801934223474 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark45(-457.16874890101565,-290.73644904321094,47.213215564052405 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark45(-457.1711015630924,-292.63987564443113,57.632380040161024 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark45(-457.3383988097462,-329.80036552422536,14.91606899271298 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark45(-457.62124462369997,-300.71365050620864,1.957939247207392 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark45(-457.73525714600464,-318.55676180857205,5.928175677697695 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark45(-457.8117114340861,-364.1138268566408,86.24856105692916 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark45(-458.15533269692423,-331.30429213662416,4.523489348794854 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark45(-458.19138558447855,-347.5769904381049,87.23161954044781 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark45(-458.36378746999986,-333.082421501363,29.315066046697808 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark45(-458.5212340897122,-304.2115080822048,26.86071767349445 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark45(-458.5289787512113,-290.45058002065275,46.062399169044454 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark45(-458.59586910221327,-322.57968173463877,22.946924775522874 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark45(-458.8806589838951,-288.8273615465015,65.91642993417705 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark45(-458.88418954205457,-338.7332194606131,88.5917981837529 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark45(-458.8926090083155,-310.69527045649596,73.62228991231129 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark45(-458.92101411605717,-362.9851365961517,44.30868364235715 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark45(-459.0824209404453,-293.57322916901956,0.9669641251323391 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark45(-459.146726692984,-343.1137588768808,4.379926396214245 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark45(-459.34621651092533,-346.6946955044731,33.81148302434897 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark45(-459.3747277076733,-298.59264513511243,17.930526993550572 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark45(-459.42519877527707,-335.1178658244109,83.46464260687273 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark45(-459.59809900447135,-306.9715756067566,48.4293013762005 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark45(-459.6407666909221,-287.12733470472847,66.15920319343712 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark45(-459.76914084206135,-350.41189912691385,26.26392848897794 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark45(-460.0344423167666,-315.4894149414274,14.211868640658864 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark45(-460.1688829396856,-310.8115105191175,86.14866655839683 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark45(-460.1870785844209,-315.9556200967155,100.0 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark45(-460.23525545892585,-344.0221690161792,16.268148260952614 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark45(-460.57174280233374,-335.6373517791088,10.52994399174662 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark45(-460.5754073097322,-286.18538347769214,100.0 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark45(-460.6258102108251,-289.72760653136424,31.479898365906422 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark45(-460.85604994503086,-295.69165141882957,39.77324417745446 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark45(-460.94873473555685,-289.97508164866167,83.70605318661055 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark45(-460.96440053968007,-310.2059954343222,94.41264836901861 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark45(-461.0573860983832,-322.49546197958676,76.02330990272296 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark45(-461.2191514943599,-297.46708077854913,92.24404327050965 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark45(-461.55254078786095,-294.2125191326051,2.3272185038601236 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark45(-461.7974895323933,-302.2694666636992,49.60543574802111 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark45(-461.8816250762858,-357.5372826410301,22.39207937241493 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark45(-462.21083499622546,-291.2718021051045,100.0 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark45(-462.2890661825579,-320.04982225467626,57.37168627272868 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark45(-462.3961326802482,-338.8129038304364,33.513121105544776 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark45(-462.57008266108767,-352.6664222873845,100.0 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark45(-462.64057816410417,-303.213266044233,82.23987338602211 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark45(-462.7157805621652,-316.23847666312446,60.84726615670019 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark45(-462.72186450167555,-289.4788035414321,85.79267710757682 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark45(-462.8108788419407,-306.5993304813854,93.25307414840836 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark45(-462.8567587283616,-284.20141490434673,80.57357605252582 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark45(-462.9577370650404,-314.5278032414491,82.30844642308139 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark45(-463.25851194469504,-288.47750578920596,100.0 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark45(-463.39503456602614,-290.277865274765,25.27343459705797 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark45(-463.4605340688673,-289.4909966520391,100.0 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark45(-463.65874801225885,-291.9587996273164,63.77721276121099 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark45(-463.664929017742,-283.68929039702414,17.009152552896722 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark45(-463.7316795419179,-303.30692391010086,6.51870178124301 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark45(-463.9824176319211,-313.6010039542811,7.676733116132326 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark45(-464.2808686449668,-289.5025288053468,5.872011551740869 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark45(-464.6241735714914,-364.01416371654057,54.17889553138218 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark45(-464.6936146818656,-334.5400286479088,11.686386292245075 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark45(-464.7523780818622,-287.3943040017371,100.0 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark45(-464.92986359350476,-285.9391050091649,22.299961878434644 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark45(-464.99857726456156,-303.60947936273715,85.24038119924734 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark45(-465.0403643692558,-335.64107213647924,12.537635700430684 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark45(-465.1170494916558,-318.8073142450327,60.6187386245108 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark45(-465.20873266184117,-286.6003357328303,32.89300187455123 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark45(-465.38898146971536,-310.82735196370146,11.954867773070447 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark45(-465.54265574808375,-296.1080061538517,80.15092611658781 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark45(-465.70796265230604,-285.979904203989,66.40473780512758 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark45(-465.89231738432557,-324.39411183281226,100.0 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark45(-466.01967088665225,-316.1178402972601,92.94534319689603 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark45(-466.1340764184232,-284.6993726631634,31.18413622504505 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark45(-466.3448956572814,-310.70147983965705,8.78625745410777 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark45(-466.57975549227933,-309.66894649346295,60.525983039371226 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark45(-466.5868888657971,-288.8030302170121,100.0 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark45(-466.899062553356,-286.60310155962526,1.732560934592243 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark45(-466.9648617721681,-326.28560747096174,30.043150657568162 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark45(-466.986935121806,-328.6541522677886,55.7281174674942 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark45(-467.2905938728584,-292.44586515956576,21.835002168242966 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark45(-467.2939413742241,-281.4097928085555,79.14381919034841 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark45(-467.4996989938268,-315.96773409893956,42.206388396564336 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark45(-467.56304322724407,-279.5752071223464,35.85165388601047 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark45(-467.6387712410095,-326.24603792451336,87.66712856020936 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark45(-467.6436259536312,-308.9179493819656,16.85554349802277 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark45(-467.8829853479624,-295.2388531184338,16.407906376347853 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark45(-468.2881768403961,-337.17652881728856,8.788785870056401 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark45(-468.3321673529369,-284.86224046343915,77.49448593407894 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark45(-46.8400443672044,-711.9818405148682,8.60156104283925 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark45(-468.4018762071925,-374.27645826682067,7.3908475917928484 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark45(-468.5316398260259,-315.83605970850994,49.56942039785622 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark45(-468.5771494116144,-310.87642998488343,84.39078542024188 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark45(-468.5934320377947,-287.5667068012561,52.065178039863525 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark45(-468.6613059726332,-303.80041458788327,65.8447501291345 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark45(-468.68582474234205,-280.6496841420492,0.3067747259046314 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark45(-469.12637818709953,-331.074054829497,85.56265863485825 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark45(-469.2008971213135,-292.13524447702156,52.777117792017634 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark45(-469.4002971590652,-278.0699526472903,70.06210433659018 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark45(-469.6739977899532,-280.96176975653685,100.0 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark45(-469.8502247940866,-321.9672794641228,74.35794621581314 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark45(-469.99346994789545,-315.38263630247565,82.75011408070998 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark45(-470.1182431361798,-276.6054826135593,12.451578125929501 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark45(-470.1709884794491,-319.13312804257095,61.576617425473444 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark45(-470.18314053794603,-283.04452034794537,14.398999093994647 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark45(-470.35969643098986,-307.48215555355216,57.73712702112175 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark45(-470.4910329226256,-287.0745354208729,100.0 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark45(-470.6300434375113,-317.5563327874732,14.086802645702562 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark45(-470.6838431608464,-299.14792890023864,23.193182175665925 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark45(-470.9157575128402,-313.61779588251727,64.36709891150844 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark45(-471.0727607239196,-321.2212315354248,100.0 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark45(-471.13820040893575,-293.32267069126146,100.0 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark45(-471.13910907400384,-275.905568905135,100.0 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark45(-471.26815607067374,-333.92360964478434,29.733260897947275 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark45(-471.33964658831263,-321.2490237253819,98.49613290341287 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark45(-471.5667118502432,-335.9793300524306,82.84090043174214 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark45(-471.685282583011,-277.7218097427507,95.73548212945144 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark45(-471.7180480067777,-326.9031541349695,94.00469048733609 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark45(-471.84356598141824,-291.9080711032957,80.7974849191267 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark45(-472.2093779685066,-312.2142575994407,7.644540407997269 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark45(-472.29288842054035,-294.3887572604995,62.72843860476664 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark45(-472.41783366810085,-323.0704013187598,2.5605291023022687 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark45(-472.44385768464633,-294.81233200674734,87.56414575841308 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark45(-472.5172424829088,-322.13020228204266,100.0 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark45(-472.5506048540191,-307.159109034252,27.101641848388084 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark45(-472.62651414378456,-322.3285752753879,96.73103461407527 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark45(-472.9606334079595,-320.13889697806366,61.95526378576011 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark45(-473.0900132416775,-310.2355487100528,59.61910615256531 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark45(-473.11770512603226,-276.68123245616516,57.190576379167254 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark45(-473.1889540110419,-327.96433664085407,73.42169210565277 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark45(-473.23174713874903,-281.14533720153526,38.73477150767547 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark45(-473.35105159842215,-385.9359051662758,29.83054289122643 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark45(-473.7980683528273,-283.8059922629429,90.18823754661912 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark45(-473.8567477932595,-364.06396735097564,33.80717803261794 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark45(-473.97445692041254,-321.3900237617636,100.0 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark45(-474.11178383428785,-273.06131563582665,14.088949384419138 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark45(-474.300892289131,-285.2854846524624,35.37157754063628 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark45(-474.4684674668879,-336.7152936272345,18.099011789813673 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark45(-474.7167305538976,-342.68378044557664,22.101337845024712 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark45(-474.72154168497684,-289.49348814091155,100.0 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark45(-474.98124906216356,-283.27566481806423,19.864114231102683 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark45(-475.08037702908086,-285.6304868930364,100.0 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark45(-475.09595260351955,-301.82350491370636,59.202676538097734 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark45(-475.1810557654686,-313.53860538468206,33.233073545744446 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark45(-475.2549969387634,-274.0099933911828,50.74791067272011 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark45(-475.63742324561065,-301.90095012405584,8.210564687820707 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark45(-475.82197330365443,-329.5632162143961,12.86639519006529 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark45(-475.9866342660946,-296.2831523148423,84.31010180148584 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark45(-476.0420799335793,-287.58744349529525,-100.0 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark45(-476.2323408575233,-297.71326285325574,54.84519525016432 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark45(-476.6576342347764,-276.88922379867955,100.0 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark45(-476.80053815057255,-316.8141200775404,100.0 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark45(-476.85194724556027,-330.9606185262856,100.0 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark45(-477.0936606531443,-275.0437529799138,8.44563108334053 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark45(-477.2667112915741,-336.923595417056,100.0 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark45(-477.2936961445371,-317.6753217739201,34.480938396727524 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark45(-477.3732232273393,-298.81646816625135,77.72266418292469 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark45(-477.4984038548445,-286.2676669616448,89.26827776401046 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark45(-477.5496361328249,-268.79002660053357,73.49333970798452 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark45(-477.72947120213865,-278.2282067587468,70.82936616728034 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark45(-477.83486877484904,-302.6384759430897,67.59202707022155 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark45(-478.0831049425707,-296.37786017374356,100.0 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark45(-478.19531115323326,-288.9643532089007,65.34479440368912 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark45(-478.21271963968707,-305.02572292098887,35.2826239547488 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark45(-478.2501694460403,-321.4905666840147,80.44823576184689 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark45(-478.31218159954267,-303.3216633061291,87.45598152783907 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark45(-478.3239602085864,-284.2200311564689,15.387672760098482 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark45(-478.73095042437313,-287.3024581640305,21.663744544479503 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark45(-478.79596031541007,-292.6287292095234,8.568812083542383 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark45(-478.9268266579624,-302.75600765049876,33.61416560062747 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark45(-479.0711093634115,-316.1177075589288,44.570889857839575 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark45(-479.3576811602824,-311.73395280024926,100.0 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark45(-479.538230876595,-402.13218505363403,71.16355231929924 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark45(-479.65410298090916,-335.87851847651325,66.81088418742704 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark45(-479.7111205839875,-302.444265668538,39.630269507250276 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark45(-480.0293811287188,-272.5705525628994,57.16173586989633 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark45(-480.46533319863977,-267.2572991852955,100.0 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark45(-480.5026300755122,-315.94328286426736,54.68175436984055 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark45(-480.52853892694776,-295.391968021206,54.39988727937234 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark45(-480.7600228263315,-294.3854691934459,100.0 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark45(-480.91225616825204,-292.5806379656966,53.784063308238586 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark45(-481.04434988749,-300.85913780703845,74.15282181339293 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark45(-481.0532281055207,-268.93350707757463,49.82153261144424 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark45(-481.07254441162195,-293.0906854748348,55.614925288764965 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark45(-481.2377969644159,-309.4751100667577,72.12372589842607 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark45(-481.5386469075175,-270.85752131235614,100.0 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark45(-481.70263566530724,-269.5729069536919,84.90951908760934 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark45(-481.7478156780811,-318.7714607297795,63.634264870780555 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark45(-482.18144671032434,-305.26323987064194,44.594046635770525 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark45(-482.18664343512086,-287.7832053442094,5.3368735184604645 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark45(-482.19630196127036,-271.4850004548919,7.700614109756003 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark45(-482.22807987109803,-269.6866456137542,100.0 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark45(-482.53319734182423,-303.3367833375483,100.0 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark45(-482.7744811369495,-296.5503398791196,100.0 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark45(-482.98298174823645,-288.5118669391695,50.6441311473678 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark45(-483.11044286486833,-293.1271725490504,46.00820537318498 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark45(-483.21884953489047,-301.1569434015055,96.26380403946078 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark45(-483.79634988729396,-266.3476554298725,10.688258175036779 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark45(-483.8225804872282,-275.0174195815744,94.39077364624058 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark45(-483.82658331526005,-263.2399854247779,2.482857111145705 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark45(-483.85852712719793,-279.6855387990902,49.42288261376916 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark45(-483.88515984982973,-318.9196412324434,100.0 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark45(-484.27217646058955,-272.8023688324581,39.47962966550659 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark45(-484.28735977383315,-322.0006521242089,58.03418901618776 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark45(-484.56779032608637,-311.5105066255133,82.20554788169255 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark45(-484.5842545074993,-265.17819355416873,39.54610787646294 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark45(-484.83505928875445,-296.8454669484671,7.556048927409591 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark45(-485.14747137842625,-281.0607345627043,4.10253217640448 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark45(-485.17512768885086,-292.31137311255065,86.40471313115026 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark45(-485.3899511366796,-300.2953094830015,96.53232873196376 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark45(-485.4238535772431,-260.8756760369098,6.0199066881144745 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark45(-485.62233352410965,-298.57812176957464,26.51089249387917 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark45(-485.64038587222433,-284.8170015516273,65.6077821316673 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark45(-485.64494483041955,-264.981419586087,50.29120559749024 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark45(-485.66185968901084,-271.6678254439768,6.483950740648382 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark45(-485.67122634525725,-277.07004444525273,98.92594255883768 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark45(-485.732479178031,-347.25029821303394,73.77791285567207 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark45(-485.915998036931,-324.433271411354,89.53935843103693 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark45(-486.16390821129596,-270.08796323494596,8.914754968133082 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark45(-486.2393863642021,-259.8133782150809,38.320444536197186 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark45(-486.6634315554444,-292.79955526215986,53.09985796740156 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark45(-486.6828947723202,-267.6969568378161,76.64334944091556 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark45(-486.72625647156946,-262.0184914688321,93.32066045122706 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark45(-486.80461285554776,-276.3833555311937,17.972228146589785 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark45(-486.8376116973792,-318.5587614734604,100.0 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark45(-487.1524521867071,-305.1739315482676,93.04131320322989 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark45(-487.3865696760683,-270.88539837116537,12.72277721113555 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark45(-487.5765172226101,-366.44954338983854,50.129183087869535 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark45(-488.10959244999464,-268.9806572142902,64.1825790479856 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark45(-488.1096597064113,-269.5458870889981,83.15909139055802 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark45(-488.30049872982056,-259.94480553085015,17.892078792569137 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark45(-488.34517596818495,-288.04179080656104,16.43928179501883 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark45(-488.606331785783,-308.2834251536435,84.29496913995712 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark45(-488.7513736478524,-282.21967421698173,100.0 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark45(-489.05823157714684,-276.9365021927787,47.13277253511359 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark45(-489.1456045113019,-265.2672957815009,100.0 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark45(-489.3172026760278,-277.6382004549446,100.0 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark45(-48.94153404656896,-698.937632340656,25.03010991122271 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark45(-489.72790271314204,-280.12876858183813,26.935244144682322 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark45(-489.7997972492054,-270.6913953927508,55.43164098199787 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark45(-489.879686383297,-259.74278025617514,31.745273214406495 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark45(-489.90960642379434,-256.7224750977718,84.22067754428889 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark45(-490.1451284828992,-260.1290007479018,97.090905218946 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark45(-490.43253926418237,-286.6457794426578,64.44789454300778 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark45(-490.53697583142474,-293.5881382690072,23.804687368327876 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark45(-490.69121563405224,-270.0049604618046,63.73392374667682 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark45(-491.1963521095479,-268.24539349093914,62.146088706251646 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark45(-49.15602219481292,-720.9965586070275,74.16131631043271 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark45(-491.67153871917645,-312.1936304860392,85.36515573174371 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark45(-491.6781845575114,-301.625604851312,37.11643394881469 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark45(-491.70027408235285,-275.05859113742633,31.361330319235577 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark45(-491.7462652331369,-279.79904062416887,86.51757134172354 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark45(-491.7577455488453,-257.3722089456604,65.21266870221666 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark45(-491.8206598233565,-287.68541606730037,20.561094690278424 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark45(-491.82193403858304,-302.13020835085007,73.90508466864692 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark45(-491.86745615565,-307.43924560017933,95.11946324184564 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark45(-492.03914669472294,-285.4836361221681,49.14450480247021 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark45(-492.06734165127847,-286.2639023715375,10.962444214679422 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark45(-492.1940502301909,-312.20843359112996,0.537876915270104 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark45(-492.2501253710272,-283.98682640993513,100.0 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark45(-492.3568080498864,-291.71185960588963,89.0747851369394 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark45(-492.39018235009064,-261.88214309242994,46.20248192912956 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark45(-492.79780188834883,-283.52874568826047,96.38005115474624 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark45(-492.8016538344053,-278.7904538315767,30.60161999053139 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark45(-492.873809990771,-261.6483084122175,35.91794097890639 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark45(-492.898424720943,-358.3314521557867,84.45063394220242 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark45(-493.06749078526843,-292.98779986211645,20.704462955913257 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark45(-493.108496831789,-276.60073198263325,16.496315799058706 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark45(-493.126107224262,-270.6832045112883,89.20685724774638 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark45(-493.18091566460816,-336.37443375062094,62.198791022590484 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark45(-493.19251845779854,-273.9413191203574,45.101016798132775 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark45(-493.2759379945718,-277.6877578736953,100.0 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark45(-493.42358196734824,-295.58987009831,45.82210522125612 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark45(-493.6662185187545,-326.55025902844574,57.661842143923934 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark45(-493.7892786513677,-269.42483846743227,48.75856694370492 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark45(-493.80247856274184,-341.9264647531056,73.86217831271827 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark45(-494.1161379221383,-277.47023650307017,48.02357679635111 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark45(-494.17692955778375,-355.5314505267804,37.049856926930545 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark45(-494.19571633483224,-258.46194861517523,81.43336398440627 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark45(-494.1983059216166,-283.9022872100974,96.818190992637 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark45(-494.31249308398293,-312.24029613676873,32.83734439434383 ) ;
  }

  @Test
  public void test2476() {
    coral.tests.JPFBenchmark.benchmark45(-494.82710677726834,-255.42905495267559,9.94580543891152 ) ;
  }

  @Test
  public void test2477() {
    coral.tests.JPFBenchmark.benchmark45(-494.8857867107774,-336.9634144716117,30.730647934593378 ) ;
  }

  @Test
  public void test2478() {
    coral.tests.JPFBenchmark.benchmark45(-494.9837738659344,-252.3703227456414,100.0 ) ;
  }

  @Test
  public void test2479() {
    coral.tests.JPFBenchmark.benchmark45(-495.0066705870903,-278.78127424812294,91.020106734331 ) ;
  }

  @Test
  public void test2480() {
    coral.tests.JPFBenchmark.benchmark45(-495.17876630913304,-264.31377606701164,3.8541861287248764 ) ;
  }

  @Test
  public void test2481() {
    coral.tests.JPFBenchmark.benchmark45(-495.9059358695809,-270.82517032801627,38.35080225816827 ) ;
  }

  @Test
  public void test2482() {
    coral.tests.JPFBenchmark.benchmark45(-496.162982200017,-337.4357182422598,100.0 ) ;
  }

  @Test
  public void test2483() {
    coral.tests.JPFBenchmark.benchmark45(-496.16733432382654,-287.03733779672734,61.553851668919066 ) ;
  }

  @Test
  public void test2484() {
    coral.tests.JPFBenchmark.benchmark45(-496.4768005574586,-289.3417721585053,91.52871961800076 ) ;
  }

  @Test
  public void test2485() {
    coral.tests.JPFBenchmark.benchmark45(-496.5041329657191,-284.70807144956393,43.26908330657611 ) ;
  }

  @Test
  public void test2486() {
    coral.tests.JPFBenchmark.benchmark45(-496.54983995827894,-252.5295662994838,72.94904471057185 ) ;
  }

  @Test
  public void test2487() {
    coral.tests.JPFBenchmark.benchmark45(-496.66934088091676,-302.4313872190496,100.0 ) ;
  }

  @Test
  public void test2488() {
    coral.tests.JPFBenchmark.benchmark45(-497.2388993583948,-267.5770319420328,45.653128275031335 ) ;
  }

  @Test
  public void test2489() {
    coral.tests.JPFBenchmark.benchmark45(-497.6217083784113,-290.0710626580173,77.2124708970716 ) ;
  }

  @Test
  public void test2490() {
    coral.tests.JPFBenchmark.benchmark45(-497.96448617770255,-255.00662381436115,39.341416094171876 ) ;
  }

  @Test
  public void test2491() {
    coral.tests.JPFBenchmark.benchmark45(-498.0291209127202,-319.16243711850245,21.90299033844903 ) ;
  }

  @Test
  public void test2492() {
    coral.tests.JPFBenchmark.benchmark45(-498.294681542093,-315.4968617874051,100.0 ) ;
  }

  @Test
  public void test2493() {
    coral.tests.JPFBenchmark.benchmark45(-498.70555372740847,-318.3372518173605,52.088660274472886 ) ;
  }

  @Test
  public void test2494() {
    coral.tests.JPFBenchmark.benchmark45(-498.7720682037754,-270.534002019503,92.94476992636515 ) ;
  }

  @Test
  public void test2495() {
    coral.tests.JPFBenchmark.benchmark45(-499.0669578691936,-250.7548541083218,100.0 ) ;
  }

  @Test
  public void test2496() {
    coral.tests.JPFBenchmark.benchmark45(-499.14718310413497,-281.35679635721397,61.77121997975114 ) ;
  }

  @Test
  public void test2497() {
    coral.tests.JPFBenchmark.benchmark45(-499.1934372178295,-314.7998266327038,100.0 ) ;
  }

  @Test
  public void test2498() {
    coral.tests.JPFBenchmark.benchmark45(-499.38734903826685,-259.7413582632424,61.31136742473424 ) ;
  }

  @Test
  public void test2499() {
    coral.tests.JPFBenchmark.benchmark45(-499.6052706964528,-260.7548142632369,26.914914058813793 ) ;
  }

  @Test
  public void test2500() {
    coral.tests.JPFBenchmark.benchmark45(-499.60841387640085,-263.1096533353601,92.56189492839357 ) ;
  }

  @Test
  public void test2501() {
    coral.tests.JPFBenchmark.benchmark45(-499.98699712994664,-266.1475910821604,23.87994245011889 ) ;
  }

  @Test
  public void test2502() {
    coral.tests.JPFBenchmark.benchmark45(-500.1627031728264,-267.5861862825287,100.0 ) ;
  }

  @Test
  public void test2503() {
    coral.tests.JPFBenchmark.benchmark45(-500.1834945378621,-269.83626124198906,73.8599540061258 ) ;
  }

  @Test
  public void test2504() {
    coral.tests.JPFBenchmark.benchmark45(-500.1966361950252,-271.1348811835632,11.838907284676495 ) ;
  }

  @Test
  public void test2505() {
    coral.tests.JPFBenchmark.benchmark45(-500.40680044102896,-281.952593353851,77.53080678822533 ) ;
  }

  @Test
  public void test2506() {
    coral.tests.JPFBenchmark.benchmark45(-500.52748088008445,-270.9844744333331,14.902782541505815 ) ;
  }

  @Test
  public void test2507() {
    coral.tests.JPFBenchmark.benchmark45(-500.528447407385,-275.65476982203813,26.72937841444798 ) ;
  }

  @Test
  public void test2508() {
    coral.tests.JPFBenchmark.benchmark45(-500.5844920673853,-283.65666914418364,63.0402415404084 ) ;
  }

  @Test
  public void test2509() {
    coral.tests.JPFBenchmark.benchmark45(-501.33304177359526,-257.38093192825926,29.355156273122873 ) ;
  }

  @Test
  public void test2510() {
    coral.tests.JPFBenchmark.benchmark45(-501.3967995799958,-247.41082004576782,37.86139148046169 ) ;
  }

  @Test
  public void test2511() {
    coral.tests.JPFBenchmark.benchmark45(-501.4038780924487,-297.4718707880246,27.660374564302835 ) ;
  }

  @Test
  public void test2512() {
    coral.tests.JPFBenchmark.benchmark45(-501.5844326156473,-283.86808167088884,100.0 ) ;
  }

  @Test
  public void test2513() {
    coral.tests.JPFBenchmark.benchmark45(-501.6257610789822,-262.2681797364682,44.26506103996027 ) ;
  }

  @Test
  public void test2514() {
    coral.tests.JPFBenchmark.benchmark45(-501.63260509641555,-320.3572560242353,100.0 ) ;
  }

  @Test
  public void test2515() {
    coral.tests.JPFBenchmark.benchmark45(-501.64653807280104,-256.2163781926987,30.550362283469266 ) ;
  }

  @Test
  public void test2516() {
    coral.tests.JPFBenchmark.benchmark45(-5.01723338049293E-7,-788.5987859171867,0.0 ) ;
  }

  @Test
  public void test2517() {
    coral.tests.JPFBenchmark.benchmark45(-502.1228967433119,-282.3629310307519,100.0 ) ;
  }

  @Test
  public void test2518() {
    coral.tests.JPFBenchmark.benchmark45(-502.1392650615905,-256.00686879685566,68.26833828634179 ) ;
  }

  @Test
  public void test2519() {
    coral.tests.JPFBenchmark.benchmark45(-502.27475711692824,-266.05377838072314,100.0 ) ;
  }

  @Test
  public void test2520() {
    coral.tests.JPFBenchmark.benchmark45(-502.5690334016575,-247.9657907977049,81.27847047976567 ) ;
  }

  @Test
  public void test2521() {
    coral.tests.JPFBenchmark.benchmark45(-502.65311020797947,-262.06031841093613,14.387697057745811 ) ;
  }

  @Test
  public void test2522() {
    coral.tests.JPFBenchmark.benchmark45(-502.8082832943315,-301.7944159058435,1.5839932920321624 ) ;
  }

  @Test
  public void test2523() {
    coral.tests.JPFBenchmark.benchmark45(-502.90446991358147,-269.5453275509469,3.8994055720173293 ) ;
  }

  @Test
  public void test2524() {
    coral.tests.JPFBenchmark.benchmark45(-502.9225060698944,-282.99644421904287,100.0 ) ;
  }

  @Test
  public void test2525() {
    coral.tests.JPFBenchmark.benchmark45(-502.95626917830236,-326.60061356211713,31.498067682583326 ) ;
  }

  @Test
  public void test2526() {
    coral.tests.JPFBenchmark.benchmark45(-503.2183943910707,-247.94100362182274,21.397241186080265 ) ;
  }

  @Test
  public void test2527() {
    coral.tests.JPFBenchmark.benchmark45(-50.33149116998523,50.33149116998523,0 ) ;
  }

  @Test
  public void test2528() {
    coral.tests.JPFBenchmark.benchmark45(-503.4735047458326,-291.3486457856548,15.5666026767489 ) ;
  }

  @Test
  public void test2529() {
    coral.tests.JPFBenchmark.benchmark45(-503.6187140247466,-289.174425442097,91.21072620898246 ) ;
  }

  @Test
  public void test2530() {
    coral.tests.JPFBenchmark.benchmark45(-503.6468082118146,-277.08821861310867,63.0479076001661 ) ;
  }

  @Test
  public void test2531() {
    coral.tests.JPFBenchmark.benchmark45(-504.1907508548102,-309.3823581217667,60.43665291757608 ) ;
  }

  @Test
  public void test2532() {
    coral.tests.JPFBenchmark.benchmark45(-504.35307495680854,-244.0032882912123,85.30964632969435 ) ;
  }

  @Test
  public void test2533() {
    coral.tests.JPFBenchmark.benchmark45(-504.4906682787699,-272.6196117000751,92.40337384757561 ) ;
  }

  @Test
  public void test2534() {
    coral.tests.JPFBenchmark.benchmark45(-504.69135833445335,-270.27365915618634,64.35403184139173 ) ;
  }

  @Test
  public void test2535() {
    coral.tests.JPFBenchmark.benchmark45(-504.98737718397035,-261.7129642861015,95.32189680826565 ) ;
  }

  @Test
  public void test2536() {
    coral.tests.JPFBenchmark.benchmark45(-505.15938291044364,-251.00113371613404,100.0 ) ;
  }

  @Test
  public void test2537() {
    coral.tests.JPFBenchmark.benchmark45(-505.1681496648903,-333.9446731059253,94.99362615060025 ) ;
  }

  @Test
  public void test2538() {
    coral.tests.JPFBenchmark.benchmark45(-505.40739402894036,-285.01903621200904,11.608236944332688 ) ;
  }

  @Test
  public void test2539() {
    coral.tests.JPFBenchmark.benchmark45(-505.4561029557393,-282.23574550302897,72.79611041195676 ) ;
  }

  @Test
  public void test2540() {
    coral.tests.JPFBenchmark.benchmark45(-505.57644617333574,-262.2239828526248,100.0 ) ;
  }

  @Test
  public void test2541() {
    coral.tests.JPFBenchmark.benchmark45(-505.6307001509165,-264.88880737667154,46.594489909752895 ) ;
  }

  @Test
  public void test2542() {
    coral.tests.JPFBenchmark.benchmark45(-505.71219967528634,-246.67748943388537,28.978922369407343 ) ;
  }

  @Test
  public void test2543() {
    coral.tests.JPFBenchmark.benchmark45(-505.7769890596325,-290.96455747481883,72.94543158454096 ) ;
  }

  @Test
  public void test2544() {
    coral.tests.JPFBenchmark.benchmark45(-506.417638224497,-242.89928898977377,100.0 ) ;
  }

  @Test
  public void test2545() {
    coral.tests.JPFBenchmark.benchmark45(-506.64196544116953,-296.7932113387609,26.067255638594844 ) ;
  }

  @Test
  public void test2546() {
    coral.tests.JPFBenchmark.benchmark45(-506.91618360816096,-246.62728917131264,84.11436610876322 ) ;
  }

  @Test
  public void test2547() {
    coral.tests.JPFBenchmark.benchmark45(-506.95013792893474,-307.9866233188179,19.70273278184665 ) ;
  }

  @Test
  public void test2548() {
    coral.tests.JPFBenchmark.benchmark45(-507.0806387586974,-243.79164627561838,78.93922159553642 ) ;
  }

  @Test
  public void test2549() {
    coral.tests.JPFBenchmark.benchmark45(-507.1676104609596,-246.62291830394133,64.03965049748746 ) ;
  }

  @Test
  public void test2550() {
    coral.tests.JPFBenchmark.benchmark45(-507.34823755111717,-340.6397343360214,55.773670669342124 ) ;
  }

  @Test
  public void test2551() {
    coral.tests.JPFBenchmark.benchmark45(-507.6581564816936,-278.0279587109209,53.993110114026535 ) ;
  }

  @Test
  public void test2552() {
    coral.tests.JPFBenchmark.benchmark45(-507.93826329206536,-238.36124455821076,1.9984419991869231 ) ;
  }

  @Test
  public void test2553() {
    coral.tests.JPFBenchmark.benchmark45(-508.2105102128111,-258.2190489272094,56.376868116309566 ) ;
  }

  @Test
  public void test2554() {
    coral.tests.JPFBenchmark.benchmark45(-508.2502566041975,-265.37258803033745,30.247983680258386 ) ;
  }

  @Test
  public void test2555() {
    coral.tests.JPFBenchmark.benchmark45(-508.83984328245157,-268.27915762487004,60.21867138352823 ) ;
  }

  @Test
  public void test2556() {
    coral.tests.JPFBenchmark.benchmark45(-508.86505577293894,-285.49299879986387,100.0 ) ;
  }

  @Test
  public void test2557() {
    coral.tests.JPFBenchmark.benchmark45(-509.03360496755676,-255.88251539657531,28.116884289473376 ) ;
  }

  @Test
  public void test2558() {
    coral.tests.JPFBenchmark.benchmark45(-509.62677597177276,-247.14326667718157,70.17659956545478 ) ;
  }

  @Test
  public void test2559() {
    coral.tests.JPFBenchmark.benchmark45(-509.62725181589565,-262.4332378368444,90.7790372263222 ) ;
  }

  @Test
  public void test2560() {
    coral.tests.JPFBenchmark.benchmark45(-509.7259092551866,-236.29314016480754,11.619418377888735 ) ;
  }

  @Test
  public void test2561() {
    coral.tests.JPFBenchmark.benchmark45(-509.73658569104225,-339.5878410734483,54.5503028058298 ) ;
  }

  @Test
  public void test2562() {
    coral.tests.JPFBenchmark.benchmark45(-509.8358818906985,-282.816653700989,43.08405036459263 ) ;
  }

  @Test
  public void test2563() {
    coral.tests.JPFBenchmark.benchmark45(-509.95810820812216,-243.8580105476082,50.86189828668088 ) ;
  }

  @Test
  public void test2564() {
    coral.tests.JPFBenchmark.benchmark45(-510.067645335795,-248.55164739057489,30.174375702527044 ) ;
  }

  @Test
  public void test2565() {
    coral.tests.JPFBenchmark.benchmark45(-510.2158527172028,-247.75464092825976,26.99573256302368 ) ;
  }

  @Test
  public void test2566() {
    coral.tests.JPFBenchmark.benchmark45(-510.6005570377127,-263.4722490956774,93.54368977542248 ) ;
  }

  @Test
  public void test2567() {
    coral.tests.JPFBenchmark.benchmark45(-510.7344322820712,-295.23775368983894,58.9621602683855 ) ;
  }

  @Test
  public void test2568() {
    coral.tests.JPFBenchmark.benchmark45(-510.7960956643488,-309.2966995960571,64.35261175311456 ) ;
  }

  @Test
  public void test2569() {
    coral.tests.JPFBenchmark.benchmark45(-510.89496010733427,-277.2923418099038,36.63377101388622 ) ;
  }

  @Test
  public void test2570() {
    coral.tests.JPFBenchmark.benchmark45(-510.9398848879806,-266.73976002203034,100.0 ) ;
  }

  @Test
  public void test2571() {
    coral.tests.JPFBenchmark.benchmark45(-511.1494725467234,-254.41282011565676,100.0 ) ;
  }

  @Test
  public void test2572() {
    coral.tests.JPFBenchmark.benchmark45(-511.19022595988815,-243.29471521045184,4.090384778438263 ) ;
  }

  @Test
  public void test2573() {
    coral.tests.JPFBenchmark.benchmark45(-511.2304299936695,-264.852552121333,40.59716880794161 ) ;
  }

  @Test
  public void test2574() {
    coral.tests.JPFBenchmark.benchmark45(-511.57017750145826,-240.89144762194553,97.53706282265597 ) ;
  }

  @Test
  public void test2575() {
    coral.tests.JPFBenchmark.benchmark45(-51.157523503418865,-75.15722730512789,2.0557196859905815 ) ;
  }

  @Test
  public void test2576() {
    coral.tests.JPFBenchmark.benchmark45(-511.8045480788247,-290.3619117869452,87.81395757234876 ) ;
  }

  @Test
  public void test2577() {
    coral.tests.JPFBenchmark.benchmark45(-511.80870231341237,-239.22920153121547,25.6988436877146 ) ;
  }

  @Test
  public void test2578() {
    coral.tests.JPFBenchmark.benchmark45(-512.0888063175944,-277.4975963461446,77.73442626564076 ) ;
  }

  @Test
  public void test2579() {
    coral.tests.JPFBenchmark.benchmark45(-512.0967658840242,-275.7687004189336,100.0 ) ;
  }

  @Test
  public void test2580() {
    coral.tests.JPFBenchmark.benchmark45(-512.13466620571,-255.85888884280587,20.511071129177026 ) ;
  }

  @Test
  public void test2581() {
    coral.tests.JPFBenchmark.benchmark45(-512.2269414056209,-236.57906762238082,24.169471877749913 ) ;
  }

  @Test
  public void test2582() {
    coral.tests.JPFBenchmark.benchmark45(-512.4144958765086,-284.7090118862698,10.812664473236444 ) ;
  }

  @Test
  public void test2583() {
    coral.tests.JPFBenchmark.benchmark45(-512.4649934429692,-279.179898537177,93.06089763685264 ) ;
  }

  @Test
  public void test2584() {
    coral.tests.JPFBenchmark.benchmark45(-512.7017805066165,-252.00676189261452,4.683702245467543 ) ;
  }

  @Test
  public void test2585() {
    coral.tests.JPFBenchmark.benchmark45(-512.8236815320085,-255.90350387960723,33.39867728886671 ) ;
  }

  @Test
  public void test2586() {
    coral.tests.JPFBenchmark.benchmark45(-512.9464075782478,-250.29361827381345,100.0 ) ;
  }

  @Test
  public void test2587() {
    coral.tests.JPFBenchmark.benchmark45(-512.9852578357744,-252.7843870746185,100.0 ) ;
  }

  @Test
  public void test2588() {
    coral.tests.JPFBenchmark.benchmark45(-513.2010023915585,-316.1481906123626,95.18663476321885 ) ;
  }

  @Test
  public void test2589() {
    coral.tests.JPFBenchmark.benchmark45(-513.220623586788,-233.41812657586541,100.0 ) ;
  }

  @Test
  public void test2590() {
    coral.tests.JPFBenchmark.benchmark45(-513.3855305848832,-261.86185642149,89.99600656029872 ) ;
  }

  @Test
  public void test2591() {
    coral.tests.JPFBenchmark.benchmark45(-513.6208175289362,-254.02634250696147,80.43843987708905 ) ;
  }

  @Test
  public void test2592() {
    coral.tests.JPFBenchmark.benchmark45(-513.868880578678,-244.69764085804934,82.75036336471709 ) ;
  }

  @Test
  public void test2593() {
    coral.tests.JPFBenchmark.benchmark45(-514.1216267101693,-284.8994909769884,-0.0018151168932078326 ) ;
  }

  @Test
  public void test2594() {
    coral.tests.JPFBenchmark.benchmark45(-514.3016135654416,-233.44495822621627,7.2703129690926005 ) ;
  }

  @Test
  public void test2595() {
    coral.tests.JPFBenchmark.benchmark45(-514.3971633414999,-275.7123409037312,100.0 ) ;
  }

  @Test
  public void test2596() {
    coral.tests.JPFBenchmark.benchmark45(-514.8151087487631,-271.4108906695727,55.726445920289024 ) ;
  }

  @Test
  public void test2597() {
    coral.tests.JPFBenchmark.benchmark45(-514.8538279837251,-240.19177843841823,28.04891743892952 ) ;
  }

  @Test
  public void test2598() {
    coral.tests.JPFBenchmark.benchmark45(-515.0470769938146,-290.81025811255154,58.33084170379871 ) ;
  }

  @Test
  public void test2599() {
    coral.tests.JPFBenchmark.benchmark45(-515.0603008574759,-238.96177794106552,78.2558935857983 ) ;
  }

  @Test
  public void test2600() {
    coral.tests.JPFBenchmark.benchmark45(-515.111881703296,-249.63931674629876,48.42207678065614 ) ;
  }

  @Test
  public void test2601() {
    coral.tests.JPFBenchmark.benchmark45(-515.3825427860114,-236.46852273531087,21.063044669986056 ) ;
  }

  @Test
  public void test2602() {
    coral.tests.JPFBenchmark.benchmark45(-515.6343032249828,-324.8327019938237,59.67118185398177 ) ;
  }

  @Test
  public void test2603() {
    coral.tests.JPFBenchmark.benchmark45(-515.6792909070258,-242.61308239592208,0.3462592792063788 ) ;
  }

  @Test
  public void test2604() {
    coral.tests.JPFBenchmark.benchmark45(-515.9389788811428,-293.8820399264983,86.18792984801493 ) ;
  }

  @Test
  public void test2605() {
    coral.tests.JPFBenchmark.benchmark45(-516.0066413847128,-277.66204192503653,60.59308665091613 ) ;
  }

  @Test
  public void test2606() {
    coral.tests.JPFBenchmark.benchmark45(-516.1847539830479,-284.8679300981285,22.414806843301903 ) ;
  }

  @Test
  public void test2607() {
    coral.tests.JPFBenchmark.benchmark45(-516.2471614429481,-236.53141837383652,35.17620246305751 ) ;
  }

  @Test
  public void test2608() {
    coral.tests.JPFBenchmark.benchmark45(-516.251925313195,-284.02311205693644,0 ) ;
  }

  @Test
  public void test2609() {
    coral.tests.JPFBenchmark.benchmark45(-516.3055221323498,-253.0332210869985,31.719979651894647 ) ;
  }

  @Test
  public void test2610() {
    coral.tests.JPFBenchmark.benchmark45(-516.388120260008,-245.5667451316299,65.82303107641144 ) ;
  }

  @Test
  public void test2611() {
    coral.tests.JPFBenchmark.benchmark45(-516.4491030750041,-261.17040583934556,60.89929843900259 ) ;
  }

  @Test
  public void test2612() {
    coral.tests.JPFBenchmark.benchmark45(-516.4616761820786,-281.4568250589881,63.20732935229353 ) ;
  }

  @Test
  public void test2613() {
    coral.tests.JPFBenchmark.benchmark45(-516.6786967663214,-267.0708808180383,66.31816935012515 ) ;
  }

  @Test
  public void test2614() {
    coral.tests.JPFBenchmark.benchmark45(-516.7443199609635,-241.93503808086328,83.49749539591568 ) ;
  }

  @Test
  public void test2615() {
    coral.tests.JPFBenchmark.benchmark45(-516.8996192128451,-264.87100616863165,54.49368731737388 ) ;
  }

  @Test
  public void test2616() {
    coral.tests.JPFBenchmark.benchmark45(-516.986911572038,-247.26453828490816,84.73278063707858 ) ;
  }

  @Test
  public void test2617() {
    coral.tests.JPFBenchmark.benchmark45(-517.0345883394423,-230.73437915240694,100.0 ) ;
  }

  @Test
  public void test2618() {
    coral.tests.JPFBenchmark.benchmark45(-517.0767974285811,-256.2851200775837,69.305721100563 ) ;
  }

  @Test
  public void test2619() {
    coral.tests.JPFBenchmark.benchmark45(-517.1682311093551,-256.54481331997584,17.246879172849166 ) ;
  }

  @Test
  public void test2620() {
    coral.tests.JPFBenchmark.benchmark45(-517.3350453915273,-230.53776608572497,91.31815086561085 ) ;
  }

  @Test
  public void test2621() {
    coral.tests.JPFBenchmark.benchmark45(-517.3444334129906,-247.58309800124238,87.72884704609118 ) ;
  }

  @Test
  public void test2622() {
    coral.tests.JPFBenchmark.benchmark45(-51.75737071673778,-707.645289237209,49.88991532223773 ) ;
  }

  @Test
  public void test2623() {
    coral.tests.JPFBenchmark.benchmark45(-517.5904046575056,-237.9208050244734,100.0 ) ;
  }

  @Test
  public void test2624() {
    coral.tests.JPFBenchmark.benchmark45(-517.6220852828149,-229.10996177823532,94.17601720666568 ) ;
  }

  @Test
  public void test2625() {
    coral.tests.JPFBenchmark.benchmark45(-517.6830940969667,-253.56420331705453,38.27106719599175 ) ;
  }

  @Test
  public void test2626() {
    coral.tests.JPFBenchmark.benchmark45(-517.7409198706813,-291.5985162565738,48.049867945745206 ) ;
  }

  @Test
  public void test2627() {
    coral.tests.JPFBenchmark.benchmark45(-518.14610688922,-242.71324909277038,13.77854266060261 ) ;
  }

  @Test
  public void test2628() {
    coral.tests.JPFBenchmark.benchmark45(-518.2043420604165,-311.40757867237824,27.641647752700635 ) ;
  }

  @Test
  public void test2629() {
    coral.tests.JPFBenchmark.benchmark45(-518.7158921081897,-270.6546467066011,37.737678006852605 ) ;
  }

  @Test
  public void test2630() {
    coral.tests.JPFBenchmark.benchmark45(-518.9493097754664,-236.85315997002257,3.526139406000439 ) ;
  }

  @Test
  public void test2631() {
    coral.tests.JPFBenchmark.benchmark45(-519.01333004805,-255.8540915990746,4.712161253334514 ) ;
  }

  @Test
  public void test2632() {
    coral.tests.JPFBenchmark.benchmark45(-519.1324572242216,-257.914671060489,70.29238643391466 ) ;
  }

  @Test
  public void test2633() {
    coral.tests.JPFBenchmark.benchmark45(-519.187212620786,-256.5412861147559,17.41611483031207 ) ;
  }

  @Test
  public void test2634() {
    coral.tests.JPFBenchmark.benchmark45(-519.2729497660013,-276.56315268306776,73.44782634159054 ) ;
  }

  @Test
  public void test2635() {
    coral.tests.JPFBenchmark.benchmark45(-519.2735615370298,-295.00589501126177,31.849240510189645 ) ;
  }

  @Test
  public void test2636() {
    coral.tests.JPFBenchmark.benchmark45(-519.4200563074698,-277.191703971188,84.29796894060661 ) ;
  }

  @Test
  public void test2637() {
    coral.tests.JPFBenchmark.benchmark45(-519.7204202112022,-252.6030848127279,39.90207570360283 ) ;
  }

  @Test
  public void test2638() {
    coral.tests.JPFBenchmark.benchmark45(-519.7720062034991,-304.4149337742261,0.0 ) ;
  }

  @Test
  public void test2639() {
    coral.tests.JPFBenchmark.benchmark45(-519.9660138222611,-261.3106682549128,20.168996654695377 ) ;
  }

  @Test
  public void test2640() {
    coral.tests.JPFBenchmark.benchmark45(-519.9965724986287,-242.64854029412277,34.929067848480145 ) ;
  }

  @Test
  public void test2641() {
    coral.tests.JPFBenchmark.benchmark45(-520.2820225445666,-234.85631052780082,56.989584612629386 ) ;
  }

  @Test
  public void test2642() {
    coral.tests.JPFBenchmark.benchmark45(-520.3688515727891,-236.09746619800706,100.0 ) ;
  }

  @Test
  public void test2643() {
    coral.tests.JPFBenchmark.benchmark45(-520.4706112235912,-261.0656012821496,64.86245318081279 ) ;
  }

  @Test
  public void test2644() {
    coral.tests.JPFBenchmark.benchmark45(-520.4857436340516,-250.35213177179648,57.566124639223204 ) ;
  }

  @Test
  public void test2645() {
    coral.tests.JPFBenchmark.benchmark45(-520.8794816406639,-317.6548455363103,4.3558616989933086 ) ;
  }

  @Test
  public void test2646() {
    coral.tests.JPFBenchmark.benchmark45(-520.9168305106333,-261.8979251569942,24.313592262390074 ) ;
  }

  @Test
  public void test2647() {
    coral.tests.JPFBenchmark.benchmark45(-521.0186086166318,-225.28973648291554,44.35360887352405 ) ;
  }

  @Test
  public void test2648() {
    coral.tests.JPFBenchmark.benchmark45(-521.0930704000386,-251.74660325570522,51.06457892667888 ) ;
  }

  @Test
  public void test2649() {
    coral.tests.JPFBenchmark.benchmark45(-521.1333021588129,-253.14948527449732,79.66142358536595 ) ;
  }

  @Test
  public void test2650() {
    coral.tests.JPFBenchmark.benchmark45(-521.6629852875526,-247.08218783196313,65.16851186730653 ) ;
  }

  @Test
  public void test2651() {
    coral.tests.JPFBenchmark.benchmark45(-521.7134598157044,-249.3430360586645,7.192709787472197 ) ;
  }

  @Test
  public void test2652() {
    coral.tests.JPFBenchmark.benchmark45(-521.7638173101903,-285.4715447468968,40.538221978642355 ) ;
  }

  @Test
  public void test2653() {
    coral.tests.JPFBenchmark.benchmark45(-521.8823663100428,-232.42958208849782,48.91834874414852 ) ;
  }

  @Test
  public void test2654() {
    coral.tests.JPFBenchmark.benchmark45(-522.1553683180309,-252.28361726450964,12.075660544470253 ) ;
  }

  @Test
  public void test2655() {
    coral.tests.JPFBenchmark.benchmark45(-522.7026024946427,-252.25922392650662,95.20121881683582 ) ;
  }

  @Test
  public void test2656() {
    coral.tests.JPFBenchmark.benchmark45(-523.1737608679448,-233.2490724736748,18.875468652021226 ) ;
  }

  @Test
  public void test2657() {
    coral.tests.JPFBenchmark.benchmark45(-523.2672741169272,-243.94739303054683,11.228346056583916 ) ;
  }

  @Test
  public void test2658() {
    coral.tests.JPFBenchmark.benchmark45(-523.4820330095764,-246.78996327607305,63.10018512457518 ) ;
  }

  @Test
  public void test2659() {
    coral.tests.JPFBenchmark.benchmark45(-523.5551432996284,-234.50188791126303,32.775894824666665 ) ;
  }

  @Test
  public void test2660() {
    coral.tests.JPFBenchmark.benchmark45(-523.7054596570313,-223.93399482449024,79.249535780165 ) ;
  }

  @Test
  public void test2661() {
    coral.tests.JPFBenchmark.benchmark45(-523.8768383309914,-251.70891183995113,7.222057492988057 ) ;
  }

  @Test
  public void test2662() {
    coral.tests.JPFBenchmark.benchmark45(-523.9521931811619,-230.00420723026653,49.12767696919164 ) ;
  }

  @Test
  public void test2663() {
    coral.tests.JPFBenchmark.benchmark45(-524.1680035957168,-293.2119561535186,20.633230013994464 ) ;
  }

  @Test
  public void test2664() {
    coral.tests.JPFBenchmark.benchmark45(-524.3807562293651,-254.46040979755927,2.613339589274469 ) ;
  }

  @Test
  public void test2665() {
    coral.tests.JPFBenchmark.benchmark45(-524.6192526738295,-284.6150410419626,17.613640312254006 ) ;
  }

  @Test
  public void test2666() {
    coral.tests.JPFBenchmark.benchmark45(-524.9568695351272,-273.89126253445863,97.25786939779834 ) ;
  }

  @Test
  public void test2667() {
    coral.tests.JPFBenchmark.benchmark45(-524.990394312761,-289.77377685767885,33.04302348359781 ) ;
  }

  @Test
  public void test2668() {
    coral.tests.JPFBenchmark.benchmark45(-525.0997528080601,-245.20310642114688,59.514733584199746 ) ;
  }

  @Test
  public void test2669() {
    coral.tests.JPFBenchmark.benchmark45(-525.2734422180295,-292.9498083732852,70.56986772236772 ) ;
  }

  @Test
  public void test2670() {
    coral.tests.JPFBenchmark.benchmark45(-525.680753753207,-221.31555792475217,35.751226882280946 ) ;
  }

  @Test
  public void test2671() {
    coral.tests.JPFBenchmark.benchmark45(-525.9651918532024,-254.146240623889,55.82124140129005 ) ;
  }

  @Test
  public void test2672() {
    coral.tests.JPFBenchmark.benchmark45(-525.9821531834998,-245.45928620920787,62.93931169751511 ) ;
  }

  @Test
  public void test2673() {
    coral.tests.JPFBenchmark.benchmark45(-526.0792920799609,-225.90126263917944,28.36555306091767 ) ;
  }

  @Test
  public void test2674() {
    coral.tests.JPFBenchmark.benchmark45(-526.1346740191076,-262.4573065963182,30.75053929237498 ) ;
  }

  @Test
  public void test2675() {
    coral.tests.JPFBenchmark.benchmark45(-526.19868892958,-250.05146227201232,15.21520979944222 ) ;
  }

  @Test
  public void test2676() {
    coral.tests.JPFBenchmark.benchmark45(-526.2917226617218,-226.86695991657552,32.406578170129535 ) ;
  }

  @Test
  public void test2677() {
    coral.tests.JPFBenchmark.benchmark45(-526.9952643249419,-221.7033834724118,15.982910995526225 ) ;
  }

  @Test
  public void test2678() {
    coral.tests.JPFBenchmark.benchmark45(-527.6385647990325,-232.94342122494018,59.39940313510414 ) ;
  }

  @Test
  public void test2679() {
    coral.tests.JPFBenchmark.benchmark45(-527.6444980327959,-250.9947653751082,5.225015796384795 ) ;
  }

  @Test
  public void test2680() {
    coral.tests.JPFBenchmark.benchmark45(-527.6484993784846,-233.4497530498078,57.333704478244385 ) ;
  }

  @Test
  public void test2681() {
    coral.tests.JPFBenchmark.benchmark45(-527.9848081415543,-230.81800333197097,72.9963010551146 ) ;
  }

  @Test
  public void test2682() {
    coral.tests.JPFBenchmark.benchmark45(-528.0365977326827,-264.1830160501983,32.08748521386369 ) ;
  }

  @Test
  public void test2683() {
    coral.tests.JPFBenchmark.benchmark45(-528.1196942161656,-260.1233032502174,73.59750999887785 ) ;
  }

  @Test
  public void test2684() {
    coral.tests.JPFBenchmark.benchmark45(-528.1322333075948,-218.08648419815563,14.599166534181336 ) ;
  }

  @Test
  public void test2685() {
    coral.tests.JPFBenchmark.benchmark45(-528.4601283026417,-223.91349098661283,90.99219418249294 ) ;
  }

  @Test
  public void test2686() {
    coral.tests.JPFBenchmark.benchmark45(-529.0473518356913,-222.98768851054345,11.513400259518974 ) ;
  }

  @Test
  public void test2687() {
    coral.tests.JPFBenchmark.benchmark45(-529.2796143167011,-273.1006024115182,52.89833356863289 ) ;
  }

  @Test
  public void test2688() {
    coral.tests.JPFBenchmark.benchmark45(-529.3541702797714,-291.32895919874255,14.566181228417236 ) ;
  }

  @Test
  public void test2689() {
    coral.tests.JPFBenchmark.benchmark45(-529.4230260845516,-222.49247604586066,35.04042536458542 ) ;
  }

  @Test
  public void test2690() {
    coral.tests.JPFBenchmark.benchmark45(-529.5417981601983,-246.93849842518222,29.10770123049349 ) ;
  }

  @Test
  public void test2691() {
    coral.tests.JPFBenchmark.benchmark45(-529.59484747258,-279.28596023814544,10.753856442515199 ) ;
  }

  @Test
  public void test2692() {
    coral.tests.JPFBenchmark.benchmark45(-529.6799786149227,-306.1617218896832,60.73202149382152 ) ;
  }

  @Test
  public void test2693() {
    coral.tests.JPFBenchmark.benchmark45(-529.7506303077832,-279.3159862705889,89.44503132478772 ) ;
  }

  @Test
  public void test2694() {
    coral.tests.JPFBenchmark.benchmark45(-53.0082325280788,-748.3876164840992,85.8438858935898 ) ;
  }

  @Test
  public void test2695() {
    coral.tests.JPFBenchmark.benchmark45(-530.1386456324296,-276.07684540338147,68.9121549079357 ) ;
  }

  @Test
  public void test2696() {
    coral.tests.JPFBenchmark.benchmark45(-530.337282053353,-232.77209339257348,63.71182838104659 ) ;
  }

  @Test
  public void test2697() {
    coral.tests.JPFBenchmark.benchmark45(-530.3544071006908,-222.3154193583564,69.27352767371903 ) ;
  }

  @Test
  public void test2698() {
    coral.tests.JPFBenchmark.benchmark45(-530.7485130415819,-219.51629496254782,34.770504423992946 ) ;
  }

  @Test
  public void test2699() {
    coral.tests.JPFBenchmark.benchmark45(-531.00935398234,-228.40177483276568,19.221964756690554 ) ;
  }

  @Test
  public void test2700() {
    coral.tests.JPFBenchmark.benchmark45(-531.2003508983925,-235.59904240417526,35.299584507157476 ) ;
  }

  @Test
  public void test2701() {
    coral.tests.JPFBenchmark.benchmark45(-531.3392804468888,-277.0685547843736,100.0 ) ;
  }

  @Test
  public void test2702() {
    coral.tests.JPFBenchmark.benchmark45(-531.3987099770533,-276.3755723460654,28.454324428779586 ) ;
  }

  @Test
  public void test2703() {
    coral.tests.JPFBenchmark.benchmark45(-531.4879070724207,-215.982789753698,24.979079165905247 ) ;
  }

  @Test
  public void test2704() {
    coral.tests.JPFBenchmark.benchmark45(-531.8133126257784,-279.82480259444253,64.93116794713083 ) ;
  }

  @Test
  public void test2705() {
    coral.tests.JPFBenchmark.benchmark45(-531.9548440405714,-240.89548964186667,70.2540250362477 ) ;
  }

  @Test
  public void test2706() {
    coral.tests.JPFBenchmark.benchmark45(-532.1638283263122,-311.44599978764484,30.024158427531518 ) ;
  }

  @Test
  public void test2707() {
    coral.tests.JPFBenchmark.benchmark45(-532.2455213189648,-257.5385932220038,52.263454448743886 ) ;
  }

  @Test
  public void test2708() {
    coral.tests.JPFBenchmark.benchmark45(-532.3197731186515,-264.90986246458283,94.6143318901924 ) ;
  }

  @Test
  public void test2709() {
    coral.tests.JPFBenchmark.benchmark45(-532.6548062017981,-224.5927325731019,9.265511917026444 ) ;
  }

  @Test
  public void test2710() {
    coral.tests.JPFBenchmark.benchmark45(-532.7302056782005,-293.75906713405743,1.2377669014288983 ) ;
  }

  @Test
  public void test2711() {
    coral.tests.JPFBenchmark.benchmark45(-533.4345850280042,-262.86995431837994,2.4811146542595566 ) ;
  }

  @Test
  public void test2712() {
    coral.tests.JPFBenchmark.benchmark45(-533.584208211443,-282.317458359716,5.674792195344125 ) ;
  }

  @Test
  public void test2713() {
    coral.tests.JPFBenchmark.benchmark45(-533.7174510420812,-265.08802345762695,9.248335466283535 ) ;
  }

  @Test
  public void test2714() {
    coral.tests.JPFBenchmark.benchmark45(-533.9501734327002,-226.17064025229655,68.81965841501051 ) ;
  }

  @Test
  public void test2715() {
    coral.tests.JPFBenchmark.benchmark45(-533.9820655962968,-254.70035031708207,46.61577519287188 ) ;
  }

  @Test
  public void test2716() {
    coral.tests.JPFBenchmark.benchmark45(-534.1225594421124,-247.18217286126318,91.26604873915173 ) ;
  }

  @Test
  public void test2717() {
    coral.tests.JPFBenchmark.benchmark45(-534.2275507701895,-215.70939368469857,41.105547702277875 ) ;
  }

  @Test
  public void test2718() {
    coral.tests.JPFBenchmark.benchmark45(-534.3168031159164,-267.00136291106594,58.53907442027577 ) ;
  }

  @Test
  public void test2719() {
    coral.tests.JPFBenchmark.benchmark45(-534.3676821154017,-270.5645723977081,49.26785595183466 ) ;
  }

  @Test
  public void test2720() {
    coral.tests.JPFBenchmark.benchmark45(-534.4740132592251,-220.27291365885597,20.18823680945472 ) ;
  }

  @Test
  public void test2721() {
    coral.tests.JPFBenchmark.benchmark45(-534.5163889320677,-220.44346523538604,53.57752177719311 ) ;
  }

  @Test
  public void test2722() {
    coral.tests.JPFBenchmark.benchmark45(-535.0081856130927,-214.68213499090837,89.93455734539245 ) ;
  }

  @Test
  public void test2723() {
    coral.tests.JPFBenchmark.benchmark45(-535.1203327826768,-259.55356704381893,41.7635069658009 ) ;
  }

  @Test
  public void test2724() {
    coral.tests.JPFBenchmark.benchmark45(-535.3191339833414,-239.80738161115414,65.93578429347774 ) ;
  }

  @Test
  public void test2725() {
    coral.tests.JPFBenchmark.benchmark45(-535.8189949485266,-259.82631068529,0 ) ;
  }

  @Test
  public void test2726() {
    coral.tests.JPFBenchmark.benchmark45(-535.865394929728,-218.6854425331791,84.93807412482502 ) ;
  }

  @Test
  public void test2727() {
    coral.tests.JPFBenchmark.benchmark45(-535.9551370556989,-340.33039308551156,70.31346566049302 ) ;
  }

  @Test
  public void test2728() {
    coral.tests.JPFBenchmark.benchmark45(-535.9927516261406,-244.58490539152956,71.24175781731566 ) ;
  }

  @Test
  public void test2729() {
    coral.tests.JPFBenchmark.benchmark45(-536.0428497942884,-245.59831984488793,46.510375131717694 ) ;
  }

  @Test
  public void test2730() {
    coral.tests.JPFBenchmark.benchmark45(-536.0881181018215,-251.137728170338,32.023970640111685 ) ;
  }

  @Test
  public void test2731() {
    coral.tests.JPFBenchmark.benchmark45(-536.5805596787279,-268.83192612226503,46.29320798482857 ) ;
  }

  @Test
  public void test2732() {
    coral.tests.JPFBenchmark.benchmark45(-536.6007649821042,-209.4819886812787,54.96322199792186 ) ;
  }

  @Test
  public void test2733() {
    coral.tests.JPFBenchmark.benchmark45(-536.6515293604467,-271.4869000702175,17.65893765914099 ) ;
  }

  @Test
  public void test2734() {
    coral.tests.JPFBenchmark.benchmark45(-536.7652613648953,-236.80235595851175,41.923622078383545 ) ;
  }

  @Test
  public void test2735() {
    coral.tests.JPFBenchmark.benchmark45(-536.9497885296576,-307.1233295848377,100.0 ) ;
  }

  @Test
  public void test2736() {
    coral.tests.JPFBenchmark.benchmark45(-537.0771703750477,-221.47171662052386,18.750931112754884 ) ;
  }

  @Test
  public void test2737() {
    coral.tests.JPFBenchmark.benchmark45(-537.1493891379995,-215.82918540205486,81.40678325073418 ) ;
  }

  @Test
  public void test2738() {
    coral.tests.JPFBenchmark.benchmark45(-537.2039478644745,-216.80435244130246,5.7433638250449945 ) ;
  }

  @Test
  public void test2739() {
    coral.tests.JPFBenchmark.benchmark45(-537.2950786714117,-267.6297442760501,66.12426799332833 ) ;
  }

  @Test
  public void test2740() {
    coral.tests.JPFBenchmark.benchmark45(-537.3620781385384,-225.90938996080862,32.150367586232676 ) ;
  }

  @Test
  public void test2741() {
    coral.tests.JPFBenchmark.benchmark45(-537.3663062255749,-218.52015887204047,42.47902595529274 ) ;
  }

  @Test
  public void test2742() {
    coral.tests.JPFBenchmark.benchmark45(-537.4825269769867,-266.1673589973101,17.62064983969698 ) ;
  }

  @Test
  public void test2743() {
    coral.tests.JPFBenchmark.benchmark45(-537.7601282241186,-221.8548569356039,69.37371678642529 ) ;
  }

  @Test
  public void test2744() {
    coral.tests.JPFBenchmark.benchmark45(-537.7933612021375,-218.05743410202692,100.0 ) ;
  }

  @Test
  public void test2745() {
    coral.tests.JPFBenchmark.benchmark45(-537.8486767723834,-332.129057934697,74.45805379237277 ) ;
  }

  @Test
  public void test2746() {
    coral.tests.JPFBenchmark.benchmark45(-538.0523147862272,-214.9394809965372,100.0 ) ;
  }

  @Test
  public void test2747() {
    coral.tests.JPFBenchmark.benchmark45(-538.4284514805593,-237.52266471161616,30.500053380250485 ) ;
  }

  @Test
  public void test2748() {
    coral.tests.JPFBenchmark.benchmark45(-538.4673237183806,-255.89339017323275,30.654749301335187 ) ;
  }

  @Test
  public void test2749() {
    coral.tests.JPFBenchmark.benchmark45(-538.6141898153779,-231.00754432839423,65.30958639225335 ) ;
  }

  @Test
  public void test2750() {
    coral.tests.JPFBenchmark.benchmark45(-538.6336009670326,-234.7632405387514,35.23820609721449 ) ;
  }

  @Test
  public void test2751() {
    coral.tests.JPFBenchmark.benchmark45(-538.8706475547139,-251.36336926204788,3.19117082976112 ) ;
  }

  @Test
  public void test2752() {
    coral.tests.JPFBenchmark.benchmark45(-539.0204465235507,-220.88509333822202,28.51297509282297 ) ;
  }

  @Test
  public void test2753() {
    coral.tests.JPFBenchmark.benchmark45(-539.2376891368262,-243.1264446384532,100.0 ) ;
  }

  @Test
  public void test2754() {
    coral.tests.JPFBenchmark.benchmark45(-539.3307446061937,-292.89174822003355,17.796187583077966 ) ;
  }

  @Test
  public void test2755() {
    coral.tests.JPFBenchmark.benchmark45(-539.4728282677568,-250.30914620310966,73.69215973553088 ) ;
  }

  @Test
  public void test2756() {
    coral.tests.JPFBenchmark.benchmark45(-539.562580285405,-223.28866261547586,100.0 ) ;
  }

  @Test
  public void test2757() {
    coral.tests.JPFBenchmark.benchmark45(-539.7847042403282,-251.04230519017403,73.15832068237626 ) ;
  }

  @Test
  public void test2758() {
    coral.tests.JPFBenchmark.benchmark45(-540.2525254124704,-220.1142239859492,42.435191726705625 ) ;
  }

  @Test
  public void test2759() {
    coral.tests.JPFBenchmark.benchmark45(-540.2536214038821,-231.46100870013012,80.62675595791885 ) ;
  }

  @Test
  public void test2760() {
    coral.tests.JPFBenchmark.benchmark45(-540.3483029775934,-209.9962847144631,99.04951575933015 ) ;
  }

  @Test
  public void test2761() {
    coral.tests.JPFBenchmark.benchmark45(-540.4158068643754,-223.075622280281,16.162760151805003 ) ;
  }

  @Test
  public void test2762() {
    coral.tests.JPFBenchmark.benchmark45(-542.0842124889122,-237.6550973555184,37.21115598832901 ) ;
  }

  @Test
  public void test2763() {
    coral.tests.JPFBenchmark.benchmark45(-542.2398874408292,-209.1312333250697,85.45111823979946 ) ;
  }

  @Test
  public void test2764() {
    coral.tests.JPFBenchmark.benchmark45(-542.5347979150367,-252.81553034446534,23.725942239119064 ) ;
  }

  @Test
  public void test2765() {
    coral.tests.JPFBenchmark.benchmark45(-542.7988018397787,-213.3694071816941,30.26136908809619 ) ;
  }

  @Test
  public void test2766() {
    coral.tests.JPFBenchmark.benchmark45(-542.9030400194304,-236.11509082021735,7.105427357601002E-15 ) ;
  }

  @Test
  public void test2767() {
    coral.tests.JPFBenchmark.benchmark45(-543.4063131906827,-222.2578177301915,13.086264038200369 ) ;
  }

  @Test
  public void test2768() {
    coral.tests.JPFBenchmark.benchmark45(-543.4403441051422,-296.3849209987124,59.422091710065104 ) ;
  }

  @Test
  public void test2769() {
    coral.tests.JPFBenchmark.benchmark45(-543.4561920735364,-207.47510319799173,75.83527161384174 ) ;
  }

  @Test
  public void test2770() {
    coral.tests.JPFBenchmark.benchmark45(-543.4568246757468,-230.1600651897632,20.471613778337527 ) ;
  }

  @Test
  public void test2771() {
    coral.tests.JPFBenchmark.benchmark45(-543.5039815506371,-229.20508276959345,22.24825782037047 ) ;
  }

  @Test
  public void test2772() {
    coral.tests.JPFBenchmark.benchmark45(-543.9573928602449,-234.47328038353822,10.17183447207637 ) ;
  }

  @Test
  public void test2773() {
    coral.tests.JPFBenchmark.benchmark45(-544.2874378032269,-230.26834815213567,73.58220977679306 ) ;
  }

  @Test
  public void test2774() {
    coral.tests.JPFBenchmark.benchmark45(-544.4362580829197,-244.505115376346,100.0 ) ;
  }

  @Test
  public void test2775() {
    coral.tests.JPFBenchmark.benchmark45(-544.57773785773,-238.57245569061826,85.66250655694964 ) ;
  }

  @Test
  public void test2776() {
    coral.tests.JPFBenchmark.benchmark45(-544.9049516387415,-201.30141357121374,30.275010623590447 ) ;
  }

  @Test
  public void test2777() {
    coral.tests.JPFBenchmark.benchmark45(-544.9945576936974,-284.43046671854455,46.694124052736754 ) ;
  }

  @Test
  public void test2778() {
    coral.tests.JPFBenchmark.benchmark45(-545.1764395864236,-226.99181673634243,69.98971189003095 ) ;
  }

  @Test
  public void test2779() {
    coral.tests.JPFBenchmark.benchmark45(-545.5624099750411,-202.9268475960147,13.265284430390366 ) ;
  }

  @Test
  public void test2780() {
    coral.tests.JPFBenchmark.benchmark45(-545.5720380619234,-238.315426513111,45.65629663176898 ) ;
  }

  @Test
  public void test2781() {
    coral.tests.JPFBenchmark.benchmark45(-545.6176889498681,-203.91820188737364,92.57350563387034 ) ;
  }

  @Test
  public void test2782() {
    coral.tests.JPFBenchmark.benchmark45(-545.6445211413875,-259.6944763379413,67.70130136704356 ) ;
  }

  @Test
  public void test2783() {
    coral.tests.JPFBenchmark.benchmark45(-545.8467410400991,-204.49635141436693,83.06881933363249 ) ;
  }

  @Test
  public void test2784() {
    coral.tests.JPFBenchmark.benchmark45(-546.0993171381426,-276.58413034375275,98.64757601218955 ) ;
  }

  @Test
  public void test2785() {
    coral.tests.JPFBenchmark.benchmark45(-546.2157602180866,-245.64876108690638,95.3031968335076 ) ;
  }

  @Test
  public void test2786() {
    coral.tests.JPFBenchmark.benchmark45(-546.2919912689877,-209.86691370259516,71.87376330530344 ) ;
  }

  @Test
  public void test2787() {
    coral.tests.JPFBenchmark.benchmark45(-546.558420747747,-205.30834650542732,41.134598977397445 ) ;
  }

  @Test
  public void test2788() {
    coral.tests.JPFBenchmark.benchmark45(-546.8577323710897,-199.1989412214619,5.541834524947149 ) ;
  }

  @Test
  public void test2789() {
    coral.tests.JPFBenchmark.benchmark45(-547.1697569471457,-222.51665592500956,45.89903707042225 ) ;
  }

  @Test
  public void test2790() {
    coral.tests.JPFBenchmark.benchmark45(-547.5760681881899,-210.36578985478928,96.18170232413078 ) ;
  }

  @Test
  public void test2791() {
    coral.tests.JPFBenchmark.benchmark45(-547.6575594035907,-199.69599644656387,18.7602166551694 ) ;
  }

  @Test
  public void test2792() {
    coral.tests.JPFBenchmark.benchmark45(-547.8748830952946,-260.3962663783731,100.0 ) ;
  }

  @Test
  public void test2793() {
    coral.tests.JPFBenchmark.benchmark45(-548.4582951428265,-218.20940086405375,100.0 ) ;
  }

  @Test
  public void test2794() {
    coral.tests.JPFBenchmark.benchmark45(-548.7983560447768,-212.45835180984307,18.811523462084523 ) ;
  }

  @Test
  public void test2795() {
    coral.tests.JPFBenchmark.benchmark45(-548.8592672968982,-288.74930148498873,100.0 ) ;
  }

  @Test
  public void test2796() {
    coral.tests.JPFBenchmark.benchmark45(-549.0538698611397,-206.8975587488534,77.29728999320267 ) ;
  }

  @Test
  public void test2797() {
    coral.tests.JPFBenchmark.benchmark45(-549.0934570448707,-243.98287238926457,31.875458297440076 ) ;
  }

  @Test
  public void test2798() {
    coral.tests.JPFBenchmark.benchmark45(-549.1338491760685,-201.94316580105692,100.0 ) ;
  }

  @Test
  public void test2799() {
    coral.tests.JPFBenchmark.benchmark45(-549.5807165366559,-224.17535258995193,81.96492637681163 ) ;
  }

  @Test
  public void test2800() {
    coral.tests.JPFBenchmark.benchmark45(-549.7311468839074,-198.00547870475302,91.74308212186705 ) ;
  }

  @Test
  public void test2801() {
    coral.tests.JPFBenchmark.benchmark45(-549.8263827099743,-203.2411606874513,100.0 ) ;
  }

  @Test
  public void test2802() {
    coral.tests.JPFBenchmark.benchmark45(-550.4792565221655,-195.53160818742262,33.24875513117709 ) ;
  }

  @Test
  public void test2803() {
    coral.tests.JPFBenchmark.benchmark45(-550.4944929560422,-196.11628172944611,18.688331296322147 ) ;
  }

  @Test
  public void test2804() {
    coral.tests.JPFBenchmark.benchmark45(-550.6262523138917,-196.25976865055725,74.84137793148341 ) ;
  }

  @Test
  public void test2805() {
    coral.tests.JPFBenchmark.benchmark45(-550.8176183334795,-198.76518878207258,58.66565239707637 ) ;
  }

  @Test
  public void test2806() {
    coral.tests.JPFBenchmark.benchmark45(-551.2587704375433,-195.7398848121228,100.0 ) ;
  }

  @Test
  public void test2807() {
    coral.tests.JPFBenchmark.benchmark45(-551.2705034906924,-206.08712503104854,14.195181722761859 ) ;
  }

  @Test
  public void test2808() {
    coral.tests.JPFBenchmark.benchmark45(-551.3909268386456,-215.39581526451593,57.93300599494057 ) ;
  }

  @Test
  public void test2809() {
    coral.tests.JPFBenchmark.benchmark45(-551.499213254842,-208.72254587306713,34.627837688110645 ) ;
  }

  @Test
  public void test2810() {
    coral.tests.JPFBenchmark.benchmark45(-551.8315109492844,-205.77027591939515,50.605241432845816 ) ;
  }

  @Test
  public void test2811() {
    coral.tests.JPFBenchmark.benchmark45(-551.907671607608,-242.5231703745089,100.0 ) ;
  }

  @Test
  public void test2812() {
    coral.tests.JPFBenchmark.benchmark45(-551.9621966288257,-200.7205169197444,100.0 ) ;
  }

  @Test
  public void test2813() {
    coral.tests.JPFBenchmark.benchmark45(-552.1234190280937,-220.6397211822853,69.39041096210141 ) ;
  }

  @Test
  public void test2814() {
    coral.tests.JPFBenchmark.benchmark45(-552.7912119915643,-193.81374251437165,50.20246501993441 ) ;
  }

  @Test
  public void test2815() {
    coral.tests.JPFBenchmark.benchmark45(-552.9127408904595,-197.25444845287822,100.0 ) ;
  }

  @Test
  public void test2816() {
    coral.tests.JPFBenchmark.benchmark45(-552.9368924281889,-199.01514357693614,90.47847940513734 ) ;
  }

  @Test
  public void test2817() {
    coral.tests.JPFBenchmark.benchmark45(-552.9468933155762,-228.96363912281717,69.56840954498017 ) ;
  }

  @Test
  public void test2818() {
    coral.tests.JPFBenchmark.benchmark45(-553.3471787695095,-261.09204584556386,31.71927350106006 ) ;
  }

  @Test
  public void test2819() {
    coral.tests.JPFBenchmark.benchmark45(-553.4134703305983,-247.32586830732612,12.144119773668862 ) ;
  }

  @Test
  public void test2820() {
    coral.tests.JPFBenchmark.benchmark45(-553.5976192686828,-198.76606324297978,27.063853332435016 ) ;
  }

  @Test
  public void test2821() {
    coral.tests.JPFBenchmark.benchmark45(-553.6919564947585,-249.15733173496113,44.800949521828386 ) ;
  }

  @Test
  public void test2822() {
    coral.tests.JPFBenchmark.benchmark45(-554.0137086296096,-289.98183887340866,66.78916716595865 ) ;
  }

  @Test
  public void test2823() {
    coral.tests.JPFBenchmark.benchmark45(-554.2217076884212,-229.7848436829238,100.0 ) ;
  }

  @Test
  public void test2824() {
    coral.tests.JPFBenchmark.benchmark45(-554.391737095144,-214.86375629273277,31.448199562755804 ) ;
  }

  @Test
  public void test2825() {
    coral.tests.JPFBenchmark.benchmark45(-554.6640772035927,-250.41372050610812,57.02890852773862 ) ;
  }

  @Test
  public void test2826() {
    coral.tests.JPFBenchmark.benchmark45(-554.9169182949369,-198.4174192517139,80.0710885855384 ) ;
  }

  @Test
  public void test2827() {
    coral.tests.JPFBenchmark.benchmark45(-555.1122597350585,-206.97005437508267,79.17318518659346 ) ;
  }

  @Test
  public void test2828() {
    coral.tests.JPFBenchmark.benchmark45(-555.3695580309802,-243.0783259250365,100.0 ) ;
  }

  @Test
  public void test2829() {
    coral.tests.JPFBenchmark.benchmark45(-555.6149904444806,-224.79187686930055,100.0 ) ;
  }

  @Test
  public void test2830() {
    coral.tests.JPFBenchmark.benchmark45(-556.0190914303614,-214.74408091793055,100.0 ) ;
  }

  @Test
  public void test2831() {
    coral.tests.JPFBenchmark.benchmark45(-556.34630452866,-246.5965040271484,12.865321047144143 ) ;
  }

  @Test
  public void test2832() {
    coral.tests.JPFBenchmark.benchmark45(-556.4707817866581,-195.14397261794687,14.031513149236716 ) ;
  }

  @Test
  public void test2833() {
    coral.tests.JPFBenchmark.benchmark45(-55.65451312389451,-695.2532756953948,28.594351179514177 ) ;
  }

  @Test
  public void test2834() {
    coral.tests.JPFBenchmark.benchmark45(-556.6106694190088,-231.6413223284258,41.52680959124859 ) ;
  }

  @Test
  public void test2835() {
    coral.tests.JPFBenchmark.benchmark45(-55.66484048752491,-703.008385579864,98.13518419141562 ) ;
  }

  @Test
  public void test2836() {
    coral.tests.JPFBenchmark.benchmark45(-556.6683988699267,-207.5231839180417,53.39837659666716 ) ;
  }

  @Test
  public void test2837() {
    coral.tests.JPFBenchmark.benchmark45(-556.7988809805447,-216.5178856468477,94.51760865541311 ) ;
  }

  @Test
  public void test2838() {
    coral.tests.JPFBenchmark.benchmark45(-557.3919958122534,-198.49268585922573,0.624289068944833 ) ;
  }

  @Test
  public void test2839() {
    coral.tests.JPFBenchmark.benchmark45(-557.4466560199003,-196.200429412348,58.02528472651347 ) ;
  }

  @Test
  public void test2840() {
    coral.tests.JPFBenchmark.benchmark45(-557.5335127945992,-229.9524981915747,100.0 ) ;
  }

  @Test
  public void test2841() {
    coral.tests.JPFBenchmark.benchmark45(-557.5398481475753,-212.41028326691503,100.0 ) ;
  }

  @Test
  public void test2842() {
    coral.tests.JPFBenchmark.benchmark45(-557.9951426370321,-204.26921130684832,38.105128403862096 ) ;
  }

  @Test
  public void test2843() {
    coral.tests.JPFBenchmark.benchmark45(-558.1132945607761,-223.43372032059986,18.571009736354014 ) ;
  }

  @Test
  public void test2844() {
    coral.tests.JPFBenchmark.benchmark45(-558.2511826325158,-203.5615020206806,21.24273657267443 ) ;
  }

  @Test
  public void test2845() {
    coral.tests.JPFBenchmark.benchmark45(-558.3151617658925,-201.3677416998068,16.947898803758136 ) ;
  }

  @Test
  public void test2846() {
    coral.tests.JPFBenchmark.benchmark45(-558.4624821079537,-197.29835901103962,63.42348569802755 ) ;
  }

  @Test
  public void test2847() {
    coral.tests.JPFBenchmark.benchmark45(-558.9669476889043,-307.626963985527,45.668082134684255 ) ;
  }

  @Test
  public void test2848() {
    coral.tests.JPFBenchmark.benchmark45(-559.1944652952377,-231.66666626995493,79.42688749882544 ) ;
  }

  @Test
  public void test2849() {
    coral.tests.JPFBenchmark.benchmark45(-559.198172882285,-213.0458782064023,100.0 ) ;
  }

  @Test
  public void test2850() {
    coral.tests.JPFBenchmark.benchmark45(-559.35228620635,-191.7778508930426,66.06279068086417 ) ;
  }

  @Test
  public void test2851() {
    coral.tests.JPFBenchmark.benchmark45(-560.0079512361038,-186.67338215422828,46.7724201254791 ) ;
  }

  @Test
  public void test2852() {
    coral.tests.JPFBenchmark.benchmark45(-560.188212629376,-243.98614275324104,6.175254122695656 ) ;
  }

  @Test
  public void test2853() {
    coral.tests.JPFBenchmark.benchmark45(-560.5972840395355,-185.6137047375555,77.72997848167182 ) ;
  }

  @Test
  public void test2854() {
    coral.tests.JPFBenchmark.benchmark45(-561.3099693674172,-199.10920898820058,100.0 ) ;
  }

  @Test
  public void test2855() {
    coral.tests.JPFBenchmark.benchmark45(-561.7363075387075,-195.1518542886824,100.0 ) ;
  }

  @Test
  public void test2856() {
    coral.tests.JPFBenchmark.benchmark45(-561.9498293071827,-186.99198697803254,100.0 ) ;
  }

  @Test
  public void test2857() {
    coral.tests.JPFBenchmark.benchmark45(-562.7464808410576,-194.90239003168762,56.923635419344464 ) ;
  }

  @Test
  public void test2858() {
    coral.tests.JPFBenchmark.benchmark45(-563.0892948541591,-224.22043305594315,25.940531656102635 ) ;
  }

  @Test
  public void test2859() {
    coral.tests.JPFBenchmark.benchmark45(-563.1057837827101,-191.20449410228343,88.19555785979992 ) ;
  }

  @Test
  public void test2860() {
    coral.tests.JPFBenchmark.benchmark45(-563.3431180022696,-218.92062864155054,86.22420107506557 ) ;
  }

  @Test
  public void test2861() {
    coral.tests.JPFBenchmark.benchmark45(-563.3459665866701,-224.78858910885043,100.0 ) ;
  }

  @Test
  public void test2862() {
    coral.tests.JPFBenchmark.benchmark45(-563.3507065025652,-193.51860913843245,100.0 ) ;
  }

  @Test
  public void test2863() {
    coral.tests.JPFBenchmark.benchmark45(-563.9109640898097,-214.95883132266275,98.46816317478363 ) ;
  }

  @Test
  public void test2864() {
    coral.tests.JPFBenchmark.benchmark45(-564.7492766612799,-240.25878473068073,100.0 ) ;
  }

  @Test
  public void test2865() {
    coral.tests.JPFBenchmark.benchmark45(-564.973535663277,-189.72148687702708,9.525879053031218 ) ;
  }

  @Test
  public void test2866() {
    coral.tests.JPFBenchmark.benchmark45(-565.2694876872596,-222.89740284211302,41.413828168661084 ) ;
  }

  @Test
  public void test2867() {
    coral.tests.JPFBenchmark.benchmark45(-565.3871170976253,-190.85951724510272,59.30844855228773 ) ;
  }

  @Test
  public void test2868() {
    coral.tests.JPFBenchmark.benchmark45(-565.6242430041559,-183.66041601133298,1.0800004389167051E-6 ) ;
  }

  @Test
  public void test2869() {
    coral.tests.JPFBenchmark.benchmark45(-565.9003555972861,-184.64040270103516,4.7318355233407345 ) ;
  }

  @Test
  public void test2870() {
    coral.tests.JPFBenchmark.benchmark45(-565.9854299903479,-221.82882214112834,31.701816008801188 ) ;
  }

  @Test
  public void test2871() {
    coral.tests.JPFBenchmark.benchmark45(-566.0197906798325,-203.56638185496723,100.0 ) ;
  }

  @Test
  public void test2872() {
    coral.tests.JPFBenchmark.benchmark45(-566.7390916482465,-209.19984354534057,31.815433218097642 ) ;
  }

  @Test
  public void test2873() {
    coral.tests.JPFBenchmark.benchmark45(-566.7815956278865,-189.90500917013375,100.0 ) ;
  }

  @Test
  public void test2874() {
    coral.tests.JPFBenchmark.benchmark45(-56.68235240410296,-713.2912222266974,68.24323917733176 ) ;
  }

  @Test
  public void test2875() {
    coral.tests.JPFBenchmark.benchmark45(-566.8633042896344,-220.50750311852892,21.620693254432567 ) ;
  }

  @Test
  public void test2876() {
    coral.tests.JPFBenchmark.benchmark45(-567.105422097324,-180.74778957119815,26.753630973285738 ) ;
  }

  @Test
  public void test2877() {
    coral.tests.JPFBenchmark.benchmark45(-567.7379690368872,-270.6451105547224,36.20603813816086 ) ;
  }

  @Test
  public void test2878() {
    coral.tests.JPFBenchmark.benchmark45(-568.0442444073017,-194.1328586713112,11.85905160058347 ) ;
  }

  @Test
  public void test2879() {
    coral.tests.JPFBenchmark.benchmark45(-568.0777376325971,-204.65035542712113,72.30724379818366 ) ;
  }

  @Test
  public void test2880() {
    coral.tests.JPFBenchmark.benchmark45(-568.0972616506505,-188.9318068718605,5.9008757603564685 ) ;
  }

  @Test
  public void test2881() {
    coral.tests.JPFBenchmark.benchmark45(-568.1423845993513,-260.7340833946108,100.0 ) ;
  }

  @Test
  public void test2882() {
    coral.tests.JPFBenchmark.benchmark45(-568.2908263809945,-216.75852330893014,2.7864776786636956 ) ;
  }

  @Test
  public void test2883() {
    coral.tests.JPFBenchmark.benchmark45(-569.2802903581588,-201.75119179914094,21.960750482763203 ) ;
  }

  @Test
  public void test2884() {
    coral.tests.JPFBenchmark.benchmark45(-56.93206635170789,-721.2694703549806,0.11729490072281124 ) ;
  }

  @Test
  public void test2885() {
    coral.tests.JPFBenchmark.benchmark45(-569.4740466794218,-191.35176895906545,100.0 ) ;
  }

  @Test
  public void test2886() {
    coral.tests.JPFBenchmark.benchmark45(-569.7155510264531,-193.2954960884706,17.53282197811552 ) ;
  }

  @Test
  public void test2887() {
    coral.tests.JPFBenchmark.benchmark45(-569.9167650556443,-191.42284334661986,64.56591024219188 ) ;
  }

  @Test
  public void test2888() {
    coral.tests.JPFBenchmark.benchmark45(-569.976669345342,-195.63240440253853,9.374047466186042 ) ;
  }

  @Test
  public void test2889() {
    coral.tests.JPFBenchmark.benchmark45(-569.980054519589,-178.61281300126592,75.67243874719944 ) ;
  }

  @Test
  public void test2890() {
    coral.tests.JPFBenchmark.benchmark45(-570.5564688065982,-226.22534876360746,45.2996544942967 ) ;
  }

  @Test
  public void test2891() {
    coral.tests.JPFBenchmark.benchmark45(-570.8334452118032,-206.53097781547118,67.36100243351629 ) ;
  }

  @Test
  public void test2892() {
    coral.tests.JPFBenchmark.benchmark45(-571.0718515371597,-194.50778825645617,100.0 ) ;
  }

  @Test
  public void test2893() {
    coral.tests.JPFBenchmark.benchmark45(-571.0808973227305,-204.81347619620965,24.36484084480071 ) ;
  }

  @Test
  public void test2894() {
    coral.tests.JPFBenchmark.benchmark45(-571.219052400817,-193.70868280894234,86.97168825746877 ) ;
  }

  @Test
  public void test2895() {
    coral.tests.JPFBenchmark.benchmark45(-571.7223620650268,-199.74103824306735,100.0 ) ;
  }

  @Test
  public void test2896() {
    coral.tests.JPFBenchmark.benchmark45(-572.3205975617967,-189.25141994491113,100.0 ) ;
  }

  @Test
  public void test2897() {
    coral.tests.JPFBenchmark.benchmark45(-572.3209285262432,-221.80634619727363,39.42036350416214 ) ;
  }

  @Test
  public void test2898() {
    coral.tests.JPFBenchmark.benchmark45(-572.7405549866982,-240.61087926977376,1.177866776248166 ) ;
  }

  @Test
  public void test2899() {
    coral.tests.JPFBenchmark.benchmark45(-572.8085638730421,-251.236192138777,90.61805827671586 ) ;
  }

  @Test
  public void test2900() {
    coral.tests.JPFBenchmark.benchmark45(-572.8665937189334,-185.33634725479834,51.34953853082456 ) ;
  }

  @Test
  public void test2901() {
    coral.tests.JPFBenchmark.benchmark45(-573.1420675256613,-192.55203613732888,89.50519235752864 ) ;
  }

  @Test
  public void test2902() {
    coral.tests.JPFBenchmark.benchmark45(-573.2180078799959,-194.43871825587303,56.16601850755703 ) ;
  }

  @Test
  public void test2903() {
    coral.tests.JPFBenchmark.benchmark45(-573.4523947568641,-223.67418243116649,18.100425698326575 ) ;
  }

  @Test
  public void test2904() {
    coral.tests.JPFBenchmark.benchmark45(-573.5600046268144,-198.209675885264,58.98069299401797 ) ;
  }

  @Test
  public void test2905() {
    coral.tests.JPFBenchmark.benchmark45(-574.2066894586616,-199.00571114036717,100.0 ) ;
  }

  @Test
  public void test2906() {
    coral.tests.JPFBenchmark.benchmark45(-574.2840842990856,-199.48078981212925,100.0 ) ;
  }

  @Test
  public void test2907() {
    coral.tests.JPFBenchmark.benchmark45(-574.2970348460307,-175.43092313791777,59.28762900508257 ) ;
  }

  @Test
  public void test2908() {
    coral.tests.JPFBenchmark.benchmark45(-574.5182914100081,-213.14987889778834,100.0 ) ;
  }

  @Test
  public void test2909() {
    coral.tests.JPFBenchmark.benchmark45(-574.5642592118588,-185.2695580756737,77.5824270657236 ) ;
  }

  @Test
  public void test2910() {
    coral.tests.JPFBenchmark.benchmark45(-574.789181288009,-177.85978482641593,73.76773914368934 ) ;
  }

  @Test
  public void test2911() {
    coral.tests.JPFBenchmark.benchmark45(-574.8893010848578,-242.41162343308963,29.120416439328636 ) ;
  }

  @Test
  public void test2912() {
    coral.tests.JPFBenchmark.benchmark45(-575.6545783833052,-187.60208086349706,100.0 ) ;
  }

  @Test
  public void test2913() {
    coral.tests.JPFBenchmark.benchmark45(-575.8523708783747,-170.2671005007437,13.972859352452318 ) ;
  }

  @Test
  public void test2914() {
    coral.tests.JPFBenchmark.benchmark45(-575.9941097744668,-181.32121909069417,24.07754776179503 ) ;
  }

  @Test
  public void test2915() {
    coral.tests.JPFBenchmark.benchmark45(-576.185659284885,-226.69391020114168,29.239895744278613 ) ;
  }

  @Test
  public void test2916() {
    coral.tests.JPFBenchmark.benchmark45(-576.6251354070366,-195.6076092783935,16.297477201229555 ) ;
  }

  @Test
  public void test2917() {
    coral.tests.JPFBenchmark.benchmark45(-577.0094036133481,-182.33684944597405,12.040605167191302 ) ;
  }

  @Test
  public void test2918() {
    coral.tests.JPFBenchmark.benchmark45(-577.5423359495129,-240.55234641727046,40.369095358671274 ) ;
  }

  @Test
  public void test2919() {
    coral.tests.JPFBenchmark.benchmark45(-578.1562213513953,-254.40311043691227,48.65136338355288 ) ;
  }

  @Test
  public void test2920() {
    coral.tests.JPFBenchmark.benchmark45(-578.9241537644291,-291.24724318391503,11.913038939708343 ) ;
  }

  @Test
  public void test2921() {
    coral.tests.JPFBenchmark.benchmark45(-578.945554186779,-184.5157478102709,100.0 ) ;
  }

  @Test
  public void test2922() {
    coral.tests.JPFBenchmark.benchmark45(-579.1698360058764,-197.03998807312797,-56.669425067033565 ) ;
  }

  @Test
  public void test2923() {
    coral.tests.JPFBenchmark.benchmark45(-579.5657106834558,-168.121801195016,79.7458985116389 ) ;
  }

  @Test
  public void test2924() {
    coral.tests.JPFBenchmark.benchmark45(-579.6506907516458,-195.9142833495527,53.19675520254478 ) ;
  }

  @Test
  public void test2925() {
    coral.tests.JPFBenchmark.benchmark45(-579.8864921357381,-187.71854128227025,70.01956718356342 ) ;
  }

  @Test
  public void test2926() {
    coral.tests.JPFBenchmark.benchmark45(-580.1138870744365,-183.65771649129414,20.766705338754576 ) ;
  }

  @Test
  public void test2927() {
    coral.tests.JPFBenchmark.benchmark45(-580.3325480826395,-185.42137166249785,33.93483363143045 ) ;
  }

  @Test
  public void test2928() {
    coral.tests.JPFBenchmark.benchmark45(-580.6875753278135,-193.6457192215675,86.12822330262279 ) ;
  }

  @Test
  public void test2929() {
    coral.tests.JPFBenchmark.benchmark45(-580.8027126937479,-187.55258978210168,29.629828319428526 ) ;
  }

  @Test
  public void test2930() {
    coral.tests.JPFBenchmark.benchmark45(-581.1319284573146,-169.27088613139853,100.0 ) ;
  }

  @Test
  public void test2931() {
    coral.tests.JPFBenchmark.benchmark45(-581.5448926982534,-186.23938642532383,100.0 ) ;
  }

  @Test
  public void test2932() {
    coral.tests.JPFBenchmark.benchmark45(-582.395154253769,-173.70459206738974,49.00132354376285 ) ;
  }

  @Test
  public void test2933() {
    coral.tests.JPFBenchmark.benchmark45(-582.8580448673011,-180.5369379221276,100.0 ) ;
  }

  @Test
  public void test2934() {
    coral.tests.JPFBenchmark.benchmark45(-583.1816838489078,-181.99401875788334,80.97333571474286 ) ;
  }

  @Test
  public void test2935() {
    coral.tests.JPFBenchmark.benchmark45(-583.4484306082613,-163.64103427864657,2.548375567556448 ) ;
  }

  @Test
  public void test2936() {
    coral.tests.JPFBenchmark.benchmark45(-583.7970445703711,-164.32703912116438,63.26636148600832 ) ;
  }

  @Test
  public void test2937() {
    coral.tests.JPFBenchmark.benchmark45(-584.4342937115059,-175.0387183961695,40.46432691094256 ) ;
  }

  @Test
  public void test2938() {
    coral.tests.JPFBenchmark.benchmark45(-584.8475963687182,-178.4905682551518,50.493728812022226 ) ;
  }

  @Test
  public void test2939() {
    coral.tests.JPFBenchmark.benchmark45(-584.8759681573857,-173.08949357027348,96.75708371123156 ) ;
  }

  @Test
  public void test2940() {
    coral.tests.JPFBenchmark.benchmark45(-585.436397512959,-173.4644162714866,100.0 ) ;
  }

  @Test
  public void test2941() {
    coral.tests.JPFBenchmark.benchmark45(-585.4981485356445,-187.65345287810666,8.033512742416832 ) ;
  }

  @Test
  public void test2942() {
    coral.tests.JPFBenchmark.benchmark45(-585.7910015170221,-186.71627798617055,36.0859821743187 ) ;
  }

  @Test
  public void test2943() {
    coral.tests.JPFBenchmark.benchmark45(-586.2169667332892,-210.54160517920874,76.01648411384053 ) ;
  }

  @Test
  public void test2944() {
    coral.tests.JPFBenchmark.benchmark45(-586.3773716573205,-252.81319518600765,91.43075047184598 ) ;
  }

  @Test
  public void test2945() {
    coral.tests.JPFBenchmark.benchmark45(-586.5257543688094,-165.93752843394464,52.596596480602386 ) ;
  }

  @Test
  public void test2946() {
    coral.tests.JPFBenchmark.benchmark45(-587.264229150618,-175.55801980702466,75.07615404186537 ) ;
  }

  @Test
  public void test2947() {
    coral.tests.JPFBenchmark.benchmark45(-587.2743530126241,-179.94189440694848,31.87853406377741 ) ;
  }

  @Test
  public void test2948() {
    coral.tests.JPFBenchmark.benchmark45(-587.7929271574349,-167.21679533322612,63.13270506804599 ) ;
  }

  @Test
  public void test2949() {
    coral.tests.JPFBenchmark.benchmark45(-587.8149116305098,-225.78740841338777,5.518405917533354 ) ;
  }

  @Test
  public void test2950() {
    coral.tests.JPFBenchmark.benchmark45(-588.1901362531004,-193.67505374844006,100.0 ) ;
  }

  @Test
  public void test2951() {
    coral.tests.JPFBenchmark.benchmark45(-588.2070947658651,-176.34762837475085,44.19002090712909 ) ;
  }

  @Test
  public void test2952() {
    coral.tests.JPFBenchmark.benchmark45(-588.2348175371005,-187.36066189432464,3.532001311448923 ) ;
  }

  @Test
  public void test2953() {
    coral.tests.JPFBenchmark.benchmark45(-588.2389273419833,-184.963721270754,100.0 ) ;
  }

  @Test
  public void test2954() {
    coral.tests.JPFBenchmark.benchmark45(-588.7407349305431,-159.5068198353717,70.64117721554638 ) ;
  }

  @Test
  public void test2955() {
    coral.tests.JPFBenchmark.benchmark45(-589.2916491987583,-205.36963462171616,28.50037540248195 ) ;
  }

  @Test
  public void test2956() {
    coral.tests.JPFBenchmark.benchmark45(-589.3970966928479,-195.58696443511582,49.63218160584134 ) ;
  }

  @Test
  public void test2957() {
    coral.tests.JPFBenchmark.benchmark45(-589.4575253682846,-248.4194915091175,100.0 ) ;
  }

  @Test
  public void test2958() {
    coral.tests.JPFBenchmark.benchmark45(-589.8902738831601,-171.56605965958985,62.72442268799071 ) ;
  }

  @Test
  public void test2959() {
    coral.tests.JPFBenchmark.benchmark45(-590.240459424906,-209.4270647971266,100.0 ) ;
  }

  @Test
  public void test2960() {
    coral.tests.JPFBenchmark.benchmark45(-590.3119169688161,-224.55089450028964,100.0 ) ;
  }

  @Test
  public void test2961() {
    coral.tests.JPFBenchmark.benchmark45(-590.5998308219041,-156.60825396611074,56.306119022385275 ) ;
  }

  @Test
  public void test2962() {
    coral.tests.JPFBenchmark.benchmark45(-591.1651511551165,-222.06555769726612,44.408125157284815 ) ;
  }

  @Test
  public void test2963() {
    coral.tests.JPFBenchmark.benchmark45(-591.649028617139,-158.16673761490057,62.30848655593539 ) ;
  }

  @Test
  public void test2964() {
    coral.tests.JPFBenchmark.benchmark45(-591.783214448247,-219.32079891365294,42.5643242622337 ) ;
  }

  @Test
  public void test2965() {
    coral.tests.JPFBenchmark.benchmark45(-591.9013603214279,-173.87207993327368,19.274697873864397 ) ;
  }

  @Test
  public void test2966() {
    coral.tests.JPFBenchmark.benchmark45(-591.9047574598349,-215.7143717877868,64.99356240347069 ) ;
  }

  @Test
  public void test2967() {
    coral.tests.JPFBenchmark.benchmark45(-592.1406186788887,-185.10060066268778,13.10625130798664 ) ;
  }

  @Test
  public void test2968() {
    coral.tests.JPFBenchmark.benchmark45(-592.3055121427112,-197.8981040789551,37.39300530082906 ) ;
  }

  @Test
  public void test2969() {
    coral.tests.JPFBenchmark.benchmark45(-592.4023511547928,-164.38470169064738,100.0 ) ;
  }

  @Test
  public void test2970() {
    coral.tests.JPFBenchmark.benchmark45(-593.1035712470987,-189.44947340621226,49.69645851172518 ) ;
  }

  @Test
  public void test2971() {
    coral.tests.JPFBenchmark.benchmark45(-593.5807361003838,-154.48003572096653,1.2752921575009282 ) ;
  }

  @Test
  public void test2972() {
    coral.tests.JPFBenchmark.benchmark45(-593.7452475003996,-286.7173687172765,61.81328084252266 ) ;
  }

  @Test
  public void test2973() {
    coral.tests.JPFBenchmark.benchmark45(-594.1553321867896,-179.8698682368989,53.239179226872665 ) ;
  }

  @Test
  public void test2974() {
    coral.tests.JPFBenchmark.benchmark45(-595.0787099918282,-212.0179857242672,70.48844928471328 ) ;
  }

  @Test
  public void test2975() {
    coral.tests.JPFBenchmark.benchmark45(-595.5669467867614,-220.6900486405994,13.016955658427264 ) ;
  }

  @Test
  public void test2976() {
    coral.tests.JPFBenchmark.benchmark45(-595.9761220454246,-192.19366612638981,44.036012558788826 ) ;
  }

  @Test
  public void test2977() {
    coral.tests.JPFBenchmark.benchmark45(-596.0733568460475,-151.00073850670879,40.07290304891464 ) ;
  }

  @Test
  public void test2978() {
    coral.tests.JPFBenchmark.benchmark45(-596.5007458714673,-191.3108849228104,36.57388612100661 ) ;
  }

  @Test
  public void test2979() {
    coral.tests.JPFBenchmark.benchmark45(-596.5113746158648,-176.64355880809552,100.0 ) ;
  }

  @Test
  public void test2980() {
    coral.tests.JPFBenchmark.benchmark45(-596.5116926946204,-185.3251835950338,39.30040671477977 ) ;
  }

  @Test
  public void test2981() {
    coral.tests.JPFBenchmark.benchmark45(-596.8965139820109,-182.33737361263482,41.55576181616897 ) ;
  }

  @Test
  public void test2982() {
    coral.tests.JPFBenchmark.benchmark45(-596.9985252132723,-175.21379514242258,96.10864494824693 ) ;
  }

  @Test
  public void test2983() {
    coral.tests.JPFBenchmark.benchmark45(-597.2389754349491,-175.08551811422774,100.0 ) ;
  }

  @Test
  public void test2984() {
    coral.tests.JPFBenchmark.benchmark45(-597.813714697782,-193.95562652081077,46.308625219897294 ) ;
  }

  @Test
  public void test2985() {
    coral.tests.JPFBenchmark.benchmark45(-597.9960854185896,-222.3204748300627,100.0 ) ;
  }

  @Test
  public void test2986() {
    coral.tests.JPFBenchmark.benchmark45(-598.0227853393212,-172.58556196687118,44.014322620624 ) ;
  }

  @Test
  public void test2987() {
    coral.tests.JPFBenchmark.benchmark45(-598.0439653030993,-190.8882787284369,38.36455871463741 ) ;
  }

  @Test
  public void test2988() {
    coral.tests.JPFBenchmark.benchmark45(-598.3442718772936,-157.92448698298816,50.66497143883822 ) ;
  }

  @Test
  public void test2989() {
    coral.tests.JPFBenchmark.benchmark45(-598.3555501372049,-156.73371037085494,37.81612150577763 ) ;
  }

  @Test
  public void test2990() {
    coral.tests.JPFBenchmark.benchmark45(-598.4284224926647,-169.3649316461412,66.9706359972426 ) ;
  }

  @Test
  public void test2991() {
    coral.tests.JPFBenchmark.benchmark45(-598.4446934150076,-155.33054625640463,84.18209198644826 ) ;
  }

  @Test
  public void test2992() {
    coral.tests.JPFBenchmark.benchmark45(-598.6785077352381,-159.63048780260314,67.12489993064253 ) ;
  }

  @Test
  public void test2993() {
    coral.tests.JPFBenchmark.benchmark45(-598.7809690192641,-173.58792778878788,31.523207471013706 ) ;
  }

  @Test
  public void test2994() {
    coral.tests.JPFBenchmark.benchmark45(-599.3314701546251,-155.546806550544,24.992239124248812 ) ;
  }

  @Test
  public void test2995() {
    coral.tests.JPFBenchmark.benchmark45(-599.5277240974945,-165.65633036701826,92.83628192952165 ) ;
  }

  @Test
  public void test2996() {
    coral.tests.JPFBenchmark.benchmark45(-599.6289614194087,-177.0068217765998,50.79428637498266 ) ;
  }

  @Test
  public void test2997() {
    coral.tests.JPFBenchmark.benchmark45(-599.7345025818033,-174.91104769483775,10.327606663861147 ) ;
  }

  @Test
  public void test2998() {
    coral.tests.JPFBenchmark.benchmark45(-599.9879473295099,-165.35802321131322,71.93632628974487 ) ;
  }

  @Test
  public void test2999() {
    coral.tests.JPFBenchmark.benchmark45(-601.3139076163282,-179.11748926406264,95.83135004425304 ) ;
  }

  @Test
  public void test3000() {
    coral.tests.JPFBenchmark.benchmark45(-601.7276206478128,-152.20527912866987,72.51145708392573 ) ;
  }

  @Test
  public void test3001() {
    coral.tests.JPFBenchmark.benchmark45(-601.7280340757588,-178.64066829587554,38.104061381409764 ) ;
  }

  @Test
  public void test3002() {
    coral.tests.JPFBenchmark.benchmark45(-601.9342293023834,-202.43763307624275,77.92474901087041 ) ;
  }

  @Test
  public void test3003() {
    coral.tests.JPFBenchmark.benchmark45(-602.2823899554015,-153.07083705780923,11.44084596324528 ) ;
  }

  @Test
  public void test3004() {
    coral.tests.JPFBenchmark.benchmark45(-602.3740636537884,-148.4117883094814,33.87109752511981 ) ;
  }

  @Test
  public void test3005() {
    coral.tests.JPFBenchmark.benchmark45(-602.3820819354286,-183.04816850532046,94.4706597856806 ) ;
  }

  @Test
  public void test3006() {
    coral.tests.JPFBenchmark.benchmark45(-602.5220935438774,-162.48234888104204,79.96869636729554 ) ;
  }

  @Test
  public void test3007() {
    coral.tests.JPFBenchmark.benchmark45(-602.6069996982831,-143.98914206838842,44.79322579573727 ) ;
  }

  @Test
  public void test3008() {
    coral.tests.JPFBenchmark.benchmark45(-602.9125469150257,-152.7783378704253,5.664809102655326 ) ;
  }

  @Test
  public void test3009() {
    coral.tests.JPFBenchmark.benchmark45(-603.0242536683116,-169.92215413464316,100.0 ) ;
  }

  @Test
  public void test3010() {
    coral.tests.JPFBenchmark.benchmark45(-603.4593647508451,-153.78051314437187,100.0 ) ;
  }

  @Test
  public void test3011() {
    coral.tests.JPFBenchmark.benchmark45(-603.4912944600726,-219.18051524704418,12.174098737113638 ) ;
  }

  @Test
  public void test3012() {
    coral.tests.JPFBenchmark.benchmark45(-603.9098740760999,-150.41889371572236,22.78782134052888 ) ;
  }

  @Test
  public void test3013() {
    coral.tests.JPFBenchmark.benchmark45(-604.016790749966,-166.3741907809617,83.55016027492186 ) ;
  }

  @Test
  public void test3014() {
    coral.tests.JPFBenchmark.benchmark45(-604.4760881029205,-153.98952658313962,88.44018835226518 ) ;
  }

  @Test
  public void test3015() {
    coral.tests.JPFBenchmark.benchmark45(-605.1734045580146,-158.18106955112177,100.0 ) ;
  }

  @Test
  public void test3016() {
    coral.tests.JPFBenchmark.benchmark45(-605.6419241718215,-149.24805764714216,32.27029522507419 ) ;
  }

  @Test
  public void test3017() {
    coral.tests.JPFBenchmark.benchmark45(-606.3469584762577,-167.7055940021663,96.35902150896584 ) ;
  }

  @Test
  public void test3018() {
    coral.tests.JPFBenchmark.benchmark45(-606.4299765135793,-160.98002386530572,37.692935090851506 ) ;
  }

  @Test
  public void test3019() {
    coral.tests.JPFBenchmark.benchmark45(-606.8530279520735,-150.6141405385241,97.30770706654876 ) ;
  }

  @Test
  public void test3020() {
    coral.tests.JPFBenchmark.benchmark45(-607.9320477235442,-196.45577492371524,20.24995772063751 ) ;
  }

  @Test
  public void test3021() {
    coral.tests.JPFBenchmark.benchmark45(-608.3144575065602,-145.79231360423734,1.4469099648677997 ) ;
  }

  @Test
  public void test3022() {
    coral.tests.JPFBenchmark.benchmark45(-609.3036717572185,-178.52168793153942,34.43387833558873 ) ;
  }

  @Test
  public void test3023() {
    coral.tests.JPFBenchmark.benchmark45(-609.9552455556612,-150.00086908486335,81.28064770474043 ) ;
  }

  @Test
  public void test3024() {
    coral.tests.JPFBenchmark.benchmark45(-610.1316207643846,-187.73302655880073,68.26817282949145 ) ;
  }

  @Test
  public void test3025() {
    coral.tests.JPFBenchmark.benchmark45(-610.1875824459403,-204.2701811649457,50.61099610892546 ) ;
  }

  @Test
  public void test3026() {
    coral.tests.JPFBenchmark.benchmark45(-610.4368863306429,-197.03155561681723,80.86544028838364 ) ;
  }

  @Test
  public void test3027() {
    coral.tests.JPFBenchmark.benchmark45(-610.9476651648761,-154.2112931280946,54.08392060029897 ) ;
  }

  @Test
  public void test3028() {
    coral.tests.JPFBenchmark.benchmark45(-611.2975499527648,-173.47812126254817,75.40089778426088 ) ;
  }

  @Test
  public void test3029() {
    coral.tests.JPFBenchmark.benchmark45(-611.3058244131039,-146.11003156803656,80.62110884711595 ) ;
  }

  @Test
  public void test3030() {
    coral.tests.JPFBenchmark.benchmark45(-611.8132382541262,-209.30412495410275,39.92296580889979 ) ;
  }

  @Test
  public void test3031() {
    coral.tests.JPFBenchmark.benchmark45(-612.7223843764842,-174.79738313034684,26.42793356255146 ) ;
  }

  @Test
  public void test3032() {
    coral.tests.JPFBenchmark.benchmark45(-613.3331815693332,-177.03944372713704,94.23000353500277 ) ;
  }

  @Test
  public void test3033() {
    coral.tests.JPFBenchmark.benchmark45(-613.3386989862122,-180.56265670076766,85.9410166724885 ) ;
  }

  @Test
  public void test3034() {
    coral.tests.JPFBenchmark.benchmark45(-613.7247855805058,-172.63847084939442,100.0 ) ;
  }

  @Test
  public void test3035() {
    coral.tests.JPFBenchmark.benchmark45(-614.0200519161476,-177.7341707377306,94.28109293069906 ) ;
  }

  @Test
  public void test3036() {
    coral.tests.JPFBenchmark.benchmark45(-615.2487353019026,-188.31889345487983,26.76328190982784 ) ;
  }

  @Test
  public void test3037() {
    coral.tests.JPFBenchmark.benchmark45(-615.6381644494521,-207.7864951573942,87.71577906805146 ) ;
  }

  @Test
  public void test3038() {
    coral.tests.JPFBenchmark.benchmark45(-615.7280444158871,-144.00402802818263,100.0 ) ;
  }

  @Test
  public void test3039() {
    coral.tests.JPFBenchmark.benchmark45(-616.1413582579526,-154.6063866163651,12.01030341097055 ) ;
  }

  @Test
  public void test3040() {
    coral.tests.JPFBenchmark.benchmark45(-616.2139739225206,-130.60409509304213,62.84339482842594 ) ;
  }

  @Test
  public void test3041() {
    coral.tests.JPFBenchmark.benchmark45(-616.8521379395307,-133.5303463790816,75.76685605655021 ) ;
  }

  @Test
  public void test3042() {
    coral.tests.JPFBenchmark.benchmark45(-617.6683818569113,-152.2371834383776,35.26381660987502 ) ;
  }

  @Test
  public void test3043() {
    coral.tests.JPFBenchmark.benchmark45(-618.0337395423838,-164.33259813872854,8.791972763567994 ) ;
  }

  @Test
  public void test3044() {
    coral.tests.JPFBenchmark.benchmark45(-618.1893187780726,-130.1542750656999,23.39484372517766 ) ;
  }

  @Test
  public void test3045() {
    coral.tests.JPFBenchmark.benchmark45(-618.8770450689377,-165.14613163163935,91.15951544598992 ) ;
  }

  @Test
  public void test3046() {
    coral.tests.JPFBenchmark.benchmark45(-619.0532401020866,-185.61209620544216,100.0 ) ;
  }

  @Test
  public void test3047() {
    coral.tests.JPFBenchmark.benchmark45(-619.0900651205852,-139.38762945997325,50.27189844659506 ) ;
  }

  @Test
  public void test3048() {
    coral.tests.JPFBenchmark.benchmark45(-620.788197476393,-131.870539149872,63.802847900443936 ) ;
  }

  @Test
  public void test3049() {
    coral.tests.JPFBenchmark.benchmark45(-621.6546072593223,-144.2653142633753,67.964367078821 ) ;
  }

  @Test
  public void test3050() {
    coral.tests.JPFBenchmark.benchmark45(-621.7775356971142,-137.25875829466455,36.46793129136634 ) ;
  }

  @Test
  public void test3051() {
    coral.tests.JPFBenchmark.benchmark45(-622.1689816003815,-162.1699850063509,65.53634867280681 ) ;
  }

  @Test
  public void test3052() {
    coral.tests.JPFBenchmark.benchmark45(-622.597526733244,-157.13539196461087,100.0 ) ;
  }

  @Test
  public void test3053() {
    coral.tests.JPFBenchmark.benchmark45(-622.7603696366976,-166.35782723393694,2.457986025447383 ) ;
  }

  @Test
  public void test3054() {
    coral.tests.JPFBenchmark.benchmark45(-622.9923837777163,-161.5753624055427,76.81798931252325 ) ;
  }

  @Test
  public void test3055() {
    coral.tests.JPFBenchmark.benchmark45(-623.1689826789685,-158.66085044483435,39.756175230274096 ) ;
  }

  @Test
  public void test3056() {
    coral.tests.JPFBenchmark.benchmark45(-623.2219260717055,-191.77460169603904,81.76669987793528 ) ;
  }

  @Test
  public void test3057() {
    coral.tests.JPFBenchmark.benchmark45(-623.4533809476231,-172.49353575667294,100.0 ) ;
  }

  @Test
  public void test3058() {
    coral.tests.JPFBenchmark.benchmark45(-623.5381893095362,-171.42913490545652,52.802511527545704 ) ;
  }

  @Test
  public void test3059() {
    coral.tests.JPFBenchmark.benchmark45(-623.544408226425,-241.4862542305282,72.23502670366562 ) ;
  }

  @Test
  public void test3060() {
    coral.tests.JPFBenchmark.benchmark45(-623.8889490361732,-157.0175301530757,14.353662043011724 ) ;
  }

  @Test
  public void test3061() {
    coral.tests.JPFBenchmark.benchmark45(-623.9450068317234,-147.81961257809377,100.0 ) ;
  }

  @Test
  public void test3062() {
    coral.tests.JPFBenchmark.benchmark45(-624.4037515306186,-178.81798366835676,76.53548364622057 ) ;
  }

  @Test
  public void test3063() {
    coral.tests.JPFBenchmark.benchmark45(-62.496808788993775,-747.3129350304881,29.428145300633105 ) ;
  }

  @Test
  public void test3064() {
    coral.tests.JPFBenchmark.benchmark45(-624.9998620501776,-202.31330862354315,58.862001175915054 ) ;
  }

  @Test
  public void test3065() {
    coral.tests.JPFBenchmark.benchmark45(-62.57081163255271,-753.4933039117703,14.978701897269104 ) ;
  }

  @Test
  public void test3066() {
    coral.tests.JPFBenchmark.benchmark45(-625.8977135453785,-177.77563515686518,16.470213960192368 ) ;
  }

  @Test
  public void test3067() {
    coral.tests.JPFBenchmark.benchmark45(-625.978225045253,-130.0497641540514,76.93618329762921 ) ;
  }

  @Test
  public void test3068() {
    coral.tests.JPFBenchmark.benchmark45(-626.7689341358043,-145.06815974739555,91.14784035892393 ) ;
  }

  @Test
  public void test3069() {
    coral.tests.JPFBenchmark.benchmark45(-627.3630739708947,-134.10926737040992,63.354064252156434 ) ;
  }

  @Test
  public void test3070() {
    coral.tests.JPFBenchmark.benchmark45(-627.575895578608,-125.27206346677312,16.343245481041492 ) ;
  }

  @Test
  public void test3071() {
    coral.tests.JPFBenchmark.benchmark45(-627.5931784257851,-138.69797730383368,92.44725351468196 ) ;
  }

  @Test
  public void test3072() {
    coral.tests.JPFBenchmark.benchmark45(-627.7037691013444,-204.33736379756735,62.974098143733414 ) ;
  }

  @Test
  public void test3073() {
    coral.tests.JPFBenchmark.benchmark45(-627.9986439739204,-126.93469860530715,100.0 ) ;
  }

  @Test
  public void test3074() {
    coral.tests.JPFBenchmark.benchmark45(-628.2495015819463,-153.6223752434993,51.45877209732393 ) ;
  }

  @Test
  public void test3075() {
    coral.tests.JPFBenchmark.benchmark45(-628.2832187870147,-170.73278255451325,95.42293282471914 ) ;
  }

  @Test
  public void test3076() {
    coral.tests.JPFBenchmark.benchmark45(-628.9828890042602,-169.71798880295262,46.991810023744335 ) ;
  }

  @Test
  public void test3077() {
    coral.tests.JPFBenchmark.benchmark45(-629.0768527052817,-165.38305605952564,86.51017893012812 ) ;
  }

  @Test
  public void test3078() {
    coral.tests.JPFBenchmark.benchmark45(-62.971413326573725,-693.1616874942257,82.65913411931055 ) ;
  }

  @Test
  public void test3079() {
    coral.tests.JPFBenchmark.benchmark45(-629.9679160822657,-159.97860993730072,77.53849321784426 ) ;
  }

  @Test
  public void test3080() {
    coral.tests.JPFBenchmark.benchmark45(-630.4039132542604,-141.2875909650806,41.04352335328508 ) ;
  }

  @Test
  public void test3081() {
    coral.tests.JPFBenchmark.benchmark45(-631.1356501246519,-139.6439142106287,40.71477255982842 ) ;
  }

  @Test
  public void test3082() {
    coral.tests.JPFBenchmark.benchmark45(-63.169628134174374,-723.1420771689973,42.25323253357013 ) ;
  }

  @Test
  public void test3083() {
    coral.tests.JPFBenchmark.benchmark45(-631.8996733029264,-183.5669036603054,100.0 ) ;
  }

  @Test
  public void test3084() {
    coral.tests.JPFBenchmark.benchmark45(-632.0648957959196,-123.55226149300142,48.93904591312449 ) ;
  }

  @Test
  public void test3085() {
    coral.tests.JPFBenchmark.benchmark45(-632.4823801577479,-129.52936720456205,38.87614199359845 ) ;
  }

  @Test
  public void test3086() {
    coral.tests.JPFBenchmark.benchmark45(-633.9564108148525,-171.68540913515884,37.500013771273814 ) ;
  }

  @Test
  public void test3087() {
    coral.tests.JPFBenchmark.benchmark45(-634.4218948823915,-149.13527492704586,20.809097664051677 ) ;
  }

  @Test
  public void test3088() {
    coral.tests.JPFBenchmark.benchmark45(-634.554906719826,-120.99860358842929,36.66262406367724 ) ;
  }

  @Test
  public void test3089() {
    coral.tests.JPFBenchmark.benchmark45(-634.892864299189,-144.24802863847182,14.465293191097174 ) ;
  }

  @Test
  public void test3090() {
    coral.tests.JPFBenchmark.benchmark45(-635.5319065598471,-151.2815606121335,26.349737634799006 ) ;
  }

  @Test
  public void test3091() {
    coral.tests.JPFBenchmark.benchmark45(-636.2490612744331,-156.16413059228987,42.895112357943134 ) ;
  }

  @Test
  public void test3092() {
    coral.tests.JPFBenchmark.benchmark45(-636.3282497717023,-157.82178381150197,17.69019106978223 ) ;
  }

  @Test
  public void test3093() {
    coral.tests.JPFBenchmark.benchmark45(-636.5385601567916,-136.0067295646213,76.93535310898179 ) ;
  }

  @Test
  public void test3094() {
    coral.tests.JPFBenchmark.benchmark45(-637.2421451303252,-112.63791025855737,36.19601725544983 ) ;
  }

  @Test
  public void test3095() {
    coral.tests.JPFBenchmark.benchmark45(-637.5265837189204,-128.98942934580782,100.0 ) ;
  }

  @Test
  public void test3096() {
    coral.tests.JPFBenchmark.benchmark45(-637.5899097933799,-181.75102873055127,10.33686819151012 ) ;
  }

  @Test
  public void test3097() {
    coral.tests.JPFBenchmark.benchmark45(-637.8030639743891,-144.4817203327025,87.05482293627199 ) ;
  }

  @Test
  public void test3098() {
    coral.tests.JPFBenchmark.benchmark45(-638.1718613070332,-132.567861185345,73.93352872334508 ) ;
  }

  @Test
  public void test3099() {
    coral.tests.JPFBenchmark.benchmark45(-638.1779378056779,-147.43406719716896,33.30631535311784 ) ;
  }

  @Test
  public void test3100() {
    coral.tests.JPFBenchmark.benchmark45(-638.3501430206667,-162.65922522414522,31.669754366263504 ) ;
  }

  @Test
  public void test3101() {
    coral.tests.JPFBenchmark.benchmark45(-638.4404810246114,-149.95796686816394,7.693864831299365 ) ;
  }

  @Test
  public void test3102() {
    coral.tests.JPFBenchmark.benchmark45(-638.8803261793238,-120.43924106649581,43.797443644097626 ) ;
  }

  @Test
  public void test3103() {
    coral.tests.JPFBenchmark.benchmark45(-639.265080432467,-155.87752655619866,74.83708520721801 ) ;
  }

  @Test
  public void test3104() {
    coral.tests.JPFBenchmark.benchmark45(-639.3258253004991,-157.14257102894007,35.587009550671326 ) ;
  }

  @Test
  public void test3105() {
    coral.tests.JPFBenchmark.benchmark45(-639.9134240367055,-166.1358209057168,40.456652910766735 ) ;
  }

  @Test
  public void test3106() {
    coral.tests.JPFBenchmark.benchmark45(-640.402044419356,-160.5855029604751,69.15701962219916 ) ;
  }

  @Test
  public void test3107() {
    coral.tests.JPFBenchmark.benchmark45(-640.9806717010802,-157.77253261191126,34.63995644701669 ) ;
  }

  @Test
  public void test3108() {
    coral.tests.JPFBenchmark.benchmark45(-641.0169340197295,-137.65185302621978,49.26699439366175 ) ;
  }

  @Test
  public void test3109() {
    coral.tests.JPFBenchmark.benchmark45(-641.0741439576459,-129.28782888252775,25.45058752340124 ) ;
  }

  @Test
  public void test3110() {
    coral.tests.JPFBenchmark.benchmark45(-643.2434407685574,-138.15102061260725,69.61606387263649 ) ;
  }

  @Test
  public void test3111() {
    coral.tests.JPFBenchmark.benchmark45(-644.377519299581,-107.55460155663224,79.59044010648603 ) ;
  }

  @Test
  public void test3112() {
    coral.tests.JPFBenchmark.benchmark45(-644.6894193430187,-181.68267057722827,68.14694586161033 ) ;
  }

  @Test
  public void test3113() {
    coral.tests.JPFBenchmark.benchmark45(-644.7541577838787,-163.33787215258303,20.828061064493994 ) ;
  }

  @Test
  public void test3114() {
    coral.tests.JPFBenchmark.benchmark45(-646.4253308934619,-175.52921479932408,100.0 ) ;
  }

  @Test
  public void test3115() {
    coral.tests.JPFBenchmark.benchmark45(-647.4385623962793,-100.0,91.59927186112748 ) ;
  }

  @Test
  public void test3116() {
    coral.tests.JPFBenchmark.benchmark45(-647.6086150220948,-141.57358330440323,72.86137705370234 ) ;
  }

  @Test
  public void test3117() {
    coral.tests.JPFBenchmark.benchmark45(-647.7561065452543,-107.42837893687319,50.89728588305255 ) ;
  }

  @Test
  public void test3118() {
    coral.tests.JPFBenchmark.benchmark45(-647.8627823494278,-177.93296937679966,35.28234553158623 ) ;
  }

  @Test
  public void test3119() {
    coral.tests.JPFBenchmark.benchmark45(-648.0992688741479,-202.05026422509485,49.60309058753987 ) ;
  }

  @Test
  public void test3120() {
    coral.tests.JPFBenchmark.benchmark45(-648.7234444339086,-118.88682168814911,18.250463416136213 ) ;
  }

  @Test
  public void test3121() {
    coral.tests.JPFBenchmark.benchmark45(-648.7236647297622,-142.84545580882627,57.60122741335405 ) ;
  }

  @Test
  public void test3122() {
    coral.tests.JPFBenchmark.benchmark45(-648.9900699247107,-140.02897584975307,3.8779201823992793 ) ;
  }

  @Test
  public void test3123() {
    coral.tests.JPFBenchmark.benchmark45(-649.3218938664903,-100.0,100.0 ) ;
  }

  @Test
  public void test3124() {
    coral.tests.JPFBenchmark.benchmark45(-649.3350022979014,-99.31196723578022,71.75859303795932 ) ;
  }

  @Test
  public void test3125() {
    coral.tests.JPFBenchmark.benchmark45(-651.7072761543404,-112.74687065978422,1.0877720198426744 ) ;
  }

  @Test
  public void test3126() {
    coral.tests.JPFBenchmark.benchmark45(-651.7353442475701,-100.0,100.0 ) ;
  }

  @Test
  public void test3127() {
    coral.tests.JPFBenchmark.benchmark45(-651.7775841184736,-99.9958253797652,19.1183732965645 ) ;
  }

  @Test
  public void test3128() {
    coral.tests.JPFBenchmark.benchmark45(-652.2399741933506,-141.43058298611993,18.760644097743338 ) ;
  }

  @Test
  public void test3129() {
    coral.tests.JPFBenchmark.benchmark45(-652.391932630251,-105.55651667225925,90.51440956094052 ) ;
  }

  @Test
  public void test3130() {
    coral.tests.JPFBenchmark.benchmark45(-652.9941535576338,-123.26751786372762,84.09589545567164 ) ;
  }

  @Test
  public void test3131() {
    coral.tests.JPFBenchmark.benchmark45(-653.4358940674234,-110.92322781798244,100.0 ) ;
  }

  @Test
  public void test3132() {
    coral.tests.JPFBenchmark.benchmark45(-653.8861062653334,-96.7511901494818,96.57366596890395 ) ;
  }

  @Test
  public void test3133() {
    coral.tests.JPFBenchmark.benchmark45(-653.9350123145481,-92.06498768545188,0 ) ;
  }

  @Test
  public void test3134() {
    coral.tests.JPFBenchmark.benchmark45(-653.9980732065748,-96.90721585770186,30.28707949220589 ) ;
  }

  @Test
  public void test3135() {
    coral.tests.JPFBenchmark.benchmark45(-654.1010292354059,-100.0,100.0 ) ;
  }

  @Test
  public void test3136() {
    coral.tests.JPFBenchmark.benchmark45(-654.936470923312,-100.0,74.06323139909213 ) ;
  }

  @Test
  public void test3137() {
    coral.tests.JPFBenchmark.benchmark45(-655.6066280799755,-96.9415059984363,9.451049539999616 ) ;
  }

  @Test
  public void test3138() {
    coral.tests.JPFBenchmark.benchmark45(-655.6177034735111,-97.47863467741243,35.99216459664126 ) ;
  }

  @Test
  public void test3139() {
    coral.tests.JPFBenchmark.benchmark45(-656.9716149115044,-131.01278227738732,17.516403051260838 ) ;
  }

  @Test
  public void test3140() {
    coral.tests.JPFBenchmark.benchmark45(-657.234306796567,-100.0,100.0 ) ;
  }

  @Test
  public void test3141() {
    coral.tests.JPFBenchmark.benchmark45(-657.3819823035479,-100.0,100.0 ) ;
  }

  @Test
  public void test3142() {
    coral.tests.JPFBenchmark.benchmark45(-657.5395325396402,-134.90556015389174,31.017844011558452 ) ;
  }

  @Test
  public void test3143() {
    coral.tests.JPFBenchmark.benchmark45(-657.7463623654544,-98.48297852320013,3.9638803451396996 ) ;
  }

  @Test
  public void test3144() {
    coral.tests.JPFBenchmark.benchmark45(-658.2255036607609,-89.26223682905372,37.13768949920103 ) ;
  }

  @Test
  public void test3145() {
    coral.tests.JPFBenchmark.benchmark45(-658.5637138877246,-100.0,100.0 ) ;
  }

  @Test
  public void test3146() {
    coral.tests.JPFBenchmark.benchmark45(-658.6430133232094,-115.6832674170474,14.239481447355985 ) ;
  }

  @Test
  public void test3147() {
    coral.tests.JPFBenchmark.benchmark45(-658.7082885283926,-117.46260851014495,84.4954534011971 ) ;
  }

  @Test
  public void test3148() {
    coral.tests.JPFBenchmark.benchmark45(-659.9958405251309,-100.0,100.0 ) ;
  }

  @Test
  public void test3149() {
    coral.tests.JPFBenchmark.benchmark45(-661.422995129817,-88.61130269123305,97.94568604880348 ) ;
  }

  @Test
  public void test3150() {
    coral.tests.JPFBenchmark.benchmark45(-661.7297301529779,-99.58974478638883,31.566279996809072 ) ;
  }

  @Test
  public void test3151() {
    coral.tests.JPFBenchmark.benchmark45(-662.0235195675306,-100.0,100.0 ) ;
  }

  @Test
  public void test3152() {
    coral.tests.JPFBenchmark.benchmark45(-662.7140634150496,-100.7843830803603,89.25458886536376 ) ;
  }

  @Test
  public void test3153() {
    coral.tests.JPFBenchmark.benchmark45(-664.1720003072421,-165.47396955068902,0.5906664332901812 ) ;
  }

  @Test
  public void test3154() {
    coral.tests.JPFBenchmark.benchmark45(-664.2927946211764,-109.01186594192345,35.51564203478574 ) ;
  }

  @Test
  public void test3155() {
    coral.tests.JPFBenchmark.benchmark45(-664.5073760988319,-96.29099391425598,57.394532969845585 ) ;
  }

  @Test
  public void test3156() {
    coral.tests.JPFBenchmark.benchmark45(-665.205723889033,-100.0,100.0 ) ;
  }

  @Test
  public void test3157() {
    coral.tests.JPFBenchmark.benchmark45(-665.8614611413489,-91.68661238700106,37.939268813518424 ) ;
  }

  @Test
  public void test3158() {
    coral.tests.JPFBenchmark.benchmark45(-665.9467535961219,-89.20875763291964,100.0 ) ;
  }

  @Test
  public void test3159() {
    coral.tests.JPFBenchmark.benchmark45(-666.5845478448987,-81.550280358636,37.083542716273485 ) ;
  }

  @Test
  public void test3160() {
    coral.tests.JPFBenchmark.benchmark45(-666.7240084587452,-158.44994827534634,56.899572438369944 ) ;
  }

  @Test
  public void test3161() {
    coral.tests.JPFBenchmark.benchmark45(-667.1875045699569,-100.0,98.59204586527923 ) ;
  }

  @Test
  public void test3162() {
    coral.tests.JPFBenchmark.benchmark45(-667.8856284661314,-100.0,100.0 ) ;
  }

  @Test
  public void test3163() {
    coral.tests.JPFBenchmark.benchmark45(-667.9225230766917,-98.77600544189784,41.74299341118214 ) ;
  }

  @Test
  public void test3164() {
    coral.tests.JPFBenchmark.benchmark45(-668.7988176335131,-83.2493031536088,76.61597784312295 ) ;
  }

  @Test
  public void test3165() {
    coral.tests.JPFBenchmark.benchmark45(-669.1071446886774,-100.0,100.0 ) ;
  }

  @Test
  public void test3166() {
    coral.tests.JPFBenchmark.benchmark45(-669.3245602123452,-100.0,100.0 ) ;
  }

  @Test
  public void test3167() {
    coral.tests.JPFBenchmark.benchmark45(-670.0762968596827,-100.0,100.0 ) ;
  }

  @Test
  public void test3168() {
    coral.tests.JPFBenchmark.benchmark45(-670.3994841391112,-76.66755957861588,91.19554092549424 ) ;
  }

  @Test
  public void test3169() {
    coral.tests.JPFBenchmark.benchmark45(-670.7956639389065,-100.0,100.0 ) ;
  }

  @Test
  public void test3170() {
    coral.tests.JPFBenchmark.benchmark45(-672.115377135599,-89.02046269277923,2.4949778332028103 ) ;
  }

  @Test
  public void test3171() {
    coral.tests.JPFBenchmark.benchmark45(-674.1582205652069,-76.2317653436303,19.736622972112514 ) ;
  }

  @Test
  public void test3172() {
    coral.tests.JPFBenchmark.benchmark45(-674.1911639769248,-87.01035848433014,87.93688770437376 ) ;
  }

  @Test
  public void test3173() {
    coral.tests.JPFBenchmark.benchmark45(-674.8306969249212,-119.2996399001157,70.3285106393291 ) ;
  }

  @Test
  public void test3174() {
    coral.tests.JPFBenchmark.benchmark45(-675.1872851962709,-75.26274774726025,89.35887401391639 ) ;
  }

  @Test
  public void test3175() {
    coral.tests.JPFBenchmark.benchmark45(-676.2925670224226,-100.0,85.06095744190958 ) ;
  }

  @Test
  public void test3176() {
    coral.tests.JPFBenchmark.benchmark45(-676.3395131902053,-100.0,62.31573753515019 ) ;
  }

  @Test
  public void test3177() {
    coral.tests.JPFBenchmark.benchmark45(-676.6326046459213,-100.0,68.73538671546743 ) ;
  }

  @Test
  public void test3178() {
    coral.tests.JPFBenchmark.benchmark45(-676.7301332380198,-100.0,5.762423016773738 ) ;
  }

  @Test
  public void test3179() {
    coral.tests.JPFBenchmark.benchmark45(-677.2046797720446,-73.59915095705922,44.000034685723875 ) ;
  }

  @Test
  public void test3180() {
    coral.tests.JPFBenchmark.benchmark45(-678.0814630795369,-80.64415599745897,29.51768015040247 ) ;
  }

  @Test
  public void test3181() {
    coral.tests.JPFBenchmark.benchmark45(-678.204753489074,-100.0,100.0 ) ;
  }

  @Test
  public void test3182() {
    coral.tests.JPFBenchmark.benchmark45(-682.5444445936396,-77.16240633076579,31.254872333069073 ) ;
  }

  @Test
  public void test3183() {
    coral.tests.JPFBenchmark.benchmark45(-682.7010123885897,-66.1985712338838,6.480191198131308 ) ;
  }

  @Test
  public void test3184() {
    coral.tests.JPFBenchmark.benchmark45(-682.8857299773786,-127.87254346831278,100.0 ) ;
  }

  @Test
  public void test3185() {
    coral.tests.JPFBenchmark.benchmark45(-683.6399892556243,-77.76402654780577,50.02409309667499 ) ;
  }

  @Test
  public void test3186() {
    coral.tests.JPFBenchmark.benchmark45(-684.0208618960362,-121.17343500644881,12.001158006308827 ) ;
  }

  @Test
  public void test3187() {
    coral.tests.JPFBenchmark.benchmark45(-688.8377063217495,-135.4462371051506,87.90719662575623 ) ;
  }

  @Test
  public void test3188() {
    coral.tests.JPFBenchmark.benchmark45(-689.3219466421825,-62.556719581990315,0 ) ;
  }

  @Test
  public void test3189() {
    coral.tests.JPFBenchmark.benchmark45(-693.2762779833681,-66.4199848941197,0 ) ;
  }

  @Test
  public void test3190() {
    coral.tests.JPFBenchmark.benchmark45(-695.8326467434588,-69.51449794140726,74.02165372992332 ) ;
  }

  @Test
  public void test3191() {
    coral.tests.JPFBenchmark.benchmark45(-698.0611337843359,-64.65226221401079,19.602029158662162 ) ;
  }

  @Test
  public void test3192() {
    coral.tests.JPFBenchmark.benchmark45(-698.2374122127516,-69.14668752894595,62.76900557574609 ) ;
  }

  @Test
  public void test3193() {
    coral.tests.JPFBenchmark.benchmark45(-699.7227933200202,-89.04537516316252,29.960468270524018 ) ;
  }

  @Test
  public void test3194() {
    coral.tests.JPFBenchmark.benchmark45(-699.9942960857961,-58.97247733545343,51.946222281919404 ) ;
  }

  @Test
  public void test3195() {
    coral.tests.JPFBenchmark.benchmark45(-70.17128035437928,-696.8113149446203,70.19389303544202 ) ;
  }

  @Test
  public void test3196() {
    coral.tests.JPFBenchmark.benchmark45(-707.5812587057344,-73.13512784194563,0 ) ;
  }

  @Test
  public void test3197() {
    coral.tests.JPFBenchmark.benchmark45(-709.7442522538731,-81.2651479880204,31.736453220144085 ) ;
  }

  @Test
  public void test3198() {
    coral.tests.JPFBenchmark.benchmark45(-710.4777924157048,-49.418862540064,38.44953111632384 ) ;
  }

  @Test
  public void test3199() {
    coral.tests.JPFBenchmark.benchmark45(-710.7573687075239,-103.21231147296538,93.0876972794776 ) ;
  }

  @Test
  public void test3200() {
    coral.tests.JPFBenchmark.benchmark45(-71.12576902469584,57.19825366927145,0 ) ;
  }

  @Test
  public void test3201() {
    coral.tests.JPFBenchmark.benchmark45(-711.9238972210545,-100.0,29.81079467616763 ) ;
  }

  @Test
  public void test3202() {
    coral.tests.JPFBenchmark.benchmark45(-714.0023794110242,-109.80668489045651,58.550263434146075 ) ;
  }

  @Test
  public void test3203() {
    coral.tests.JPFBenchmark.benchmark45(-717.203808024309,-74.1222521936838,83.95833734910104 ) ;
  }

  @Test
  public void test3204() {
    coral.tests.JPFBenchmark.benchmark45(-719.1470465404747,-70.6744931986288,48.64202376842604 ) ;
  }

  @Test
  public void test3205() {
    coral.tests.JPFBenchmark.benchmark45(-719.4707491815246,-96.45709002803571,26.968608152702572 ) ;
  }

  @Test
  public void test3206() {
    coral.tests.JPFBenchmark.benchmark45(-722.8842500204584,-100.0,38.424864274105374 ) ;
  }

  @Test
  public void test3207() {
    coral.tests.JPFBenchmark.benchmark45(-726.0865163242421,-40.68786547664216,42.881089183734645 ) ;
  }

  @Test
  public void test3208() {
    coral.tests.JPFBenchmark.benchmark45(-727.2208518535265,-88.02189001831393,29.90879644425746 ) ;
  }

  @Test
  public void test3209() {
    coral.tests.JPFBenchmark.benchmark45(-73.95094189358504,-699.9931324011345,20.771196966260646 ) ;
  }

  @Test
  public void test3210() {
    coral.tests.JPFBenchmark.benchmark45(-75.24650926142385,-694.0164278809107,55.81711843078858 ) ;
  }

  @Test
  public void test3211() {
    coral.tests.JPFBenchmark.benchmark45(-75.45519892246753,-672.9100983373307,100.0 ) ;
  }

  @Test
  public void test3212() {
    coral.tests.JPFBenchmark.benchmark45(-75.58293279456893,-677.5248672893205,37.54706508226931 ) ;
  }

  @Test
  public void test3213() {
    coral.tests.JPFBenchmark.benchmark45(-83.89833768575124,-673.5464261249472,24.28435845510215 ) ;
  }

  @Test
  public void test3214() {
    coral.tests.JPFBenchmark.benchmark45(-85.55516674234094,-699.5898325233479,37.72879749087076 ) ;
  }

  @Test
  public void test3215() {
    coral.tests.JPFBenchmark.benchmark45(-87.97118135002822,-719.0443465426504,8.773791140369582 ) ;
  }

  @Test
  public void test3216() {
    coral.tests.JPFBenchmark.benchmark45(-88.43886522179847,-690.5225134816714,61.42607067223025 ) ;
  }

  @Test
  public void test3217() {
    coral.tests.JPFBenchmark.benchmark45(-88.5705603711757,-664.1100164069002,74.30994023035439 ) ;
  }

  @Test
  public void test3218() {
    coral.tests.JPFBenchmark.benchmark45(-88.93632869203026,-721.7150767395153,96.61763148997198 ) ;
  }

  @Test
  public void test3219() {
    coral.tests.JPFBenchmark.benchmark45(-89.32184054559943,-669.9614218799651,47.820994015190706 ) ;
  }

  @Test
  public void test3220() {
    coral.tests.JPFBenchmark.benchmark45(-89.3634388649377,-724.3180608600379,62.939727652949614 ) ;
  }

  @Test
  public void test3221() {
    coral.tests.JPFBenchmark.benchmark45(-92.31190509036983,-722.5838745470908,93.22899308200701 ) ;
  }

  @Test
  public void test3222() {
    coral.tests.JPFBenchmark.benchmark45(-96.05593978621755,-677.9937972319805,64.24101441308284 ) ;
  }

  @Test
  public void test3223() {
    coral.tests.JPFBenchmark.benchmark45(-96.81337400393079,-651.001841249915,-37.1711034399199 ) ;
  }

  @Test
  public void test3224() {
    coral.tests.JPFBenchmark.benchmark45(-98.00865966821198,-659.7264115272134,42.401365057207585 ) ;
  }

  @Test
  public void test3225() {
    coral.tests.JPFBenchmark.benchmark45(-9.806442460852224,-36.565112854281814,0 ) ;
  }

  @Test
  public void test3226() {
    coral.tests.JPFBenchmark.benchmark45(-98.22952388691934,-679.9303871056978,50.15026795420624 ) ;
  }

  @Test
  public void test3227() {
    coral.tests.JPFBenchmark.benchmark45(-99.00383710930905,-697.8452675613443,3.5661990964605224 ) ;
  }

  @Test
  public void test3228() {
    coral.tests.JPFBenchmark.benchmark45(-99.53696727607652,-650.3251410239637,100.0 ) ;
  }

  @Test
  public void test3229() {
    coral.tests.JPFBenchmark.benchmark45(-99.72355234718324,-660.1431800154497,85.79452814067011 ) ;
  }

  @Test
  public void test3230() {
//    sym_v1null;
  }

  @Test
  public void test3231() {
//    sym_v2_( doubleToRawLongBits (x_4_SYMREAL) & CONST_0);
  }

  @Test
  public void test3232() {
//    sym_v2( doubleToRawLongBits (x_4_SYMREAL) & CONST_0);
  }

  @Test
  public void test3233() {
//    sym_v2_( doubleToRawLongBits (z_6_SYMREAL) & CONST_0);
  }

  @Test
  public void test3234() {
//    sym_v2( doubleToRawLongBits (z_6_SYMREAL) & CONST_0);
  }

  @Test
  public void test3235() {
//    	UnSolved;
  }
}
