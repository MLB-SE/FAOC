import org.junit.Test;

public class Sample30Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark30(-0.003070424284672413 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark30(-0.012297242482858906 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark30(-0.012942744109764703 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark30(-0.07065620421766994 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark30(-0.07078931686741896 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark30(-0.08061329056798172 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark30(-0.13780648759318126 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark30(-0.14260141291732964 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark30(-0.1510737805732134 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark30(-0.1543065886400683 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark30(-0.1642074277542065 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark30(-0.19675271541719042 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark30(-0.23203471071447268 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark30(-0.32910976597588615 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark30(-0.3693683701262671 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark30(-0.39043174714822726 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark30(-0.41609318448561794 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark30(-0.4459528856712893 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark30(-0.50684649396608 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark30(-0.5778194002181039 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark30(-0.6633955859948202 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark30(-0.6834709021834868 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark30(-0.6848656856307542 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark30(-0.7271651577128466 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark30(-0.7356642671913391 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark30(-0.7766265611309393 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark30(-0.7931498205397531 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark30(-0.8065080487075846 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark30(-0.8754559513551214 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark30(-0.8844549746343375 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark30(-0.9331294419444589 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark30(-0.941858039676859 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark30(-0.9555918072584006 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark30(-0.9923828581824807 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark30(-10.094206710018256 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark30(-10.097458099254155 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark30(-10.132542864371331 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark30(-10.133235929342604 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark30(-10.18422584554611 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark30(-10.340767561405784 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark30(-10.344367719509833 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark30(-10.403359721300916 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark30(-10.5160522863722 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark30(-10.531574303406217 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark30(-10.565412574978865 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark30(-10.578753186236128 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark30(-10.580264605802256 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark30(-10.61198387159736 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark30(-10.618852695242055 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark30(-10.62285692440031 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark30(-10.650086578099135 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark30(-1.0654196610084767 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark30(-10.721666906134402 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark30(-10.729997330740119 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark30(-10.75734951810243 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark30(-10.850087468636431 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark30(-10.906834334248217 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark30(-10.913132965144285 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark30(-10.93044258514098 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark30(-10.960796333228046 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark30(-11.02726426279419 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark30(-11.092461382149878 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark30(-11.102695141187226 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark30(-1.1112881815942757 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark30(-11.230082877136425 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark30(-11.239770089849827 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark30(-11.250424530986919 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark30(-11.27091736854564 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark30(-11.2981537502083 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark30(-11.335093562609686 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark30(-11.36430536837787 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark30(-11.400958469495734 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark30(-11.461586771629968 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark30(-11.57952711051962 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark30(-11.590590543965831 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark30(-11.606123077394386 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark30(-1.1631193343312844 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark30(-11.649871599799582 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark30(-1.167331559430849 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark30(-11.729486111986432 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark30(-11.735985547724198 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark30(-11.808268564280766 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark30(-1.1854896180609273 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark30(-11.859580655600396 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark30(-11.864332426605046 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark30(-11.938210586716579 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark30(-11.949776355834857 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark30(-12.042019696376968 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark30(-1.2183576640462093 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark30(-12.263179092737644 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark30(-12.333923429495243 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark30(-12.369593546944031 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark30(-12.380610876788339 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark30(-12.42175254969537 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark30(-12.445167908036751 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark30(-12.537016984809227 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark30(-1.2538415075441236 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark30(-12.546189537005432 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark30(-12.54841519363272 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark30(-12.57786883585186 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark30(-12.591074116376703 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark30(-12.592152279439944 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark30(-12.615143439444608 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark30(-12.65664737039836 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark30(-1.2666980716304437 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark30(-12.688078365868222 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark30(-12.70141762316399 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark30(-12.730740157773383 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark30(-1.2835313565290818 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark30(-12.856642987385897 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark30(-12.85703071228393 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark30(-12.936136902522065 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark30(-12.96829741090771 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark30(-12.991311541637003 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark30(-12.995747257237028 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark30(-13.032056994071311 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark30(-1.3041608611942195 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark30(-13.044977666223588 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark30(-13.05199239944723 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark30(-13.071769971511742 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark30(-1.308067862217527 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark30(-13.093938812053139 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark30(-13.09443682527332 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark30(-13.102463792817716 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark30(-13.114820733647207 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark30(-13.13660846115792 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark30(-13.137026769402766 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark30(-13.171534006792513 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark30(-13.176859468005333 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark30(-13.215510289274192 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark30(-13.305230622587132 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark30(-13.324898176660113 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark30(-13.42733619750534 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark30(-13.43314799012532 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark30(-13.555206168394847 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark30(-1.35948656413089 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark30(-13.603314230622203 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark30(-13.65932927920565 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark30(-13.691155859147841 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark30(-13.719630003566351 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark30(-13.76493721062171 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark30(-13.782892687317386 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark30(-13.79600280919982 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark30(-13.805237188397129 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark30(-13.836826448222467 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark30(-13.967548669478887 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark30(-13.999852191840972 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark30(-14.01064158991656 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark30(-14.056715000195112 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark30(-1.407285463006886 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark30(-14.093754134827336 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark30(-14.1173988498075 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark30(-14.12450036776842 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark30(-14.143049822237842 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark30(-14.147975250315326 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark30(-14.172132648085565 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark30(-14.19852162856236 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark30(-14.234732861938767 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark30(-14.308902299117136 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark30(-14.310340481688115 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark30(-14.379684953935978 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark30(-14.395732413344959 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark30(-14.54045751346142 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark30(-14.586349032751627 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark30(-14.622058479477033 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark30(-14.647755608151968 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark30(-14.655720803711475 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark30(-14.666889441164273 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark30(-14.793814032708468 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark30(-14.812154066421584 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark30(-14.877664292306576 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark30(-14.894884098108534 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark30(-1.4920024012088646 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark30(-14.985314430236315 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark30(-14.990078912150096 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark30(-15.027039548345726 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark30(-15.065878703608433 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark30(-15.117999418538687 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark30(-15.150219732106777 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark30(-15.180751976859327 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark30(-1.5186167529985397 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark30(-15.21303968331425 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark30(-15.238034480551093 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark30(-15.265029232753974 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark30(-15.265364470900607 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark30(-15.284147709768135 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark30(-15.387436901156008 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark30(-15.48877898540566 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark30(-15.515180822649356 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark30(-15.573515465602924 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark30(-15.63457733380696 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark30(-15.720199690140376 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark30(-15.73248821307729 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark30(-15.744044526843197 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark30(-15.80059078393164 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark30(-15.853453522896714 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark30(-15.856485070116477 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark30(-15.916078078856174 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark30(-15.918749109894435 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark30(-15.944415786523635 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark30(-15.951218242838962 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark30(-15.984411155991324 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark30(-16.021780235319312 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark30(-16.036207720883652 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark30(-16.072617030790767 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark30(-16.088316911443698 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark30(-16.090958315507535 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark30(-16.093886108772054 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark30(-16.214948078698256 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark30(-16.23464456230809 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark30(-16.2368387224233 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark30(-16.264522254484987 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark30(-16.26863470086259 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark30(-16.280257553396368 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark30(-16.304654577624618 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark30(-16.311029540297838 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark30(-16.361004489405076 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark30(-16.403521499268365 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark30(-16.435036632609183 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark30(-16.442110103660298 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark30(-16.446269816291334 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark30(-16.483142388626874 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark30(-16.496228167533047 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark30(-16.542885734879604 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark30(-1.6579381564661304 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark30(-16.593122998964787 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark30(-16.61952289552113 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark30(-16.68455597146341 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark30(-1.6699062540199492 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark30(-16.770387540566986 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark30(-16.779677165529776 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark30(-16.794612622366103 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark30(-16.81547224303486 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark30(-16.819051220286013 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark30(-16.834108789633177 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark30(-16.84742119588776 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark30(-16.885002292067867 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark30(-16.89133109140066 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark30(-16.913470411971844 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark30(-1.6957149596274377 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark30(-16.97510860680576 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark30(-16.982758341103604 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark30(-16.996023869275817 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark30(-17.02081292714719 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark30(-17.07785624782423 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark30(-17.085581254512405 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark30(-17.10346331534241 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark30(-17.121550754396523 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark30(-17.122339713326483 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark30(-17.17590504695798 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark30(-17.2181779751224 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark30(-17.226556099329102 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark30(-17.2821187477266 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark30(-17.3045050966727 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark30(-17.31704862877976 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark30(-17.38215490436106 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark30(-17.38264832273846 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark30(-17.456553599389053 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark30(-17.488994215914772 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark30(-17.530012107501463 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark30(-17.552821281133177 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark30(-17.59170117748323 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark30(-17.60859269994755 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark30(-17.689632737618766 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark30(-17.715888839418753 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark30(-17.72670134909839 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark30(-17.729834712914766 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark30(-17.73409526511807 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark30(-17.735643947832557 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark30(-17.784605396325404 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark30(-17.838596576495604 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark30(-17.84073657152014 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark30(-17.854382790854558 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark30(-17.86390313629869 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark30(-17.875144510584008 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark30(-17.915890427958786 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark30(-17.930377632083164 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark30(-17.93117656023651 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark30(-17.9321570907327 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark30(-17.95731869052915 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark30(-18.031914143233863 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark30(-18.125667808340353 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark30(-18.163717075378855 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark30(-18.185919691519345 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark30(-1.820519736153983 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark30(-18.22242481833169 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark30(-1.8233627089347095 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark30(-18.336040726858187 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark30(-18.366160021737144 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark30(-18.40735322029022 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark30(-18.41074692325506 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark30(-1.8448243220988871 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark30(-18.46248769595735 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark30(-18.46989275141142 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark30(-1.8531847432329727 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark30(-18.541832054859114 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark30(-18.592797719443155 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark30(-18.626797377645744 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark30(-18.63944854638335 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark30(-1.8703748154360085 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark30(-1.870418877939045 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark30(-18.714526292324948 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark30(-18.732762410508585 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark30(-18.78979145435835 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark30(-18.88017599692479 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark30(-18.928769713401834 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark30(-18.995062604656 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark30(-19.010888555519074 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark30(-19.01879300322031 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark30(-19.019827415108523 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark30(-19.029081648273532 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark30(-19.044601008550302 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark30(-19.06436032102043 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark30(-19.0955253043182 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark30(-19.156841386995268 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark30(-19.15932444369058 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark30(-19.276123634384334 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark30(-19.277593963669744 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark30(-19.28906944457421 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark30(-19.29182361136445 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark30(-19.330168147413488 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark30(-19.352731567599022 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark30(-19.368910858604593 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark30(-19.418347442661428 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark30(-19.43529436553621 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark30(-19.440091719767565 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark30(-19.500397055476327 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark30(-19.512520211155376 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark30(-19.616121015727856 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark30(-19.649052967915082 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark30(-19.657529920369797 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark30(-19.664040652333796 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark30(-19.67419465617411 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark30(-19.683569148120327 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark30(-19.68567599295494 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark30(-19.703392305244606 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark30(-1.9721159939526842 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark30(1.9721522630525295E-31 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark30(-19.755599839617915 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark30(-19.824123641728292 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark30(-19.862061210406992 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark30(-19.877362467674416 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark30(-19.885851409199006 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark30(-19.951978166507985 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark30(-20.106510224806712 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark30(-20.152355532180295 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark30(-20.170046467539976 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark30(-20.233002781342265 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark30(-20.25046126604107 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark30(-20.269078636808686 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark30(-20.33119327175794 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark30(-20.331284836018497 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark30(-20.33473678616457 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark30(-20.342695065956235 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark30(-20.391621509166953 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark30(-20.452987917375737 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark30(-20.453348570687282 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark30(-20.477664325518703 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark30(-20.48074860599955 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark30(-20.531234323859053 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark30(-20.53316994621342 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark30(-20.53349182895559 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark30(-20.55154849776264 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark30(-20.609700332515104 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark30(-20.621818501157918 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark30(-20.626633317073257 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark30(-20.6807312729687 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark30(-20.682513779624117 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark30(-20.715031954533927 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark30(-20.717138749566445 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark30(-2.0770779429375636 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark30(-20.819400272120163 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark30(-20.842996667524602 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark30(-20.89518701042263 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark30(-20.939293810545493 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark30(-20.94789053885387 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark30(-20.948241610489532 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark30(-20.99452476430865 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark30(-21.00403279058402 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark30(-21.014888559546563 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark30(-21.059631023031542 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark30(-21.110143249553005 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark30(-21.122091757499177 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark30(-21.132849340112173 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark30(-21.15408047789043 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark30(-21.16662371997691 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark30(-21.189217481089244 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark30(-21.206935030703164 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark30(-21.2389917179501 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark30(-2.125597416443597 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark30(-21.258050108668527 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark30(-21.304814820893966 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark30(-2.1338089871288304 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark30(-2.1361379357668397 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark30(-21.461691890314768 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark30(-21.509168832730154 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark30(-21.513964393126543 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark30(-21.59478780286119 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark30(-21.608369512324415 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark30(-21.626804264407326 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark30(-21.725506641832865 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark30(-21.738447151720578 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark30(-21.768001366355108 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark30(-2.1900419246433103 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark30(-21.940277808382902 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark30(-22.09617549942024 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark30(-22.12906631281355 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark30(-22.147735949552967 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark30(-22.20276694403171 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark30(-22.210024624087296 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark30(-22.22534881178882 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark30(-2.223428405721208 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark30(-22.265006830777793 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark30(-22.318363835731276 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark30(-22.34162416157686 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark30(-22.353564664807607 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark30(-22.369834608187134 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark30(-22.37280355154006 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark30(-22.386897457624926 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark30(-22.465601899953285 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark30(-2.246648740473532 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark30(-22.471130372843035 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark30(-22.56784733061336 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark30(-22.59678452622191 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark30(-22.619976225250696 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark30(-22.623560270634187 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark30(-22.66079243854074 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark30(-22.67729641423128 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark30(-22.69516475145184 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark30(-22.704710085789387 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark30(-22.72907504097337 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark30(-22.72922879894186 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark30(-22.828062558623444 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark30(-22.866013366389453 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark30(-22.892965202405307 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark30(-22.945165999780627 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark30(-2.2947501192456485 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark30(-2.29630353686278 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark30(-22.963843172478022 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark30(-22.97719610226568 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark30(-23.013777573002628 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark30(-23.01804877868649 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark30(-23.02484131861071 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark30(-23.057507075812595 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark30(-23.067709336344848 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark30(-23.143605032846423 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark30(-23.166506030426092 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark30(-23.214476297669634 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark30(-23.21904254397697 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark30(-23.2249971486536 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark30(-23.2555662691248 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark30(-2.328028252187792 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark30(-23.3546520532103 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark30(-23.400592137482334 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark30(-23.44716248236236 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark30(-2.347762247439931 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark30(-23.48888369268623 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark30(-23.516340912097462 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark30(-23.56053936665252 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark30(-23.609605265761587 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark30(-23.634947568020138 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark30(-23.683689543331155 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark30(-23.69080908541497 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark30(-23.852608103587357 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark30(-23.875802763457713 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark30(-23.89869915945799 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark30(-23.915449252442315 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark30(-23.92638524155373 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark30(-23.92645156570667 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark30(-24.027996575222872 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark30(-24.04496054360014 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark30(-24.091768033157308 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark30(-24.15869507031016 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark30(-24.160735210213645 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark30(-2.42177482265933 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark30(-24.273223477132973 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark30(-24.274195321929753 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark30(-24.30628326085953 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark30(-24.331607176582708 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark30(-24.408770238420118 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark30(-24.410317190226678 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark30(-24.41332087085941 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark30(-24.461289875707124 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark30(-2.4475876731705455 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark30(-24.502207758052535 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark30(-24.538541578615863 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark30(-24.55483193446868 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark30(-24.575976916632555 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark30(-24.59203222588667 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark30(-2.46348290244498 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark30(-24.657283889027056 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark30(-2.466373347204126 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark30(-24.70517003069716 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark30(-24.765310173548045 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark30(-24.900096819728418 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark30(-2.5003404260559847 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark30(-25.018335034292477 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark30(-25.056211873417823 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark30(-25.058281322062555 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark30(-25.175982325876674 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark30(-25.219517951708312 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark30(-25.22310819798672 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark30(-25.224471420773597 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark30(-25.271106100084296 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark30(-2.52947267669488 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark30(-25.29681608020941 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark30(-25.335193538028292 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark30(-25.349659373831116 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark30(-25.37662849472831 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark30(-25.477378771728112 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark30(-25.48836239766159 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark30(-25.49435606749401 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark30(-25.50569268929263 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark30(-25.59213395871396 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark30(-25.598531030272213 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark30(-25.60220762981558 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark30(-25.71310568581484 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark30(-25.714009976606974 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark30(-25.763001164356055 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark30(-25.77166537288838 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark30(-25.771937982035098 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark30(-25.77751375246153 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark30(-25.812842475957567 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark30(-25.81558945552291 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark30(-25.839207412478274 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark30(-2.5860156595083765 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark30(-25.961957114541406 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark30(-26.006713514471215 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark30(-26.021553928026435 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark30(-26.073292112601436 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark30(-26.08806489997623 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark30(-26.146666845833394 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark30(-26.147478096714977 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark30(-26.165519766543312 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark30(-26.190613171353803 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark30(-26.210789192779032 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark30(-26.23342445488548 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark30(-2.6251297275553043 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark30(-26.306719334518178 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark30(-26.336347763214604 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark30(-26.350762156111827 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark30(-26.362946246694037 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark30(-26.374998309918453 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark30(-26.380361167961055 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark30(-26.39918244907875 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark30(-26.441871561806394 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark30(-26.48676424273748 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark30(-26.488196629549236 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark30(-26.501144219772385 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark30(-26.527812880364763 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark30(-26.59648878408882 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark30(-26.63010806131257 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark30(-26.6539354970497 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark30(-26.71494502591976 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark30(-2.673066505625158 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark30(-26.740488418263908 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark30(-26.755675979024616 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark30(-26.76505792580579 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark30(-26.780022183096847 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark30(-26.78372722104892 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark30(-26.793793949513727 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark30(-26.830399418770455 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark30(-26.910573443067776 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark30(-26.945966355626254 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark30(-26.95273264573403 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark30(-26.97342417820363 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark30(-27.041976718267733 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark30(-27.08242756017694 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark30(-27.196016232206844 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark30(-27.217586732073727 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark30(-2.7228957023311295 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark30(-2.725759910178894 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark30(-27.25763053989745 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark30(-27.295414199738204 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark30(-27.318721728639318 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark30(-27.355704458458902 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark30(-2.7396724050998955 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark30(-27.40034949361703 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark30(-27.46377000906857 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark30(-27.5039521813587 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark30(-27.52110638842167 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark30(-2.757508319503316 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark30(-27.690185120152222 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark30(-27.709077387716064 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark30(-2.7746702059549477 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark30(-27.75321270495192 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark30(-27.80677178436825 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark30(-27.82743371369311 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark30(-27.857783135905805 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark30(-27.858679602333794 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark30(-27.886988301028666 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark30(-27.90423334336998 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark30(-27.906518739738544 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark30(-27.91323159023689 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark30(-27.930908257285807 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark30(-27.992693946893567 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark30(-27.996370842401205 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark30(-27.998552412587102 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark30(-28.058316177027763 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark30(-28.071013104666534 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark30(-28.07971118102519 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark30(-28.142669932132037 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark30(-28.150380409843805 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark30(-28.166192933899083 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark30(-28.201687329996147 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark30(-28.223980083601404 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark30(-28.30314546919101 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark30(-28.31181051158846 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark30(-28.312768291055008 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark30(-28.334937313581392 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark30(-2.8384647030107857 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark30(-28.40906294903786 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark30(-28.422624337024644 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark30(-2.8450798084031987 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark30(-28.454325031590628 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark30(-2.8587611838648996 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark30(-28.615377873186333 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark30(-28.64991605869143 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark30(-28.666247825887353 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark30(-28.67722556068803 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark30(-28.702736185112173 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark30(-28.75970204357776 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark30(-28.77708821888332 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark30(-28.786592532586354 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark30(-28.78731883802743 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark30(-28.848435066818624 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark30(-28.928669320274963 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark30(-28.92920785912419 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark30(-28.964928285419816 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark30(-2.897101274715098 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark30(-28.981088024753745 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark30(-29.027885682251807 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark30(-29.071838611436277 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark30(-29.108221492037785 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark30(-29.13006948447847 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark30(-29.132528968030044 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark30(-29.16302050412314 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark30(-2.916373039312248 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark30(-29.181615065437356 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark30(-29.20153923174243 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark30(-29.229175413827505 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark30(-29.23514738768023 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark30(-29.248416685344793 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark30(-29.29128412433198 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark30(-29.361404436810716 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark30(-29.38090009677454 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark30(-29.429364768120507 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark30(-29.436360565035486 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark30(-29.46020163125705 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark30(-29.49358363716223 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark30(-29.53498507930594 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark30(-29.577534560834067 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark30(-29.589099610782043 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark30(-29.63777698316858 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark30(-29.655082691786006 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark30(-29.657622531556214 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark30(-29.684664546161656 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark30(-29.696579077748737 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark30(-29.70477611838622 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark30(-29.70578402434407 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark30(-29.713377256441035 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark30(-29.733717666595254 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark30(-29.75591301712477 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark30(-29.777511658095506 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark30(-29.786060207372273 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark30(-2.983980436240799 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark30(-29.851585345519084 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark30(-29.86085786750006 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark30(-29.89312373523309 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark30(-29.957604970166003 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark30(-30.019637422415357 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark30(-30.024708319308985 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark30(-30.042083698954684 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark30(-30.08102119107521 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark30(-30.097457464302792 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark30(-30.1713522143785 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark30(-30.28972855692625 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark30(-30.34271627810105 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark30(-30.361327560626904 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark30(-30.386914267910825 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark30(-3.0496803982126437 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark30(-30.502386889053156 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark30(-30.516544423981415 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark30(-30.53129963109582 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark30(-30.533935962432963 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark30(-30.588898505095656 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark30(-30.613176532059654 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark30(-30.635137355861318 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark30(-30.63729820210277 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark30(-30.68714949501468 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark30(-30.712216571169918 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark30(-30.72348764654494 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark30(-30.733338313989748 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark30(-30.741708578101452 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark30(-30.761077759009822 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark30(-30.81614775711141 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark30(-30.873504552330672 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark30(-30.901759176004703 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark30(-31.053522203972662 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark30(-31.127427835260463 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark30(31.164335698822725 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark30(-31.169044475701682 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark30(-31.18916917636207 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark30(-31.242220027406262 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark30(-31.245437090161545 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark30(-31.270435319647035 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark30(-31.308300447920857 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark30(-31.337503847032792 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark30(-31.367586310998277 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark30(-31.39479898413444 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark30(-31.402871734459097 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark30(-3.141820832917503 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark30(-3.142758536896224 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark30(-3.143801154212383 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark30(-31.483685563367402 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark30(-31.491991985113458 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark30(-31.52482680934594 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark30(-31.545949919894085 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark30(-31.59313542134086 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark30(-3.160532450471294 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark30(-31.607528277056446 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark30(-31.652336714203045 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark30(-31.688676349846318 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark30(-31.712096862613876 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark30(-31.785598639637698 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark30(-31.79545848344712 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark30(-31.817916983614495 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark30(-31.915950282917564 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark30(-31.91887316824736 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark30(-31.973567795491746 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark30(-31.987968319876074 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark30(-32.03920349986646 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark30(-32.08161653317738 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark30(-32.14860815284621 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark30(-32.17064165558479 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark30(-32.18973888090055 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark30(-32.20209992752312 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark30(-32.241549664874185 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark30(-32.25319045653919 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark30(-32.26243085838378 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark30(-32.27948325583631 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark30(-32.28414652408375 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark30(-32.32310318311022 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark30(-32.3385153244556 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark30(-32.34639839139915 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark30(-32.36063893556063 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark30(-32.41653349764688 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark30(-32.45615558446082 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark30(-32.47427543243346 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark30(-32.496596516220706 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark30(-32.531116034730005 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark30(-32.54966338762905 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark30(-32.62632268391259 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark30(-3.272728733249693 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark30(-32.74136973709794 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark30(-32.76641860338802 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark30(-32.905624187463616 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark30(-32.92899783553891 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark30(-32.93374491795595 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark30(-32.938024453469666 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark30(-32.94585080335479 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark30(-32.96688819401952 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark30(-33.014547759451915 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark30(-33.03236400492288 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark30(-33.05794079042117 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark30(-33.07570173095891 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark30(-33.091645372457876 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark30(-33.09434564981433 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark30(-33.1140861836312 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark30(-33.122850343339906 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark30(-33.125144382907166 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark30(-33.14644027227294 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark30(-33.16882215177614 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark30(-33.169653280182104 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark30(-33.17705146331696 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark30(-33.1917692229967 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark30(-33.19530281978369 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark30(-33.225542027328885 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark30(-33.27500482669127 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark30(-3.328289646677348 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark30(-33.332929912859896 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark30(-33.33342383504228 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark30(-33.41548708192616 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark30(-33.46231817152794 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark30(-33.465908663274746 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark30(-33.47463740766845 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark30(-33.52139164365926 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark30(-33.54154141881199 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark30(-33.578270403473056 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark30(-33.60667581615435 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark30(-33.696090521451836 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark30(-33.723693589311665 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark30(-33.73315740757114 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark30(-33.75464621360173 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark30(-33.76636860573723 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark30(-33.770554121900844 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark30(-3.3777955048933705 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark30(-33.78590695753945 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark30(-33.92740423441208 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark30(-33.945029233116486 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark30(-33.96978069202025 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark30(-34.007609832929674 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark30(-34.00849138157673 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark30(-34.03081954174108 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark30(-34.03616750746056 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark30(-3.4045598024062116 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark30(-34.082109290942086 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark30(-34.13362276579721 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark30(-34.146226995539664 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark30(-34.15534629731019 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark30(-34.15991455980544 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark30(-34.19269811874244 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark30(-34.22981298518708 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark30(-3.42323315150081 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark30(-34.23357994397162 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark30(-34.23815079467619 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark30(-34.25002850731573 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark30(-34.25119849873066 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark30(-34.25951477940059 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark30(-34.279079939499454 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark30(-34.284610740425364 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark30(-3.431567896994551 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark30(-34.32088891121687 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark30(-34.34280307317114 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark30(-34.375552885981264 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark30(-34.444931619029774 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark30(-34.57358340822809 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark30(-34.57685890529345 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark30(-3.457704054470099 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark30(-34.6099983606818 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark30(-34.6634675560403 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark30(-34.668667645287954 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark30(-34.676509319540074 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark30(-34.705691054638834 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark30(-34.75314231219855 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark30(-3.4774960839044695 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark30(-34.790756889067325 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark30(-34.809639124231694 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark30(-34.827510287287836 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark30(-34.84382493423905 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark30(-34.85241527780249 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark30(-34.86006185580857 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark30(-34.8705271794866 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark30(-34.88896235366819 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark30(-34.93469297286407 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark30(-35.02720870318372 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark30(-35.037031242126716 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark30(-35.052933052933795 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark30(-35.076044917250854 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark30(-35.09480134921165 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark30(-3.5211794590746877 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark30(-35.2756720995161 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark30(-35.29844129790661 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark30(-35.327774145316695 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark30(-35.33434654976131 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark30(-35.35141103628854 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark30(-35.404562668616364 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark30(-35.4584262292384 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark30(-3.547886481667234 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark30(-35.49198056124237 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark30(-35.5069814666185 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark30(-35.510519998270325 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark30(-35.56836204530089 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark30(-35.58863638882603 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark30(-3.561580072564311 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark30(-35.6406795965388 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark30(-3.5691628285846804 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark30(-35.7141578412502 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark30(-35.81365951529915 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark30(-35.829750392711674 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark30(-35.87351214124361 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark30(-35.87374665592276 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark30(-35.898970830909406 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark30(-35.93310026402925 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark30(-35.98031782689766 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark30(-35.98383560904779 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark30(-36.0116655564811 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark30(-36.02286722036831 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark30(-36.02420155660937 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark30(-36.03615119767365 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark30(-36.0479360106714 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark30(-36.109763453372246 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark30(-36.181149347430065 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark30(-36.185858204461674 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark30(-36.197401549304246 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark30(-36.273206739452846 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark30(-36.326233908482905 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark30(-36.33266554843786 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark30(-36.335141162075814 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark30(-36.36045532826917 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark30(-36.367767161521236 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark30(-36.373723060030436 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark30(-36.41561593841165 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark30(-36.47972124874279 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark30(-36.56424869118771 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark30(-36.58472155373931 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark30(-36.591726522033 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark30(-36.66674694136436 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark30(-36.68065580721787 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark30(-3.670618049451633 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark30(-36.79071283547064 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark30(-36.83991259775763 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark30(-36.88365514177798 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark30(-3.689691814438305 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark30(-36.95081976990249 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark30(-3.700599610629098 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark30(-3.7041998353252836 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark30(-37.09733639351664 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark30(-37.165644967076126 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark30(-37.25618290463728 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark30(-37.375382142654104 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark30(-37.40303774175035 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark30(-37.411006983378094 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark30(-37.53248649671998 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark30(-37.568990758922816 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark30(-3.7584075114618827 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark30(-37.62414140567929 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark30(-37.678283281457105 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark30(-3.7695479544651818 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark30(-37.72785695389948 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark30(-37.731237340755456 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark30(-37.77027782592046 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark30(-37.77835803478731 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark30(-37.78560418054035 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark30(-37.79079945631361 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark30(-37.81994094220082 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark30(-37.83501656033188 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark30(-37.843264614898885 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark30(-37.90064121904253 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark30(-37.955752493644134 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark30(-38.07556365835729 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark30(-38.11693212553058 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark30(-38.14935365590766 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark30(-38.1931768339431 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark30(-38.193793784823704 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark30(-38.29589457483862 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark30(-38.4433560226769 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark30(-38.449126508062314 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark30(-38.47598784592585 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark30(-38.51733267363593 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark30(-38.52185509863473 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark30(-3.858065541623205 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark30(-38.63920450301066 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark30(-38.673758094636156 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark30(-38.67757069133631 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark30(-38.68739106495094 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark30(-38.7724718435045 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark30(-38.784893299720856 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark30(-3.87929447427706 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark30(-38.79596908203593 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark30(-38.81766006855947 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark30(-38.84091063573658 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark30(-38.868952845925996 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark30(-38.86930925953591 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark30(-38.90750972853332 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark30(-38.90809406886642 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark30(-38.921746372291445 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark30(-38.96311844944498 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark30(-38.96541195049048 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark30(-38.96782846306821 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark30(-39.00555373360801 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark30(-39.07085068589786 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark30(-39.097195985713526 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark30(-39.112523522755005 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark30(-39.14942954218883 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark30(-39.21802352521324 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark30(-39.265231021619314 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark30(-39.288034669109685 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark30(-39.312288417513905 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark30(-39.321577374643454 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark30(-39.32648552497648 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark30(-39.34820647994235 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark30(-39.34864823464474 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark30(-39.35087603958771 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark30(-39.36556838375853 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark30(-39.39031328893512 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark30(-3.9417045978505456 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark30(-39.42725396567148 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark30(-39.433921189620904 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark30(-39.50565705887907 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark30(-3.9518277665442554 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark30(-39.53706932788006 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark30(-39.57162706606845 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark30(-39.650585373683 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark30(-39.68577600111971 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark30(-39.75767653806115 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark30(-39.79462680148094 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark30(-39.839119888798116 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark30(-39.84010151107788 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark30(-3.985119368848956 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark30(-3.986150526360248 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark30(-3.986603330497829 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark30(-39.90030625032362 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark30(-39.92863653575682 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark30(-39.95558869993092 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark30(-39.98945400211369 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark30(-3.999172496349786 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark30(-40.02410111722743 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark30(-40.02574676765798 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark30(-40.0524816327215 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark30(-40.05529629003186 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark30(-40.0564160696802 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark30(-40.07662831246903 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark30(-40.076820973302894 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark30(-40.1142480374588 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark30(-40.142596127232125 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark30(-40.24896296332019 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark30(-40.28693335994193 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark30(-40.29208640879403 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark30(-40.310144562232495 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark30(-40.34692381432503 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark30(-40.385414632101856 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark30(-40.39423474413286 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark30(-40.40209991422002 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark30(-40.404270285477885 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark30(-40.487441871454344 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark30(-40.51219290000798 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark30(-40.65511244370556 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark30(-40.70461006590027 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark30(-40.738663818641975 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark30(-40.75663553690825 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark30(-40.75804443099295 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark30(-40.78378115040962 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark30(-40.90887380709771 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark30(-40.93023219472478 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark30(-4.099166447924162 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark30(-41.07893728987499 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark30(-41.10975959768035 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark30(-41.14262356755973 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark30(-41.25894459330415 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark30(-41.26459857749589 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark30(-41.379787786813615 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark30(-41.39225148040029 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark30(-4.143588718384251 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark30(-41.542512012318845 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark30(-41.55300613924591 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark30(-41.556164099324654 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark30(-41.592127856122715 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark30(-41.60685657766929 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark30(-41.64176415682901 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark30(-41.644946617492096 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark30(-41.72620874410056 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark30(-41.72917916477979 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark30(-41.73283663785472 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark30(-41.751423286756676 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark30(-4.176199522482136 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark30(-41.866724171902156 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark30(-41.87426411045705 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark30(-41.91828920078182 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark30(-41.92798227185561 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark30(-41.959385195930096 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark30(-41.96365352456739 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark30(-42.06442979541911 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark30(-42.071065769150785 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark30(-42.12596412602072 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark30(-42.12977454738387 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark30(-4.2139374741964275 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark30(-42.18380083188589 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark30(-42.22042360991254 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark30(-4.223766066051084 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark30(-42.25666510461483 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark30(-42.26233350092392 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark30(-42.273405705521874 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark30(-42.2860272726828 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark30(-42.29001675004038 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark30(-42.29187461706423 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark30(-4.229275925783256 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark30(-42.31648392670741 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark30(-42.32104655405957 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark30(-42.349633227914005 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark30(-42.352617985099464 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark30(-42.36397800741156 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark30(-42.423877754223696 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark30(-42.519148851100816 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark30(-4.2526571857124225 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark30(-42.56551540704277 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark30(-42.5706970044492 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark30(-42.59208799899517 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark30(-42.62801128118336 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark30(-42.6301722222193 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark30(-42.6695648464513 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark30(-42.68394484012019 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark30(-4.273422537147582 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark30(-42.73471372926332 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark30(-42.81163675548187 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark30(-42.84065955207994 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark30(-42.850839186165636 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark30(-4.2855882106486405 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark30(-42.975039815793735 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark30(-42.98439855009371 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark30(-43.007155667225014 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark30(-43.113269250092756 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark30(-43.11767837767484 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark30(-43.121861453178 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark30(-4.315543086013918 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark30(-43.165711243364925 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark30(-43.16886472531836 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark30(-43.19142668868858 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark30(-43.20617673709124 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark30(-43.22143947780268 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark30(-43.26097085540972 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark30(-43.27723328602069 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark30(-43.329623402696704 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark30(-43.34276288733403 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark30(-43.34603552091001 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark30(-43.36220834753137 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark30(-43.3703610339147 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark30(-43.500761239899724 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark30(-4.35192031809521 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark30(-43.53212285533638 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark30(-43.554071882450614 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark30(-43.5680034682965 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark30(-43.60663586509932 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark30(-43.62969814006414 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark30(-43.79962640206507 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark30(-43.81004383494454 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark30(-43.84661122964273 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark30(-43.85529004780126 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark30(-43.944534874127505 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark30(-43.978609981851235 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark30(-43.98850312536202 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark30(-43.99877523350122 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark30(-44.01550923226589 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark30(-44.02422641980981 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark30(-44.113993041823974 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark30(-44.17421388629563 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark30(-44.192851753733756 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark30(-44.21346916878797 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark30(-44.22296448857765 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark30(-44.268721105337235 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark30(-44.28781170893616 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark30(-44.36724033539443 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark30(-44.40276827838652 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark30(-44.409284657722736 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark30(-44.41713778421483 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark30(-44.42052962817438 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark30(-44.47576883100899 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark30(-44.50208475480994 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark30(-44.51027271118895 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark30(-44.51164418143247 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark30(-44.515066901309154 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark30(-44.57827994443508 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark30(-44.587495255402885 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark30(-44.614006995388046 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark30(-44.63018309902738 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark30(-44.66152356554582 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark30(-44.69083838948777 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark30(-44.69561895117775 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark30(-44.73893842845629 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark30(-44.81859986459058 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark30(-44.83726305134563 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark30(-44.881020293978665 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark30(-44.889006356583664 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark30(-44.89436696630189 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark30(-44.959160795225394 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark30(-44.96161629181958 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark30(-4.500847300893199 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark30(-45.097070817275345 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark30(-45.160981613648346 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark30(-45.199389828508 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark30(-45.23832150810894 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark30(-45.242547971545655 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark30(-45.25317704268874 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark30(-45.30522012049227 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark30(-45.31527292108961 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark30(-45.32685785105242 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark30(-45.34361888835814 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark30(-4.536252467742912 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark30(-4.5371954139995125 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark30(-45.3733313632664 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark30(-45.40649106890478 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark30(-45.42150112819587 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark30(-45.48011567799479 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark30(-45.486641891655786 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark30(-45.53608349077689 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark30(-45.57172311758424 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark30(-45.600811154340605 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark30(-45.61263620713858 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark30(-45.68358343049981 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark30(-45.78447658720688 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark30(-45.79057711827077 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark30(-45.79451862445107 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark30(-45.81165827187333 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark30(-45.81705081233536 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark30(-45.8188767082117 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark30(-45.88458792192631 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark30(-45.901318573670565 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark30(-45.92094695910125 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark30(-45.95585217720068 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark30(-45.95926557173375 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark30(-45.97142446401081 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark30(-46.02960107089991 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark30(-46.063596077347334 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark30(-46.07642799712741 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark30(-46.090212410266716 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark30(-46.183728842949236 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark30(-46.30754501861611 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark30(-46.32918785033952 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark30(-46.330417359045285 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark30(-46.33814322519076 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark30(-46.35472635806794 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark30(-4.636420455091411 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark30(-46.415813770534896 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark30(-46.5003400928367 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark30(-46.517090930683416 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark30(-46.533505245863104 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark30(-46.54212140247302 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark30(-46.553240686334505 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark30(-46.676889830986035 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark30(-46.69522216100452 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark30(-46.69609192560191 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark30(-46.79487987139503 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark30(-46.810801424885625 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark30(-4.688651660510885 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark30(-46.899646618289445 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark30(-46.92126460727839 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark30(-47.01386420096701 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark30(-47.01760129640218 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark30(-47.038665687392054 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark30(-47.05905261014915 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark30(-47.11028143029454 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark30(-47.19472587269422 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark30(-47.23470184798204 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark30(-47.41584466031363 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark30(-47.43215022762999 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark30(-47.43635120238243 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark30(-47.47814222954254 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark30(-47.503901316272405 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark30(-47.5221856435732 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark30(-47.53663254783527 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark30(-4.754946104947095 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark30(-47.553894909571845 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark30(-47.56095155117739 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark30(-47.56928770812985 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark30(-4.757987012204822 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark30(-47.600542501381504 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark30(-47.68109737740471 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark30(-47.80165927462801 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark30(-47.8363182714846 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark30(-47.84508500368154 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark30(-47.853765029035486 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark30(-47.869565151634255 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark30(-47.895053860561035 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark30(-47.89677215419699 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark30(-47.918324329883674 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark30(-47.944912220670034 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark30(-47.95409245164315 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark30(-47.98541441277153 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark30(-47.99988962719033 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark30(4.80062702757462 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark30(-48.065728640379746 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark30(-48.06911714281905 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark30(-48.08543951339787 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark30(-48.12095965962919 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark30(-48.16041609876969 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark30(-48.1606742715341 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark30(-48.184198004684205 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark30(-48.21112597063508 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark30(-48.284635083048585 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark30(-48.28959182365491 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark30(-48.29016194049578 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark30(-48.32765584892764 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark30(-48.32972298261298 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark30(-48.335212820804884 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark30(-48.382585120501396 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark30(-48.39443147627138 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark30(-4.842305306570353 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark30(-48.43546806648167 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark30(-48.48423569253879 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark30(-48.4995111734813 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark30(-4.855371348801185 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark30(-48.56127232667951 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark30(-48.566163829916874 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark30(-4.858857341221807 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark30(-48.60726639357307 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark30(-48.66011773943404 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark30(-48.67080063913913 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark30(-48.67612964976533 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark30(-48.739593584523774 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark30(-4.8768098283069605 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark30(-48.76929387184952 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark30(-48.79165751802241 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark30(-48.84696370556241 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark30(-48.85728025257716 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark30(-4.885967904682161 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark30(-48.86622824888285 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark30(-48.87568842884127 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark30(-48.87783725109518 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark30(-48.881896176204506 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark30(-48.88193226762581 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark30(-48.92391562722498 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark30(-48.99171739995738 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark30(-49.064015053011104 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark30(-49.10123555574397 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark30(-49.10425576076038 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark30(-4.915840172680234 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark30(-4.916228455356261 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark30(-49.182093325952934 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark30(-49.18572777321521 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark30(-49.24542477494385 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark30(-49.251487897181654 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark30(-49.30724675126512 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark30(-49.30794289027274 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark30(-49.32640035279208 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark30(-49.33014109353984 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark30(-49.44268967750891 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark30(-49.549314707189126 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark30(-49.56899855789341 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark30(-49.601212213255884 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark30(-4.966937548812567 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark30(-49.67594413538874 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark30(-49.69256093709657 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark30(-49.70417452119573 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark30(-49.761109068653056 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark30(-49.85001386901307 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark30(-49.89535188966951 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark30(-49.89659536088966 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark30(-49.93151126188904 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark30(-49.95807319411873 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark30(-49.99017147843175 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark30(-50.019601795606874 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark30(-50.065274831463455 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark30(-50.131865102724184 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark30(-5.015279290230495 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark30(-50.209826003255856 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark30(-50.25642633705911 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark30(-50.25961780655599 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark30(-50.31023318270529 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark30(-50.33918085803546 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark30(-50.41837093368129 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark30(-50.425997974459676 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark30(-50.459910097029706 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark30(-5.049712391501188 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark30(-50.52403953091098 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark30(-50.55109305730967 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark30(-50.55809678728149 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark30(-50.57717975280846 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark30(-50.62613660790161 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark30(-50.720728161969134 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark30(-50.792060822706866 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark30(-5.083146706233649 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark30(-50.89315572443791 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark30(-50.894957373340446 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark30(-50.99685893596404 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark30(-51.01015718436339 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark30(-51.11319976063295 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark30(-51.18665551547452 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark30(-51.25389795366362 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark30(-51.2641989126152 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark30(-51.3013918833513 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark30(-51.32779301086294 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark30(-51.34548084470249 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark30(-51.35544389021209 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark30(-51.380772482976944 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark30(-51.55398166035323 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark30(-51.61596497903969 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark30(-51.68752628027185 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark30(-51.699204725706885 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark30(-51.731149208481206 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark30(-51.74939596167483 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark30(-51.76705567617017 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark30(-5.17992175772541 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark30(-51.799520929237495 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark30(-51.82992097778967 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark30(-51.836611912787966 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark30(-51.84137211159023 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark30(-51.858255216365045 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark30(-51.858780958895714 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark30(-51.9395584685695 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark30(-5.200223671256651 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark30(-52.100698445849545 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark30(-5.2105196681535375 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark30(-52.107527642639354 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark30(-5.211175115664332 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark30(-52.124771675095175 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark30(-52.13435552141969 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark30(-52.1475326398132 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark30(-52.15668602693777 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark30(-52.18282942348269 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark30(-5.21876437626598 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark30(-52.201602031446946 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark30(-52.20788934197982 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark30(-52.258152503301794 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark30(-52.25905123049661 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark30(-52.27616152324644 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark30(-52.28317807677756 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark30(-52.334046183297914 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark30(-52.34555093484208 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark30(-5.237868703830628 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark30(-52.38897775598985 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark30(-52.389938389903335 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark30(-52.39037349507052 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark30(-52.475797963416284 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark30(-52.4859062767663 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark30(-5.249945164649546 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark30(-52.52536984972303 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark30(-5.260086264443629 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark30(-52.61472173966651 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark30(-52.67426411710663 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark30(-52.67645628535958 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark30(-52.7894882940807 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark30(-5.285462960586827 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark30(-52.85806565674811 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark30(-52.87537627347725 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark30(-52.90403260101997 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark30(-52.90551648476547 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark30(-52.931788167338325 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark30(-53.01022876201933 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark30(-5.303782101221714 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark30(-53.1255565100299 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark30(-53.37785883917843 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark30(-53.38048665870496 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark30(-53.38537781799655 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark30(-53.39228128155214 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark30(-5.340792127943317 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark30(-53.410176100214436 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark30(-53.415781283865506 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark30(-53.44569212149588 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark30(-53.446311943522296 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark30(-53.48667658736079 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark30(-53.49649842373063 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark30(-53.499611480076936 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark30(-53.51631654575895 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark30(-53.53564483791104 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark30(-53.55210018101823 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark30(-53.55426726009347 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark30(-53.57895667053065 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark30(-53.61652249155575 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark30(-53.626800411993926 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark30(-53.64016893528982 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark30(-53.651159217027924 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark30(-53.69308496070564 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark30(-53.69715632406855 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark30(-53.739873755991695 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark30(-53.76650103106484 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark30(-5.383597434640407 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark30(-53.89606234685742 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark30(-53.898607170652355 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark30(-53.907358200386746 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark30(-53.917710586081256 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark30(-53.922008162035475 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark30(-53.95011632905735 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark30(-53.952036030980956 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark30(-54.05160370567972 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark30(-54.11708239620599 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark30(-54.161297281919055 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark30(-54.163368067155716 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark30(-54.1716157546448 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark30(-54.25824972517459 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark30(-54.28502071208374 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark30(-54.31088831822039 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark30(-54.35915996614986 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark30(-54.36927195912822 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark30(-54.374962805999004 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark30(-5.4392424493029665 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark30(-54.487682795392956 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark30(-54.59148684162367 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark30(-54.64504189560388 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark30(-54.64612244644185 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark30(-54.65063361755074 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark30(-54.66169989303127 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark30(-54.69628031655154 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark30(-54.72699726089172 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark30(-54.733531775389196 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark30(-54.823625331815194 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark30(-54.85203207236901 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark30(-54.86267816451797 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark30(-5.498760599276565 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark30(-55.07254470506506 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark30(-55.09787185810848 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark30(-55.104007074822306 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark30(-55.19527781754261 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark30(-5.51998818066788 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark30(-55.22699080826832 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark30(-55.22902830385972 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark30(-55.26752094819454 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark30(-55.2820137247241 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark30(-55.310495184851916 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark30(-55.33272383691323 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark30(-55.33887083810658 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark30(-55.41496907477512 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark30(-55.415188912840165 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark30(-55.45339899870303 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark30(-55.508375087464515 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark30(-55.50851547147604 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark30(-55.509129837511686 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark30(-55.53364745204099 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark30(-55.55139287794797 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark30(-55.57361692118023 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark30(-55.619878322466136 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark30(-55.63973561015636 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark30(-55.64845347522998 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark30(-55.68271420583335 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark30(-55.68966841381942 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark30(-55.716488208682605 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark30(-55.80192395576995 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark30(-55.85278219829617 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark30(-5.586381442006655 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark30(-55.8724095533133 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark30(-55.930791941964976 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark30(-55.978120205501455 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark30(-55.986775416140546 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark30(-55.9990257069706 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark30(-56.027562082126934 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark30(-56.04571300505945 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark30(-56.06183848562871 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark30(-56.088383698545115 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark30(-56.10841709669643 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark30(-56.160826588499944 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark30(-56.2038500291939 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark30(-56.21945895369922 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark30(-56.238072250909866 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark30(-56.240984499697674 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark30(-56.25568641328793 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark30(-56.26075060923708 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark30(-56.28902201773309 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark30(-56.30560844469132 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark30(-56.32658272215749 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark30(-56.35697905396641 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark30(-56.374484022832206 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark30(-56.44501467460841 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark30(-56.47667892060977 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark30(-56.508345194895696 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark30(-56.61528963855744 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark30(-56.6265906343518 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark30(-56.64273066982155 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark30(-56.6639541175167 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark30(-56.6794345199271 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark30(-56.72760409287132 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark30(-56.74315785601913 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark30(-56.78372531789431 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark30(-56.80253328898539 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark30(-56.84389423223271 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark30(-56.84648408236199 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark30(-56.876775441559005 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark30(-56.88440984795127 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark30(-56.88788045520907 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark30(-56.96010733477919 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark30(-56.96652590667486 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark30(-56.99298474554877 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark30(-57.09838851579174 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark30(-57.10380829819957 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark30(-57.1778687301969 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark30(-57.192810582105416 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark30(-57.19652297114168 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark30(-57.199934075957785 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark30(-57.21579504551699 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark30(-57.22196552517278 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark30(-57.23883752450312 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark30(-57.2630625689112 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark30(-57.269789394923954 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark30(-57.34315639130272 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark30(-57.348021321995546 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark30(-57.374136084069384 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark30(-57.383577881912885 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark30(-57.38396784375834 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark30(-57.384777336735105 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark30(-57.39432513829597 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark30(-57.40354623829431 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark30(-57.43508455858988 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark30(-57.4695266783734 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark30(-57.47100986477769 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark30(-57.473239614946166 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark30(-57.523879923520084 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark30(-57.52410658188598 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark30(-57.545859580685075 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark30(-57.57625707227376 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark30(-57.59607069290442 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark30(-57.60568429959625 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark30(-57.62858876497374 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark30(-5.766507979247365 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark30(-57.668018248411144 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark30(-5.769410034765542 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark30(-57.71612019637542 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark30(-57.71932172589462 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark30(-57.73572601408639 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark30(-57.77682314331547 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark30(-57.778028010309555 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark30(-57.81754286197316 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark30(-57.886365288946905 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark30(-57.88926538938666 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark30(-57.93577049230218 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark30(-5.795690546991068 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark30(-57.96189197861323 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark30(-58.035157715285536 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark30(-58.04652059798288 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark30(-5.806263575108559 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark30(-58.11711397968167 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark30(-58.12109338767251 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark30(-58.14434041471499 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark30(-58.18774747437416 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark30(-5.821842277806837 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark30(-58.242288251971154 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark30(-58.25086385196758 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark30(-58.255636545743684 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark30(-58.27971431708112 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark30(-5.828679372285038 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark30(-58.29521337871431 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark30(-58.29793672290309 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark30(-58.33088163266675 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark30(-58.33596364611746 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark30(-58.432800217927294 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark30(-58.457739047920576 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark30(-58.45774884440276 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark30(-58.46106095689245 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark30(-58.5041732937432 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark30(-58.60439251328753 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark30(-58.60696568795698 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark30(-58.61267287522869 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark30(-58.64563080998766 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark30(-58.658403672289495 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark30(-58.65893095465196 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark30(-58.6675514613973 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark30(-58.71728393957609 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark30(-58.7235867239946 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark30(-5.879072425738755 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark30(-58.804487242901146 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark30(-58.81155319533848 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark30(-58.81621358209921 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark30(-58.86863733291226 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark30(-58.91162904644378 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark30(-5.911821284903624 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark30(-59.13831484072849 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark30(-5.9148186990760365 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark30(-59.17637855410969 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark30(-59.21921409755786 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark30(-59.24593577993833 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark30(-59.255285521615434 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark30(-59.38650640913428 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark30(-59.4311878191587 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark30(-59.48108171062827 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark30(-59.48469127410792 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark30(-59.5021424076424 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark30(-59.51842712564939 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark30(-59.54052407215886 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark30(-59.583380666025064 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark30(-59.61311061715959 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark30(-59.61415121742195 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark30(-59.660642352798085 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark30(-59.67603807635528 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark30(-59.72554252788049 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark30(-59.7710250008658 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark30(-59.77640952252321 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark30(-5.981281081427085 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark30(-59.86591835290325 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark30(-59.93643448435893 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark30(-59.9523423175421 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark30(-59.96502902479652 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark30(-59.98114333093698 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark30(-60.02739557799806 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark30(-60.04196204347192 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark30(-60.04479738128066 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark30(-60.0938894414113 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark30(-60.26596385039091 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark30(-60.288907531720824 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark30(-60.3201988158647 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark30(-60.35102342366414 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark30(-60.3577886871818 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark30(-60.39061447398855 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark30(-60.4024828903329 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark30(-60.45407814213684 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark30(-60.49318821521603 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark30(-60.50355501604094 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark30(-60.55829084548932 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark30(-60.57083404865429 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark30(-60.58270611405601 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark30(-60.596040823148066 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark30(-60.59613061665219 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark30(-60.59975257695025 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark30(-60.61301957519267 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark30(-60.67019806293015 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark30(-60.67633018743559 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark30(-60.67646724322837 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark30(-60.682889888631266 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark30(-60.706316157937955 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark30(-6.071628332572601 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark30(-60.7379746805683 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark30(-60.738806702052315 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark30(-60.76105079909138 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark30(-60.779787661039904 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark30(-60.9507654664734 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark30(-6.096732181132424 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark30(-61.01321345411201 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark30(-6.1033614473869875 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark30(-61.036353709422485 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark30(-61.11858928642948 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark30(-61.125734510053256 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark30(-61.13108215356115 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark30(-61.1435289531923 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark30(-61.22298131550021 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark30(-61.26942795998582 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark30(-6.133486646619787 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark30(-61.34682557350379 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark30(-61.35306022539477 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark30(-61.370895428251316 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark30(-61.38184094159984 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark30(-61.38821284695428 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark30(-61.42292971841836 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark30(-6.144915377953225 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark30(-61.51378754868348 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark30(-61.52865615874579 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark30(-61.540630650579644 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark30(-61.54501021199561 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark30(-61.62053505568406 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark30(-6.162975822039155E-33 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark30(-61.84037913594078 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark30(-61.93489800065299 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark30(-61.946539522535616 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark30(-61.949598719966545 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark30(-6.1953734869641295 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark30(-61.954929408565576 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark30(-61.97601099895409 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark30(-6.200249109900653 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark30(-62.084377750422505 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark30(-62.11789609444682 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark30(-62.17970147253531 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark30(-62.20401633743007 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark30(-62.20594562426891 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark30(-62.21981715414924 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark30(-62.343312491663625 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark30(-62.43598327839655 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark30(-6.24362238498162 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark30(-62.43728673457838 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark30(-62.47155448770889 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark30(-62.48568931723941 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark30(-62.49353604914918 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark30(-62.50609891048071 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark30(-62.506163017026054 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark30(-62.508400903619574 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark30(-62.51122753583924 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark30(-62.522385859285976 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark30(-62.523575945264966 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark30(-62.5900827406233 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark30(-62.59008740873067 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark30(-62.609097529617365 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark30(-62.65832402856179 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark30(-62.704464913861166 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark30(-62.70596034364537 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark30(-62.78232107397812 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark30(-62.806962735795715 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark30(-62.81326739036936 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark30(-62.95017592646399 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark30(-62.97830864738534 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark30(-63.07452605799382 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark30(-63.112569278080265 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark30(-63.11716669352065 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark30(-6.314119663216488 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark30(-63.15272407710613 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark30(-63.184992522954396 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark30(-63.27789670006829 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark30(-63.364714015359084 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark30(-63.39360888312151 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark30(-63.40276401928766 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark30(-63.43530067195824 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark30(-63.440421447517956 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark30(-63.44232047779808 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark30(-6.345798325306063 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark30(-6.346916672899994 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark30(-63.48582551697628 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark30(-63.53962723588103 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark30(-63.54336465255479 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark30(-63.56490404420101 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark30(-63.62889833865608 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark30(-63.63308311594427 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark30(-63.66908432136371 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark30(-63.67176463546209 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark30(-63.67555845130974 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark30(-63.68532030433796 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark30(-63.70484550427942 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark30(-6.371721510721073 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark30(-6.3757676698195525 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark30(-63.83923287657682 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark30(-63.87522872450568 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark30(-63.8757428448119 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark30(-63.895633922713735 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark30(-63.91404328553576 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark30(-63.92768876691566 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark30(-63.93048680754853 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark30(-63.94454988236 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark30(-63.96255487136542 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark30(-64.01900625907558 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark30(-64.12119759916627 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark30(-64.12846966872014 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark30(-64.17901014965832 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark30(-64.21416817436803 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark30(-64.22639407861095 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark30(-64.23851356021193 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark30(-6.423863711623042 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark30(-64.30409868374201 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark30(-64.34156287463281 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark30(-64.34940061479543 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark30(-64.39194690453616 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark30(-64.40662980914249 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark30(-64.46492204527298 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark30(-64.54001665657019 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark30(-64.6412324036525 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark30(-64.65726995809891 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark30(-64.66615708481716 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark30(-64.70534206399417 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark30(-64.7696512660028 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark30(-64.81067301133643 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark30(-64.83125119179911 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark30(-64.91147429066586 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark30(-64.91406932604283 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark30(-64.95267759250652 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark30(-64.9629201487283 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark30(-6.496688452858962 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark30(-65.01164593146602 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark30(-65.04914743143222 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark30(-65.05629532968445 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark30(-65.07864502748417 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark30(-6.50896644554868 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark30(-65.11650639887188 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark30(-65.11683198479759 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark30(-65.12389159392886 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark30(-65.13418992578309 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark30(-65.13647239276321 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark30(-65.14191012080259 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark30(-65.18901314171947 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark30(-65.19325072643639 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark30(-65.19872933803572 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark30(-65.20787798302199 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark30(-65.21488332553307 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark30(-65.2514181174659 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark30(-65.28403235529274 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark30(-65.2966420123361 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark30(-6.529968985177263 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark30(-65.32309408076932 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark30(-65.32570097748942 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark30(-6.535871551895383 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark30(-65.41336259011118 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark30(-65.42761663838954 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark30(-65.42966595311808 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark30(-65.45872623742655 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark30(-65.46875657013356 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark30(-65.49622607183593 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark30(-65.56376906405679 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark30(-65.59557264194164 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark30(-6.560553958198099 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark30(-65.63741450926096 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark30(-65.67287822951059 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark30(-65.78496921631137 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark30(-6.5855615361881945 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark30(-65.87376832052038 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark30(-65.94938330098807 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark30(-65.95782855230621 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark30(-65.96429930902445 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark30(-65.99400618621559 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark30(-66.0075832737825 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark30(-66.07988867304033 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark30(-66.10061638647508 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark30(-66.125467690808 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark30(-66.16272497336334 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark30(-66.27857540008313 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark30(-66.32561873284786 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark30(-66.33087543418569 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark30(-66.34653938584447 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark30(-66.35796673847902 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark30(-66.42868489194703 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark30(-66.44468013089269 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark30(-66.45083612682461 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark30(-66.4606332614886 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark30(-66.47463013950055 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark30(-66.47746448655585 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark30(-66.55195920350963 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark30(-6.6587298445480485 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark30(-6.661272318388086 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark30(-6.663375105590717 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark30(-6.663907248658347 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark30(-66.64859515275779 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark30(-66.77411503831294 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark30(-6.678957903575153 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark30(-66.84360033079889 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark30(-66.85589585144996 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark30(-66.89934110932442 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark30(-66.99179174427412 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark30(-66.9997250186903 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark30(-67.00119020644888 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark30(-67.00833665085553 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark30(-67.08939851782335 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark30(-67.09023582176674 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark30(-67.17682178057463 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark30(-67.18373446076947 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark30(-67.18761604872563 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark30(-67.18909619423097 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark30(-67.20829121940122 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark30(-67.21868161477782 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark30(-67.2273172691323 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark30(-67.25337857879414 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark30(-67.27866817049116 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark30(-67.31632829708894 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark30(-67.3257604756437 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark30(-6.7328431252683885 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark30(-67.35587878343318 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark30(-67.37889977868332 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark30(-67.43278735189338 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark30(-67.46506122805518 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark30(-67.55141444950377 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark30(-67.55227099136792 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark30(-67.59709824482047 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark30(-67.6006637824191 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark30(-67.61835091046927 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark30(-67.72502143518619 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark30(-67.72526874141445 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark30(-67.72831203843197 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark30(-6.774958127363945 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark30(-67.75129894881982 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark30(-67.76572370177843 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark30(-67.77692256747224 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark30(-67.80539605314559 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark30(-67.82647777737466 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark30(-67.9221831441495 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark30(-68.00113887324291 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark30(-68.01120943507047 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark30(-68.12108030307367 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark30(-68.16200670253502 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark30(-68.1849702249632 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark30(-68.2216819856417 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark30(-68.29089610150132 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark30(-68.29933068286101 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark30(-68.32833754733355 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark30(-68.45071883361462 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark30(-68.51524736861008 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark30(-68.5395647255855 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark30(-6.856335541906674 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark30(-68.58903272365286 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark30(-68.59161296286074 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark30(-68.66024058868501 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark30(-6.8764496741226395 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark30(-6.878170676259643 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark30(-68.81399417380634 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark30(-68.82168693621489 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark30(-68.87194205848061 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark30(-6.891965755948235 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark30(-69.00357840229705 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark30(-6.901183644176044 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark30(-69.06991124615021 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark30(-69.08921147425497 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark30(-69.12219417647535 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark30(-69.16007573397573 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark30(-69.16023876149504 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark30(-69.19304904666876 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark30(-69.23894701102199 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark30(-69.2545404656709 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark30(-69.29666327765148 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark30(-69.30530598631732 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark30(-69.30783636031333 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark30(-69.38301857828111 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark30(-69.41088022989214 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark30(-69.41842702275298 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark30(-6.945645503131942 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark30(-69.51584255637411 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark30(-69.61735529886587 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark30(-69.66383389843385 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark30(-69.77681827324199 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark30(-69.7972718741296 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark30(-69.851483698933 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark30(-69.87445793024455 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark30(-69.90953687633446 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark30(-69.98707153807806 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark30(-7.004027371667078 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark30(-70.09646920456788 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark30(-70.14235800837434 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark30(-70.14255214033791 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark30(-70.15196810826137 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark30(-70.16891754339255 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark30(-7.017589556535398 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark30(-70.19913011847352 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark30(-70.20551665619404 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark30(-70.3018998441505 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark30(-70.3893418930671 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark30(-70.45222758231584 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark30(-70.49931991271352 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark30(-70.52832741887678 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark30(-70.56102382242884 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark30(-70.56648164938441 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark30(-70.56797675284497 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark30(-70.58050553272604 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark30(-70.58238104670417 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark30(-7.0583885312352805 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark30(-70.6145319323563 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark30(-70.63978831737518 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark30(-70.6652860986158 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark30(-70.66594371927198 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark30(-7.070925591760485 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark30(-70.73470483108575 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark30(-70.73894658441004 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark30(-70.75472257432463 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark30(-70.82023490699109 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark30(-70.850835582841 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark30(-70.99205851253012 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark30(-71.05745708634387 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark30(-71.12664229453569 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark30(-71.17637916518854 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark30(-71.27116187372656 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark30(-71.3170879182059 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark30(-71.42895303209457 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark30(-71.46916055813628 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark30(-71.48766532573785 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark30(-7.149828958838185 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark30(-71.51148200231901 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark30(-71.52071503814375 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark30(-71.55109998622947 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark30(-7.164414769187658 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark30(-71.6476425562677 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark30(-71.69188902094882 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark30(-71.70470611192148 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark30(-7.177114542636758 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark30(-71.79639627120781 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark30(-71.81033572290738 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark30(-71.81236897035924 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark30(-71.87005742533357 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark30(-71.92607384271582 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark30(-71.96105688721232 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark30(-71.96190319231792 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark30(-71.97134340521345 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark30(-71.98495166945096 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark30(-72.0168513850361 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark30(-72.04361066885795 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark30(-7.206843216150787 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark30(-72.06859732472901 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark30(-72.08538894682121 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark30(-72.10857388694617 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark30(-72.14301732173098 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark30(-7.2150035131412125 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark30(-72.17883415545067 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark30(-7.21840358598935 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark30(-72.19449224534301 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark30(-72.25034677612712 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark30(-72.32089274605315 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark30(-72.32929935304114 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark30(-72.3469918314815 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark30(-72.37045811030265 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark30(-72.38126755685505 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark30(-72.43605362481213 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark30(-72.44519476123044 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark30(-72.49382061871559 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark30(-72.49765681652933 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark30(-72.50313730716641 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark30(-72.54139515805085 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark30(-72.57104131469316 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark30(-7.257478583552341 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark30(-72.60215283285496 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark30(-7.2615017209027855 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark30(-72.69598344244281 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark30(-72.71506079508379 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark30(-72.72214939206796 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark30(-72.72406232171099 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark30(-72.75906181583258 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark30(-72.76065216565961 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark30(-72.82166995320489 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark30(-72.90477738365004 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark30(-72.91107325858806 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark30(-72.98328568991586 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark30(-73.01493876028964 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark30(-7.315730791930733 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark30(-73.16198312097396 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark30(-7.319660044590364 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark30(-73.22504087292563 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark30(-73.27544200621827 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark30(-73.29851410468086 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark30(-73.3523348329291 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark30(-7.335294840330093 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark30(-73.36149021367495 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark30(-73.42984852844464 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark30(-73.45182029316084 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark30(-73.53705044140253 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark30(-73.56272171903193 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark30(-73.58300097196681 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark30(-73.58486302309458 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark30(-7.358770856162963 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark30(-73.59281127447275 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark30(-73.6236464041433 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark30(-73.64283187097709 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark30(-73.70006877551303 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark30(-73.73874873611143 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark30(-73.74315201177006 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark30(-73.7912022028667 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark30(-73.84381119404418 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark30(-73.92953236678157 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark30(-7.3933245796542195 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark30(-73.95644529008673 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark30(-73.97986223263975 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark30(-74.09739023201121 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark30(-7.41068799509803 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark30(-74.14547876769015 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark30(-74.14677696184842 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark30(-74.16210189677753 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark30(-74.16958175419313 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark30(-7.417861110607134 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark30(-74.18377508761765 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark30(-74.24542684366382 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark30(-74.26867689947147 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark30(-74.31989325347428 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark30(-74.36519954569722 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark30(-74.43420733830506 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark30(-74.47168313283245 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark30(-74.50351658205312 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark30(-74.54859566753697 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark30(-7.45984866294944 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark30(-74.617581322386 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark30(-74.64321600995464 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark30(-74.64333342089533 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark30(-74.67058296186437 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark30(-74.68795485673456 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark30(-74.69157257586703 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark30(-74.7306077251864 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark30(-7.479570111567128 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark30(-74.7974417585001 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark30(-74.80714381520761 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark30(-74.84529774649943 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark30(-74.92415358737429 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark30(-74.96295953630936 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark30(-74.99753589499507 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark30(-7.503391511941388 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark30(-75.04257664054721 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark30(-75.05700359554393 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark30(-75.0949422016599 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark30(-75.13708921745575 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark30(-75.14720126319489 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark30(-75.16804546016584 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark30(-75.1700576283244 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark30(-75.18204852100482 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark30(-75.18756445707851 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark30(-75.20086440088929 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark30(-75.2072257812567 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark30(-75.20960229787639 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark30(-75.21028120612684 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark30(-75.2174180448741 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark30(-75.22439183326048 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark30(-75.24567209977111 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark30(-75.25355005003047 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark30(-75.25903008683177 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark30(-7.527755681154787 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark30(-75.31839437110199 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark30(-7.5357905949247055 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark30(-75.38123287458767 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark30(-75.39021667045789 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark30(-75.40271626820791 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark30(-75.435364611607 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark30(-75.46642998525353 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark30(-75.50047404070213 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark30(-75.54303406158374 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark30(-75.5585178209039 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark30(-75.61846218984843 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark30(-75.6304456881228 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark30(-75.66710950071933 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark30(-75.68229805499735 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark30(-75.69018880905432 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark30(-75.71726658551161 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark30(-7.575937503331829 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark30(-75.7597291352671 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark30(-75.80119994961294 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark30(-75.80981241936686 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark30(-75.85043228674589 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark30(-75.88891694986049 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark30(-75.8894956968525 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark30(-75.89799038103897 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark30(-7.601614873935603 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark30(-76.11670770339099 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark30(-76.14439305026615 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark30(-76.15017778992927 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark30(-76.18882347604034 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark30(-7.620712630515868 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark30(-76.21900114143418 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark30(-76.24588054590922 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark30(-76.35956873600902 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark30(-76.37796882756675 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark30(-76.41563827600521 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark30(-76.43334834037923 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark30(-76.47595638497107 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark30(-76.53746209203156 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark30(-76.56278088817905 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark30(-76.56849783362851 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark30(-7.65718434395248 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark30(-76.61577949873273 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark30(-76.69837901682526 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark30(-7.6724212610050415 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark30(-76.80658048293088 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark30(-76.8083757126156 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark30(-76.82231334399626 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark30(-76.82885530516461 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark30(-76.83472379767701 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark30(-76.86729426831567 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark30(-7.692527806922513 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark30(-7.698524064642569 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark30(-77.01893722817823 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark30(-77.02117325635135 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark30(-77.04147863909463 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark30(-77.0667915566628 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark30(-7.716354849159373 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark30(-77.20553356967186 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark30(-77.22781638407511 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark30(-77.25381846506465 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark30(-77.27996237651655 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark30(-7.732161823918034 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark30(-77.3272503575948 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark30(-77.34302358097152 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark30(-77.3539833252207 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark30(-77.41899858462148 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark30(-77.42476775959165 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark30(-7.742764298748767 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark30(-77.43419157031788 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark30(-77.44387204391305 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark30(-77.45644553290009 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark30(-77.4710429533239 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark30(-77.47225106544649 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark30(-77.47648271247856 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark30(-77.48187383500498 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark30(-77.49572108216293 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark30(-77.56155277010231 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark30(-77.58601648238542 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark30(-77.60549664294805 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark30(-77.60633541588004 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark30(-77.6323619029921 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark30(-77.70361810205067 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark30(-77.7542404532773 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark30(-77.76013441017149 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark30(-77.763012264658 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark30(-77.7791875325961 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark30(-77.7940685123124 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark30(-77.79970336312138 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark30(-7.782273330931304 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark30(-77.88338991671813 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark30(-77.92009809937875 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark30(-77.9236450666198 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark30(-77.99329844378863 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark30(-78.00060034634623 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark30(-78.05283361577939 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark30(-78.05517691421156 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark30(-78.09247126195982 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark30(-7.810249176044891 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark30(-78.1522713061818 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark30(-78.1832138269614 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark30(-7.821809274058467 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark30(-78.27050263831812 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark30(-78.27749798060661 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark30(-78.28262973094738 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark30(-78.30215377183747 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark30(-78.31598372485055 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark30(-78.37508733023961 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark30(-7.842459085070303 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark30(-78.47662899475239 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark30(-78.58212927333113 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark30(-78.63071698537998 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark30(-78.6375844699054 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark30(-7.864331086822446 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark30(-78.64846597238603 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark30(-78.6928074937596 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark30(-78.71568505203416 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark30(-78.73953648219228 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark30(-78.83233389555869 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark30(-78.8799688602262 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark30(-78.89943835706843 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark30(-78.93564226658967 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark30(-7.900208304912866 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark30(-79.003850287175 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark30(-79.02802371157244 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark30(-79.08536868861198 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark30(-79.15162863313185 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark30(-79.1638739983002 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark30(-7.917284629978454 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark30(-79.20397303385897 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark30(-79.21353041894747 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark30(-79.22280102407501 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark30(-79.32175956586977 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark30(-79.34515702889848 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark30(-79.4449301706881 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark30(-79.51482645466565 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark30(-79.54169509321085 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark30(-79.59181332210605 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark30(-79.62972600764806 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark30(-79.6465761336727 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark30(-79.65476853280977 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark30(-79.66068953633203 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark30(-79.66389449428894 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark30(-79.6692629586871 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark30(-79.72199526333053 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark30(-79.73137647638092 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark30(-79.73845068231697 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark30(-79.78117978022306 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark30(-79.81485804981132 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark30(-79.8494603320749 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark30(-7.986464133735296 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark30(-79.92696036690121 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark30(-79.94068027074657 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark30(-79.95067667091071 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark30(-79.97276839038491 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark30(-79.99730155739293 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark30(-8.010414142451609 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark30(-80.1225348268479 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark30(-80.1488451270551 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark30(-80.16461212149552 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark30(-8.016603743463065 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark30(-80.1800112457579 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark30(-80.26915683857874 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark30(-80.3417628628433 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark30(-80.39638541104826 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark30(-80.45894962017238 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark30(-80.47698733575078 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark30(-80.49905238586791 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark30(-80.50641630925219 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark30(-80.53389055725168 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark30(-80.56158424688837 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark30(-80.56975520152076 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark30(-80.57821905596619 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark30(-80.661405403275 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark30(-80.66701106257847 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark30(-80.71353556892302 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark30(-80.71567946976859 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark30(-80.71678443735746 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark30(-80.71788368061483 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark30(-80.74463860596651 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark30(-80.7571267505492 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark30(-80.76044249693545 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark30(-80.7644103935136 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark30(-80.80039405427921 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark30(-80.8168130454862 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark30(-80.84747187417669 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark30(-80.8666458373153 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark30(-80.87946826954642 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark30(-80.92262938083898 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark30(-80.94608540223564 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark30(-8.101094256974022 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark30(-81.03709456556476 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark30(-81.05041724318376 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark30(-81.06689856101792 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark30(-81.08028355966749 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark30(-81.1144947897964 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark30(-81.11901519186691 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark30(-81.1201155799216 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark30(-81.15861311730444 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark30(-81.2175637728069 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark30(-81.23416043540526 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark30(-81.28979522416743 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark30(-81.4356821665449 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark30(-81.47955694327031 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark30(-81.5978712585145 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark30(-81.59842669519657 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark30(-81.63438388742668 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark30(-8.166425050231524 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark30(-81.7136403871221 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark30(-81.75934325988749 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark30(-81.82375848574854 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark30(-8.184491206019473 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark30(-8.187481518628559 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark30(-81.88577148584768 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark30(-81.94015327696478 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark30(-81.98837541557131 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark30(-81.99742004578319 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark30(-82.00903742623979 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark30(-82.02249456369096 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark30(-82.03834430075753 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark30(-82.05233109059269 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark30(-82.10787043517573 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark30(-82.18087859581694 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark30(-82.22164832317176 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark30(-82.3265125961698 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark30(-82.34150984342585 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark30(-82.35617667142215 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark30(-8.24215118721969 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark30(-82.44664281517377 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark30(-82.52986683992624 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark30(-82.5348498458221 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark30(-82.56133069142982 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark30(-82.62483042242494 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark30(-82.6273857958463 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark30(-8.263344622666907 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark30(-82.65831785450743 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark30(-82.69483412518028 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark30(-82.73652520813349 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark30(-82.73890103446612 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark30(-82.798742169968 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark30(-82.81717568530429 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark30(-82.8352752043032 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark30(-82.83871912312352 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark30(-82.86028718318249 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark30(-82.88619106289252 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark30(-82.89470793719416 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark30(-8.294540109357754 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark30(-82.95821539295196 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark30(-82.96624878860376 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark30(-82.97940289594564 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark30(-8.298201339231866 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark30(-83.02796883425114 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark30(-83.03413251770507 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark30(-83.05613191549114 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark30(-83.05721566532746 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark30(-83.08348849047758 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark30(-83.09292063547504 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark30(-83.10477552133707 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark30(-83.11339878556947 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark30(-83.17488572040423 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark30(-83.20380788715318 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark30(-83.22336117511108 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark30(-83.23897679145333 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark30(-8.324671598190875 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark30(-8.337049132951861 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark30(-8.338769566748155 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark30(-83.49282703398966 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark30(-83.61930955679651 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark30(-83.63028992546266 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark30(-8.364418369137681 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark30(-83.67739560934702 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark30(-83.71869140563743 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark30(-83.73275639176308 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark30(-83.74265672179394 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark30(-83.74678095053434 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark30(-83.75443635371036 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark30(-83.77522417773574 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark30(-83.77555848494727 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark30(-83.80333355413319 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark30(-83.80920412277032 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark30(-83.83802119498911 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark30(-83.85341360018359 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark30(-83.90513218074771 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark30(-83.9744565876326 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark30(-83.9749568467983 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark30(-84.02898001035915 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark30(-84.07248683960127 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark30(-8.408453179735346 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark30(-84.09052966436963 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark30(-84.1277634491087 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark30(-84.15049846716501 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark30(-84.17522104722684 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark30(-84.2009962235068 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark30(-84.28081056299423 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark30(-84.30996075713612 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark30(-84.40144199742498 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark30(-84.41786355778325 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark30(-8.441801377556573 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark30(-84.4220277261621 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark30(-84.42621713213411 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark30(-84.44813571595837 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark30(-84.4670454388027 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark30(-84.48606527487313 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark30(-84.56902014533061 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark30(-84.77071999247336 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark30(-84.78942633243447 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark30(-84.81670010272174 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark30(-84.86712032978829 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark30(-84.9728963499583 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark30(-84.97360873609401 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark30(-8.498160564129336 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark30(-84.98355147435457 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark30(-85.0082694798264 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark30(-85.00915216674953 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark30(-8.501195663605387 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark30(-85.03751061800726 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark30(-85.09988636961295 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark30(-85.12828662364547 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark30(-85.14256177315565 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark30(-85.16299628003472 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark30(-85.18469404881563 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark30(-85.20102561889613 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark30(-85.20487986236604 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark30(-85.242827043898 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark30(-85.28682060540393 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark30(-85.29646536245181 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark30(-85.3130448655889 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark30(-85.38432665358498 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark30(-85.39467889608237 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark30(-85.44121297456427 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark30(-85.444602870907 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark30(-85.4470687335101 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark30(-85.4970906895118 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark30(-85.56493530794995 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark30(-85.59546999621725 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark30(-85.62999502596864 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark30(-85.75422391278494 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark30(-85.8611588816425 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark30(-86.01115246379618 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark30(-86.0125637512628 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark30(-86.09293554721694 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark30(-86.10563333564482 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark30(-86.13135800088314 ) ;
  }

  @Test
  public void test2476() {
    coral.tests.JPFBenchmark.benchmark30(-86.2845458704577 ) ;
  }

  @Test
  public void test2477() {
    coral.tests.JPFBenchmark.benchmark30(-86.29124588275533 ) ;
  }

  @Test
  public void test2478() {
    coral.tests.JPFBenchmark.benchmark30(-86.29338640377777 ) ;
  }

  @Test
  public void test2479() {
    coral.tests.JPFBenchmark.benchmark30(-8.641513548599718 ) ;
  }

  @Test
  public void test2480() {
    coral.tests.JPFBenchmark.benchmark30(-86.42933450521286 ) ;
  }

  @Test
  public void test2481() {
    coral.tests.JPFBenchmark.benchmark30(-86.46238183523289 ) ;
  }

  @Test
  public void test2482() {
    coral.tests.JPFBenchmark.benchmark30(-86.49640826695762 ) ;
  }

  @Test
  public void test2483() {
    coral.tests.JPFBenchmark.benchmark30(-86.53405188809941 ) ;
  }

  @Test
  public void test2484() {
    coral.tests.JPFBenchmark.benchmark30(-86.59431269621163 ) ;
  }

  @Test
  public void test2485() {
    coral.tests.JPFBenchmark.benchmark30(-86.61669146775168 ) ;
  }

  @Test
  public void test2486() {
    coral.tests.JPFBenchmark.benchmark30(-86.64333331485265 ) ;
  }

  @Test
  public void test2487() {
    coral.tests.JPFBenchmark.benchmark30(-8.671686061119118 ) ;
  }

  @Test
  public void test2488() {
    coral.tests.JPFBenchmark.benchmark30(-86.74517271188327 ) ;
  }

  @Test
  public void test2489() {
    coral.tests.JPFBenchmark.benchmark30(-86.7664054138992 ) ;
  }

  @Test
  public void test2490() {
    coral.tests.JPFBenchmark.benchmark30(-86.76642622295299 ) ;
  }

  @Test
  public void test2491() {
    coral.tests.JPFBenchmark.benchmark30(-86.8160394340473 ) ;
  }

  @Test
  public void test2492() {
    coral.tests.JPFBenchmark.benchmark30(-86.87589346517987 ) ;
  }

  @Test
  public void test2493() {
    coral.tests.JPFBenchmark.benchmark30(-86.88826983068567 ) ;
  }

  @Test
  public void test2494() {
    coral.tests.JPFBenchmark.benchmark30(-86.91344543688453 ) ;
  }

  @Test
  public void test2495() {
    coral.tests.JPFBenchmark.benchmark30(-86.92829540138409 ) ;
  }

  @Test
  public void test2496() {
    coral.tests.JPFBenchmark.benchmark30(-86.99152406312622 ) ;
  }

  @Test
  public void test2497() {
    coral.tests.JPFBenchmark.benchmark30(-87.0088919020776 ) ;
  }

  @Test
  public void test2498() {
    coral.tests.JPFBenchmark.benchmark30(-87.07387799926663 ) ;
  }

  @Test
  public void test2499() {
    coral.tests.JPFBenchmark.benchmark30(-8.710852928699893 ) ;
  }

  @Test
  public void test2500() {
    coral.tests.JPFBenchmark.benchmark30(-87.1131720236513 ) ;
  }

  @Test
  public void test2501() {
    coral.tests.JPFBenchmark.benchmark30(-87.16191639173884 ) ;
  }

  @Test
  public void test2502() {
    coral.tests.JPFBenchmark.benchmark30(-87.20780718635109 ) ;
  }

  @Test
  public void test2503() {
    coral.tests.JPFBenchmark.benchmark30(-87.23299072152126 ) ;
  }

  @Test
  public void test2504() {
    coral.tests.JPFBenchmark.benchmark30(-8.725488720711255 ) ;
  }

  @Test
  public void test2505() {
    coral.tests.JPFBenchmark.benchmark30(-87.30783399911668 ) ;
  }

  @Test
  public void test2506() {
    coral.tests.JPFBenchmark.benchmark30(-8.732674973253296 ) ;
  }

  @Test
  public void test2507() {
    coral.tests.JPFBenchmark.benchmark30(-8.735436853202216 ) ;
  }

  @Test
  public void test2508() {
    coral.tests.JPFBenchmark.benchmark30(-87.41306697209406 ) ;
  }

  @Test
  public void test2509() {
    coral.tests.JPFBenchmark.benchmark30(-87.6850635269326 ) ;
  }

  @Test
  public void test2510() {
    coral.tests.JPFBenchmark.benchmark30(-87.69190958546568 ) ;
  }

  @Test
  public void test2511() {
    coral.tests.JPFBenchmark.benchmark30(-87.70032343086034 ) ;
  }

  @Test
  public void test2512() {
    coral.tests.JPFBenchmark.benchmark30(-87.74038818850408 ) ;
  }

  @Test
  public void test2513() {
    coral.tests.JPFBenchmark.benchmark30(-87.79038377316411 ) ;
  }

  @Test
  public void test2514() {
    coral.tests.JPFBenchmark.benchmark30(-87.83447207150353 ) ;
  }

  @Test
  public void test2515() {
    coral.tests.JPFBenchmark.benchmark30(-87.86016369148606 ) ;
  }

  @Test
  public void test2516() {
    coral.tests.JPFBenchmark.benchmark30(-87.87513084293505 ) ;
  }

  @Test
  public void test2517() {
    coral.tests.JPFBenchmark.benchmark30(-87.90591355600432 ) ;
  }

  @Test
  public void test2518() {
    coral.tests.JPFBenchmark.benchmark30(-87.92319951062055 ) ;
  }

  @Test
  public void test2519() {
    coral.tests.JPFBenchmark.benchmark30(-87.98482491723203 ) ;
  }

  @Test
  public void test2520() {
    coral.tests.JPFBenchmark.benchmark30(-88.01075811965705 ) ;
  }

  @Test
  public void test2521() {
    coral.tests.JPFBenchmark.benchmark30(-8.804657836619967 ) ;
  }

  @Test
  public void test2522() {
    coral.tests.JPFBenchmark.benchmark30(-88.05809899691195 ) ;
  }

  @Test
  public void test2523() {
    coral.tests.JPFBenchmark.benchmark30(-88.09776894862391 ) ;
  }

  @Test
  public void test2524() {
    coral.tests.JPFBenchmark.benchmark30(-88.26634888882393 ) ;
  }

  @Test
  public void test2525() {
    coral.tests.JPFBenchmark.benchmark30(-88.29042556062832 ) ;
  }

  @Test
  public void test2526() {
    coral.tests.JPFBenchmark.benchmark30(-88.31180108202273 ) ;
  }

  @Test
  public void test2527() {
    coral.tests.JPFBenchmark.benchmark30(-88.31201822679205 ) ;
  }

  @Test
  public void test2528() {
    coral.tests.JPFBenchmark.benchmark30(-88.37173052282905 ) ;
  }

  @Test
  public void test2529() {
    coral.tests.JPFBenchmark.benchmark30(-88.46702310215258 ) ;
  }

  @Test
  public void test2530() {
    coral.tests.JPFBenchmark.benchmark30(-88.47522493209186 ) ;
  }

  @Test
  public void test2531() {
    coral.tests.JPFBenchmark.benchmark30(-88.47895969271285 ) ;
  }

  @Test
  public void test2532() {
    coral.tests.JPFBenchmark.benchmark30(-88.49166680602487 ) ;
  }

  @Test
  public void test2533() {
    coral.tests.JPFBenchmark.benchmark30(-88.494524368361 ) ;
  }

  @Test
  public void test2534() {
    coral.tests.JPFBenchmark.benchmark30(-8.853673878238922 ) ;
  }

  @Test
  public void test2535() {
    coral.tests.JPFBenchmark.benchmark30(-88.59261392374262 ) ;
  }

  @Test
  public void test2536() {
    coral.tests.JPFBenchmark.benchmark30(-88.6173106877416 ) ;
  }

  @Test
  public void test2537() {
    coral.tests.JPFBenchmark.benchmark30(-88.6221379200685 ) ;
  }

  @Test
  public void test2538() {
    coral.tests.JPFBenchmark.benchmark30(-88.65568681388226 ) ;
  }

  @Test
  public void test2539() {
    coral.tests.JPFBenchmark.benchmark30(-88.70991153681553 ) ;
  }

  @Test
  public void test2540() {
    coral.tests.JPFBenchmark.benchmark30(-88.73306219419341 ) ;
  }

  @Test
  public void test2541() {
    coral.tests.JPFBenchmark.benchmark30(-88.79046947545257 ) ;
  }

  @Test
  public void test2542() {
    coral.tests.JPFBenchmark.benchmark30(-88.9231686031932 ) ;
  }

  @Test
  public void test2543() {
    coral.tests.JPFBenchmark.benchmark30(-88.9862147670482 ) ;
  }

  @Test
  public void test2544() {
    coral.tests.JPFBenchmark.benchmark30(-8.904525662258962 ) ;
  }

  @Test
  public void test2545() {
    coral.tests.JPFBenchmark.benchmark30(-89.04916953864142 ) ;
  }

  @Test
  public void test2546() {
    coral.tests.JPFBenchmark.benchmark30(-89.05186179686362 ) ;
  }

  @Test
  public void test2547() {
    coral.tests.JPFBenchmark.benchmark30(-89.07011308267818 ) ;
  }

  @Test
  public void test2548() {
    coral.tests.JPFBenchmark.benchmark30(-89.08317282082301 ) ;
  }

  @Test
  public void test2549() {
    coral.tests.JPFBenchmark.benchmark30(-8.909709083208384 ) ;
  }

  @Test
  public void test2550() {
    coral.tests.JPFBenchmark.benchmark30(-89.18257043351092 ) ;
  }

  @Test
  public void test2551() {
    coral.tests.JPFBenchmark.benchmark30(-89.24023770819365 ) ;
  }

  @Test
  public void test2552() {
    coral.tests.JPFBenchmark.benchmark30(-89.2706829648236 ) ;
  }

  @Test
  public void test2553() {
    coral.tests.JPFBenchmark.benchmark30(-89.30274373248446 ) ;
  }

  @Test
  public void test2554() {
    coral.tests.JPFBenchmark.benchmark30(-8.93394145364961 ) ;
  }

  @Test
  public void test2555() {
    coral.tests.JPFBenchmark.benchmark30(-89.36566966784471 ) ;
  }

  @Test
  public void test2556() {
    coral.tests.JPFBenchmark.benchmark30(-89.41809424165676 ) ;
  }

  @Test
  public void test2557() {
    coral.tests.JPFBenchmark.benchmark30(-89.48178662553428 ) ;
  }

  @Test
  public void test2558() {
    coral.tests.JPFBenchmark.benchmark30(-89.55109200981472 ) ;
  }

  @Test
  public void test2559() {
    coral.tests.JPFBenchmark.benchmark30(-89.58744603047015 ) ;
  }

  @Test
  public void test2560() {
    coral.tests.JPFBenchmark.benchmark30(-89.60263203691187 ) ;
  }

  @Test
  public void test2561() {
    coral.tests.JPFBenchmark.benchmark30(-89.62775198232771 ) ;
  }

  @Test
  public void test2562() {
    coral.tests.JPFBenchmark.benchmark30(-8.965916574583417 ) ;
  }

  @Test
  public void test2563() {
    coral.tests.JPFBenchmark.benchmark30(-89.69688171360617 ) ;
  }

  @Test
  public void test2564() {
    coral.tests.JPFBenchmark.benchmark30(-89.72685674341498 ) ;
  }

  @Test
  public void test2565() {
    coral.tests.JPFBenchmark.benchmark30(-89.73076427679459 ) ;
  }

  @Test
  public void test2566() {
    coral.tests.JPFBenchmark.benchmark30(-89.732360338509 ) ;
  }

  @Test
  public void test2567() {
    coral.tests.JPFBenchmark.benchmark30(-89.79057820484981 ) ;
  }

  @Test
  public void test2568() {
    coral.tests.JPFBenchmark.benchmark30(-89.80544711969523 ) ;
  }

  @Test
  public void test2569() {
    coral.tests.JPFBenchmark.benchmark30(-89.81601671619642 ) ;
  }

  @Test
  public void test2570() {
    coral.tests.JPFBenchmark.benchmark30(-89.88315378665939 ) ;
  }

  @Test
  public void test2571() {
    coral.tests.JPFBenchmark.benchmark30(-8.990732578190233 ) ;
  }

  @Test
  public void test2572() {
    coral.tests.JPFBenchmark.benchmark30(-89.93263729493329 ) ;
  }

  @Test
  public void test2573() {
    coral.tests.JPFBenchmark.benchmark30(-89.9335404979525 ) ;
  }

  @Test
  public void test2574() {
    coral.tests.JPFBenchmark.benchmark30(-90.01889750055017 ) ;
  }

  @Test
  public void test2575() {
    coral.tests.JPFBenchmark.benchmark30(-90.05863182224847 ) ;
  }

  @Test
  public void test2576() {
    coral.tests.JPFBenchmark.benchmark30(-90.10607051894635 ) ;
  }

  @Test
  public void test2577() {
    coral.tests.JPFBenchmark.benchmark30(-90.11248523393816 ) ;
  }

  @Test
  public void test2578() {
    coral.tests.JPFBenchmark.benchmark30(-90.11919599813866 ) ;
  }

  @Test
  public void test2579() {
    coral.tests.JPFBenchmark.benchmark30(-90.12847838582567 ) ;
  }

  @Test
  public void test2580() {
    coral.tests.JPFBenchmark.benchmark30(-90.25659444341758 ) ;
  }

  @Test
  public void test2581() {
    coral.tests.JPFBenchmark.benchmark30(-90.26353817296564 ) ;
  }

  @Test
  public void test2582() {
    coral.tests.JPFBenchmark.benchmark30(-90.28470039930143 ) ;
  }

  @Test
  public void test2583() {
    coral.tests.JPFBenchmark.benchmark30(-9.029036596932698 ) ;
  }

  @Test
  public void test2584() {
    coral.tests.JPFBenchmark.benchmark30(-90.30768490977658 ) ;
  }

  @Test
  public void test2585() {
    coral.tests.JPFBenchmark.benchmark30(-90.32046187951168 ) ;
  }

  @Test
  public void test2586() {
    coral.tests.JPFBenchmark.benchmark30(-90.33139098985893 ) ;
  }

  @Test
  public void test2587() {
    coral.tests.JPFBenchmark.benchmark30(-90.3905600509205 ) ;
  }

  @Test
  public void test2588() {
    coral.tests.JPFBenchmark.benchmark30(-90.39224175577476 ) ;
  }

  @Test
  public void test2589() {
    coral.tests.JPFBenchmark.benchmark30(-90.41701762624757 ) ;
  }

  @Test
  public void test2590() {
    coral.tests.JPFBenchmark.benchmark30(-90.45903162276511 ) ;
  }

  @Test
  public void test2591() {
    coral.tests.JPFBenchmark.benchmark30(-90.50407078400802 ) ;
  }

  @Test
  public void test2592() {
    coral.tests.JPFBenchmark.benchmark30(-90.50502994631896 ) ;
  }

  @Test
  public void test2593() {
    coral.tests.JPFBenchmark.benchmark30(-90.51263590587706 ) ;
  }

  @Test
  public void test2594() {
    coral.tests.JPFBenchmark.benchmark30(-90.51550837867795 ) ;
  }

  @Test
  public void test2595() {
    coral.tests.JPFBenchmark.benchmark30(-90.57583467249202 ) ;
  }

  @Test
  public void test2596() {
    coral.tests.JPFBenchmark.benchmark30(-90.60665863694801 ) ;
  }

  @Test
  public void test2597() {
    coral.tests.JPFBenchmark.benchmark30(-90.63034599999932 ) ;
  }

  @Test
  public void test2598() {
    coral.tests.JPFBenchmark.benchmark30(-90.64685402605923 ) ;
  }

  @Test
  public void test2599() {
    coral.tests.JPFBenchmark.benchmark30(-90.67168420346523 ) ;
  }

  @Test
  public void test2600() {
    coral.tests.JPFBenchmark.benchmark30(-90.6778230298589 ) ;
  }

  @Test
  public void test2601() {
    coral.tests.JPFBenchmark.benchmark30(-90.7146241480147 ) ;
  }

  @Test
  public void test2602() {
    coral.tests.JPFBenchmark.benchmark30(-90.75254142104536 ) ;
  }

  @Test
  public void test2603() {
    coral.tests.JPFBenchmark.benchmark30(-90.81428778711778 ) ;
  }

  @Test
  public void test2604() {
    coral.tests.JPFBenchmark.benchmark30(-90.93620282157184 ) ;
  }

  @Test
  public void test2605() {
    coral.tests.JPFBenchmark.benchmark30(-90.9413867077621 ) ;
  }

  @Test
  public void test2606() {
    coral.tests.JPFBenchmark.benchmark30(-90.96328886194433 ) ;
  }

  @Test
  public void test2607() {
    coral.tests.JPFBenchmark.benchmark30(-90.99589399460295 ) ;
  }

  @Test
  public void test2608() {
    coral.tests.JPFBenchmark.benchmark30(-91.02570335706662 ) ;
  }

  @Test
  public void test2609() {
    coral.tests.JPFBenchmark.benchmark30(-91.03384679660928 ) ;
  }

  @Test
  public void test2610() {
    coral.tests.JPFBenchmark.benchmark30(-91.03772577602899 ) ;
  }

  @Test
  public void test2611() {
    coral.tests.JPFBenchmark.benchmark30(-91.0828834455111 ) ;
  }

  @Test
  public void test2612() {
    coral.tests.JPFBenchmark.benchmark30(-91.12014533889005 ) ;
  }

  @Test
  public void test2613() {
    coral.tests.JPFBenchmark.benchmark30(-91.12182085242735 ) ;
  }

  @Test
  public void test2614() {
    coral.tests.JPFBenchmark.benchmark30(-91.14447296130261 ) ;
  }

  @Test
  public void test2615() {
    coral.tests.JPFBenchmark.benchmark30(-91.15587064194415 ) ;
  }

  @Test
  public void test2616() {
    coral.tests.JPFBenchmark.benchmark30(-91.16445313383352 ) ;
  }

  @Test
  public void test2617() {
    coral.tests.JPFBenchmark.benchmark30(-91.21667698855731 ) ;
  }

  @Test
  public void test2618() {
    coral.tests.JPFBenchmark.benchmark30(-91.25768626365524 ) ;
  }

  @Test
  public void test2619() {
    coral.tests.JPFBenchmark.benchmark30(-91.26436822516762 ) ;
  }

  @Test
  public void test2620() {
    coral.tests.JPFBenchmark.benchmark30(-91.26511220985347 ) ;
  }

  @Test
  public void test2621() {
    coral.tests.JPFBenchmark.benchmark30(-9.13560314061408 ) ;
  }

  @Test
  public void test2622() {
    coral.tests.JPFBenchmark.benchmark30(-91.37653726022594 ) ;
  }

  @Test
  public void test2623() {
    coral.tests.JPFBenchmark.benchmark30(-91.4346132566467 ) ;
  }

  @Test
  public void test2624() {
    coral.tests.JPFBenchmark.benchmark30(-91.45859470341856 ) ;
  }

  @Test
  public void test2625() {
    coral.tests.JPFBenchmark.benchmark30(-91.47781782976175 ) ;
  }

  @Test
  public void test2626() {
    coral.tests.JPFBenchmark.benchmark30(-9.148062062405259 ) ;
  }

  @Test
  public void test2627() {
    coral.tests.JPFBenchmark.benchmark30(-91.49284547267945 ) ;
  }

  @Test
  public void test2628() {
    coral.tests.JPFBenchmark.benchmark30(-91.56275677396002 ) ;
  }

  @Test
  public void test2629() {
    coral.tests.JPFBenchmark.benchmark30(-91.56604232107932 ) ;
  }

  @Test
  public void test2630() {
    coral.tests.JPFBenchmark.benchmark30(-91.65899315348629 ) ;
  }

  @Test
  public void test2631() {
    coral.tests.JPFBenchmark.benchmark30(-9.168785477188962 ) ;
  }

  @Test
  public void test2632() {
    coral.tests.JPFBenchmark.benchmark30(-91.72115680487359 ) ;
  }

  @Test
  public void test2633() {
    coral.tests.JPFBenchmark.benchmark30(-9.17601481908865 ) ;
  }

  @Test
  public void test2634() {
    coral.tests.JPFBenchmark.benchmark30(-91.80726611797587 ) ;
  }

  @Test
  public void test2635() {
    coral.tests.JPFBenchmark.benchmark30(-91.84321467836037 ) ;
  }

  @Test
  public void test2636() {
    coral.tests.JPFBenchmark.benchmark30(-91.85919722246877 ) ;
  }

  @Test
  public void test2637() {
    coral.tests.JPFBenchmark.benchmark30(-91.86380797568083 ) ;
  }

  @Test
  public void test2638() {
    coral.tests.JPFBenchmark.benchmark30(-9.190486800137904 ) ;
  }

  @Test
  public void test2639() {
    coral.tests.JPFBenchmark.benchmark30(-91.98385880391947 ) ;
  }

  @Test
  public void test2640() {
    coral.tests.JPFBenchmark.benchmark30(-92.02609314016976 ) ;
  }

  @Test
  public void test2641() {
    coral.tests.JPFBenchmark.benchmark30(-92.10685372373395 ) ;
  }

  @Test
  public void test2642() {
    coral.tests.JPFBenchmark.benchmark30(-92.15496189104282 ) ;
  }

  @Test
  public void test2643() {
    coral.tests.JPFBenchmark.benchmark30(-9.220669590777717 ) ;
  }

  @Test
  public void test2644() {
    coral.tests.JPFBenchmark.benchmark30(-92.22124314739075 ) ;
  }

  @Test
  public void test2645() {
    coral.tests.JPFBenchmark.benchmark30(-92.25781242763169 ) ;
  }

  @Test
  public void test2646() {
    coral.tests.JPFBenchmark.benchmark30(-92.26871224343509 ) ;
  }

  @Test
  public void test2647() {
    coral.tests.JPFBenchmark.benchmark30(-92.26932796855563 ) ;
  }

  @Test
  public void test2648() {
    coral.tests.JPFBenchmark.benchmark30(-9.231796451943026 ) ;
  }

  @Test
  public void test2649() {
    coral.tests.JPFBenchmark.benchmark30(-92.38697760180703 ) ;
  }

  @Test
  public void test2650() {
    coral.tests.JPFBenchmark.benchmark30(-92.39729574965831 ) ;
  }

  @Test
  public void test2651() {
    coral.tests.JPFBenchmark.benchmark30(-92.41191081205315 ) ;
  }

  @Test
  public void test2652() {
    coral.tests.JPFBenchmark.benchmark30(-92.42182368204 ) ;
  }

  @Test
  public void test2653() {
    coral.tests.JPFBenchmark.benchmark30(-92.44692368521041 ) ;
  }

  @Test
  public void test2654() {
    coral.tests.JPFBenchmark.benchmark30(-92.47096349916475 ) ;
  }

  @Test
  public void test2655() {
    coral.tests.JPFBenchmark.benchmark30(-92.49402320340872 ) ;
  }

  @Test
  public void test2656() {
    coral.tests.JPFBenchmark.benchmark30(-92.5051182947175 ) ;
  }

  @Test
  public void test2657() {
    coral.tests.JPFBenchmark.benchmark30(-92.50687894515306 ) ;
  }

  @Test
  public void test2658() {
    coral.tests.JPFBenchmark.benchmark30(-92.52255838408716 ) ;
  }

  @Test
  public void test2659() {
    coral.tests.JPFBenchmark.benchmark30(-92.53521561817448 ) ;
  }

  @Test
  public void test2660() {
    coral.tests.JPFBenchmark.benchmark30(-92.62568033398 ) ;
  }

  @Test
  public void test2661() {
    coral.tests.JPFBenchmark.benchmark30(-92.63155083879688 ) ;
  }

  @Test
  public void test2662() {
    coral.tests.JPFBenchmark.benchmark30(-92.68063980516482 ) ;
  }

  @Test
  public void test2663() {
    coral.tests.JPFBenchmark.benchmark30(-9.269983885758748 ) ;
  }

  @Test
  public void test2664() {
    coral.tests.JPFBenchmark.benchmark30(-92.75134515904335 ) ;
  }

  @Test
  public void test2665() {
    coral.tests.JPFBenchmark.benchmark30(-92.8115178315492 ) ;
  }

  @Test
  public void test2666() {
    coral.tests.JPFBenchmark.benchmark30(-92.87095416249585 ) ;
  }

  @Test
  public void test2667() {
    coral.tests.JPFBenchmark.benchmark30(-9.289177116726009 ) ;
  }

  @Test
  public void test2668() {
    coral.tests.JPFBenchmark.benchmark30(-92.94207249942063 ) ;
  }

  @Test
  public void test2669() {
    coral.tests.JPFBenchmark.benchmark30(-93.16913925906532 ) ;
  }

  @Test
  public void test2670() {
    coral.tests.JPFBenchmark.benchmark30(-93.29998312080536 ) ;
  }

  @Test
  public void test2671() {
    coral.tests.JPFBenchmark.benchmark30(-93.30621304271578 ) ;
  }

  @Test
  public void test2672() {
    coral.tests.JPFBenchmark.benchmark30(-93.32396067219204 ) ;
  }

  @Test
  public void test2673() {
    coral.tests.JPFBenchmark.benchmark30(-93.33884962368282 ) ;
  }

  @Test
  public void test2674() {
    coral.tests.JPFBenchmark.benchmark30(-93.40126910155075 ) ;
  }

  @Test
  public void test2675() {
    coral.tests.JPFBenchmark.benchmark30(-93.43561633881583 ) ;
  }

  @Test
  public void test2676() {
    coral.tests.JPFBenchmark.benchmark30(-93.46816555899495 ) ;
  }

  @Test
  public void test2677() {
    coral.tests.JPFBenchmark.benchmark30(-93.5615913057469 ) ;
  }

  @Test
  public void test2678() {
    coral.tests.JPFBenchmark.benchmark30(-93.58499087692765 ) ;
  }

  @Test
  public void test2679() {
    coral.tests.JPFBenchmark.benchmark30(-93.6170650920664 ) ;
  }

  @Test
  public void test2680() {
    coral.tests.JPFBenchmark.benchmark30(-93.67551605524118 ) ;
  }

  @Test
  public void test2681() {
    coral.tests.JPFBenchmark.benchmark30(-93.7050753540275 ) ;
  }

  @Test
  public void test2682() {
    coral.tests.JPFBenchmark.benchmark30(-93.76409466332053 ) ;
  }

  @Test
  public void test2683() {
    coral.tests.JPFBenchmark.benchmark30(-93.77181799045384 ) ;
  }

  @Test
  public void test2684() {
    coral.tests.JPFBenchmark.benchmark30(-93.83701441373564 ) ;
  }

  @Test
  public void test2685() {
    coral.tests.JPFBenchmark.benchmark30(-93.88211050633288 ) ;
  }

  @Test
  public void test2686() {
    coral.tests.JPFBenchmark.benchmark30(-93.90850468238163 ) ;
  }

  @Test
  public void test2687() {
    coral.tests.JPFBenchmark.benchmark30(-93.93000496233019 ) ;
  }

  @Test
  public void test2688() {
    coral.tests.JPFBenchmark.benchmark30(-93.94433990328757 ) ;
  }

  @Test
  public void test2689() {
    coral.tests.JPFBenchmark.benchmark30(-93.95093450655152 ) ;
  }

  @Test
  public void test2690() {
    coral.tests.JPFBenchmark.benchmark30(-93.98798280759704 ) ;
  }

  @Test
  public void test2691() {
    coral.tests.JPFBenchmark.benchmark30(-94.03243205720904 ) ;
  }

  @Test
  public void test2692() {
    coral.tests.JPFBenchmark.benchmark30(-94.05985053204799 ) ;
  }

  @Test
  public void test2693() {
    coral.tests.JPFBenchmark.benchmark30(-94.12432706407472 ) ;
  }

  @Test
  public void test2694() {
    coral.tests.JPFBenchmark.benchmark30(-94.15735912122094 ) ;
  }

  @Test
  public void test2695() {
    coral.tests.JPFBenchmark.benchmark30(-94.18899252828422 ) ;
  }

  @Test
  public void test2696() {
    coral.tests.JPFBenchmark.benchmark30(-94.20531545212411 ) ;
  }

  @Test
  public void test2697() {
    coral.tests.JPFBenchmark.benchmark30(-94.21301374516086 ) ;
  }

  @Test
  public void test2698() {
    coral.tests.JPFBenchmark.benchmark30(-94.21392299561293 ) ;
  }

  @Test
  public void test2699() {
    coral.tests.JPFBenchmark.benchmark30(-94.32341366745793 ) ;
  }

  @Test
  public void test2700() {
    coral.tests.JPFBenchmark.benchmark30(-94.38523667201028 ) ;
  }

  @Test
  public void test2701() {
    coral.tests.JPFBenchmark.benchmark30(-9.441592077017845 ) ;
  }

  @Test
  public void test2702() {
    coral.tests.JPFBenchmark.benchmark30(-94.41835916131099 ) ;
  }

  @Test
  public void test2703() {
    coral.tests.JPFBenchmark.benchmark30(-94.46216383037897 ) ;
  }

  @Test
  public void test2704() {
    coral.tests.JPFBenchmark.benchmark30(-94.48062467611653 ) ;
  }

  @Test
  public void test2705() {
    coral.tests.JPFBenchmark.benchmark30(-94.55742476577448 ) ;
  }

  @Test
  public void test2706() {
    coral.tests.JPFBenchmark.benchmark30(-9.456860779093873 ) ;
  }

  @Test
  public void test2707() {
    coral.tests.JPFBenchmark.benchmark30(-94.58280428519137 ) ;
  }

  @Test
  public void test2708() {
    coral.tests.JPFBenchmark.benchmark30(-94.61705729740181 ) ;
  }

  @Test
  public void test2709() {
    coral.tests.JPFBenchmark.benchmark30(-94.62523114009846 ) ;
  }

  @Test
  public void test2710() {
    coral.tests.JPFBenchmark.benchmark30(-94.72380129284488 ) ;
  }

  @Test
  public void test2711() {
    coral.tests.JPFBenchmark.benchmark30(-94.73877280331541 ) ;
  }

  @Test
  public void test2712() {
    coral.tests.JPFBenchmark.benchmark30(-94.77200876212422 ) ;
  }

  @Test
  public void test2713() {
    coral.tests.JPFBenchmark.benchmark30(-94.78326030796318 ) ;
  }

  @Test
  public void test2714() {
    coral.tests.JPFBenchmark.benchmark30(-94.7942638915338 ) ;
  }

  @Test
  public void test2715() {
    coral.tests.JPFBenchmark.benchmark30(-94.7962114687741 ) ;
  }

  @Test
  public void test2716() {
    coral.tests.JPFBenchmark.benchmark30(-94.80551779393294 ) ;
  }

  @Test
  public void test2717() {
    coral.tests.JPFBenchmark.benchmark30(-94.90166577548993 ) ;
  }

  @Test
  public void test2718() {
    coral.tests.JPFBenchmark.benchmark30(-94.92116949427395 ) ;
  }

  @Test
  public void test2719() {
    coral.tests.JPFBenchmark.benchmark30(-95.00629212785267 ) ;
  }

  @Test
  public void test2720() {
    coral.tests.JPFBenchmark.benchmark30(-95.0328354302084 ) ;
  }

  @Test
  public void test2721() {
    coral.tests.JPFBenchmark.benchmark30(-95.03864317361193 ) ;
  }

  @Test
  public void test2722() {
    coral.tests.JPFBenchmark.benchmark30(-95.06115651879712 ) ;
  }

  @Test
  public void test2723() {
    coral.tests.JPFBenchmark.benchmark30(-95.08237849159873 ) ;
  }

  @Test
  public void test2724() {
    coral.tests.JPFBenchmark.benchmark30(-95.09575535944978 ) ;
  }

  @Test
  public void test2725() {
    coral.tests.JPFBenchmark.benchmark30(-95.17565939148784 ) ;
  }

  @Test
  public void test2726() {
    coral.tests.JPFBenchmark.benchmark30(-95.19686002173628 ) ;
  }

  @Test
  public void test2727() {
    coral.tests.JPFBenchmark.benchmark30(9.523045004775852 ) ;
  }

  @Test
  public void test2728() {
    coral.tests.JPFBenchmark.benchmark30(-95.2446881543618 ) ;
  }

  @Test
  public void test2729() {
    coral.tests.JPFBenchmark.benchmark30(-9.526548485957619 ) ;
  }

  @Test
  public void test2730() {
    coral.tests.JPFBenchmark.benchmark30(-95.33500485294675 ) ;
  }

  @Test
  public void test2731() {
    coral.tests.JPFBenchmark.benchmark30(-95.37162028541171 ) ;
  }

  @Test
  public void test2732() {
    coral.tests.JPFBenchmark.benchmark30(-95.41988041423673 ) ;
  }

  @Test
  public void test2733() {
    coral.tests.JPFBenchmark.benchmark30(-95.44356534386091 ) ;
  }

  @Test
  public void test2734() {
    coral.tests.JPFBenchmark.benchmark30(-95.48229944798703 ) ;
  }

  @Test
  public void test2735() {
    coral.tests.JPFBenchmark.benchmark30(-95.60987684519804 ) ;
  }

  @Test
  public void test2736() {
    coral.tests.JPFBenchmark.benchmark30(-95.68248868467923 ) ;
  }

  @Test
  public void test2737() {
    coral.tests.JPFBenchmark.benchmark30(-95.7031006677881 ) ;
  }

  @Test
  public void test2738() {
    coral.tests.JPFBenchmark.benchmark30(-95.7515715428237 ) ;
  }

  @Test
  public void test2739() {
    coral.tests.JPFBenchmark.benchmark30(-95.78317596185492 ) ;
  }

  @Test
  public void test2740() {
    coral.tests.JPFBenchmark.benchmark30(-95.83014080752359 ) ;
  }

  @Test
  public void test2741() {
    coral.tests.JPFBenchmark.benchmark30(-95.83267474417305 ) ;
  }

  @Test
  public void test2742() {
    coral.tests.JPFBenchmark.benchmark30(-95.91559975092834 ) ;
  }

  @Test
  public void test2743() {
    coral.tests.JPFBenchmark.benchmark30(-95.92495086696972 ) ;
  }

  @Test
  public void test2744() {
    coral.tests.JPFBenchmark.benchmark30(-95.93655170897964 ) ;
  }

  @Test
  public void test2745() {
    coral.tests.JPFBenchmark.benchmark30(-95.94207936017492 ) ;
  }

  @Test
  public void test2746() {
    coral.tests.JPFBenchmark.benchmark30(-95.95610791784898 ) ;
  }

  @Test
  public void test2747() {
    coral.tests.JPFBenchmark.benchmark30(-95.99876360544005 ) ;
  }

  @Test
  public void test2748() {
    coral.tests.JPFBenchmark.benchmark30(-96.01977289481675 ) ;
  }

  @Test
  public void test2749() {
    coral.tests.JPFBenchmark.benchmark30(-96.02695985913469 ) ;
  }

  @Test
  public void test2750() {
    coral.tests.JPFBenchmark.benchmark30(-96.03987647612459 ) ;
  }

  @Test
  public void test2751() {
    coral.tests.JPFBenchmark.benchmark30(-96.10198230142288 ) ;
  }

  @Test
  public void test2752() {
    coral.tests.JPFBenchmark.benchmark30(-9.617433414881432 ) ;
  }

  @Test
  public void test2753() {
    coral.tests.JPFBenchmark.benchmark30(-96.20306448830243 ) ;
  }

  @Test
  public void test2754() {
    coral.tests.JPFBenchmark.benchmark30(-96.20560752813776 ) ;
  }

  @Test
  public void test2755() {
    coral.tests.JPFBenchmark.benchmark30(-96.21925947121122 ) ;
  }

  @Test
  public void test2756() {
    coral.tests.JPFBenchmark.benchmark30(-96.22073198971887 ) ;
  }

  @Test
  public void test2757() {
    coral.tests.JPFBenchmark.benchmark30(-96.27046815595746 ) ;
  }

  @Test
  public void test2758() {
    coral.tests.JPFBenchmark.benchmark30(-96.30194566206988 ) ;
  }

  @Test
  public void test2759() {
    coral.tests.JPFBenchmark.benchmark30(-96.33537979654456 ) ;
  }

  @Test
  public void test2760() {
    coral.tests.JPFBenchmark.benchmark30(-96.38086153754408 ) ;
  }

  @Test
  public void test2761() {
    coral.tests.JPFBenchmark.benchmark30(-96.42719759634917 ) ;
  }

  @Test
  public void test2762() {
    coral.tests.JPFBenchmark.benchmark30(-96.44437310741714 ) ;
  }

  @Test
  public void test2763() {
    coral.tests.JPFBenchmark.benchmark30(-96.45405394886524 ) ;
  }

  @Test
  public void test2764() {
    coral.tests.JPFBenchmark.benchmark30(-9.648779146836375 ) ;
  }

  @Test
  public void test2765() {
    coral.tests.JPFBenchmark.benchmark30(-96.50733194483682 ) ;
  }

  @Test
  public void test2766() {
    coral.tests.JPFBenchmark.benchmark30(-96.52655143696633 ) ;
  }

  @Test
  public void test2767() {
    coral.tests.JPFBenchmark.benchmark30(-96.52892060484919 ) ;
  }

  @Test
  public void test2768() {
    coral.tests.JPFBenchmark.benchmark30(-96.68386182743025 ) ;
  }

  @Test
  public void test2769() {
    coral.tests.JPFBenchmark.benchmark30(-96.68642231975709 ) ;
  }

  @Test
  public void test2770() {
    coral.tests.JPFBenchmark.benchmark30(-96.73599122179768 ) ;
  }

  @Test
  public void test2771() {
    coral.tests.JPFBenchmark.benchmark30(-96.81337083742115 ) ;
  }

  @Test
  public void test2772() {
    coral.tests.JPFBenchmark.benchmark30(-96.82090186776946 ) ;
  }

  @Test
  public void test2773() {
    coral.tests.JPFBenchmark.benchmark30(-96.8297451065897 ) ;
  }

  @Test
  public void test2774() {
    coral.tests.JPFBenchmark.benchmark30(-96.83026949497653 ) ;
  }

  @Test
  public void test2775() {
    coral.tests.JPFBenchmark.benchmark30(-96.85506091553742 ) ;
  }

  @Test
  public void test2776() {
    coral.tests.JPFBenchmark.benchmark30(-96.85737160693941 ) ;
  }

  @Test
  public void test2777() {
    coral.tests.JPFBenchmark.benchmark30(-96.9776543322167 ) ;
  }

  @Test
  public void test2778() {
    coral.tests.JPFBenchmark.benchmark30(-96.99108564664989 ) ;
  }

  @Test
  public void test2779() {
    coral.tests.JPFBenchmark.benchmark30(-97.01675904303926 ) ;
  }

  @Test
  public void test2780() {
    coral.tests.JPFBenchmark.benchmark30(-97.07434598814145 ) ;
  }

  @Test
  public void test2781() {
    coral.tests.JPFBenchmark.benchmark30(-97.13020939606184 ) ;
  }

  @Test
  public void test2782() {
    coral.tests.JPFBenchmark.benchmark30(-97.15719059314532 ) ;
  }

  @Test
  public void test2783() {
    coral.tests.JPFBenchmark.benchmark30(-97.16566757352886 ) ;
  }

  @Test
  public void test2784() {
    coral.tests.JPFBenchmark.benchmark30(-97.20779049513251 ) ;
  }

  @Test
  public void test2785() {
    coral.tests.JPFBenchmark.benchmark30(-97.210125829406 ) ;
  }

  @Test
  public void test2786() {
    coral.tests.JPFBenchmark.benchmark30(-97.26201357688294 ) ;
  }

  @Test
  public void test2787() {
    coral.tests.JPFBenchmark.benchmark30(-97.2760729081467 ) ;
  }

  @Test
  public void test2788() {
    coral.tests.JPFBenchmark.benchmark30(-97.28763401755494 ) ;
  }

  @Test
  public void test2789() {
    coral.tests.JPFBenchmark.benchmark30(-9.730240101184506 ) ;
  }

  @Test
  public void test2790() {
    coral.tests.JPFBenchmark.benchmark30(-9.731338970125364 ) ;
  }

  @Test
  public void test2791() {
    coral.tests.JPFBenchmark.benchmark30(-97.34658936395239 ) ;
  }

  @Test
  public void test2792() {
    coral.tests.JPFBenchmark.benchmark30(-97.34915917399572 ) ;
  }

  @Test
  public void test2793() {
    coral.tests.JPFBenchmark.benchmark30(-97.36797114534232 ) ;
  }

  @Test
  public void test2794() {
    coral.tests.JPFBenchmark.benchmark30(-97.37431388095166 ) ;
  }

  @Test
  public void test2795() {
    coral.tests.JPFBenchmark.benchmark30(-97.40654852187825 ) ;
  }

  @Test
  public void test2796() {
    coral.tests.JPFBenchmark.benchmark30(-97.40840204419077 ) ;
  }

  @Test
  public void test2797() {
    coral.tests.JPFBenchmark.benchmark30(-97.44882448092427 ) ;
  }

  @Test
  public void test2798() {
    coral.tests.JPFBenchmark.benchmark30(-97.5327345727341 ) ;
  }

  @Test
  public void test2799() {
    coral.tests.JPFBenchmark.benchmark30(-97.60287392001676 ) ;
  }

  @Test
  public void test2800() {
    coral.tests.JPFBenchmark.benchmark30(-97.6362673070867 ) ;
  }

  @Test
  public void test2801() {
    coral.tests.JPFBenchmark.benchmark30(-97.6363348470967 ) ;
  }

  @Test
  public void test2802() {
    coral.tests.JPFBenchmark.benchmark30(-97.71620412090387 ) ;
  }

  @Test
  public void test2803() {
    coral.tests.JPFBenchmark.benchmark30(-97.72462304289992 ) ;
  }

  @Test
  public void test2804() {
    coral.tests.JPFBenchmark.benchmark30(-97.73116031529194 ) ;
  }

  @Test
  public void test2805() {
    coral.tests.JPFBenchmark.benchmark30(-97.77075220085239 ) ;
  }

  @Test
  public void test2806() {
    coral.tests.JPFBenchmark.benchmark30(-97.78890758328937 ) ;
  }

  @Test
  public void test2807() {
    coral.tests.JPFBenchmark.benchmark30(-97.79046023112979 ) ;
  }

  @Test
  public void test2808() {
    coral.tests.JPFBenchmark.benchmark30(-9.781722817968145 ) ;
  }

  @Test
  public void test2809() {
    coral.tests.JPFBenchmark.benchmark30(-97.88042039430351 ) ;
  }

  @Test
  public void test2810() {
    coral.tests.JPFBenchmark.benchmark30(-97.9444023736487 ) ;
  }

  @Test
  public void test2811() {
    coral.tests.JPFBenchmark.benchmark30(-9.80492036174438 ) ;
  }

  @Test
  public void test2812() {
    coral.tests.JPFBenchmark.benchmark30(-98.19330095020801 ) ;
  }

  @Test
  public void test2813() {
    coral.tests.JPFBenchmark.benchmark30(-98.19723550292483 ) ;
  }

  @Test
  public void test2814() {
    coral.tests.JPFBenchmark.benchmark30(-98.24175907108364 ) ;
  }

  @Test
  public void test2815() {
    coral.tests.JPFBenchmark.benchmark30(-98.26222848060443 ) ;
  }

  @Test
  public void test2816() {
    coral.tests.JPFBenchmark.benchmark30(-98.37309188711023 ) ;
  }

  @Test
  public void test2817() {
    coral.tests.JPFBenchmark.benchmark30(-98.37987161569177 ) ;
  }

  @Test
  public void test2818() {
    coral.tests.JPFBenchmark.benchmark30(-98.39969895998169 ) ;
  }

  @Test
  public void test2819() {
    coral.tests.JPFBenchmark.benchmark30(-98.41303054406146 ) ;
  }

  @Test
  public void test2820() {
    coral.tests.JPFBenchmark.benchmark30(-98.44078208221019 ) ;
  }

  @Test
  public void test2821() {
    coral.tests.JPFBenchmark.benchmark30(-98.51168666377892 ) ;
  }

  @Test
  public void test2822() {
    coral.tests.JPFBenchmark.benchmark30(-98.64576680148392 ) ;
  }

  @Test
  public void test2823() {
    coral.tests.JPFBenchmark.benchmark30(-98.6600526906166 ) ;
  }

  @Test
  public void test2824() {
    coral.tests.JPFBenchmark.benchmark30(-98.72535226054664 ) ;
  }

  @Test
  public void test2825() {
    coral.tests.JPFBenchmark.benchmark30(-98.72997223359059 ) ;
  }

  @Test
  public void test2826() {
    coral.tests.JPFBenchmark.benchmark30(-98.73536240674142 ) ;
  }

  @Test
  public void test2827() {
    coral.tests.JPFBenchmark.benchmark30(-98.7423151596735 ) ;
  }

  @Test
  public void test2828() {
    coral.tests.JPFBenchmark.benchmark30(-98.80992284015339 ) ;
  }

  @Test
  public void test2829() {
    coral.tests.JPFBenchmark.benchmark30(-98.8375081112828 ) ;
  }

  @Test
  public void test2830() {
    coral.tests.JPFBenchmark.benchmark30(-98.87076510256283 ) ;
  }

  @Test
  public void test2831() {
    coral.tests.JPFBenchmark.benchmark30(-98.9414786812999 ) ;
  }

  @Test
  public void test2832() {
    coral.tests.JPFBenchmark.benchmark30(-98.9565246688161 ) ;
  }

  @Test
  public void test2833() {
    coral.tests.JPFBenchmark.benchmark30(-98.98156987956963 ) ;
  }

  @Test
  public void test2834() {
    coral.tests.JPFBenchmark.benchmark30(-99.02371266724359 ) ;
  }

  @Test
  public void test2835() {
    coral.tests.JPFBenchmark.benchmark30(-99.02649493978942 ) ;
  }

  @Test
  public void test2836() {
    coral.tests.JPFBenchmark.benchmark30(-99.07431762047922 ) ;
  }

  @Test
  public void test2837() {
    coral.tests.JPFBenchmark.benchmark30(-9.910839570414211 ) ;
  }

  @Test
  public void test2838() {
    coral.tests.JPFBenchmark.benchmark30(-99.17575077013774 ) ;
  }

  @Test
  public void test2839() {
    coral.tests.JPFBenchmark.benchmark30(-99.22381440142844 ) ;
  }

  @Test
  public void test2840() {
    coral.tests.JPFBenchmark.benchmark30(-99.26854074643872 ) ;
  }

  @Test
  public void test2841() {
    coral.tests.JPFBenchmark.benchmark30(-99.2832901886049 ) ;
  }

  @Test
  public void test2842() {
    coral.tests.JPFBenchmark.benchmark30(-99.31468007851163 ) ;
  }

  @Test
  public void test2843() {
    coral.tests.JPFBenchmark.benchmark30(-9.931471167894301 ) ;
  }

  @Test
  public void test2844() {
    coral.tests.JPFBenchmark.benchmark30(-99.32589649639603 ) ;
  }

  @Test
  public void test2845() {
    coral.tests.JPFBenchmark.benchmark30(-9.935614367970032 ) ;
  }

  @Test
  public void test2846() {
    coral.tests.JPFBenchmark.benchmark30(-99.41217431180857 ) ;
  }

  @Test
  public void test2847() {
    coral.tests.JPFBenchmark.benchmark30(-99.42224893548457 ) ;
  }

  @Test
  public void test2848() {
    coral.tests.JPFBenchmark.benchmark30(-99.47944582594444 ) ;
  }

  @Test
  public void test2849() {
    coral.tests.JPFBenchmark.benchmark30(-99.52279791143074 ) ;
  }

  @Test
  public void test2850() {
    coral.tests.JPFBenchmark.benchmark30(-9.957012453587268 ) ;
  }

  @Test
  public void test2851() {
    coral.tests.JPFBenchmark.benchmark30(-99.64043551731928 ) ;
  }

  @Test
  public void test2852() {
    coral.tests.JPFBenchmark.benchmark30(-99.65054548278742 ) ;
  }

  @Test
  public void test2853() {
    coral.tests.JPFBenchmark.benchmark30(-99.69932787760354 ) ;
  }

  @Test
  public void test2854() {
    coral.tests.JPFBenchmark.benchmark30(-99.72331337279057 ) ;
  }

  @Test
  public void test2855() {
    coral.tests.JPFBenchmark.benchmark30(-99.7248723429372 ) ;
  }

  @Test
  public void test2856() {
    coral.tests.JPFBenchmark.benchmark30(-99.84664062200825 ) ;
  }

  @Test
  public void test2857() {
    coral.tests.JPFBenchmark.benchmark30(-99.87089767771002 ) ;
  }

  @Test
  public void test2858() {
    coral.tests.JPFBenchmark.benchmark30(-99.89302262151634 ) ;
  }

  @Test
  public void test2859() {
    coral.tests.JPFBenchmark.benchmark30(-99.90307527743548 ) ;
  }

  @Test
  public void test2860() {
    coral.tests.JPFBenchmark.benchmark30(-99.9185215037494 ) ;
  }

  @Test
  public void test2861() {
    coral.tests.JPFBenchmark.benchmark30(-99.92143633849679 ) ;
  }

  @Test
  public void test2862() {
    coral.tests.JPFBenchmark.benchmark30(-99.94172898767393 ) ;
  }

  @Test
  public void test2863() {
    coral.tests.JPFBenchmark.benchmark30(-99.97960083019797 ) ;
  }
}
