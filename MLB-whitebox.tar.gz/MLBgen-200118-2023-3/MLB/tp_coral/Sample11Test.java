import org.junit.Test;

public class Sample11Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark11(-0.702179622174441,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark11(-1.0000000000000002,-0.6788401335140509,-9.52577441191768,-0.04503869955545903 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark11(-1.0000000000000004,-0.9637353299662096,-2452.952971270889,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark11(-1.0000000000000036,-0.19100884488900904,1.04367032593614,-0.24369995401435807 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark11(-1.0000000000000142,-1.3942678385752645,-0.43770313067269684,-1.0000135360456044 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark11(-1.0000000000000142,-1.5635674706462794,-96.39594892171303,1.0000012714825246 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.0011484729118271533,0.09672339745219224,78.23468912821016 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark11(-1.0000002546480022,-1.5048664170981032,0.0,0.06259708959509455 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.006256768249015563,-100.0,-1.0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.00693332342531372,-87.46942305955704,-0.05955080028033066 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.014297536618005254,0.0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.01579974487532508,-88.23921558949904,60.535699949704295 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.02077406838353503,-84.1873548386834,88.5515556968551 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.025125657390524456,-60.85084796856782,1.0000197182233712 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.033789946792620526,0.0,-1.0842021724855044E-19 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.037249106315296814,-0.42186217746550503,-1.6940658945086007E-21 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.037258454609628795,-0.7487531810873735,-0.3621554877669839 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.048371176169782426,-62.71988635763195,-1.0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.05516550284831223,1.4909861272826415,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.06808660853236187,-93.58594832946427,-1.0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.07208310601205642,-12.414972759890802,-0.02023371444282296 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.07880246572005588,-58.705178585703386,-0.8007627135298091 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.0863970144671199,-13.239989805230888,-3.280907199404709 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.09233999487354835,-1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.09376086427888938,-17.45736767475867,-100.0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.09992190676605284,-13.53765782084246,1.0000000000000753 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.10988632264983589,-61.12962105736821,0.0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.1204908507509981,-100.0,-24.506178203121493 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.14743942208267963,-44.07897262537289,-0.6811416899701797 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.1559048650935292,0.0,-1.0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.15721115853739287,0.0,1299.6033651834343 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.16483049223666207,-11.44544128916073,0.06260589427909523 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.1817944994414901,-24.61731060876977,-0.03674368661971783 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.18318548126043055,-73.74984207396275,5.421010862427522E-20 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.1880138857277842,-71.74881228883477,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.19325395103017995,0.0,2.2541451703578456E-131 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.1936911901899554,-80.71933092860235,0.8978016640227361 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.21336588081113908,-1.5707963267948966,0.06255271223173696 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.22361273495338405,-13.682860008361674,-1.5064309205589933E-7 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.22929357558187624,0.0,1.0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.2349917059074698,-27.447011126412868,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.23545109504114947,0.0,0.9500696949994243 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.24420957186150985,-20.03832214747851,0.9287166552336489 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.24658050887274838,-67.14688321272149,1.0000000078561284 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.26030637897969483,-9.870084063006757,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.26615961339652167,-0.5273865850068621,0.7703425926726459 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.2835848637635308,-0.6191562633641738,-0.0625527009977498 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.29420515451421636,-78.2614430816011,51.61016910999747 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.29977133027507863,-1.2482867768673773,1.000000703072568 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.3017002906171101,-78.4959788122819,1.8991135491519597E-65 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.3138473541818352,-15.88498651670351,0.007734610773550525 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.3245605232069594,-1.549810661770493,-0.9746027760958775 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.3829632544854026,-1.5707963267948966,-2.2761049594727193E-159 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.38589367155991355,-1.5707963267948966,-0.05301041230042586 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.39310478967538875,-56.49029774082792,-0.10151989507605308 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,0.3993594446784726,100.0,0 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.43501618036622797,-0.48466022403883147,50.741154888799514 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.45290439394530857,-58.18059672651107,-37.47401804855805 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.45641804022810106,-36.15814510884064,61.40337861445577 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.4664605119460445,0.0,-0.5266990743894976 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.47155616590273497,0.31307361466302963,48.2141096498606 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.47730478775382357,-65.82839366623855,0.9801904032459785 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.4845273711277742,-100.0,0.26334945055984504 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.4937294658899256,-54.40425761638511,0.06255714437823298 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.4952878630770341,-10.690350977410422,69.48718774961156 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.5061523618901829,0.0,25.54818559759315 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.5173790128010767,-21.171296294801923,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.5178982870099075,-5.372364530627006,8.658962748794407E-7 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.5304979916106356,0.0,-1.0000004754826235 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.5756411343116792,-65.10374240267652,1.0 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.5763542295933577,-12.029277341334605,20.517537518454404 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.605212646892312,-95.43023800281881,100.0 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.6301297675157402,0.0,1.0 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.6317614399668515,-21.292105330367434,-20.417733727486237 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.6381401002601784,-72.38460352474345,-1.0 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.6436456984834038,-5.9770247098001335,-1.0 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.6472604796113536,-9.184582327831663,1.6242827758820155E-114 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.6474639912307927,1.1280260437079903,0.9584054757681087 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.6607550286620232,-44.13809211692169,1.6940658945086007E-21 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.6609937603731926,-1.5707963267948966,-50.89476981747323 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.6666821189995175,-27.45258970990774,0.8574294055548941 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.6669580047636738,-49.02598982669466,-1.0 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.6807524236198103,-1.5707963267948983,1.0 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.7014530091785888,-2.5642709580557863,85.42415122963897 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.71375550811983,-21.61271660110669,0.9999999999999991 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.7599815648541641,0.02925793131972576,0 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.7754127437851551,-33.8491329542129,-1.000000037599953 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.786292049564156,-88.29851923396174,33.79163005341678 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.7985175414300316,-19.395642047183,32.97157485156603 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.8231848763804878,-0.2792573568163572,1.734723475976807E-18 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.8233438745577201,-53.85246613809581,-0.005688600387712406 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.8252862575221975,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.8665359567798547,-61.40541343155765,1.614220128250878 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.869156408174041,-2.8602233852071794,-4.930380657631324E-32 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.8700703596908906,-30.172635196938053,-1.0 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.8750738853858951,0.0,1.0000000000000002 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.9047336983872275,-97.37728800865682,-1.0 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.9182587265730302,-32.75272406223346,-60.405330970974624 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.9202283316521118,-87.53774356590745,22.568330051327877 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.9334815644627054,1.274639898685578,1.0 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.9541063386517464,-1.5707963267949054,-7.68947813625347 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.9541430510283525,0.0,-0.010613805684188099 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.9613986457050064,0.0,2.4559394674125074E-15 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.9673159466418711,-45.77661085602542,-0.05255633524377634 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.999859510377334,-26.930112900712032,1.0 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.0069825907079417,-1.3178774020031432,-1.0000012248074648 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.0124229208972773,0.0,-1.0 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.029811817630873,0.35156722709360444,0.05981363026653805 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.0341107735461295,-72.6894932555559,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.0638591541486448,-1.2523910593623144,0.0 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.071288524781153,-91.44144598717291,-1.0 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.0956600663655096,-72.3233268450417,1.0 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.0979749688810467,-40.501649387916,-0.9781579106645446 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.1065885399972335,-25.836752591472035,-57.845186190552184 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.1102230246251565E-16,0.0,32.69338783756418 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.1243680082213214,-40.85132075750394,2.0165824105866648E-4 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.1478927469690063,0.19064333921118826,26.82357602072917 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.1565097451300461,1.5527225573978694,1.0 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.1688451481945474,-36.45339169108645,0.222318985040735 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.1722096236454376,-23.894063710468828,-0.8171438742430088 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.1727840529301983,-53.83073042192907,0.35203677044543724 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.2024755959308993,-1.1102230246251565E-16,0.04535115770038658 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.2220887723643756,0.0,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.2561551574589063,-67.20552530021031,1.000003203319757 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.2768942512667467,-62.653212095962374,-1.0 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.2865209387971532,-1.5707963267949125,-1.0 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.3028873802750998,-39.021832695444814,1.0 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.3228406520079763,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.3252843067099782,-1.5707963267949054,61.45553599007208 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.3334989942002116,-74.07898587607221,1.0000000035712855 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.3412859881105845,-5.548365162704751,1.0 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.3435462714779476,-32.87239340105286,1.0 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.3573104404910992,-10.542691656859683,-0.9221065249106459 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.372341952755758,-87.6465579320591,-1.0 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.3877931119626568,-66.69536435646033,-0.4828536185876846 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.397327212944495,-24.055639151464575,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.4029594282971096,-21.91280255608867,0.9997027477872369 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.408622916146036,-52.83520718155028,-1.0 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.414855884227431,-1.5707963267948948,1.0 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.4203806074147949,-0.8470492194224192,0.3647623515000289 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.4275410587955981,1.2872183585807806,0.2981498866209169 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.4355383668741422,-0.3234735118492075,1.0000155406440483 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.4388495361504865,-7.38021301770465,1.0842021724855044E-19 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.4512447572688596,-4.3908719845248765,0.0 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.4567994843318708,-88.66933317630982,0.03352293554330632 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.4662869250798212,1.5707963267948806,1.0 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.468402013211679,0.0,-62.02881382565934 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.4730998296325861,-1.5707963267948966,0.9999999999999999 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5132435725234008,-1.5707963267948983,-0.9999999999999999 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5152325797314095,-66.49770738391607,-1.0 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5222084728173135,-26.193876477204135,-1.0 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5255893271935994,-0.05087584986815044,0.15869554499606325 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5293578635491314,-14.473501012052068,0.0 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5298984530403539,-37.84874202093336,4.5719495651291E-100 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5362425710755423,-57.77618281765031,-0.917386815010643 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5425704426715459,1.4842609184871804,0.9560320558269297 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5432145095227554,-4.751191610055017,-0.23198888478906743 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5519155077866131,-1.5707963267948966,-0.06255255952239029 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5604986551688984,1.4044301411737083,1.0 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5627666312490853,-29.769960241169112,1.0 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5663074158290662,-0.5276344244396367,0.9174473216470991 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5663983444422112,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5687563607059967,0.0,100.0 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5689148816827057,-52.137452793453036,-0.010367201954486217 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.569177652954983,0.0,0 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5693512341554507,-50.36990042561076,-20.450785398737246 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5699533451143313,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.570796326794866,-67.45503589738362,-0.36216579968106777 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948744,-68.15959715610694,-0.6208013205531699 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.57079632679488,-1.107521074257631,-1.0 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948912,-100.0,-1.6376922960732273E-5 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948912,-15.207586477887052,-1.0 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948912,-25.929040189853595,100.0 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948912,-28.628059754079445,1.0 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948912,-40.05711137309367,0.6651237216687148 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948912,-50.67140323119426,-30.39950703880335 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948912,-5.39324754733363,-100.0 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948912,-65.35459635666727,1.0 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948912,-68.5578244476501,-0.042065189317384344 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948912,-86.44020182866305,11.027824466827369 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948912,8.905781117218061E-4,-0.19220253612074523 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948912,-95.57351492808762,1.000006508683763 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948912,-96.26155531042592,-4.406067598722288 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948912,-9.90701646526681,-1.0 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948948,0.0,-1.0 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948948,0.7349292166388057,0.5887540146215715 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948948,1.4855756626340408,100.0 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948948,-15.494791848599386,-0.05660731561978281 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948948,-1.5564677085196275,0.7658907518618747 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948948,-1.5707963267948963,-1.0 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948948,-40.545543909959456,-5.3232275581390525 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948948,-58.89459074638209,0.062566380179005 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948957,0.0,100.0 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948957,-100.0,-1.0000000310762631 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948963,0.0,0 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948963,1.1102230246251565E-16,101.66712491436843 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948963,-48.68893320192658,0.03708397281438462 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-3.552713678800501E-15,0.0,0.35674465353436724 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-4.440892098500626E-16,-2.4387250877160085,41.198177928109004 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-6.018440492487986E-4,-1.5707963267948961,2.996272867003007E-95 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-7.105427357601002E-15,-31.697214306182016,-84.53388850346421 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-7.140654365153542E-4,-23.29555792794818,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-8.240298064010428E-5,-25.634774799999303,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-8.881784197001252E-16,-1.0650667114618084,0.2641995774023327 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-9.860761315262648E-32,-51.837544974926374,1.0000001125679843 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark11(-1.001208114073717,-0.8273260990761702,-56.96411630439897,-0.8095961191843576 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark11(-100.25257028132353,-0.9365525045638714,-20.210198635669826,7.852283657237944 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark11(-10.034180296268469,-0.6424372389274997,-1.5707963267948966,1983.3800964581537 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark11(-1.00462685452121,-0.2830766146385848,-62.155618205436554,-0.04070226017626098 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark11(-10.072008123247116,-1.5707963267948948,-20.898020321364775,39.40970571240435 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark11(-10.105329876910488,-0.6743373385323097,-37.92192553535628,1.0 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark11(-1.0115504517276164,-1.5611092030814229,-25.60928695892556,0.014014815165625097 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark11(-101.46333849514154,-1.570796326794893,-95.79358611390188,50.60929733661126 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark11(-10.148755721063733,-2.220446049250313E-16,-42.41779002625726,0 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark11(-1.0,-1.5707963267948912,3.7531481516510694,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark11(-102.02932296818815,-0.03399466735492995,0.0,669.0736306412157 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark11(-10.220401147958142,-0.020152343879846258,-1.5707963267948808,-58.24134930004104 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark11(-10.255968369878637,-0.6522922032531583,-10.027515560925977,46.713112367960264 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark11(-103.82640812305031,-0.1223886488071761,-0.0929634248686485,0.06043013212563959 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark11(-10.38480763037407,-0.6039950850623725,-79.37555537287594,73.8543365916046 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark11(-10.38749031662806,-1.4861795802955846,-1.5707963267948966,-0.9999999999999816 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark11(-1.0488260540768024,-0.5237284272456375,0.0,46.05109056105522 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark11(-105.06539250084836,-0.6064994787733892,-1.1102230246251565E-16,2170.226504604667 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark11(10.509938899503666,-32.90922766930595,-75.90063241032743,0 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark11(-10.521971267233631,-1.1102230246251565E-16,0.0,0.0 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark11(-106.13333758836141,-1.0297007388372734,-96.87417637509496,-0.9852197530647635 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark11(-106.31319771831124,-0.024923914332831032,-30.811830715177777,1.0 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark11(-10.802141015486317,-0.38173128776024307,-0.8928218128702667,0.7146953836233225 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark11(-10.825225698042724,-1.4047628876544462,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark11(-1.0826107002107515,-4.440892098500626E-16,-96.82154003201137,0 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark11(-108.29629901731874,-8.375003683180418E-18,1.570796326794893,-1.0000000004080882 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark11(-108.47461422210407,-1.5707963267948948,-1.5707963267948966,2199.861955475894 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark11(-10.909290867989817,-1.5595381966545054,0.0,1.0 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark11(-10.916930896142706,-0.32469803581052925,-71.44110070939443,-0.9999999999999957 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark11(-10.96592728322537,0,0,0 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark11(-109.69725383545202,-1.5554168471208811,-24.5544307612181,-12.02668276053818 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark11(-109.99894510449444,-0.2868682217767291,-123.81695455810876,-0.9984941660512905 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark11(-11.005770129461496,-0.9304546561833646,-42.474115865389294,0.9999999999999982 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark11(-11.054042288818932,-1.5646394174448788,-73.44147658009778,1.0 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark11(-110.55927447186728,-0.787682338877483,0.0,0.01805330667902777 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark11(-1.1160668177504434,-4.2423532638157413E-16,0.0,0.2785005360592647 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark11(-11.169559868710833,-0.3212495428961148,-77.00416001054491,-1.0 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark11(-111.79270901252495,-0.4224302719162069,-88.19054783230102,-2181.9242908515544 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark11(-1.1192995025942951,-1.1489899589945318,-73.4646233775288,0.0049165797692248825 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark11(-11.21727439650586,-0.05375242831536564,-1.5707963267948966,0.7481388932003498 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark11(-11.267477591670644,-0.03704912622510999,-31.528993087277655,-0.056648863580311376 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark11(-112.87046029117457,-0.9257994434677244,-78.37915536251359,64.00628378018394 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark11(-11.300998402582223,-0.0045809862514293795,-29.94674309618493,69.25562806329373 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark11(-113.34655747154103,-0.5098103804523451,-165.59468707178448,-0.7391599431454843 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark11(-1.133700129128217,-0.04576407711607191,1.0624401340346823,6.938893903907228E-18 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark11(-113.97348234093663,-1.3708478804886919,-128.12748662148982,-6.26526553641133E-5 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark11(-11.577894081157895,-1.5707963267948963,-51.93694955353009,1.0 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark11(-11.61483566100479,0,0,0 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark11(-1.161515688145018,-0.5334133909257968,-1.5707963267948966,1.0151767349262597E-115 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark11(-11.615654918825769,-1.5707963267948963,-66.2853571100924,-0.9999999999999991 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark11(-11.6177531937422,-0.6916146312957873,0.0,23.42361083701941 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark11(-11.620694095746302,-0.48666117446143087,-38.9417542398331,-0.004983042222991211 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark11(-11.643991801557211,-1.5441864178859992,-53.95963770922936,1820.1201434550724 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark11(-11.664024222798759,-1.3877787807814457E-17,-32.57794580578414,1.0 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark11(-11.664299305935105,-1.7806419502792766E-14,-67.71992087078499,-1.0 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark11(-11.79723508863538,-1.4878181367393992,-44.06536333184718,0.9876336106220025 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark11(-11.821852429453958,-0.967583768875821,-44.57205279559828,-1.0 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark11(-11.834976905729333,-0.05469213492170502,-76.89200642612809,0.0 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark11(-11.836017925789312,-1.176092363776371,-10.739039489979724,0.5012515728766428 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark11(-1.184124209977053,-0.0010275519326300596,-1.5707963267948966,3.3881317890172014E-21 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark11(-118.6147736302333,-0.9661078728120103,-33.873649563136524,-1528.8972248849113 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark11(-12.073070957044436,-0.2130109733922058,-1.5707963267948966,-36.78210313796202 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark11(-12.083584910829646,-1.5032143140414025,-6.509766361398261,-0.06255603415150533 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark11(-12.134343935637194,-1.508045682476621,-21.780467021174584,-0.9999999999999996 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark11(-12.23365238434286,-0.45473172773193404,-18.56024996422643,7.105427357601002E-15 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark11(-122.38187777622979,-0.3285075309727309,0.0,0.09967251931435935 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark11(-122.40996071422491,-1.402161958959966,-3.1849131010572194,-95.75668364428347 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark11(-12.29176410210236,-0.9108609575883525,-21.631230978607043,1.0 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark11(-123.31923731541846,-0.14955414178827198,-53.96704057578173,-1.0 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark11(-123.57497748079882,-0.23294040618970158,-101.01029273125484,-0.9999999991371424 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark11(-12.384178616639327,-1.5707963267948912,-66.01356817274461,0.0 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark11(-12.427634008633337,-1.375201411006997,-29.46067697940014,-93.45317764107959 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark11(-124.30903003194624,-0.16791708288383966,-52.17489103769825,-64.54816654994856 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark11(-12.445117341166045,-0.08322848502483998,-1.5707963267948966,0.03586619807002767 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark11(-12.455476336017313,-1.2756468761070914,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark11(-1.2473534672862456,-0.5632065674417657,-50.615177726401896,53.147867548016535 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark11(-12.51972772900372,-1.1738624219696878,-3.61366633162744,0.0 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark11(-12.551394249555713,-1.4627084961917376,-14.689631321746631,-11.87605307264326 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark11(-12.559587607794882,-0.9471592598104921,-51.84960808655419,-0.06129621205054459 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark11(-12.644075420916847,-0.8298006402272358,0.5882400156308627,0.9999999999999954 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark11(-12.722420178922524,-0.2441954953747283,1.5707963267945786,0.3586809033319325 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark11(-1.273909899618002,-0.21416455730505216,0.8576722665566018,-0.36222183360879556 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark11(-128.6943891454219,-0.17273360937540597,-43.35911603838706,-2156.450565546488 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark11(-12.87038508096613,-2.598791694912421E-4,-3.202075740998021,-0.9112938740791237 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark11(-1.2931189538416894,-1.1044448543291154,-1.5707963267948983,-0.9248398677223539 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark11(-12.934481311891027,-1.1539324287190784,0.0,-0.7467741643610748 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark11(-12.94888104394589,-0.09848961346311025,0.2016711609205947,1.734723475976807E-18 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark11(-129.5991839738427,-7.105427357601002E-15,-1.2951449097228362,-2162.0013034974863 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark11(-129.97616828446922,-1.5707963267948948,-0.43568949165455406,-2100.8701917287194 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark11(-1.3009029418002225,-0.7715599758626183,-1.5707963267948966,0.8840203256247224 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark11(-13.012887895938022,-0.841118857294058,-24.788089284995145,0.5584084145393575 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark11(-13.072539787414323,-0.09821790377052025,-3.1163450730858635,1.0 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark11(-13.122351215297684,-1.5707963267948963,-96.24693076590465,1.0 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark11(-13.287479676014664,-1.5473852211251644,-0.40152388882277207,-23.749168315567417 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark11(-132.96156093963867,-0.3252466887633689,-92.80094725989686,2176.1058785405794 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark11(-13.332554000788111,-0.6377722866241129,1.5161560735003707,-1.0 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark11(-133.57836599875216,-1.5707963267946718,-0.027879360229379868,2030.6198463366727 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark11(-13.39549394499084,-0.12943660958956424,-19.383349265386162,0.6363784332644953 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark11(-13.400752918856092,-1.5707963267948948,-89.52981386831227,-42.534749451210985 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark11(-13.413379471048518,-1.0900831268526445,-36.742987746176766,-56.7205044464217 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark11(-134.5518722265333,-0.878823729713476,0.0,-56.13765955042851 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark11(-1.346453280589905,-0.36763331052136655,0.42129798715562106,-0.15084901152122177 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark11(-13.46569259864786,-1.5497050588214576,-8.674127560752915,0.8492617054461109 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark11(-135.1025535831511,-1.4113407817194255,-65.97776900167369,-2207.479332218659 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark11(-13.538255440080167,-1.406973561654675,-0.1328657536474168,-67.905377171964 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark11(-13.544063768716171,-0.5051117467682736,-157.36719790748032,18.12443986143583 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark11(-13.555218392987122,-1.211085056376632,-94.33684849574945,1.0 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark11(-135.92567652944564,-0.20812468794204264,-130.20578750167726,0.9999942556542314 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark11(-13.621492046049777,-1.5341371698588435,-88.09551046439974,0.9161109064361814 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark11(-13.627485244842362,-1.1117737941330859,-80.37862097264878,1.0 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark11(-13.657018638188646,-40.394334797318756,0,0 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark11(-13.687828545125496,-1.5707963267948948,-31.713413596164525,-1974.4132224020934 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark11(-13.714539403950575,-0.27793031695504405,-64.58909784025609,0.9999999999999999 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark11(-13.717840937844016,-1.5707963267948948,-28.872048501676293,-7.576948090028843 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark11(-13.771672414118854,-1.5707963267948948,1.5195392876609333,-1.0 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark11(-13.792585735361314,-1.5707963267948963,-0.0993061242566337,0 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark11(-1.3804188580486567,-0.13541090382387155,1.208197572847423,1977.5562513810828 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark11(-13.848698250040531,-0.2986670027698417,-164.6882579324568,-0.9999119218840891 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark11(-13.85035876528148,-1.570209542117244,-28.55424370124009,0.21398845396891386 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark11(-13.853724008899237,-0.7348775883609662,-90.34382741075817,70.60032647546015 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark11(-13.882827406383946,-0.3058241776899311,-77.21260382540281,-0.781221325296396 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark11(-13.892522429359051,-1.349328014642769,-0.20172261979022338,0.6073880729783211 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark11(-1.3998709870801207,-0.9240549542920447,-29.728741052964352,1.0 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark11(-14.01238896579606,-0.3301494635118134,-4.689447254678692,0.6071315659052684 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark11(-14.030571215377872,-0.5339391425494107,-1.5707963267948963,-1.0 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark11(-14.037407713607664,-1.5272109730550767,-21.88487738308524,1.0 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark11(-14.155954647225698,-0.03837352062895858,-37.71182077710071,0.6973051938662197 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark11(-14.223512936608408,-1.092245543562615,0.4246781626854067,0.1045458809768317 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark11(-14.260107002893532,-1.3378081447202474,-0.11124043708801912,2251.0580028020995 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark11(-1.4358739092799675,-7.105427357601002E-15,-57.99573096664788,0.048679728595188654 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark11(-1.4432467697583267,-0.42051591943510797,-0.5297061778370235,-58.78497730805483 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark11(-14.437525262096399,-1.197048875498826,-65.05410873844976,-52.17512118418644 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark11(-144.81680987136232,-0.07817976203222077,-66.53021667660832,-0.8968644344752201 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark11(-145.0205013047297,-0.019402213076980923,-9.353907617284705,-1.0000000000000009 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark11(-14.516025501770573,-0.07563271608807647,-53.85437655202754,3.398506608884577E-4 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark11(-14.567926251876116,-0.7109378095279553,-32.41969361925679,26.098964520176764 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark11(-145.85889638565956,-1.3888505644683657,-74.01300290088132,-0.5151082308344597 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark11(-14.612564993737294,-5.712727322469192,0,0 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark11(-1.4630111932780197,-1.5707963267948948,-43.99352155294543,0.02555366424016135 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark11(-14.638478993857149,-1.0010920536909835,0.0,0.47797533396570113 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark11(-146.70362422052628,-1.4216001961775377,-1.362384864609915,-0.9921407486253346 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark11(-14.75971082372747,-0.6472626645940253,-22.63932177194299,-0.4701754301463008 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark11(-14.769231120654498,-1.5621679781511995,0.0,-10.704014920281526 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark11(-14.789828017971416,-0.12809249537255846,0,0 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark11(-148.39845362131106,-0.16761279941821128,-53.055704345177986,0 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark11(-14.897335349455146,-0.016069274343031997,0.22631781697612752,-29.207711204332046 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark11(-14.988383459727636,-0.7827538225482613,-1.5707963267948966,-1.0000000484709424 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark11(-14.990283682648837,-0.21937376765911146,-71.3198554614129,-0.18730561825968728 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark11(-150.49352582424822,-1.570796326794893,-20.845980276233572,2264.887202874246 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark11(-15.051260971465027,-0.1827101812714318,-64.86356832913258,95.03173868598594 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark11(-15.114646758210881,-1.5707963267948961,-32.75398902979819,1.0 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark11(-15.171389527013275,-0.49747443728922125,-1.5707963267948966,58.41762612085258 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark11(-15.239581893470874,-1.3271629392362279,-4.197734096501723,-111.65951351475212 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark11(-152.5892285714138,-1.50454083263989,-136.49310462797933,2.7004222347613818E-8 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark11(-15.268050217742548,-0.08026242547304241,-0.20059733062454974,-45.27346973665863 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark11(-153.79123918619396,-0.2861169922198411,-86.24837004897576,2103.4859802625206 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark11(-1.5380279789165012,-2.220446049250313E-16,-33.70960992630873,-0.8289908994207751 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark11(-15.40991622866838,-0.8038105717051188,-4.8235825252292415,-63.09689612257971 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark11(-15.470617617457044,-1.444780518969701,-34.099144900796276,-0.801107803062721 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark11(-15.496486377546695,-1.2850150727668588,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark11(-1.549814085438574,-1.1881187504633375,-6.90953725601318,-0.9957694804548998 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark11(-15.573301228055357,-0.024977376142327756,-52.32021707628098,-1.0 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark11(-15.622921645188015,-0.13384638489501333,-11.081873943185045,0.0 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark11(-156.62147712785858,-1.2077153130571077,-142.18892620134295,-1.0000000199887908 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark11(-15.676080700724505,-0.08657748750176124,0.0,-0.9159423086622901 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark11(-15.706695536722224,-0.6421310642831333,-13.06339360140994,-0.9999999999999999 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark11(-15.742205786577657,-0.8746195048604787,-1.0267556865849732,0.03835089792668006 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark11(-15.768401317873696,-0.6840241694666862,-1.5707963267948966,0.9999999999999999 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark11(-15.781123906713091,-1.5667720329995234,-61.05011040410455,56.55723881960506 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark11(-15.801353901873023,-2.220446049250313E-16,-60.24709158502482,54.262068624846336 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark11(-1.580994385919659,-0.05807506257832351,-23.806256170757095,0.0 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark11(-15.832701616548638,2.9795964962797234,0.0,0 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark11(-15.971367596762015,-1.5707963267948961,-31.936213796924374,0.36209131311298004 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark11(-16.014021743675315,-0.1966623264362592,-46.79650277251286,-2223.947627674195 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark11(-16.035166974831895,-0.4003541459690938,-93.92129405633868,-41.794156929950724 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark11(-16.039937461311972,-1.500496895498467,-5.4028778733618195,-0.34456231160095396 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark11(-16.041278433357043,-3.552713678800501E-15,-69.04905382393731,0 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark11(-16.126801175325255,-0.5493799186778641,1.3990614244566297,-0.05973933386708654 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark11(-16.14354928411637,-1.5707963267948948,-0.2110479049146976,13.239249417523585 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark11(-16.171928419382148,-1.1967505295453194,-41.61665578742951,1.0 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark11(-16.20637679061639,-1.5707963267948963,-69.09609367188514,-0.9895052500749303 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark11(-162.94996997007175,-1.0144496875975184,-195.27022480314173,-1.000005458660354 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark11(-16.302066855388638,-0.31728828694320615,-9.444519621889132E-5,0.9574158829897503 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark11(-16.31796817498349,-1.5707963267948912,-66.52718641242268,-34.75101848793915 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark11(-163.40016160525633,-1.5597639785524393,1.5546506439486913,-0.06255252677241896 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark11(-16.372888086765826,-0.24661883674533414,0.0,-0.13829767322638986 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark11(-1.640560959044301,-0.35254730660492123,-84.47137392986825,1.0 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark11(-16.55003448347788,-1.3396232445682017,-30.38147481012558,-0.8481999677194757 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark11(-16.710584266610173,-0.9633002387538946,-31.625134932514797,1.0 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark11(-167.57319750535083,-0.4012321059200814,-135.51074279029163,-1.0298009254874902 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark11(-1.67591674011675,-0.5347338975414908,0.0,0.9999999999999964 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark11(-16.948799933510283,-0.672926621836579,-67.44030073875173,1.0 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark11(-17.07723825135198,-0.12928876127313121,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark11(-17.09521943001965,-1.205769091084211,-24.01357148191837,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark11(-17.1989896076591,-0.6336426760552845,-100.0,1.0 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark11(-17.266770298586074,-3.552713678800501E-15,1.2406213370706034,-1.0 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark11(-17.268294998586967,-1.5707962738621457,-31.361633913987806,-0.2705963924465332 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark11(-17.279059620078698,-0.557300906994114,-40.44049505682577,-1.0568384260149157 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark11(-17.3138340505005,-0.9236829972418502,-1.5362927389270689,-0.02476268139022777 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark11(-17.441804637473236,-1.546582078448979,-100.0,2.1175823681357508E-22 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark11(-17.58018102242002,-0.18200119871786774,-52.23016532637998,0.0 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark11(-17.667657557017492,-1.2165591493815247,-100.0,1.0006619666790542 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark11(-17.675074196377906,-0.02188612382372293,-7.6942926551495505,0.8156588503354243 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark11(-17.785030468504672,-1.0099674243883885,0.0,-1.0 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark11(-17.79201840737103,-1.5707963267948912,-27.155713264530007,33.235544127722505 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark11(-178.08553375356988,-1.5262060516686375,-110.51229361771641,21.516578593675774 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark11(-17.826403863856818,-0.11584428908732505,-88.42343428071364,-2.6727647100921956E-51 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark11(-1.7877035696978454,-1.4775749244118799,-65.64322682966369,-78.26902779262075 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark11(-1.7894117166324435,-0.0018392896938481396,-1.5707963267948983,-0.9752866743420467 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark11(-17.896905054917923,-1.2775417206721127,-67.2982804346279,0.2534343893819314 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark11(-17.966164471747984,-3.552713678800501E-15,0.0,7.777304376931646 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark11(-18.045845479407525,-0.9563733533203369,-0.22813718526840518,1975.1593572910929 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark11(-18.082021817554534,-0.012118702299147799,-31.220591771152037,-29.483743359346512 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark11(-18.092384575392757,-1.5707963267948908,-48.49511209997448,-0.75869543997959 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark11(-18.09531750974741,-0.37200401112854364,-185.44838281206077,-0.005762886919150723 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark11(-18.115532967187548,-0.28118758508916536,0.0,1.0 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark11(-18.12189050635065,-0.8612074513883069,-29.895073402092066,0.060686614870964675 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark11(-18.126851872860538,-0.17426909271460894,-38.03352823108243,-36.87190530509381 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark11(-18.173919203061562,-0.07454787474294361,-59.00621844440312,1.0 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark11(-18.251333109505204,-1.4586652979134658,-1.570796326794897,-15.098995251589768 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark11(-18.33493365435878,-1.2695657761303443,-52.34576777862215,5.551115123125783E-17 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark11(-18.414602929037173,-0.21571099034651908,-1.5707963267948966,0.6651513098623789 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark11(-1.842178862018483,-0.34332864258344337,-13.84353934122916,1.0 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark11(-1.8599394080713836,-1.3223948360667084,-37.45932576762318,-5.25177351605099 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark11(-186.1641236224066,-1.3437503416955887,-67.4414358373487,-8.32308261199858E-5 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark11(-18.843514616025228,-1.6673198231134128E-13,-1.5707963267949674,-1.3350619801653157E-13 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark11(-18.851753081449942,-1.5707963267948948,-38.86772210429568,1.0 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark11(-1.8861227562125165,-1.2359804612180372,-92.22545420915374,-0.476735548275812 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark11(-18.88678387495067,-0.7183272965767538,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark11(-18.91671188901666,-0.22289464053757202,0.0,45.88070926809337 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark11(-1.8973313999975119,-1.5707963267948912,-90.19911782484394,90.18781175452278 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark11(-19.012568166183158,-1.570796326794895,0.1267420097244048,-0.9076490509143175 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark11(-19.018999745304058,-1.1481497750347163,-84.28001729731935,0.5303633394627907 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark11(-19.041425559639617,-1.5531920150350629,-1.5707963267948948,47.1191421682432 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark11(-19.059684884458402,-1.5707963267948963,-3.4629509387424426,-100.0 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark11(-1.9078447429096235,-2.7755575615628914E-17,1.4892803221030777,0.0 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark11(-19.07988089442801,-1.5707963267948963,1.110021145958832,-0.6267339562086296 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark11(-19.12809082634898,-0.7289884094021204,-22.356906065763862,-0.5942164324637758 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark11(-19.170295460338284,-0.13809714077326815,0.0,-2.6727647100921956E-51 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark11(-19.232058112820596,-0.2557448161450164,1.205896331308828,20.836789612044242 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark11(-19.24337239035051,-1.2969976050780656,-19.20766514133922,0.8491289401823616 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark11(-19.290011004408175,-0.587829260701597,-34.87294279400532,73.12111306590003 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark11(-19.290610707513316,-0.061251461889697364,-38.592351227976884,-1.142987391282275E-100 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark11(-19.306509493222098,-1.5707963267948963,-1.5707963267948966,91.67925419282031 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark11(19.314868738598463,34.908023706235724,0,0 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark11(-19.42433815085287,-0.9162941651829235,-7.239391264609555,-94.08954584629807 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark11(-19.502837803345564,-0.20080676852725432,-89.5825739439201,1.0 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark11(-19.752666311424942,-0.7796580812572246,-32.63106909924358,-0.9999999999999996 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark11(-19.779605610286993,-0.5417038222230031,14.465679939035411,2.710505431213761E-20 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark11(-19.789941015174122,-0.4364160965562187,-6.625555850244095,0.12895067843610292 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark11(-19.81158245752991,-1.5379859732442362,0.16520945581485288,11.909051881880897 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark11(-19.825713910477845,-0.4123779212719965,-95.55480951596431,0.16088148088941523 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark11(-19.86142301891593,-0.4444190325121395,-91.17189893968296,1.0 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark11(-19.896628770408523,-4.4854887496474454E-4,-0.003975611968370414,1.0 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark11(-19.928080126645604,-1.2982556369025429,-86.54853885652487,53.01073940333161 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark11(-19.94507739377144,-0.04481843519711959,-100.0,0 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark11(-1.9972371864201859,-0.020245489159825956,-1.570796326795179,0.47532570827892573 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark11(2.000786999697297,0,0,0 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark11(-20.040660184040558,-0.4263897571821151,-0.297541919467864,0.03373056329179902 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark11(-20.040977591462553,-1.5707963267948912,0.0,1.0 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark11(-20.147573797793726,-1.0353019353918995,-1.1322708807596378,-21.668745584356717 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark11(-20.32989317277829,-1.2057779686124093,-14.580732495677918,-84.22372496411775 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark11(-20.363632763559835,-0.14337714587891262,-83.42258997978463,87.11979519824123 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark11(-20.413966217802507,-0.7559297151870974,-21.922844573505017,-1.0 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark11(-20.427277841657954,-3.1169083784996373E-17,-1.5707963267948966,-0.022993180770142063 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark11(-2.0430845351385756,-0.11507734665790004,-80.34743782006693,-4.784058281974138 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark11(-20.53004858587978,-0.0570003661540615,-27.425910333664262,1.0000001011382886 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark11(-20.536198468440173,-0.27814573878287463,-3.2489889635248277,-0.06343677554823547 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark11(-20.53659824099176,-0.37424880230424007,-81.199749966463,-100.0 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark11(-20.55858134086842,-0.39808147915240255,-1.130339547637069,4.3368086899420177E-19 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark11(-2.0743050488929726,-1.4992793070030075,-3.7633421032231684,-6.560812998240834 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark11(-20.774930252676658,-1.4702388883112083,-68.12143919513314,-2252.0040600482794 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark11(-20.851582534251797,-0.3270449766269108,-40.9019648332053,-1.0 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark11(-20.938179165447362,-1.5296311206622153,-1.5707963267948963,-1.0 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark11(-21.04196294200735,-0.03588135038379025,-18.270925386564784,0.021575280675118047 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark11(-21.063851462209644,-0.30488172638936994,-10.753057932657578,0.047441259976389816 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark11(-21.117013055285682,-1.5707963267948912,-58.87754090890694,-1.0 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark11(-21.12046538591821,-1.5707963267948963,-100.0,1.0000000007203067 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark11(-2.1379420105742155,-0.24453237732518396,-26.53001703072345,-27.210883696144066 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark11(-21.400680343630654,-1.2919293883799654,-47.657737015025425,-0.6663540814553557 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark11(-21.48142327269223,-0.7003596984205482,-1.5707963267948963,1.0 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark11(-21.498809515853242,-0.7062596158636127,0.4559744141850891,25.371537224636317 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark11(-21.679592859410455,-0.4797555561337774,-1.5707963267948983,-0.7527490851732828 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark11(-21.80509265192039,-8.881784197001252E-16,0.8586505496069115,0 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark11(-21.823449488847196,-0.4113682295065364,-45.22864189403158,-0.05606932871914672 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark11(-21.845686467502222,-0.16716607027235802,-1.3358909953138938,0.0 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark11(-21.898694873810154,-0.16777163278942453,-58.21995088387496,-0.7039857745841402 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark11(-2.1935777470518243,-0.2703510390216286,-10.20009874946053,84.21403483897993 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark11(-21.992221851480007,-1.5707963267948963,-0.4480947414500603,-0.020077310807662285 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark11(-21.993096603610994,-0.471410098555447,-1.5707963267948948,-14.870641131660339 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark11(-22.076516414122228,-0.21403712045292142,-30.254144427740815,0.02784779940777904 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark11(-22.14526716874243,-1.1614297509286617,-20.84554544375027,-0.021099830311861332 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark11(-22.1575591886077,-3.61284872940639E-15,1.1275954776890265,-1.0000000059768304 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark11(-22.171300210510992,-0.9019997730541972,-35.399464021860226,-40.945294556141505 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark11(-22.172074308845602,-0.12469747815836921,-75.206605975287,-1.0 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark11(-22.287233850197016,-1.5154428159266553,-1.389615177221234,-14.512310318289078 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark11(-22.295684219273575,-0.958223643658697,-75.3727490695298,-100.0 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark11(-2.236297883364645,-1.5707963267948963,-71.25120387702415,3.2126615085803623E-6 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark11(-22.466121289013522,-1.4171903271883117,-51.90200492741982,-94.51855590183713 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark11(-22.498288345317757,-0.11243598222449752,-9.81370378393232,-1.0 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark11(-2.2509775061200514,-1.5582715472457875,-108.90565710138956,-0.15201721872389262 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark11(-2.265143988919572,-0.14331381005934446,0.760151039919478,-1.1591269220898192E-69 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark11(-22.706497330452773,-1.5512798669842844,-47.1228278950967,-0.6255997074527901 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark11(-2.281964350760632,-0.25932086954519207,0.0,-51.92168885092307 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark11(-22.889227369725074,-1.558848714210383,-100.0,-7.140320208872158 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark11(-2.290631780756735,-1.5511563379278601,-1.5707963267948966,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark11(-22.93880871146705,-1.4202429056894454,-0.10044336794651046,-0.04760713432426217 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark11(-22.977066280361626,-1.568386971380334,0.0,0 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark11(-22.990287989028918,-0.7013246096096708,-91.70096319149775,-17.187563349886524 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark11(-22.993650764909006,-0.7059324757803591,-1.5707963267948966,3.469446951953614E-18 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark11(-23.027927369748735,-1.4509881066618082,-31.479762263039454,-1.0 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark11(-23.053436452194866,-1.2098362393260524,-61.79938701947553,0.7304715651046791 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark11(-23.05881847642894,-0.3704342254717905,-4.036106950128408,-28.20715611436285 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark11(-23.115616296694338,-0.0453914389404323,-0.3241225181268419,-1.0 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark11(-23.150814610216358,-0.025523744592718913,-96.20203096072856,0 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark11(-23.182592225402583,-0.673812429468072,-79.79151762174578,1.0 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark11(-23.19283990828599,-0.987169066524536,-1.5707963267948966,-0.04955406363412712 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark11(-23.224334296482702,-3.9798843388917334E-4,-39.12109871217976,-0.7476733165945335 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark11(-23.280775180352766,-1.2537444605917163,0.0,0.05748227420927077 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark11(23.29174214334178,-68.51670449052554,64.98824336323787,0 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark11(-23.292616003663323,-0.07472962561816002,-0.003521850881436153,0.9218682350813339 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark11(-23.295810982466424,-0.6288955802583924,-51.88720196396858,1.0 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark11(-23.40254539804846,-0.2280018654063405,-0.16110153191100682,5.551115123125783E-17 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark11(-2.3410600126681502,-1.5707963267948362,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark11(-23.42976520501302,-1.3376956291852318,-1.5707963267948966,1.00000023384993 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark11(-23.451173546378836,-0.6523785754968001,-100.0,1.0 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark11(-23.46184983250278,-1.3021118304474995,-0.3184446301968702,-100.0 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark11(-23.485534070938396,-0.8620275456309039,-2413.087293336564,0 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark11(-23.529066320396467,-0.7814982176615698,-74.53567541412608,0.5982488777741495 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark11(-23.569662340021782,-0.8153756592553822,-50.88759289961726,0.0 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark11(-23.60755264045788,-0.12249207034255266,-57.1170047169188,-0.04249789059389383 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark11(-23.634304526548288,-0.10983691468877432,0.10790919114406555,-1.000000000000007 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark11(-23.71361287006195,-0.5407330097285208,-87.7137169226104,41.28053244127565 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark11(-23.74550606296353,-1.0690525640756559,-34.07326378185055,-0.0013321951234523122 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark11(-23.788327748758803,-0.8425142689755503,-14.753271316511764,0.03794257827853188 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark11(-23.84919852921567,0.0,0,0 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark11(-23.96303611476489,-1.5707963267948961,-0.6683965069191018,-0.5174236671913817 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark11(-23.97839250201351,-1.2148397881698456,0.0,-2.9825911852153055 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark11(-24.035440508743932,-0.33989045081004976,-85.22606979744094,1.0 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark11(-2.4070457597369437,-0.7356708143253134,-28.525561828121404,1.0 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark11(-24.074759696596608,-1.1386604954052006,-9.503462303605076,36.70815501784236 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark11(-24.08404092347333,-0.6860590517931611,-54.40983354868063,0.20296065027179833 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark11(-24.105022601014284,-0.906085417890407,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark11(-241.45797100483088,-1.5707963267948948,-99.37606925185784,-2274.345444546903 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark11(-24.229507346632325,-0.09876298887622736,-53.33693491832666,-1.0 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark11(-24.259044695405702,-0.2786903481846932,-44.467609117962084,-5.418536503744946 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark11(-24.267342174850796,-0.05279183498408213,-1.5707963267948966,-10.454396400712682 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark11(-24.281392625664466,-1.5707963267948912,-85.57052649737531,-0.421072408273659 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark11(-2.429648015740426,-1.5707963267948912,-0.6368462112867057,-2.0966031683116057E-15 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark11(-24.306816402423948,-0.6464859967029764,-70.16156650234731,-73.65430926375518 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark11(-24.307354255085507,-1.5707963267948961,-1.570796326794935,-57.97447953568107 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark11(-24.373193196515892,-1.5707963267948948,-2.0083671740869473,0.9999999999999964 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark11(-24.40940765240027,-1.5707963267948948,-1.5707963267948966,-7.483889673389757 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark11(-24.643690416145162,-1.0515194581282046,-67.14950122283892,-26.120636006087395 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark11(-24.732076475273228,-0.2520216523041128,0.0,-1.0 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark11(-24.768274389389873,-0.7516620686630091,-16.16177124488054,-0.1784580837519245 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark11(-24.821218224300125,-7.105427357601002E-15,-1.5707963267949019,1.0 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark11(-24.907290185664515,-9.144513166077571E-6,-0.5607593927566632,0.14717162140824858 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark11(-2.4955844078093494,-1.5707963267948912,-71.81972400010461,11.451925178869232 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark11(-25.000122084962907,-1.034494481665202,-67.71750906696869,94.35050288036842 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark11(-25.14903694049653,-3.552713678800501E-15,-84.74894294355255,-1.0 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark11(-25.17445114761268,-0.9179005516628203,1.570796326794896,1.0321081342883882 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark11(-25.280977874848354,-0.40103896917410653,-1.5682388448229982,-34.36719604056204 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark11(-2.5287609563323246,-1.2026876360935412,-1.2149442434386657,1.0 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark11(-2.529306893318907,-0.02683961636675836,-6.123780064346387,-0.06255276186783108 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark11(-25.308596514115152,-1.1306119718801706,-64.38405187760416,1.0 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark11(-25.328146748090653,0.4712617971087425,1.58707364651105,0 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark11(-25.347837427067223,-1.460434765761326,-1.5707963267948966,89.51250098422437 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark11(-2.5416794584406124,-0.015462142987434563,-100.0,3.469446951953614E-18 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark11(-25.44881973085981,-1.2811714727573502,-17.587509061447832,-1.0 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark11(-25.463263583516394,-0.2957854845786914,0.0,0.39336771963314876 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark11(-25.47603517024508,-0.1546730190684924,-39.76337705670011,0.27392422130870386 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark11(-2.5480102542991783,-0.9249886939712402,-47.633530044282715,1.0 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark11(-25.53081728294551,-1.5676957990496485,-95.93880506821694,-0.9999999999999999 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark11(-2.558772293713178,-0.7950635518659793,-31.500029156087535,2038.8024371167764 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark11(-25.67862618669006,-0.15246970737071672,0.0,1.0 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark11(-25.71653641548261,-0.16021292230158726,-72.53428031704416,1.0 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark11(-25.75433030856233,-1.5707963267948948,-47.03942441573987,65.85634707776398 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark11(-25.930020820568288,-1.5347673581314352,-99.22970013018158,-0.9970838139212718 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark11(-25.961355323291162,-0.11329726522909378,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark11(-26.088906555287906,-0.013113208701289422,-45.06768273102369,-1.0 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark11(-26.336378994736563,-0.25570255196316694,-12.069634585747497,-68.21826920271482 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark11(-26.39253493377285,-0.5638541843960052,-34.098652858746064,-1.0 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark11(-26.44530664014934,-1.5707963267948948,-100.0,0.0 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark11(-2.646851324380215,-1.5707963267948912,-19.66771693211326,-1.0007258411053386 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark11(-26.666002988493666,-0.4071566577563303,-1.5707963267948966,-1.0000165986846203 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark11(-26.711358979500847,-0.4659253519435308,0.0,6.776263578034403E-21 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark11(-26.713136187462894,-0.6284453436660611,-33.0391892502567,-1.0 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark11(-26.71345643292034,0,0,0 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark11(-26.76035166486347,-1.5707963267948948,-61.172844397380295,3.6808919957024635 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark11(-26.784839486041374,-0.12741480011275752,-84.89309658226946,-100.0 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark11(-26.857585123727695,-0.8700933845392186,-0.12034429213558183,-1.0000000000000142 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark11(-27.121261823790636,-0.21388029139561518,-1.5707963267948966,-0.06196405642181485 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark11(-27.16767504997766,-0.6110792380580682,-29.924385759015216,-64.01258679063082 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark11(-2.7242587813845516,-0.7609638950552955,-23.324333019657047,-0.7965784741495554 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark11(-27.38819982666337,-1.5305577224529134,-68.2793915113252,-80.0891021772162 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark11(-27.407612313449064,-7.105427357601002E-15,1.5707963267948948,0.0 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark11(-27.497467485243703,-0.024790320089917835,0.0,100.0 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark11(-27.51499945448867,-0.29503964386605963,-30.84987572006814,2.0303534698525194E-115 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark11(-27.546830521249518,-1.4148304425566565,-37.897578847667184,-0.3621898596801293 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark11(-27.569463665070547,-0.4848010866895791,-26.624870293702827,1.0 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark11(-27.601310351029777,-1.5707963267948877,-0.3775519784017477,-1.0 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark11(-27.617427656514074,-1.4157566086535809,-5.68721383332187,-12.848184995680146 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark11(-27.618229257297216,-1.40426784090543,-48.655658721884876,89.33269631612004 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark11(-27.705687566057094,-0.5912085361632455,-27.0330755959219,-0.012951867558159864 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark11(-27.761841975516994,-0.9963140049732732,-0.4514570505874339,-100.0 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark11(-27.815994067688433,-0.03937735715643198,-55.10264550688491,-28.83447136089651 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark11(-27.90415036539591,-0.09750339966150161,-1.5707963267948966,1.0000019720020503 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark11(-27.94502257536039,-2.030179094460908E-17,-8.838386159079427,0.05466489507065726 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark11(-27.95400872041344,-0.8474044009308326,3.552713678800501E-15,0.2799539241417981 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark11(-27.977205829131986,-1.5705034514962863,-1.5707963267948966,-0.16895349967887463 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark11(-27.984915906362485,-1.354197930176796,-1.5707963267948966,0.9999999999999964 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark11(-27.994121476505327,-1.531312771560587,-71.04027774504048,-0.9647873416221424 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark11(-28.05287856582831,-0.11791341974192207,1.5707963267948912,-81.42189605880563 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark11(-28.15119933096571,-1.0339143478617945,-60.79834102632457,0.23535152267361115 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark11(-2.8155675848456188,-0.06447140796490361,-4.828938432848108,2.220446049250313E-16 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark11(-28.319759274585326,-1.047513310776547,-36.79631652478492,29.911433511571868 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark11(-28.342749229200756,-0.11817749794116494,-1.0330621726125127,25.37033622640284 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark11(-28.363115971130956,-1.5676922176829147,0.0,-57.07316019327534 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark11(-28.421653564097497,-1.5707963267948948,-11.548934511458015,13.898055674932053 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark11(-28.503624725371303,-1.5707963267948948,-48.77136447325686,99.62988732689249 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark11(-2.8574695911726167,-1.081152334099544,-66.02556296286281,-2133.5941053242295 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark11(-28.597572385307195,-0.5630303221973814,-42.5344079761111,4.104743917374652 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark11(-28.60836905296216,-1.2198580278263038,-57.97740808282435,50.29966844872225 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark11(-28.66720451885118,-0.1583303501001726,-45.195327150576816,-0.004174239457803458 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark11(-28.683007022073408,-0.007010229555255419,-54.990596061766055,-0.6989832180171774 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark11(-28.699356911551437,-1.5102605543626926,-3.764167577064594,-57.022207684448105 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark11(-28.71274024844819,-0.19006326168756152,-1.5707963267948957,-50.87810015293622 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark11(-28.720922092661105,-0.6529739734514352,-88.31489845699514,-0.0798921559010779 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark11(-28.82240856887939,-1.5707963267948948,-4.26991528159601,-0.1472379554614358 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark11(-28.856881776231873,-1.5707963267948948,-1.5707963267948966,-63.513535203399925 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark11(-28.859476843318056,-0.7365295493371846,0.5516661381415702,0.9999999999999982 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark11(-28.905740813162488,-1.4013037701034639,-8.25943783414671,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark11(-28.973362261800197,-1.5699414362595492,-10.536208424777152,1.0 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark11(-29.02686651603613,-1.5707963267948963,-1.5707963267948966,-0.7772853295390852 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark11(-2.9037241775532054,-1.5707963267948961,-59.12948924239882,0.9996315669736637 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark11(-29.123570312692028,-1.2925657185881552,-49.93295626821953,-74.2631381067409 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark11(-29.17669798144312,-4.440892098500626E-16,-40.04315536039314,-1.0 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark11(-29.265878712193267,-1.5252559557120904,-77.8768969820872,-2075.2246682816267 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark11(-29.278517791220693,-1.4787409422982023,-4.687071816928494,-26.85160975264857 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark11(-29.28567873338104,-0.4641587350520244,-45.94425771488939,13.178354998082199 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark11(-29.30266438661785,-0.0010418765538402362,-39.93422775259459,0.45198013104620227 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark11(-29.362876600462616,-0.3602884327789128,-44.085225230258665,-0.9999999999999996 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark11(-29.409551301428838,-1.3617006275338923,-15.65217980545227,0.0 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark11(-29.41772151180897,-1.5672816424005923E-15,-98.49989799951,-0.032289413911944426 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark11(-29.432263536846364,-0.17214015879627276,-1.5707963267948966,-2177.648520136179 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark11(-29.52038774931938,-0.37534356603069186,-114.97032329758444,-1.0 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark11(-29.581376130219514,-0.8347361929327448,14.4434455264661,-0.9976416523960879 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark11(-29.631737908956307,-1.5677664096789026,-1.1250253551872476,-0.7809220153943288 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark11(-29.69141453640934,-0.0074947813062188956,-76.49859860633933,-1.0 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark11(-2.9734571087754276,-0.5715166032991277,-30.273533526324403,-0.33957229957870927 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark11(-29.828069518207315,-1.435994846969452,-9.515856300221813,-22.89393534901984 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark11(-29.8310248976933,-0.3636303859624874,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark11(-29.833568764519335,-0.4115093548695441,0.0347871821868704,-0.9069683698403708 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark11(-29.84804994828356,-1.2978064102067914,-16.246942255022617,28.203583163562257 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark11(-29.884407875512142,-0.4785896314033649,-64.9754903691216,-1.0 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark11(-29.990312349860318,-0.3109895150772735,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark11(-30.002748954259772,-0.024980537020398538,-58.774229815237554,-1.0 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark11(-30.006701730876138,-1.5707963267948948,-72.3198689165104,16.974028707592236 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark11(-30.08011656304039,-1.4840919973567361,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark11(-3.0200464500393736,-0.504636354156278,-1.5707963267948952,0.3537414100284426 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark11(-3.0308399043783067,-0.8236654426403152,-87.93213409215728,-0.4340157035281269 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark11(-3.0368142921856687,-0.5904067420536263,-74.97036720583034,-5.852095443365248E-98 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark11(-30.398876014927897,-0.60252535288662,-0.8747514956240199,0.002377727830094045 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark11(-30.418340965119572,-0.12307673422031695,-72.4369608563355,0.8969757948642394 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark11(-30.419430461570798,-0.019047417556091194,-68.1275611485653,0.1158627594716779 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark11(-3.0459279731630766,-1.202160122012518,0.7835522106249279,0.021092976928625926 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark11(-30.582540785237992,-0.4533065275293137,-88.3029900493184,0.5801030273250493 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark11(-30.5867268416898,-1.5707963267948024,-49.84566116183515,0.058736463281133126 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark11(-3.0616799535767685,-1.5441368770152244,-114.0395245520488,0.8421301918990942 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark11(-30.749158201048047,-0.5696910248569456,-57.76148148049851,0 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark11(-30.776116213895307,-9.397897303992138E-4,0.0,-1.0000000000000009 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark11(-30.779331143734584,-0.43168630229689364,-1.5707963267948966,-77.14808483421558 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark11(-3.0901559655675466,14.431832788754114,-7.105427357601002E-15,0 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark11(-31.037642899165444,-1.5547109413653704,-62.68443273225384,-1.0 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark11(-31.096481216006936,-0.26399508131761046,-9.394676853120302,0.015406689359432929 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark11(-31.15747317859313,-1.2778432933558976,0.0,-1.0 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark11(-31.185664581251274,-0.8033677792491997,-68.20641495862796,-0.17786147787375872 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark11(-31.188499603355446,-1.570271286538261,0.0,1.0 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark11(-31.19677289600747,-1.5707963267948963,-1.5677234451396798,1.0 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark11(-31.305244592449345,-0.32711875010153685,-74.2285487701281,0.8680950404342804 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark11(-31.333756750911366,-0.5748833992825475,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark11(-31.378063058748484,-0.3644247232688598,1.5707963267948957,-0.8386204797295825 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark11(-31.404470798942985,-0.03643240607807145,-1.5707963267948966,1.0003952886973466 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark11(-3.1439996666413492,-0.22852334569494576,-38.750305473798555,-3.719557193786767E-5 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark11(-31.54586829454673,-1.5707963267948948,1.4385441985962955,0.9368174010875521 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark11(-31.578694072934024,-1.5597998204587984,0.0,0.5464984592790876 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark11(-31.58123926929397,-2.220446049250313E-16,2.439009130184951,100.0 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark11(-31.584170542385525,-1.3689655529301268,-1.5707963267948912,1.0 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark11(-31.597348309858276,-0.010578882750280233,-18.204491303670885,-1.0 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark11(-31.622995204303564,-0.7940912048128921,-46.16645208034405,1.0 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark11(-31.738708044872084,-0.244151175900643,-1.5707963267948912,-0.4874523901209171 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark11(-31.867286633862285,-0.01264149178680174,-64.95970793497874,0.0 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark11(-31.909958273568613,-0.5759757063572093,-1.5707963267948966,11.037762505832667 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark11(-31.92686920268497,-1.5707963267948957,-30.484253851871205,-0.4269978707571769 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark11(-32.01125665803223,-0.8254987479153977,-0.7355069946488499,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark11(-3.201423207702038,-0.3012449750409672,-26.45848523848378,39.346524492557876 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark11(-32.06179620058434,-0.6745892859335432,-4.755926342577813,-2.675596184279052 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark11(-32.104270207576164,-0.10415192723420796,0,0 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark11(-32.114075739752835,-0.33213790359937523,-1.5707963267948983,1.0 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark11(-32.21627078973462,-0.6729013123980474,-1.570796326794895,40.9044886840467 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark11(-3.229297038185578,-0.45611560981090804,0.9136807887777938,-0.05335487299210895 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark11(-32.29758375065933,-0.36452156712450623,-1.2379545603923174,19.335755643693346 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark11(-32.3523388431488,-1.3631284508767303,-100.0,0.06698866898700323 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark11(-32.417187112578176,-0.4940642557748903,0.0,-1.1181683940351197 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark11(-32.479034723897946,-0.06315244257471497,-67.16255182198785,-0.44445842883144576 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark11(-32.535802891114585,-1.492621604654019,-53.95378728187236,-0.0831736463764483 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark11(-32.54116628073969,-0.15109176227279986,0.0,2.1175823681357508E-22 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark11(-32.547137129134036,-1.1868148765063995,-43.77369543654204,0.8680676727227326 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark11(-3.2555415387367264,-0.03439596511456068,1.4617061830002527,75.76423221451721 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark11(-32.56274758835912,-0.0037977067263371966,2366.9565204901214,0 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark11(-32.586271453900224,-0.8959745585675696,-56.62309353976289,28.837304785824017 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark11(-32.719703313069125,-1.3196353285661135,-47.775122779633875,0.6980528782706608 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark11(-32.74374920314641,-1.1028298377089139,-46.749987883353675,61.71806203560492 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark11(-32.759095355330345,-1.2581313741231663,-38.85386918154239,-9.5564294367788 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark11(-32.80172487643944,-1.0379369222224994,-1.5707963267948983,-28.63863891370016 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark11(-33.01891452645009,-1.5194977216102448,-22.780367423072263,-2063.3412803865467 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark11(-33.09595511756819,-8.881784197001252E-16,-65.81440396507469,14.538909199221102 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark11(-3.31275539428178,-0.30055522257542017,-54.98174656036356,-25.133897753719047 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark11(-33.19473931809676,-1.5707963267948963,2354.286215561851,0 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark11(-33.22664884160604,-0.3715933149584354,0.0,0 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark11(-33.228417583232556,-0.6811020137126308,-4.436055905192685,-0.9093211633363601 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark11(-33.362894448039995,-0.10392640367686568,-88.13843802501826,-0.8682858152949424 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark11(-33.36576745462321,-0.6681885557759504,-1.5707963267948912,57.971022514941865 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark11(-33.432957280390134,-1.1486821842441635,-100.0,0.051003345039189685 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark11(-33.45060917488213,-0.0023947984806091806,-100.0,-0.06271099604132228 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark11(-33.631203307567176,-1.5707963267948948,-100.0,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark11(-33.637544399262644,-0.06977883559785973,0.0,0.0 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark11(-33.639848626112084,-1.5678379595754481,-40.171004251110716,65.43127288208608 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark11(-33.64046135425589,-1.223809535660535,-19.757148933862624,-84.17921156060027 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark11(-33.73432573624074,-1.362109790450068,-0.5682643639523176,1.0 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark11(-33.780434840876175,-1.5707963267948948,-12.665986362780004,0.9624366771411268 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark11(-33.839629430755075,-1.5707963267948948,-14.117908992284327,-0.021811404879857887 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark11(-33.92880591029131,-1.5707963267948841,-25.102738671338237,39.8584563916403 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark11(-3.395928245695212,-0.09725677789257518,-45.28439889900556,1.0 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark11(-33.96863906569128,14.429230658152633,0.0,0 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark11(-33.992492826212484,-1.2651840883949084,-18.76862861188451,0.06164905998898327 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark11(-34.011499198020246,-0.5278590463518524,-7.720141063694858,0.7266368634580254 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark11(-34.04957772477086,-2.220446049250313E-16,-42.21767757229233,0.002297258508971257 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark11(-34.06643114388471,-0.5938223194519529,0.8935854630429674,-0.646984951458478 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark11(-34.07313443460589,-0.34260356937898706,-52.06094510959187,0.56374239342661 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark11(-34.22492338961702,-1.5303016739294946,-35.955446365785264,1.0000000000000009 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark11(-34.270029630474426,-0.05370319395361989,-58.27077751650813,-83.75898214170665 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark11(-34.27049772029894,-0.526228222512606,-1.5707963267948961,-0.020312711176640377 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark11(-34.27508520307028,-0.7776851107137882,-37.37738884885292,58.69507254752335 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark11(-34.34153652915982,-1.563801383815712,0.0,1.0 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark11(-34.361260362965545,-1.5290048171408694,-1.5707963267948966,-6.5352521037073075 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark11(-34.455047937290516,-1.0629600762296751,0.0,-1.0 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark11(-34.51065213016806,-1.5678876992597435,0.0,0.007378613963078484 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark11(-34.510655827694976,-1.0612451256972344,-75.11279890559632,-37.075649689586506 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark11(-34.633894347659826,-1.0848142498111137,0.0,62.70640415890892 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark11(-34.653903400950654,-1.5707963267948963,-0.32471127549952084,15.242088257918738 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark11(-34.700543762125015,-1.2585998362543134,-78.73774045391973,-0.042232727080102395 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark11(-34.745205379633404,-0.6907702722026254,-35.371049490252936,-90.55961758373579 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark11(-34.75525330490255,-1.5705786208201653,0.0,-2076.7430081554753 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark11(-34.782421596118084,-0.1453374232906004,-99.46391799224298,0.4079218840399452 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark11(-34.871832647298476,-0.22057640170945625,-0.03534514879661632,-0.9999999999999959 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark11(-34.94119690151552,-1.480786148690133,-59.261948573171644,1.0000000000000002 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark11(-34.96210494362404,-1.5707963267948963,-69.14278401364928,0 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark11(-34.962855665146265,-1.2175229110544006,-32.34147597155677,0.0 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark11(-35.090081804355215,-1.4170439306292169,-0.5423520976774113,-9.86807568851169 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark11(-35.10309168296012,-1.3000499385459041,1.3998368705225845,0.9043885825953133 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark11(-35.1612099663594,-1.5707963267948912,-15.105589790408544,2256.8330508685835 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark11(-35.22795499948381,-0.3686795234766418,-1.5707963267948966,-15.74690877643231 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark11(-35.28637193613712,-0.8685359714770448,0.0,0.0 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark11(-35.411262768084086,-0.5065121892528182,1.0094209318918206,0.9999999999999998 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark11(-35.41761797935348,-0.8235132939526072,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark11(-35.432046707569626,-0.5003161166491701,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark11(-35.452589814025096,-0.44436771112441154,0.0,-0.8938688501991991 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark11(-35.49721975999971,-0.9337007648132474,-19.701270284654033,-0.7634807364224483 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark11(-355.17954164843997,-1.5136068799228743,-164.6951212366637,-0.7529828224463699 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark11(-35.630511079161074,-0.26696272178971775,-1.4329379024754823,-0.30752666842684395 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark11(-35.66645275298691,-1.5707963267948948,-29.9533946314812,0.05126921215088309 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark11(-35.69724196656733,-0.5820900774483414,-23.93310428331546,0.19980535745068728 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark11(-35.88167066857134,-0.15266398440150192,-64.74895199393664,96.39379093152678 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark11(-35.88384506913039,-1.1208385769814255,0.0,-1.0 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark11(-35.917159442736796,-0.05524589596084606,-11.191710534463846,-0.15445948671473975 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark11(-35.91809324122349,-0.9274203780622066,-1.7635554378696978,1.0 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark11(-3.598712509940661,-0.12024634660875805,14.432482042688399,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark11(-36.08060572585199,-0.22378116763293845,-1.5707963267948966,-0.9940966397725887 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark11(-36.125474986614584,-0.16341143760548515,-27.790167917564958,26.753300587690752 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark11(-36.136846444656946,-1.5707963267948957,-39.40663512992902,0.8938616854685354 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark11(-36.17093707204493,-0.2374852983548177,-41.82540834506777,0.018104099186849056 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark11(-36.17125470404824,-1.060558010673827,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark11(-36.25996970006449,-1.0994365995554642,-51.84349201328266,-30.721430835191214 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark11(-36.333771590587176,-1.7763568394002505E-15,39.91838504322264,0 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark11(-36.44599657504459,-3.469446951953614E-18,-37.80358837775918,8.470329472543003E-22 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark11(-3.645837587494734,-0.9920530369888121,-67.40595148801374,6.842277657836021E-49 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark11(-36.45914199262715,-1.2278418244889093,-100.0,0.6590039600012814 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark11(-36.55558805884177,-0.43542487179661193,0.05817936908002053,-0.026115772034277007 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark11(-36.65903256457282,-0.39441583541022596,-62.94847264606205,0 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark11(-36.70349187075388,-1.5707963267948963,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark11(-36.79601370325875,-0.40356966216910806,-1.5707963267948966,48.47558325956891 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark11(-36.797855122921206,-0.9392342464299679,-67.1422039172454,-84.1542173783099 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark11(-3.681448619798666,-1.121272755751093,-86.7167676960282,2141.28741303218 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark11(-36.8246309711468,-0.01653862423050531,0.0,0.0 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark11(-36.82474900461034,-1.5707963267948957,-67.05200628114966,-1.0 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark11(-36.92479689651136,-0.5061767430182302,-1.564744348008781,-0.7334148127038718 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark11(-37.07419623234984,-1.5707963267948948,-1.3238409185977855,-1.010229421047856 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark11(-37.113360115479054,-1.2988729102705503,-1.5707963267948966,-95.01607137368164 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark11(-37.12508001812113,-1.5693359360113404,-40.21516503082599,0.7345521211952252 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark11(-3.7189360218969654,-1.5707963267948948,-2.1238174452104914,0 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark11(-37.19157279445329,-0.04237074864249975,0.0,-0.5861693753832109 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark11(-37.22142630973792,-0.6986494090347536,-0.19193259946361574,-35.86629002822826 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark11(-37.281538165179384,-0.4236418839175453,-159.4751284769132,-0.7831663008923273 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark11(-37.337645458335196,-1.3082416962150312,-97.94220624983977,-32.022428680764826 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark11(-37.396736207381934,-0.7461803607179586,-91.88686942547636,0.9999999999999991 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark11(-37.41317666702401,-1.2368487886994848,-1.3621578401268486,1.0 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark11(-37.47136396899356,-1.5707963267948948,-21.916611623177918,-75.86627040510925 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark11(-37.51510476801834,-0.3824444905811488,-9.516392574817615,32.14911485040709 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark11(-37.517027351829675,-0.4488486546730317,0.0,-0.2809159103338422 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark11(-37.56957887101318,-0.6706368218511187,-73.54729923607424,38.034078162281745 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark11(-37.58875873263852,-0.3588991715346408,-44.259077255580074,100.0 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark11(-37.63902616242427,-0.994745080098614,6.444145719026577E-16,81.74826800259396 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark11(-37.7039521930212,-1.021594312192109,-97.89691740536364,0.5035216313757473 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark11(-37.733639339773674,-0.02495620214530958,-125.28971268017854,0.14662683383421893 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark11(-37.93094744804042,-1.3635698872710673,-105.58166639582628,18.94017781510722 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark11(-37.94097305815363,-1.5707963267948912,-0.015145042428812094,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark11(-38.00553092301401,-0.6531872468188153,-9.45312583973508,0.2892734383129447 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark11(-38.0133025019506,-1.2657690104488553,-75.27800485465572,-0.0323518624556616 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark11(-38.02663107296536,-0.007225245151904267,-28.511914735923753,-1.0 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark11(-38.051553402048185,-0.23241276591013996,-31.821899202312398,-1.0 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark11(-38.083824190626224,-1.5281320721862581,-64.83348454871148,-0.885409808924032 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark11(-38.11966396149731,-0.2933185350989063,-82.6604948715568,1.0 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark11(-38.12700122116867,-0.0550125329902057,-38.77002398227559,1.0 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark11(-38.14309411907507,-1.5707963267948957,-60.28602091052637,-68.89550544855867 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark11(-38.15693103843105,-0.5179922514352548,-4.212719170300877,0.9354536523385072 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark11(-38.27483999741814,-0.7767239499570715,0.0,0.0 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark11(-38.282051853411936,-0.6158988280444823,-17.040747214299273,-1.0 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark11(-3.834897108630615,-1.456103571480606,-1.481649207715558,-1.0 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark11(-38.43284998853005,-1.0700408899835303,-46.72830986000673,-1.0 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark11(-38.56028572001009,-0.7883420195739286,-95.51382155966805,-65.17146835304098 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark11(-3.856049373473139,-0.3060478021056946,-70.06108495935378,64.79225206925597 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark11(-38.728156264655176,-1.2684317380015482,-3.797751724451846,0.8042381376048321 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark11(-3.881199226148823,-1.0846198453394023,-1.0513845058574187,0 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark11(-38.88344723307968,-0.46432829690075805,-77.14365057924886,0.9999999999999999 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark11(-38.88417534636148,-1.5707963267948954,0.0,0.02097141275617559 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark11(-39.00813460971788,-0.8994162417418154,-78.44551898513329,87.90569855327752 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark11(-39.04553144303822,-0.41597251543648717,-72.37922313852255,90.40776681619022 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark11(-39.06614710280064,-0.862444828198426,-31.44520859353492,-0.9993570617912519 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark11(-39.107908497214936,-1.3549529877493405,0.7219232964493686,-1.0 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark11(-3.913217037923335,3.311431078080241,0.0,41.952416772508606 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark11(-39.17093210647182,-1.4919013535482355,-44.39828764194549,0.9717837181554501 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark11(-3.9210669317871316,-0.5072922596806562,-0.43550325528755707,1.0 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark11(-39.213178296059,-0.0038027187968360456,-67.11606008440762,-23.905701785394633 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark11(-39.23044718148532,-1.3877787807814457E-17,0.0,0 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark11(-3.9298431721417764,-0.006510897641351244,2.49112558459781,-1.004939041870723 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark11(-39.344081357719666,-0.020864619232169698,1.2192371040118566,-45.287067985880256 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark11(-39.39104095299582,-0.4992317425659065,1.5707963267948963,0.007046624236490483 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark11(-39.466226203939094,-0.31170238111239357,-54.22253500826375,-1.0 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark11(-39.500258052918,-1.5707963267948912,-45.869369344228296,-0.5137293770767135 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark11(-39.525303716291575,-1.250437880510662,0.0,-0.04237607990004788 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark11(-39.57895165836788,-1.5707963267948877,0.0,45.12427997529049 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark11(-39.685633750748835,-0.9272186499911452,-31.52010490536944,0.36822723959166126 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark11(-39.70067167893598,-0.6413772700954912,-100.0,-1.0 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark11(-39.700777915757705,-1.5707963267948957,-1.5707963267941665,86.19158426805177 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark11(-3.9749040775145392,-1.3841933157739097,0.0,1.0 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark11(-39.804154263534684,-0.4853166075458142,-42.21353012726104,1.0 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark11(-39.812818746112065,-1.5098796259421567,-74.77808511624397,0.37600730321476306 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark11(-39.835791754578565,-0.9062197527418293,-1.5707963267948963,72.06844886970956 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark11(-39.87942128198094,-0.10728279540073699,0.0,1.734723475976807E-18 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark11(-39.92781861237762,-1.5707963267948901,-0.13911826624217094,0.3831536719278179 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark11(-39.95849609223567,-1.2709019693338557,-31.71967768890174,-3.6559038469506504 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark11(-39.982676133282524,-1.490792766522803,-37.46192275783746,-0.05903654316248175 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark11(-39.98640700541967,-0.9122083848213229,-80.2319192929557,1.0 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark11(-40.018781344799926,74.56024320883014,88.52369435182467,0 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark11(-40.03522184436628,-0.10200666639587097,-92.48326258378859,0.44654278556701676 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark11(-40.08222701791837,-0.43718765754203126,-1.5707963267948966,0.004279964540051973 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark11(-40.09214832911337,-0.9665078335751787,-23.793054010267525,0.0 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark11(-40.15297643398124,-1.5707963267948948,-45.09653136403112,-46.67413305069112 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark11(-40.203021494845714,-0.4360355699553944,-47.828108904926594,-1.0 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark11(-40.20984945755488,-1.5707963267948735,-98.72838091159115,1.0 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark11(-40.254811185804826,-0.5946973445025525,-0.0015227407761918864,-1.0 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark11(-40.28101420741792,-1.5146897947087052,-0.17562045997174922,0.9989995080209616 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark11(-40.321386952436065,-1.5167693329844223,-88.47386109044179,73.22338334747062 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark11(-40.336681407891376,-1.3613070056054608,0.7054452001182624,-2.4829952761425146E-16 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark11(-40.40115322080671,-0.12935559226592788,0.0,-0.482655383197535 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark11(-4.043696867433056,-0.7850814654195526,-31.663701933176604,-12.46409075859657 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark11(-40.486505476441124,-0.9815455933294341,-21.381931207330666,-0.9874013353931061 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark11(-40.508544007530766,-1.5578804034393876,-25.37496904833499,0.5686370892967697 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark11(-40.60376856634324,-0.07463535788869508,-1.5707963267948966,42.38893781361259 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark11(-40.60795186970533,-1.4512865720795094,-24.850822512415576,62.72410385234676 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark11(-40.617757634581686,-0.1686978440588493,-1.5701481107086415,-1.0 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark11(-40.63426381955468,-0.2865760470171847,1.4688220857078154,-1.0 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark11(40.68120762706104,0,0,0 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark11(-40.68544998757983,-1.0694972073260651,-1.9282542691890967,-42.72293400278646 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark11(-40.74404013281486,-0.4609628247176964,-1.5707963267948966,67.60582076892311 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark11(-40.75975868738985,-1.341735841450213,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark11(-40.773693725108565,-0.17071715511678343,-1.5707963267948966,0.24279354845583612 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark11(-40.907582161477634,-1.5133053777970087,-1.5707963267948966,-0.29474607677197207 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark11(-41.0093931487485,-0.7954483725013675,-24.21573428703981,0.49977247993707263 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark11(-4.101257717857398,-1.2429840795244473,-87.632760312672,-0.887047398039372 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark11(-4.102139948004098,-1.1480420481913498,-54.96477231411809,0.9929846361978765 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark11(-41.15639413174615,-1.2895506784220063,-1.5220941674387434,36.422075691817604 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark11(-41.174556682672105,-1.4363701265235062E-15,0.0,0 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark11(-41.183630024938324,-0.17052012098808156,-23.820810656206614,1.0 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark11(-41.206353819048225,-1.5707963267948806,-11.434445456176718,0.012123154208099438 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark11(-4.1242180345426975,-1.0909067096903386,-1.5707963267948966,79.15711142964284 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark11(-41.2428425369932,-0.8031619069619164,0.665577178059347,-1.0 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark11(-41.27873563928208,-0.7015342695353112,-53.272278658363675,-1.0 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark11(-41.33200213110443,-0.7129063976652462,-53.2404469594779,5.421010862427522E-20 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark11(-41.372087318358616,-0.19847353788723898,-45.144602019809014,-0.4080310601748538 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark11(-4.139769883567567,-1.534975660856026,-0.48806823961366164,-1.0 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark11(-41.40420108537044,-0.583721728965291,-37.7992958944385,-14.096763791374034 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark11(-41.41350241929771,-1.5707963267948912,-91.9342168262111,1.0000000000000409 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark11(-41.47038963128105,6.958517506610559,-2.0756550294734143E-4,1.0 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark11(-41.50946092494346,-1.3512004959358372,1.066009489674008,-0.9003191557414377 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark11(-41.512324517033996,-0.32076683500929004,1.5707963267948961,-5.191163916448804 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark11(-41.598465762563684,-0.09034731508013172,-0.003951436912641821,0 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark11(-41.701881359089434,-1.190715146603321,-79.59419399390661,1.0 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark11(-41.755518981453314,-1.0550630084523513,-66.33615009434,-60.90905142793631 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark11(-41.861932337823056,-1.2240873493823674,-88.14055320511603,1.0000000000000018 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark11(-41.915749658387895,-1.5707963267948948,-167.5462316402531,-100.0 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark11(-41.91945479336301,-0.8355335702968778,0.0,-1.0 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark11(-41.93136622660713,-1.5707963267948963,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark11(-42.022677629631424,-1.553648808099851,0.0,-78.31426422921719 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark11(-42.027656812725,-0.7487646936989036,-21.670777706016736,0.9660599155625014 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark11(-42.14571371455828,-0.6981317007977318,-51.12382886109983,0.6172269958551289 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark11(-42.16623915330037,-1.5707963267948948,-87.2498888137228,-1.0 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark11(-42.20692326076282,-1.2336237993603263,-66.08207188584959,1.0000000000000036 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark11(-42.21831653417245,-0.8830291101479943,-1.5707963267948966,0.37362514280374426 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark11(-42.22236018461594,-1.3511391457559583,-66.10333951066016,-89.40970401283094 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark11(-42.23641180619995,-0.9269927987867334,-0.765766457255275,88.02299730863706 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark11(-42.253868362975695,-0.2568239904652509,-20.528355338703065,-0.3653170875434204 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark11(-42.32544221695518,-1.556437062471244,-6.028132224385767,0.8645929562225556 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark11(-42.43967318267747,-0.3733629823432673,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark11(-42.545586199861916,-0.06963512426473281,-100.0,-1.0 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark11(-42.5780903699688,-0.24054727888340194,-14.838183360061239,-0.0027943921331925747 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark11(-42.6610144002261,-1.4854120592294764,-14.757450313815372,1.0 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark11(-4.267963453552033,-1.1228298249901947,-93.32699731936246,-0.01987371065270009 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark11(-42.694401684557334,-1.5707963267948948,-1.5707963267948983,-18.97096327218712 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark11(-42.731304960558134,-0.46669520407859366,-191.68603160073047,-10.871240187043597 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark11(-42.739150365943246,-1.465816238004816,-32.971875658628804,-0.048678851666514034 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark11(-42.86452642339648,-1.5577378087472786,-59.26624094587608,1.0 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark11(-42.86484294431742,-0.1780126992601624,-100.0,-0.024003379058473745 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark11(-42.87108513542445,-1.4663076989044415,-42.98297457378161,0.9825777179737087 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark11(-42.949872390162426,-1.5707963267948957,-63.84215149005848,0 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark11(-42.99561345358803,-0.6935441832141742,1.0243677271993978,-0.019941885620177513 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark11(-43.043965948245166,-1.5075252693879952,-37.043801346271756,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark11(-43.181836168638924,-1.5514101774970854,-9.703228786426067,-1.0 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark11(-43.204975207624024,-1.4741526592006804,0.0,-0.9999999999999966 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark11(-43.211013956304875,-1.567393332472026,-86.83728268711491,-1.0 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark11(-43.233606668230024,-0.07790362070289772,-0.856681905292654,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark11(-43.31503473685464,-0.8314419462692253,-0.007905150221983407,0.9999999999999998 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark11(-43.34667948138092,-1.5271635956422198,0.0,1.0 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark11(-43.39521238933952,-0.14816657713992495,-1.5707963267948966,-0.3872683537617547 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark11(-43.40526728652384,-0.9951531767830564,-11.041629857942004,0.057097276254018614 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark11(-43.44143075249147,-0.6835984026434168,1.2003658801475137,66.919012120188 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark11(-43.72173567165116,-1.5707963267948508,1.3877834464879648,0.0 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark11(-43.77869826334531,-0.3625126030112186,0.0,-0.81655565330981 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark11(-43.8669655508956,-0.4556052702924917,-14.433357290032603,-78.15353612930707 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark11(-43.941015007221104,-0.4230731213209083,-18.531688216021642,-77.02491170092313 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark11(-44.025033783310214,-0.5682353648009233,-24.017971074662942,11.008678350131156 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark11(-44.03964719076251,-0.4456695779676958,-31.626714383501493,-1.0 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark11(-44.10280089429596,-0.0750486985775224,-37.83086522249964,1.0 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark11(-44.20175714716678,-0.42581520626805236,-35.73965965916599,3.469446951953614E-18 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark11(-4.421036492497723,-0.14971063510253146,0.024291087210587925,-25.534212862569692 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark11(-44.31998815333292,-1.5707963267948948,-61.166490973790914,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark11(-44.37785207708894,-1.5707963267948957,0.0,1.0 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark11(-44.40711700001902,-0.18707017536245554,0.0,-2135.868529003528 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark11(-4.4414035423686755,-0.18333086578286628,-55.65889118939215,1.0 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark11(-44.469884547581,-1.5244440749860466,-2.220446049250313E-16,4.910973176750424 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark11(-44.50199076956339,-0.8317623018207537,-73.54393508433381,-1.0 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark11(-44.53216936100199,-1.554032445539895,-72.91701251556695,-1.0000306566018924 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark11(-44.5781003009461,-1.1972256558653445,-4.176347849225447,-1.0 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark11(-44.57882242420761,-0.7890393733876326,-13.548775168686404,-1.0 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark11(-44.59391200382369,-1.5248265208833232,-23.639544777192626,0 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark11(-44.66517926003024,-1.2301390502069256,-29.760424341220588,0.7105369764434202 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark11(-44.67770404823767,-1.5707963267948961,0.0,2.1183333946819102E-16 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark11(-44.70810811432792,-0.36144628178068616,-67.33392853953154,34.15071615948594 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark11(-44.7215150231151,-1.3968045768470636,-4.778908558998784,1.0 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark11(-44.73377174549995,-1.5707963267948948,-1.5707963267948983,-68.60862619550116 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark11(-4.489793769909718,-1.5707843274097724,-13.061653924742302,0.1391646766763205 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark11(-44.90420144347594,-4.0686457743274077E-17,-9.498629452672073,-1.0 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark11(-44.97196351660856,-0.891071632661264,-1.5707963267948983,-21.63451316812676 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark11(-44.98880639552378,-0.044598853612513395,-97.05692321852754,-2.5277957623490253E-7 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark11(-45.170196907891714,-0.6381022354706444,-32.501197016576484,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark11(-45.19607112377316,-1.321544437426624,0.0,15.683555605259826 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark11(-45.21844022089193,-1.1675432322161265,0.10719774129719184,-36.6906938261705 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark11(-45.26319559365892,-0.9799053262643378,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark11(-4.528847204561927,-0.6837660519303301,-74.73421048468586,-1.0 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark11(-45.298451452024494,-0.02700245900373024,-63.24103871627456,-1.0 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark11(-45.34332635391965,-0.37824323215149175,-2.0711308649349363,91.52724989106261 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark11(-4.541227938327168,-1.5707963267948912,-2.0307502538875752,-30.632853602863037 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark11(-4.549285022099141,-0.46785627873833535,-74.69004627854969,1.0 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark11(-4.558860509910417,-0.3080690076384238,-1.5707963267948966,0.2292365067559532 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark11(-45.593122983915585,-1.4798909051266766,-0.07234600917824352,-0.9797851529266429 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark11(-4.567302957806504,-0.2776049586835234,-0.5502632156054098,0 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark11(45.67540683246182,0,0,0 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark11(-45.7076004881848,-0.17805245560486144,-18.5025261108795,-1.0 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark11(-45.710865171125846,-0.651400508073678,-34.6843027776775,-47.35171995754646 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark11(-45.72937695446038,-1.570796326794885,-1.3786688431370082,-85.88317312762095 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark11(-45.923761972012095,-0.5592030881484222,0.0,1.4981364335015035E-95 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark11(-45.93056766824909,-0.07908286804753396,-39.83982151461926,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark11(-45.94185547582399,-1.5525002810811843,-1.5707963267948957,-1.0 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark11(-46.058569692930156,-0.7395256621994172,-42.38391847529254,56.487823222868926 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark11(-46.124156730166874,-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark11(-46.17056496758158,-1.4706966378261708,-8.880935084734876,73.67265948693763 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark11(-46.17907206152702,-0.7041952892260158,-12.17765152997994,0.5434208758907858 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark11(-46.23326124980182,-0.07054469358863373,0.0,-0.06272820555374518 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark11(-46.251090084509386,-0.0011919969099665195,-80.00772220928877,-1.232595164407831E-32 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark11(-46.26506735580225,-1.375367149339,0.0,-0.9879291837705075 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark11(-46.281352160220464,-1.0614938453761562,1.192454137613879,0 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark11(-46.35988030264744,-1.0421539957778423,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark11(-46.38312900446935,-1.5707963267948948,-37.74479920374667,-175.71358376897302 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark11(-46.388607601987054,-0.08461466028684918,-17.047602958160603,-0.9999999999999929 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark11(-4.638941809709349,-0.8454682797579683,0.0,0 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark11(-46.394583657463386,-1.5707963267948912,-23.443994788851867,-1.0000021582196135 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark11(-46.43868519598856,-1.4121522033060323,-9.768010206488778,30.65087606029557 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark11(-46.450500899515134,-1.5483475171973473,1.5707963267948912,13.478893191555208 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark11(-46.4836151350898,-0.6420722978866681,-1.2632044381965812,73.18877649992876 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark11(-46.54728402809862,-0.22867347753987366,0,0 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark11(-46.55339350257599,-0.7082692702042814,0.0,0.04802678613363853 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark11(-46.56616190543961,-1.3641441232237828,-0.006027060645723344,-0.19102934831491325 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark11(-46.636008457609485,-0.23867570010683306,-1.5707963267948966,-0.4296705324447121 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark11(-46.70378664111576,-1.4470909905101896,-95.84367442887836,-0.27096948293809453 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark11(-46.726526616121824,-0.8084956595303652,-36.34555814106683,-96.78672303543819 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark11(-4.681727334002735,-0.00379128444377328,0.0,0 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark11(-46.83280057101001,-1.5707963267948948,-47.57818360476515,-0.37012505367673776 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark11(-46.8563738169495,-0.17601788734921273,0.0,1.0000266964482536 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark11(-46.87389092482031,-0.05556889991832037,-17.293041020654982,-1.0 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark11(-46.89885488824595,-0.3400256354894082,-1.5707963267948966,-0.6176158223127788 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark11(-4.69224930282941,-0.7988723070739738,-68.81049811118444,-1.0 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark11(-46.96065997570507,-0.16954137287746643,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark11(-4.705567635376252,-1.3770976610990344,-19.36118318491335,82.00052671095611 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark11(-47.065415189915335,-0.5654772206353753,-11.010479673034514,-72.22751914312484 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark11(-47.06595047569574,-0.6272320027879359,-9.928415232639372,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark11(-47.0701910084709,-0.9319854174971393,-1.5707963267948963,-1.0 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark11(-4.711936101553059,-0.6484248966015254,-39.28858077672431,-1.0 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark11(-4.712615360652503,-1.5707963267948912,-61.144966755544175,-0.029612380292016627 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark11(-47.28748074005833,-0.5105070396783109,-56.285402293051035,-1.0 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark11(-47.3035619130781,-1.538288738782132,-55.09841907321993,-29.57604928843689 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark11(-47.304086135482486,-0.09880736444452332,-57.512445066367775,1.0 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark11(-47.32320579635132,-0.8644706296059219,-5.866832684986491,0.9999999999999922 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark11(-47.326620000323416,-0.04038723949850248,1.2621031809120673,-1.0 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark11(-47.41731265244113,-1.4395530018221188,-85.16163087793569,-28.931807235618262 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark11(-47.452516253225085,-0.7573237126221367,-33.13921270082068,-1.0 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark11(-47.46618554021303,-0.19214498546821934,-20.761734958381695,0.9999999999999998 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark11(-47.47716802127111,-0.057510256018244776,0.0,-0.37625977355620144 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark11(-47.48497835691401,-0.35796631789986577,-83.53202616061174,0.35119144016248693 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark11(-47.527497225573065,-1.0762867011062514,-4.630949631241476,-52.33623919910983 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark11(-47.544949147258215,-1.562756489858947,-12.153116584385154,1.0019729201051228 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark11(-47.551300443301024,-0.16537249850728483,-70.12625948734713,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark11(-47.696770198525925,-1.5707963267948948,-41.078259968310206,0.44254929130993104 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark11(-47.723880651195955,-0.48191141499783846,-1.5707963267948966,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark11(-47.74705042991636,-0.4911332715076129,-10.172558502432224,49.47843426744408 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark11(-47.75660137401155,-1.5666263559738707,-38.793620564379204,-24.527030049954014 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark11(47.773867538846304,-67.5973047825478,49.64922242594824,0 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark11(-47.82918711334428,-1.1213560266564608,0.0,5.306491663311775 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark11(-47.96471460246158,-0.24698877877095793,-1.0143528722802242,1.0000000000000009 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark11(-48.0188473089563,-1.5707963267948912,-39.376364249647686,-0.8778975913804984 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark11(-48.09993264492534,-1.5707963267948912,-1.5707963267948983,0.8378237558209349 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark11(-4.818428715198077,-0.7618817018762605,0.0,-3.2891134599969085 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark11(-48.2016960247221,-0.5402768805333551,-90.37931140561982,-18.156805608014338 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark11(-48.247424281825396,-0.5159272973186828,-0.9220779359554044,1.0 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark11(-48.24787409249073,-0.09652369468797749,-1.3783685669977042,-1.0000000000000007 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark11(-48.33207006701378,-1.4028655239356738,-34.55467914791028,-1.0 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark11(-48.35684990871157,-1.5707963267948957,-57.55317815292129,-27.338543712545935 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark11(-48.41462588029589,-1.0656257844060555,-9.525787762985942,0.6582101210231638 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark11(-4.842433408315959,-1.2573884505910933,-1.5707963267948966,-13.438034028352655 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark11(-48.50935826912153,-1.366249000918243,-41.6062138051593,-1.0 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark11(-48.523472412785246,-0.6009397206533776,0.03162084090479951,-2093.137261476566 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark11(-48.5320531211867,-1.5190080712315204,-23.90976130065296,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark11(-48.532435487187286,-0.7919800691364474,-14.528040160846416,1.0 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark11(-48.59161588142421,-1.5382696303707832,-40.70486003005521,-0.019698485893116652 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark11(-48.600557699505806,-0.7089601119104785,-68.35096713731178,-0.9658561524901433 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark11(-4.872632481440352,-0.08936299829820868,-3.2374857401485144,1.0 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark11(-48.7495681779466,-0.753027459339828,-152.95938764392992,74.59265544665416 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark11(-48.811243934980034,-0.2614749843848797,0.0,0.6613624608159883 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark11(-48.89020607010461,-0.03755160920001632,-0.05998432082973071,9.45512423585626 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark11(-48.94336985706586,-0.9024148828885359,-57.05229070845643,1.0000000000000009 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark11(-48.94792621016658,-1.5707963267948948,0.0,-87.05527663018697 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark11(-48.9749660733,-1.386723351240697,1.0259216753011275,-1.0 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark11(-4.9182826927109975,-1.3754728211679024,8.492134740838014E-5,0.01453608752928539 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark11(-49.19959458968858,-0.3101320017472169,-94.33408510592399,70.44871507728189 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark11(-49.20207315470114,-1.1464798064600898,-77.95942301451386,-2.4074124304840448E-35 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark11(-49.363537184921285,-1.5707963267948912,-48.49020214280398,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark11(-49.39306609522148,-0.5194974091720108,-1.5707963267948966,0.007209228023279432 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark11(-49.46488598013809,-0.4085582282367744,-0.500903455543536,-79.89875393708354 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark11(-49.50288104720682,-0.004210073890226802,-45.27858424391575,-1.000000133988093 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark11(-49.68715569666975,-0.8721140499124271,-45.35198786533508,1.0 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark11(-49.84390803597125,-1.5707963267948912,-17.634443516571373,-67.9481965675541 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark11(-4.988986384310959,-0.036149158710548024,-0.46552805081197324,-100.0 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark11(-50.07935822855156,-0.609661504711402,-50.71832163853631,100.0 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark11(-50.12219183919237,-1.1648913073480411,-0.8318818118039939,-48.87110154335879 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark11(-50.16757581310194,-0.5763612638172577,-82.5023843665601,27.361365340474908 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark11(-50.18073476745213,-0.3939908742346181,1.5707963267948957,70.63431263611261 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark11(-50.257928290694885,-1.2912540747134358,-70.29473814331564,0.05152447617228717 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark11(-50.37335463091205,-2.7823355212435392E-15,-1.5707963267949054,-1.0 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark11(-50.42630409097402,-0.07826965480370665,-9.09356781755168,0.7099696753052882 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark11(-50.45188991209513,-1.3200389860480883,-69.91904672645558,1.0000000001036429 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark11(-5.053857855138211,-1.5707963267948877,0.0,1.000000022544115 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark11(-5.062106484200129,-1.5683652556099255,-95.71013248976992,1.000074798536676 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark11(-5.068614567831956,-0.4943990341543164,0.0,0 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark11(-50.70655573545141,-5.352555785709328E-15,0.0,33.21900690202938 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark11(-50.73308330873292,-0.9480401422963411,-37.0297741158133,0.3678175261630017 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark11(-50.74277000815793,-0.11298300481571699,-6.508851465398465,-0.04071525363429748 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark11(-5.076046598536171,-0.24998051022104784,-80.45015448639727,-1.0 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark11(-50.88716004556923,-0.8413708408033613,-88.5000533318805,46.031398444353385 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark11(-50.96913169562868,-0.11187413151283312,-13.085579993784677,71.24553297838298 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark11(-51.09572187986346,-1.1268317578843394,-9.634901908925038,59.16070875140884 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark11(-51.100272079911676,-1.152160270712236,-1.5707963267948966,0.35692424585628707 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark11(-51.14600749812625,-0.7206742190285644,-25.911678088589696,-0.8356207978137 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark11(-51.26228792385733,-1.5707963267948912,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark11(-51.26393605745903,-0.36507265565654057,-7.619472011866208,-0.2461908990260384 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark11(-51.28195061950891,-1.0551719274963358,0.6231912982669818,1.0 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark11(-51.4745180544312,-1.0133586191510962,-67.13621571135405,-1.0 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark11(-51.611013060431524,-0.15060221495066778,-39.92423956074409,-6.6703817281913555E-9 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark11(-51.63109170151636,-0.7307240758825534,-1.5707963267948966,0.23193259615018036 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark11(-51.75272819672094,-1.051218153218672,0.6641520080962515,-1958.1022979242173 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark11(-51.89559656908055,-1.4297802735706244,-64.24255126262764,-1947.188643440999 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark11(-51.89768759578477,-0.3254610069135182,0.6098366195746173,-46.23691491824764 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark11(-51.91749520773814,-0.8531606296629928,0.039471939742129966,1.0 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark11(-51.91881035228835,-1.2981877651066465,-9.730611600399698,-1.0000002836216806 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark11(-51.9711005765575,-23.373171578941637,0,0 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark11(-5.200790859311057,-0.040434581881769315,-1.5707963267948948,-55.747636908244516 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark11(-52.081929026380806,-1.5707963267948948,-0.3184249871062559,-26.128478855876395 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark11(-52.10915362440173,-0.04598381220999864,-27.9081855667548,1.238894514757316 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark11(-52.13319128718749,-0.0789385292078808,-0.9646483057135137,-1.0 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark11(-5.21513411490783,-0.570560710831986,-73.29381075082185,-83.20834431535414 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark11(-52.27114409914404,-1.539255351241934,-0.248406378966456,64.84494834018449 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark11(-52.39619984587059,-0.29720397542702415,-100.0,4.088878725650558 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark11(-52.41005102159253,-0.5275525962634485,-0.0037347210624860067,0 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark11(-52.410084063697326,-0.4154970687113782,-24.096311758188826,-1.0 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark11(-52.42413121727352,-1.5672541272952591,-34.015568365235524,1.0 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark11(-52.429643284099846,42.76459329911003,0,0 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark11(-52.45404190308757,-1.1535371153764633,-35.083860789806245,-0.014662717710062384 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark11(-52.550952911360106,-0.9869622969524372,-65.53560887966682,-1.000000000000043 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark11(-52.55212195724916,-1.5602164355736508,-44.21577745530875,0.32300709512605386 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark11(-52.63149589927972,-1.1762327604290432,-73.25864851893478,0 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark11(-52.715720489739866,-1.5707963267948912,-9.993736275977795,0.32639494675051617 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark11(-52.7778925356831,14.430325768058971,0.0,0.9999999999999999 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark11(-52.81006783740268,-0.7412500842499714,-83.02773705469028,0.028496371422797928 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark11(-52.88799563044268,-1.4269335048964327,-66.51019929361773,26.966266216000392 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark11(-52.9579416464536,-7.105427357601002E-15,-20.51712496297806,85.83623649599045 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark11(-52.987552404906026,-1.4204609919397395,-92.52933315168531,0.9999999999999993 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark11(-53.022254486222295,-0.11817117610629896,-89.61001284091319,50.89258661097736 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark11(-53.048493922021564,-0.8556311200748825,-72.92813576753778,-0.8247198404331044 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark11(-53.066191471126075,14.430459376674442,0.0,-100.0 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark11(-53.09967246597388,-0.28798160272279105,0.0,-18.707535136193812 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark11(-53.10140093838434,-1.2993994794194763,-1.5320868452951883,-2180.8712618340546 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark11(-53.147357395793875,-0.6858760419936292,-85.21079851139588,-0.06436614730588719 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark11(-53.17767609939344,-1.5707963267948912,-95.4713599348687,7.516005879191589E-17 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark11(-53.218108370655536,-1.4232078874345722,-7.00426396012746,0.9488914566224995 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark11(-53.2839542734049,-0.8105657293514383,-1.4135963300366343,47.207402425154896 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark11(-5.330358136123417,-1.5093605671789871,-67.29145226146206,68.24628245917927 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark11(-5.335247797207714,-1.4210854715202004E-14,-5.390205781169584,40.60086919097634 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark11(-53.370070192371266,-1.2167251870155398,-35.643557398644745,-1.0 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark11(-53.42377541393146,-0.03155759340244195,-57.87129046824323,1.0 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark11(-5.346821137979995,-0.9216869488038543,0.0,0.0 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark11(-53.50455698312468,-1.567877317521389,-44.200399886384155,-0.06260849218422307 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark11(-53.5111634955809,-4.662549726461657E-16,6.20565288635384E-17,1.0 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark11(-53.56775370373893,-0.7636024853780763,-1.0269125507248649,1.0 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark11(-53.60124453332676,-1.5707963267931315,0.1621151161973246,-0.7795858263465618 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark11(-53.640704185534375,-1.4456366099485758,-100.0,-0.6547671334653385 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark11(-53.7132455168658,-1.5707963267948237,-87.24629735243784,33.28975927615069 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark11(-53.81945008096189,-1.5569456756021798,-62.88599023627208,7.540380916780535 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark11(-53.82652909276644,-0.5657380622579896,0.0,0 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark11(-53.83202061501513,-0.13115263526622006,-73.56317511509161,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark11(-53.86341309937295,-0.6392371216874643,-86.49227322148714,-1.0000000662802342 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark11(-53.87624947278698,-0.6950376406822912,-95.3771732036824,-1.0 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark11(-53.88010702630936,-1.178987692915058,-2.891548139361902,0 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark11(-53.928853414203594,-1.5707963267948961,0.0,0 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark11(-54.00951948888932,-0.5614737348753026,-58.8027341787211,-0.3621547153307627 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark11(-54.01857860916931,-1.3057506098211873,-44.53611801991516,0.0 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark11(-54.02610042236767,-1.7763568394002505E-15,0.18411855467397248,-0.866321818417289 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark11(-54.12811360539508,-1.2414863105104872,-52.065423746684964,1.0 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark11(-5.428064246583065,-1.5222439965358903,-22.128590689682227,3.469446951953614E-18 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark11(-54.285813923585955,-1.2503887942146636,-84.30387546116772,100.0 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark11(-54.29285537740762,-0.8486104434171722,-73.75481271930636,-100.0 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark11(-54.30923831485955,-1.3409862992594386,-93.14698505454547,1.0 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark11(-54.36841253346112,-0.07371094899092068,-1.5707963267948966,4.276328253797107 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark11(-54.430821693320674,-0.5442485332999711,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark11(-54.445643294385626,-0.8268556722039319,-100.0,-48.37937076572675 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark11(-5.4503533204464105,-0.10713450919706292,-73.58368404018162,-1.0 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark11(-54.52990875961898,-1.3426112502962748,-4.303482973587441,-0.9341867287991825 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark11(-54.53878222021398,-1.4348235475734405,-70.22960640766297,53.40487671544901 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark11(-54.56840884646101,-1.5707963267948952,1.570796326794893,-57.494538746956046 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark11(-54.602897830602615,-1.5705787496997177,-45.64274507180026,-1.0 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark11(-54.60770530329082,-1.570796326794889,-24.688532701098914,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark11(-5.462400966115041,-0.37742244931559826,-64.6448036370207,-1.0 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark11(-54.656801083666025,-1.410131615078844,-1.5707963267948957,0.9999999999999996 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark11(-54.75552629934908,-0.17974129791794513,-37.62456383825281,0.7218421931424163 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark11(-54.75979489980367,-0.08002278152703204,-73.68458753712417,0.7399588925731524 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark11(-54.77552681458533,-0.024521680640246207,-54.63774787576596,-0.023040482236221682 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark11(-54.78121420304026,-1.568731589741553,1.563893862806459,-0.29001155359893205 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark11(-54.898598660090904,-0.5478644344949489,-0.5745671148366859,0.027773180643293927 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark11(-54.90537714158626,-1.7763568394002505E-15,0.0,-1.0 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark11(-54.91757945782237,-0.9236498961525506,-34.49757106436034,27.553501571571616 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark11(-5.49676489974852,-0.029419831425158357,-1.0786396658577928,13.995994145019568 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark11(-55.186329007037905,-1.5706956419982574,-25.28138564030994,-0.3952765951970886 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark11(-55.30748756276446,-2.220446049250313E-16,-6.315479422700955,-93.98900951434757 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark11(-55.507616158087835,-0.3661657771913127,-90.23575711207135,1.0 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark11(-55.59482405572179,-0.2157292711503302,-20.921334500002807,0.9999999999999991 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark11(-55.632892522797675,-0.3685982092652234,0.15912392385813284,1.0 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark11(-55.84536520148589,-1.4637672889049265,1.115357962000207,0.9945816602948397 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark11(-55.856540590141094,-0.4012090027873042,-26.01861698935481,-1.0000000000000004 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark11(-55.92520688491282,-1.5707963267948948,-31.774562550590257,6.208818107024399 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark11(-55.97007613682542,-1.4700098563851922,0.0,-0.016484179013502853 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark11(-56.032696162140375,-0.17980306991436312,-0.9851065670019272,0.0593846350550918 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark11(-56.16768927881871,-0.702023349489664,-85.26652449277147,-74.75368400147666 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark11(-56.21570598833071,-1.5707963267948664,-18.371497236059106,1.0 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark11(-56.28527026736325,-1.5707963267948912,0.35341159195595656,-1.0 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark11(-56.290961379846976,-0.019676193558387067,-7.309744702040897,-1.0 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark11(-5.6321845334518645,-1.5707963267948963,-66.14161110542254,0.06255365199079525 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark11(-56.35471338865119,-0.5728089365885816,-4.164390860448176,0 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark11(-56.432347063012436,-0.2528230417490354,-27.68148872271977,-0.9718814048350577 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark11(-56.48370507472997,-0.39649126571666893,0.0,0.0 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark11(-56.548977759157395,-0.5310780252039133,-23.160840531501265,-0.060638438455475396 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark11(-56.549799548576104,-1.4603891205094293,-70.30139149538051,0.9999999999999983 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark11(-56.575516178843216,-0.8246175228542907,-1.062062323908228,0.0 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark11(-56.61301716049056,-1.0822947393024913,-75.25896448229862,0.9797982742398276 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark11(-56.62099405483587,-0.25886835035822464,-37.78143107105649,0.06255796824407928 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark11(-56.63344271559906,-0.6156323884146511,0.5581987726776572,-16.222635914384412 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark11(-56.859600792579535,-0.04738678162472404,0.044965976614413455,0.00422204544041385 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark11(-56.986778447639566,-0.16663732914065577,-46.46351654880504,-85.41864234090859 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark11(-57.02277524144834,-0.9960038340136516,-3.1650710690237602,1.0 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark11(-5.702279971376271,-0.895246484642382,-8.247599165372762,-50.457821834102745 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark11(-57.140631295826154,-0.2616991271687853,-12.308661235249097,54.027773619762485 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark11(-57.1494415498671,-1.3769547285382377,-37.933525881056276,8.723767724675099 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark11(-57.29687240368837,-0.2608143841667552,-31.80802699182577,0 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark11(-57.34487665023455,-0.2916960453000388,-100.0,-0.44203315475106564 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark11(-5.738858876303791,-1.0373717981290869,-64.34542026574847,0.9999999999999964 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark11(-57.423410140964684,-0.2990055167406265,1.0084350302586118,-1.0 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark11(-57.44748599017668,-1.5098141495107553,-1.5707963267948983,-33.192903401920574 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark11(-57.448374424339555,-1.3662989369918723,-1.395836789760876,1.0000292634708663 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark11(-57.57707556075482,-0.06342305377867112,-39.259334758239056,0.2868815206316002 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark11(-57.58792382954602,-4.8798163278956935E-4,-31.846175360061768,-0.4534460759037461 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark11(-57.590481568141,-1.7763568394002505E-15,-27.68265056404359,33.67522574353081 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark11(57.62352039828821,0,0,0 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark11(-57.73749412325885,-1.3672621264562452,-8.881784197001252E-16,-0.01206447621632172 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark11(-57.79996869806381,-1.3356007580264,-23.962220589285714,-1.0 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark11(-57.88084233214809,-1.4731946136506746,-67.25223938771374,0.025263807396303878 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark11(-58.072008871861,-0.9622878475217738,-49.14417929047392,73.94289642357373 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark11(-58.216939193574184,-1.0668724193965438,-5.064988175847165,-1.0 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark11(-58.25661324863561,-0.9328381402549895,-56.47913865668343,0.04739338577852702 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark11(-58.29088992604794,-3.552713678800501E-15,-26.056537896234545,-29.456179081034932 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark11(-58.342686467716604,-0.38613889355887493,-100.0,2274.40012940799 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark11(-58.35444561364076,-1.5707963267948948,0.0,0 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark11(-58.365351678489766,-1.1335822633889323,-0.9174742638725218,0.9842835272442646 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark11(-58.400546451154185,-1.0797337917681693,-186.82874693040262,-25.666587654117553 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark11(-58.411353528082785,-0.9612101091780916,-11.756646578684862,1.0 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark11(-58.48908758464335,-1.0220572302294786,-49.51597802406673,1.0 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark11(-58.662718773766784,-1.1109900257734786,-63.94292935138898,-0.8602825501383755 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark11(-58.70668467862253,-0.20715660251715032,-0.052551443453753066,1.0 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark11(-58.72384664067154,-0.5544658195095126,0.0,0.6756454675340564 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark11(-58.72583851149798,-0.5386902038038633,-1.4762428583146625,1.0 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark11(-58.73545890660109,-1.570796326794893,1.1111387703149536,2.7237421106665067 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark11(-58.81536176275979,-1.545443333882534,-1.5707963267948966,83.95154383381518 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark11(-58.84785307581777,-0.8322345786617852,-38.83236235514859,0.010040018675904453 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark11(-58.952423259366604,-0.6799167389755438,-4.147739467939605,3.469446951953614E-18 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark11(-59.043765002088435,-1.1703294602480498,-97.67056887114438,1.0 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark11(-59.06577537804753,-3.552713678800501E-15,73.28183730248594,0 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark11(-59.13746885821012,-1.4961860309711974,-28.827399641600284,0.0 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark11(-59.208714114572885,-0.3328507981418955,-3.5648342839662757,-40.767974482192145 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark11(-59.2448946732721,-1.118357357278075,0.002253138175404956,-1.0 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark11(-5.926094888396937,-1.2541440762594367,-9.692767324167747,1.0 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark11(-59.29885019930845,-0.10124027215855724,0.9701532063625804,-1.0 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark11(-59.3062321653131,-0.42431011991188433,-15.495937832330936,1.0 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark11(-59.36899284247339,-0.004897777888249427,-4.554715480257932,0.45055537503995363 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark11(-59.372135851915615,-1.5337717598617233,-0.10093696844153849,1.0 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark11(-59.571307839119875,-1.3327246248304927,-17.008405515648736,2104.2527221630376 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark11(-59.60623001901264,-0.845270009590573,-0.976947765222576,2.1684043449710089E-19 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark11(-59.63887335966587,-0.9693670123544109,-14.600774632357538,-80.15115317768434 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark11(-5.965996138174492,-1.5534921418037575,1.4974528911574,-1.0 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark11(-59.71361646310149,-0.8614353394414802,-64.67888088095872,1.000000000000007 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark11(-59.75006776172882,-0.10555170954492654,13.261598736984515,0 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark11(-59.77149601870367,-0.32493279637359707,-0.814517293281483,-1.0 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark11(-5.9797464900212205,-1.1458964215949432,-0.452828846241621,0.007213885568459699 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark11(-59.80219341553184,-0.22790635444018706,1.5707963267948961,0.9999999999999996 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark11(-59.97369597941017,-0.2081692170253227,-72.26561859277531,-40.240275867363074 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark11(-60.02469470008134,-1.570796326794893,-0.5696686859057462,-1.0 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark11(-60.02724405000539,-0.5129606691972539,0.0,0.029204962915390518 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark11(-60.09516536225129,-0.5358226345625354,-67.3979317890726,-0.24320594180071411 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark11(-60.15029129512555,-0.5883750223294955,-21.398442570466898,-86.37899920467761 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark11(-60.162219903071495,-0.45308133238854964,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark11(-60.16455256515058,-1.510935996645449,-1.5707963267948966,-0.035660813292634486 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark11(-60.26107759496205,-0.9222128433471469,-30.935087815503138,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark11(-60.476512813953455,-1.5629163060840545,-18.900713959611604,0.6950445674186918 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark11(-60.49089033991821,-0.8673399978254352,-85.40930437236233,-1.0011596928798316 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark11(-60.51716308087529,-1.1618313555836266,-90.86766545227438,-1.0 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark11(-60.64123066980345,-0.9793363955714298,-2.551515058468894,0.18957956204051107 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark11(-60.66303986968179,-1.1774347852592355,-84.34131458732301,-0.01643803621142864 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark11(-60.667576556040565,-1.3539484954875718,14.44244652507389,-79.37369258123086 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark11(-60.67051930704763,-0.16423588753244278,-1.7733231584232634,0.047731502871876 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark11(-60.69929426496559,-1.5621521898352113,-31.475867224870825,0.0 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark11(-6.071252678688727,-1.023574400439145,-1.5707963267949,93.97739546302078 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark11(-6.088445892414841,-1.4680377259233386,0.0,-1.0691058840368783E-50 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark11(-61.01246815194867,-1.5384965558599983,0.19719524551773304,-1.0 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark11(-61.12169431623211,-0.1369875994767117,0.0,-7.111013097188959 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark11(-61.178012611404434,-1.2782901924482695,-18.77194591677541,-1.0 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark11(-6.120886086686006,-1.3375695072442613,-12.302624849130325,0.8744668633620912 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark11(-6.124570406158853,-1.360691760023334,0.0,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark11(-61.29380508866224,-0.6137513604512482,-3.3311483004286623E-16,2162.792187230139 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark11(-61.40540528559582,-0.0982327898260262,-51.384036510428956,1.0 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark11(-61.54489361274407,-1.5707963267948912,-45.332597143436274,-1.0 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark11(-61.568518504556934,-1.4981491567423006,0.0,-1.0 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark11(-61.572505217724306,-3.552713678800501E-15,-64.17811543868689,87.44556718941918 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark11(-61.58174257058154,-0.4927082378461378,-5.504742262723244,57.83861340467948 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark11(-61.65968677140161,-1.4372879696881284,-196.36820946613577,1.0000306951623328 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark11(-61.68641066154031,-1.0658944613712606,-87.04912619061577,-92.34385794653019 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark11(-61.70633617889177,-1.2898939611350917,-1.2228917141751274,-55.93079769977253 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark11(-61.875583522467345,-1.5317790620518643,-51.68636540696033,-0.6287119007889228 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark11(-61.8895273852999,-1.4254720429540921,-14.714798143168961,1.0 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark11(-61.984190273912674,-1.823025213841012E-15,-43.41116524594525,-98.40618041214346 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark11(-62.01621739686675,-0.13579507255135093,-73.32427731604137,-0.05082238563221536 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark11(-62.05365931422837,-0.6638877274059454,-86.88808512552875,-1.0 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark11(-62.15059086471175,-0.2820442514794746,0.5998131066338563,-82.48069561987971 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark11(-62.21984512973382,-0.8591598184826759,-47.52092983174752,-100.0 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark11(-62.29773224145999,-0.11146789438463922,-1.5707963267948966,-27.0515345428709 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark11(-62.304152254374756,-1.2860371997462892,-91.99315804561516,59.79423290807738 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark11(-62.39761459187527,-2.220446049250313E-16,-56.871243079903145,-56.27663206831562 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark11(-62.444995076133615,-1.5212413285134647,-9.142421367092101,0.9999999999999988 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark11(-62.46885562874627,-1.497671919826355,-42.97173725147677,1.0 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark11(-62.53170261713637,-0.22293538899907683,-100.0,-1.6704779438076223E-52 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark11(-62.55934038959434,-0.05225046084513212,-59.65899818764338,-2171.282862206601 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark11(-62.56273285854253,-1.1913443448149912,-1.5706974991104514,-4.0607069397050388E-115 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark11(-62.62167302505854,-0.5069083243937136,1.5608911645066714,0.6657285161941311 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark11(-62.67416481694833,-0.12559417862179445,-67.39710161073519,-0.8038206451145506 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark11(-62.68690083201808,-0.19374882667108628,-95.0172784816862,2145.967967915916 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark11(-62.69380692667044,-0.45660510478522776,-88.28930977884524,2179.596393333692 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark11(-62.70271312558119,-8.881784197001252E-16,-23.712088369410885,0.15470009529646056 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark11(-62.70629409905056,-0.32035855794894474,-33.46186581455375,-0.8081120278159086 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark11(-62.75463535228782,-1.5707963267948806,-42.62567639638295,-35.0108325628875 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark11(-62.781636058599474,-1.56172079324591,-24.816572064398116,0 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark11(-62.841141986759695,-1.5707963267948948,-61.3631744395406,-0.9435641222154165 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark11(-62.90906746144779,-0.029352569782657715,-3.3001517210540396,0.9999999999999996 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark11(-62.90957361448967,-0.27702375227048204,-38.653379864067496,-0.006435159155531611 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark11(-62.93886718587821,-1.2013169400847923,-100.0,-0.023877821935070404 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark11(-63.046889128521165,-0.46763462850417703,-82.90277210413586,-0.3536621463292905 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark11(-63.059412965402785,-0.9510915016480527,1.570796326794891,2066.2449697876664 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark11(-6.321858584569073,-0.2875340350753106,-0.2013699021296591,90.93493330855898 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark11(-63.2534014013508,-0.8144781056244704,-0.06683058418179433,-0.01792543617853764 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark11(-63.32791529049372,-0.7607546730873939,-38.84321014935949,1.0 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark11(-63.35735541731781,-0.9529241020144198,-0.0072757973282372435,-1680.9213861026785 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark11(-63.44378304053884,-0.4975641535348312,1.1996664490061175,2.0790819531289798E-112 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark11(-63.500506378536876,-0.0696877959277753,-174.44127516112061,0.999999999547774 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark11(-63.5117689358965,-1.5707963267948912,-2.95033005146405,1.0 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark11(-63.5268708632946,-1.514198933452741,-1.5707963267948966,0.8360336285941284 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark11(-63.53490405151927,-0.8059958644738623,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark11(-63.54995972925445,-1.4855654605787143,0.0,1.0 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark11(-63.55779292484145,-0.4255941227626374,-77.0408865152799,-43.5813539475656 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark11(-63.608801107511745,-1.0641203751395096,-1.5707963267948966,-0.8907320928024671 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark11(-63.61891538803122,-1.1134766194052936,-10.39380115888008,0.014769120220829823 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark11(-63.63148592458106,-0.27052499051474377,-10.102269107075877,0 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark11(-63.70432612088034,-1.5707963267948948,-49.936334577558824,0 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark11(-63.764536547657045,-1.5085614800209255,-39.090493165512555,22.089300705998056 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark11(-63.824277717421744,-1.069946515049947,-4.19401590015006,-0.010516188305471852 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark11(-63.83625309904018,-98.0344743330676,1.722072063540807,0 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark11(-63.84954084907072,-0.034129701463671586,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark11(-63.858649942696175,-0.326762465581317,-57.03683162778637,-5.421010862427522E-20 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark11(-63.8859548801191,-0.9824744049487995,-1.5707963267948966,-0.07369168356026257 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark11(-6.397376193648732,-1.0938625235999664,1.187479698858695,-1.0 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark11(-64.08244739962124,-2.220446049250313E-16,-65.41120968081671,0.5867917680936081 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark11(-6.425930149084479,-0.511800365545876,-80.51514397209134,-69.23521500978411 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark11(-64.28238333158967,-1.3320155734670678,-8.054560059251202,1.0 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark11(-64.32547719858067,-1.0315446992857185,-76.37565694698188,1.0 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark11(-64.41276320767238,-1.2823653193720048,0.0,7.998483386086903 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark11(-64.48446240069109,-0.29238312167441155,-45.089615439492256,0.004101856203137272 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark11(-64.53462791366962,-1.1445488682514195,-88.52474612231931,-32.34392858418143 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark11(-64.5925464697584,-0.052557096200583076,0.0,0.35389664979409297 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark11(-64.75524060537879,-0.4149047218915478,-52.76189615339335,-5.421010862427522E-20 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark11(-6.4841050117485395,-0.6513581655852593,-1.5707963267948966,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark11(-64.85048887048919,-1.5707963267948963,-0.009178902693907164,1.0 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark11(-64.92412171457653,-0.007993007886535423,0.0,0.00940569152679599 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark11(-6.493273696810917,-1.5707963267948841,-2.5574531787895296,-4.57253909813528 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark11(-64.94841780801993,-0.7710000833215881,-0.8579402765818027,-74.88604452019788 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark11(-64.95874940924911,-1.3592303523166613,-0.005148888817130878,-100.0 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark11(-65.04221013941215,-0.45425658383263245,0.12631537296081974,-0.5701887287986998 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark11(-6.504735741262792,-1.570796326794893,-7.915267012388207,0.0 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark11(-65.05073652372873,-0.9634957713207791,0.10714510824483336,9.470170084512262E-9 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark11(-65.08265490235318,-0.4812879803338177,-27.939489808878093,-16.945976467921923 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark11(-6.509479142083505,-0.7483443559127025,-45.322660359059455,-14.522667847402301 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark11(-65.15558181607435,14.43036649535047,0.0,0.9983593122123576 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark11(-65.2551400748815,-1.2664684142465812,-0.3340293438416825,-53.289311631391286 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark11(-65.28902867190698,-0.06913183193227852,-21.835435052389442,0 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark11(-65.35447094620653,-0.16547587876507314,-71.21717078941906,0.018485654105115712 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark11(-65.42324387561565,-1.4199752974237176,-7.914431318455101,-8.199648086313005 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark11(-65.42693681740518,-0.021289886891879994,-50.27704264050765,-0.9570560372402497 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark11(-65.44322294710943,-1.0994067017112918,-29.094858508267563,36.86758806610126 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark11(-65.50964335200737,-1.5707963267948948,-40.71061009944188,1.0 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark11(-6.551598540055894,-1.5707963267948948,-61.37205224594241,0 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark11(-65.57188264265827,-0.2765536404309241,-76.96225962335797,-79.86254620692526 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark11(-6.5640427330624265,-0.6147274863797834,0.2995045547138735,-1.0 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark11(-65.6995056001964,-0.984282558920583,1.5707963267945928,1.0 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark11(-65.69990531331385,-3.552713678800501E-15,-69.03656903900747,93.25750291861218 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark11(-65.72768991638895,-0.09180265873954896,-1.5707963267948966,-0.5892142597097206 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark11(-65.7988186108172,-1.5707963267948948,-1.5707963267948983,0.0 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark11(-65.89665882811379,-1.5443359295556236,-25.451096168241662,-8.856181272923502 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark11(-66.0489953407592,-1.0757281291227674,0.0,-59.04099451544946 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark11(-66.10902715169493,-1.1426451012652379,-72.3635386812312,1975.4732474672785 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark11(-66.14753852060387,-8.881784197001252E-16,-1.5707963267948974,1.9328808811973258E-15 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark11(-66.1478385481487,-0.3820680367970368,-0.18317547915715165,0 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark11(-6.618464091862961,-0.4011043836876821,-1.5707963267948983,1.0 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark11(-66.23287513732201,-0.35985331184861313,3.552713678800501E-15,-0.7663563712543856 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark11(-66.27959876596042,-0.4953661727377174,-75.13102840050239,75.35337469208159 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark11(-66.29444711123818,-1.2796013779370823,0.0,-0.05292833329263891 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark11(-66.37989135812649,-0.7091146952713312,-0.7815565085939606,-1.0 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark11(-66.3834068198495,-1.0389728732279933,-42.58915671316174,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark11(-66.59965310585812,-1.5590847640299281,-20.76111341703897,2260.6879282520554 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark11(-66.61953575829018,-1.0597021291096786,-4.669085420975648,-0.09900671986483806 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark11(-66.66119547252849,-1.0519211546124816,-37.25314807380611,0.004819683799607732 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark11(-66.81140817727785,-0.7891524485029908,-10.659054288149285,5.379333172739507 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark11(-66.85979279168153,-1.1920194688125854,94.54152282680434,0 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark11(-66.88304710670147,-0.6267786853444844,-1.5707963267948966,45.018007056125384 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark11(-6.68884520725758,-0.5172132257270547,-49.87330814962911,-10.618259713172643 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark11(-67.02647506935699,-0.5294973726903578,-72.71212812233951,17.36835189433014 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark11(-67.10929521203919,-0.5407125124170316,-45.05956380496966,0.6056202044380736 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark11(-67.15330799188274,-1.151572743928989,-67.45857227006871,-42.892745488638234 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark11(-67.21779458186474,-1.5707948266852387,-66.30259524520775,-0.07266609234515092 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark11(-67.22127526338016,-0.46338800005237424,-1.5707963267948963,54.82549714470056 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark11(-67.35618175844739,-0.24329164401090733,-60.20242327194592,-1.0 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark11(-67.51346098196983,-0.017133852618914425,-73.91336717133782,0.9999999999999982 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark11(-67.58269438143321,-1.556087221971572,-35.96171437495304,0.0 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark11(-67.68135512615727,-1.0274634784670642,-1.5707963267948983,-0.2302495139659868 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark11(-67.73735539503771,-1.3523322503300532,-1.578874734173946,-0.07083097814380555 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark11(-67.81852442795349,-0.10159235108116665,-21.37313306635329,-4.3368086899420177E-19 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark11(-67.86202545209441,-1.4753544226819049,-135.10237634507098,1.2108824421506341 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark11(-67.97098117755269,-1.1700415327966323,-96.59608646857428,0.7903895934658475 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark11(-68.04304614995965,-1.14732083003748,-36.94116847974842,1.000004226662695 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark11(-68.06730067393372,-0.6878115743095208,-82.26408021770273,-1.036790192301531 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark11(-68.08338091291841,-0.5086558041578656,0.0,0.2574529109357062 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark11(-68.08825386094915,-0.6867083152750837,-57.44751032711617,72.16947640351518 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark11(-68.14909656367638,-0.39236937567444685,-1.5707963267948966,69.5844630835059 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark11(-68.16598813137917,-1.5563858523663476,-0.3533153996867774,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark11(-68.27571335820339,-1.4451282154418252,-0.010397628479667936,23.4717474664299 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark11(-6.8380970574976025,-0.2026057960118708,0.0,-1.0 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark11(-6.84429328984133,-0.09685256959819638,-12.063079858699657,-1.0 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark11(-68.45699897625434,-1.5031351800331265,-48.24640091383042,1.0 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark11(-6.850644176951344,-7.03829159715702E-16,-53.1142753671547,0.3945887925942433 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark11(-68.58832608583943,-0.18852006961349732,0.0,1.0 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark11(-6.8656567975453955,-0.13378666320649857,52.49419525179667,0 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark11(-68.66230818783971,-5.551115123125783E-17,1.3681883249239424,26.911956276013292 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark11(-68.67420047823883,-1.2127305061316207,-1.1102230246251565E-16,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark11(-68.68937405101627,-1.0206093243534875,-1.287484527582143,69.53429212494524 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark11(-68.77045893469321,-1.5226404625645265,-1.5707963267948948,-1.0 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark11(-68.7888168843784,-26.487915142653335,0,0 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark11(-68.79776000570061,-1.5707963267948948,-20.620917060186684,-71.4301442060873 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark11(-68.82107142236968,-1.5707963267948957,-73.56169655621082,-25.53977266689347 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark11(-68.93632907800675,-0.8162648197850514,-100.0,1.0 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark11(-69.03834723920379,-1.38416888640506,-51.11289686232752,-60.09793755269927 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark11(-69.0596682622226,-0.9615202915795066,-43.16869365699601,1.0 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark11(-69.06855288711765,-0.7382855276494846,-1.5707963267948966,-45.99982961010593 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark11(-69.10205373442565,-1.0774774345646556,-99.20929280582072,87.24322053604575 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark11(-69.18474556399583,-7.105427357601002E-15,-11.868557203307091,-82.89869988083176 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark11(-69.32400252862838,-1.3459486443280133,0.0,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark11(-69.32904165362643,-0.4409385899237195,-0.37839006592160596,-0.8169965210181331 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark11(-69.40572937705322,-0.3536890898354372,-87.7453586225849,0.20835378261663784 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark11(-69.41229062080883,-0.8951437284126922,-11.011889479454751,1.0 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark11(-69.43263197036593,-1.1962086703619679,-97.26055727950917,4.2351647362715017E-22 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark11(-69.44262710858297,-0.1354184895041588,-84.56019919874178,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark11(-69.45786428830658,-0.13474414319270756,0.0,-43.99348911070281 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark11(-69.46067891061494,-0.09491608302256865,-63.43016025303092,0.2794550809153651 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark11(-69.54299262634427,-0.5732760639681393,-1.2363319437685902,0.9168529221641524 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark11(-69.55358575698276,-8.881784197001252E-16,99.15459327622779,0 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark11(-69.62550790644428,-0.17612779729032144,-22.934901163366025,49.87573009000499 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark11(-69.64551811740567,-0.6135932667664183,0.3790162039885937,0.0 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark11(-69.67506404196403,-0.3967157161188902,-28.075077322041608,1.0 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark11(-69.774564712199,-1.3950263756689765,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark11(-69.81230234001694,-1.5531131772325855,-63.39485616352972,1973.5715216785916 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark11(-69.81704731511194,-0.5938534183325421,-98.35119198799238,0.0 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark11(-69.99329338948945,-1.2594374624053524,-88.33836016129378,-47.33683436496536 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark11(-70.10255737008391,-1.5707963267948957,-0.19405523609029163,56.063077440361724 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark11(-70.15099561478775,-1.5707963267948903,0.0,-1.0000000000000036 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark11(-70.21875161853836,-2.7755575615628914E-14,-1.5707963267948966,0.7083484628000762 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark11(-70.23787766533958,-8.881784197001252E-16,-6.175007098073648,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark11(-70.2628908973036,-0.8400324925014415,-71.96346460953342,-5.009062605453044 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark11(-7.027131222840239,-0.6105737391959427,-1.5707963267948912,-0.44861145931462265 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark11(-70.27197718403806,-0.8671721244575863,-51.42739261382401,0.04487169074611043 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark11(-70.32847375766957,-0.1382982257383732,-32.84738709681246,0.0 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark11(-70.50072512684558,-1.5707963267948948,-59.45970814327176,1.0 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark11(-7.05364043332192,-0.2827962649431992,1.5707963267948968,0 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark11(-70.59094313682165,-0.23127556711806385,0.0,94.05243925736713 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark11(-70.59274908003523,-3.552713678800501E-15,-1.5707963267948966,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark11(-70.59337021162871,-0.8868072717714686,-4.38247514034142,0.0 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark11(-70.66086967193013,-1.3479212430417205,-73.67481403424307,47.45911638200468 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark11(-70.69373353893215,-0.8428401693524264,-58.5774079297099,-0.3734345954969871 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark11(-7.075070578327047,-0.3257172381156794,-0.5326648194697021,72.63458996764513 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark11(-7.086930681399301,-0.40757576508721893,0.0,82.08082124953565 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark11(-7.087909836318666,-1.5707963267948912,-67.41554918150628,0.003187452623742121 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark11(-70.8886134311846,-1.0316939821737772,-36.18873457874647,17.29704358864125 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark11(-70.8902182772173,-1.4197715812012237,6.542360521154053,-57.83748124123453 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark11(-70.91164213700816,-0.004713402786659939,-17.751126478868642,0.9773128219158871 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark11(-71.00508444934307,-1.5707963267948872,-0.3105812194004881,0.11718981512022712 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark11(-71.03651619409668,-1.570796326794582,1.5707963267948966,0 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark11(-71.09022171567528,-1.5298381920778448,-30.807136909834064,0.016698021405008173 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark11(-7.113434274842632,-0.12267263990074545,0.5457390210284956,-36.89422248933241 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark11(-71.13634204726068,-1.1948604806136005,-61.3786623864012,-1.0 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark11(-71.22291463579641,-0.017579258296548217,-37.406561766569766,0.03966451446624772 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark11(-71.23983010989552,-1.5707963267948963,-26.39024708183945,0.0 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark11(-71.29130355601211,-1.3873281963226551,-73.52755909873724,-0.9225425630721092 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark11(-7.145038471437428,-1.0436203236435115,-36.66927834602651,9.860761315262648E-32 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark11(-7.146846541713085,-0.8212447393339282,0.0,1.0 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark11(-71.55064417719252,-0.2564943849274093,-58.60737232462016,1.0 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark11(-7.1553750686353546,-1.0383164727151262,-69.95704972505817,17.25251639334316 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark11(-71.60203786666645,-1.4177596076094887,-42.851027606874034,-0.18017795994796115 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark11(-71.6406007229628,-0.26898088652152363,0.0,-13.186407228135666 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark11(-71.65338666267166,-0.060740099016220336,1.1718216116388127,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark11(-7.167580462419991,-1.2017232585940327,-21.255318825686,-11.502912054392851 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark11(-71.6767673247433,-0.541981399597387,-42.43498493216444,-0.2985193167748784 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark11(-71.67834214106213,-0.16833292276143674,-0.9478212365599085,-1.0 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark11(-7.173280884515581,-1.4363432136707153,-20.70882098827427,-1.000000000154787 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark11(-71.74691291901539,-1.5455232253612283,0.0,0.9769699612570544 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark11(-71.77531924899903,-1.537210900870005,0.0,1.0 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark11(-71.87467250222907,-0.0022889209474469515,-1.5707963267948966,0.014197863668470312 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark11(-71.95273136266898,-0.5709068458338213,-1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark11(-72.00302350481014,-0.47976435714850935,-1.5035813515496146,-0.5795389761885642 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark11(-72.05728658671636,-1.0505166453372035,-27.19683144896274,0.7117489544237887 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark11(-72.08620620447601,-1.3942189398593712,-28.25363982224892,-1.0000000000000009 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark11(-72.24281862300306,-1.5707963267948912,-24.083079271885666,5.895515729713779 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark11(-72.27285328823682,-1.3718114767203138,-3.439258506312129,0.7973861416383905 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark11(-72.3059194741793,-1.578128108022423E-15,-67.22999727682542,-1.0 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark11(-72.32115941601913,-1.5599438859875947,3.552713678800501E-15,1.0 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark11(-72.34181324361823,-0.622927961078092,0.0,0.6536998619148495 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark11(-72.38318882164499,-1.5635018342086964,-82.16096761085706,-1.0 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark11(-72.4222091520252,-1.0489226728706402,-13.840695317889349,-1.0 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark11(-72.55574143032929,-1.501008426684828,-43.515671325764814,1.0 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark11(-72.6899667110565,-0.9666032623428737,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark11(-72.73419049025215,-1.5707963267948961,-1.5707963267948966,-68.10718134793942 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark11(-72.87117113671601,-0.08494920604077816,-170.25740571294747,-0.9999999999995978 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark11(-72.87332442064854,-0.18371080668970508,-100.0,91.46470143133789 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark11(-72.90560500601273,-0.05099924243130083,-100.0,-1.0000000000000002 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark11(-7.296807924955331,-1.5707963267948957,0.0,2330.6373473264916 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark11(-73.057666658686,-0.2637531298038809,-94.58973391052155,-13.363910734332848 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark11(-73.09116419252274,-1.3425708027039112,-0.42944662487379515,1.0 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark11(-73.14740972702992,-1.5139949263136017,0.0,81.38743948109285 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark11(-73.24667393084964,-1.3909577512331028,-65.90212684310201,0.3621957964237331 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark11(-73.27291935056829,-0.20928552888593233,0.0,0.2900658084688327 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark11(-73.35148443727533,-1.7763568394002505E-15,-0.6837147493823061,1.0 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark11(-73.38373755269821,-8.881784197001252E-16,-65.32261038308508,6.130404863904687 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark11(-73.43981599611853,-4.440892098500626E-16,-85.75741736717617,-15.078808155538617 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark11(-73.52253410063351,-0.7092685479994068,-62.559172882641256,0.027914649878259225 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark11(-73.54148329533362,-0.31096080218672856,1.2796565782049885,-1.0 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark11(-73.64671230065464,-0.09374540763391619,-89.12912586433978,0.6216712381243414 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark11(-73.6588841310101,-1.449235134091681,-65.03162117574115,-1.0 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark11(-73.70441507165346,-0.14510802043470505,1.3058972195988616,-0.24583412171439 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark11(73.71585176954306,-12.927387238693086,46.19086596287886,0 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark11(-73.81711101305991,-1.5645401533574061,-1.5707963267948966,-0.39289902310586144 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark11(-73.85678695439262,-0.7820319241630463,-1.3742365710019975,-0.5370660136958799 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark11(-73.89233839944634,-1.2908456968779225,-52.44697293906135,39.26946433857012 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark11(-73.91837312883516,-0.3281527442736554,-66.72451492400049,0 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark11(-7.393865367182329,-0.03246337360192586,0.0,0 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark11(-73.94691651276628,-0.03114740396901916,-9.74944677218165,-0.1263837795126359 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark11(-7.401405973373883,-0.6835590276119774,-32.965174938595084,-29.825067993009128 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark11(-74.06519239668316,-0.2464660352083159,-36.81369593170588,-0.7862023375680783 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark11(-74.0913892507846,-0.8890807493294901,-37.67580333615224,26.50954668028666 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark11(-74.15787117577308,-0.6355819359415417,-9.957127926412397,-1.0 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark11(-74.19378899424258,-0.22238137550182002,1.3541106730904853,1.0 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark11(-74.24631047287488,-1.3199892792400465,-46.53537416939613,-0.6935469209373435 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark11(-74.24654684595326,-1.5707963267948948,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark11(-74.3320099450662,-0.5757832984752994,-5.13287702653642,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark11(-74.50200197947224,-1.2104457274756846,-130.37482211245185,-0.12195775132120401 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark11(-74.5885406040334,-1.3063812154734564,-45.06535322462628,1.0 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark11(-7.459958778450875,-1.4596487957095448,-67.50970423903655,52.157365959029505 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark11(-74.73740694534234,-4.439021370480551E-17,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark11(-74.77511703145093,-0.24785719250691973,1.382058660605431,-30.62554579719916 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark11(-74.83549612289598,-0.47232584765898944,0.0,0 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark11(-74.84219895914673,-5.918423793418418E-6,-57.18398639183915,0.9760599755681039 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark11(-7.488824746143799,-0.8717905847086203,-0.7790142456051838,-0.5851807481595239 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark11(-74.90933580038865,-0.6046273503028435,-45.56750452845163,-1.0 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark11(-74.93814669254904,-1.51549846152084,0.43151892406756465,0.4887395292927498 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark11(-74.97201497875133,-1.420600295302677,-84.442990322243,0.06028262712069246 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark11(-75.03276011938226,-0.8941764219165146,-71.9746306478836,0.02252806859411781 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark11(75.03926827867483,40.6462434226475,0,0 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark11(-75.07481921695216,-1.2516780160389374,-93.19069409398331,-1.0 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark11(-7.511838388380213,-1.570796326794894,-34.29510546490823,0.04885972003636768 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark11(-75.23146657369162,-1.516936557681834,-0.16711367717381498,0.005429536304896075 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark11(-75.25327999978678,-0.3372982616423436,-4.180322726811227,13.192604477564888 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark11(-75.30763458750553,-0.19906428088607764,-1.5707963267948994,-20.264569240237194 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark11(-75.39062966038104,-0.7701300839386289,-85.33103204102426,1.6940658945086007E-21 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark11(-75.5105458019403,-0.49763098580946163,-25.753781269960914,-1.0 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark11(-75.60452406884684,-1.117060540561992,-79.99480942942652,31.904179895901397 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark11(-75.63202742719176,-1.5609325276375108,1.5079499387532909,1.0 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark11(-75.64328621130207,-0.0826147437373379,-1.5707963267948948,-1.0 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark11(-75.66214273111885,-0.4652072564088301,-83.02530035769094,0.04795216217312179 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark11(-75.6653096985316,-0.30236173378790776,0.0,0.0 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark11(-75.67963335018753,-0.12368360290628336,-35.84798051285931,1.0 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark11(-75.69349169181902,-1.2833975379882738,0.0,87.83033790730448 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark11(-7.571590825998673,-1.5707963267948948,2.220446049250313E-16,0.03573171574967127 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark11(-75.74749712207907,-1.2840787561668872,-34.72243678314199,16.99607303999153 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark11(-75.74877634690867,-1.3843344491723322,-157.4620258374863,97.4833438318272 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark11(-75.77807960861315,-0.3048195140731511,-1.5707963267949054,89.55733261333802 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark11(-75.79589774836039,-1.5492316263676578,-34.049864122654455,-0.06306729310705375 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark11(-7.580292397871864,-0.47358974434276796,-100.0,0.9582150049065812 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark11(-75.82640222346437,-1.5707963267948963,0.0,20.914505765718804 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark11(-76.002491664368,-2.5907282659203625E-15,-90.87346201013763,0.0462448890688712 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark11(-76.0650328494521,-0.927573249334742,1.3324526849759195,-46.43207450111648 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark11(-76.24400494869035,-0.12475249018620346,0.0,0 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark11(-76.26590980513876,-1.552826199817997,0.0,0 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark11(-76.39385091184728,-1.3833347579931008,0.0,0.7388082118166155 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark11(-76.75260232126479,-0.0038500478737468285,-0.35758773701434077,-46.362823783421206 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark11(-76.7681110918486,-0.24720709155366904,0.7392310315319652,-32.693742842547266 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark11(-7.677305206296114,-1.1332652704842827,-15.148568836653851,-0.37589597474497394 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark11(-76.86436129563263,-0.3119142994890307,-29.831089262237114,-61.02154006580213 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark11(-76.92676852464602,-0.8842268990272544,-0.23858550211654514,-47.318333706971394 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark11(-77.03669370509418,-1.555291474495828,-72.30438089808551,-2.4308653429145085E-63 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark11(-77.05244697587781,-0.5460635141965888,-11.660498568946224,0.0 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark11(-77.1052577444224,-1.2315082868272649,-27.718693626708117,0.9310122846254918 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark11(-77.13167541814113,-1.5707963267948704,-1.5707963267949054,0.023407479899390293 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark11(-77.14189239780242,-1.4478251592421838,0.0,-0.14274634445379086 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark11(-77.21675129934737,-1.5707963267948948,-32.01955186135301,0.16785825168315838 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark11(-7.7237740419727094,-0.47766958835797474,-38.89487754717415,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark11(-77.30816005258622,-1.5536950806366483,-74.20183499014257,67.67563000955738 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark11(-77.36144937484674,-0.14258507334104156,1.3881738798269936,0.6833096007972816 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark11(-77.45002850957461,-1.5623536938847016,-3.552713678800501E-15,-65.9296589783122 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark11(-77.5715570637886,-0.7445005898124268,-0.3699212571545871,-1.0 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark11(-77.5952454287039,-1.5707963267948963,-44.453008319505805,0 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark11(-77.66960883341392,-1.4578607916122417,-1.5707963267948983,1.0 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark11(-77.93937916198952,-0.19127526142588813,-45.735306466548465,53.2154169861144 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark11(-77.95183224224058,-1.5069180932876676,0.0,1.0 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark11(-78.09088652387722,-0.1712228071369548,-1.5707963267948983,0.0921692650792526 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark11(-78.29161118788346,-1.515153184063563,-53.72992311011083,0.6905806993325823 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark11(-78.34512346357,-0.6977449637131302,-24.057251071285013,-0.20380026894614245 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark11(-78.38625488095155,-1.5707963267948912,-76.46956179936642,1.0 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark11(-78.42311432354246,-1.5702916295994953,-40.41675655754986,0.06255367488252046 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark11(-78.50757508866731,-1.0517018432160492,-45.12465549261435,0 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark11(-78.51619855442905,-1.5707963267948912,-15.532983705255656,0.8283681828159515 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark11(-78.51640609855484,-0.7830499846737304,-1.5707963267948966,51.97125084750589 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark11(-78.51795798450785,-0.8399709102721218,-20.589507576751338,-1.0 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark11(-78.55676216455035,-1.1917445455743905,0.0,-2.469745158940027 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark11(-78.56371857028375,-1.548446851601778,-62.193938277655704,72.35770891224217 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark11(-78.62095366293009,-0.3336640707550774,-7.198149071014053,1.7940222822507645E-5 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark11(-78.78495759807853,-0.344800538737875,-1.5707963267948983,1.0 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark11(-78.81088441251394,-0.0096558380009213,0.0,1.0 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark11(-78.8465108769877,-0.09011754546126194,-30.603636577719495,1.0 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark11(-78.99147071588204,-1.519063245644746,0.0,-1.0 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark11(-7.901942155129594,-1.324474148150042,-9.073723679095025,0.2283292469028606 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark11(-79.11393342442975,-0.7879218081865809,0.31874977758631573,1.0 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark11(-7.93198123566385,-0.12509614171367428,-9.75515810709629,0.6799026577496305 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark11(-79.33052824157174,-0.6637544410444695,-44.25137946091002,-64.50592177310948 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark11(-7.945006756109848,-0.8105231566994888,0,0 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark11(-79.53919660359146,-1.5707963267948912,-33.706407425206685,-4.376002850736043 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark11(-79.67091300703211,-0.3531715536569454,0.0,1.6940658945086007E-21 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark11(-79.76017385742874,-1.3596654140884166,0.6901580962579501,1.0 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark11(-79.7657875007917,-1.2159138258359439,-50.598759732641675,0.8625363142707769 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark11(-7.988120570591633,-0.6987129350156822,-64.90142168847264,13.647912964125325 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark11(-79.91167381132583,-1.4208742835075892,-0.08754204835498983,1.0 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark11(-7.992827437988003,-1.6788672517347014E-4,-37.97585191173103,1.0 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark11(-80.02443938543233,-1.157051649441092,-172.13790643296406,-1.0000004067782196 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark11(-80.03320273237975,-0.04003868646586217,-97.25192082593564,16.326589247557383 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark11(-80.08907369430543,-1.5573536102954912,-1.570796326794896,0.9691311626447601 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark11(-80.17544404318373,-1.3271665026165067,-87.69220418074109,69.27156373925703 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark11(-80.17770707528653,-0.8751520041218015,-72.70169464322942,67.01102478749331 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark11(-80.19325153034379,-1.01336809092823,-94.35276834556441,0.03817579156824183 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark11(-80.20179534083296,-2636.8578118057944,0,0 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark11(-80.27520045625222,-0.2939130385684122,0.0,-18.809449868035166 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark11(-80.32969433975066,-1.7763568394002505E-15,-11.197034414239072,-0.42629991096423314 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark11(-80.43689028438075,-0.10986267129222149,-42.99071542560631,0.0 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark11(-80.47518518429314,-0.542127476413752,0.0,0 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark11(-80.53022230636111,-1.5266417325990886,0.0,27.71431464297941 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark11(-80.56323150403881,-0.12502008650903426,-92.45295672445351,6.930152847499585 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark11(-80.61280920751337,-1.5645715008705585,-88.45418251394368,0.03353178962143542 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark11(-80.87763461346634,-0.38698093877923284,-14.604941647631179,16.594582039050593 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark11(-80.9007101318868,-1.4909282355894604,-91.5751291568636,-4.1359030627651384E-25 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark11(-80.92907890117823,-1.5707963267948912,-1.5707963267948948,4.571776116886145 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark11(-80.95678814708319,-1.5606721607921272,0.0,-1.000002359919038 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark11(-81.17928105574646,-1.1739539008705178,0.0,0.08224075240272555 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark11(-81.24200952041619,-0.6897557532574127,0.0,-1.0193735523919516 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark11(-81.32928471113075,-0.3097093093140701,-0.9633203224410726,-0.6644141260293102 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark11(-81.3604748101875,-1.446031894807474,-45.354543350642686,1.0 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark11(-81.36133670980314,-1.5707963267948961,0.0,1.0 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark11(-81.48064963689153,-0.15594805484145324,0.0,1.0 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark11(-81.56709260576511,-0.2990328905195754,-9.660493303376073,-100.0 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark11(-81.57284100653318,-1.5701333885258242,-44.12797419760173,-1.0408313476547797 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark11(-81.61458057379903,-7.105427357601002E-15,0.7982258194156486,-84.99502265428956 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark11(-81.69864808525745,-1.5707963267948961,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark11(-81.84698575391329,-8.881784197001252E-16,-0.48216804212886244,-34.20094870212991 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark11(-82.08980745569129,-1.5005930371769687,-65.77101526316329,-0.9556440649671435 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark11(-82.11025405782186,-0.45931911732022157,-1.5707963267948966,-0.013064162949391056 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark11(-82.1802696471235,-0.6908188802454447,-93.45331679654687,1.0 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark11(-82.34091404705222,-1.5396243546493533,-2.164016169260016,0.05064271253931078 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark11(-82.45218218887067,0.29608770879252944,-14.46635667449101,0 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark11(-82.53780860206982,-0.45011894490775894,-20.8302960747542,1.0 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark11(-82.54218824843655,-0.015446641665622318,-0.2888086592742175,0.3472776927337716 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark11(-82.56404334582734,-0.1376206726575692,-1.3877787807814457E-17,-0.15410385657174108 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark11(-8.259991798034363,-1.0580948828056687,-1.5707963267948963,-1.0 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark11(-82.69100150501222,-1.528951690324794,-121.36492749723827,29.806149820984984 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark11(-82.7149554167299,-1.0084273231815928,-88.88943280654956,18.853008534222546 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark11(-82.86015105757937,-1.466443680303567,-60.0130488713271,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark11(-82.93656884117837,-0.1316046974532279,-27.09900249985421,0.0 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark11(-82.93897527453329,-1.5673817174884528,-1.5707963267948983,-41.85899847403025 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark11(-82.94604883826662,-0.03002088190754329,-44.311629016206425,0.8307850469833767 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark11(-82.96432714277168,-0.01142187931514227,-49.99822882998362,-0.7704797928060954 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark11(-83.00309883661018,-0.46085250651901527,0.1394370254960099,40.984237222913556 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark11(-83.0054177287019,-1.5707963267948948,-69.48411342907704,-55.65423969459597 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark11(-83.05716223835466,-0.3145978099326275,0.0,-45.413539685372264 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark11(-83.08221559749225,-0.5143083796552687,-73.49238560778521,1.0 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark11(-83.1055686099168,-0.9503001650097511,-74.92249390864265,0.7005361003482993 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark11(-83.11768521774923,-1.4288000448356382,-3.721788836074001,3.469446951953614E-18 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark11(-83.19511341474825,-1.1406196313528199,-12.022273512909294,-1.0 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark11(-83.21205277943608,-0.04104564017134221,-1.5707963267948966,0.17073440606047363 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark11(-8.322129068754665,-1.5002101348171137,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark11(-83.26486862703389,-1.1046307757610785,-54.13242429296137,-5.635362925894614E-132 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark11(-83.48855619645839,-1.1970465897393108,-65.80548641281203,0.03183734225567578 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark11(-83.52821930036747,-0.5664622201411815,-82.89773715928222,1.0 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark11(-83.58618901471273,-0.6491053670713786,-45.1987390180866,-0.2783650979508684 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark11(-83.6752477736829,-0.05578824227261882,-63.41676511088179,1.0 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark11(-83.80513052106794,-1.4558620281812562,-1.5707963267948966,-1745.273481481187 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark11(-83.83235553837083,-0.10315733094774782,-14.41592183797778,-70.41738272055035 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark11(-8.391459899207211,-2.0661522314538674E-4,-100.0,-0.9275264170545122 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark11(-83.92425324391175,-1.5707963267948948,1.2291764047586975,-86.62566412050886 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark11(-83.97469406126086,-0.08158468961279208,-67.96870811224116,1.0 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark11(-84.09491425774466,-2.220446049250313E-16,-1.3170225123186134,0.9983210779558451 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark11(-84.18048297487324,-1.0804776629521644,0.0,-66.11222726975991 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark11(-84.19368045757525,-0.26545951397468404,0.33302094349074235,1.0 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark11(-8.420049882121418,-3.729353458203304E-4,-28.99455592889872,0.9999999999999998 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark11(-8.421877408071815,-0.29354443645526374,-30.607515166415666,0.6872947586805758 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark11(-84.24428451837973,-1.5707963267948912,-32.01514748975224,1.0 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark11(-84.36074152793972,-1.4985546673502887,-60.996004688682206,71.26964675324567 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark11(-84.54316426480241,-1.5707963267948948,-4.613952859145506,-1.0 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark11(-8.457833089446702,-0.3794799206175627,-1.5707963267948966,0.48163102005503067 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark11(-8.459554683398029,-1.5707963267717313,14.43615615469588,0.0 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark11(-84.72579876022125,-1.7763568394002505E-15,0.4088022666291973,1.0 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark11(-84.82458736632215,-1.4018138100587458,-1.5707963267948966,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark11(-84.90978040975409,-0.7448816415586459,-72.27122115771732,0.4909356295481817 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark11(-85.03849239722562,-0.6865624722478687,-67.56447127020985,-1.0 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark11(-85.05096756467037,-0.6937090564812148,0.7333276658569569,-0.021068035040100897 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark11(-85.08557330408787,-0.5972961508793537,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark11(-85.09029949090603,-0.45351349559556664,-38.713899203463264,-1.0 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark11(-85.12428571091466,-1.5707963267948912,-219.97754085582517,-1.0 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark11(-85.16957071289633,-1.5707963267948912,-0.29385491816107,1915.7706921162933 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark11(-85.21095477384753,-1.0542381318875726,-47.749666182811836,65.93177321641392 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark11(-85.35278159010021,-1.5707963267948963,-33.20076653857083,-57.95067995177525 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark11(-85.63716713066407,-1.0379788261069414,-1.5707963267949203,-2.3582190412948586E-14 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark11(-85.66023516707982,-0.04342105578375382,0.23006038234367998,0.010991621073982202 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark11(-8.569784666685763,-0.4634762612671202,-84.42422874830478,-1.0 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark11(-85.92377105893284,-0.004499713948086667,-1.1286820874613568,1.0 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark11(-85.93556088700805,-0.023168472813414484,-94.72386382637943,1.0 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark11(-85.96587790821602,-1.0265864672757608,-31.442030520038962,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark11(-86.05010155270719,-1.5707963267948948,-1.5707963267948957,1.0 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark11(-86.05894321696067,-0.1573519427214055,-0.4851867540224042,3.469446951953614E-18 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark11(-86.06340824159537,-1.5707963267948877,-39.181245910882396,-0.33591548084639555 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark11(-86.06786711232843,-1.025688593121727,0.0,-1.0 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark11(-86.12537499566662,-80.64070815469653,0,0 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark11(-86.19124979275647,-0.6089842395182075,-94.37252356742766,0.0 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark11(-86.25448422332926,-0.36522607286102016,-42.48127784427462,1.0 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark11(-86.2918213374711,-0.014277843597657833,-1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark11(-86.35220981300043,-1.5707963267948912,-75.73258153468944,1.0 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark11(-86.37645426976246,-0.7518758059813575,-0.2850322206729732,-63.07649980531636 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark11(-86.38111645540113,-1.5385989845987609,-56.01544286922988,2197.667877813151 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark11(-86.39382087500687,-0.27737104925515355,-88.47592875615159,-0.006444583156384007 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark11(-8.64069979965888,-1.5707963267948961,1.5707963267948963,-19.010734260630866 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark11(-86.49276629254584,-0.7788938422294562,-9.725979860306921,-1.0 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark11(-86.5583803422975,-0.6448796818300925,1.3770786947556994,1.0 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark11(-86.57508248338999,-1.5308121616156896,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark11(-86.64247478279455,-1.5707963267948948,-1.570796326794896,-0.04870120326781888 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark11(-86.7281645317121,-0.05533533332926338,0.0,-0.008340175577594387 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark11(-87.04242170935503,-1.5707963267948912,-94.34161453925424,-3.1670410616915063 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark11(-87.08958655988761,-1.552205228494074,-100.0,-1.0 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark11(-87.21919383648452,-0.9730521613171104,-88.15290119580668,1.0 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark11(-87.33995665642583,-1.5707963267948948,1.5707963267948912,43.897944264443026 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark11(-87.36398405214364,-0.8212244040284968,-75.4188717392723,-0.656263825068149 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark11(-87.39555748561531,-0.00609143922081824,-81.81030899884112,-1.0 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark11(-87.47894523127935,14.429321400612992,0.0,5.551115123125783E-17 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark11(-87.61811031636455,-1.2840790146090058,-34.90752473422978,-0.5807669206178732 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark11(-87.64474331622394,-1.5618566469623196,-58.83435299165982,-0.021082505373088978 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark11(-87.64954722066821,-1.3783222119692435,1.0500990597253397,-78.0367429351124 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark11(-87.71674699304126,-1.3634915164539203,-38.19272129895877,-1.0 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark11(-87.77836056771982,-1.5707963267948948,-32.295586867874405,-0.03189277881100905 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark11(-87.80803393282379,-0.2750779321710939,0.0,-1.0 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark11(-87.8200063014265,-0.00994317881676025,-59.436582879384865,51.45369681471294 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark11(-87.83855801197436,-0.6595126907398045,-0.011822592237918615,-65.83569316059676 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark11(-87.92057989290834,-1.5079131415034688,-73.00604553492475,-0.9999999999999991 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark11(-88.01228088732202,-1.4918864215822907,-2.030026914709074,0.05349087510388214 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark11(-8.803703569543284,-1.202518707558518,0.0,2.843155849929778 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark11(-88.05680345140301,-0.6423893801059117,-14.984022690217461,-87.58821162509088 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark11(-88.16057809348783,-0.06853514369860783,-41.56568526887033,1.0 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark11(-88.21231781946764,-3.552713678800501E-15,-20.026995443777825,18.73953776418164 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark11(-88.33118583811049,-0.11574953227655242,1.466738624780004,0.32214722712930666 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark11(-88.3862864700487,-0.853688548401962,-53.67864137712951,86.81566509845703 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark11(-88.50298686767013,-0.9925818222586145,-79.72966413856611,2.3045575924015953 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark11(-88.79179414960132,-0.023477665231155243,-45.34471086043426,0.9999999999999983 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark11(-8.885389190626825,-0.2723229229903766,0.5188590386845391,66.40813203424945 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark11(-88.86882270868065,-1.5707963267948948,-3.248410439444413,-26.52561827689067 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark11(-88.9180473125335,-0.14965061238728516,54.35877054658066,0 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark11(-89.01277302037127,-1.570796326794889,-14.73327194154021,-1.0 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark11(-89.18481136177323,-1.159300466471763,1.3123825783225598,-1.0 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark11(-89.18921024030972,-0.4602446929060502,-47.75697657697566,0 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark11(-89.4539012703037,-1.5450717727020593,-35.302692242412974,0.3371742229213088 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark11(-8.948540364623964,-0.3070840520086345,0.11966686389276593,0.47799705108552326 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark11(-89.5380721230793,-1.400876319186104,-3.552713678800501E-15,-0.6650674883240747 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark11(-89.5767056467861,-0.4966212451330989,-25.95802613810541,-0.9150370588256623 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark11(-89.63372017346359,-1.5108437189177872,1.0511695458154287,0 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark11(-8.968761910783241,-1.3164773792278668,-1.1102230246251565E-16,0.24920304103134533 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark11(-89.71167495953645,-1.2862184926544873,-27.343171589527863,71.13668291593478 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark11(-89.72832391728281,-1.5707963267948912,-45.24309836916689,-16.18828433016482 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark11(-89.741662196131,-1.5707963267948948,-6.809564461113425,-1.0 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark11(-89.78873981104037,-0.8409286411622965,-100.0,-1.0 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark11(-8.98072358833879,-0.7401690427707006,0.0,1.0 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark11(-89.82988798727075,-1.2811343212188602,-0.08816156149904453,0.06255396179054801 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark11(-89.86438750962236,-73.56058488949739,0,0 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark11(-89.90347663378687,-1.5707963267948912,-27.030329290634896,-89.3113820045991 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark11(-89.92663671447798,-0.7816518953120783,-26.256047297784548,-57.529591820642466 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark11(-90.09599080228658,-0.07046645176690447,-0.4542634372642783,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark11(-90.3790700246107,-0.5837246433645067,-36.66055603810139,-8.15772234861602 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark11(-90.56206606026667,-0.030276113361374438,-4.471470114960449,-1.0 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark11(-90.63212089795252,-0.27365882863313823,-0.26531802869048704,0.9786041365422486 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark11(-90.74666532937692,-0.13040909633576803,-30.657578287717513,-0.7933273541291389 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark11(-90.80949381669348,-1.124419614310213,-1.342968932866043,0.0 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark11(-90.86698399685785,-0.5804395682481548,-65.73578703031683,0.7806988220950264 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark11(-90.90582980388676,-1.5707963267948912,-36.379838901306826,1.0 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark11(-90.95317742267044,-1.1720098411489683,-31.074473504712444,1.0000002882489627 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark11(-9.108674429266571,-0.5243136989691619,0.013348961888434813,-1.0 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark11(-91.12985767134066,-0.5462711351886327,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark11(-9.119312329161184,-0.7606272621317829,-1.5707963267948966,-0.9644871250046066 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark11(-91.19719954926768,-0.045774351558441916,-0.5056930886896034,-0.1752172224233289 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark11(-91.21904155012668,-1.5707963267948948,-0.6621187781120206,30.766755799536725 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark11(-9.122663143650746,-1.1324554430456786,-94.85628072995655,51.21932815372264 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark11(-9.129441234919543,-0.21107763844149735,-1.5707963267948966,-0.15739204053220135 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark11(-91.30658984641634,-0.17711633560610782,-0.42321921873390145,-1.0000000000000036 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark11(-9.136078134602556,-0.3149068343382193,-95.40002444432538,58.002824645515375 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark11(-91.41384049690481,-1.1798639691096993,-30.378489462330286,0.10603417732738896 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark11(9.15687835079919,-36.00548932367516,74.01029483624322,0 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark11(-91.59872234001236,-1.5707963267948912,-45.072842686740664,-0.8478219163701666 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark11(-91.68266225566309,-0.81772312493881,-80.308817709195,-61.39383373798376 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark11(-91.73473140939855,-0.39092299078845927,-47.25054858373843,1.0 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark11(-91.81436517076206,-0.2058581315802696,-31.55356637272513,-0.98855819664811 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark11(-91.83392638120947,-4.440892098500626E-16,0.4921739811526288,0.04098409075696141 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark11(-91.84439134640326,-0.44670700653641604,-45.0455782683217,-1.0000003153624333 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark11(-92.0715426735421,-0.2341990438329241,0.0,0 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark11(-92.1180285652419,-0.4421244863829336,0.09550228599443766,-0.9653377142901034 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark11(-92.17444122719876,0,0,0 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark11(-92.19252873136088,-0.2575060135953342,-1.5707963267948966,-60.29104135805845 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark11(-92.45456115881014,-0.7729011353956565,-45.16656090183733,1.0405948680302983 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark11(-92.49164880087864,-0.8426276216685772,-44.501162718363155,0.3699129739806981 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark11(-92.54733580637406,-1.3375158622507837,1.1030422315460133,-0.040462813983672484 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark11(-92.57003052329394,-0.18174091800209446,0.0,0.0026476662421583974 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark11(-92.64660162035803,-0.20560399958568365,0.0,0 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark11(-92.65815180779245,-1.5707963267948948,-92.71719659968605,1.504632769052528E-36 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark11(-92.72039805194774,-0.03993051563772099,-74.52967664228478,-0.831291133446349 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark11(-92.73812954732415,-0.7119347882349095,1.287624404949946,-74.56126927631962 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark11(-92.7663699451938,-0.355477925032682,-5.0128948930598884,-1.0 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark11(-92.7730366712623,-0.7042050993403712,-42.103082293011724,-0.5245654634011516 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark11(-9.278005884441104,-0.27818761915556034,-9.699227000713291,0.5554664310481359 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark11(-92.910654428922,-1.074123031857738,-43.76610449223175,29.03185624794689 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark11(-9.292838754605052,-1.2533100427129635,1.5707963267948946,-1.0 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark11(-93.01545025394084,-0.16697690796137205,-99.75962976593202,0.7299479355033778 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark11(-93.04964535039574,-0.8996198875754975,-96.78421407431634,-0.5605865919267232 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark11(-93.07539561594507,-0.007263450411597733,-38.82700370963161,36.40572753826575 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark11(-9.311394423833903,-1.1736647206966138,-34.49762410289058,1.0 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark11(-93.15996208493127,-0.8777697719965922,-70.31488869630806,12.128461400027334 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark11(-93.23320556391602,-1.5707963267948961,-79.76136786382696,0 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark11(-93.23942583099969,-0.3217513424361639,0.0,1.0 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark11(-9.326303890237195,-3.552713678800501E-15,-62.94965061810178,-0.42152850506093453 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark11(-93.27637483809724,-1.1445678079907253,-32.67625141626007,0.5016187337992177 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark11(-93.29253247110505,-4.440892098500626E-16,-1.5707963267948966,43.73307984765225 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark11(-93.35229227753064,-1.5707963267948912,0.6565095042654937,1.0 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark11(-93.40214258198391,-0.9866394058487398,-44.53129583574087,-0.9999999999999996 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark11(-93.40696551071952,-0.15941097105498964,-0.04601459293671255,31.530351693087464 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark11(-93.5419100401906,-1.419426498088228,-0.13666026049348404,0.9658239969424249 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark11(-9.366900930099241,-0.21626137681290208,-56.17793026405499,1.0 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark11(-93.79873540524135,-1.5707963267948948,-17.556390050528712,49.21968646932103 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark11(-93.92594537657428,-0.3466903554247929,0.16045818247162225,-49.38875678846952 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark11(-93.94220002712498,-0.09287155772771083,-100.0,-1.0 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark11(-94.00723228529802,-0.0016255719277004426,-8.521631788369472,0.318503695538114 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark11(-94.13545468886461,-0.21104852750987096,-0.06443022807468365,-40.64730504216381 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark11(-94.35184212314347,-0.8173039924701624,-81.71697192248162,-1.0 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark11(-94.55374336720857,-0.45555466199219025,-10.767893008518138,-1.0 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark11(-9.455711727948414,-1.5707963267948948,-0.6534948207331155,0.038356148544006874 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark11(-94.68904028199098,-0.4068803160717016,0.0,1.0 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark11(-9.469787252499316,-1.5120776021918618,-77.61967708897272,1.0 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark11(-94.70311570519836,-0.7975180113971678,-0.01148826238222396,-1.0 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark11(-94.79548701108916,-1.5219380291376439,-82.53889537112823,1.0 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark11(-94.79972536981545,-0.1551695131047716,-66.17275677808435,0.3917546617832479 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark11(-94.98408048098462,-0.3089240551077521,0.0,1.0000000036488712 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark11(-95.05619098595007,-5.706981899264419E-17,-46.21260313726796,-1.0 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark11(-9.506108929471054,-0.3442253007094106,0.0,80.7535319818784 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark11(-9.511438570769128,-1.5707963267948202,-48.82940111417555,1.0 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark11(-95.17245022745008,0.3350098158634339,0.0,1.0 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark11(-95.17457439755225,-1.5707963267948948,-14.42932467814665,1.0 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark11(-95.36534946329125,-1.0230613348353064,-1.5707963267949019,1.0 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark11(-95.42921898431499,-1.5199292988099002,-95.36354562579625,-0.854847624476225 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark11(-95.5149819284562,-1.0341967729661121,-58.27235746904367,-1.0000000000000036 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark11(-95.58984948297504,-1.570796326794845,-49.183639239604425,-11.604309251164452 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark11(-95.62780653714185,-2613.555609903457,0,0 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark11(-95.63071395701245,-0.8837281916274268,-7.819513769520411,69.63378745250951 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark11(-9.569814962769044,-0.44439517213422675,-10.175932161965179,-2320.706038570966 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark11(-95.77034142122493,-1.5707963267948948,0.5765835078225068,46.36284920185136 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark11(-95.90755442197035,-1.3542556265622994,-0.08012683313584035,77.33304314486952 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark11(-95.91871987259653,-1.3615380487422672,-1.5707963267948966,-87.98658419829202 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark11(-95.93248693429716,-1.3675549317917728,-87.4737638755413,-2398.1036978074526 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark11(-9.593249268013967,-1.1206351218849693,-5.167962741368058,0.9999999999999964 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark11(-95.98312099912496,-1.5707963267948806,-31.659564242920638,1.0 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark11(-96.00729483097086,-1.5707963267948963,-20.857502528067684,0.9100553989905427 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark11(-96.02057035953028,-0.5229611964295331,-22.836343164141937,-25.66656952984055 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark11(-96.15978982292745,-0.7999894299327082,-0.12014269291457147,2.631571143845605 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark11(-9.625539150055392,-1.4205260817335883,-4.288297947186457,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark11(-96.35698940131786,-0.6286012295305167,0.0,-0.37786937964206935 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark11(-96.45794767928919,-0.001959645310477716,0.0,-11.00549799895785 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark11(-96.51002072667548,-1.0099033280147625,-1.854234696659969E-18,0.2342309454733766 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark11(-96.54620678719998,-1.5707963267947846,-87.89109914922088,-56.27247346178012 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark11(-9.658600705901936,-0.33355668577236197,-32.709037837391094,0.9870114145079211 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark11(-9.658979696975376,-0.4128453133312581,-32.85691937285513,-59.1499749991521 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark11(-96.61153410984573,-0.9795525936807253,-74.69191806928731,-1.00000012653096 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark11(-96.65394238157273,-2.1674296525589475E-16,-6.738810726447483,-2164.056566004342 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark11(-96.69312588875894,-0.7441629485018098,0.2354294200504796,-9.860761315262648E-32 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark11(-96.6992900741413,-1.071475384306768,-68.93781760525555,1.1091042744903348 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark11(-96.7271072943175,-0.9138779229093026,1.3698969310246736,0.0 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark11(-96.78803351568934,-0.28805372786338523,-47.2537135465819,1.0 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark11(-9.683679489665044,-1.300389664328634,-102.02148262599643,-0.010547709312661798 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark11(-96.86242196022161,-0.7692533342484364,0.0,-0.9641957241000902 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark11(-96.8811292077214,90.08727375079545,-37.00615599765078,0 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark11(-96.95391079958921,-1.1966233226334175,-83.37655846444694,-1.0 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark11(-96.98624610245037,-1.4195924358035812,1.0714241606999029,-7.87684226029209E-9 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark11(-97.1689351509151,-0.38477614077196387,-17.548254300987153,-0.027928102881959495 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark11(-97.18272450818509,-4.440892098500626E-16,-38.82745840501681,1.0 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark11(-97.18710382370531,-1.4677891990251966,-34.728610657745534,1.0 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark11(-97.23138450379516,-1.5707963267946496,-75.5759329599318,0 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark11(-9.744683545020802,-0.24093798463750105,-78.06307005571759,2271.7273423286124 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark11(-97.49826329998872,-95.73524143914828,0,0 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark11(-9.751441889962626,-0.3392799558377325,0.0,0.18946356027929712 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark11(-97.60574909922886,-1.5696557462095229,-1.5707963267948966,18.978129806028242 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark11(-97.69693693984696,-1.0160138349853978,-1.5707963267948966,3.0382015785213477E-5 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark11(-97.72161920674803,-1.5707963267948943,-80.57421245673942,-1.003409447794903 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark11(-97.83502941855275,-0.007068148394883768,2.783149993330939E-4,0.06292500783618801 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark11(-97.85353225029485,-0.2931377076480643,0.13024490954205103,-1.0 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark11(-97.88371013968732,-0.20672752026987018,-24.507128289513005,-1.0 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark11(-97.90403198206582,-0.7988578717309074,-45.38038225265818,0.0285190920549537 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark11(-97.92517031664312,-1.570796326794891,-1.5707963267948966,7.944283028846604E-16 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark11(-9.797925842928445,-1.5707963267948912,-56.08013523207154,-55.310083389561 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark11(-98.16006850682535,-1.0202067437112246,-62.37011192593065,0.0 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark11(-98.16856328002598,-1.7763568394002505E-15,-0.431012475182886,-100.0 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark11(-98.32415636428499,-0.02922136362842305,-64.55901801005267,0.0398834074956012 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark11(-98.41066924595413,-1.5707963267948948,-38.69539180871135,1.0000000000000002 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark11(-98.4244269454055,-0.3640155710600834,-0.16824902315140833,0.32337477997621955 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark11(-98.43347106600525,-0.005365055481665779,-32.63805388986147,99.66323692360835 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark11(-98.56534451911521,-0.016782246011523262,-66.86308865923274,-0.06255615127339323 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark11(-9.858809889572491,-1.3590874335200531,-1.5707963267948966,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark11(-98.74582674598318,-1.3235713011926438,-0.24766709624031905,-70.49176057062627 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark11(-98.745901486013,-1.1307999860457363,-73.67699534242954,0.0020221750692468454 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark11(-98.7476387744903,-0.937466054418365,-7.644669458920831,1.0 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark11(-98.89336234124389,-0.029386302184201695,-52.045768346834365,1.0 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark11(-99.06417722209268,-0.6721598673574396,-9.538448178513864,-1.0000585690670742 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark11(-99.07780009867339,-0.0828205386443978,-1.5707963267948966,-15.39491557458578 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark11(-99.2815204987219,-0.06954555537007547,1.1854850827052912,1.0 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark11(-99.30668612325485,-1.4371261714707433,-1.3430410066799507,-46.78244647916992 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark11(-9.932771377951365,-0.689496980594675,-5.40469815776453,1.0 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark11(-99.35465413667113,-5.877510831283902E-16,-73.87340733684356,-5.893595540901657 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark11(-99.445012606715,-1.1912181596480065,-19.804347697096862,0.06255409780534826 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark11(-99.45506192903937,-1.2018425983457803,-61.43274272108306,16.611857270788818 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark11(-99.51672962517051,-1.4056396213927942,-49.14055740621475,77.46248593435257 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark11(-99.54453598223009,-0.4834671711819867,0.0,-1.0 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark11(-99.60128044592378,-0.309086015429113,-52.07537370518869,-12.114590879951592 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark11(-99.62725831476237,-0.10090361278910143,-70.52444857631635,-0.7693783450039575 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark11(-99.71972696395466,-0.7724037954032118,0.0,-0.9193706329083076 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark11(-99.72390202305876,-1.442671003805628E-16,1.5707963267948912,0.0 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark11(-99.75383059965033,-0.860676489559139,0.39373787096564905,0.0773622542932948 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark11(-99.82059421620775,-0.5755639983985694,-3.5510859990421593,1.000060106910529 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark11(-99.9195646452304,-0.6300539342399665,-100.0,1.0 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark11(-99.98933979209124,-1.5707963267948912,-88.61823018132915,4.276423536147513E-50 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark11(-99.99364827902843,-1.5445058339671247,0.0,1.0 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark11(-99.99999955966055,-0.835485798722622,-68.78658944971262,-1.0 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark11(-99.99999999999997,-1.570796326794884,-1.5707963267948966,-0.7259260058297209 ) ;
  }
}
