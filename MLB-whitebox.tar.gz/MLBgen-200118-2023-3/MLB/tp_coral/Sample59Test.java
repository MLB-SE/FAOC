import org.junit.Test;

public class Sample59Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-0.001655675251611921,-17.597191433433863,95.74223102499028 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-0.013647384960122154,34.933588184402936,-81.23272296319242 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-0.021558566628274097,-3.0713790748582522E-238,0.01656612582246178 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-0.023892109183350815,143.36854036950444,-0.0015441384977912809 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-0.037569018370700494,0.0,40.40868977436787 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-0.04153860207882734,80.62481978252549,-100.0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-0.04292420273318717,-29.364577849122774,6.689728884256463 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-0.044695710144327494,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-0.0490136095978877,49.006751100790126,-82.54634367172231 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-0.057350637304317775,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-0.4864087612735968,1241.0718146163051,-1285.309038080118 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-0.48934159387018505,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark59(-0.004941727889549935,37.69392619606101,-0.057949981674884396,0.011655996154027511,-25.498724274849575 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-0.9999999999999911,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-1.0,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-1.1102230246251565E-16,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark59(0,0,1.1102230246251565E-16,0,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-1.1102230246251565E-16,-11.85938892047026,26.050803187740506 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-1.1102230246251565E-16,-23.35151924807299,-66.12417568874211 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-1.1102230246251565E-16,-3.521407188936207E-18,-11.990193716946763 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark59(-0.01180429026818111,-62.89995784084974,-0.029036914442805317,1.777417302347876E-15,-41.25632367720988 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-1659.0366788473598,0,0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-1.7763568394002505E-15,100.0,-100.0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-1847.8164154650372,0,0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-2.220446049250313E-16,-40.38334652188393,0.06647427579449072 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-27.423708264004844,0,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark59(0,0,33.83160996450721,0,0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-4.440892098500626E-16,-1293.346408489876,1200.7310610333366 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-48.81788949673249,0,0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-4.892434653203679,0,0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark59(0.06200261857271071,-6.130269786890203,-5.551115123125783E-17,-60.07076991847148,0.02614840015602297 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-66.6354034853125,0,0 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-67.82469651273323,27.392011464215642,43.32240383436806 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-6.931860416677154E-4,-2.752673928074059,0.5706438059279774 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark59(0,0,72.38415604220683,12.57767414175781,82.88517676409168 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark59(0.0,72.46202034142661,-9.433918258815596E-10,0.6237558874755272,-7.055921764401818 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-74.6675714239428,0,0 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-9.860761315262648E-32,0,0 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark59(0,100.0,-0.022992060653984896,-1.1255108490863799,1.1255108479212614 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark59(0,-100.0,-0.03598688191884755,7.103356370330968,-8.674152637790554 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark59(0,100.0,-0.03627136799891553,-474.72456685459076,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark59(0,-100.0,-0.04023620407257433,0.14217913741339602,-4.231477660524547 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark59(0,100.0,-0.040291674303138125,7.796672438868148,-9.367468765663045 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark59(0,-100.0,-0.044442308172748364,0.03973156072212908,-38.78226622882464 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark59(0,-100.0,-0.05215040398411547,-32.93120836683124,0.02095501218029151 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark59(0,100.0,-0.05855408257609564,-9.515157798630788,9.515157798630788 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark59(0,-100.0,-0.7748167656990944,-18.39413665529195,17.933392818068047 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark59(0,-100.0,-1.1102230246251565E-16,-0.37147404051600574,0.37147404051600535 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark59(0,-100.0,-1.1102230246251565E-16,4.892713327616997,-6.392713327616997 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark59(0,-100.0,-1.7763568394002505E-15,-34.04938814345284,34.04938814345338 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark59(0,-100.0,-4.156744515645983E-15,-1.9214604558512258,0.7841126755663375 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark59(0,-11.4251366862879,-1.738348725038296E-11,-2.4529256397468457,0.9780951016686734 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark59(0,11.473699290657292,-1.1102230246251565E-16,0.017364632553748954,-82.6005517757055 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark59(0,-126.17294226615506,-0.03742419298770794,0.006322458222804773,-248.34638785758918 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark59(0,-13.861072702980092,-6.935032788502049E-4,0.013783987647257412,-10.45907109341227 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark59(0,-15.565106115742353,-0.04124006446897552,-0.682732030975501,0.317033597060357 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark59(0,-1.58263427789353,-2.31398680930183E-10,-96.65263859961843,0.016251975626882655 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark59(0,-16.258346314893533,-0.007405999639705008,2.1828509686894898E-4,-25.11029304802099 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark59(0,-18.189990156297803,-0.02414356798031643,-10.895296856659753,0.003030160978351931 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark59(-0.20124223871619848,22.23740327665827,-0.047151420441868715,0.1087293121162417,-14.021032942715046 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark59(0,24.76553481084278,-0.04871781180053486,-6.031460415483886E-4,47.595058439152886 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark59(-0.3137163994254058,-69.44806613648424,-0.025045022969967322,-1.3531585640097052,-1.82271422689801 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark59(0,41.35294015856263,-1.1102230246251565E-16,-8.72889503167448,7.22889503167448 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark59(0,43.45635248237902,-0.012668360324962998,-1.5881784807393695,0.5375003188631543 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark59(0,47.89692655198045,-0.001253343690941544,-40.55249347543079,7.815970093361102E-14 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark59(0,48.06824701763675,-0.033253084712653896,-0.027288666233879343,2.957634137601417E-11 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark59(0,-52.97196486781106,-0.052580971864951254,-5.113574535527666,0.30718166243230605 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark59(0,54.987301737859156,-1.3877787807814457E-17,0.037618731782808466,-41.73990921303924 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark59(0,59.06304110451066,-0.026794301395935527,0.030525487974315594,-44.74887508702206 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark59(0,-61.08399769338223,-0.033455767501851086,-1.6925879973494515,0.12179167055455466 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark59(0,64.09608650301612,-0.04978784449863247,0.04801451688398295,-32.71502930229163 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark59(0,-65.33877445977441,-0.03465797915908864,0.39151744713912906,-1.8917181559470384 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark59(0,-66.63072508607814,46.42522864302671,26.990877226075185,-51.57368005380869 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark59(-0.6670308324875407,-99.35289353266272,-0.029519337882702196,-16.716102162675412,0.01662778855739047 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark59(0,-70.06352196132002,-1.592847798987002E-16,-4.133350994937242,1.0625546681423454 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark59(0,-72.12840646168387,-0.0440218747661264,-32.666507548590175,31.16650754859017 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark59(0,72.86558771076417,-0.01572505368078314,-38.39239716763529,0.039885683995023055 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark59(0,73.99089101784631,-0.0579382606801193,2.4592267429553147,-4.030023069750212 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark59(0,77.2240916138912,-0.03145033429749386,-2.11955117402266,0.61955117402266 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark59(0,-79.25934843792668,-1.795177566034999E-15,0.081488598151193,-1.6522849249460894 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark59(0,79.56434913044838,-1.1102230246251565E-16,0.019908200715710977,-78.9019735749032 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark59(0,83.52401147472506,-0.026289517010691987,0.6773615843064889,-2.1773615843064893 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark59(0,-89.79726463897532,-0.0405115685321249,-21.41917314639076,1.0658141036401503E-14 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark59(0,-90.54651916229682,-0.05512346925870067,-12.697005206047491,12.695919248945913 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark59(0,-91.90612743197066,-0.010694625484739404,-2.102420457652366,0.7259737254215068 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark59(0,93.96749691873613,-0.031173836461549354,0.14950857327069356,-10.50639633856235 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark59(0,-94.47986618573867,-9.02901414068971,-5.381381884115882,84.83067324553872 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark59(100.0,100.0,-0.011063193821754318,-2.8995395168412044,-0.25112072333354557 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark59(-100.0,100.0,-0.01661914534452452,-0.051196202889753746,-4.09039705503724 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark59(-100.0,100.0,-1.1102230246251565E-16,6.254069158205387E-11,-16.417527054596064 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark59(100.0,-100.0,-5.551115123125783E-17,-4.457258911674423,0.09589490075254425 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark59(-100.0,32.12969533001153,-0.017909073611009213,3.968021623435014E-5,-91.30432150213294 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark59(-100.0,-52.25348697284888,-2.4620764719071055E-8,-22.53587061520206,0.028135613774455382 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark59(-100.0,-57.39881285976998,-0.987398877217525,-4.508651962693308,0.4375104424541617 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark59(-10.677608968949727,-95.4823037134857,-0.04484071332376027,0.003606611033302041,-26.12061899080591 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark59(-1.2235469291354655E-16,19.816552208590625,-0.006170921182264568,0.05335463290859366,-4.43972524687628 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark59(-1.4489086360846793E-70,-99.99999862103707,-0.05901550205432131,-32.845092984630924,0.0478243836158363 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark59(15.340874953459789,35.219762361273524,-0.018856548765613754,4.440892098500626E-16,-80.02654881109237 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark59(-20.74685876778817,8.672348572220285,-0.052614598667960755,-40.99590598993587,0.03273014911871108 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark59(-27.466509381761917,23.4619317361851,-0.022749590780109234,0.3120930012049731,-4.953685654794766 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark59(-2.940716124815064,-64.43699270463982,-0.02136157743603012,0.11163071656116692,-12.893865418987215 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark59(29.65788934461692,-100.0,-2.49151496584073E-43,0.01700895803466551,-92.35112013231952 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark59(-29.790388106499787,-69.08149108977025,-0.004125871719768387,-4.386628475553531,0.01844310319930838 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark59(3.23235686252697,71.99311571765068,-1.1102230246251565E-16,0.04395456824235433,-10.765415684452112 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark59(-40.979468959814945,12.260361756439718,-0.03422809039219894,-19.486573609980695,0.07819325762761331 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark59(-53.24687071591181,-83.1043080409007,-2.7755575615628914E-17,2.58146096257519E-11,-4.194833416579016 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark59(-5.338918120937469,-56.397548534952165,-0.037991198779411775,-0.16241346637255935,-3.9797070944892363 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark59(63.652596928937925,74.77997625868028,-45.86091199539888,78.8936222715572,-7.7966002859798635 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark59(-6.617050358318807,52.92874690852868,-1.7489526069700086E-15,0.01973685507658054,-79.58696158531716 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark59(-69.94610912541945,50.39739177439163,-0.005212187950943581,-6.678104778082725,0.23521588519396744 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark59(7.07737341588836,-19.955343736238085,-0.03962510796934009,-2.4487843368994784,-0.7283281483916249 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark59(-73.16605515645762,-84.63003547072086,-77.55670674403304,-90.17177854918043,79.63530348453972 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark59(73.32027185016605,0.009823344257636495,-0.009654565718612174,-89.46709413118512,0.011394221718324715 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark59(-7.421163550810121,100.0,-0.0028289832779795354,-25.48361123281329,0.061639471440852134 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark59(76.9107899541762,8.371480387067788,-0.053770894780723465,-28.50609491860719,0.03413157152283966 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark59(78.86277773559789,4.258244200851806,-0.027746678267624114,-79.77983074021293,4.263256414560601E-14 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark59(-80.44131633197144,-45.37390739461409,-0.04995186067179165,-81.7304879156241,0.019219221209306074 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark59(-82.60903701085383,-31.64844615856397,-0.047892811662075124,-16.310458068376736,0.09630608289539146 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark59(84.38852525042904,60.93237652933351,23.5682865679902,-71.44790155377245,47.93703097029481 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark59(-89.83674613359634,-64.8603219367833,-0.04594988984467335,0.07937201889314294,-19.790303292015626 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark59(90.90455158450963,39.706161363978126,-0.05590716678466682,-16.744041659934283,0.09381225624595402 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark59(-91.6787549442375,-86.99363388344614,-1.3877787807814457E-17,-2.3085850987782432,-0.8335617389797202 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark59(-91.75998449692186,-100.0,-0.011082599468205057,0.32190116091639864,-4.87141268849048 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark59(-95.44600625655093,-49.71344236031547,-0.054875615961963886,0.24142100653252918,-4.672952053002864 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark59(-97.49119667653913,-64.80574712261128,-0.015341983277582759,1.8809685312598913E-4,-4.302003655266513 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark59(-97.50413721753566,0.7857271854299122,-0.011711657561190103,4.440892098500626E-16,-16.71939962747644 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark59(-99.9819736263626,-100.0,-0.025580665087034365,-9.90504478199627,0.02450153443561151 ) ;
  }
}
