import org.junit.Test;

public class Sample83Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark83(-0.5488506215575154,0.30123700478407095 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark83(-0.6972856873474537,0.48620732978010733 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark83(0.9999468343323897,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark83(0.9999999916812923,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark83(0.9999999956049002,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark83(0.9999999999999972,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark83(0.9999999999999993,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark83(0.9999999999999999,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark83(1.0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark83(1.0000000000000002,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark83(1.000000008154138,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark83(1.261171575366784,1.5905537425131357 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark83(1.326570216934604,1.760036770970511 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark83(-2.2022515038885464,4.8499116863793645 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark83(-32.347964780860394,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark83(3.406371874181022,11.60336934521153 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark83(4.909201293020098,24.10201672579807 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark83(50.40939752516985,90.89657272364232 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark83(-5.369743746645046,28.834147912920958 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark83(-6.023456642783323,36.28202993072916 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark83(-6.167514255026552,38.03823208595572 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark83(-67.24774050210871,0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark83(-67.94578622030227,57.01075589030543 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark83(7.409318215673414,54.89799641686627 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark83(-7.575875267208996,57.394103446878184 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark83(7.8090313184259905,60.98097013215797 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark83(8.532509994421474,72.80372680490234 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark83(-87.18719419196866,-37.38536412354576 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark83(88.92856652160552,0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark83(-9.041843113233893,81.75494512236389 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark83(9.314145320323952,86.7546022981088 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark83(95.52534701559506,55.159519756383844 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark83(-9.834346252087197,96.71436620594149 ) ;
  }
}
