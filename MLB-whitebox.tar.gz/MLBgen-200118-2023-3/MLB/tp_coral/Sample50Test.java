import org.junit.Test;

public class Sample50Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark50(0.001421258217032016,7.327329846593559E-5 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark50(-0.0016796801116970717,3.2192028383118344E-5 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark50(0.004972376934016717,3.0790850275773778E-6 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark50(-0.06650347810426317,1.5956076329107092E-4 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark50(-1.0098760067616105E-8,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark50(1.0564136567477078,10.151959261009804 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark50(11.728079992534603,58.2773794298449 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark50(14.761776776590025,35.238223223409975 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark50(2.0096192273939595,5.515532889326853 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark50(20.864741296488873,28.594312380784345 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark50(2.2475460176066093,15.24754601760661 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark50(2.480144196181061,5.2523125727541995 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark50(2.547794584107506E-10,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark50(26.342821348271443,79.98328267818903 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark50(3.5547969841754252,31.253976961596123 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark50(38.27051301454392,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark50(38.291672524325804,94.6490515363395 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark50(39.655731306016264,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark50(41.78724416995027,68.78479028126335 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark50(-42.64664718806994,9.300781836891645 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark50(4.759480631573832,6.347530303210095 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark50(5.082197683525802E-20,2.2406925212643879E-10 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark50(-5.1292893066151666E-5,0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark50(-5.1548810246314625E-18,0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark50(6.108214961343722E-8,0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark50(6.203143496917819E-5,4.5448794225947726E-8 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark50(-62.97277293867285,0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark50(6.989766957264701,43.010233042735294 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark50(9.428188534203642,48.67377443129544 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark50(-9.634579518869972E-9,0 ) ;
  }
}
