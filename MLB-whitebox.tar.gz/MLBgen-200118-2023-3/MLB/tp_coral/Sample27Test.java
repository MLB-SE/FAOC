import org.junit.Test;

public class Sample27Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark27(0,0.0,-0.47483079490539737 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark27(0.001754816234620371,95.47649542865827,-0.005977262149850085 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark27(-0.004728335830307307,3.2967047012094017,-0.10902468665160225 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark27(0.0,0.9504761803837862,-0.21093970920156835 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-11.576302220000116 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-12.939410194822628 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-1.3933100161695506 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark27(-0.015560798509996088,33.2938554732751,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-1.5707963267948963 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-1.5707963267948966 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-17.167759619965906 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-2635.362086738058 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-2728.742517060275 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-3.3881317890172014E-21 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-36.949784443739816 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark27(0,0,3.7285079305924 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-43.25981433730372 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-49.15565360488505 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-49.87656328449446 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-58.089862444651196 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark27(0,0.6468804556041903,-1.1852140854902586 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-82.20110908868622 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-83.1644907422723 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark27(0,0,84.06434618718984 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark27(0,100.0,-3.0434882550201807E-5 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark27(-0.12110023963357186,1.3685224627894,-0.41840231970074476 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark27(0,15.856341876600773,-1.5707963267948963 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark27(0,2390.186081343151,-1.5707963267948963 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark27(0,2521.0633129479143,-1.490286377131478 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark27(-0.32910777049742346,49.70377072374045,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark27(0,36.61654437719605,-1.5707963267948963 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark27(0,39.068909837642906,86.19085088998563 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark27(0,43.240373103596795,55.572175858581176 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark27(0,44.37816305013098,-0.03527222640914984 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark27(-0.611655482472464,12.000810600105936,-0.042063604756744866 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark27(0,65.45878551178538,-0.9145554072747769 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark27(0,76.55817167604528,-7.517718134819346E-11 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark27(0,-78.72423405658498,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark27(0,88.03155494073016,-1.5707963267948957 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark27(0,94.80224681632546,-1.5707963267948961 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark27(0,9.671236115808664,-1.3620152025184402 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark27(0,-96.77032905419229,-0.4983839858702055 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark27(0,99.96844433047774,-0.01571356823340252 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark27(-100.0,0.5667704864652077,-1.0167071870227693 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark27(-100.0,2.7084445356563E-6,-1.5702117231875168 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark27(100.0,3.7569783408055645E-16,-1.0802373650189088 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark27(-1.0217707671158067,1.6342482922482304E-13,-1.1619670126399062 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark27(1.0623283878275978,-41.177415420890995,-4.7498884935600655E-8 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark27(-10.921776704633402,611.2210291881463,-7.247535904753022E-13 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark27(-1.1344093309162417E-7,1.78190117127649E-5,-1.5707963267948948 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark27(1.2415325789028202,0.0025145184356771787,-0.5137585604100678 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark27(-13.136217742542414,0.5095781347936766,-1.5707941084729617 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark27(-13.661957580558544,0.03190056104033935,-0.4264344671871252 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark27(-1.4210854715202004E-14,0.13953857377871515,-1.357351180461276 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark27(-1.4210854715202004E-14,0.7690996355919943,-0.7998339543684736 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark27(-1.4210854715202004E-14,17.252444813720054,-3.4600904961547636E-9 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark27(-1.4210854715202004E-14,7.105427357601002E-15,-0.4636625136673427 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark27(1.452012167760271E-21,99.99999999981041,-1.5927889392544417E-9 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark27(-1.570790794091323,1.8703676838850744E-13,-1.5707963267948895 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark27(-1.5707907940934973,100.0,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark27(-1.5707907940935115,-2.800711051964555E-15,1.3565166672804538 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark27(-1.5707907940935257,-7.823789939342918E-14,3.4772628200758233 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark27(-1.5707907940935328,1.91402449445377E-13,-0.5082073978095969 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark27(-1.5707907940935346,89.29612923573808,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark27(-1.5707907940935348,1.4210854715202004E-14,-0.004810199048291719 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark27(-1.5707907940935364,1.5707427661274178,-2.545717010072052E-10 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark27(-1.5707907940935724,2.3343026046873605E-9,-0.6920869232577893 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark27(-1.5707907956130853,3.176371415531381E-5,-0.9473790697801172 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark27(-1.5727303898785343,1.5764841774777336,-0.03149826602539096 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark27(-1.5783316185371348,0.4323952103702643,-1.4493573990873407 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark27(-1.5859441895236515,0.2214491316889211,-0.6747042861521576 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark27(-1.7462674809978296,0.45213348279811,-1.5707963267948948 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark27(-1791.2812569341193,0.05228206451943995,-0.1120161241106471 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark27(-1.7975566928451E-139,289.50914006052807,-1.7282856447243739E-4 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark27(-1.8474111129762605E-13,0.10116477931868667,-0.5177255999621937 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark27(21.249461335316752,-45.2884305105393,82.43918752541458 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark27(-2.2131618651272261E-221,35.48669407964962,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark27(2.220446049250313E-14,22.38522404689396,-4.806616637413334E-13 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark27(-2298.005991218311,148.4020115620777,-7.124477649258252E-5 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark27(28.566899328976234,1.6844752567955936,-0.03279006526586487 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark27(28.685422787573696,5.303649262653404E-15,-1.366336236419224 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark27(-29.854207352165037,0.3592003440063054,-1.5707963267948961 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark27(-36.559157261183586,19.85613991658446,-0.02785315418536642 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark27(-38.30716217335092,0.09496721248797946,-1.5537224005446297 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark27(38.54882986889939,7.105427357601002E-15,-0.044290249720371655 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark27(-40.19304732362473,9.220379687705268,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark27(-44.86631077155922,50.58383433764,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark27(45.493111720178916,39.26190017697178,79.33685499056273 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark27(-45.955651218738396,0.9870180921976717,-0.5500748374138227 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark27(-47.4001836211647,193.23079378730964,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark27(-47.86136970779147,-78.51560818648022,-34.31533368940369 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark27(-4.812624123197756,-0.095728253939392,-0.88650826615874 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark27(48.25810701262163,12.987694212836457,-0.0403611339032278 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark27(-51.720377779502506,0.37746838292690804,-1.1716285377752769 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark27(-52.90193504765553,61.88636078370601,-1.7223991646039644E-18 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark27(5.551115123125779E-17,22.513304550002562,-0.015413197316105394 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark27(-56.96739715752071,78.51608247607376,49.804793625985496 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark27(-5.719869022868806E-13,100.0,-2.7082112983354645E-11 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark27(59.19282929040662,27.911033561846594,-35.51760371511155 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark27(-66.64241633645045,-76.03428144733041,-78.8433465522528 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark27(70.17544492463867,2.8789267966771116E-13,-1.2729234272344847 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark27(72.54017601616701,1.1402898343103409E-4,-1.5707963267948961 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark27(-7.307005958813853,1.4210854715202004E-14,-0.661539178095417 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark27(73.17778444330409,0.1334985549132078,-0.731922241542736 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark27(-7.35552090039306,21.929975648582143,-34.210792547962555 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark27(8.0149733720019,1.6242868274942195,-0.2573622279312553 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark27(-8.526512829121202E-14,1.4210854715202004E-14,-1.0469611960648635 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark27(-88.95889151351592,-57.0335556768369,-79.45906987798874 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark27(91.94915577009579,1.0658141036401503E-14,-1.1841743327640728 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark27(-92.09194682740383,94.99394873341946,-3.6190959755027556E-17 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark27(-97.51450745368744,81.40858143554172,-2.220446049250313E-16 ) ;
  }
}
