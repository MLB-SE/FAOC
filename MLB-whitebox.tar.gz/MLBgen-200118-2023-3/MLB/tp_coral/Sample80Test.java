import org.junit.Test;

public class Sample80Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark80(-0.01660199024742326,91.35061324848147 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark80(23.915268005994037,10.381263815635933 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark80(72.99203580572623,-46.22866659414178 ) ;
  }
}
