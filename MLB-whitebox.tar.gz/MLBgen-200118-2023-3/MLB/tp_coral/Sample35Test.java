import org.junit.Test;

public class Sample35Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark35(0.0710765230675463,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,0.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-100.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,100.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-26.656843021737266 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark35(-10.002852432692602,-747.685546875259 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-40.19140625 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-709.2578554136862 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-709.2648823007385 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-709.5931965389822 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-709.7379529126052 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-709.825316561069 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-709.8714811005092 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-709.8924450359297 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-709.9021805003161 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-717.9697263044688 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-725.3370689630125 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-728.5883907215949 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,735.2972043136224 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-736.8192099909245 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-740.2181384359009 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-744.4192633957279 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-745.0577109964755 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-746.0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,755.1286789418562 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-755.9790614007662 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark35(-10.039833804049735,-709.331468502196 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark35(-10.072199750123787,-713.3087298586419 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark35(-10.08792049744811,-746.0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark35(-10.190935527468042,-709.2500476051856 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark35(-10.243728205257895,42.79654558501979 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark35(-10.303174428710875,-709.9496602816971 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark35(-10.311975347154558,-40.40607000207546 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark35(-10.320592975602437,22.86388502097516 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark35(-10.389996348170271,-712.1658858874819 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark35(-10.39680194959756,0.0 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark35(-10.505907489253971,59.276481044838135 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark35(-105.18972472435425,0.0 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark35(-105.23962462274899,-42.094844774530074 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark35(-10.546913021710665,-71.53725345506018 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark35(-10.566236562497778,-709.3640863645763 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark35(-10.603908211368719,-29.87925116293566 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark35(-10.801724694212183,7.3145087683068795 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark35(-10.948887684557247,0.0 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark35(-10.97010555760663,-8.883844792479906 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark35(-10.994773594020288,0.0 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark35(-11.061900718437428,0.0 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark35(-111.36679148102185,-742.3198543000315 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark35(-11.413178593641703,-719.1173454284309 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark35(-11.51037315859628,-716.2733294906351 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark35(-11.566768027558965,-709.9089500874675 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark35(-11.569863936496759,0.0 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark35(-11.615380303641608,-709.4874952601325 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark35(-116.37393752636282,-746.0 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark35(-116.55293270504741,-709.253957584408 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark35(-116.71667367495745,-714.8865225820244 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark35(-11.744443588696043,-72.33565743385164 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark35(-117.80599523710814,-720.5463457170174 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark35(-11.818836433871056,754.4341303005212 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark35(-11.854772118074393,-733.0139004753471 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark35(-11.882983129592347,0.0 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark35(-12.01770623133504,-722.0144608588993 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark35(-12.07677107912053,-39.072986870030775 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark35(-12.08159821251023,-740.3004654955805 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark35(-12.10012435803364,-1.494140625 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark35(-123.04819928327507,-734.7593392234461 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark35(-123.35796970555252,-82.52948219025771 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark35(-124.08918054428841,-727.8573294862058 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark35(-124.09663908930592,-735.4507452314265 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark35(-12.4776122382316,-709.6239611106341 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark35(-13.878409973894975,29.65984929933836 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark35(-13.987821372960468,8.047126988988637 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark35(-142.9461950108447,-709.2244364954287 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark35(-143.41877981419037,-709.9626086025132 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark35(-148.28317407523815,0.0 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark35(-149.22192526496792,-745.9999999999999 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark35(-149.2285297109808,-746.0 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark35(-1.5707963267948966,0 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark35(-1.5707963267948968,0 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark35(1.5707963267948977,0 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark35(-15.760024760664024,-772.7690404578431 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark35(-15.766118963467406,-746.0 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark35(-15.782921243581356,-746.0 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark35(-15.8835508662673,57.16390786330845 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark35(-15.918480127091584,89.9116098780737 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark35(-15.940591616675775,-746.0000000124891 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark35(-15.980623893494467,-709.0775369326219 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark35(-15.989098708939338,745.6031098398896 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark35(-15.997130096976349,-709.4261742988049 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark35(-16.08008612507963,-743.2146206469935 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark35(-16.159497404028755,-746.0 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark35(-16.167788885483446,-709.0886173799431 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark35(-16.23414274568769,-746.0 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark35(-16.235499936671573,-746.0 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark35(-16.260836529899123,-709.36468909502 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark35(-162.61850463941403,-68.21592114822047 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark35(-16.450339317003138,-744.4656872009956 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark35(-16.708167975115074,-709.9938160204458 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark35(-16.83609678187156,47.581540373838976 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark35(-16.881718575582937,-709.9470740021461 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark35(-16.93719920882846,82.89512477016345 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark35(-16.94073711650968,40.50901126663402 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark35(-16.985287154830104,-1.494140625 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark35(-17.031476185072506,0.0 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark35(-17.058265329936013,0.0 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark35(-17.170904255391534,-762.9035916754883 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark35(-17.180524637339744,-709.7393542934486 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark35(-17.281389985852588,-809.1227088612131 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark35(-17.282488867252937,7.357063883623113 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark35(-17.512345066093495,-709.6371220019 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark35(-17.761790338893377,0.0 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark35(-18.745813417782482,0.0 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark35(-187.80436146243838,-709.8550248101897 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark35(-18.83270140524435,-709.0190797359039 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark35(-18.849555921540112,0 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark35(-19.00258640689681,0 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark35(-19.592334828793142,62.80081002495132 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark35(-22.034729776959907,68.46047479492483 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark35(-22.102898519359165,0.0 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark35(-22.22855471271161,-746.000000019165 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark35(-22.26595723368171,-709.7491396183866 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark35(-22.380168485295897,765.0345595289259 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark35(-22.446583203341078,0.0 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark35(-22.53302026616734,-717.0726791661542 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark35(-2.2601436188695914,-84.57975339401966 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark35(-22.730515137730606,713.7022543453585 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark35(-22.77742902908308,-746.0 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark35(-22.970010455134855,-746.0 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark35(-23.022344542076787,-739.4855906274846 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark35(-23.036037168014545,0.0 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark35(-23.07806258731351,0.0 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark35(-23.18581027003879,-745.1209602678401 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark35(-23.189616053375147,-746.0 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark35(-23.451657365497766,-746.0 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark35(-23.55941036088098,-732.0166117116474 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark35(-23.622647429283305,-736.4584523266448 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark35(-23.756566898940406,17.97722807761164 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark35(-23.898759998763524,-746.0 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark35(-23.985980356341912,79.61781461087267 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark35(-24.280746925542047,-79.95331925266045 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark35(-24.31221322527479,-750.1914063474552 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark35(-24.430366829708234,46.36768863872237 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark35(-24.43673094321936,0.0 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark35(-24.462575266820892,56.19898351200777 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark35(-24.72134180537404,-709.9287873777015 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark35(-24.80564785489176,58.472365400845206 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark35(-24.947284300592216,-41.42722772035341 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark35(-25.195398195249965,0 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark35(25.497049092818642,78.1442106310599 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark35(25.95496671353075,33.47864351652902 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark35(-26.199812200024468,-0.28303968165570836 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark35(-2643.4869459854767,0 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark35(-2722.051470151482,0 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark35(-27.778227799750454,0 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark35(-28.27433388231162,0 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark35(-28.30548896184976,-91.31454870484987 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark35(-28.445793371976194,-735.9001735498767 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark35(-28.472544324526154,-89.81656035404274 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark35(-28.523258054133933,41.10294400153205 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark35(-28.539092791365846,96.98746037058098 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark35(-28.738376384032406,-736.0664491245178 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark35(-28.752101888511707,0.0 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark35(-28.867419656787632,-746.0000000305239 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark35(-28.90143059834287,-5.388862246246788 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark35(-28.936110828261448,-746.1914062563543 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark35(-28.96768849934594,-709.9999948249393 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark35(-29.161564158365607,-709.9998722078161 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark35(-29.23059853061723,-20.766942694850954 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark35(-29.23225069769302,710.7193015037038 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark35(-29.295861952976864,-711.4514722136668 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark35(-29.4453232816458,0.0 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark35(-29.47840645643238,-746.0 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark35(-29.499365223127356,-715.5231527858316 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark35(-29.579047283541087,-19.21884696793053 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark35(-29.644518247838008,-709.5835530402653 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark35(-29.65506937696152,-25.196043479430855 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark35(-29.759487264479304,-742.937091842334 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark35(-29.841400936593928,-1.5589591473421365 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark35(-29.842635087472917,-764.7590425550504 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark35(-29.844005226928573,-709.1165879837037 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark35(-29.8440605498011,59.68962842441442 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark35(-29.847424691082573,-731.4985903367991 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark35(-29.848859481612152,-745.9996306739207 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark35(-29.95277696659646,-746.0000000022375 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark35(-30.16643431963257,-715.4093867186424 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark35(-30.34756945086923,8.34571337996664 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark35(-31.355959763932347,-746.0 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark35(-31.37160076051846,-709.0255159463863 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark35(-31.400946445540214,-2.855592890783896 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark35(-3.1486797977563654,0 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark35(-3.148713463569056,0 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark35(-31.623603639838223,0 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark35(-3.176513984737525,-711.9503533682006 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark35(-3.3054186523258267,-746.0 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark35(-3.3253013378308127,-41.68554687499994 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark35(-3.3757032408032757,-50.425775577056385 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark35(-3.4123185434375065,-709.999582673864 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark35(-34.71875282625044,-709.7023355222989 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark35(-34.74302175294787,-709.492171842215 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark35(-34.805961474795225,737.6161778447852 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark35(-34.85590179270028,-746.0 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark35(-34.89896158824139,-745.9972381704889 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark35(-35.02588287422846,-67.07043583453137 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark35(-35.26818392089615,23.02610405000725 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark35(-35.33511872392255,-746.0 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark35(-35.336047507020524,53.66465158505844 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark35(-35.46336426571837,-14.617481702720099 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark35(-35.5158369642423,-731.3565971844971 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark35(-35.6155809975953,10.633126754432638 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark35(-35.621961662760654,-95.39204974025657 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark35(-35.67115523028931,0.0 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark35(-35.700309212268415,-746.0 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark35(-35.70802228177436,-65.56906859423275 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark35(-35.90499152748259,-746.0 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark35(-35.962876270159796,-746.0000000095944 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark35(-36.0270011646427,0.0 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark35(-36.05584182473577,-709.5541205451784 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark35(-36.059131541731126,0.0 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark35(-36.1245862437735,36.0306781729496 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark35(-36.12568567564387,-770.150492311095 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark35(-36.12597337791368,95.77393936084194 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark35(-36.334969510145385,0.0 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark35(-36.3869991485314,-709.783710731234 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark35(-36.6006013183362,0 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark35(-36.7502467177794,13.266588239600011 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark35(-3.6833582649572207,-17.048739441675067 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark35(-37.12644203327851,-709.1002627947236 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark35(-37.2743647294441,-746.0 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark35(-37.50303323194662,80.19779906265862 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark35(-37.69911184307751,0 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark35(-3.791209864663017,0.0 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark35(38.47673547134204,49.14769515512751 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark35(-3.8512336243713605,0 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark35(-3.9191453505695235,-746.0 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark35(-3.9466334048404974,-709.6641991404395 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark35(-3.9475387006556986,73.60483612530713 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark35(-40.04775054252823,6.675148432074863 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark35(-4.021269188513775,0.0 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark35(40.55925606913837,-24.197836883725813 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark35(-41.187315720418674,-758.4858982109528 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark35(-4.121484036421791,-714.819361370062 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark35(-41.24436436153438,-43.102380082284995 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark35(-4.124679323177531,20.18169907664904 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark35(-41.29154168338784,0.0 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark35(-41.33683173977912,0.0 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark35(-41.34532933425893,0.0 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark35(-41.366144505923984,-720.5215525843711 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark35(-41.41970854708503,-746.0 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark35(-41.42951463488495,-742.0659818582554 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark35(-41.44684519393999,0.0 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark35(-41.53686753064334,-709.4542651885332 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark35(-41.62600548345253,-746.1915133862162 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark35(-41.723592100940394,-746.0 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark35(-41.73618702246374,-745.9999999999985 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark35(-4.180324210619958,0.0 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark35(-4.196213261594627,-69.36373830404325 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark35(-41.967477346927005,30.94897166826587 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark35(-42.135471607769006,-745.9999999960233 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark35(-42.15284088266975,-33.14884045348781 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark35(-42.21442190472315,-746.0 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark35(-42.2761469444186,-709.9728109041326 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark35(-42.35858374718882,-76.64410234466428 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark35(-42.383990284456544,-1.4941406249999964 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark35(-42.407771550953065,-745.9965608331928 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark35(-42.40777155095311,-709.1017412035656 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark35(-42.41048906699555,-1.5287067157401792 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark35(-42.41523009597132,-41.65451072477562 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark35(-42.67102139525585,-709.5060644500725 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark35(-42.83275688372687,-727.1358445410976 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark35(-42.889079132166394,-745.9874021259595 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark35(-42.93991825428047,36.6037230530157 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark35(-4.3003522670309575,-709.0979936574652 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark35(-43.081655358230236,-745.9999999999995 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark35(-4.312839698639771,-21.920744531372918 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark35(-43.13897452882776,-25.449957583383267 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark35(-4.316235403361219,-746.0 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark35(-43.304799441136424,0.0 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark35(-4.330648046061199,-76.82062537234226 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark35(-43.35582197652357,-765.0870500697694 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark35(-43.364324534675134,24.250384940248452 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark35(-43.60400382796274,-746.0 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark35(-4.362709219895365,-746.0 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark35(-4.387149285247617,0 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark35(-4.390365516545309,-746.0 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark35(-44.71669529091127,0 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark35(-4.572933585594271,-746.0 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark35(-45.843337482764035,74.10030875982483 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark35(-46.15666809199648,67.05943546430615 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark35(-47.13297732203628,-709.6117203908558 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark35(-47.168789807771304,-746.0 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark35(-47.17102458743767,-41.9783716156976 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark35(-47.200969217966104,-743.5280938305782 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark35(-47.20360155769341,-50.94687710327761 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark35(-47.20865806018101,-708.7728046748279 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark35(-47.20877774673933,-51.22367146521527 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark35(-47.501761508227084,-746.0000000409957 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark35(-47.54923928250434,-47.555250679202274 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark35(-47.750160957456345,1.6107011953992298 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark35(-47.7934641786524,66.01869949021776 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark35(-47.81338366910679,-40.78976930087759 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark35(-47.82976282525819,-16.643643600260248 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark35(-47.830625381491565,-740.7728875982242 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark35(-47.862090462215235,-709.9836693454761 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark35(-4.81568325572019,-746.0 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark35(-48.170254243033426,85.51236939884285 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark35(-48.17048820977499,-712.3640420396647 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark35(-48.200942866438766,0.0 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark35(-48.23734382514262,-72.50730622041594 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark35(-48.27873675326332,-709.899839143502 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark35(-48.32890934108961,-26.784231454447927 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark35(-48.447396958945845,-720.7592848397665 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark35(-48.51653263386688,0.0 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark35(-48.57082691967891,760.1429079526039 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark35(-48.602068788952934,-709.9989948702258 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark35(-48.65417509968388,710.3516360044889 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark35(-48.6931577303981,-745.9999999892303 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark35(-49.11872083477347,-746.0 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark35(-4.914119339771943,-10.032547286660247 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark35(-4.930380657631324E-32,0 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark35(-49.573311336790084,-746.0 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark35(-49.71307953185688,0.0 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark35(-49.780065478146426,-714.1500994498019 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark35(-49.905144568030835,76.56102538251645 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark35(-49.99487711101709,-709.502771334157 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark35(-50.070508922823855,12.718378307215914 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark35(-5.048527715518759,-728.9257094109995 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark35(-5.074323158802784,-42.87906606051881 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark35(-52.72184107834701,-4.703009886002633 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark35(-5.319697880481925,-1.4005378933358958 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark35(-53.42999976994163,-709.9786266504752 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark35(-53.49062695799829,0.0 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark35(-53.55695549568149,-709.1505450644843 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark35(-53.576221392994285,-746.0 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark35(-53.69300441662639,-719.488855269831 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark35(-53.765970512096885,-745.8831492002831 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark35(5.3811009466169395,0 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark35(-53.859346251100646,-709.0850609953857 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark35(-53.86258367171368,-74.20930602509664 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark35(-54.01196505201244,78.65334792592733 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark35(-54.021560882444874,-724.5409236382457 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark35(-54.08975015864672,-746.0 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark35(-54.603320805551256,-729.5402339225568 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark35(-54.60675625935208,0 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark35(-5.465722321248338,0.0 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark35(-54.7396264303331,-97.11339558906018 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark35(-54.75473611000795,-712.5556740349755 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark35(-54.812788588682395,-721.0840785707595 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark35(-54.82133594538918,81.64045292912678 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark35(-54.8249758110249,88.70449299077876 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark35(-54.836390728456166,-66.9889023817027 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark35(-54.96525483728687,-40.19140625 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark35(-54.97552726961857,0.0 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark35(-54.97639840212474,-774.9275637989198 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark35(-54.97775916251435,-729.8983371515984 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark35(-54.98068695464441,-100.0 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark35(-55.00065149091851,83.25976777480025 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark35(-55.112585570132275,-81.86815529444385 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark35(-5.55150364060691,-721.374934571614 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark35(-55.68476534342012,0.0 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark35(-5.575367898326263,-24.277985870451758 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark35(-55.88305168656835,0.0 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark35(-56.09630066578131,-709.4156185460573 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark35(-56.30091509629666,-7.67295884280324 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark35(-57.253570675072154,61.460747536372594 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark35(-57.43475622691718,0 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark35(-58.700762821447114,0 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark35(-58.719943582839875,0 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark35(-5.881186598253754,-709.8634755176406 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark35(-58.83877127044877,24.883484522381053 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark35(-59.718528311661935,0 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark35(-59.73147005823327,-19.356923413183736 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark35(-59.74491130035935,-709.2249067702115 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark35(-60.057050324412955,-746.0 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark35(-60.08793511789161,-745.2298902900698 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark35(-60.13719158083282,-709.8206055406611 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark35(-60.24315752857659,0.0 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark35(-60.35595880064386,-40.18506468638033 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark35(-60.41678675089444,-24.183966355285833 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark35(-60.42796791662701,0 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark35(-60.45224474799404,-746.0 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark35(-60.664889762981346,-711.3043277244466 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark35(-6.071727152808421,0.0 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark35(-60.726028923105545,-740.5033652373605 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark35(-6.084587345604092,-746.0 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark35(-61.15334838815545,66.10809739244766 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark35(-61.202795240177664,-714.958088087098 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark35(-61.219082999936944,0.0 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark35(-61.261429400808225,0.0 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark35(-61.26300987000097,0 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark35(-61.45864403673214,-85.4628353926637 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark35(-61.60459575096049,0.0 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark35(-61.77478123695366,-744.2074544186713 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark35(-6.24766380886561,34.56031045690182 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark35(-62.52204125772904,74.87573027993034 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark35(-62.57816924092202,0.0 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark35(-62.80291874577117,0 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark35(6.283185307183225,0 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark35(6.283185434525475,0 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark35(6.283185471637345,0 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark35(-63.14328559365339,-20.61662466993215 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark35(-63.40470044893893,0 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark35(-65.64701089333582,0 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark35(-66.00737644482999,-746.0 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark35(-66.04978236019872,-709.8739614416637 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark35(-66.08380586444058,-709.5836954980833 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark35(-66.10832196235413,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark35(66.47392109834013,-17.858907732987433 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark35(-66.52212689239241,-41.68554687500001 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark35(-66.57601627255143,57.13568854422118 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark35(-66.63742286444885,-40.19140625 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark35(-66.6556611839358,94.76623941359536 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark35(-66.80275419108463,0.0 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark35(-66.91276577757802,-709.3572637846883 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark35(-66.95940717978232,-746.0000073812615 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark35(-67.06120838360746,-746.0 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark35(-67.12269815162885,-709.1962814698752 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark35(-67.25422462565575,-709.8920545350514 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark35(-67.30827603425558,-746.0 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark35(-67.4818800794638,-710.1130484987109 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark35(-67.48640325479644,-750.1914196941276 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark35(-67.54283970302227,-100.0 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark35(-67.60333592745864,22.65274664971774 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark35(-67.8494920677361,94.67558988472675 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark35(68.01361706581571,-23.522088889832915 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark35(-68.38938919498425,-40.19140624999995 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark35(-68.47498508886937,-89.06648930297074 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark35(-68.5925577411306,-36.79148488462081 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark35(-68.96176052051264,-11.873213032573958 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark35(-69.02186635981072,-746.0 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark35(-69.03325543262049,-709.0810676021323 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark35(-69.05590306490998,-745.4186093687895 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark35(-69.566028631905,0 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark35(-71.27009760121344,51.84104416880629 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark35(71.74980369822839,0 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark35(-72.2872390618251,0 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark35(-72.33775662301129,0.0 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark35(-72.40262182185491,-721.9413469723613 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark35(-72.4268957980297,-746.0 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark35(-72.50880591810295,-709.233773512275 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark35(-72.55582574964232,-745.9998772197206 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark35(-72.60756709431925,-64.18066194579103 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark35(-72.767449161634,-746.0 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark35(-72.77542380025842,-747.1914067762824 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark35(-72.82887708383944,0.0 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark35(-72.90158230128634,-743.2757240685025 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark35(-72.93826369658476,0 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark35(-72.99630528482788,-709.6029581443767 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark35(-73.00063868825526,-746.0 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark35(-73.1221921767519,39.15850430766284 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark35(-73.2092793751873,0.0 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark35(-73.22828440848114,43.99816412727685 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark35(-73.35899227546497,21.371721108941216 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark35(-73.71056869379815,-746.0 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark35(-73.73052445481743,-712.6583089214071 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark35(-73.8236980868511,-709.0803495517004 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark35(-74.25610885688658,-746.000000174545 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark35(-74.35821711967874,-709.1411193956488 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark35(-74.56140918904404,-40.19140625 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark35(74.75262857014607,-64.37996473579773 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark35(-76.72097413813066,0 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark35(7.853981633974484,0 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark35(-78.61976685334224,0 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark35(-78.6518375242029,-40.19140624960147 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark35(-78.80295720568766,61.89099935286376 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark35(-78.8257882777695,-746.0 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark35(-78.87405176116133,-746.0 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark35(-78.91517019112632,-745.5627943153147 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark35(-78.91725455796129,-40.02591130152766 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark35(-79.01156073770525,-5.414463840062979 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark35(-79.05241732436534,0.0 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark35(-79.12773948758216,-745.9999999989368 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark35(-79.28287751272276,70.12216047056674 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark35(-79.48994040986639,-746.0 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark35(-79.56851533981013,-710.0268304637797 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark35(-79.7348071027026,-711.9351599651454 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark35(-79.84569330823079,-1.3656791743675059 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark35(-79.88298648628097,0.0 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark35(-79.9454937651895,-711.656358704039 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark35(-80.04551544063764,-61.40392107348966 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark35(-80.1068833940306,0.0 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark35(-80.10798282590092,-746.0727902481706 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark35(-80.11434193904884,0.0 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark35(-80.3524277944903,80.960704367756 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark35(-80.38732213321038,0.0 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark35(-80.44399759378638,-746.0 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark35(-80.8173885604823,726.0858463846301 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark35(-80.83722849150199,-45.740110194138836 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark35(-80.86333907765997,0.0 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark35(-81.25307459992305,-746.0 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark35(-81.3108160210244,-10.973478694033375 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark35(-81.47054057517562,-746.0 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark35(-81.52508674761853,-80.16698818455133 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark35(-81.57206856877892,-58.146589775018384 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark35(-84.82300786482057,0 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark35(-84.83713430535771,-746.0 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark35(-84.9415399973488,-709.909135707913 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark35(-85.03265446996993,0.0 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark35(85.12304954099562,0 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark35(-85.12858661406794,33.311899756894206 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark35(-85.14533038009634,-709.2250847599921 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark35(-85.16705408645555,0.0 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark35(-85.21630006434837,-746.0 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark35(-85.25141983045823,22.566184081522152 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark35(-85.30464097823393,-709.9950972726907 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark35(-85.31981039720269,-709.1315936077917 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark35(-85.3467117859144,-1.7843963917983103 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark35(-85.53182461492838,30.78340709412882 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark35(-85.76421543660825,-40.19140625 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark35(-85.86267096351476,-709.6963453721762 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark35(-85.9274772990905,-709.0035500021418 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark35(-85.94043635731717,55.469549993353894 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark35(-86.04963902330442,-40.19140625 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark35(-86.25669781256471,-738.3391899528363 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark35(-86.26589874163861,70.64362781758874 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark35(-86.39207617252818,-746.0 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark35(-86.44638837264398,-746.0 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark35(-86.66209318314264,-41.55709520158906 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark35(-86.69168005430363,-746.0 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark35(-87.09668392738925,86.48487078357846 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark35(-87.34022116578558,-745.988143938661 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark35(-87.45253957919424,85.30462927360858 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark35(-87.46974237494182,-728.1484124082898 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark35(-87.59999206547953,-746.0 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark35(-87.76946040475818,0 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark35(-88.23886975330461,63.88999540340575 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark35(90.75742198198961,42.840205684064045 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark35(-90.75761386538355,0 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark35(-9.095403228559391,42.916895627875874 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark35(-91.11327876469643,-746.0 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark35(-91.34468192991517,39.38691893320333 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark35(-91.41208906660148,-709.2055601159933 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark35(-91.44466514220157,2.5340964066993763 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark35(-91.44768181398288,-730.2204784111082 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark35(-92.11655801402077,43.53157338735437 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark35(-92.19098693754229,0.0 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark35(-92.39340872315559,-709.7081302654951 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark35(-92.40012319684509,0.0 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark35(-92.67325400838976,21.571571173504744 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark35(-92.73821194678824,-709.6120209535829 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark35(-92.81797922157298,-67.61598350243645 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark35(-93.11228865999517,-746.0 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark35(-93.6236383051337,-7.606320401367601 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark35(-93.62597643521605,-745.200584649318 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark35(-93.80753773663055,-83.22878751875052 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark35(-93.96087034386447,0 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark35(-93.9979502787021,-746.0 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark35(-94.00774933512794,0 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark35(-94.10604239167823,35.57419632658116 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark35(-9.497032781769803,-709.6589145668362 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark35(-9.625345732448508,-709.1601694792597 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark35(-96.38786444154456,0 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark35(-9.737705697339774,-709.4016878625484 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark35(-97.39470388826525,715.9094447835017 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark35(-97.50656487230803,-746.0 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark35(-97.65560351029757,0.0 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark35(-97.70190245556103,80.13753556512006 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark35(-97.71087824448182,-746.0 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark35(-97.79155894328174,-748.685546934659 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark35(-97.8063577225637,-746.0 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark35(-97.83157246089296,-746.0 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark35(-97.89553872160923,-727.3171251505639 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark35(-98.00883000396261,-21.37824881771661 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark35(-98.12599583236887,-745.9383682223735 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark35(-98.18077737620831,-60.06500537869688 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark35(-98.30176282162972,-746.0 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark35(-98.50276941541892,0.0 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark35(-98.56371785232103,-78.78195237299374 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark35(-98.57706193133868,-746.0 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark35(-98.58217143986134,-40.19140624999972 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark35(-98.64047129015776,-758.0819616982327 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark35(-98.7573211865531,-721.1807379185375 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark35(-98.77234355337433,15.035893530463397 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark35(-98.79087646107506,-709.8627463239262 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark35(-98.90155967315376,-1.494140625 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark35(-98.95643931556934,0.0 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark35(-98.95973158249454,-709.1265259456372 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark35(-98.96073308917306,-709.55363234323 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark35(-98.96108656441136,53.3614809871267 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark35(-98.96211641366162,-765.4986817957652 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark35(-99.01627500960046,-746.1914064174707 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark35(-99.35229441842597,-92.23200381639715 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark35(-99.46248842008505,-709.6090795470525 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark35(-99.5694586473677,-720.1487537212147 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark35(-99.60436213065525,-745.9367168468785 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark35(-99.66158312285623,0.0 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark35(-9.973604195915957,-742.3978776973681 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark35(-9.97482780413182,-709.1301435939959 ) ;
  }
}
