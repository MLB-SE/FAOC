import org.junit.Test;

public class Sample29Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark29(-1.2209672403719907 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark29(-1.4941406249999978 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark29(-1.494140625 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark29(-18.999645536811897 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark29(25.20793054749231 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark29(30.381504900159882 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark29(-40.188964728168806 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark29(-40.190711560783164 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark29(-40.19140625 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark29(43.67128957649874 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark29(-45.97315306785978 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark29(-4.63331205597872 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark29(4.993467501257399 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark29(50.10820412211615 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark29(-51.03078090211972 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark29(69.05456443455446 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark29(-709.0261036312102 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark29(-709.2898983407438 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark29(-709.2991180321706 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark29(-709.3478835668864 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark29(-709.5456579911433 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark29(-709.6448652336877 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark29(-709.6510261223272 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark29(-709.711799161276 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark29(-709.8446947289474 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark29(-709.9843513563455 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark29(-709.9952014727963 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark29(-709.9996935539334 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark29(-709.9999337743507 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark29(-719.1450593882713 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark29(-721.3065426397397 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark29(-723.4174391072404 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark29(-731.8084023683133 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark29(-734.9367124123381 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark29(-739.9436055532534 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark29(-740.5814823132969 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark29(-74.37732376912696 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark29(-744.2656574752139 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark29(-745.4195638433965 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark29(-745.9624211327088 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark29(-745.9999999991668 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark29(-745.9999999999027 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark29(-746.0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark29(-746.0000000021138 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark29(-746.0000000927987 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark29(-748.191406250025 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark29(-750.1914062749474 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark29(761.6590376029823 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark29(-763.1720230402785 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark29(-98.79882580835209 ) ;
  }
}
