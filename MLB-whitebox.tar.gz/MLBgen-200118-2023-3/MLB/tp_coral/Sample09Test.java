import org.junit.Test;

public class Sample09Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark09(-0.0021275785020388417,268.2709005485639 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark09(-0.004402385351051947,129.64208759290594 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark09(-0.005697795580280596,100.1662974962092 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark09(-0.0057079418484630665,100.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark09(-0.006054674019373318,8.0948E-320 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark09(-0.006384587183449952,89.40205438452955 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark09(-0.006778643035052228,-101.95051416507401 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark09(0.008474208027416535,-67.35689051874421 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark09(-0.009047099243347663,63.091635161736555 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark09(0.009343608367424712,-61.066878792870845 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark09(-0.01424073320248001,4.299802481146414E-15 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark09(-0.01855826371681424,84.64134095538888 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark09(-0.019138017369241478,82.077275638775 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark09(0.019965537340354,-78.67538448965352 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark09(-0.020839960231100102,75.37424780930002 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark09(0.023243647709324966,-67.57959621650603 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark09(-0.02839245679288327,55.32442430936871 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark09(-0.02976965963264555,52.765007936884444 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark09(0.030699330400892462,-16.595461942468212 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark09(0.03129567411868597,-18.23881290106549 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark09(-0.03397150384910834,16.79912840859867 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark09(0.03553950989772914,-23.396157137420808 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark09(0.05510838823041717,-28.503760992376343 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark09(0.06685713476810974,2.3392027300222657E-15 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark09(0.07026998759009118,-22.353729958768213 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark09(0.07191837132506862,-6.661338147750939E-16 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark09(-0.09850282141859878,1.134371570609403 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark09(-0.11081883547127225,14.174452565891624 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark09(0.15662036889394937,-10.029323375291707 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark09(-0.16053084100844842,9.7850127547281 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark09(-0.18360472910441156,8.555315184183641 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark09(0.1870233132158282,29.601404563865064 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark09(-0.19179141261327234,8.190128564109623 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark09(0.2268021253409067,-6.925844828101873 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark09(0.23882689036426943,-6.5771334391996135 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark09(-0.2439982407269048,6.4377362808652805 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark09(-0.25973795584736614,6.047619500470574 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark09(0.26677584197191434,-2.139578712949437 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark09(-0.3073550693584135,9.860761315262648E-32 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark09(0.38696074831839455,-4.059316955585459 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark09(-0.4042022854398462,3.8861638921353006 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark09(-0.44219281108202146,1.3241306820055883 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark09(0.5135217082272522,-3.0588703488650992 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark09(0.5514638519971573,-2.8484121327375647 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark09(0.5648606225012287,-1.2263709145961426 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark09(0.5657900435166283,-1.2079226507921703E-13 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark09(0.6032907198120654,-2.6037137240967745 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark09(0.6396250133572847,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark09(0.6413276988263362,-0.8900228219366737 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark09(0.657381324451944,-47.82990033460399 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark09(0.6789931031126384,9.885798470726396 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark09(-0.6874797767358416,2.284861867869113 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark09(-0.690732448964738,4.077267988837896E-4 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark09(0.7756400534782696,24.34061802727056 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark09(-0.8464895814556803,46.391484349212234 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark09(100.00602574367487,-0.005707617863107558 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark09(-100.0,19.302683630280928 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark09(100.0,-25.331417012636503 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark09(-100.10746569103374,55.185157333618235 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark09(-10.106223657204726,58.49763821328126 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark09(-10.164733978764783,74.83064116871489 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark09(-10.256045256928516,0.15315809236837544 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark09(10.440281649310464,-0.15045535930523876 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark09(1.0635145461157365,-5.757546070338759E-17 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark09(1.0658141036401503E-14,-1.3217995619375813 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark09(-1.0658141036401503E-14,1.9027244086062751 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark09(-1.1102230246251565E-16,107.24987308900656 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark09(1.1102230246251565E-16,-8.551531886830048 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark09(11.118665060483579,-20.76922901278931 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark09(-1.131545841632601,1.3881862042182422 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark09(-11.57930844124418,1.1102230246251565E-15 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark09(1.1623169371400635,-1.3514354618800581 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark09(1.1715487527645791,-0.356090392001003 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark09(11.941369120426543,25.482389983328886 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark09(-12.081784337008926,-57.151432207487105 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark09(-1.2113360073876578,3.552713678800501E-13 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark09(1233.4816487343242,-1450.048274521816 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark09(-12.396696615760817,-75.70174103149041 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark09(-125.57592195817757,66.30085766849905 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark09(1.2650745996274537,-1.2416630033180667 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark09(-1.265425080748859,1.2413191035105164 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark09(-1.2789769243681803E-13,10.944923204762873 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark09(-1.2789769243681803E-13,18.95393073001604 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark09(-1.2909452611180683,15.033700431705547 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark09(13.068126289592328,-0.12020057749563566 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark09(1308.558554794426,-1369.5450946695973 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark09(-13.270403170072996,8.881784197001252E-16 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark09(-1.3500311979441904E-13,0.8683949703682146 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark09(-13.8217126518106,0.11364701078408945 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark09(-1.3877787807814457E-17,29.76412609412887 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark09(-13.907895073187776,0.11294277951687626 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark09(-13.983743897938748,72.34319018074183 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark09(1.4207650859533487,-4.263256414560601E-14 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark09(1.4210854715202004E-14,-2.6606513034257127 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark09(14.253048806898903,-0.371029689392115 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark09(14.424318083429938,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark09(-14.479091001500308,53.45541885646227 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark09(-14.571249392822068,0.016907723045376688 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark09(-14.652197709913011,0.10720550991010497 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark09(-1.4678822315452655,1.0701105940503766 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark09(148.1140512527931,-73.55974949843474 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark09(15.610280045998167,-0.10062576213663663 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark09(1.5631940186722204E-13,-0.021871725505384416 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark09(-15.883023918818708,0.09889781283611643 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark09(1.6342482922482304E-13,120.52000575279428 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark09(-16.395805085848394,0.09580476948647565 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark09(-1.6418147205193505E-288,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark09(-16.779441011618218,85.29287706402411 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark09(16.98566549755529,-45.580001455523515 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark09(-17.31253584886501,-70.11760041551295 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark09(-17.592500689952374,78.21622784177887 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark09(17.71885895446917,-47.186084491687865 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark09(-18.09482017293466,133.35878536391735 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark09(-18.46024881936242,0.019205271816919833 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark09(186.40740067690618,-0.0030620696807304934 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark09(-19.051169194854324,0.08245143963233215 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark09(19.67342934802684,-0.0308753342013363 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark09(19.752619067115482,-0.07952344554702506 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark09(-1.9856623128752062,0.7910692148457052 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark09(20.204167918833775,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark09(-2.0314918012479652,0.7732230697805136 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark09(20.544473527156903,-93.60490150327954 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark09(-21.27823925713002,0.24853110296437347 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark09(-2.159006501571805,-7.993605777301126E-15 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark09(2.181376247978573,-0.25329519200469197 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark09(-2.220446049250313E-16,3.3738550910840104 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark09(-2.220446049250313E-16,5.131226546936276 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark09(-2.231962034278851,1.3322676295501878E-15 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark09(-22.3353697654358,0.07032775115393619 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark09(2.245176584848906,-4.9E-324 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark09(2.3388602218848717,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark09(23.699192460175507,26.53334197029338 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark09(23.77159970664225,-16.674553534655118 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark09(2.388558889144335,-0.6576334935404446 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark09(-23.999862435565376,0.0 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark09(-25.704015485756997,3.2893583754280885E-18 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark09(-2.6645352591003757E-15,16.9464079643723 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark09(2.7000623958883807E-13,-0.14185549899517014 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark09(2.7354883422679848,-0.5742288506675024 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark09(-27.54109085591081,4.440892098500626E-16 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark09(-2.808503942467497,0.5593000255555367 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark09(28.131347059970636,-0.055837934935936584 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark09(28.41253101752426,-97.40224670726865 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark09(2.8631896312631966,-0.5486176359551442 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark09(2.8876861040167436,-54.594032497768545 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark09(-2.894004118700977,0.5427761199938388 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark09(-29.5661220969808,44.468345264040806 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark09(-29.63780335980799,-7.588939439036665 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark09(2.9960436902955063,-0.5242901937254345 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark09(-30.023284629984843,82.13809141139913 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark09(-30.051133279766418,15.263069376423212 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark09(30.200423210648694,-55.63642141266687 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark09(-30.666075727082017,0.05122260639980358 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark09(-3.0916993585060246,0.5080689111873862 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark09(3.180079904601854,-0.49394869749084336 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark09(-3.240411324429431,0.48475214086331503 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark09(33.06035350304508,-0.01726073042454445 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark09(-3.371060178096002,0.4659650803629656 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark09(-3.548075327109224,63.85702850266658 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark09(-35.512049263008535,69.54889424022619 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark09(3.552713678800501E-15,-41.84128762669095 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark09(3.552713678800501E-15,-55.207974796648166 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark09(-3.552713678800501E-15,7.616107176159375 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark09(35.57886089741359,-0.044149708202408634 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark09(35.8078966262727,-6.72264031387151E-13 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark09(-364.7050347194905,344.5980257119651 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark09(-36.66844199468899,11.139556392572047 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark09(3.6802139561410883E-6,-38.53250392841105 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark09(-38.064510433610145,15.035043532755992 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark09(-3.8231389001524168,1.6016247789199218E-17 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark09(-38.686262285202965,70.32642490534872 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark09(39.779865473643234,-5.067721094451188 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark09(39.98660361813108,-0.03928306444317897 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark09(-4.002245060054737,0.39247879708130956 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark09(-4.0026402276775315,0.3924400489289856 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark09(-4.019286670800696,0.3908147030681768 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark09(40.27593420361106,-81.27780546297231 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark09(-4.267068233022854,0.3681207426303847 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark09(42.699733270279076,-136.44309062083732 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark09(43.13788297170993,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark09(-4.4298682909433375E-4,2.0415299389846072E-13 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark09(4.440892098500626E-16,-21.152320812342126 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark09(-4.440892098500626E-16,24.737310601508455 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark09(-4.440892098500626E-16,36.39884052235982 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark09(-4.525630992453216,0.34708890968227446 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark09(-45.44280824524491,0.034566444888653264 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark09(-46.02217419036505,27.725091818621706 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark09(46.49306059246925,2.060922097044596 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark09(-47.41106764714691,-95.23892504363774 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark09(47.54698409596273,85.16272224853196 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark09(48.06982582180805,-0.8053375417681536 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark09(49.85610853281074,-87.07289426326102 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark09(51.74588509954303,-0.011739560002886904 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark09(52.00777320699527,-37.22268185251727 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark09(-52.43328201511473,64.08813160161381 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark09(52.510861528777895,-2.9999750933743696 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark09(5.329070518200751E-15,-2.3956982382111676 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark09(-5.3425632081366246,2.220446049250313E-15 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark09(-53.732472750394344,0.029233650461086745 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark09(54.15797733027526,24.410466474872266 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark09(5.465193414253091,-0.10444087235139672 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark09(55.162568125706855,-10.614806836069548 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark09(-5.532481145593721,38.710575658111736 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark09(-5.670036734738944,-14.494299546724857 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark09(5.674416393494226,-0.27682077201733346 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark09(57.05691575376846,-23.153016381112074 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark09(-57.369171321339174,2.220446049250313E-16 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark09(-57.423287779863585,-57.73946232935756 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark09(57.987029146796004,-32.53539733255917 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark09(58.56142179127056,-84.8877162878877 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark09(-5.9159697693664395,0.2655179772771419 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark09(-59.66750901376214,0.026325823765034277 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark09(-61.03617566680515,59.607708517673316 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark09(6.162975822039155E-33,24.84562501275572 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark09(618.5815209910613,-434.9930272534054 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark09(-62.35444506505894,-13.228708407003069 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark09(63.14723403980855,8.083160117047544 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark09(-63.30470463546434,0.024813263656155993 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark09(-6.335329393430683,0.021459747099514814 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark09(6.501964477697088,-0.2415879588673564 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark09(-65.06149807101237,6.184363409543442 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark09(-65.24742985803162,28.62377311596066 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark09(65.69670953900462,-12.646976949148218 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark09(-67.18383409591752,57.339428633300116 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark09(-67.45496465243409,18.536128253439376 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark09(-67.62470215304886,-60.78887427696016 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark09(-67.67580672383346,90.69950164571517 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark09(6.855853658469371,-0.01957001111442245 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark09(68.96368995799156,7.070872829551973 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark09(-6.903203898028323,0.011908673110891268 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark09(69.45414411085542,-1.591294905359078 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark09(-69.5118767467128,42.58869005286792 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark09(70.33697652505656,-3.9528419272280217 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark09(-71.00419881026328,20.647487922449443 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark09(-7.105427357601002E-15,0.6821144616741037 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark09(7.105427357601002E-15,-8.733823201702052 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark09(71.9964334933462,-30.195878368796564 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark09(-72.71261583591881,50.829389868334886 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark09(-73.55034101738987,-65.03158193452882 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark09(73.8844137621226,-11.233103365299772 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark09(-74.65407314752092,18.533478943030374 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark09(-76.65432298690509,49.342799964636015 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark09(77.6935459164829,-71.82114399953582 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark09(-7.783323397485816,1.4210854715202004E-14 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark09(78.30579364869024,-1.3322676295501878E-14 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark09(-78.38735137115911,2.8928833978780575 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark09(78.72455617084177,-14.289923999127879 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark09(78.94702602629205,-0.007230028668881558 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark09(-7.945232906271201,0.19770299314385387 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark09(80.14090855379484,-94.59449087861071 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark09(80.19770841534083,-0.019586548765954802 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark09(-81.66055568661838,4.174142509712249 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark09(82.94484266285545,-0.006881637091282607 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark09(84.45659585957833,-40.173717838723924 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark09(-8.485186135371363E-15,0.008993966590653601 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark09(84.91093945767625,-48.617224843393366 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark09(-85.24505718779608,0.018426831755586834 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark09(-85.36049857537421,0.006686838405921158 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark09(86.40801620485544,-16.738023073548263 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark09(86.88110435473001,-63.64584557464181 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark09(87.30864943187387,-199.41559791988678 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark09(-87.51858176816066,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark09(8.805994482703927E-18,-6.953483797614869 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark09(88.06908579764979,-0.017835955858608615 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark09(88.2564568716518,1.1955042418031984E-18 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark09(8.881784197001252E-16,-11.926200280226055 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark09(-8.881784197001252E-16,18.587616025348723 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark09(-8.881784197001252E-16,2.07394852099884 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark09(8.881784197001252E-16,-9.109718981992714 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark09(88.98262826388759,97.11048423621915 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark09(-89.12009941770623,32.57699168736277 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark09(89.72211046443795,-1.8319903116981209 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark09(-90.45312913064313,112.26548922124519 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark09(-91.0311044950297,34.5929484671191 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark09(-9.23178938882117,0.17015079749295225 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark09(92.3544391754653,-0.017008346765124326 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark09(-92.61624277593458,26.03340606819077 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark09(9.313885486933644,-0.061284447569674244 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark09(-93.76125879405741,67.36411704315589 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark09(9.414691248821327E-14,-3.340794567220968 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark09(-94.53995383114987,68.733443670707 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark09(95.16487558026512,-37.57971192753217 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark09(96.29436154865647,29.843112514881938 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark09(9.636133739173005,89.67433756322552 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark09(97.29739506923953,-42.9599273714028 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark09(97.50642335683543,26.695648071885202 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark09(98.85685518994636,-46.07985293731473 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark09(-98.94486522859165,32.13671255985628 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark09(99.70171975238796,-0.005716973926281554 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark09(-99.7771821565633,3.467962948962115 ) ;
  }
}
