import org.junit.Test;

public class Sample07Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark07(-0.0010001363863144101,-0.0019879562804523943,-71.35858146673519,94.32471019371036 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark07(-0.0011705122126239207,-1.5777218104420236E-30,-0.4714443037208387,0.7853981633974483 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark07(-0.0015949412170559903,-0.00318988243411198,0.5391031211282111,-30.87020130640519 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark07(-0.0016714977787186593,-6.734282997911123E-8,0.7759759391379951,-0.7853981297260333 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark07(-0.0020178373198828092,-0.004035674639765585,-75.29750743425039,0.7874160007173311 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark07(-0.0021008704982962145,-0.0041824365841843306,-24.57678264928074,0.002091218292092162 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark07(-0.0025004467764903784,-8.881784197001252E-16,-49.47747690736303,-25.747270603335885 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark07(-0.0032274895557575234,-0.006454979111515012,-83.52514627431631,-60.734057037553505 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark07(-0.0036469445332460992,-0.007293889066492053,-0.7835746911308252,66.27022328097476 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark07(-0.0037171449446289605,-3.944304526105059E-31,-128.01853542744348,0.7853981633974483 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark07(-0.003914663261098114,-0.006505533596753765,0.0019573316305487864,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark07(-0.005097734976200696,-0.010195469952401367,0.002548867488100348,-30.82085464082877 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark07(-0.006178716702770225,-0.008057276121174005,1.3610895931764162,0.004028638060586956 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark07(-0.0062074557011778525,-0.012414911402355703,-49.47694202382133,71.32262259274077 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark07(-0.006333889582964658,-1.3306440458217372E-15,0.7743298650921104,0.785398163397449 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark07(-0.0063571713686911835,-2.4981421837130933E-16,73.75252595270847,1.249000902703301E-16 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark07(-0.007068812373249689,-0.010389545765124096,-76.11769292911303,50.7652580004479 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark07(-0.007073881808492111,-0.014147763616983092,-2.8269789666795533,99.99991421697028 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark07(-0.0073886066184807855,-6.416745306609099E-4,0.0036943033092403928,-38.49871490975039 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark07(-0.007402688233709931,1.1466367408118954,-1.214537176848487,100.0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark07(-0.00907703298550111,-0.018154065971002217,0.004538516492750555,-100.0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark07(-0.009213688464431803,-0.018427376928863603,4.4415613739755,0.009213688464431801 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark07(-0.00921578442185686,-0.0023532695629717533,-0.7778396602730172,-117.80854836397594 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark07(0.0,1.1102230246251565E-16,3.3877010841264243,-5.551115123125782E-17 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark07(-0.011410225090680848,-1.460694962876911E-12,-20.59872149960924,13.475568946159305 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark07(-0.011456346011060183,-6.159360158157135E-17,-0.7796699903919182,-0.7853981633974483 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark07(-0.011560698609155626,-0.02310815988824611,-8.603920503745803,-57.342045834451795 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark07(-0.01303612150314637,-0.026072243006292684,0.006518060751573185,88.84478760690739 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark07(-0.013104141616760545,-0.02620828323352104,2052.1907221169017,0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark07(-0.014936076355100606,-0.0026526057667686934,-0.777930125219898,0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark07(-0.016140990434472036,-1.8473944678576437E-4,-14.004168416033146,0.0508764245268587 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark07(-0.016344398292843208,-6.938893903907228E-18,0.008172199146421604,-0.7853981633974483 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark07(-0.016347886254693744,-0.03269577250938747,-0.7772242202701838,43.20755103959567 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark07(-0.016843885171489915,-0.03368777034297967,0.008421942585744968,-31.56523151147963 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark07(-0.01744065376191628,-0.03488130752383212,-61.61088911142963,9.345181216931167 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark07(-0.0176368279134253,-1.005517250319499E-10,-35.27312569713303,4.384238091781583 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark07(0.0,1.9721522630525295E-31,1.8254606193994668E-15,38.58692482843322 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark07(-0.02049497689266211,-1.8594030823930936E-16,-25.89190803927567,100.0 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark07(-0.02120194389801713,-0.042202125481889514,0.010489064177609963,-11.098220525774193 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark07(-0.021417051411957988,-6.938893903907228E-18,-65.70592166909981,-18.719592563302918 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark07(-0.0227468384114308,-0.023902566987974664,-43.04521474394264,0.7973494468914356 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark07(-0.02401720674816791,-0.047717364061126276,0.012008603374083954,-166.47226861232272 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark07(-0.024977812040532767,-2.7755575615628914E-17,54.27929940379689,1.3769367590565906E-17 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark07(-0.025420391925803254,-0.03292799343481997,0.012710195962901627,0 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark07(-0.025661048087849858,-2.285409072740254E-16,-1.0160486335051524,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark07(-0.025744371285486598,-0.050880578854851505,0.6388904431666029,2153.844733755918 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark07(-0.026062884566178224,-0.010789734667450288,-147.6268811039963,-14.029648606847672 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark07(-0.026624248265295154,-0.006536792031121996,86.8395349235466,0.0032683960155609985 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark07(-0.027373849057484634,-0.054747698114969136,-17.686953810925242,0 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark07(-0.02821962884118534,-0.04127173239256211,-8.581730753927339,-53.25821494551883 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark07(-0.03159456874772615,0.05142327986852674,-95.08155662448362,31.390211028239595 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark07(-0.0323036207153482,-4.025622105463018E-11,-0.7692463530397742,-31.000872789328902 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark07(-0.03259654151214472,-0.004939823475749061,0,0 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark07(-0.032704213985950865,-0.06540842796502307,-52.59367979798434,-0.7526939494139115 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark07(-0.03288406202647439,-1.6675541494138261E-16,0.016442031013237195,8.33777074706913E-17 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark07(-0.03672977780559794,-8.37345192928079E-11,0.361746644916277,4.1867259659156275E-11 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark07(-0.0372726906918977,-3.671837256778679E-14,0.01863634534594885,-5.208786894660364 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark07(-0.037820080059023396,-1.8442232790080677E-10,0.018910040029511698,78.7373202928528 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark07(-0.04065933958207779,-2.220446049250313E-16,-62.04086592197111,-194.67004409276265 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark07(-0.04174680684644931,-5.467269269880247E-13,-17.54766161481501,2.7335772534442526E-13 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark07(-0.04327531093169341,-0.07970123779687555,-5.763783472164767,0.03985061889843777 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark07(0.0,4.518281109477948E-17,0.5068081138235215,-57.35995438993554 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark07(-0.04617602329624049,-0.09235204659248089,-0.7623101517493281,0.8315741866936843 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark07(-0.04639527323617543,-0.09279054647235059,9.690557808686734,46.65555738766456 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark07(-0.04772551384857149,-0.005504938356746703,-0.7390701384278846,0.002752469219484417 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark07(0.04835902322825669,-6.516062813570605E-14,0.7612186517835227,0 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark07(-0.04900526339170774,-5.391113551620147E-15,-20.62863643370931,-2057.7787859076116 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark07(-0.04914127544744576,-1.1977428186488612E-14,-0.7608275256737254,5.934575334622232E-15 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark07(-0.04974812686756602,-0.09949625373513171,26.355491348859843,14.069820070350815 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark07(-0.05018561740842773,-1.5836304642160749E-16,-0.2760553489520351,-62.80367060481578 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark07(-0.05100029260967176,-0.10200058521934294,-60.39194342252166,-5.963907939608163 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark07(-0.05111505893672996,-0.10223011787345986,0.7610951211606093,0.1927170382633315 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark07(-0.054142009825714155,-6.938893903907228E-18,-25.83742713750973,-0.731256153571735 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark07(-0.05583425528738939,-5.720521846223994E-14,-72.88834961151916,-57.47046411106338 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark07(-0.05673317290691452,-0.03856957965595907,-51.67797453384776,100.0 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark07(-0.05789001727171106,-3.944304526105059E-31,-1.4305112242271747,0.7853981633974483 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark07(-0.05796007934402814,-0.04371199429025902,0,0 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark07(-0.05909402060628466,-0.07362725304187273,-30.897860011493442,0.8025472053594376 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark07(-0.05966844529801257,-0.11933689059602509,0.17643824869912977,-65.26649600821305 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark07(-0.05972983594517567,-2.220446049250313E-16,0.029864917972587612,-73.70252136346184 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark07(-0.059997408028573895,-0.11999481605714782,60.2161979772838,-100.0 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark07(-0.06346591165619625,-4.932165786897258E-13,-0.7536652075693501,-100.0 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark07(-0.06462680421751776,-0.12925360843503547,-90.32946598402458,45.46707314300334 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark07(-0.06470426963345055,-0.32412601163854976,-146.60521242091198,-213.1895042129053 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark07(-0.06491261195909229,-0.12982522390436282,-81.56021538901989,100.0 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark07(0.06492056088614465,-0.5480921499479534,-52.65159747456822,114.94569871740914 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark07(-0.06538728306656905,-0.130774566133124,22.21914991711255,0.065387283066562 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark07(-0.0669205721355518,-2.9318746943321185E-12,0.0334602860677759,-65.1066618563323 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark07(-0.06724092387046121,-0.04619769636039008,-54.19981894289106,0.8084970115776431 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark07(-0.06903257894117942,-0.1240763021288634,-49.36862223339503,0.8474363144618806 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark07(-0.06916166687817965,-0.138323333564814,-87.14458997306394,-0.6418971862408742 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark07(-0.06969818641041772,-2.7755575615628914E-17,70.05001146791216,-75.72017231481038 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark07(0.07155581585147541,0.1431116317029509,-71.3792533262969,-0.8569539792489237 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark07(-0.07283098419639822,-0.05697489163023228,-98.97788540310077,-3.389769255731503 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark07(-0.07321446160892468,-0.13845494722619728,0.8220053777097555,0.854625637010547 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark07(-0.0745450701331698,-7.888609052210118E-31,0.7853981633974514,0.0 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark07(-0.07527717515069811,-2.7755575615628914E-17,4.449791140358589,100.0 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark07(-0.07755506396540875,-9.478050023617986E-4,8.057145908225051,4.7390250118089925E-4 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark07(-0.0786233058541923,-0.045048289063879754,-0.06821871694610238,37.32712533534263 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark07(-0.07887347238547653,-0.117979039248122,-6.556196260101915,61.29166850044387 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark07(-0.07898610252800431,-0.1579722050560073,-0.7459051121334461,-1995.0434393738346 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark07(-0.07943113889031962,-6.068735939062751E-4,-35.22423048834252,-63.661236224561705 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark07(-0.08112924179529807,-0.10846882120324741,-0.43382196533821116,65.73471787183583 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark07(-0.08146858984553429,-0.16293717969106808,0,0 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark07(-0.08155174620163338,-4.9452417589873595E-18,-99.63913014682267,0 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark07(-0.08202516701799478,-3.552713678800501E-15,-128.72396038468804,-76.17075178111291 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark07(-0.08312869670209011,-0.1662573934041447,0.041564348351045055,99.82526664188337 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark07(-0.08490610301859292,-0.16981220603717945,-19.46031081174296,-71.31602791933585 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark07(-0.08604314536450021,-1.030491720605137E-14,-3.8773113225891715,-5.8617743427230025 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark07(-0.0864800256798614,-2.5903462636488406E-4,0.0432400128399307,-44.41076426073548 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark07(-0.08673386611704803,-0.17346773223409492,5.589944822151338,0 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark07(-0.08739848879360282,-0.1288414734087624,-0.7416989190006469,-10.962878587353169 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark07(0.08978095749374958,-4.415947190626731E-16,-1.493260549938455,1.6653345369377348E-16 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark07(-0.0903022258222261,-8.676831936868554E-16,-0.7402470504863352,-0.7853981633974478 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark07(0.0934691508951915,0.18693830179925106,0.08263168673135615,-18.08038965607884 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark07(-0.09459575085910199,-1.3322676295501878E-15,-6.7912497426750384,89.47613048826285 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark07(-0.09675432500263337,-0.1930045014908925,-0.7370210008961317,-39.95748916219869 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark07(-0.09727383292077385,-8.952838470577262E-13,0.048636916460386925,-100.0 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark07(-0.0985464607754385,-0.19701302791156983,0.4796123884916549,-56.63423725001478 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark07(-0.10050253130023697,1.0573807753756583,-2.493841271999479,-71.21431745196115 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark07(-0.1019458122261207,-0.00708259834340242,-100.0,-44.22105735766185 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark07(-0.10297820024248816,-0.14374971331405675,-47.06159221697423,-85.46507199324078 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark07(-0.10409963532620166,-0.031092321153680175,-36.165534733838655,-7.294884015975041 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark07(-0.10537467167924022,-0.18123310037148532,-0.7327108275578277,-0.6947816132117056 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark07(-0.11640323946870357,-0.21949608189784364,0.05820161973435184,16.818502712725394 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark07(-0.11891482015721744,-0.23782964031443476,-46.26770872179263,0 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark07(0.11909986454795342,0.4766910745727371,-12.794998858396175,-60.712068234848175 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark07(0.12085248677586502,0.50886650522855,-100.0,-100.0 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark07(-0.12316719360453485,-1.8810212041430507E-12,-0.3926990816987237,-26.709871417841285 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark07(-0.12389442870650491,-0.24601099195524123,-60.58998802789345,42.24898183538081 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark07(0.1244659316986913,-0.5235987755982981,-0.444677870285364,100.0 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark07(-0.12448806307760558,-1.2976651386789559E-8,0.7853981633871444,-10.455427165592297 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark07(-0.1250799229998172,-0.25015984599963437,-29.54791425520946,65.42551241766968 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark07(0.12654286690034586,0.37893982602791865,-43.94986468682613,-99.94003537644505 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark07(-0.1274845178482683,-5.551115123125783E-17,0.7882089227665301,-25.904678313165174 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark07(-0.12758333552012374,-0.09985379539900723,-0.17428537015655365,0 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark07(-0.12969851988879186,-1.7089845528353727E-14,-0.7205489034530519,-2085.7372547436557 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark07(-0.1308806414029895,-0.19210816068312653,-70.94837454774628,-0.31836088780684935 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark07(-0.13224865954544196,-0.26449731909088386,73.31239450159818,0 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark07(-0.13445715657308988,-0.26891431314617964,0.06722857828654494,0 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark07(-0.13463038882480727,-5.666205411595051E-15,0.1498473639937885,-64.58839194065811 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark07(0.13512560473946414,-3.469446951953614E-18,-0.8529609657671804,0 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark07(-0.13534861166376033,-0.013280128479621234,0.34805782273160835,111.97506317428909 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark07(0.13543686238239439,0.39114621300217367,-0.06771843119119719,6.874499154406903 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark07(-0.1388561239576092,-2.220446049250313E-16,0.06942806197880458,31.84319007981898 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark07(-0.14056248032580554,-0.2811249606516109,-47.216140023003085,41.83718081580342 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark07(0.14145660764046394,0.7423907362907293,-35.373429663450445,90.73899990352297 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark07(-0.14171753091703154,-0.17223860967812665,16.508913050048807,0.08611930483906333 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark07(-0.14255032269490084,-0.28510064538980023,0.09443858140357105,0 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark07(-0.14369937314427794,-0.09144523460002812,0.8572478499695871,-0.2741981338345869 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark07(0.14398999312299876,0.3089853469558155,-75.25229808165805,-196.8201574675361 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark07(-0.14821705518128514,-0.29643411036257006,0.07410852759064257,-1984.653942215812 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark07(-0.14882253038599016,-0.2618609323150274,0.07441126519299508,0.916328629554962 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark07(0.14970928993800928,0.2994185798760554,11.800560738004792,0 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark07(-0.15028763496812375,-0.30057526993624745,-27.294898929838602,90.15175935152034 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark07(-0.1510601301479718,-0.3021202602959388,-46.42493607632264,0.15106013014796937 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark07(-0.1529143014833396,-0.3031075010233728,0.07645715074166992,-82.15238922573273 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark07(0.15554316294018625,0.311086326290997,92.89187947296253,-0.1555431631607183 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark07(-0.1564550952977792,-0.07301208246685892,0.0782275476488896,0.8219042046308777 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark07(-0.1569554037402407,-1.1317406851641947E-14,0.07847770187012038,34.66280181283364 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark07(-0.15779386942779416,-0.06348573179080122,-62.42047435548961,0.03174286589540061 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark07(-0.15941086145193126,-0.06768847458060058,-0.7056927326714835,0.8179274803683142 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark07(-0.15943689580623055,-0.2668432464794288,0.7843910974538026,-100.0 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark07(-0.15960979937761266,-0.05450353638515707,-67.90602779924788,-31.55812365995798 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark07(-0.16378106300027281,-0.21440430226349666,-0.005415429197979785,-100.0 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark07(-0.1644896941384738,-0.3289793882769475,0.18194657656550406,-100.0 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark07(-0.16473653485751102,-5.551115123125783E-17,-99.15829410790236,-100.0 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark07(-0.16512708793349215,-1.1102230246251565E-16,-50.69213700048171,5.551115123125793E-17 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark07(-0.16552410437125803,-0.331048208742516,-99.79187465019447,36.20251736527126 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark07(-0.16554708329115916,-2.1691468382983067E-25,-100.0,0.7853981633974483 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark07(-0.16613250239298244,-0.07976688458301308,-52.97994181992372,0.8252816056889548 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark07(-0.1674894725226247,-0.33291421766712426,-0.7016534271361359,0.16645710883356216 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark07(-0.16883020301369522,-0.00803548478745909,-0.7009830618906007,100.0 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark07(-0.1706318096593937,-0.2872608958717901,0.08531590482969685,-7.7103665757976305 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark07(-0.17312708284910072,-0.3459296631014672,-5.874970394675511,0.1729648315507336 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark07(-0.17318793025656998,-0.002908891436806005,0.08659396512828499,33.121471124479456 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark07(-0.17356819408049073,-0.32839538101418486,-86.37551857019515,0.16419769050709243 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark07(-0.17471305186019623,-0.0748660950761284,-0.6980416374673502,61.2209233371918 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark07(-0.18278849702508992,-5.863040419788138E-14,-77.83772026162396,134.3833433263091 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark07(-0.18411851844966354,-0.368237036899327,2389.4602091148686,0 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark07(-0.18482984103594127,-1.6653345369377348E-16,-0.07316586872750615,-73.34613627606875 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark07(0.18734612595400923,0.3746922519080187,-0.09367306297700462,0 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark07(-0.18972296541048583,-0.12698033006912396,-14.820233536060186,0.848888328432011 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark07(-0.18999332454885243,-0.37998664909770474,0.7412830131843996,-88.17586905304526 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark07(-0.19068110168120952,-6.938893903907228E-18,-68.6692092992507,10.515316204161808 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark07(-0.19269058146152168,-1.1102230246251565E-16,0.12186550177269609,0.7853981633974483 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark07(-0.19281833138249949,-0.38563666276499875,-100.0,-0.5925798320149489 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark07(-0.19316699868089832,-0.03730477946782562,0.8427453274034118,100.0 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark07(-0.19388747330001313,-0.36874629939762826,-0.3389564981926556,0.9697713130962624 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark07(-0.1948142901176464,-7.100487342539204E-15,-0.6879910183386251,44.78215087150765 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark07(-0.19583714928366094,-0.39167429856732183,-0.6874795887556178,22.099222729009 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark07(-0.1959722959926382,-0.3919445919852763,-0.6874120154011292,0.9813704593900865 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark07(-0.1965781777041199,-0.1960975034045731,0.05007819856097588,50.77444528466424 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark07(-0.19845741876027034,-0.396914837520535,-0.6861694540173131,88.87266602521792 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark07(-0.20135941611584404,-0.058196106123006006,-0.6847184553395262,0.029098053061503037 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark07(-0.20184434039783683,-1.1942390673583178E-13,0.10092217019891846,0 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark07(-0.203384150660738,-0.4067683013214758,0.101692075330369,-38.82850454766018 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark07(-0.20376892333387886,-0.4075378466677575,0.10188446166693987,0.2065746801040655 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark07(-0.2038237801710301,-0.3942887969800404,-0.6834862733119422,0.5659285300126694 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark07(-0.20688904683080855,-0.2712954810286625,-0.6267311997301606,80.40343174750556 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark07(0.20693506511002457,0.41387013022004937,67.2625432446564,-1781.097908179238 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark07(-0.20700902702030455,-1.506889066789282E-17,0.3926990816987228,-13.013861538523834 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark07(-0.20730434539111664,-0.4146086907822323,-0.04113775039795087,1945.1773854619923 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark07(-0.20745264944093478,-0.41490529888186845,0.7733447108924654,0.27756069380913395 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark07(-0.20803814169633253,-0.3050212578595361,0.3337503680949682,0.1525106288428305 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark07(-0.210708588940371,-8.371389880595208E-11,0.10535429447018552,124.88651392160882 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark07(-0.21372310089684377,-0.4274462017936875,-83.17182945310925,69.46364978822204 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark07(-0.21525379843439915,-0.43050759626551327,-0.6777712641802486,-36.808273462584 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark07(-0.21649790268921681,-2.83276944882399E-16,-49.752528231415745,-99.83267341097019 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark07(-0.21792362581142305,-0.4358472334251382,-146.7465846195155,-0.5674745466848792 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark07(-0.21882343608291857,-8.881784197001252E-16,-0.6759343440943466,4.440892098500626E-16 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark07(-0.22060800661503074,-1.7763568394002505E-15,-69.91043390834267,2013.3563963427616 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark07(-0.22088171526941203,-1.6263032587282567E-19,0.11044085763470601,-0.7853969152591366 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark07(-0.22262179838515225,-0.3147094007563311,0.1113108991925762,-67.83432894301261 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark07(0.22349846987579483,-0.014213670990262127,-37.016405116578774,0.0071068354951310635 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark07(-0.22465169015275865,-0.44930338030551675,-12.309489152397333,-51.334417992856054 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark07(-0.22665484054590435,-0.4533096810918083,-80.99791214270269,-42.36199497428545 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark07(-0.22764086969782493,-0.45528173939564714,-11.797786169816405,31.20077802777824 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark07(-0.22939829674348997,-0.0194886001283367,0.9000973117691933,94.74992832918254 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark07(-0.23036358277683533,-0.46072716555366355,-38.031823481828916,-20.903611231430347 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark07(-0.231023094027162,-0.002619446995996928,-0.6698866163838674,2251.5927559695924 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark07(-0.23223157236643327,-1.3877787807814457E-17,-6.513327770826578,-63.21333064293934 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark07(-0.23249733183637097,-5.551115123125783E-17,-53.436636376644806,-9.8480900816121 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark07(-0.23822181690192806,-9.940408080000296E-10,0.3685802533995798,0 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark07(-0.2392381032772847,-1.3171735637022866E-7,-29.7459179999431,1817.1768217891163 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark07(-0.24159866007828845,-0.48319732015657635,0.6501884993709849,-0.54379950331916 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark07(-0.2423797458987984,-0.11682980854814454,0.1211898729493992,0 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark07(-0.24343283251321252,-0.4868656650264248,-81.67728173102634,0.2434328325132124 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark07(-0.2436605594557568,-3.7628009760852643E-13,-21.28269967817817,0.7853981633976365 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark07(-0.2457417193570964,-0.49148268860528677,-0.6625273037189,0.2457413442844266 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark07(-0.2468786655745096,-1.757310814225704E-15,-0.0599816830986345,48.694761798425574 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark07(-0.24751162003358676,-1.1102230246251565E-16,-3.8857532679406517,0.5907201274736283 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark07(-0.2489785582504257,-0.31056486649583426,-66.14757534416707,80.43413116177264 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark07(-0.24984732058083547,-0.027610544935442516,-0.6604745031070305,-27.358601187548516 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark07(-0.2499553913318131,-0.49991078266362593,-83.29651532104108,99.80068105722675 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark07(-0.2502125373605447,-0.01605255727891825,11.451990232562444,0 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark07(-0.2518261339280131,-0.3242687569339825,-0.13674899403512264,0.1621343784669902 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark07(-0.2543113558716916,-0.47236177075000246,-83.9150244340425,100.0 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark07(-0.25573474419901343,-0.5114694883980268,-0.6575307912979416,95.93135678624489 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark07(-0.2562225842361814,-0.5124451684723607,-90.34949563369011,74.09653845506747 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark07(-0.2563647089071919,-0.5127294178143835,-58.86753560386548,0.1526530673453231 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark07(-0.2580946486029354,-0.2700191280702526,0.7705304854563625,-0.5235987755982983 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark07(-0.2600791801334452,-0.5201583602668891,-100.0,1.0454773435308928 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark07(-0.2601089598239712,-1.0070092293320328E-19,0.1300544799119856,93.46149125332376 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark07(-0.2605264067629497,-3.3362150553273295E-7,-56.772197903859585,92.28678450435771 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark07(-0.26065644815210104,-0.521312896304202,-68.08132787394023,0 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark07(-0.26089704435510025,-0.5208137947778777,-59.77350149008622,-0.5249912660085094 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark07(-0.261613057084066,-0.523226114168128,-7.786562071902782,-31.9480873266129 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179098181318106,-0.523581963456051,-76.76504191390742,84.43104911265551 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938479450016,-0.4961212511650527,-175.01350062991858,0 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877326076,-0.523598775465215,-100.0,16.674004963734905 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877983906,-0.523598775596767,-47.73144029522629,96.53339645055189 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark07(-0.261799387799031,-0.5235987755980619,-93.64000437023319,-18.68638935625702 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991216,-0.5235987755982429,-80.64153919062737,45.814892893999044 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991225,-0.5235987755982412,0.9162978572970095,0 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991367,-0.2573757835991682,-66.07482657644088,0 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991438,-0.5235987752695083,0.9162978572970193,49.55354190545937 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991438,-0.523598775598284,0.35897483776074246,0.945802336025853 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991438,-0.5235987755982865,-75.81398908244779,24.82023521856489 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914547,-0.5235987755982876,0.1308996938995728,-39.63633990379825 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914735,-0.5022154633368635,-0.6544984694978746,1.03650589506588 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914735,-0.5223577566823282,-68.74158594706931,0.5272596679689785 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914735,-0.5229017069143852,-74.48879931778882,-100.0 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914746,-0.5235987755982947,-0.6544984694978744,71.33245144697325 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914774,-0.5235987755982947,-0.6544984694978745,1.0471975511965956 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991479,-0.5235987755982932,-100.0,-0.5235987755983018 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914824,-0.5235987755982963,-26.52146927705706,0 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914913,-0.08446064212146934,81.97555295955212,-51.167175449189344 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914913,-0.09183816695517377,-32.707476585030115,-38.40061259725353 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914913,-0.40481777950382314,-48.555953235284655,0 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914913,-0.4206444514261347,-189.10844614931398,12.776692622617446 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914913,-0.5070510763634235,-49.84842738548989,14.669334550029813 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914913,-0.5189399872271954,-76.90478141256841,-94.1034881945762 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914913,-0.5200283782608509,-52.6989792400023,-73.05529638205952 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914913,-0.5235987755899477,0.13089969389957457,1.047197551192422 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914913,-0.5235987755982867,0.13089969389957457,0.2617993877991433 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914913,-0.5235987755982969,0.130899693899575,45.1062079614868 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914913,-1.3876152353277504E-17,0.13089969389957457,36.913760538359966 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914935,-0.5235987755982983,0.13089969389957468,0 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914935,-0.5235987755982983,-0.6544984694978736,71.77920370569605 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914935,-0.5235987755982987,-0.6669276689265421,-34.77464407260184 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914935,-0.5235987755982987,-0.7772295934386163,53.002042609083624 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991494,-0.5235987755982987,-0.027920168515342902,-30.864028558228842 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991496,-0.33367779795593233,0.12541324250051944,-83.54929339109005 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991496,-0.48333525925847215,-1.665533983696807,36.81024361064155 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991496,-0.5184046706015049,0.41185405931151275,-43.88363030405966 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991496,-0.5235987755982983,0.13090033418098318,122.06463106271343 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991496,-0.5235987755982983,-0.8495219607542992,45.797582669066664 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991496,-0.5235987755982983,-35.67697955042793,17.71838329114478 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991496,-0.5235987755982987,0.1308996938995748,-0.5235987755982989 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991496,-0.5235987755982987,2089.1614415772146,0 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991496,-0.5235987755982988,-24.9133693390364,0.26179938779914935 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991497,-0.3618389909201071,-2214.0462709931844,0 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991497,-0.5235987755982984,-100.0,0.26179938779914924 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991498,-0.5235987755982987,-75.67724374154398,1.8551643869777479 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779915,-0.007813225622042634,44.711555310192665,70.34975738014992 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779915,-0.5039256543629533,-36.37234508792848,7.728348655839071 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779915,-0.5235987754452768,0.13089969451167285,2184.0013216813013 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779915,-0.5235987755982983,-0.057927247935217085,69.2847338088999 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779915,-0.5235987755982983,-77.51624852485173,4.893096207211457 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779915,-0.5235987755982987,-16.911256702776928,39.973552028723276 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991509,-0.033892253417692766,-2.309458110097779,0.1374845142897016 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991509,-0.5235840648725468,-19.03454722151959,0.26179203243627336 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991509,-0.523593461229567,-89.42315446700766,3.3683082388590577 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991509,-0.523598775598249,-0.6544984694978728,100.0 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991509,-0.5235987755982968,-71.96317426297742,-2012.3388763455728 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991509,-0.5235987755982978,-74.04902854370981,0.261799387799149 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991509,-0.5235987755982981,-51.841959708056706,0.261799387799149 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991509,-0.5235987755982983,0.13089969389957723,79.7843225153754 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991509,-0.5235987755982983,-81.78721304764409,796.8241409445498 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991509,-0.5235987755982983,-90.69809115785456,42.47380623554423 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991509,-0.5235987755982987,-39.66520825107029,45.25864351075498 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779915096,-0.5235987755982981,-0.654498469497869,-0.5235987755982991 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779915113,-0.47216370777113287,-0.6544984694978727,-42.48775450079516 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779915135,-0.5235987755982968,-57.41506724937528,-60.74108580627069 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991518,-0.5136100687760184,0.9162978572970237,-0.44351448077248085 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991527,-0.2979080970977199,-54.1849767530692,51.43117396177436 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779915446,-0.015052840734630646,0.13089969389957723,0.7929245837647656 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991553,-0.5235987755982984,-35.94883930090077,0.26179938779914924 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779915624,-0.48527427561811853,-80.0478055456169,-18.09751946893883 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779915757,-0.5235987755982987,-100.0,0 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877992405,-0.14550173960109963,0.9162978572970684,-51.79244175528576 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark07(-0.2618016686321354,-0.5214879057138184,-100.0,-0.5246542105405391 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark07(-0.2618030817323034,-0.5235987755971032,-72.17350182243476,1.0471975511959999 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark07(-0.26180399489332407,-0.5235987268140021,-17.915937314085213,0.26179938739145603 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark07(-0.2619967948556983,-0.5235987755982953,-0.08187730731667453,1.0471975511965947 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark07(0.2620037352449054,0.5240074704898112,-1.4440822039941636,-0.7171869821371879 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark07(-0.26245218140796595,-0.5223375055442849,-100.0,-27.37163488572608 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark07(-0.263067931010583,-0.5235987755982987,-99.61207898061629,64.99441048388523 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark07(-0.2642181471647691,0.6108732634060061,0.1420550894043166,131.94755007933816 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark07(-0.2655479299143435,-0.4490355922849109,-92.48003364491316,0.22451779614245546 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark07(-0.26557804677159425,-0.5235987755982983,51.90215365445082,0 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark07(-0.26591367308805064,-0.5235987755982983,-96.10974704087694,75.96782304316503 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark07(-0.26618493287042766,-0.5234846087266006,-8.546103201609949,-1.8020109789798369 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark07(-0.26730984325011115,-0.5235987755982987,-0.6517432417723927,-0.5235987755982987 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark07(-0.2686167233674941,-1.1102230246251565E-16,0.13430836168374705,68.50359261928698 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark07(-0.2689413449897342,-0.29416268845873,0.23014545541137799,-0.6383168191680832 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark07(-0.269821276466905,-0.5235987755982987,0.1349106382334525,1.0471975511965976 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark07(-0.27270310149003346,-0.44599102311534516,-0.6490466126524316,0.8036855640750027 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark07(-0.27295013716565153,-0.3105645944653145,-0.6489230948146225,-20.29765334942109 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark07(-0.27336857617841304,-0.09285188206939929,-0.6000446837006685,26.820240189271885 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark07(-0.2735071119859313,-0.5235987755982966,-0.6486446074044827,0.2617993877991483 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark07(-0.27446425537096075,-0.5235987755982984,0.023930459816752472,0.26179938779914913 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark07(-0.2757156383811914,-7.008369413967533E-15,0.1378578191905957,-0.7853981633974443 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark07(-0.2765842791241482,-3.552713678800501E-15,0.9236903029595225,0 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark07(-0.27676868011989697,-1.1102230246251565E-16,-100.0,81.02794706106184 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark07(-0.2783699834483572,-0.5235987603414993,-175.00068059020916,100.0 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark07(-0.27942313594983936,-0.09429037394332518,-38.121514371464194,-0.7382529764257857 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark07(-0.28001717946446836,-0.518410278742119,0.14000858973223418,-100.0 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark07(-0.2811632888568658,-0.3038186713885772,-1.0473133828889374,45.20366994172033 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark07(-0.28132985994157195,-0.5235700294633943,-0.6463330936215357,15.22779262876703 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark07(-0.28161897525781887,-0.5235987755982987,-28.225944694128785,0.57246263673963 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark07(-0.282115693790182,-0.5235987755982965,-100.0,-27.158931955328093 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark07(-0.2824685696335322,-0.5235987755982987,-0.03585406029799813,0.26205184581508517 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark07(-0.28316167762047684,-3.552713678800501E-15,0.14158083881023842,66.19363748881469 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark07(-0.2839008098710953,-0.5235987755982987,-27.043171540006288,-100.0 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark07(-0.2841928138933567,-0.5197479835599218,0.14209640694667836,-21.020244573237264 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark07(-0.28534395304563426,-0.49522289887473214,0.9280701399202653,1.0330096128348143 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark07(-0.2854856510039463,-0.5100623635377466,0.14274282550197315,0.2550311817590362 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark07(-0.2855691251771238,-0.13847535121352056,0.918066126296134,-37.770919795541715 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark07(-0.28574620600175227,-0.5235987755982663,-99.4580989663029,49.638447426525836 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark07(-0.28589718275572906,-0.5235987755982988,0,0 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark07(-0.2866531820639009,-0.5235987755982974,0.14332659103195033,0.2617993877991487 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark07(-0.28765024372163434,-0.09189134597457504,70.79005810435353,0 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark07(-0.28784735238293035,-4.8105553554595724E-5,0.9293218395889132,2.4052776777297967E-5 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark07(-0.2889363141268907,-9.860761315262648E-32,-16.339510258163088,100.0 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark07(-0.28942875519249545,-0.5235987755982947,0.14471437759624772,-30.545181449872345 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark07(-0.2897280567827598,-0.502680610389828,0.1448640283913799,38.0294569957103 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark07(-0.2900286063656274,-0.5235987755982987,-0.6403838602146346,-0.5235987755982989 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark07(-0.29443070120383474,-0.5139134159508766,-73.5357426247099,0.25695673653742207 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark07(-0.29527190856241997,-1.6653345369377348E-15,1.8280117190089917,-0.1658053720130861 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark07(-0.2955920257083118,-1.1102230246251565E-16,-105.89790780427415,94.55853251174409 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark07(0.29569801199195633,0.7180750336835362,-0.6734258197087993,-60.04847388140437 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark07(-0.2965845835213104,-0.5235987755982947,-0.6371058716367931,32.17252844352482 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark07(-0.29692430966410127,-0.28232954420433876,-0.4676422537014552,64.92722713612503 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark07(-0.29932612787727253,-0.18445855776663644,-70.16577880196134,95.98578399864877 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark07(-0.299975244629053,-0.5235987755982983,-52.549172506999234,73.1333054747739 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark07(-0.30001773478804333,-0.49977412753386746,0.15000886739402167,-0.5350101263202142 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark07(-0.300658568391472,-0.25466679407159953,0.150329284195736,100.0 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark07(-0.30104316284611027,-0.5235987755978496,0.15052158142305513,0.26179938779892487 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark07(-0.30109053736959407,-0.3595557546873437,0.15054526868479703,57.660313111490886 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark07(-0.30321792235063605,-0.521067480200802,0.15160896117531802,100.0 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark07(-0.3032726594601315,-0.5235987755982876,-69.17153222795261,-73.29009118954191 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark07(0.3058441457032951,0.6116882914065906,41.85434035959954,-0.3058441457032952 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark07(-0.3059446285936462,-0.5235987755982948,-0.632425849100625,1.0471975511965956 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark07(-0.30773001048989385,-6.339373470609644E-14,0.15386500524494695,3.168319450156189E-14 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark07(-0.3102274842363266,0.31310940173378926,0.16222481083410478,104.29115135422143 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark07(-0.3105811589093628,-0.005845143629488438,63.94039394966329,-1438.363617467335 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark07(-0.3136419789498339,-0.5235987755982947,-15.68526882783665,0.2617993877991509 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark07(-0.3140799308631035,-0.48963897335465695,0.08101538975374252,0.24481948667732847 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark07(-0.31614855256762797,-2.220446049250313E-16,-100.0,-83.21339797740995 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark07(-0.31806798946290765,-0.28722415554887415,0.9348885347154882,-74.25284219876262 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark07(-0.3184146367252769,-0.5220971840811788,-0.6261908450348098,-9.163738318891777 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark07(-0.3188301839984291,-0.5235987755982947,0.416855994778886,-38.26222777900742 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark07(-0.32066074735234157,-0.523598775598293,-25.39887066073202,-0.5235987755983018 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark07(-0.32190084160815174,-8.870307146272343E-14,45.20774533870506,0 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark07(-0.32228485434494303,-3.192467443916594E-14,0.9465405905699198,1.5962337219582968E-14 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark07(-0.323868389730374,0.0,0,0 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark07(-0.32431524343201856,-0.017907906446413088,-70.97790007967765,0.7943521166206549 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark07(-0.3286925450889987,-0.5235987755982987,-100.0,1.0471975511966107 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark07(-0.3289589818482581,-0.5235987755982987,-0.6209186724733184,0.1625438825604455 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark07(-0.33054337713839366,0.28493072311909723,-110.1316127263273,-176.321444828147 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark07(-0.3339851086032044,-1.6814510672702454E-8,-0.2874300884613944,-0.7853981549901929 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark07(-0.3342351586941103,-1.3917006085863063E-13,0.9525157427445592,0 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark07(-0.33496037733462214,-0.5235987755982947,-55.74408935583919,-7.230984042443282 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark07(-0.33601367232905105,-0.49867601782604815,0.8301901834618177,70.1220648693255 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark07(-0.3404918188850644,-0.5235987755981952,-6.323081460079253,2241.2876352185554 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark07(-0.3408042538842011,-0.5235987755982983,0.17040212694210055,97.63058357425854 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark07(-0.34308577629143855,-0.5234532981199256,0.5311026261445152,-0.39134635289802416 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark07(-0.34533791640288314,-7.477228741367081E-19,0.9521624960120255,3.73861437068354E-19 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark07(0.3459568303729271,0.6919136607458544,-0.17297841518646356,41.20172634903763 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark07(-0.34729010368234847,-0.5228285457495,-99.74591879300515,100.0 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark07(-0.34971504581627605,-1.5407439555097887E-33,-80.91335734323657,0.0 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark07(-0.3501594075808967,-0.022266975214777468,-22.263826465432125,-0.3033775011342659 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark07(-0.3533423045937631,-1.1102230246251565E-16,-69.34485913937165,99.26539201683616 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark07(-0.35476862062562037,-0.5235987755982916,-15.968090624764612,1.047197551196594 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark07(-0.3560478420826505,-0.3448905141247086,-0.607374242356123,18.21073549651973 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark07(-0.35609108837052517,-4.563022116215294E-5,0.9634437075827105,-26.77399701345588 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark07(-0.3569372746431867,-0.5042542892902578,0.17846863732159335,1.0375253080425773 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark07(-0.35918125696600267,-0.012683209706912701,-12.775511825891424,0.00634160485345635 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark07(-0.36293539147941556,-2.0328790734103208E-20,-62.251776158382015,0.7842156304058262 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark07(-0.3634143236541093,-0.5235987755982987,-3.443918268448488,0.2617993877991722 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark07(0.36422224137324233,0.7284444858847687,-88.07088232876006,44.40945259409257 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark07(-0.3643427952274294,-0.27519765477681996,-93.29641246961268,-36.06929944649211 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark07(-0.36591770150429126,-0.5235987755982956,-3.406044546538321,98.01295363767386 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark07(-0.36595427234540034,-2.7626606443809615E-14,-0.10645808648101916,1.3811868315727338E-14 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark07(-0.3662593734500264,-3.1615989012572505E-39,-0.31484348544571633,1.580799450628091E-39 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark07(-0.3668478469754394,-0.726031439223729,-31.283006929003584,-1.207780607183032 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark07(-0.3671395166924492,-0.5235987755982986,0.1835697583462246,0.2617993877991496 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark07(-0.3712810770865271,-0.4997662165637943,0.6558398212671722,-27.261974974103143 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark07(-0.372013465074747,-5.5329738269028194E-14,-0.4738034863983465,-92.68143257375507 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark07(-0.37340269541599724,0.8239909359629012,0.18670134770799862,9.776886571270193 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark07(-0.3742995384409485,-0.521671245039034,-99.63015333784523,0.260835622519517 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark07(-0.37558955684423206,-0.0060099421841773104,22.76625526138605,-54.98744702560378 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark07(-0.38073053408178203,-0.5235987755982983,0.19036526704089674,0 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark07(-0.3820737345587496,-0.07086251165076331,-68.7689812588097,0.8208294192228299 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark07(-0.3839225386929943,-0.4214290942103389,0.19196126934649627,35.046844724087265 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark07(-0.38458366946487077,-0.5008567009124384,-0.5931063286650115,0 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark07(0.3891619765142462,0.7961817265571678,-52.59710477502613,-100.0 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark07(-0.389499050766245,-4.440892098500626E-16,0.9801476887805707,83.0525375515621 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark07(-0.389905237243215,-0.2574884942186805,-100.0,-0.6566539162881081 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark07(-0.38993794250955743,-0.012028121352082533,0.1949689712547787,0.7914122240734898 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark07(-0.3913714607668336,-0.5168359122980923,-66.45828209989361,6.637986497027249 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark07(-0.3936720378404469,-0.4121038580758858,-13.133770492131163,50.51268721985824 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark07(-0.3941203375295572,-9.753957993658279E-4,-170.5542995936086,4.876978996828929E-4 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark07(-0.39622853949063674,-0.25446753736970606,-15.988471210349505,40.14077087938017 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark07(-0.3993886078290956,-0.7187405327311778,0.1996943039145478,36.55018578245656 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark07(-0.40412885290540723,-0.5235987755982983,-18.096520920226105,-47.229739872608604 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark07(-0.4050921001803061,-0.2573885436779076,0.20254605009015306,-0.6567038915584945 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark07(-0.4057202379434111,-9.031228750141373E-4,0.27844723743183425,0 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark07(-0.41211118077511,-1.0658141036401503E-14,-100.0,-63.597286024319864 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark07(-0.4123852510219862,-4.0151504942398856E-12,8.021061925410447E-15,64.2343991750257 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark07(-0.41484742401180563,-0.5154689011588462,0.20742371200590282,-97.22936934956064 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark07(-0.4168179419776834,-0.5235987755982987,-15.533784752616555,-23.975337001793733 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark07(-0.41723390058095255,-0.35323485066061266,-0.5530973271633782,31.48483650886192 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark07(-0.42244620917089337,-0.020029530532507556,-0.5741750588120016,-0.9927816392105697 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark07(0.42254608938457,0.8730293576369047,-31.521145758660314,0.3489013891544579 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark07(-0.42269920881860407,-2.8421709430404007E-14,0.37500642626211755,2091.4518734434823 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark07(-0.4246391456255236,-0.5235987755933901,-0.33918811689224204,18.900516302775795 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark07(-0.42639662146316537,-0.47944648487853314,-100.0,0.22263914862546652 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark07(-0.42671632264631276,-2.279007871484772E-16,0.21325386156472256,-0.7853981633974482 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark07(-0.4288163279393316,-2.7755575615628914E-17,69.58107120802615,-78.33987125097444 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark07(-0.42924732403769983,-0.01166129069848605,1.0000218254162987,51.462001862026 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark07(-0.43302542631349894,-0.5235987755982379,-100.0,84.2600699755304 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark07(-0.4330292875928772,-0.41392966475854653,-97.70773939086898,0.2069648435783389 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark07(-0.43345434338635885,-0.8668795278028987,-37.92147641009184,10.643586838676288 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark07(-0.4334727701520311,-0.44720171602139913,0.21673638507601556,76.67220096759624 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark07(-0.4337831530254892,-0.0028905091471646727,1.0022897399101929,-26.40249919940393 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark07(-0.43492966963278334,-0.4697885147680982,-72.78349807867959,0.23489425738404907 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark07(-0.4377077681455127,-3.469446951953614E-18,-12.388693954092709,100.0 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark07(-0.4385335457233185,-0.49115421889948707,-153.71544878732416,-67.01405352554727 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark07(-0.4396196171176859,-0.09280476074651675,74.00435308606922,58.59805659641457 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark07(-0.44176545115356636,-0.5235987755982986,0.3583458132284658,-60.7250273707539 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark07(0.44265106943039834,-8.673617379884035E-19,-0.43886039279481515,100.0 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark07(-0.443017974088443,-1.9240406609631154E-15,0.2215089870442215,9.620181415805514E-16 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark07(0.4456199721565026,-2.862293735361732E-17,0.5625881773192002,0 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark07(0.4463665295872548,-0.033692988041686335,-100.0,0.016846494020842928 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark07(0.44775238011982543,-0.029515157332628956,-100.0,0.014757578666314476 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark07(-0.4487189549595382,-0.1082117898969478,-37.537015393670025,100.0 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark07(-0.4520950268302555,-0.5235987755982987,-0.5593506499823206,100.0 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark07(-0.45249914944409625,-2.7755575615628914E-17,97.99616190220235,1.3010426069826053E-17 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark07(-0.45305261555732645,-1.1102230246251565E-16,-24.68442177759499,-41.61845958730495 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark07(-0.4543296194764239,-0.30886712649301107,-0.5582333536592363,3.102721804214358 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark07(0.45538126947540647,2.1433482160722788,-0.22769063473770323,0 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark07(-0.4570158987354932,-8.722174425873709E-16,0.2285079493677466,-52.4025849231758 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark07(-0.4574310447777137,-0.5220710508746934,-5.646134559830816,0.26103552543734676 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark07(-0.4575762814368547,-0.22716828194618854,-33.19470957473327,-76.90491742651585 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark07(-0.4576077552548133,-0.07509269489316113,0.8535148699141247,-6.6526655178817125 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark07(-0.45936258260579166,-0.5235987755982876,-62.19475312133296,40.794131603252794 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark07(-0.460621147935686,-0.4322769091416265,0.680260985233097,48.12411150149573 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark07(-0.46126922502029344,-0.28264840170752686,-77.97151414702398,8.362774874711933 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark07(-0.4623152563805899,-1.1102230246251565E-16,-137.24238638463368,-0.3230829070168646 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark07(-0.4629639846413056,-0.5220822000532834,-90.61432122607279,77.35357114219234 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark07(-0.46312021062698305,-0.017487513132339406,0.23156010531349155,0 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark07(-0.468913423520425,-0.5235987755982987,0.34074300387658657,26.86128329166662 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark07(-0.46932686034278837,-3.3662664124702874E-13,0.2346634301713942,0 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark07(-0.47548497458122063,-4.5831348075052973E-14,0.23774248729061034,-91.99753921577042 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark07(-0.4783557649463503,-0.3364374076140187,-0.5462202809242731,-0.617179459590439 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark07(-0.4810716001332622,0.6086531265283711,-0.5448623633308172,0.48107160013326267 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark07(-0.4818746020194523,-0.5223947572968676,-0.0090584473052123,0 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark07(-0.48244382993067153,-0.4625408102696921,-100.0,0.7934341692546234 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark07(-0.48603721036087677,-0.4031051871174763,1.0284167685778858,0.9869507569561864 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark07(-0.4897612684207524,-0.28516478772019865,-157.70596554456978,33.69112877171936 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark07(-0.4902624221844537,-0.5235987755982987,0.5235987755982991,-3.8613051044458437 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark07(-0.4920376954464718,-0.04165933709787169,3.5875300404899737,0 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark07(-0.4978023741584614,-0.5235987755982987,0.6027177651552451,0 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark07(-0.49821143281590896,-1.1102230246251565E-16,-35.95279349052602,5.551115123125783E-17 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark07(-0.5015207640156355,-0.08601034589836186,-22.183707064488996,-0.2578398965466251 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark07(-0.5028845791572313,-0.5235987755982627,-52.23741762782932,100.0 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark07(-0.503828624740553,-1.3877787807814457E-17,-99.41975180959352,1091.3663856562353 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark07(-0.5056706999222186,-0.512665625873013,-24.086718740288024,-0.00968981893748499 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark07(-0.51067365340482,-0.005504268892381231,10.929972786990652,-44.36434333647478 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark07(-0.5130568281977279,-1.1102230246251565E-16,-100.0,59.096836290902026 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark07(-0.5133374684976376,-7.955008179960643E-15,25.84031006473441,0 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark07(-0.5138599469848857,-0.42437276468948604,-0.14311258271962063,99.8103589971066 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark07(-0.5143949342682583,-0.5235987755982987,-62.171402799586374,-98.42878186613065 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark07(0.5156389909971284,1.0619298295082726,-1.0432176588960125,100.0 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark07(-0.5183344792334529,1.8551834804495462,-163.103992553875,-69.263993959386 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark07(0.5183724078667563,-1.1102230246251565E-16,-100.0,8.695040952542438 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark07(-0.5187623078888799,-1.7763568394002505E-15,0.25938115394443995,-0.7853981633974474 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark07(-0.5216278336704057,-0.3587410112342867,-100.0,-0.606027657780305 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark07(-0.5227887543127496,-7.105427357601001E-15,-20.597961651966394,3.552713678800501E-15 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark07(-0.5228028472401979,-0.31600200915890936,-0.5239967397773493,-80.58960187845864 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark07(-0.5232824867340631,-1.1102230246251565E-16,-17.053718384228127,-49.291167177621276 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark07(-0.5247741149717804,-0.40282472378220036,0.26238705748589,-61.27209023214441 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark07(-0.5277077606429518,-1.7763839444545626E-15,-30.366673726889047,0.7853981633974492 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark07(-0.5282636165449404,-1.0565231661350751,0.2641318082724702,-4.184127381293254 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark07(-0.5289612787738122,-1.674487900293362E-11,0.15557179997310663,-0.7853981633761314 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark07(0.5298897825169125,1.1183524824722935,0.520453272138992,-0.5591762412361467 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark07(0.5325024410245245,1.446086663587319,-13.693394584548914,7.13107994161462 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark07(-0.5326472347945507,-0.17606860104470423,-0.5190745460001747,61.319239010646115 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark07(-0.5338333761187304,-0.5235987755982987,0.2669166880593652,-14.086328258784317 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark07(-0.5342833495807326,-0.25979768041452334,-62.65492287196741,-28.459802974209346 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark07(-0.5354108774873879,-0.5235987755982983,-0.2617993877991498,33.075882202802 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark07(0.5379638431126976,1.1064451281284444,-32.742357906819606,0.23217559933323173 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark07(-0.5381564055299174,-0.5235987755982981,-100.0,-41.79629806974641 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark07(-0.5387203204520252,-0.2338525603571071,-0.5160380016447181,-171.35493232736707 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark07(0.5399669109637358,1.1167006088316929,64.99100009795484,0 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark07(-0.5416267986848079,-0.5137145424794614,-83.32308080075082,41.89623951992917 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark07(0.550077462995934,-0.5235987755982991,-37.17913339095023,0.2617993877991496 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark07(0.5513845948604698,1.1027855328568419,-100.0,100.0 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark07(-0.553836180624586,-0.3602415471147416,-98.68370367236601,173.75179996407536 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark07(-0.5566525775029593,-0.5235987755982987,-100.0,-88.5575722299258 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark07(-0.5571032640482828,-0.27950801281213555,-6.405714329971416,0.13975400640606783 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark07(-0.5575328260444647,-1.6076379079466577E-30,-99.46679954776538,0.7853981633974483 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark07(-0.5598101328721844,-0.007823032712741812,0.2799050664360922,69.24868481062448 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark07(0.5600688591456401,1.1203288726964242,-0.28003442957282004,100.0 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark07(-0.5600870165701854,0.3308318766971022,-56.87311775542863,70.52053225681199 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark07(-0.5607667604929537,-0.50210375902436,-100.0,-44.057995367532605 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark07(-0.5614596662245206,-1.2250155968835722E-15,-9.929445248821175,0.785398163397449 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark07(-0.5621157041499992,-4.184187332797172E-17,-0.15081704819841202,4.716227580212204 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark07(-0.5668397721430938,-8.326672684688674E-17,-93.70710000729076,-100.0 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark07(-0.5677055960819041,-0.1900601472697243,-100.0,-0.690368089762586 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark07(-0.5689281655999192,-0.05151514866473894,-100.0,0.02575757433236947 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark07(-0.5699138918261718,-3.898843156915243E-14,-43.32961619224424,53.92833033841112 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark07(-0.5731368259918883,-0.5169382345356653,-0.17725436648910253,0.25846911726783267 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark07(-0.5742057069286333,-0.022498325253715014,-0.49829530993313165,0.7953324057048873 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark07(-0.575463757866124,-0.5186219120528301,-182.0745562024883,31.407098523710584 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark07(-0.5757690872225587,-0.5034980377667264,0.28788454361127935,94.77957869430806 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark07(-0.5763412100823484,-7.92830478243425E-11,33.31359820859393,-92.86122355020315 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark07(-0.5765000926177127,-0.5235987755982218,0.28825004630885637,100.0 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark07(0.5774433256912268,1.3306857067244207,125.7371438996191,-0.6653428533622103 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark07(-0.57899500105589,-0.14484734446843367,-45.395874010298456,-0.7129744911632314 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark07(-0.5790846464701715,-0.09447252622042712,-70.03286309722588,0 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark07(-0.5795258205109306,-0.4316758748913862,-100.0,-72.26016262436609 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark07(-0.5802402254710088,-1.1019833690206766,-5.841416840793796,-100.0 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark07(-0.5809859826144038,-0.5235987755982987,-36.819487990310215,0.26179938779914935 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark07(-0.5816741933512823,-0.5232555389783634,0.2897410120607039,-79.4778171757407 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark07(0.5826154060632321,2.5151454853581834,-20.326894039998095,25.45406492526018 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark07(-0.5832864377734426,-0.007442500382356777,-72.17067771517712,-0.7816769132062699 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark07(-0.5840169825504989,-1.0842021724855044E-19,0.29200849127524947,-33.77343594640979 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark07(-0.5852681384965158,-0.20434705469056041,-31.42334457948293,0.1021735273452802 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark07(-0.5878196634291804,-8.881784197001256E-16,0.45029561141294305,-0.7853981633974478 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark07(-0.5880874499401568,-0.5235987755982985,-33.542307526316,0.2617993877991493 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark07(-0.5881731598845146,0.20539850207147528,-132.78238274699345,85.50627142002128 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark07(-0.5890330425556511,-0.5235987755982986,-36.023121360443525,0 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark07(-0.5897168376075933,-0.5235987755982974,-100.0,0 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark07(-0.5897244492004345,-0.4148812197152374,0.29486222460021727,-83.04476478856634 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark07(-0.5903969968273741,-0.5235987755982987,0.46493529512480647,-84.7255657644396 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark07(-0.591331270940392,-0.4876604129936126,-47.75241732761256,0.2438302064968063 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark07(-0.5933823530770266,-0.5235987755982964,-0.48870698685893504,100.0 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark07(-0.5933961309819787,-6.938893903907228E-18,0.9669464569183324,-0.017689862036246146 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark07(-0.5946196974368081,-4.440892098500626E-14,-0.48808831467904423,-16.549729986356603 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark07(-0.5953149430658318,-0.5113911197145725,-0.48774069186453234,0.2556955583245222 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark07(-0.5963167908633729,-2.1094237467877974E-15,1.0560729093726597,1.0547118733938987E-15 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark07(-0.5969120108755828,-0.5235987755982983,-100.0,97.21139091990781 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark07(-0.5998374407892237,-0.11387252963954493,-0.4854794430028364,-4.3021279541309 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark07(-0.6002900317271046,-0.5057261378361038,-81.24907305522684,1.0052847514182401 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark07(-0.6016640659217236,-1.3877787807814457E-17,-100.0,-58.86509809076361 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark07(-0.6051699589207091,-5.551115123125783E-17,0.30258497946035456,0 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark07(-0.6054731575079817,-4.0323643647280547E-7,0.16157642024875668,-100.0 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark07(-0.6068674262994447,-1.8994032021189393E-4,-144.72569896071457,-0.7853031932373422 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark07(-0.6068847084153219,-0.2986882351692959,-77.56019961001859,0 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark07(-0.6077041270518819,-1.7763568394002505E-15,-29.83875941502187,10.59979344996961 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark07(-0.6086057464638293,-4.440892098500626E-16,-81.87881566295562,0 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark07(-0.6127539974685341,-0.3442412650403407,-42.97176047928157,0 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark07(-0.614896332063894,0.0637889176641284,-83.82869630325031,75.37079526960237 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark07(-0.6153747298187413,-7.717994882530069E-13,-2.8414456077639514,-73.16194075577471 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark07(-0.6190676048282809,-0.5211495315586596,-63.26091797340303,0.7750165734686861 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark07(-0.6218233143463827,-0.009267218620640897,-0.12395823652671845,95.97643959498865 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark07(-0.6254355836195131,-0.5235987755982876,-8.97710746174937,41.28178241359767 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark07(-0.6278324889420581,-0.5235987755982984,-90.98250786433772,1.8247760449054908 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark07(-0.631400724108852,-0.49963251122254637,-55.43765176494896,82.15293177737931 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark07(-0.6328750614024182,-0.517108565403659,-46.38757495652592,0.25855428270183056 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark07(-0.6335731978101232,-2.8208546609675977E-12,-97.21024436894464,59.43863133550813 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark07(-0.6342214322286581,-0.1280682880160691,67.18526164786392,62.819524960399946 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark07(-0.6349126524160771,-0.029827023101249947,8.80301129301067,0 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark07(-0.6357047023874012,-0.5235987755982947,0.3178523511937006,-43.14866843632224 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark07(-0.6389879776177037,-0.5235987755982745,-43.581124011652555,-0.523598775598311 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark07(-0.639255326262463,-2.489766514440422E-13,0.31962766313123225,52.27786926792206 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark07(-0.6403505443119437,-0.2836853175433896,-84.51898208762901,-41.59732678907619 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark07(-0.6427255707849036,-0.5235987755982983,-22.04619018301881,57.3091010772203 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark07(-0.6431103678588599,-0.5187921192817182,-96.33809402186633,0.25939605964085904 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark07(-0.643500414531043,-0.0033485891089327932,-0.4636479561319268,-36.58291653712521 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark07(-0.6443893752818045,-1.1129073794521106E-14,45.711399170247006,5.564536897260553E-15 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark07(-0.6450535992460551,-0.523598775598268,-50.87584168408722,1.0471975511965823 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark07(-0.6453257856909327,-4.440892098500626E-16,-121.47835718017069,0.7853981633974485 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark07(-0.6454060778810786,-0.20188347229072018,-0.18297645797379664,-1.1562407190216188 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark07(-0.6464102514963264,-0.11605828070727559,-0.4621930376492851,67.31230963833609 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark07(-0.6496702598134952,-7.105427357601002E-15,-37.4269570145365,0.7853981633974518 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark07(0.6506283071223228,1.620977527419534,-37.585666129003485,44.74261638780526 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark07(-0.6522965975401599,-0.07401233203055486,-75.15847917743743,-61.22405057859494 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark07(-0.6536243686477046,-0.5230623517268926,-80.71746122797053,100.0 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark07(-0.6541704319659492,-0.5235987755982987,-90.20739058096476,-0.5235987755982989 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark07(-0.656656358238461,-0.44766624676086914,-60.21301609734551,90.79710786112997 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark07(-0.6601771078930089,-2.89057151864149E-4,79.21730220117217,24.237530772981657 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark07(-0.6650499469747087,-0.5235987755982987,-79.09936318447069,99.83854729119868 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark07(-0.6656424538314005,-1.7671438028652885E-10,1534.6642765076977,0 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark07(-0.6668306701000261,-0.07029070035484361,-0.4519828283474352,-0.698250606934238 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark07(-0.6682771731285453,-0.5235987755982987,-0.45125957683317564,-100.0 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark07(0.6683673833149171,1.367833098864995,0.4512144717399612,87.82825276398931 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark07(-0.669136326551056,0.21567455208717629,1.119965299976376,-45.66092408567152 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark07(-0.6710368567930436,-0.4167687320635295,-0.3954185355327919,12.77475494887699 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark07(-0.6717223690052185,-8.881784197001252E-16,-51.41086130000935,18.1057152420397 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark07(-0.6738434539302565,-0.5235987755982987,-12.009313338751896,5.4741562616420225 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark07(-0.6745277728168633,-0.0877417855348321,0.4617139883015245,-0.7415272706300322 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark07(-0.6754228120668078,-0.5235987755982947,-0.4476867573640444,97.43008797412185 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark07(-0.6768410828265445,-0.1504423391392659,0.44983653194793066,10.886727094295132 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark07(-0.6770625441312184,-1.0658141036401503E-14,0.33853127206560907,83.53699548219487 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark07(-0.6778429481782386,-0.15509942321935205,-0.44647668930832896,12.209636018608784 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark07(-0.6780787898397542,-0.0014382842233146788,-21.07612336364999,-99.74616252968367 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark07(-0.6785950185031373,-0.3756877114482447,-100.0,89.4995432212888 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark07(-0.6810451995628997,-3.495407453934312E-11,1.1259207631788968,1.747703726967156E-11 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark07(-0.6816153363426218,-1.0931798301807039,-0.44459049522613736,-100.0 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark07(-0.6826688589419475,-0.494646733087329,0.34133442947097375,-43.95225219990412 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark07(-0.6841733651202858,-1.1508155539630138E-14,1.1274848459575912,6.17273791391039 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark07(-0.6848223489905687,-0.5235987755982987,-75.2768658112596,-3.1826223070740554 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark07(-0.6857594683819943,-0.5235987755982918,-71.92518344807573,-42.152381471136366 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark07(-0.6873706923092564,-0.1854185019675258,-0.4417128172428204,-1867.8135940964107 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark07(-0.6874877206902227,-0.5235987755982933,-0.441654303052337,1963.234645677118 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark07(-0.6879188387334026,-8.604255937760484E-16,0.3306983824419233,4.3021142204224816E-16 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark07(-0.6929563775294769,-0.2707602108243327,-100.0,44.64070557528285 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark07(-0.6931626132237092,-0.3686973249484692,-71.52887229095545,-4.30551342156223 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark07(-0.6964824890565604,-0.5235483885956854,-34.7118164935204,74.84630721242064 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark07(-0.6972374686029742,-0.523563699344043,0.4226343793463232,0.2617818496720215 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark07(-0.6974880503357757,-1.1566257914404815E-13,1.134142188565336,0.7853981633975061 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark07(-0.7061245672601244,-0.5235987755982987,-59.41183834809698,100.0 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark07(-0.708700202681375,-7.884503487509707E-14,-0.4310480620567608,122.41547240109193 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark07(-0.710215010685082,-0.48040588011547536,-0.27030012870773135,-95.10998629431066 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark07(-0.7105400907886121,-0.16814773905310643,7.178302028570229,41.8613729199067 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark07(-0.7121489819388415,-0.5235987755982983,-0.4293236724280276,50.75257365907463 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark07(-0.7125167867052342,-0.04221299454172917,-0.42913977004483117,0.8051897216193219 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark07(-0.7139139424567791,-9.23122764217309E-12,-0.4284411921690587,0.7849870370723029 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark07(-0.7155419617496453,-0.4186348979622934,-0.4276271825226256,-64.32007648749905 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark07(-0.7170883762553699,-0.5215837970379565,-0.4268539752697633,-100.0 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark07(-0.7178782425850956,-0.5235987755982987,-50.41450104958791,0.26179938779914935 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark07(-0.7190888983571952,-0.5231740909263586,0.06275662710382249,0.2615865247177992 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark07(-0.7204589808486603,-0.27542031226289654,-0.42516867297311817,-0.2811804433993504 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark07(-0.7215067231891998,-0.0029964340071771773,0.3607533615945999,100.0 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark07(-0.7222070272867747,-0.24213754024216377,38.08896064061135,0 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark07(-0.723489617084011,-0.51479256434881,0.3617448085420055,17.249064499227824 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark07(-0.7248514053241931,-0.5222366163428327,-0.42297246073535166,-5.229588783677837 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark07(-0.7251358850962817,-2.7755575615628914E-17,0.8854211491792278,-58.91180534950228 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark07(-0.7251609471231554,-4.530763067671256E-15,-0.3926990816987239,62.104758285750876 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark07(-0.7271202078450861,-0.5235987755982983,-63.253691087349075,1.0471975511965974 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark07(-0.7285628902185586,-3.948230631323213E-15,100.0,0 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark07(-0.7289665540638421,-0.02500059102031732,0.36448327703192107,0.01250029551015866 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark07(-0.7365965563156653,-1.637054793398591E-15,-46.72934099606155,-0.7853981633974475 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark07(-0.7383187099964379,-1.3877787807814457E-17,-56.36872018803172,-2048.8374603273533 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark07(-0.73836828199518,-6.938893903907228E-18,-0.41621402239985833,3.469446951953614E-18 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark07(-0.7388044058000407,-0.40517417870337297,-11.467631343012679,-27.967478423955313 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark07(-0.739904176736037,-2.7422414078212623E-15,-0.25293805076796827,95.8604593135573 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark07(-0.7404122656690147,-0.038751101241938146,0.3702061328345074,0.8047737140184174 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark07(-0.7409274029693705,-0.5235987755982983,0.3704637014846853,67.68667438168751 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark07(-0.7415309517180556,-0.5235987755982947,-14.123364337632369,69.21153249215864 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark07(-0.7428979082989331,-6.418706124125951E-15,0.37144895414946655,23.47201469148223 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark07(-0.7438982422149338,-0.11552819206941756,0.12588312938117674,-36.85463466332593 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark07(-0.7455299863047946,-1.4910599726095883,-11.063957162677493,0.7455299863047942 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark07(-0.7458669267151237,-9.658940314238862E-15,63.9239947903374,0 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark07(-0.7496386098430288,-7.105427357601002E-15,-55.6108241751336,-85.69372076041245 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark07(-0.7499542042371069,-0.5235987755982987,0.7492814872058311,-64.26930568488494 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark07(-0.7500125833721284,-0.08345181325124881,0.3750062916860642,-0.7852920174885583 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark07(-0.7509460664279376,-2.1316282072803006E-14,-39.880480205972056,-70.00167479530845 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark07(-0.751468041040592,-0.23889986114890593,0.375734020520296,-17.93720486303841 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark07(-0.7520274449205573,-0.017257826741327177,-100.0,-2.3405485759391897 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark07(-0.7522929708400407,-0.5235987755982795,-33.57095097602119,-66.56034785598361 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark07(-0.7553708857155326,-0.3106363768571906,-100.0,29.529381643211718 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark07(-0.7557366837313462,-2.7755575615628914E-17,43.48793702131459,50.23201764206106 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark07(-0.7557685115113828,-3.2314355966805655E-12,95.25834571368222,1.615716529948668E-12 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark07(-0.7566103611226161,-0.015442402972484781,45.84040718296481,-90.72102676983387 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark07(-0.7570189098213359,-0.06505970977036729,-23.472760685092897,-0.7528683085122646 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark07(-0.7587068280111975,-1.7734865992409272E-4,16.616711835586358,-99.99999999999949 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark07(-0.7591194379206198,-0.5207810179712336,-73.50104039456602,-47.73107685493481 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark07(-0.7603640252320463,-1.2226827716406858E-12,99.99999999999974,6.113413858203429E-13 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark07(0.7616063520592795,-1.2543887337926178E-14,60.758065385463226,6.271501747939039E-15 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark07(-0.7622885947342681,-3.566214840513682E-15,0.38114429736713407,24.30595870597494 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark07(-0.7636872909733734,-0.13489248504515317,-17.380448389228818,-83.04394395001742 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark07(-0.764374597687531,-1.4527997220208884,1.1675854622412136,-0.058998302387004126 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark07(-0.7647472381842704,-1.7763568394002505E-15,0.3823736190921352,-25.918138893762155 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark07(-0.7657527058674072,-0.004381327861766246,4.528992207244275,-150.73756184998598 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark07(-0.7661149762281725,-0.2833890318043015,-0.40234067528336204,27.66623553692028 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark07(-0.7676096317560486,-0.15685143240608773,-84.48133033287375,-75.15702495399808 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark07(-0.7676918410843669,-0.05777343820942171,-81.66515684231409,0.028886719104710856 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark07(-0.7684339643751072,-4.051414616309635E-12,0.3842169821875536,-63.39578045226867 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark07(-0.769843248639461,-1.670091848774373E-11,-0.06059878581436484,-43.67508393432608 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark07(-0.7706092337177781,-0.40673996027016746,-19.468793585610996,34.58492166552606 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark07(-0.771420376241432,-2.1316282072803006E-14,-23.193323275678914,-0.785398163397435 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark07(-0.7726943367923171,-1.1277536764252095E-4,31.004922410218946,0 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark07(-0.7728562712238229,-0.48472068069523555,-0.2639738615134315,6.384711848274921 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark07(-0.7730266377941789,-0.40578562530526663,-45.465288209470785,0.9869760557306307 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark07(-0.7741340105775016,-0.08219044492238259,100.0,32.768195113109726 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark07(-0.7779997607418422,-1.1102230246251565E-16,-2111.6890764761065,0 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark07(-0.7780017508834899,-1.6456306757560332E-20,-0.3963972879557034,-5.499102064101598 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark07(-0.7790994483293459,-0.4563833570261794,-0.3958484392328927,1306.9022697657365 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark07(-0.779734071963749,-2.7755575615628914E-17,100.0,0.2723242511822477 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark07(-0.7801383314252064,-0.008916979261309927,49.02120381946638,0 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark07(-0.7804494272104704,-0.006865923909921228,-0.395173449792213,0.0034329619549606136 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark07(-0.780616057787846,-4.0389678347315804E-28,0.390308028893923,-0.7853981633974496 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark07(-0.7819352193981536,-3.9538586323121E-9,0.03927555662818015,0.7853981653743776 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark07(-0.7829305919685206,-0.012514579980816981,1.020236846344429,69.31825726916415 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark07(-0.7830886703716321,-0.4397757047917978,-90.84198972574936,-13.37947965890655 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark07(-0.7840141833016517,-9.523049016024743E-12,-100.0,4.761524508012371E-12 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark07(-0.7842031566608685,-7.105427357601002E-15,1.1589082886189834,50.30372162479851 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark07(-0.7843814171303296,-0.5235987755982987,-9.445751006327217,-0.09053484673046364 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark07(-0.7849597794750942,-1.5058332043068072E-7,0.999133817941756,7.530606551684234E-8 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark07(-0.7850830265583284,-0.041558530020240646,-86.82370891551928,-0.5235987755983018 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853955167286809,-2.329820611576337E-15,44.81567667901953,1.1649074716998942E-15 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981136225109,-1.1978869020614183E-6,99.9999926019247,0 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981623660371,-2.3968353629699934E-9,0.3926990824391572,-0.7853981621990305 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981632561446,-8.241790287999925E-10,0.06782017965011851,77.28607324285562 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633412024,-1.805619348735423E-10,-72.21689027055112,40.13505075950374 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633863776,-1.8019525287316505E-9,-0.39269908162611356,57.03480749888885 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633866455,-9.902084729473604E-13,-100.0,0.7840832430785383 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633964564,-8.077935669463161E-28,-1.8227318994954786,-96.3639098008743 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633969217,-0.4348771907697212,0.39269908169846085,-50.5220438720608 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633970255,-0.5235987755982987,1.0201094261038353,-100.0 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974068,-4.440892098500626E-16,-0.3926990816987449,0.7853981633974485 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974421,-0.035448193954811025,0.3926990816987228,1.6080644522518523 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974425,-0.3087582645446419,-0.39269908169872697,-100.0 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974438,-3.552713678800501E-15,0.3926990816987228,42.81255375461056 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974456,-0.05956194009853254,-19.425525844265337,0 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974456,-1.4210854715202004E-14,-0.39269908169872547,20.276318250032084 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974456,-1.425655253937168E-14,-0.39269908169872547,4.980789953827966 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974456,-2.0209402749742373E-17,1.0906575174291446,1.0104701374871188E-17 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974456,-3.552713678800501E-15,-0.3926990816987228,-0.2893347826802664 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974456,-7.12199361104241E-15,-0.39269908169872547,44.46744959848284 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974456,-8.191744925385056E-13,-0.3926990816987299,-17.781189889881404 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974474,-0.14188252818117153,-0.3926990816987246,-0.7144568993068625 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974474,-1.1102230246251565E-16,0.3926990816987237,-82.1509771854089 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974474,-3.3306690738754696E-16,1.178097245096172,1.6653345369377348E-16 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974474,-7.486976083630865E-13,0.14235225411465882,-77.45247238073037 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974478,-1.0020061831731812E-17,0.3926990816987239,89.92180529513293 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974483,-0.08048989774572701,22.944971064043408,0 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974483,-1.8965687092626278E-16,-74.85101103624412,0.5751568135266504 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974483,-2.220446049250313E-16,-80.77895749215232,0.5668975629483584 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974483,-3.0564416368154434E-14,-49.18707471650066,14.996157507305899 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974483,-4.440898241142887E-16,-0.39269908169872403,2.220446049250313E-16 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974483,-6.416473049480125E-16,-100.0,20.15729870637371 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974483,-8.326672684688674E-17,-95.31566793317391,0 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974483,-8.840271565820885E-16,-96.6062657094475,4.4201358760793E-16 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974483,-9.329417966444478E-14,10.812639843393669,0 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark07(-0.785398163397449,-1.7763567906895787E-15,-9.789952513810732,8.881784197001252E-16 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974492,-0.02597463988537463,-43.715562617380414,17.847438247343952 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974492,-0.1129602313814917,-100.0,-42.695005810647906 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974492,-1.673853712333036E-5,-40.34577919179858,7.499924690278863 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974492,-2.8861561469935137E-10,0.3926990816987246,-23.38315921315413 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974492,-5.2459705079271036E-14,0.3926990816987246,2.6229852539635515E-14 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974499,-3.4724811881368026E-15,62.82683580231722,0 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974527,-0.2674158899849236,-0.392699081698722,-79.95940273266484 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974527,-1.7763568394002505E-14,0.39269908169872636,51.04468220884027 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974527,-9.526671757512177E-15,-71.63528445578916,76.25261491322959 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974546,-0.02931296443559006,-55.874062514822654,-1476.16380605707 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark07(-0.78539816339745,-9.443211097175295E-5,-71.82870298776808,87.22908000044251 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974598,-0.008952075996124317,-100.0,-2105.5726568561554 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark07(-0.785398163397461,-0.11614071173016204,0.3926990816987305,-6.856730917958105 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974616,-2.7027406625661168E-14,-75.7611235862826,-16.13651938327969 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974829,-7.456060097425728E-14,89.07674792304073,0 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633975717,-0.005668330260216292,0.39269908169878587,-13.285091736565624 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633975822,-1.0468282227727002E-12,100.0,1.4387830193387856 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633976046,-3.1291273750945284E-13,-100.0,0.7853981633973681 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633976849,-1.3997025638215971E-11,-0.39269908169860585,97.76398243096077 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark07(-0.785398163397712,-8.225674531191629E-13,0.392699081698856,42.39648837052775 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633981135,-1.3358203432289883E-12,-55.075983619320446,-64.92619487784263 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633981392,-1.265835004120331E-11,64.17874533047096,-40.72842790731987 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633990711,-3.4394189974136853E-10,1.178097245086074,-69.66401781676635 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633995922,-6.941286014351559E-10,0.32139983172874054,17.682444465806604 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981634000983,-5.595117351234628E-12,-61.82687109208865,1910.8700415804628 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981634031745,-1.1452547851961034E-11,-100.0,100.0 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark07(-0.785398163476783,-9.527674424075348E-9,-0.39269908165905676,0.7853981633974492 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981636619407,-5.289859781597753E-10,-14.752109030869674,55.786648649230756 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853984666928537,-2.444004370654656E-6,1.1464011996309849,-99.99999571040122 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853995980212364,-2.8692475766183487E-6,0.3926997990106182,-99.99998892437057 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853999380384142,-3.549281994843729E-6,-100.0,0.7853999380384458 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark07(-0.7854057417098003,-1.5156624704093881E-5,-33.45385098635078,-20.70309813960024 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark07(-0.7854135870199621,-3.0847245028575566E-5,65.16282471003859,1.5423622514258377E-5 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark07(-0.7855274171314636,-0.022335495711198874,0.3986966380759309,0.01116774785559943 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark07(0.7859568685565036,1.9620805020858219,-99.33675544658455,68.92071129899318 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark07(-0.7864208172560385,-0.002045307717180811,8.329163996619883,0 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark07(-0.7867743352871039,-0.002756345070701522,-100.0,51.828044730928944 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark07(-0.7870787375206519,-0.0033611482464075883,-0.11165917174488411,-17.10843138565813 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark07(-0.787182538502714,-0.0035687502105325028,-61.70349201467974,-3.431342872361484 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark07(-0.7872119980863658,-0.454546655198823,-0.17586046472354935,-1766.994333660118 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark07(-0.7873801823222508,-0.5209812919636657,-33.93973974199442,26.35676688624862 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark07(-0.7891767100222269,-0.5235987755982987,-96.7228475635516,-12.499678034998338 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark07(-0.7894965617703105,-0.5235987755982977,0.39474828088515523,17.540558940634988 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark07(-0.7898103642402349,-0.06743009599017927,0.40955660569626895,-78.49660915647956 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark07(-0.7902981454331296,-0.09685007648271465,-66.33289215829764,-0.7329966469517889 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark07(-0.7903749941058285,-0.009953661416760705,1.1805856604503624,-7.55720154918188 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark07(-0.7911709483509863,-0.38123509666673217,0.37252176340112353,-91.42711774488136 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark07(-0.7912249157238619,-0.15200601108574158,0.8998600907659453,-1.3518053101433338 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark07(-0.7936385414358107,-0.4767363311622828,-0.2617993877991509,-96.21452938591017 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark07(-0.7942274157147808,-0.017658504634665336,-7.723593294422642,25.250704539597525 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark07(-0.794533049028685,-0.018269771262474317,0,0 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark07(-0.7946141455128911,-0.09806725201525908,-14.6776166315466,54.84218365649648 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark07(-0.7966704253790536,-1.5212904088966346,-17.659568630375315,67.5753514876695 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark07(-0.7967401522703024,-0.022717791184025945,-53.076805211168406,96.71755234220355 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark07(-0.7967536641251733,-0.022711291754742152,-0.3870213313348616,38.4971805726728 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark07(-0.7969425429340143,-0.40743653672387004,-96.9912686924349,0.9264747253083448 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark07(-0.7977527316294237,-0.024709136463953008,1.1842745292121597,0 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark07(-0.8009413029229719,-0.11729387302103993,-52.089209890939365,23.081806774903647 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark07(-0.8047930237523385,-0.03878972070978065,-0.08181493466707349,-0.766003303042558 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark07(-0.8048592225605082,-0.03892211832612169,-100.0,38.98269460332071 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark07(-0.8060593144437107,-1.0619298338160228,-89.71365652340842,-100.0 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark07(-0.8063119182779812,-0.4958061959349871,-60.85965403401511,0.24790309796749355 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark07(-0.8083288688939378,-0.04586141101659777,-75.1163784498933,37.07444619701113 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark07(-0.8105107682713497,-0.05022520974780307,-77.87563374797269,0.9858508021001834 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark07(-0.8107769433397038,-0.487926074928653,-0.37911108130369775,1.029361200861775 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark07(-0.8131342263869318,-0.1040107205814525,-70.58171214800691,-0.7333928031067221 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark07(-0.8143246937257418,-0.5235987755982987,-0.3782358165345774,-5.308429673620177 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark07(-0.8156662798028878,-0.06053623281087919,52.98135603953087,0.030268116405439596 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark07(0.8163154143204627,2.7774772098562424,-16.106885367746173,-0.6033404415306691 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark07(-0.8168713536456693,-0.06294638049647844,0.3885184903000685,-83.71951348400572 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark07(-0.8177488446746725,-0.09270823034472031,0.5492836420434624,0.046354115172360155 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark07(-0.8182857256832474,-0.0659000014209017,0.4091428628416237,0.8183481641078991 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark07(-0.8218459474181357,-0.072895568041375,0,0 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark07(-0.8238377113706234,-0.5210808294073314,0.4119188556853117,-64.9280904878756 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark07(-0.8262895591168473,-0.19629809396125683,-68.73370576716337,-54.44871983384504 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark07(-0.8281887847103143,-0.0969054059447466,-58.18046971716133,0.8338508663698215 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark07(-0.8285190960387643,-0.08715199763811014,0.41425954801938214,0.04357599881905507 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark07(-0.8289414284161385,-0.164251974269561,0.41447071420806925,0.0821259871347805 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark07(-0.8292458356807623,-0.11646950386642882,-64.33257059894449,-29.786895455258716 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark07(-0.8302973097976477,-0.523598775598181,-89.13676926556315,-0.5235987755983587 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark07(-0.8335868720729079,-0.09637741735091995,-0.3686047273609943,-33.725255239015226 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark07(-0.833738455807677,-0.4713704471780025,-0.07215504121299239,-95.87384151644797 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark07(-0.8344823845294682,-0.21315233364186884,0.4172411922647341,65.88133578409703 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark07(0.8350741593900954,-2.220446049250313E-16,-1.202935243092496,52.24455657691447 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark07(-0.8353259163561049,-0.517653320159021,0.41766295817805243,0 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark07(-0.8365027834527794,-0.11121767386313997,0.4182513917263897,-14.659547886252282 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark07(-0.8377651759809848,-0.45933693975982015,-40.433699601877564,44.994769311879224 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark07(-0.8431517145658333,-0.5235987755982987,0.4091663335562642,-30.921495349559432 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark07(-0.8464518224808618,-0.12210731816682723,-54.70467250797264,0.4622460145670481 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark07(-0.849639542616719,-0.21751699716953174,-0.3605783920890888,7.57440984788088 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark07(-0.8511272972741097,-0.16840922604993822,-0.3598345147603933,0.8696027764224173 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark07(-0.8519820566615761,-0.1331677865282558,0.42599102833078806,0 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark07(-0.8521999121430059,-0.5235987755982985,-15.97304872909925,0.2617993877991493 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark07(-0.8524284258886805,-0.23943989592263276,-60.11746327265567,83.83612736217022 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark07(-0.8539360625589865,-0.5233399625259865,-0.35843013211795505,-0.523728182134455 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark07(0.8553082715548556,1.7106165431097113,-1.2130522991748762,4.680210131275151 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark07(-0.8557278635966448,-0.14065940039841152,1.2132620951957707,0 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark07(-0.8575495159891611,-0.5235987755982987,-2.4913031073293865,0 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark07(-0.8575645691473683,-0.1877475132824406,-0.3566158788237641,-77.37483710110138 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark07(-0.8601445470731841,-0.21083390936754187,-60.141943419165024,36.36293446905022 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark07(-0.8621600988812421,-0.5235987755982929,-27.579277368595644,1030.5009376337728 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark07(-0.8623018292193292,-0.5235987755982947,-0.17096915353579625,20.89884476328351 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark07(-0.8625655353157158,-0.1543347438369156,-100.0,-0.7082307914789904 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark07(-0.8636885713461208,-0.3277058111724724,-0.3535538777243879,0.1638529055862362 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark07(-0.8641264250121559,-0.5235987755982947,0.43206321250607793,73.74256037698476 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark07(-0.866781705645101,-0.18397746408186175,0.31520904240530917,45.081448043343435 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark07(-0.8678995492567702,-0.5020488902120007,0.43394977462838513,1.0351076881840175 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark07(-0.870416375157482,-0.5235987755441901,-0.2797109981533163,0.26179938779914824 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark07(-0.8707839179376353,-0.5218298477983315,0.43539195896881766,-1.2407084005182014 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark07(-0.8712269104552105,-0.17247092107222084,-45.95534453764692,-99.9775397338324 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark07(-0.8718781468400968,-0.174931843804642,0.43593907342004845,0.08746592014657954 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark07(-0.874067785237771,-0.4797254535310852,0.4370338926188855,-10.915706575258426 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark07(-0.8763851209774627,-0.5229291371272602,0.5234313659805423,0 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark07(-0.879572526993708,-0.1883487271925197,0.4280162839866645,0 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark07(0.8796258098227863,-2.7755575615628914E-17,56.89741855648576,69.31817787429125 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark07(-0.8824829766372899,-0.19416962647968355,-0.34415667507877395,0.88248297663729 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark07(-0.8831945502120462,-0.19559277362919641,0.4415972751060231,0 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark07(-0.8862101249584292,-0.5235987755982987,-0.3422931009182336,-57.047001786530345 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark07(-0.8873304687616271,-0.313957260460013,0.44366523438081357,-0.6284195331674418 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark07(-0.8876272815424147,-0.3463309732930018,-85.83657948233869,0 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark07(-0.8881654866783233,-0.23229258102258737,-0.3413154200582862,0.2617993877991498 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark07(-0.8907941199224156,-0.3182675908048068,0.44462766641022383,94.18422761434533 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark07(-0.891804289255459,-1.0931798521361529,0.5549359015933302,-100.0 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark07(-0.8920408573234115,-0.21328538785192666,-43.392272968147324,-100.0 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark07(-0.8941675776986285,-0.5205438095773344,-2.5847025776862615,67.82048552968588 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark07(-0.8947186433486707,-0.2186409599024741,-0.09977840938337357,0.10932047995123705 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark07(-0.8947783045078064,-0.22144261482722138,0.6934352308006311,0.11072277550548658 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark07(-0.895288787191963,-0.21978124758903056,-2.910857149951458,-49.51589159551246 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark07(-0.8959608921362059,-0.2792168411417839,-0.3374177173293451,0.9250065839683402 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark07(-0.8996393793856016,-0.22848243197630674,0.4498196896928008,-0.6711569474092949 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark07(-0.9013607607696965,-0.5235987755982983,-0.2769970062095002,-48.434946774775256 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark07(-0.9036401671189094,-0.5235987755982987,-33.669055806964955,-0.5235864084957423 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark07(-0.9057831192611233,-0.5214296812511993,0.45289155963056166,-23.31066202313813 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark07(-0.9073025824148433,-0.36578562575006723,-34.47300739616227,0.18289281287503362 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark07(-0.9086816465368811,-0.5235987755982947,0.45434082326844055,19.28567047609314 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark07(-0.9089375647580971,-0.5222754465006856,-61.09829980302211,5.0217286896363476 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark07(-0.9132762435234055,-0.47171403407307955,-33.95950645684432,-100.0 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark07(-0.9139404985027255,-0.3272850647633755,-66.48569781233371,14.300606395148165 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark07(-0.9148995300182166,-0.2730752050515977,-11.51718695118845,-156.1563819473633 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark07(-0.9150705881439418,-0.5234000006486447,-62.36499451239195,100.0 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark07(-0.9155454949921971,-0.2602946631894996,-74.1472036093303,-3.4271444041525747 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark07(-0.9163277095528815,-0.5235987755982983,1.243562018173889,63.83833184024271 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark07(-0.9176741955979231,-0.5235987755982974,1.243634128294344,100.0 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark07(-0.9204520812403172,-0.27042992845027836,-0.3251721227772896,100.0 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark07(0.9225117472298188,2.143261606761132,98.64674697818292,-1.0715687335633213 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark07(-0.9235320642083485,-0.5235987755982627,-28.244163902018826,0.26179938779913137 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark07(-0.92431126498249,-0.27782620317008466,-2.9601824773365597,0.13891310158504266 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark07(-0.9249412705120895,-0.5235987755982976,-112.64767791341731,0.26179938779912937 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark07(-0.92533292668408,-0.5066849166618262,0.46266646334204,-0.5320557050665351 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark07(-0.9266379344623681,-0.5235925577592938,-73.56577103585568,0.2617962788796469 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark07(-0.9267658033151225,-0.5235987755982983,0.46338290165756124,-95.33163620013177 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark07(-0.9280067806905713,-0.5235987755982983,0.46400339034528565,56.77617532715615 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark07(-0.9297288864881382,-0.5052205293198485,-56.16111903143374,1.0366935077379522 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark07(-0.9309688456505583,-0.2911413645062202,-0.08840470079686374,0.14557070155743115 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark07(-0.9310995772845184,-0.5235987755982987,-75.99553906304344,0.2617993877991493 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark07(-0.9312685855025932,-0.5235987669461175,0.4656342927512966,1.047197546870507 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark07(-0.9322926060291987,-0.5235987755982975,0.46614630301459936,0.2617993877991487 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark07(-0.9333459417749586,-0.2958955567550209,-100.0,-94.29485380015123 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark07(-0.9341405274755086,-0.32961595163538515,-49.356501299422675,-171.6138074244818 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark07(-0.9344467673151584,-0.29809720783542515,-37.21421331729899,91.21572873806883 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark07(-0.9349824212819299,-0.3202974398856184,-0.3179069527564833,-0.6252494434546391 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark07(-0.9377827057458209,-0.30476913426437796,-0.31650681052453783,16.64706091879806 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark07(-0.9389767670931048,-0.5235987755982983,0.4694883835465524,-57.24483193554812 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark07(-0.9412413074650721,-0.31168660985542235,0.47062065373253603,-92.1537197493148 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark07(-0.9428877774156508,-0.4423188025373398,-0.31395427468962284,1.0065575646661182 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark07(-0.943298042249656,-0.5235987755982983,-62.36211531881799,59.802618651818904 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark07(-0.9435761066188426,-0.5235987755982983,-100.0,-0.025181442476371108 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark07(-0.9527199788665879,-0.5235987755982987,-0.3090381739641543,0.26179938779914935 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark07(-0.9542198845456693,-0.5235987755982987,-34.14208247655455,-0.5235987755982989 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark07(-0.9546389291273514,-0.39252839641177295,-3.648437498026111,55.04579916927462 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark07(-0.9549973688977,-0.48005114471699933,-0.3120474090762062,-100.0 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark07(-0.9557098557706936,-0.5235987755982974,0.4778549278853468,45.55373250943191 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark07(-0.95657718414055,-0.5235987755982947,-0.3071095713271732,0.2617993877991492 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark07(-0.9569893267328136,-0.5235987755959027,1.216960043661946,1.0471975511953995 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark07(-0.9587378598649625,-0.4932451210750275,0.4793689299324815,-26.675771151935244 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark07(-0.9589323363933842,-0.523598543584648,-143.46741152643636,1.04719433350847 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark07(-0.960695620842726,-0.3505949148905567,0.5297860561768744,-73.87367341920854 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark07(-0.9612762114147513,-0.3517560960346068,-2.9431534588881902,-76.54231919179003 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark07(-0.9618962328830527,-0.5235987755982983,-100.0,78.60328588717553 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark07(-0.9620864747414171,-0.47688506811561115,0.481043237370713,0 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark07(-0.9629542256509335,-0.3705599528481308,-100.0,11.203445411787458 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark07(-0.9656551362729326,-0.4432544285053885,0.17206609688969454,-70.22463354995249 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark07(-0.9677922190278705,-0.5235987755982974,0.04254461921744823,-0.5235987755982996 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark07(-0.9692291683566493,-1.9323856591840802,-130.65303425458467,85.00377201994965 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark07(-0.9696665376157667,-0.5235987755982983,-11.736824093017232,-1.4440947775210535 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark07(-0.972291989890815,-0.3740935861383043,0.4861459949454075,91.71182590417837 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark07(-0.9767710414434657,-0.5233584478042047,0.5620071613018247,0.2617993666069676 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark07(-0.9790114926768374,-0.38722665855877847,-0.2958924170590296,-41.646253793666205 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark07(-0.9822749350739937,-0.443051260818906,-59.93201537308745,0.5916233030031322 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark07(-0.9822847128934646,-0.5235987755982006,0.13880352992912587,-100.0 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark07(-0.9830239904193055,-0.5235987755982947,1.1050306670758425,-20.875296332789247 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark07(-0.9830438207807862,-0.5207450418605791,0.033055394021248644,1.0444557640082759 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark07(-0.9832986569884793,-0.3958604533222284,-0.2937488349032086,60.662722534083855 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark07(-0.9837403694500988,-0.523594954170749,-73.95634871972383,0.2617973552346664 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark07(-0.9870227543103093,-0.40324918182572217,-0.2918867862422937,-4.194274099438631 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark07(-0.9894102909297686,-0.5226725320109133,-40.77046881867071,2071.007741789383 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark07(-0.9894990849828766,-0.4082018431708569,-42.29740550671117,-2024.4724386305336 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark07(-0.9895699581863192,-0.49951846578277853,-0.29061318430428873,-49.63935231178094 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark07(-0.9917660872540163,-0.5186068648339918,-0.2895151197704402,-72.848616557868 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark07(-0.9921061985319154,-0.4222700434309549,-56.40980613971637,0 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark07(-0.9925359752527738,-0.41427562372791504,-43.776748167676764,-0.6444991541663955 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark07(-0.9941685055136109,-0.4493714106930213,-0.2883139106406428,40.12969781233661 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark07(-0.9956025446521195,-0.5235985851427107,-100.0,17.6642885466876 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark07(-0.999532955456872,-0.46172716718929974,-40.76124211385427,-68.7786671745481 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark07(-1.0011832948106931,-0.5224767459671709,-62.534637266522914,1.0466365363810337 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark07(-1.0028503204400903,-0.5235987755982987,-110.59817858848868,0.26179938779914935 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark07(1.0028887694081572,-5.551115123125783E-17,-13.853117736040645,17.175478021104503 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark07(-1.0031759468327737,-0.5230609314672783,-57.56582559156782,53.72235111619602 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark07(-1.0055921346702656,-0.5235987755982987,0.5027960673351335,-1934.3887906278692 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark07(-1.006393680092796,-0.44199210415725104,-0.2822013233510503,-0.3884642077441969 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark07(-1.00763602273568,-0.5068081422828428,-28.12650350701896,-52.1175131845982 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark07(-1.0129802547493467,-0.45516418270380304,-0.2789080360227749,1.0129802547493498 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark07(-1.0138028515089916,-0.48373498972199436,1.1887848919039796,-0.5435306685364512 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark07(-1.0155336951434322,-0.4621332911907015,1.2931650109691635,0 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark07(-1.0156546802514204,-0.46051303370794433,-0.2775708232717381,0 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark07(-1.0168256460468543,-0.46285496529882053,-100.0,-95.71639203999571 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark07(-1.0172122032176736,-0.4636280796404508,-27.8421449883687,-27.04855306594716 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark07(-1.0181635989991722,-0.5235987755982945,-93.45723500657256,1.0471975511965956 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark07(-1.019640224505796,-0.5235987755982983,-55.83459176344013,-20.894838563986063 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark07(-1.0199860101263991,-0.5010901895364263,-86.60990451986925,-0.5348530686292352 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark07(-1.0205174282481901,-0.49643799552339807,-100.0,0.24821899776169903 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark07(-1.0210584424118054,-0.4713205580287145,-100.0,0.23566027901435727 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark07(-1.0235330216300589,-0.5235987755982987,0.5117665108150294,1998.2570063370579 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark07(-1.0238246394731587,-0.48564776705288787,0.5119123197365794,-0.5425742798710043 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark07(-1.0240534034067308,-0.4773104800185652,-61.60665912940482,1845.1117637205843 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark07(-1.0254437587397027,-0.48061626421143955,0.5127218793698516,1.8111044589006164 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark07(-1.0259169461341013,-0.4810375654733075,-20.996863310713366,45.47481918869558 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark07(-1.0265829522033927,-0.4993522190285914,-27.474663133040664,26.903940746818392 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark07(-1.027295696012851,-0.5235987755982983,1.2990460114038735,-1923.4685954345744 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark07(-1.027946914648646,-0.5235987755982987,-0.2714247060731253,0.2617993877991494 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark07(-1.029409695188372,-0.5151939017671241,-101.60426576144415,4.538978234684194 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark07(-1.030400338736218,-0.49816667542785587,-56.60135198568096,58.07950066854057 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark07(-1.0307234656463544,-0.49125532369031977,0.4759812552266215,0.1988211448861727 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark07(-1.0315037548712933,-0.5235987755982987,-93.26192817288516,0 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark07(-1.031679087366058,-0.50109629580307,-78.53850256769259,0.25054814790153496 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark07(-1.0319646965477696,-0.49313306630076414,-52.601908827945614,-20.216950203716166 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark07(-1.0319711432669862,-0.493145959739077,-66.13933292433087,117.92465900687236 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark07(-1.032760505236724,-0.49472468367855144,0.516380252618362,7.6723684915160675 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark07(-1.0334975297230151,-0.5855107756197282,0.1810933896174656,-87.67473230551957 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark07(-1.034249076686653,-0.5235987755982983,0.8346979781819769,1.0471975511965974 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark07(-1.0344780806270923,-0.5235987755982987,-68.95206506702613,0 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark07(-1.0357653977910242,-0.5007344687871523,-41.04599648510214,38.56229907225025 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark07(-1.0360123824154435,-0.5077123748945773,-90.46919388155041,85.06778997472222 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark07(-1.0364620064077694,-0.5021276860206432,0.5182310032038847,0.21903682277893288 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark07(-1.0366293137911817,-0.5234050787395793,-79.76340195417458,99.99999999999997 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark07(-1.0368595898684394,-0.5199426026106275,-43.64335168979846,0.25997130152656817 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark07(-1.0377173223100442,-0.5163747444851969,-100.0,95.15801223361899 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark07(-1.0383852412331713,-0.5235987755982983,-67.41819860255787,0.26179938779914935 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark07(-1.039038119061812,-0.5072799113362548,-100.0,100.0 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark07(-1.0410210776686828,-0.5112458285424692,3.367031874849328,0 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark07(-1.04149337496486,-0.5121904231348242,0.08043972437451008,0 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark07(-1.0416006086334517,-0.520822809133098,1.091670142030052,-0.17755463489830714 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark07(-1.0421995277961882,-0.513602728797482,-0.2642983994993542,25.42944299108754 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark07(-1.0423863666681599,-0.5139764065415324,-30.979479844647166,-93.7664923046804 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark07(-1.042410870074606,-0.5140254133543163,-11.155084339582038,1.0424108700746064 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark07(-1.0426361698821789,-0.5144760129694614,-0.2640800784563589,-77.3873415804765 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark07(-1.0431096428390123,-0.5154229588831283,0.9118517158862371,-1967.6444883172778 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark07(-1.0442211165921302,-0.5176476610051803,-14.67646103724772,18.48364058305573 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark07(-1.044682989375752,-0.5235987755982983,-0.24559608499261507,-0.5235987755982991 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark07(-1.0449419211251574,-0.5211840488533104,-54.87532367572935,0.2605853533133264 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark07(-1.0449681715557098,-0.5227578763134375,-0.2629140776195934,-55.50057574273335 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark07(-1.0450548905287953,-0.5193134542627066,-0.013975653871010603,-100.0 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark07(-1.0451008880543622,-0.5209434343527084,-3.7500880370157255,100.0 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark07(-1.0451395431226922,-0.5194827594504885,-56.20008768934066,20.944958060116335 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark07(-1.0451484092107728,-0.5235987755982983,-0.26282395879206194,-56.142997034110664 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark07(-1.0453076259808574,-0.5235987755982987,-98.56194833035316,1.0471975511965976 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark07(-1.0453799315225166E-4,-4.149916623663905E-5,-100.0,25.91684522137949 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark07(-1.045582401713339,-0.5235987755982987,-77.72572536478397,7.0657648365302075 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark07(-1.0456343722997512,-0.5235987755982987,1.3074558386515378,-1.1381355986244128 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark07(-1.0457981868159345,-0.5233261506300486,0.48233794604280034,0.8711536513217523 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark07(-1.046252249855807,-0.5217081729173545,-18.47199410028365,-0.3622936561603069 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark07(-1.0463885932546464,-0.5235987645471519,1.3085924600247714,-10.204752484646775 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark07(-1.0463920263610836E-12,-1.096558828758922E-12,0.7853981633979715,0 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark07(-1.0465781909899754,-0.5235987755489744,0.4456054769752289,-79.24634490781929 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark07(-1.0468171918360665,-0.5235624274932474,-0.26198956747941526,0.2617812137466237 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark07(-1.046859258436749,-0.5229221900786019,-89.69759919505884,19.639891421934337 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark07(-1.0468885267917472,-0.5235987755982986,-58.06197361151883,0.2617993877991493 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark07(-1.0470668326406234,-0.523566129287852,-0.26186474707713664,-6.938093463857058 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471524311974658,-0.5235987755982987,0.7187744249396912,0.26179938779914935 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471766730073613,-0.5235570192198263,-16.853955873989115,0.6072430836436736 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471972491643309,-0.5235981787361995,-0.2617988839232482,90.86444912331106 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471974393763688,-0.5235985519578413,-6.556424999374906,78.67217564587611 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark07(-1.047197545711989,-0.5235987755982983,-14.996270719779735,-0.5235987755982991 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975491882144,-0.5235987755982987,-0.26158429394724403,-93.18586673928255 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark07(-1.047197550137712,-0.5235987734805276,-32.76630976468102,1.047197550137712 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511963336,-0.5235987755982983,-66.06664109460836,4.2481103100708 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511963796,-0.5235987755980618,-85.12474770493895,0.2617993877990309 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511964389,-0.5235987755982988,0.5235987755982194,1.047197551196475 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark07(-1.047197551196568,-0.523598775598245,-30.14982054422881,0 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965728,-0.5235987755982935,-100.0,0.26185381974533534 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark07(-1.047197551196583,-0.5235987755982696,-0.2617993877991568,100.0 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965876,-0.5235987755982912,0.5235987755982938,100.0 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965894,-0.5235987755982947,-81.79915225064865,-85.85025441713395 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965894,-0.5235987755982983,-77.70047017549473,99.21642978891526 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965903,-0.5235987755982843,-0.2617993877991531,64.71005006750632 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965903,-0.5235987755982843,-1.5156729634886852,0.26179938779914214 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965912,-0.5235987755982983,-72.74900131939401,0.26179938779914913 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965927,-0.5235987755982959,-100.0,-78.54084099427361 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965934,-0.5235987755982983,0.5235987755982983,35.49341022685301 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965934,-0.5235987755982983,1.3089969389957439,-76.32547876417121 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965952,-0.5235987755982947,-23.05638285633185,41.898621427636606 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965954,-0.5235987755982945,0.5235987755982977,-136.38979962762846 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965954,-0.5235987755982979,0.5235987755982977,-19.282906599582827 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965956,-0.5235987755982949,0.5235987755982978,-45.17033102948924 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965956,-0.5235987755982977,-77.25637305585501,-90.24303314301945 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965956,-0.5235987755982987,-50.89839372167826,1.0471947144246083 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965965,-0.5235987755982967,-0.26179938779915,-27.228451251431004 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965965,-0.5235987755982983,-0.26179938779915,-42.0024579752893 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965965,-0.5235987755982983,0.5235987755982983,-64.7695082110719 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965965,-0.5235987755982983,-32.19862937365826,92.40160797153713 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965967,-0.5235987755982983,-0.11453497254652811,2084.8668471655583 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965967,-0.5235987755982987,-0.2617993877991497,13.16966661076192 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark07(-1.047197551196597,-0.5235987755982978,-53.02792800911566,-56.54543129501742 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark07(-1.047197551196597,-0.5235987755982983,1.3089969389957465,-68.66785149230294 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark07(-1.047197551196597,-0.5235987755982987,-60.57182387797484,0.26179938779914935 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965972,-0.523598775598298,1.2582877962609391,78.80603448248183 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965974,-0.5235987755982985,-14.70160622680328,-46.26622558452884 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965974,-0.5235987755982986,-37.970942513858844,-50.58973770530729 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965974,-0.5235987755982987,0,0 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965974,-0.5235987755982987,-99.39150577944316,61.43132225303384 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark07(-1.0505513917648712,-0.5303064567349749,-33.524822847481474,271.33743204541884 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark07(-10.551684253386684,-20.16296017270019,4.37235929704711,27.360170359294667 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark07(-10.553593618324824,-19.65733661210108,5.276796809162412,20.746647475583497 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark07(-1.0627201631380077,-0.5577423076532477,-100.0,-1629.547528325736 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark07(-1.0657428767953303,-0.1238220970670959,-100.0,0.7853981633974486 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark07(-1.0713618055382337,-0.5719272842815736,-66.30626454241242,-100.0 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark07(1.076730737161788,0.2815096096946767,99.99999998870962,22.649358058533416 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark07(-1.080795482197116,-0.6301228135531147,1.325795904496006,0.31506140677655736 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark07(-1.081158140082921,-0.5969137113762397,0.5170762477134846,19.931069471813288 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark07(-10.812376904820649,-0.11345006720727561,27.98740116630239,41.075857173182015 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark07(10.824577085263584,-39.43757840353555,89.7204091048099,-47.1181774914381 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark07(-10.824781183295812,-53.83929589951955,-68.44818829730805,39.56996559239599 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark07(-1.0850181228638407,-0.5992399189327852,-100.0,1.0783757369596287 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark07(1.087188155485546,2.2453892129590187,-72.5784993781408,2.0188973369956216 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark07(-1.0908693669372351,-1.2772744496515174,-100.73336356857385,-1.696728740155557 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark07(1.1043814799096978,2.2087629598194054,67.0940442267145,-1.1043814799097027 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark07(-1.1102230246251565E-16,-1.1102230246251565E-16,-65.86092290865953,65.25450936929788 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark07(-1.1102230246251565E-16,-2.2204460492503128E-16,0.47704992053289175,-0.7853981633974483 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark07(1.1102564292482187,2.22054988313334,0.23026994877333884,-1.1220637137367038 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark07(-1.1142665299857316E-16,-2.220446049250313E-16,-153.21774903048998,81.68785284032357 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark07(1.129044074627637,2.2580881492552747,81.1168869560208,0 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark07(-11.317931408042403,-21.065112607575404,5.658981839218167,33.299462900233294 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark07(1.135118680791001,-0.5029647864435787,-92.45898369416929,45.28279526334035 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark07(-11.35608713139761,-17.85846562836531,-32.542211574250175,-57.972784587560795 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark07(-1.1356362913640592,-0.957868704890743,-40.530844506020244,-4.381076900299404 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark07(-1.1381814142559654,-0.7136321380775015,-92.89852628502413,3.451717362069637 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark07(1.1404762046341834,2.2809524092683677,-34.518021287926814,97.8363183732983 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark07(-11.415715691529233,-21.465897314689226,5.763799551884921,27.22598866184266 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark07(-1.1503633080496163,-0.7299302893043365,0.5169952562223288,1.8509504893638962 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark07(1.1690817836384835,2.3381635672794507,-0.5845408918122645,-55.7871600767737 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark07(-1.17091783746666,-0.5235987755982987,-64.7280494122332,1.0471975511965976 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark07(1.1734941620962167,-1.0097419586828951E-28,-41.41097545857363,-46.28372211716693 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark07(-1.1782455248595671,-2.7755575615628914E-17,57.92064454677143,1630.1689163397477 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark07(-1.1806664645395084,-0.8206957983259643,-42.16944704975181,-0.37505026423446625 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark07(-1.1828254675775711,-1.9516409547371465,-2.2325025803552725,-4.5047243969214 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark07(-1.1837734092190022,-0.7967601731936589,0.5918867014502608,-194.495793920106 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark07(-11.838386989367335,-0.5235987755982987,-72.62083503819068,-100.0 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark07(1.1854741271192057,2.3719262222955697,0.6151914752668711,-1.1858888071892102 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark07(-11.888823434716926,89.38863437742515,0,0 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark07(12.103729921393365,24.2970823948912,-100.0,-85.97435941317184 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark07(-1.210929449134511,-1.0208731469282695,0.3286011529532348,-45.54896793485311 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark07(12.28762270559697,25.82686859191611,-6.143811352798485,-8.986443225023176 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark07(-1.23378127903378,-0.8967662312726645,0.6168906395168898,-0.337015047761116 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark07(-1.2517059327776873E-12,-2.503411865555374E-12,-69.23114391066035,-65.54809914422333 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark07(12.57003961999358,24.293705045677697,-148.39773226976632,-12.146852522838849 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark07(1.2700423811391885,-0.002958303079790875,-185.95994746960585,-35.487455802655944 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark07(-1.2797700499053055E-12,-9.336667898418513E-13,-80.23226350291452,-39.70090633602964 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark07(12.959233024763492,50.81626259897192,23.217837909552628,-11.39881361936797 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark07(-12.978579537785459,-24.386707707670304,-58.9124559905996,12.193349682258312 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark07(-13.152187675345866,-0.19021544201128535,89.04283157780526,90.24932534460325 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark07(13.238997021066488,26.478241387641802,-97.29217308763786,28.385409507163192 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark07(1.3348077986470832,-0.0032691979174033683,-6.9489925389192715,-65.01975763480188 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark07(-1.3384860201489859,-1.1061757135030754,-55.434940156608775,-100.0 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark07(1.3419553424848,2.6839196312231737,0.11441322172906533,-0.5552266576190877 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark07(-13.48196930988317,80.58710494644669,0,0 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark07(1.3518913709894833,2.703782771188024,-0.6759456854947417,58.586898196878245 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark07(13.527680406251081,28.62477882109661,-7.425347617702054,6.95719166058449 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark07(-1.3585097394237038,-0.4237383245074875,-142.27377275443743,-100.0 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark07(-1.3617173422359057,-1.3495709225472547,-12.036964685547199,1.4662010460794017 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark07(-13.65554370920485,-26.71604844876977,0,0 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark07(-1.3656344481653242,-1.2316786855713122,1.2141922429050358,-42.57087152522381 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark07(-1.3712095060010447E-10,-4.7627048618121767E-11,22.61377550055564,0 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark07(-1.3786016234383802,-1.1874105330828206,-82.76855535322395,-84.23029837187786 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark07(1.3791494420816273,2.7582988841632554,-66.52511231828471,-31.226023587257085 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark07(-14.248393289053539,-46.99937083194874,13.131461949693701,78.78648437281112 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark07(-1.4250542927335261,-1.2796800154111645,-48.019263278619086,90.04614656956194 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark07(-1.4271555839834842,-2.63513791693448,0.7458769363276333,-100.0 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark07(1.4276576262658809,-1.1102230246251565E-16,-51.64007966717649,100.0 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark07(-14.820326426188753,-28.138946314518815,8.195561376491824,13.28407499386196 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark07(-1.5051545859571438,-0.5159039054553074,-91.98749981306928,76.17071766302756 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark07(-1.5165646516379638E-13,-3.0310279300407644E-13,-40.05174776479653,17.999647052720018 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark07(15.18556196705174,65.85667450311328,0,0 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark07(1.5221661975533054,-3.009265538105056E-36,-1.546481262174101,0 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark07(-1.5260134466176982,-1.8118699635694695,-0.022391440088599168,29.18026697415776 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark07(-1.5266629017117468,-0.5235987755982983,-80.13338202723914,-813.4581512789978 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark07(1.5346280963278773,-6.871200063588771E-11,-89.07417286978838,-212.95715056745837 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark07(15.507475451660596,14.745465747606929,20.05302717020001,-53.68353421302161 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark07(-15.52064434902664,31.150829655211368,0,0 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark07(-1.5596831594435607,-2.975158131751,-0.00555658367566785,-0.8437087314374985 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark07(1.562351749711787,-0.15944809566089357,100.0,0.07972404783044684 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark07(-1.563009356224522,-2.0695328615981863,-0.0038934852851872925,131.41456928466627 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark07(-1.5737141427051742,-3.1474282854103475,0,0 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark07(-1.5801968091614402,-1.5895972915282857,0.004700241183271859,0.00940048236669444 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark07(1.5876399546367077,4.689679507183916,-0.11322500968372712,21.21710514833149 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark07(-15.918147021903204,-30.317129143745525,-73.67516675911897,-68.87904020621188 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark07(1.5946674109728718,4.687762392324803,-0.7973337054864359,-86.38029698418215 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark07(-1.60480696709734E-4,-1.2568015566208495E-4,-1.0468060221670634,76.62362185663316 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark07(-16.056446807281297,-30.54628559962656,7.242825240243201,-20.855172595387263 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark07(1.6080337107116902,3.7290235936686034,-0.803135474904929,-100.0 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark07(-1.6161172568591873,-2.9379140643874435,-64.97335156557392,77.65257672332925 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark07(16.18050991337001,33.86180842265142,-100.0,21.55660053152743 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark07(1.6286671246882327,4.828130576171357,-0.02893539894666819,-2.4140652880856783 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark07(16.329919164146233,-44.798947539119794,71.08966011465122,-3.057994902441891 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark07(-1.6350184665013976,-0.5235987755691028,-62.806593406696,84.53989195523806 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark07(-16.530671678638676,-31.799463134089226,7.47993767592189,-26.511757187023235 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark07(1.6686606868311653,4.809743294732653,-0.04893218001813435,7.113360825761919 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark07(-1.670421574473207,-1.7700591817858455,0.04982126543001575,-91.05803183604662 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark07(-1.6793521351460108,-2.5739960476072317,0.05427790417555714,2.0723961872010643 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark07(-1.6875650034981884E-12,-1.11038226034552E-12,-99.99999999999895,-99.99999999999895 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark07(-1.6968924484731866E-12,-3.39371952297041E-12,-0.7853981633965998,100.0 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark07(-1.707107535049524,-0.7880960750412266,1.9520220790233376,0.394048037520605 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark07(-17.080627435302382,-33.396521116584765,8.006931652917297,16.698260558292382 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark07(-1.7151351254740943,-3.359709493387557,-10.980376217910178,-29.03239366626614 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark07(17.1868144467483,35.5617662611442,-89.98722754081969,19.918186249358094 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark07(1.727039473404159,4.809734557778088,0,0 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark07(-1.7288387357426036,-1.8868811446903568,0.07902120447385357,-95.07483300946039 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark07(-1.7408656624520862E-15,-4.3790577010150533E-47,8.704328312260431E-16,33.757896770156684 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark07(-17.419850119800515,37.22411287002393,-39.24948746118781,24.583926629919347 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark07(-17.429708683791624,-0.5227041745642464,-6.993179224522919,54.283889802025854 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark07(1.7734065103888668,-15.143059209953577,0,0 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark07(-1.7763568394002503E-15,-3.5527136788005E-15,-23.35740201580714,-40.85651241852253 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark07(-1.7763568394002505E-15,-2.220446049250313E-16,-83.11669948815043,73.76767012043503 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark07(1.778442876683077,-1.3138101980516957E-4,-1.1503887461626883,-4.378726884180555 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark07(-1.7792952256198418,-3.2776876833479927,-5.147574794134542,177.06802050389967 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark07(-1.780998551865258E-4,-6.875105172591589E-18,-100.0,3.437552586295794E-18 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark07(1.7886614408047294,4.867678419715477,70.208008076172,-2.4338193078025463 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark07(-1.82648001261513,-2.082163886296789,-89.00041747777692,-52.645271812161255 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark07(-18.282390787114068,-90.62217006776964,24.487296759171315,86.49126765640278 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark07(18.30244072603608,-12.141311872842325,-8.927793791039937,-64.38652634724905 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark07(-1.8320193732418149,-2.186557988999604,-65.68879635804508,12.334677792944989 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark07(-1.8438421118908892,-5.487896315989466E-4,45.149038527757526,-20.81392264913189 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark07(-1.8497164702537485,-2.1286380866958434,1.689222453551295,100.0 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark07(1.8640242815582582,2.2622983080272645,-0.1466139773816808,-29.461738988591755 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark07(1.8834008823904913,4.06736657530429,-76.02151589276784,144.83577350061898 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark07(1.94226528920805,5.328903756702408,-0.9711326446040249,-48.19965970778713 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark07(1.9477023002879559,4.57670904007858,-0.9738511501439779,-93.39454083665751 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark07(1.9486597903476472,-7.29005665293572E-7,-97.57828885234404,0.017264282541810408 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark07(-1.9494318383310925E-6,-1.268145928844074E-6,-5.465951181803737,-83.62394593557437 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark07(-19.588702166962776,-39.17740433392555,0,0 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark07(1.9670536707245014,4.8418405597197065,44.02395314098653,-2.5651623054180517 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark07(-1.985403731519669,-2.4000112019809428,0.9927018657598345,34.613349071309415 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark07(1.9884910550897823,-4.684149314477029E-17,-0.7796015906766632,1.9081958235744878E-17 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark07(-2.0030973373581515,-4.00619430489797,0.21615050528162752,-15.275420764674745 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark07(-20.072206190313082,-40.14441238062616,0,0 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark07(20.32088325459327,42.14351269189855,115.79559532967122,96.81990995272336 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark07(-20.54461016567292,60.647869203838326,77.21587645507438,52.97458242478939 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark07(20.586746739177272,42.144607427539384,-0.5353477346174031,68.40133452308005 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark07(20.742671540180606,42.14336485537454,-8.437094179544552,74.61323912305099 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark07(2.0840678581193957,4.809775387502576,-2.609687477730933,0 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark07(2.085486519973075,4.817967819184434,13.17938127576409,-2.417016344410623 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark07(-2.087602001310617,-0.5235987750084483,-53.93444954295016,58.80712560846172 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark07(-2.1017690741325987,-2.6327418214703013,0.464663644847188,-100.0 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark07(-2.1066882256230189E-16,-4.2133764512460372E-16,-54.12470823347453,-48.66722126125161 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark07(21.175321031800912,42.35074773301953,-9.802262352503009,95.5582392147278 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark07(-21.222578984105915,-41.899927897631045,9.82589132865551,20.949963948815522 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark07(21.357473263087243,-1.4190156542889988E-15,-33.45376125069131,8.881784197001252E-16 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark07(-2.1602405658872645,-2.7509240145756384,0.29472211954618405,1.3754620072878192 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark07(-2.1663055408441476,-4.238542067122969,-15.541255594422335,6.331340160533642 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark07(-21.69558402537453,-42.83350327713818,0,0 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark07(21.73202920117736,43.50256831101392,-47.92894673998916,-21.75128415550696 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark07(21.952800321674435,44.82687414862642,-11.76160785968481,96.96700043570547 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark07(-2.220446049250313E-16,-4.930380657631324E-32,-13.350156779543816,-58.109302030648145 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark07(2.228653624776209,-8.673617379884035E-19,-90.93364258606904,-7.877936653365188 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark07(-2.2447667723380214,-0.5235987755982965,-80.60833540126237,0.26179938779914824 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark07(22.68184700286413,46.19466508262883,-99.1549332798218,0 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark07(-2.2793181362445514E-14,-3.7940313659432775E-14,-14.072808263223811,0 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark07(-2.2985824322261896,-4.5617297165789195,-23.660566856948932,93.38695808454514 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark07(-2.3397304418221357E-6,-4.258600600154395E-7,2.964324008039276E-6,-58.16769717766716 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark07(2.3426898712819386,5.799519013248357,-36.14091895873577,-2.8997595066241786 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark07(2.3576792404437636,-1.3322676295501878E-15,-110.84588792719431,137.45341215121624 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark07(-2.386948274508665,-4.593054673499083,65.43781638401691,2.2965273367495413 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark07(-2.4019649660437166,-0.09598642913688113,-35.83372064062881,-0.7374049488290078 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark07(2.40503751598669,4.810157409256163,9.558604230284445,-96.17669486873223 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark07(2.4507129685249174,4.92864537305816,-1.0787894092366332,-2.46432268652908 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark07(2.4808770042397725,4.961754008479548,-0.45504033872243793,0 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark07(2.5043413373454415,5.008682674690888,18.39806793060162,-83.819505148939 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark07(2.54000533842501,5.123646696723777,-0.5003641822360575,-2.562819938022533 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark07(2.551852154860965,5.169236845569765,-2.061324240827931,-33.937932598671246 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark07(-2.553393495969531,-0.5235987755982974,0.4912985844338191,88.49353106213727 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark07(-2.5596378745933683,-0.5235987755982947,-2.009363511485507,69.33940889871198 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark07(2.5760117678375782,5.314503571401104,65.77931781148598,-2.657251785700552 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark07(-2578.0684659316466,116.27562756356193,0,0 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark07(-25.85270691260007,-0.523598775598296,-65.61346288344707,100.0 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark07(2.5875800219363323,6.087002055556791,-2.067507072307092,-186.5412282552983 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark07(-25.94386831430266,-50.31694030181042,0,0 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark07(2.596755626504294,6.742685251232279,-1.3008975187389906,-99.97660612407482 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark07(2.6175687930777745,5.282428636599633,-1.2235142598277848,-2.6412143182998165 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark07(-2643.6451142293017,100.0,0,0 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark07(-2.6645352591003757E-15,-5.199694608763805E-15,-11.501651941664747,-90.32210371102596 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark07(-2.6671460234316844,-4.4109997383814274,-84.7072518129751,2.9908980325881775 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark07(-2.6946099972373085,-0.5235987755982983,-49.047865445049446,-20.2897346300754 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark07(2.8373797705445973,6.400169282777063,-75.73205774870763,-62.73384713106611 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark07(-2.857195283369269,-5.367410477380525,-7.985741371108801,6.610552966228587 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark07(-2.8838714685451246,-0.5230452042611677,-85.76046176369975,-100.0 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark07(-2.9214295197999185,-4.272184230399029,1.4607147598999592,-100.0 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark07(-2.9779072403485425,-0.5202394124907153,-202.12228897123077,196.92343949673256 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark07(29.918131891270605,-8.707282132986577,18.974425513350496,-41.112581314346095 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark07(-3.006484154061973E-5,-6.655880969376222E-8,-30.594220554504645,-0.7853981301180442 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark07(-30.150798387146097,-34.414770042289405,-58.245924055052775,-35.30892109676648 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark07(-3.019434568865248E-14,-1.6778398905614095E-15,1.509717284432624E-14,-61.55153713377278 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark07(3.0415753981467355,6.137933348792627,-71.39891105711307,-3.8543648377937623 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark07(3.056513988644166,-2.240959769144036,-67.49167853195445,-10.660492566389706 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark07(-3.1060007306534015E-9,-8.630292516114335E-10,0.2770349875385948,78.69188909690916 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark07(-3.142276980047375,-5.52646367219207,-82.83841420599323,-159.8011803238733 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark07(-31.468281318416462,-61.3808461119532,15.734578017899583,29.905024901273748 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark07(-31.675767226208066,79.73424555389735,16.88711167111863,0 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark07(-32.159928645050684,33.97689454075547,3.288796880010622,56.716974208774786 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark07(-32.68745760337981,-65.27127967505172,0,0 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark07(-32.83499056107854,40.143201770058,10.584250496145359,0 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark07(-32.92738423899051,-40.20165976659338,0,0 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark07(32.99274692946176,-15.534217019646434,-73.3438078496735,90.9086505026028 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark07(-33.00717590072882,-0.523598775598296,9.2889832848619,0 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark07(-33.015959282338706,-64.46112223788252,0,0 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark07(-3.3306690738754696E-16,-6.633327384384197E-16,-0.7853981633974482,-100.0 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark07(-3.3814833478406423,-5.195482985284899,-171.14642415295282,2.59772269828267 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark07(-3.3901383569212733,-4.309876746131047,-25.79388078804665,7.367215370124833 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark07(-34.182816188540244,-66.7948360502856,0,0 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark07(34.36462934825735,68.72925869651469,0,0 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark07(-3.4416913763379853E-15,-6.772360450213455E-15,-80.89600953797559,-0.785398163397445 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark07(34.96518815380489,69.93231058483384,-17.482594076902444,-37.320138538430946 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark07(3.5072583088702043,7.014525547025205,-92.43980159845754,-3.471301968692429 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark07(-3.5145342432246915E-5,-2.6550979924572675E-19,-0.7726194385695108,-100.0 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark07(-3.552713678800501E-15,-3.552713678800501E-15,-37.64447875623781,100.0 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark07(-35.74557516188355,44.74809193126609,7.016564150366975,0 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark07(-3.581972955651846E-8,-2.0311995852949928E-8,-99.99999976045461,73.43677800887738 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark07(-36.05953305001334,5.261709225947229,69.0301589931829,-2.6308546129736143 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark07(-36.11861222982808,-0.5235987755982983,17.27390795151659,0 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark07(3.7476723570503285,7.983862936281154,-100.0,-49.545024937367764 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark07(-3.7592129288927415E-15,-4.930380657631324E-32,-0.2848550213481854,-34.341340083676286 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark07(-3.791101365446746,-3.294443451605944,-6.747738326726093,46.38230112854258 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark07(3.8144709635354435,-0.5235987755982958,-0.6747923987163802,0.26179938779914735 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark07(3.817801012515006,3.065759686359437,-100.0,-0.7474816797822703 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark07(-3.9168134401823727,-6.732773639757946,2.6267926458158746,2.5809886564815203 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark07(3.9169136603088654E-4,7.833827320627984E-4,85.3756934994357,2081.5485140183478 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark07(-3.9212988149978893,-6.277019906494953,1.1752512441014964,4.709306280042373 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark07(3.921742750007617,-0.010024794784045683,76.58755176301754,-0.8555037408840676 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark07(3.941320788692535,7.882641577385072,-2.0256486055301552,-3.1559226252950863 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark07(-3.9562930047358824,-6.341798065302968,1.5566127003862966,1.1001027093290645 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark07(39.93574175365691,-73.88453001554625,0,0 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark07(4.037435230839728,8.603595361103869,-48.30722156270089,-49.854708631869116 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark07(-41.74381150945949,-0.7878424422765704,-72.49739795879073,54.57646650635627 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark07(41.7812420061138,84.80977483165972,-20.8906210030569,0 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark07(-4.243076830199537,-8.396010937521694,-10.510943533860807,-6.797567333203754 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark07(42.44953686534249,84.89960374938826,-20.439370269273795,19.304456950322823 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark07(4.264712340372739,-91.43785669898223,44.587446935351664,-37.33565782933339 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark07(-4.280307246915315,-6.990057719829844,1.3547554600602094,14.45289669915994 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark07(4.31704446643725,8.705382319214321,-36.32327977566432,-96.58524665062843 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark07(4.3194712096247825,8.638943850884472,-2.1597356048123917,-1.007844542778502 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark07(-4.341922185832884,-7.282462438422675,2.170961092916442,10.702576990369694 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark07(4.352378521744226,-1.7763568394002505E-15,-0.9615832235992647,0.0 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark07(-4.353422727266029,-7.625608714578604,2.9621095270304627,3.812804357289302 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark07(4.361578336262982,10.023104938507553,-1.5190268920797099,-48.21331838963596 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark07(43.64987085318223,-2.6444955037851506E-15,-14.610326038156067,-12.524883328974056 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark07(-44.187425779107414,-62.60982494206826,-28.41754839769912,53.79599603149791 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark07(-4.440892098500626E-16,-8.879198169966179E-16,0.0020443499537069476,-69.1748017984309 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark07(-4.525332313451578E-5,-2.557772868092868E-13,-0.785375536735881,20.877194853805364 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark07(-4.536062607290965,-0.5235987755982988,-31.60880208571004,1.4285474915918215 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark07(4.540321742837292,4.015123704165636,-23.228674764670828,-16.129598703124515 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark07(4.566647411817721,-7.96692345030855E-12,-7.7811108496728565,184.71136356274795 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark07(-45.74645055144626,-12.049734948154082,-71.19161469542819,-19.74527158562171 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark07(45.91302738968767,32.91288257134366,-6.226289126839475,-15.703139482814677 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark07(-4.596001107579832E-5,-1.4565693757465775E-13,6.112315682953578E-4,100.0 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark07(-4.658439925142337,-7.746109445942367,-23.621216687501928,1.525264675540375 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark07(-46.813502296624186,-92.05620826645348,0,0 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark07(-47.53282217753705,-93.49484802827921,0,0 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark07(-4.801748355970766,-8.03270038594644,1.6154760145879348,49.43331759530763 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark07(-4.860274020169731,-8.634127835384614,-31.807930735403605,-23.17286964748173 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark07(48.767748180731154,-2.7755575615628914E-17,-31.598475927144932,0 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark07(-48.86050394413866,-97.66751628004191,0,0 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark07(-4.907525753201678,-0.5235987755982979,5.668487035321192,0 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark07(-4.9253934264470445E-12,-9.850498732821298E-12,-0.7853981633949855,52.39340632293937 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark07(49.35781328627672,74.3599433503218,0,0 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark07(-49.92071839179457,23.08234034325463,38.45654804723509,-91.47371884255301 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark07(4.992303756658886,10.35917455506521,-78.50490044416279,173.1057959033463 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark07(-5.004173227735525,-9.634232809650822,-22.283360286104024,18.95427332295569 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark07(-5.029485018644942,-2.6224315437929935,-131.9424260530546,-85.0860660401051 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark07(50.80462241220775,56.53079673178877,-66.53417680816392,15.535364509056564 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark07(51.098327940620294,-84.74793960547187,94.74249592572625,32.25976696615521 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark07(-5.112486568027103E-15,-1.0224973136054205E-14,-6.226533912923953,-100.0 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark07(51.18923471456657,-36.62902866885667,-65.56873453979735,0 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark07(5.247969678216575,4.13489636380352,-100.0,-61.75240976882481 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark07(-5.27312593590068E-9,-1.0546250649520558E-8,23.25009234433329,67.52146195023121 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark07(5.2905463249189575,10.90586542800975,-34.82351556408898,-61.85033480377643 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark07(53.188735352832,-41.17389948785384,10.37307729190755,30.54833147788699 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark07(5.547879820287684,12.549936056164787,-2.7739236739940956,14.993286695980155 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark07(5.576395713030508,11.152791426061018,-2.54870310281595,-4.790997549633059 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark07(5.623187195978408,11.583339408525246,-2.4357515738618885,-34.06591463236593 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark07(-56.57517933359622,-49.3194469941878,61.787884037073354,-4.275174122479868 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark07(-5.774563343184983,-7.0513094145935495,-100.0,96.7024763802572 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark07(-57.896636258349,-64.92433434994535,49.45794189933798,-87.08922730894938 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark07(-5.802908889542662,-0.5169780948736128,-19.167587516776837,100.0 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark07(-5.854130450077724,-0.5235987755982987,-90.24991806354649,22.51515654732244 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark07(-5.876311384310218E-4,-0.001175262276861987,0.3131380713201373,-35.32519546989816 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark07(5.908351554880614,11.824584611081441,-3.7497491176802553,-65.40105564481219 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark07(59.412259835281475,-45.136347720466304,9.176122164396403,-48.16241686780831 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark07(5.963731827058301,13.479887494128754,-197.91206415793437,-5.954545583666916 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark07(5.9666017596635275,11.933203519327058,0,0 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark07(-5.969161441165734,-11.816034692545985,1.7102072331671012,20.043941949715634 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark07(5.990624919311244,89.15235654446468,-51.366885329401434,28.414470579195523 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark07(-5.993946099630547,-11.413334979632067,-100.0,-77.54553780111748 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark07(-60.333516045101796,99.25408398640778,-41.23919501336495,38.17320946483986 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark07(-6.0418684437749866,-12.083701669460584,-39.52449654552493,6.825934058577997 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark07(-60.738110820156564,-40.964740301953405,51.04294212245418,85.9230917946164 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark07(6.19323398401188,12.930763640728209,-100.0,-5.6799836569666535 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark07(62.041686893933075,2.9196180398062097,58.95597471703894,-28.067419878845072 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark07(6.246140001020864,14.019639843352202,-100.0,-58.84609545511257 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark07(-62.63361536894572,-51.32764186266363,59.92071900839727,-60.49060647690627 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark07(-6.317684153600567E-10,-1.2505726577415006E-9,-100.0,-62.65085809575756 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark07(-6.3521102869486015,-80.5521849970785,28.078603073435204,-13.63624934923709 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark07(-64.28968247978645,56.62105843719297,0,0 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark07(-6.435899594943668,-11.360458193341476,-100.0,-78.37250665987239 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark07(-65.08245393636902,-28.91746942092901,-59.26998906035115,59.57004697705389 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark07(6.5440768457622465,14.632029182612264,-97.17713197856943,94.00623097624823 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark07(65.69415811557182,-4.4929710316459376E-4,-25.62771493556735,2.43670819607366E-4 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark07(-6.572520305780378E-14,-4.922375449628095E-14,-0.7853981633974154,-89.53550460481222 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark07(-6.703010403069932,-13.406020806139859,-100.0,6.703010403069929 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark07(-67.0439432635116,4.321802927386713,-26.88752072473119,-26.583309880869493 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark07(-6.7920520532638875,4.827196776731685,100.0,0 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark07(6.888364229847596,14.675103916547217,-62.378376959662475,-12.547893323501635 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark07(6.900624844169319,13.930619838987079,-3.4503124220846595,37.80240016909092 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark07(6.91279910080339,-0.14056331548352075,40.59168744854233,-0.053193648108912805 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark07(-69.31160470074565,17.146100469748205,5.014824271654007,91.75205593553898 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark07(-70.04515235006845,62.272510893900886,-48.114085036969236,-65.7437967010533 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark07(7.0296394215529,14.059278843105801,0,0 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark07(7.113624243531831,-16.02606470767188,-35.1931150622476,87.25156799375279 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark07(-7.153202719045737E-8,-1.4306405435272548E-7,-13.311070337550854,24.045419093358458 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark07(71.8675418942459,64.42843244160034,59.53517947425098,0 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark07(7.235470203771928,14.471406247362166,-4.403133265283412,-9.836133781601204 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark07(-7.316685682702804,-13.085661376087812,-2.264014291216102,-56.60073753684814 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark07(73.31892055195422,62.29591791463562,69.38424213323196,-64.08900044747487 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark07(-7.39796340028675,-13.267447511046594,-11.51969893102347,-38.133971561910265 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark07(-7.489137205347291,-92.41920732874507,94.78951724222244,98.11685169932736 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark07(-74.93208800777339,-71.132057449462,83.26362372028382,0 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark07(-75.65238725513701,-81.57162245603742,73.61947347103032,-24.114279131231115 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark07(-76.61126096626634,-6.323331463643058,-40.19047469351651,-16.956824409323417 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark07(-7.760172408908311E-13,-1.552034481781662E-12,-61.64507369421482,0.7853981633974499 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark07(7.774126072902183,16.84187761946219,-100.0,-26.48418868150828 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark07(78.06550872810485,-56.02720637832959,0,0 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark07(-7.813190808397781,-0.008510683437634212,2.271692878397821,37.70462519307594 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark07(79.42325961796831,43.388963358455385,-27.867260619023938,-54.38522024301131 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark07(7.986354464264516,16.040878858418136,-3.858136916071475,-266.4929076457507 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark07(-8.093181238128252E-14,-3.1554436208840472E-30,4.046590619064126E-14,-22.48694087226963 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark07(81.20163534622839,70.76259068793956,-63.02013416388086,90.26130801752996 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark07(-81.59673371385954,-46.62162534575614,-51.030833712360234,82.93865481504065 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark07(-8.19437135032075E-4,-0.0016388742700627404,-7.70300068115335,0.7862176005324797 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark07(8.266697930112702,16.662125981573993,-4.092088997888439,-92.373604519821 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark07(-8.308021085499133E-4,-4.3368086899420177E-19,-0.7849827623431733,-0.7853149960172632 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark07(-83.48845057070515,58.15430368248755,-41.0694157930382,0 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark07(85.07786831269746,-73.81220625399942,-38.34013686949511,51.24264976806495 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark07(-8.822598109810716,-16.618432531620503,3.6259008915079103,6.2384419792922605 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark07(-8.835598919176846E-12,-1.767008473666123E-11,-69.90819499954529,40.95084877910229 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark07(-8.858908107575958,-16.147023053557266,4.747751475203496,0.21953095471941136 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark07(8.85922698410009,17.737015498868658,-4.429613492050045,1.0562575395072917 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark07(-8.906160338196562E-7,-3.197807462690872E-7,-19.00306016922319,65.21661621171789 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark07(-8.921387394399172,-16.54967513152661,-85.58217740312132,9.060235729160754 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark07(-9.064765856065158,-17.19157839767043,-98.4123017700095,63.574579866584614 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark07(9.180893005456031,18.39209676364891,-5.375844666125464,-54.468353680997694 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark07(92.13584685915842,47.664693269029016,-2.5559391082746714,7.181453334799443 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark07(-9.227538882164358E-15,-2.5243548967072246E-29,-62.15128201002764,1.2621774483536124E-29 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark07(9.257438626944458,20.069793764229235,-5.414117476869677,0.1687471210129221 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark07(-9.324236222355724,-0.5235987755982965,-56.599756068047384,-100.0 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark07(-9.387705434473073,-18.74095840659404,34.56371071817687,9.37047920329702 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark07(9.490209745446919,85.31299751269796,0,0 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark07(-96.13494266665559,41.16279800252477,7.695923960031962,-62.61394624280363 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark07(-9.664812045787018,-17.81223019447323,4.903254830529621,8.906115097236615 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark07(-9.706643486995489,-1.4801487156423823,-135.75951408029871,83.1815797923948 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark07(9.709430676578435,27.86231483198624,0,0 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark07(-97.71445901919036,-3.1068392348129805,0,0 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark07(-9.785891834764314,-19.571783669528624,4.892945917382157,9.785891834764312 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark07(-9.913320334931086E-4,-0.0019826640669830574,0.004803430293404326,0 ) ;
  }
}
