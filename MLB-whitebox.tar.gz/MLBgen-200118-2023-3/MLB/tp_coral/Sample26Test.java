import org.junit.Test;

public class Sample26Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark26(0.0010447745152020425,-1.7371015559280636,-54.96782478319831,-34.38817503216896,1715.9025258162753 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark26(-0.001565098595309608,3.385417649477702,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark26(0.0015706455182462116,-80.53626400901875,-12.772972406131245,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark26(0.003366114240065596,-10.049168704170198,-6.162484851632627,-92.06203600278059,20.097169232927275 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark26(0.003979318509801543,-86.58904420441017,-394.73452158353655,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark26(-0.004427242968650008,45.09073098484332,0,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark26(0.005582154472404316,-100.0,-1761.423238710464,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark26(-0.006057423821429462,0.4884849914146774,100.0,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark26(-0.006435254374157515,30.21170669800058,244.089558987425,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark26(-0.006726076314208192,57.55099244921411,25.44640624375992,-85.94648761875733,-39.396306712311144 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark26(-0.007601422785831789,51.13697322950489,59.79279050721914,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark26(-0.007997467313448331,69.5957648295614,10.47402898750218,-42.46665325415745,77.5431181010074 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark26(0.008844044436042173,-9.515845348777077,-18.680292557737474,-160.9586870935325,29.860651409711462 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark26(-0.01164814809001058,40.99560520500887,98.2668255036934,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark26(0.015707963267948963,-20.644614546017753,-100.0,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark26(-0.016942419611770676,6.49375146984856,7.207942438996508,-61.23234090070612,-6.434470666148002 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark26(0.017343630823080342,-14.401569873248302,-1.475513386161619,-100.0,30.571959089865317 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark26(-0.018389873269331503,7.815970093361102E-14,0,0,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark26(-0.021039117802101794,1.4210854715202004E-14,74.66075058707904,0,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark26(-0.021707327663107963,-47.905999047317586,23.909111266241972,-23.952998718521275,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark26(0.0248180770233561,17.59744575554457,-0.04364704786413863,-28.087743081424335,-33.62409518429424 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark26(-0.02561411654840673,22.279364384531714,0,0,0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark26(0.026328510263776694,-10.132406985457747,-17.366903380023285,-95.62343031032466,0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark26(-0.02853177133634769,3.9565160407107207,18.910879530518883,-37.70430553797914,87.93084997229417 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark26(-0.028883622149438244,18.6342658020928,17.191937999342258,-30.407318166162696,58.16131128622585 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark26(-0.0316082423462917,2.5437834206791425,37.96990096664007,0,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark26(-0.034408993909351863,1.8882514313179684,0.21242534719405537,-35.19176904331646,78.56340759754266 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark26(-0.03814317104305035,14.22511715634404,0.014483294859191843,-38.698446966395146,-86.14360518341091 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark26(-0.05213275714029006,30.130697338102777,0,0,0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark26(-0.06006480425741323,1.7763568394002505E-15,1.1478618542276635,-53.996764039768365,0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark26(0.07651953463689976,-3.872457909892546E-13,45.07293349799758,0,0 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark26(0.078016706291689,-7.158181313889983,-6.583898724951993,0,0 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark26(0.07911995995334978,-5.409936426034385,0,0,0 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark26(-0.08606823693620508,3.2943459645134774,0.01811164382561796,0,0 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark26(0.08951915337577218,85.06488691293468,-0.7355188367223147,-3.7164508193875463,49.955656733076225 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark26(0.09612070756590184,68.50648231094085,-0.0027364326621950874,-36.99834172337872,89.19723509290897 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark26(-0.11491910538262842,4.954274670231943,0,0,0 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark26(0.12580073427836247,-12.486384406303669,0,0,0 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark26(0.15403259915148781,21.52786959710105,-0.3241938970234568,10.763934798550522,100.0 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark26(0.16625993442514161,-2.7997286664668892,-4.440892098500626E-16,-100.0,0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark26(0.22120663825439058,-2.8413921423052604E-14,-6.666083478782074E-146,0,0 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark26(0.2466435877536657,28.16813752280227,-0.034797347187282265,-82.06453753201194,-35.92321935927182 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark26(0.26255031509322996,11.425912043991772,-0.20665780062852307,0.6446067267673424,14.945846560577067 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark26(0.27717008634785445,-2.059371944236168,0,0,0 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark26(-0.28819622881989915,0.0,0,0,0 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark26(0.4524045723618002,-0.11138445931150175,0.029812568180821505,0,0 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark26(-1.1102230246251565E-16,22.68988298012418,0,0,0 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark26(1.1102230246251565E-16,-82.97853943148922,-84.91179650217939,0,0 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark26(-1.1104042642684533,1.0658141036401503E-14,0.5309482432430854,-39.94358498114157,96.10171106439338 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark26(1202.7084987502915,-1461.1528634509018,0,0,0 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark26(-1.231893470660496E-16,-15.441900173067701,100.0,-88.30391578771867,99.99883872511086 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark26(1.2364755064881763,-4.440892098500626E-14,-31.43248248756825,0,0 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark26(1.364169350975877E-4,81.17662390007555,-1.9613834727292263,-8.233390775628958,0 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark26(-1.4084040281302145E-16,57.43810555415091,29.13201474752117,0,0 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark26(-1.4210854715202004E-14,39.351552010243374,68.85104819736404,-1.1558189533495202,23.38280204897778 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark26(1.4329211994021946E-11,-0.05780654523792772,0,0,0 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark26(14.403243325517082,-3.597122599785507E-14,-0.016672622553929983,-0.7853981633974598,61.7225645597922 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark26(-1.4588015461977138E-15,-18.670533074260952,35.072353679348325,-77.40350140304919,38.765616004753795 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark26(1.474514954580286E-16,-39.85168636158635,-100.0,-27.784051351830538,0 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark26(-1496.1064988930718,1227.3140267855447,0,0,0 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark26(-1.552546025143024E-17,-80.55778350456023,35.64633017415057,-41.06428991567756,0 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark26(-1.618497003086361E-15,2.658732038083957,26.261554772372747,1.329366019041978,172.9711235094722 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark26(1.6456570010240767,-0.06177442202037753,-4.163336342344337E-17,-90.07903514684767,100.0 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark26(-17.01837998753564,4.982237440589614,87.17399253040315,61.425176535449765,41.11548529200806 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark26(1.7072557559473864,-3.9378856442629797E-4,-1.4210854715202004E-14,0,0 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark26(-1.7763568394002505E-14,90.34154861914713,30.86671766407369,0,0 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark26(1.7763568394002505E-15,-63.432353377552175,-12.80215544053074,0,0 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark26(-1.8969310412121957E-17,-19.991381278641875,4.416079468808577,-10.781088802718386,0 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark26(-19.230590381582456,1.2079226507921703E-13,0,0,0 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark26(-19.312169303833727,0.08133712490202072,0,0,0 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark26(1.9531980270642372E-16,-31.185772020014262,0.0,0,0 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark26(-1.958198376817877E-14,0.025805431961831715,0,0,0 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark26(-20.23429344658172,0.02820933941317048,0,0,0 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark26(2.1308176361698514,-1.2789769243681803E-13,0,0,0 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark26(2.1316282072803006E-14,-54.60864903544132,-35.48288694162473,-92.60584044197293,0 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark26(2.220446049250313E-16,-36.38594289091073,-3.4559213870807532,-61.54500561204237,0 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark26(-2.2847274480083,4.5102810375396984E-17,0.2658841364143414,0,0 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark26(-23.241342274633055,4.440892098500626E-16,0.003904063506039758,-0.060000680724373145,-49.383753273023956 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark26(-2.3803181647963356E-13,27.575870413700713,0,0,0 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark26(2.6020852139652106E-17,39.01135393419992,-2.6195437501746928,-48.75630090908304,48.46365635296975 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark26(2.7198630515230224E-4,-1.6402936596977327,21.367788537623525,-93.50273066230164,-3.533958986361404 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark26(-2.7755575615628914E-17,19.65733174178716,100.0,-39.40077338273673,-84.66707330662908 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark26(-2.8057547555666815,32.28304497562954,0,0,0 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark26(2.8421709430404007E-14,-14.59613025631377,-4.142950446811893,-31.21689118728864,0 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark26(-2.843506393069281,-44.50608767683359,9.739966228452896E-6,-22.253043610027436,0 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark26(28.698371927004928,-23.614389719089644,0,0,0 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark26(-2.877698079828406E-13,2.1415407127762336,0,0,0 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark26(-2.8983633974721465E-5,23.91094101420451,51.03860212816909,-93.695886449646,-16.04522168129347 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark26(-2.90703743065092E-4,27.905501143002496,77.98343406297653,13.38286667999192,0 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark26(-31.206277606708127,-8.871762812211827,89.83808348351656,81.27668628848858,0 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark26(-3.2623855888902487E-4,39.865485966630246,95.80186823865156,-38.803043193834014,66.67272041140767 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark26(-3.398640341813882E-4,38.39178337475267,-67.87887731437024,19.195891687376335,0 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark26(-35.49912198685128,0.003350406744576168,0.010838047339098426,-11.75869809780718,0 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark26(3.552713678800501E-15,-0.01977318548515683,-5.454757127462965,-57.98762431209039,0 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark26(-3.552713678800501E-15,32.09154333995454,47.706746697153676,-2344.7039688545947,0 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark26(-3.552713678800501E-15,55.65123929656319,15.082125745214213,-2097.915539101123,0 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark26(-3.586206248826762E-4,89.65924875687092,20.921697279003794,-76.57362376495877,68.6583570395812 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark26(3.599967236295996E-18,-21.321288401454055,-18.160498455296164,-38.44686361082834,0 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark26(38.570627547598306,-3.907985046680551E-14,-54.46145915598064,0,0 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark26(3.885780586188048E-16,-20.207508628590972,0,0,0 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark26(-3.922699188403425E-16,68.67996672264363,35.29411856752591,-86.93028337253247,27.309251034602894 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark26(4.08177289287526E-14,-9.543964896869289,0,0,0 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark26(-4.2296563486743377E-4,30.19363405593905,44.91226120957205,-8.886024191730739,0 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark26(42.37249115929393,-40.16066007422749,0,0,0 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark26(4.291678123991005E-12,-16.669672909677587,-99.4558849303387,-54.5782851827298,1916.5276154464 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark26(4.418425574398134E-16,-12.702143260266752,-2.220446049250313E-16,0,0 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark26(-44.317295711513815,57.52798724850328,0,0,0 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark26(4.440892098500626E-16,-2.2446962853282457,-73.1583400017628,-66.24454856251087,95.1939537186573 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark26(4.440892098500626E-16,-97.1664301013241,-3.552713678800501E-15,0,0 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark26(46.13114545781636,24.203278801214708,-49.684340220698544,0,0 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark26(46.65934533281609,-4.440892098500626E-16,-5.576424090448697,0,0 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark26(47.27297065034896,-0.004233027571167725,-0.0018267918044383574,-0.2305937027785223,69.96730968534062 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark26(-47.31788346711872,-46.69920046247924,0,0,0 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark26(-4.844692633841418E-14,1.2250509245966157,0,0,0 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark26(-48.73242394615093,1.1102230246251565E-16,4.440892098500626E-16,-49.417848407006616,-3.256448500474889 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark26(-49.262497685813244,1.9791105564918654E-4,0.010853168114251046,-55.67159934318448,0 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark26(4.9432680171435095E-14,26.293897576915548,-100.0,13.033864475723249,-52.587795153831095 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark26(50.682817547650984,-0.08766642593838014,0,0,0 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark26(-51.15702954711101,33.18095157253725,0,0,0 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark26(-5.184400827302045E-10,100.0,99.74740133835373,0,0 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark26(5.204170427930421E-17,-22.96873061576571,-23.09017540386202,-85.35103133019555,86.59081087437565 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark26(-53.011557449311766,-73.56753710075992,53.90014731938447,-11.332166543229036,62.9804706755304 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark26(-5.59399398688099,7.596410708229231E-15,5.551115123125783E-17,-71.17867809650542,-92.49022583546004 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark26(-57.25864061072481,8.881784197001252E-15,0.027433349971998443,0,0 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark26(-6.086851539484913E-16,15.846475742298692,8.931620926992373,46.33452803531014,0 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark26(-67.92588423871669,-22.80010304257742,0,0,0 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark26(-679.7616054019827,7.105427357601002E-15,1447.7302462523724,0,0 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark26(-7.105427357601002E-15,0.10733257534324553,100.0,0,0 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark26(7.105427357601002E-15,-20.606085413233743,-84.58280711914013,0,0 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark26(-7.108208202765738E-12,-14.746340728337843,22.53666104075595,-8.143067411021178,46.9893923923121 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark26(71.28541825197826,-63.97203794615973,0,0,0 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark26(75.3987437015021,-15.021656997205994,2.6676440840032427,0,0 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark26(-76.9815084730765,61.53240745461969,-55.76066316132176,-86.64505415809353,0 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark26(79.4456782491323,-94.44214866293572,0,0,0 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark26(-8.071751231484195E-17,0.7586004350397787,2.3071826823744732E-210,0,0 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark26(80.92901419142717,-76.0109043832186,-96.23662657032253,0,0 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark26(-80.97458949885016,-11.753984756598413,-82.1061644068806,-57.821541274433976,98.19487499764386 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark26(83.04853522748857,-94.12525073263112,0,0,0 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark26(-87.71998202452758,-82.0716433764368,-96.45718358797966,39.603835730846924,-65.72151887547876 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark26(-8.881784197001252E-16,23.607196281029346,56.57743969594719,11.803598140514671,0 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark26(8.881784197001252E-16,-42.106347606944716,-83.3651268405863,-255.17820094411053,84.21270689252442 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark26(-8.881784197001252E-16,50.59734911762342,-1.7763568394002505E-15,0,0 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark26(8.962752231440445E-14,98.64723610908797,-72.41340934493448,-128.92632747475812,29.923569456717985 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark26(91.11379114734405,-40.854940198782415,20.26469087994714,9.182301874093255,-9.612088194739954 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark26(-93.03545643822618,47.863741009128375,0,0,0 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark26(-95.8206200800507,-79.29101186350334,3.671070405701599,-30.23143838663991,-59.4059635109532 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark26(97.0743173867902,-24.084935176237735,14.3116693593647,0,0 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark26(98.68223157234067,-4.440892098500626E-16,-51.766753536705856,0,0 ) ;
  }
}
