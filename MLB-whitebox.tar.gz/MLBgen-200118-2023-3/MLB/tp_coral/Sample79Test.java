import org.junit.Test;

public class Sample79Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark79(0,-0.32073783610719886,55.05883342867719,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark79(0,-100.0,100.0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark79(0,-111.21106119582605,68.7889388110135,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark79(0,-111.95365999056412,99.10968993817238,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark79(0,-123.38029461847475,70.53600827271447,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark79(0,-1255.340404472603,1403.555827693803,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark79(0,12.730299965820294,97.09311215834208,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark79(0,-133.71386696083061,46.28657017346427,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark79(0,-139.27151657816677,98.02426293261247,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark79(0,-140.32002613489544,40.91722947788145,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark79(0,-1408.5900232638503,1310.0084615721976,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark79(0,-147.60026866203387,74.73420800217897,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark79(0,-15.681421375492292,73.19841331542102,0,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark79(0,-15.803949048294154,74.19605095170584,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark79(0,-16.69079410804815,73.30920589195185,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark79(0,-167.29196206941472,12.708075990326645,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark79(0,-168.24023154702365,57.77244928614533,0,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark79(0,-168.35871926070473,21.618860626213717,0,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark79(0,-175.65473946826089,43.09617514023151,0,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark79(0,-192.1858658285255,11.505238586922431,0,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark79(0,-19.782631696912738,70.21736830308726,0,0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark79(0,-200.1570957688828,22.61797928348432,0,0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark79(0,2.21596355969847,92.21596355969847,0,0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark79(0,-26.305945180017872,63.694054819982114,0,0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark79(0,26.479674256313857,26.47967425631386,0,0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark79(0,27.742911502471813,55.50955177255679,0,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark79(0,-28.733223344631867,176.4132482687674,0,0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark79(0,29.72454297008099,29.724542970080986,0,0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark79(0,29.953892861598547,-20.034437568240463,0,0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark79(0.3011629844108273,-92.06308145320058,87.95370758651089,24.097047346752603,0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark79(0,-31.41278004485079,-88.26185814715879,0,0 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark79(0,-31.519574679457165,12.830949356155344,0,0 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark79(0,-32.99109230168585,57.00890769831413,0,0 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark79(0,33.5981626305806,33.59816263058061,0,0 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark79(0,-34.46764461050617,79.3582419322693,0,0 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark79(0,34.66441130088464,34.664411300884666,0,0 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark79(0,35.58823045639113,64.04211818835935,0,0 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark79(0,-35.63553914514175,45.09732304246663,0,0 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark79(0,-35.92063139375386,144.07938226918586,0,0 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark79(0,-37.544268172752695,52.455731827247305,0,0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark79(0,-37.92779088052338,34.74045575609196,0,0 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark79(0,-40.647954882652584,38.08540388260414,0,0 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark79(0,-41.195005597233724,11.08630104727635,0,0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark79(0,-4.1613499121804685,85.83865008781953,0,0 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark79(0,42.782742601184566,87.25345714671556,0,0 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark79(0,-44.62035072028914,-26.918461813951236,0,0 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark79(0,44.82701082141779,48.38512064933519,0,0 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark79(0,-45.93387231474417,140.03220625738663,0,0 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark79(-0.4754882558840876,73.98209686874058,73.9820968687406,63.747499287785075,0 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark79(0,52.22045904683242,74.5628854461446,0,0 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark79(0,-57.251275238036236,79.70700461572025,0,0 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark79(0,-57.57529023873032,32.42470976126968,0,0 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark79(0,-58.078328874444594,-23.67781349299709,0,0 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark79(0,-5.93255945202317,174.09488770330128,0,0 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark79(0,-60.0891949052317,-51.423364167470375,0,0 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark79(0,-67.38498568007789,91.91421645691057,0,0 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark79(0,-67.7302354103478,151.30095316288245,0,0 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark79(0,-68.38156860088787,-55.3666197619666,0,0 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark79(0,69.76476793898448,69.76476793898449,0,0 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark79(0,-71.53013471362524,18.469865286374763,0,0 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark79(0,-71.6235111264856,86.45379113385772,0,0 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark79(0,-72.19102688097976,115.87195282179269,0,0 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark79(0,-72.76530811210489,-54.27404039342814,0,0 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark79(0,7.333454263302185,7.333454263302187,0,0 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark79(0,-74.18574260857112,15.814257391428882,0,0 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark79(0,-75.18685404238522,14.813145957614779,0,0 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark79(0,-76.25581365001571,13.74418634998429,0,0 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark79(0,-77.5295945247097,-53.45944545899173,0,0 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark79(0,-80.10968329874056,-47.40546281182291,0,0 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark79(0,-80.41749390090837,9.582506099091649,0,0 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark79(0,-80.47805030354701,-61.0545663952696,0,0 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark79(0,-81.26292423909632,98.7370757609038,0,0 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark79(0,-82.95506316639577,7.0449368336042095,0,0 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark79(0,-83.49126980542036,6.508730194579627,0,0 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark79(0,-85.20067370261086,121.42549260469892,0,0 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark79(0,-85.98088485694957,4.0191151430504215,0,0 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark79(0,-87.37706223957645,28.14780140997857,0,0 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark79(0,89.42218211614014,89.42218211614015,0,0 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark79(0,-89.49330134210592,0.5066986578940837,0,0 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark79(0,-92.39519818114834,89.04076912840804,0,0 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark79(0,-9.366485769646808,80.63351423035319,0,0 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark79(0,-95.11666962914532,91.63335752520489,0,0 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark79(0,-97.24440359054273,-86.63073138758033,0,0 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark79(0,-97.80612297520244,-7.806122975202461,0,0 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark79(0,-97.9678661870062,82.03213466676756,0,0 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark79(0,-99.41190553205548,137.88387396356518,0,0 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark79(0,99.75653408481219,-60.99339541125703,0,0 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark79(100.0,-60.52333495126351,-36.93737512610855,0,0 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark79(100.0,-87.66461859229905,92.58916173520326,0,0 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark79(12.156778679137688,-24.899766330546697,-6.950859922357353,-64.69769790041724,0 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark79(-1.2581891372431013E-23,-68.62514569750134,-36.264699677086234,0,0 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark79(-1.2912294491974646E-29,-63.27357790881409,26.72642209118591,-2.8586667800319248,0 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark79(-13.019825527609136,-12.051820858976122,77.94817914102387,0,0 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark79(1.3124171152263631E-5,-99.9454989194749,80.06005874697901,-92.34249333786354,0 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark79(-15.599796024952823,-61.21989473507272,-58.63918221408058,0,0 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark79(-1.6105384476670345E-27,-34.53883880877795,55.46116119122203,0,0 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark79(1.635964332607793E-9,-104.95307214957953,75.18691994256457,0,0 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark79(-1.7402281871226704E-6,-55.05448447375534,34.691239171975155,0,0 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark79(17.82200927300859,-33.21489371179918,35.39221365371026,0,0 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark79(2.5024107204549607E-9,-75.60039787835856,-52.538103867420375,-25.68804335399738,0 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark79(2.7095345569717234E-6,-55.288008954817734,126.00081667698066,0,0 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark79(2.798981971713559E-26,1.9134639479912634,1.9134639479912643,86.75244576249553,0 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark79(3.162707514292155E-31,-79.71823939953408,10.281760600465908,0,0 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark79(-3.19983173121326E-9,9.545323683591505,38.60461292470019,0,0 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark79(-3.2264784525271457E-9,10.884172310028529,78.55905406118788,12.606508633481791,0 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark79(-33.33845494164369,-94.88885396510437,105.79751432994787,-48.05308784136548,0 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark79(-3.46027601172281E-27,-52.28625123670587,-52.286251236705866,-89.55447868767702,0 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark79(3.6819693428497567E-33,-2.6010552504602416,87.39894474953977,0,0 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark79(-3.790090854601717E-31,-75.02241857486213,14.97758142513787,118.55574538208549,0 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark79(-38.96517063565197,40.51655526469159,51.47669295993862,-95.60602340257438,0 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark79(4.491501187276458E-35,3.3788236013892883,93.37882360138929,0,0 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark79(4.492648638014094E-9,-100.0,80.29003304040717,0,0 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark79(46.63069998364696,40.861875549154206,55.38621416251553,13.062702898728261,0 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark79(4.811758322396614,-132.3971902930279,64.96343271002883,-24.373328554431282,0 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark79(50.92819145045916,-53.818499127501696,36.1815008724983,-31.90882245140734,0 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark79(-52.359323237674516,-77.07746731317616,-47.337274822313354,0,0 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark79(52.502082403662286,-84.52890005217628,5.471099947823717,0,0 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark79(52.63780211553723,-100.0,80.30341236191512,0,0 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark79(5.570926317069944E-9,-55.26013531616011,34.7398646838399,100.0,0 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark79(5.695078161254818E-31,7.731940890498052,97.73194089049804,0,0 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark79(-56.981643769487775,-46.23534269630487,-37.44479579582749,0,0 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark79(61.689138648422954,-51.52163574736952,38.478364252630485,0,0 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark79(-6.178939963358856E-28,-14.364082722091744,-14.364082722091739,0,0 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark79(6.359383131105212E-28,-80.23376992176705,100.0,0,0 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark79(6.406652881236608E-9,-5.000799456901516,84.99920054309848,-64.67255544625054,0 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark79(65.3876358087264,-91.46454171071858,-89.86602922687487,95.76324271595823,0 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark79(6.541794018734653E-26,-20.58967670471633,69.41032329528367,-55.71288699621993,0 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark79(-6.548313500608505E-8,-95.88065860239834,92.27685383370233,-100.0,0 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark79(66.78070938460777,49.93536283150405,70.57305328862995,0,0 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark79(67.32305039527432,-167.66730970559794,13.48450754420611,0,0 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark79(68.39680801140537,8.956542600078635,16.565507812551132,22.649150236828916,0 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark79(-6.914112524685191E-6,1.1621780347770452,181.17675909893308,-1.9204190455130714,0 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark79(-69.50596652517362,-59.97698057031842,30.02301942968158,0,0 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark79(7.098345241210396,-23.79376888196545,-23.793768881965377,-52.66916823120946,0 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark79(-7.112943903661239E-5,-4.769854935884894,85.2301450641151,-100.0,0 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark79(7.323145736059842E-16,-93.17926872790918,86.8211684125632,-76.62633793662874,0 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark79(-7.372029050009911E-28,38.48653260489146,38.486532604891465,-38.515829893220314,0 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark79(7.390365677126771,-91.87530192646337,-1.875301926463377,38.815540570195026,0 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark79(7.503362702241451E-29,-100.0,81.28529488133394,0,0 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark79(7.651418309935351E-20,-89.45082274474635,90.57341176753195,100.0,0 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark79(-7.878264416360113E-26,-39.75367893984151,-38.23817675851662,-7.5369233734234955,0 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark79(-78.82737259808353,-97.33307486912949,-7.3330748691295025,67.64403934400863,0 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark79(8.044719801876326E-5,-71.51547983415954,-55.04370601308681,0,0 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark79(-8.150412693305146E-27,26.031064300560992,58.492969500845504,0,0 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark79(83.13147474255348,-42.561685318727505,47.438314681272495,0,0 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark79(8.540946568787732,-60.494424511050006,29.50557548894998,0,0 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark79(-86.44712623114094,-87.01533354238225,2.9846664576177453,0,0 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark79(90.23491545125468,-16.50904739953639,73.49095260046361,37.152093941108326,0 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark79(-9.181779893948045E-31,-81.10079086199212,100.0,0,0 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark79(93.43761797299318,-63.87410795560325,26.12589204439668,0,0 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark79(-9.488585743801406E-10,-94.84773517890221,-4.847735178902212,81.52793546634672,0 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark79(9.75087322772281E-21,-9.77969523920118,80.22030476079883,-9.533283385168872,0 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark79(9.803805225365261E-21,-23.202244604700795,-23.20224460470079,-2.20416470482823,0 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark79(9.82594549219022E-31,-13.812166949309507,76.18783305069049,0,0 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark79(9.850100828008224E-9,-32.75522608887953,-32.755226088879525,0,0 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark79(98.6165752412825,-30.984057230539165,-30.98405723053915,-0.08422342870073862,0 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark79(99.39347409622513,-71.86651120829058,118.29861059686787,-67.94388472615323,0 ) ;
  }
}
