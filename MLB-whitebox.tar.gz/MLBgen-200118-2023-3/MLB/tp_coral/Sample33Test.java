import org.junit.Test;

public class Sample33Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark33(0.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark33(-0.10958332040805718 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark33(-0.16928661593825253 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark33(-0.44692971982047425 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark33(-0.5325129121971657 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark33(-0.5706937359840857 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark33(-0.729036273704752 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark33(-1.1479836805291512 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark33(1.1619323856220396E-4 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark33(13.891879356239727 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark33(14.429203673218339 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark33(-14.975249412084835 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark33(-1.5386284383219389 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark33(-1.547823372285145 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark33(-1.5707963267948948 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark33(-1.5707963267948957 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark33(-1.5707963267948961 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark33(-1.5707963267948963 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark33(-1.5707963267948966 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark33(-1.5707963267948968 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark33(-1.5708149602914583 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark33(-18.42378771433333 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark33(-2.220446049250313E-16 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark33(2.220446049250313E-16 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark33(-23.963071694583093 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark33(24.268781025962454 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark33(-2.465190328815662E-32 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark33(2.465190328815662E-32 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark33(-2728.1755767504164 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark33(-2733.287654296758 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark33(30.09566526643127 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark33(-3.1415926535916125 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark33(3.141592722676401 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark33(-3.1415928920083727 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark33(-3.1435457785899015 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark33(-3.157217653590926 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark33(-34.55751918948772 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark33(-35.23685818378223 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark33(-35.607784886430515 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark33(-35.61034687949074 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark33(-3.7453410837537587E-96 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark33(-3.7894969699509176 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark33(38.0767652886486 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark33(4.141592653592017 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark33(-41.49387154834092 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark33(-41.825747246499944 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark33(41.97196665888623 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark33(-42.22381426859852 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark33(-43.98681286569166 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark33(-4.440892098500626E-16 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark33(-48.62651379901186 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark33(-50.199417020983006 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark33(-525.6750725600792 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark33(-53.553834671832455 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark33(-54.787426145104995 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark33(-54.793023253460206 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark33(6.072173285579495E-5 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark33(64.09472079757333 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark33(-65.11768433672842 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark33(-65.97817691607293 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark33(-66.05663728014287 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark33(-66.53627409155376 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark33(-66.81930453622597 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark33(-67.22231751766942 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark33(-71.54421363919539 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark33(-72.34316553629094 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark33(-72.87587727615232 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark33(-74.98173665776973 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark33(-78.04662464292839 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark33(-78.70717402690869 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark33(-80.03693469127306 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark33(-85.0730016467809 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark33(-8.881784197001252E-16 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark33(8.881784197001252E-16 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark33(-9.860761315262648E-32 ) ;
  }
}
