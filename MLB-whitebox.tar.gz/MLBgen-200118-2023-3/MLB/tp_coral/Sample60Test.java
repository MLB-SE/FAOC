import org.junit.Test;

public class Sample60Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.012179320484083532,-1.5502073557445297,100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.01259004968229666,-12.969339279470972,19.147324928267658 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.01483178910513151,-1078.1302801244406,1340.9853063907829 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.03637452928562368,-20.637844358370685,-95.16781135677894 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.04279426602669667,44.40714167067212,-53.16235329100468 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.0555550095163988,0.15974381821644634,-9.833221368644962 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.05686382616210956,74.5758066630862,-14.246395886327974 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark60(0,0,0.5178910393585028,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.5287735388709827,1292.1390087722068,-1124.3043458662048 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.5629216976924496,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-1.0,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark60(0.0,100.0,-0.012853931393438614,-15.943090025870191,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark60(0.0,100.0,-0.03725626737651408,-2.0775481085044554,-1.190761445835374 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark60(0.0,100.0,-0.05135108455719073,-25.39461016696465,0.059465551072865 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark60(0.0,100.0,-9.057964225190895E-4,-41.884538434422325,0.003301545006883906 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-1.1102230246251565E-16,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-1.1102230246251565E-16,0.0,-1.0658141036401503E-14 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark60(0.0,11.854528921093934,-0.019260375853341893,2.5554227266534455E-7,-3.4838189058311366 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark60(0.0,12.065251389360348,-2.209342682850414E-39,-7.146530786123069,0.17332135957800132 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-1.4612556990742376E-4,-1.4210854715202004E-14,66.92103787526293 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark60(0.0,15.535055237462114,-0.37384744501874245,-0.4931511907691347,-3.288830015312694 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-16.09660258659514,0,0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-16.32700034202477,-0.3058571779312019,0.38491514012686534,-3.9800094608335037 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-18.50763943076477,-0.016900088987025164,0.07790142281039891,-20.163897784220723 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark60(0.0,19.388220450961857,-0.022593247854491266,-41.93992608689194,0.01626701086936469 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-2133.5924745751927,0,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark60(0.0,21.5422151651875,-0.005302263273145369,5.096977913649764E-4,-72.97677053741671 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-2.220446049250313E-16,-41.55195094232658,19.798924682797676 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-2.465190328815662E-32,0,0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-2627.4186561662445,0,0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark60(0.0,26.652151031509025,-1.3877787807814457E-17,-13.125080929918054,5.551115123125783E-17 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-2.7755575615628914E-17,0,0 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-2.7755575615628914E-17,0.8236873118492464,-47.12730467071113 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-2.7755575615628914E-17,9.41878946947007,-100.0 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark60(0.0,28.580083102420456,-0.060857960164337616,8.084977113935593E-16,-10.10191654068052 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark60(0.0,29.17980659045011,-0.03981786832601006,0.0023567850463403484,-35.59576253293016 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-29.21793923358598,0,0 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark60(0.0,29.59137799890398,-0.008385625195434288,-15.811346458075192,8.50586077489408E-18 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-3.1204953248593625,-0.03210609757939725,0.07832833262644802,-20.053999288943217 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark60(0.0,4.199164905849961,-0.15248947246264735,-3.1469591120777194,0.0014895201544352088 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-4.440892098500626E-16,-0.8148003757419803,-3.1554436208840472E-30 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-4.440892098500626E-16,-71.06675895518404,0.018978849704516576 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark60(0.0,4.8148248609680896E-35,-0.02612017019150714,-25.190525215230974,0.02074549556192995 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-48.91071235778783,-23.93086876823709,-96.15155230032491 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-49.65680737918219,0,0 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-50.40894670909801,-5.31642230057588,-61.552297203752325 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark60(0.0,51.18422821108268,-5.551115123125783E-17,7.36463447072982E-14,-34.617063500337665 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-5.3142716187297345E-12,-9.031436907993436E-162,3.7453410837537587E-96 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark60(0.0,59.93792014870411,-0.007933977840232365,-19.124771203916183,3.2272480030905853E-4 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-63.46775087183651,-0.044905455992781555,-3.969864611091064,0.39180171962718013 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark60(0.0,6.473663837268082,-0.010686661152052935,-7.302963865140281,0.007966550485015109 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-6.938893903907228E-18,0,0 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark60(0.0,69.85389668848012,-0.015854771189637185,0.11695492235445294,-13.379730320743679 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-73.59100972429181,-0.013377258896453914,1.1102230246251565E-16,-12.595715714399688 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark60(0.0,78.96067579775365,-0.001587642382996377,-4.123112958949642,9.08350798275448E-5 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark60(0,0,83.50712697193552,0,0 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark60(0.0,8.43972538831427,-2.7755575615628914E-17,-34.83108511370341,1.110223014698872E-16 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark60(0.0,8.628261709596346,-1.1102230246251565E-16,0.06950921549391816,-9.6085640233356 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-8.881784197001252E-16,0,0 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-93.22565121159722,0,0 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-9.860761315262648E-32,0,0 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark60(0.0,99.16459614717687,-0.43159366801868615,0.031274952976795965,-3.870999138706484 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark60(0.0,99.99963692076594,-0.06114351997883721,0.019363840434097113,-3.7443934103233376 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark60(0,100.0,-0.011634988832468524,2.8576481726024557E-4,-88.41381325826403 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark60(0,-100.0,-0.025532723086010314,-12.070792942928422,5.7964829626617576 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark60(0,-100.0,-0.027092921178262182,-0.9942807488916472,0.9942807488916471 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark60(0,100.0,-0.03460688849795168,1.7053025658242404E-13,-8.593658468771409 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark60(0,100.0,-0.036724930276703247,0.010431158289703769,-1.5812274850846002 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark60(0,100.0,-0.05569938115919848,-0.07392188128467936,0.07392188128467903 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark60(0,-100.0,-0.06252032834930332,0.38000897608745093,-1.9508053028823473 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark60(0,100.0,-1.1102230246251565E-16,1.1102230246251565E-16,-3.2368417183846385 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark60(0,-1.0223588785773643,-5.551115123125783E-17,2.7755575615628914E-17,-3.510161353753521 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark60(0,15.13029775262365,-0.03878153302052245,7.743478319819641E-4,-10.170310941074673 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark60(0,-153.8285117133432,-0.058921924388058766,-0.017543720304104227,0.017543720304118077 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark60(0,-17.132090647970152,-0.026532630527229983,0.06466297822480982,-24.292050411499364 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark60(0,-20.382811255016964,-0.035827234787006154,-1.0921131942324964,1.131036654058314 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark60(0,-23.67734096222818,-0.017765428704246446,-341.47260910736827,0.004595488828829965 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark60(0,27.68336217174018,-0.41368133055961503,-12.996576367252255,11.451137221893688 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark60(0,29.40837274818569,-0.019011117564317895,-4.122295738634081,0.3482555529450337 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark60(0,29.42606097580432,-0.047668580258051985,0.7817246284359045,-1.8488753690699296 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark60(0,-29.86890523831745,-0.009481325776133004,0.35562128954260686,-1.9645286160352602 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark60(0,30.636871919790565,-0.2743301175185551,12.859708368398643,-12.862124008648813 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark60(0,-32.967361780351894,-0.048208985313707764,17.806528480294006,-19.3773248070889 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark60(0,34.98343069785287,-0.013148082566456526,-31.532075975505165,0.016962002488699543 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark60(0,36.371623922074484,-0.03988905152104316,0.018784030424611124,-57.487589514300694 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark60(0,-3.685115549591302,-0.04368080860252725,3.469446951953614E-18,-61.88234893799452 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark60(0,38.54340386535401,-0.5521413639681569,2.0234574408923268E-5,-1972.6131131747334 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark60(0,-40.66688715657193,-3.552713678800501E-15,-5.803532427275639,7.105427357601002E-15 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark60(0,-42.240414357082415,-0.041682032229278354,15.432229862875374,-16.932229862875374 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark60(0,-43.66808205184231,-1.7763568394002505E-15,0.591352442445988,-2.6562777356556637 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark60(0,48.97691079438623,-0.00123579208484151,-15.577196980716712,-0.05996996043735625 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark60(0,4.9657053088130185,-0.015871751516679376,-1.7112004513205215,0.23037635248324 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark60(0,-50.526897147379984,-5.551115123125783E-17,0.002628531194675894,-49.84101920932579 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark60(0,51.050349559364065,-5.551115123125783E-17,0.19523500725969378,-6.470085338254712 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark60(0,51.07481105527972,-0.016978921362600125,-32.60164777242245,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark60(0,55.98884895401937,-0.010208000245455554,-7.619378373097874,0.036027547474854454 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark60(0,-56.81870432499662,-2.7755575615628914E-17,4.53977454306053,-4.539774543060531 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark60(0,-5.795110858967973,-0.03293977779260138,2.31501406352732,-3.885810390322213 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark60(0,-59.58935843488693,-50.881616311085324,58.33387037116432,5.550127998096983 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark60(0,-69.96204529815051,-0.00863304529722364,-0.01648622942325062,0.01648622942325062 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark60(0,72.82217501895613,-0.0020939490775141456,-7.709322276616735,0.20375284239436553 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark60(0,78.01197480054361,-0.023361906257808762,2.5968384622659618E-5,-89.77602498284725 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark60(0,-81.17379975001451,-0.060658748327219375,-0.9931551631003794,-16.292737360432476 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark60(0,-84.42246692478311,-0.0110156859252411,-9.559087781423322,7.988291454628426 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark60(0,-90.35308753281976,45.680955801900495,84.19836696311651,-31.196010737467986 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark60(-100.0,72.61031037571894,-1.1102230246251565E-16,0.012066242684515874,-66.52542824761524 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark60(1.0362813428909843E-16,44.260215210928884,-0.05467712789289075,-14.122487179736847,8.881784197001252E-16 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark60(1.0842021724855044E-19,1.0842021724855044E-19,-0.051351916279923804,-2.548432062656701,-0.5954685702179328 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark60(1.0885383208889298E-14,2.22593061140216E-9,-5.551115123125783E-17,-35.12415991665875,0.04300055439309956 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark60(1.79691266669866E-15,75.60047742302922,-1.1102230246251565E-16,4.030083614779334E-17,-10.114143051870258 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark60(18.24795050499135,96.2299065686143,-0.03043677764093993,-35.3789325349954,0.044399200717577525 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark60(2.2990720619227606E-15,67.82897765699406,-0.03912609929493241,-3.9090461475820515,0.4018359554010095 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark60(-36.32634152232474,-0.9762133482464515,-1.1102230246251568E-16,0.01764271744442425,-89.03369516305946 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark60(-40.28400906729451,-3.6434455807172754,-0.05909438188750778,0.036693958091919665,-13.786657118315595 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark60(-50.26951988762436,-5.672513514483356,-0.013840890245056914,0.07717333438916185,-20.354133188982374 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark60(52.99950063803147,-0.06795020562091736,-7.105427357601002E-15,0.01738016776908611,-41.654204756652874 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark60(-53.37654694659249,24.7873855266463,-1.2158571684598637E-34,0.19483307758479995,-7.198164976800294 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark60(-5.6735792997236985,-87.02713704063297,-5.927180986772271,61.92514941023728,-90.79424713809748 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark60(66.91294783658039,-94.99406229230283,-2.7755575615628914E-17,0.0248644814182577,-63.174304759135744 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark60(75.356278663334,-15.473567326850329,-78.81066520259274,-42.57957742483149,46.8214191357346 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark60(-80.98783757333064,95.91689607567187,-0.04447297772347607,3.977560287156279E-4,-7.325557858922495 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark60(-89.08219607407437,-77.360069486409,-0.051629230723911235,-4.120172941810019,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark60(-93.47602716240412,100.0,-1.1102230246251565E-16,-2.421522946388688,-0.720133300911575 ) ;
  }
}
