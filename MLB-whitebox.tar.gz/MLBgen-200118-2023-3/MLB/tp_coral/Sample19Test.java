import org.junit.Test;

public class Sample19Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark19(-1.0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark19(-100.0,-0.0475789263143691,0.9999999997627307 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark19(-100.0,-0.05954108576647055,-0.8410884410458834 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark19(-100.0,-0.7335099077117901,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark19(-100.0,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark19(-100.0,-2594.6426178785628,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark19(-100.0,-5.551115123125783E-17,-1.0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark19(-10.026506816350349,-92.95408679579762,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark19(-1.0055888408613,-0.026301507158121636,0.9999999994378725 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark19(-10.128164469262671,-0.027524515274328476,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark19(-11.271236328714304,-0.05619903832400096,-7.778769097326427E-62 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark19(-14.906095501935882,-0.036021224790170336,-1.0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark19(-15.487824345954937,-0.02656833831784655,-0.02682633163068715 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark19(-15.669475724988718,-1.1102230246251565E-16,-1.0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark19(-16.460470743030786,-0.538649957858264,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark19(-18.585351860702275,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark19(-18.64036754051265,-0.006464556344716765,-0.9999999999999993 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark19(-19.19476148584865,-0.049407339346429796,-0.7071067811865479 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark19(-19.42113346865881,-16.452209197653886,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark19(-19.958929625280355,-1.7763568394002505E-15,-0.14482516042397356 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark19(-20.323414691990713,-0.0153750228680994,-0.6657995837883532 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark19(-21.30753120552982,-0.04336390835851771,-76.09963473601192 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark19(-24.294385853202755,-4.9E-324,0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark19(-25.85049512779119,-0.06162073164031519,-0.9926010315121636 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark19(-2.6380687557532383,0,0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark19(-26.69231375505707,-0.06119097280437638,-0.5654894541825541 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark19(-26.93679551502015,-0.05720071980430497,96.50593547968859 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark19(-28.52488804599001,-2535.6946701347533,0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark19(-29.256978195083104,-0.04141091446679911,-1.0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark19(-29.972479240490447,-0.0020160150596249477,-1.0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark19(-30.94579489406135,-95.04836590430573,0 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark19(-31.138367053527574,-0.04743662397431203,0 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark19(-33.91916845732435,-0.02304254313943073,-43.759697353841304 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark19(-35.43895237423304,-0.01789721760300341,-1.0000000000532878 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark19(-36.507791190587895,-0.057994773002252115,-0.9999977883337782 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark19(-38.59506328275546,-8.881784197001252E-16,-0.999999999999373 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark19(-39.56336417817813,-0.012007297677931184,-0.6690038134713284 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark19(-48.079233089512606,0,0 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark19(-4.970066670052047,-0.014246214604322627,-3.932751545920766E-113 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark19(-53.35508066037289,0,0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark19(-54.660705414793966,-0.04198977934529699,-0.1062605662575038 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark19(-55.150556841412836,-0.02688507066440371,-94.03686891085121 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark19(-55.474737823085206,1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark19(-55.97707252138971,-0.008264195990085932,-0.6703320440972543 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark19(-56.426545098017236,-0.028324043411571298,-1.0 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark19(-57.19407700913271,-1.1102230246251565E-16,-0.12793655315448405 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark19(-58.395925142913256,-0.0351280266920426,-0.08733455356844833 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark19(-58.90214829722094,-0.05739618414077325,-1.0 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark19(-59.123054353620674,-0.0012601898727853111,-0.030087169058771013 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark19(-59.66927328664912,-0.05602733708160257,-0.9999999999999999 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark19(-60.44916559591945,-0.042606498132253645,-3.600785487190109 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark19(-60.780332075713964,-0.043374136662277615,-51.9282928097443 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark19(-61.90679829661019,-8.881784197001252E-16,-0.9474656124912655 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark19(-62.36628519049325,17.668074404953288,0 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark19(-63.53977778950883,-0.038322435717437306,-0.014862290947506629 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark19(-64.23310008806764,-8.453495085192822E-16,49.00705908292943 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark19(-67.58417359279888,-0.05080923270309383,3.7375122002442864E-20 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark19(-67.63872805378034,0.0,0 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark19(68.48347353982521,0,0 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark19(-7.018051612143511,-0.002382044411491993,0 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark19(-70.72813931645945,-0.005234969347023055,57.18347650871257 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark19(-72.56170191680383,-0.05013035824319545,-0.7337456564783638 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark19(-72.83491146848753,-0.020502372832640708,-0.6146774132213082 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark19(-73.09982117748703,-50.19129002637197,0 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark19(-75.0409271358107,-0.01174688858212744,0.9508609458468129 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark19(-75.36413922735599,-0.024062952823529563,-0.06002430561722927 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark19(-80.82921312309895,-0.013333273607011835,-3.3753897284743175 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark19(-80.94075669343077,-0.010017516909029245,1.0 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark19(82.99600140236254,0,0 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark19(-84.67681080788006,-0.06222694931412692,0.0 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark19(-85.49923967235168,-0.04479225156868072,-0.893905652879738 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark19(-86.826746078462,-0.007359650592932976,-0.5805553707398358 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark19(-8.862248003654756,0,0 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark19(-92.79253389451038,0,0 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark19(-95.51287966149089,-1.0,0 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark19(-95.80766746783875,-0.040866262814232224,0.09459993759880315 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark19(-98.55886195354937,-0.025566482059549284,0.9999999999999998 ) ;
  }
}
