import org.junit.Test;

public class Sample49Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark49(0.004358528769116653,3.8304365130005086E-7 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark49(-0.01318648441616999,3.5460342868418267E-6 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark49(0.01589648073064883,1.5788410243327074E-5 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark49(-0.030658176089745495,1.3612541033143899E-6 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark49(0.04444858976947261,0.21079087685653566 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark49(0.434772693613656,49.56522730638634 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark49(12.772454312600985,29.43562948693227 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark49(16.9423844833765,26.23603542315169 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark49(-1.888189011932386E-41,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark49(-2.3656485784251575E-5,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark49(2.458713984105529,19.885913016812708 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark49(28.730553666553647,65.11103907671963 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark49(28.84051015291601,36.730871356613136 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark49(-2.8975149759841314E-25,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark49(29.95905380719381,64.08912525006173 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark49(3.063666426406588,5.32285249846507 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark49(3.285064219683612E-11,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark49(39.09517816328432,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark49(-4.861323435234738E-9,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark49(5.102973201701721,6.615013376365116 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark49(57.34731670744421,94.94977602410916 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark49(-61.057723792643024,0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark49(69.36026832953698,69.72142331330186 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark49(-8.423179720354483,51.53168469933195 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark49(8.786139039111827E-9,0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark49(9.297735070745716E-8,1.9852848871784737E-4 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark49(-98.52740165684226,0 ) ;
  }
}
