import org.junit.Test;

public class Sample78Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,0.0,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,1.1102230246251565E-16,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-12.884294427922157,0,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-13.106747591020465,0,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-1.4615655675980292,0,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-15.966051330314372,0,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,17.02385512056057,0,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-17.301610186430864,0,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-18.369105971205983,0,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-1.8E-322,0,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,2.053960237210802,0,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-22.334247731023055,0,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-2723.6420238508003,0,0,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-2737.8425862252807,0,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0.2755855032929446,-16.272438660376082,0,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-27.909875248458775,0,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-28.77111669681109,0,0,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-31.681700796264394,0,0,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-3.508354649267438E-15,0,0,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-3.671790762952881,0,0,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-48.67293802214476,0,0,0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,64.53109110659912,0,0,0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-66.7446006374092,0,0,0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-71.42528736019646,0,0,0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-74.49801512262073,0,0,0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-78.55310648686435,0,0,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-7.864304480691729,0,0,0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-80.50219091047488,0,0,0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-8.767237396033612E-193,0,0,0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-89.99999999999997,0,0,0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-89.99999999999999,0,0,0 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-90.0,0,0,0 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-9.000307921116274,0,0,0 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,90.7516658767072,0,0,0 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-9.671267194132298,0,0,0 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-98.63859193173164,0,0,0 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,100.0,-32.70183199286767,0,0,0 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-100.0,-32.70249290155671,0,0,0 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-100.0,-3.552713678800501E-15,0,0,0 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-1.4210854715202004E-14,-32.70216807790105,0,0,0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,14.814328842543986,-0.6968211049947413,0,0,0 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,1.506538697534315E-7,0,0,0,0 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,1.751719548159151E-36,0,0,0,0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,2.0154200538230164E-36,0,0,0,0 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,22.543184305291128,-0.4293471262333684,0,0,0 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-22.972840560165636,-1.6670937704800934,0,0,0 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,24.64281133816246,-58.318002628966426,0,0,0 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-25.108207955305133,-4.365725565455961,0,0,0 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,2.6430734786960386,-4.0833769509203824E-15,0,0,0 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-26.59973533407009,-7.081687465453186,0,0,0 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-26.735505342352383,-32.70033489691882,0,0,0 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-31.5229381592053,-3.5083546492674388E-15,0,0,0 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,34.180656539606105,-8.782308213994838E-12,0,0,0 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,3.5056766494710416,0,0,0,0 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-39.35705675757355,-4.757551101533622,0,0,0 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,41.86032847096379,-3.50835464926744E-15,0,0,0 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-47.269918657079614,-24.35678392146434,0,0,0 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,48.1863299356159,-3.552713678800501E-15,0,0,0 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-54.14478901311517,-31.00222932102183,0,0,0 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,5.4907872383348035,-32.70334941745723,0,0,0 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,56.66468332280641,65.8258173637376,0,0,0 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-57.243057982504155,-1.7053025658242404E-13,0,0,0 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-57.65740214668244,-3.5083546492674388E-15,0,0,0 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-59.17130594694069,-5.331985044821536,0,0,0 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-64.94388613570896,0,0,0,0 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-67.36129647732803,-2.55883276952369,0,0,0 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-7.194456020395484E-5,0,0,0,0 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,71.97992776128882,-89.57475420002848,0,0,0 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,73.27589177454456,0,0,0,0 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-73.44830718450655,-32.22033488949696,0,0,0 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-75.77832345283628,-3.552713678800501E-15,0,0,0 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-79.4064577735803,-3.552713678800501E-15,0,0,0 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-80.79513906589281,-4.189827238647003E-15,0,0,0 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,85.82079116584046,-3.0817081129604684,0,0,0 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,86.9617274007413,-2.447514483949547,0,0,0 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,9.152374900712346,-9.2570844942462,0,0,0 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-92.5153558371714,-32.6827669846017,0,0,0 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-9.413154333626354E-9,0,0,0,0 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-9.486025045628918E-9,0,0,0,0 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,94.87524632727974,-50.41871239164117,0,0,0 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,95.4746813734084,-3.7548871819683427,0,0,0 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,99.23536071750203,-32.69107696168304,0,0,0 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-9.948197547916891,-20.125560424692623,0,0,0 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark78(-100.0,-100.0,41.810330281779926,-14.764803033104274,-20.908783887782935,0,0,0 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark78(1.2039688045913183E-26,0,0,-100.0,-12.192969983814969,0,0,0 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark78(1.3393538213036095E-5,0,0,-70.58387162295537,-3.308750995499338,0,0,0 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark78(16.882722488921488,0,0,-43.43331614146151,-30.41538811477271,0,0,0 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark78(-24.07692994445742,0,0,-95.41917895327354,-4.77110228938345,0,0,0 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark78(24.25351038511124,-100.0,-24.57305659708065,-64.65490428000746,-23.297996254588284,0,0,0 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark78(2.561608352976319E-32,0,0,-100.0,-6.2846995417980756,0,0,0 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark78(32.319554112525225,-1803.41088148128,1096.2985410969236,-124.85310930990028,-10.105049893086488,0,0,0 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark78(-33.11464371708395,64.86888903042795,68.9317824623875,42.918257491619585,-9.742138345351819,0,0,0 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark78(-34.33913041770768,-24.693556959230193,-21.24320131337747,-94.84276407068326,-22.83782211500285,0,0,0 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark78(35.89883413054869,-96.35655717309501,-57.95864108375739,30.558898107553887,-8.238412734522853,0,0,0 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark78(4.009426988659559E-9,0,0,-100.0,-32.257481542341566,0,0,0 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark78(-43.89961788580635,-1451.5398386653096,1191.1676370607233,-12.62478341760189,-12.0909009630751,0,0,0 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark78(44.12499014767806,-100.0,-100.0,100.0,-6.184756455049595,0,0,0 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark78(45.799956794165496,0,0,97.4505171587196,-32.31712483644131,0,0,0 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark78(53.82456096421504,0,0,90.8356595169453,-32.4599158185122,0,0,0 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark78(-58.43200839888469,-67.72100052781376,81.44248960732585,4.312550978253199,-10.840553111770191,0,0,0 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark78(6.085354694421929,-94.10523773361155,-94.10523773361153,76.97183003610071,-3.552713678800501E-15,0,0,0 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark78(-63.90671488195245,22.92460662797579,-94.5683993465255,0.7662981172769321,23.709156254696467,0,0,0 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark78(-68.62640766931437,58.35456351992565,85.35128918346217,-87.51234602124818,-10.752266533764313,0,0,0 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark78(75.71465826200877,-26.520444187342815,82.45502912542273,-17.67541963005771,-0.016726702483026656,0,0,0 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark78(-7.845918572259958E-20,0,0,6.3451021097639035,-7.641471291657363,0,0,0 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark78(-8.109879204815315E-14,-10.095834418157239,-10.095834418157231,39.090712168840355,-30.094967611009807,0,0,0 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark78(83.47744242877744,45.24607599491524,85.91206131575305,48.57502255347899,-6.506887978620824,0,0,0 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark78(-84.80516205225402,-75.34507637238859,-75.34507637238858,-7.044679466367693,-21.100251159931588,0,0,0 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark78(86.93901825335504,-18.653664449151126,71.34633555084888,89.68462966141362,-3.552713678800501E-15,0,0,0 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark78(-8.888463881093312E-9,0,0,26.84240767285034,-12.848723163819528,0,0,0 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark78(90.96010842339388,-29.11440404633578,-50.85115814231871,-41.46557936468227,10.692488541882298,0,0,0 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark78(-91.50595870610734,18.294965257359323,18.294965257359316,-54.47526561388361,-15.262316689836837,0,0,0 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark78(-93.63727085159834,-27.812700759246823,-28.390051661127487,-12.716889514326951,-3.247015207363651,0,0,0 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark78(9.419215947933893,-91.59154447551153,2.0376843235833064,59.36457732752646,-19.21683226209656,0,0,0 ) ;
  }
}
