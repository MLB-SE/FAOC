import org.junit.Test;

public class Sample57Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-0.003109008960712978,11.795015468539212,0.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-0.00889047952148303,-31.376397539005566,16.649339563908683 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-0.013880856089209057,37.476352255256224,-35.078822454893285 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-0.03232240101118132,100.0,-100.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-0.0371036861732722,-47.52010070300676,30.96420573204196 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-0.03964767154518664,-48.699653876934306,49.048832560424316 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-0.04620448274583727,-41.38914077149228,35.92136606883903 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-0.05356661507711778,1.7763568394002505E-15,-30.565346501564427 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-0.056668277153078456,2.5243548967072378E-29,0.05539405521737062 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-0.058416966643294266,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-0.05998217229322354,-63.49776720278053,90.78522781201053 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-0.062038024706491945,-45.94592807315237,-100.0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-0.07326261280637425,0,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-0.22471429327782277,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-0.7209555394900078,-1480.4591140214213,1044.88545228777 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-0.9999999999999991,-1460.3524206548182,1065.6053049890156 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-1.0,0,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-1.1102230246251565E-16,0,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark57(0,0,1.363524722004712,0,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-1.540743955509789E-33,1.463023860841312E-98,-3.234539689561756E-173 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-15.865951967559184,0,0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-1741.2714292806388,0,0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-2.220446049250313E-16,0,0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark57(-0.024872008131091108,23.761012855983342,-0.030575220074450345,-4.026227781118602,0.3712098298302077 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-31.40978198662812,0,0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark57(-0.0318696366523028,33.25787097788909,-0.03638758509958015,0.36645240655448874,-4.286494777218309 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark57(0,0,31.989840684537114,0,0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-34.921344282675506,0,0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-49.67694792240302,62.57947900948017,44.28674461314819 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark57(0,0,5.466727784934889,55.992859542142895,-17.13036743187179 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-6.389117656681043E-4,-15.70833258576836,96.50423104318892 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-7.520558764676636,0,0 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark57(-0.08582929194779772,97.64263792518697,-5.21150086133896E-18,-26.620882320451017,0.03610783712840437 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-8.881784197001252E-16,84.89424737805993,-0.018502977237075467 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-91.86474741717919,0,0 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-9.860761315262648E-32,0,0 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-99.31870330697473,0,0 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark57(0,-100.0,-0.010784675578535852,-1.6234400210476148,0.9675727507205649 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark57(0,100.0,-0.03802516044367302,-4.697551619190093,0.27058917871030697 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark57(0,100.0,-0.041192040379951556,5.85728038219381,-5.8572803832643165 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark57(0,100.0,-0.05534143279710772,-13.84297938953414,13.842979388143211 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark57(0,100.0,-0.055612207737063324,0.041484101162700154,-37.82958196464608 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark57(0,100.0,-0.21571505857986717,-9.64894518324959,8.187257989040447 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark57(0,100.0,-0.9999999999999931,-2.551885334067477,2.216300637258231 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark57(0,-100.0,-0.9999999999999999,4.698210416744415,-4.690407265439656 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark57(0,100.0,-1.1102230246251565E-16,28.345123153331432,-3.8247179017991517E-16 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark57(0,-10.697654710271308,5.115918731355308,14.058100628529672,-47.370824390418576 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark57(0,20.00554249694821,-1.7763568394002505E-15,-38.94941961449561,0.040329133074175516 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark57(0,27.812443940576014,-0.0581557538533711,-30.065658384003484,1.7734814643660815E-15 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark57(0,29.221060131998236,-4.0259813164486765E-15,-32.870419265877615,0.04778753547647985 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark57(0,34.14098250227308,-0.02510544665024802,-7.4564169531958155,0.15934200755006245 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark57(0,-41.23918075547785,-0.058563849714011365,0.05668232354705628,-24.273337755505267 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark57(0,43.60844727386671,-0.05737642213760344,-62.814553558307075,1.4210854715202004E-14 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark57(0,-46.04128114608014,-0.01006802369164886,-0.18505433323931797,1.1538549651983256 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark57(0,46.8436768586391,-0.0526777408472824,-21.451326641726638,0.0732260690925949 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark57(0,-50.04223444019814,-0.008148973733264717,-7.219506150067002,0.007452550825952751 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark57(0,50.34278634055693,-0.040498924448642476,0.021982141196833727,-71.45783992239714 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark57(0,-51.3508661192301,-0.021348367271326274,-5.28211346325158,0.015245950226349675 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark57(0,-5.315034836260395,-0.028353364869098174,-111.94812937298633,0.013769319687438563 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark57(0,-53.2293556079817,-0.008415306203699829,0.4314896122655814,-17.63945288021455 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark57(0,-54.23831960628232,-0.027981127217794888,-24.507805307184242,0.026424955281910273 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark57(0,57.921188648274466,-0.019159774869088375,1.1614421951160239,-1.161442195116031 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark57(0,60.05728746549742,-4.440892098500626E-16,-24.26030580495937,0.06474758972221117 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark57(0,69.88130787112208,-0.059975925441297484,0.07226815140988663,-21.735664966516588 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark57(0,-7.236232884537955,-0.042256972325801986,-0.978127419694113,0.9537616466305138 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark57(-0.734062123303957,94.75513278537221,-0.026434858642745168,0.06651452469335553,-13.600732064746815 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark57(0,81.2966053391539,-0.3497841041066809,-22.924814073599734,22.924814073599734 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark57(0,-84.572497930902,-0.054606403345993065,0.15119155586322108,-10.389444819348583 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark57(0,-84.7796080967955,-0.011263976878047402,0.08324824908608264,-18.868821194913178 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark57(0,86.94929796126613,-0.9999678367933877,8.881784197001252E-16,-2225.1363582850495 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark57(0,91.00572331195947,-0.024733435600257404,-13.726666942737696,12.1558706159428 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark57(0,92.34410763846205,-4.440892098500626E-16,-76.94264148150539,0.020415159871687738 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark57(0,98.0347677105928,82.4769896458892,-3.1057070238370983,-33.22605722477847 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark57(-100.0,149.99786900663617,-0.020558522377484123,-2.757521271704447,-0.40053918268052185 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark57(-100.0,-4.393419081211485,-0.05120451344058885,0.013611855990478122,-7.772795574614928 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark57(-100.0,-60.6854437954663,-0.029580270266430453,-3.90635474638906,0.3795331271081157 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark57(-100.0,-72.59043966507441,-0.04046592958778927,-15.826051865461203,2.220446049250313E-16 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark57(-100.0,-89.24454946738686,-2.1390211526008207E-27,-14.174264549586496,0.11082030544157728 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark57(-10.312684086415288,31.48823123137669,-0.029390841699728436,-1.0772762418933002,-2.0828951372943516 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark57(-14.099578022823138,-46.242856248887904,-0.0556616821668236,6.62353447199936E-5,-7.166970289429951 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark57(-14.86215693627284,-39.672920439898704,-0.05638643189234438,9.482211961543323E-4,-10.02149964908384 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark57(-15.581482230929819,-9.977539150535094,-0.02626210153070871,-10.33657554960722,0.0184218811047334 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark57(-1.6671280024235072E-19,-95.89569466516126,-0.035245656449788526,-2.1989167907770204,-0.9583495340146233 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark57(-21.49826935063406,-99.97395521747436,-0.029333156039052635,0.01826266073697497,-19.066712901765452 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark57(-22.418548807727106,-21.026998533457018,-0.059488410778087766,-20.39668763919924,0.07691645242071843 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark57(-24.838168797929633,-77.94827761108269,-1.767250595078077E-45,3.469446951953614E-18,-60.9519277023284 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark57(-2.6101217871994098E-54,22.731242869850654,-0.06249901206064026,-3.7194640044630347,0.0438299747609161 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark57(-27.518901903481986,-37.31109356961913,-1.810962884106679E-18,2.7755575615628914E-17,-3.4698603811890605 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark57(29.354747091411085,97.02440678569948,-0.06150958007104364,5.297900423592641E-43,-44.96795109947764 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark57(-31.564717155178897,85.79047391633605,-0.017035368384803573,-3.855541299964522,0.29461670310001414 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark57(-32.8023731063757,-83.585268838214,-2.98430653496101E-6,-4.034782054333041,0.24533579109225592 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark57(-37.487056787053135,28.533553725043422,-0.007596093759823861,-3.9032804162305896,0.12287133086350036 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark57(38.500179603133574,28.65989289395486,86.67464134658613,-87.05615423875213,-27.752317038902376 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark57(-41.888063743479094,-15.285697040877752,-2.7755575615628914E-17,0.015677496663731527,-98.7838741658054 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark57(-42.57107985520915,-32.886086284550956,-0.0299864307974686,-13.958249358521858,0.1125353392426598 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark57(-43.93515231584005,-25.412464888913277,-0.021897848964654104,-3.147143752064385,0.005466413422513913 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark57(-44.527228718193925,-1.2408114066439353,-0.005369089484345446,-35.219852895082255,0.04459974127303145 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark57(-45.46931188761113,33.28607115750683,-7.397678816153443E-9,7.915564674704963E-7,-10.05838972639678 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark57(-47.25483965915775,25.42768357203289,-0.02901247044232047,0.02874447860814655,-20.1380940988511 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark57(4.913349949645587,-85.37526997280563,-1.4504462949435228E-9,0.3642378316173762,-4.312556770448224 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark57(-53.779741513851384,100.0,-0.031740554542743334,0.3566566266746356,-4.404225827627408 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark57(54.5160704634757,33.9066084711169,14.587905138342123,-52.7342005439654,-96.8366543282305 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark57(-56.9568270393174,97.70997812359457,-0.01165544790851214,-41.69258651035324,4.837150879798064E-18 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark57(-60.19337775128781,-76.87648612603982,-3.569947962163014E-27,-13.409972109888447,0.09395330411871702 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark57(-6.044867540167331,-49.08513238671072,-1.7763568394002505E-15,0.06842630884124058,-10.12424957396044 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark57(-6.134267082210542,-18.564799999572273,-0.03345764760127781,-7.297797085991959,7.178183962920675E-15 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark57(-61.5886038205169,-45.044762273434486,-0.06126201029831367,-26.227834526372263,0.007120222014536826 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark57(-66.0597852567436,-40.88415491287172,-0.020325896369448204,6.938893903907228E-18,-32.23575112116846 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark57(-66.31993014714435,-70.86955382428293,-0.03336549619602269,0.38397280895019925,-4.090905111457058 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark57(-6.8972695010872735,34.400108989885865,-6.661815859870483E-5,0.023655456239148887,-66.40312961688969 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark57(-72.86016278668866,-59.83901133858772,-1.1102230246251565E-16,0.05860068228691945,-26.517899675733553 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark57(-74.87869627312507,-58.754657404622314,-0.04531313891333055,1.7763568394002505E-15,-15.823027200284887 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark57(-7.534112413734345,24.347624457283583,-0.028549107595255196,-22.38931582159714,0.07015829957964326 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark57(-8.967262537869889,57.70747716906318,-0.05465344573135478,-7.343045352477169,0.20863959514059693 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark57(-91.21533432940015,18.698275597211136,-0.046835664452491585,3.0531133177191805E-16,-66.07587056226458 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark57(-96.58516508598281,-100.0,-0.0490891499659134,0.01571199886788688,-97.78957196547077 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark57(9.809037503165024E-25,32.38788935692741,-0.02950498161340831,-41.52228391540908,0.03783020052545716 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark57(-99.45885909349263,7.513626963140406,-0.008614344297527063,0.2180430912456206,-7.2040637372244465 ) ;
  }
}
