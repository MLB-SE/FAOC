import org.junit.Test;

public class Sample35Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark35(0.0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark35(-0.07296900998387912,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark35(-0.4192489069508838,23.01202580796317 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,0.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-100.0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-40.19140624999997 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark35(-10.005198555775038,75.51516331526048 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-709.1005282834012 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-709.1063738142086 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-709.5407967108222 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-709.7373193678249 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-709.8441702175683 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-710.8437275748137 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-711.9434973637402 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,715.4077967673966 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-716.7183454846005 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-721.2425279115035 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-727.9079743794401 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-729.157379142689 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-730.7757887507777 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-745.2332888579632 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-746.0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-746.0000004637865 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,746.5098240116529 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark35(-10.087963435474151,-709.9932907186477 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark35(-10.08941821190183,-746.0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark35(-10.131417450054172,8.13609295268975 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark35(-10.19940518661176,0.0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark35(-10.322039453963598,-31.838471076435113 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark35(-10.32251139618316,716.7555033434633 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark35(-10.452987417538282,744.1327722444079 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark35(-105.13175283037204,-709.6323115675475 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark35(-10.604548347927619,0.0 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark35(-10.820185208959956,-746.0 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark35(-10.937739491469415,-26.850344966596523 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark35(-10.990381938589314,-1.494140625 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark35(-10.996102442778286,-95.30358514577591 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark35(-11.01210329414971,0.0 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark35(-111.02859662145715,-746.0000000176431 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark35(-111.52921162787503,-717.2031922862978 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark35(-112.05300795193652,-1.156691079119916E-15 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark35(-11.23138593922181,716.3462586341022 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark35(-11.24127897420324,81.59820617717511 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark35(-113.05279687312164,-7.924587072857546E-15 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark35(-116.98046607320254,-40.17414292515686 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark35(11.740043198944903,-95.62260397750852 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark35(-11.786424144288759,0.0 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark35(-118.18687962033674,-746.0 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark35(-118.92568030412957,0.0 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark35(-119.38052083641212,0 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark35(-12.024045196390247,-98.58986060354773 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark35(-12.192709025091133,-4.245997360778546 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark35(-124.09268672553893,87.5121061073402 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark35(-129.38215042627294,-745.5169015549693 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark35(-136.65555115864694,-11.225111263488728 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark35(-141.71630250814897,-748.1914062500105 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark35(-142.44351254178315,-745.9999999997855 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark35(-142.93983589769675,-804.6661368422895 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark35(-14.383422455740032,-38.66475276224557 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark35(14.839561206449218,37.183634028042604 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark35(-1.5707963267948966,0 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark35(-1.5707963267948968,0 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark35(-15.876845327825773,-729.4813328456536 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark35(-15.896337778011542,0 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark35(-15.967837565955875,-54.71634390794107 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark35(-15.975974563805934,-746.0 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark35(-15.997757115357913,-715.0011389187148 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark35(-1.618064519434796,0 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark35(-16.32750818054896,-709.3016832162816 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark35(-16.775610138534102,-709.6765609221377 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark35(-16.81382062071573,-709.2960698198594 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark35(-168.59042775341766,-40.191406248278554 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark35(-16.87547905917927,77.11107409713148 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark35(-16.928410419422676,-734.3435324023383 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark35(1.702506631048422,0 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark35(-17.089548042346323,-43.97875544719025 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark35(-17.16387915563375,-745.6029908423418 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark35(-17.243745752912023,-744.6688338390474 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark35(-17.275030322234784,-716.8785880131792 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark35(-17.275030322234795,0.0 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark35(-17.282488867253015,0.0 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark35(-17.40434357948298,-746.0000006423928 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark35(-174.3558488092082,-867.38621925552 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark35(-174.4995825413194,-47.70389651525515 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark35(-174.59914186244097,0.0 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark35(-17.466467618790332,-713.1790320300568 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark35(-17.65033332329282,18.47482613514731 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark35(-17.778502136331127,81.17658056674435 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark35(-17.987680635228728,53.34637461106375 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark35(-18.013724836879547,-709.0282139616279 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark35(-18.147263998368707,0.0 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark35(-181.75396354779812,0 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark35(-182.03439641495655,0.0 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark35(-18.403095117396134,26.419746843920905 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark35(-18.44601996687929,-746.0 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark35(-18.536247779421288,-26.5530657368094 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark35(-18.556606257858387,-709.4376560105975 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark35(-186.73689662901162,-726.9196512537491 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark35(-18.78007713060947,-27.291663072105976 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark35(-18.80013947786992,-709.3415517427953 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark35(-19.077111757016226,-62.33033546564091 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark35(-21.99115238982599,0 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark35(-22.00906414644524,-709.1761679686254 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark35(-22.073429592025335,-741.1599396750312 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark35(22.113335402345015,27.174193585552956 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark35(-22.138917795355685,0.0 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark35(-22.142340675779295,-22.386461633212235 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark35(-22.308120222738843,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark35(-22.37812977343476,-722.4277934020076 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark35(-22.391086696712517,-711.2933913400211 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark35(-22.418954724201726,-746.0 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark35(-22.426315298534277,-714.1120354071447 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark35(-22.452894804368043,-709.8854003525419 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark35(-224.62468775212005,-725.3846021648208 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark35(-22.467386399347376,0.0 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark35(-22.618139344706037,-709.659351190555 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark35(-22.637147190271634,-746.0 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark35(-22.664201083260878,0.0 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark35(-22.821328681388692,-727.1513278649718 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark35(-22.836467287319493,0.0 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark35(-22.939769514113095,-745.9999999940362 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark35(-23.08137090875978,0.0 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark35(-23.17935363667769,-714.8529620143717 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark35(-23.195978496178885,-709.9329717760381 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark35(-23.250912821734943,77.29517841846774 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark35(-23.33206766698352,-78.25726633454377 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark35(23.510235735062167,-47.240629222415656 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark35(-23.558215629414384,-709.881839464133 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark35(-23.558977924476743,-715.2135126818482 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark35(-23.56567417443253,-709.4388023107288 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark35(-23.582148366353223,14.373789604919082 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark35(-23.615739708281325,-715.0120613019973 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark35(-23.674342135948585,-17.961924874351666 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark35(-24.026319806885454,-28.294221722457863 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark35(-24.058413243728133,-745.894239654295 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark35(-25.04977708311626,92.53010962118674 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark35(-2726.80249371485,0 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark35(-2728.0906257096267,0 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark35(-28.078945730295302,0 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark35(-28.289146624273727,-746.0 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark35(-28.34864371737337,-709.9492912222214 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark35(-28.39876242074328,-746.0 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark35(-28.40501333368522,-720.7751380101203 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark35(-28.423739713870162,-709.3860180927221 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark35(-28.569020926911527,0.0 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark35(-28.709767618574375,74.80071071531415 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark35(-28.816374947163197,-746.0 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark35(-28.948850819862713,-747.1914075416161 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark35(-29.319097199272832,-722.024501013065 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark35(-29.404329847650217,0.0 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark35(-29.41830442751683,72.74677679070007 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark35(-29.537157485473788,7.386194495492134 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark35(-29.56616975244171,-709.4343714688914 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark35(-29.702012772645176,-746.0 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark35(-29.83689515408419,-732.2368431031429 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark35(-29.84580872958544,21.892517126449846 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark35(-30.198413906824555,-731.2662063881361 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark35(-30.22626173414789,-712.868590006807 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark35(-30.228775586388046,0.0 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark35(-30.361003364827567,41.39778726553055 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark35(-30.5737248483898,23.291545898846366 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark35(-30.725175184035965,-746.0 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark35(-30.862049656091102,722.5774494368945 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark35(-30.87568289183345,0.0 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark35(-30.92211708001642,-10.030011211413964 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark35(-31.033122090791437,0 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark35(-31.102455291471813,-709.4212713853626 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark35(-31.415926535897928,0 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark35(-3.148686585456475,0 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark35(-3.148687266133803,0 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark35(-3.1649027421458698,-718.5811244410588 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark35(-3.170063982111884,711.3315029373007 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark35(-32.49556952070702,-74.17052820421712 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark35(-3.2846927978283986,-94.2531144438889 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark35(33.24859471153806,-37.47903358981117 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark35(-33.5814297185767,9.829710693111963 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark35(-3.3688446546220305,-746.0 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark35(-33.931388265091385,38.32008044631911 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark35(3.469446951953614E-18,0 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark35(-34.741034259381934,-46.489767610782295 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark35(-34.894560776040734,-709.5012159499183 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark35(-34.97475871367742,0.0 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark35(-34.9967638323012,74.31749813594772 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark35(-3.503762613038532,-709.777784181052 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark35(-35.14966715113404,-8.146828459450958 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark35(-35.207176394296496,-719.9159782333217 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark35(-35.30451954529509,-709.4671862442465 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark35(-35.32412809496762,-81.39824788499195 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark35(-3.5360859690620146,-64.35732418374869 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark35(-3.540558008829265,-740.8682706004049 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark35(-35.48252549139673,65.04687657671153 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark35(-35.643695306910544,-32.99475520796729 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark35(35.746348000371654,-99.7459391659609 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark35(-3.5920662318308416,0 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark35(-3.593960092818577,-746.0 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark35(-35.94096669189126,-709.9724931555876 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark35(-35.98336586928221,-739.3931398518198 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark35(-36.02434277881827,-30.81397358774531 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark35(-36.0964515560829,0.0 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark35(-36.13069794135956,-751.2790625625219 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark35(-36.2033834261698,-84.11150704047772 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark35(-36.22176496625238,-709.6127245303815 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark35(-36.228778499099825,24.907705660872764 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark35(-3.629501491616054,-746.0 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark35(-36.3779374170335,0.0 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark35(-36.39993473856799,-746.0 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark35(-36.450939187822314,-732.7063928162091 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark35(-36.81347177739186,23.179107316551864 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark35(-3.7198120725120134,-86.62910076293593 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark35(37.30973284130175,71.45178590717924 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark35(-37.39675825548407,36.74160811517166 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark35(-3.814282799542653,-722.8031252161177 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark35(-3.819643775595729,-715.0762326614216 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark35(-3.8312786010562245,-709.9846724867161 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark35(-3.8383595571088733,0.0 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark35(-3.840313558486912,-713.4448042296978 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark35(-3.8948106182432554,-761.0020102864945 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark35(-3.9782416262777076,0.642361716744702 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark35(-40.84071975545638,0 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark35(-40.95371786448801,0.0 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark35(-40.96628867684704,-710.8033297739133 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark35(-40.98300525531384,-62.1093557910192 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark35(-41.05225713994738,0.0 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark35(-4.110183342004015,737.3677626238682 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark35(-41.109445231077004,-709.9016061824191 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark35(-41.131532973056096,4.0598500012586385 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark35(-41.20899514137308,-720.6692722606009 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark35(-41.27285946700976,3.552713678800501E-15 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark35(-41.38276363986393,81.59418943595179 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark35(-41.456820978694765,-709.5056171026533 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark35(-41.54141087936252,-709.9904806970027 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark35(-41.56168347805247,0.0 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark35(-41.59891060542489,-714.7289001098238 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark35(-41.707194578872844,0.0 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark35(-41.72718924993346,-749.1914064227129 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark35(-41.8021440204857,-709.917635250983 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark35(-41.88794218655136,-730.7494504938946 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark35(-41.890392877580474,10.048115216365488 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark35(-42.01867745882335,76.52716520016384 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark35(-42.04298397631847,-1.252748697827572 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark35(-4.216352372310993,40.53593257618846 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark35(-42.231269623193434,0 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark35(-42.24759498370367,-51.99026122740271 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark35(-42.25573861399017,-746.0 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark35(-42.36507979730027,24.763156675987943 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark35(-42.38678795482808,-709.8271293147326 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark35(-42.40313341272058,-709.9993644069555 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark35(-42.40881553391462,-746.0 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark35(-42.41019273972674,-709.4778340369346 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark35(-42.41049889706177,0.0 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark35(-42.53650841569391,-765.4862665166501 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark35(-42.56233364555946,-745.8916397959691 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark35(-42.56530748877521,85.09997671596096 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark35(-42.58125846023873,-709.8939705526797 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark35(-42.631543613421506,0.0 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark35(-42.637075971632136,0.0 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark35(-42.63950750953375,9.432782873264973 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark35(-42.67242738512707,-740.5150226124387 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark35(-4.27257237846861,-746.0000000002789 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark35(-42.74474066767461,-743.0441876207949 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark35(-42.75912854058079,-745.5214371486383 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark35(-42.764440094508565,-709.694132609947 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark35(-42.76896497624134,53.29507844603752 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark35(-42.831314706698876,-725.2671934998808 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark35(-42.832931856324706,-40.19140625 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark35(-42.849859250274505,-737.9022394607761 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark35(-42.873275545323224,-1.0900140913037621 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark35(-42.88509872520483,-709.9625741381008 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark35(-42.889781820905114,713.5888298291776 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark35(-42.91939559326497,-719.3236566482407 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark35(-42.92407323731407,40.71934932075908 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark35(-42.92959807592762,27.285942068264973 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark35(-42.965781059529526,0.0 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark35(-42.96835828038591,0.0 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark35(-43.073638113072896,-41.39765514128424 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark35(-43.18922658507815,-733.6211789316778 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark35(-43.3576813553396,-6.464451116982474 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark35(-4.339864455918345,0 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark35(-43.44110361378304,-709.9041807794737 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark35(-43.683146883265614,-734.95230440878 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark35(-43.73754866518108,-709.5450932367587 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark35(-43.76691332218015,-1.1856360081027564 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark35(-43.85741901978222,-709.9919465037524 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark35(-44.09195207931775,0 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark35(-46.17625740971858,0 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark35(-4.708659707875618,100.0 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark35(-47.15970945779293,-725.2748236355843 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark35(-47.23551409060749,83.58249205015505 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark35(-47.28435482784818,-40.19140625 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark35(-47.31137715789735,56.89293272928961 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark35(-47.340842319865,78.31638454048539 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark35(-47.34531964166591,47.29175702429973 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark35(-47.46982222221108,-709.7201053231289 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark35(-47.560526022597635,-7.041018223569637 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark35(-47.57540710058153,-731.1810644716116 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark35(-47.71571139848319,0.0 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark35(-47.751619412001716,-709.3328889994527 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark35(-47.960807347850974,-43.019263152368595 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark35(-48.00305196018921,-61.08519028517596 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark35(-48.029744134374,-79.83324871728485 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark35(-48.23433136723641,17.36283085006866 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark35(-48.29274657744591,-709.8474696194438 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark35(-48.38878696021994,-746.0000017468914 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark35(-48.460618082476394,-746.0 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark35(-48.523888909072795,-746.0 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark35(-48.56589476674226,-709.329208358519 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark35(-48.684505267849374,-746.0 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark35(-48.69731597128065,-797.8746483823346 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark35(-48.708401666932616,-721.4003855148048 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark35(-48.71954710312076,17.75006548916729 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark35(-48.72932503025054,0.0 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark35(-48.754619080512356,100.0 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark35(-48.772065838129514,-715.6298399573138 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark35(-48.773714658824716,100.0 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark35(-48.785503824223035,-765.8855610281157 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark35(-4.887746298457344,-34.38899771919819 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark35(-49.21951193399756,-40.19140625 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark35(-4.924179153395048,0.0 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark35(-49.29945100859999,-748.1914161205752 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark35(-49.452396662141126,-746.0 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark35(-49.50888282962613,0.0 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark35(-49.73859812469209,-40.19140625 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark35(-49.76288968621557,0.0 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark35(-49.7721256609629,-709.6603284969236 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark35(-49.77288826315646,-709.4600550705261 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark35(-49.80394597176815,100.0 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark35(-49.81128183697179,100.0 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark35(-49.81186898681688,-742.4466940416221 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark35(-49.81505744952494,-743.9557233333425 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark35(-49.84822603774181,0.0 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark35(-49.895166717762315,-2.151449760878265 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark35(-49.944190596714,-709.2358439820856 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark35(-49.94737193954451,0.0 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark35(-50.023645644942945,748.5253390275747 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark35(-50.04093448919444,-709.1323712020036 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark35(-50.082728637374224,15.806583486347819 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark35(-50.09140254814422,-709.8411411800063 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark35(-50.137954858617896,711.2317855079609 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark35(-50.14475404341467,-709.0421435511641 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark35(-50.15479413025747,100.0 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark35(-50.25122324091718,9.012974911937093 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark35(-5.034989626385695,13.512568821094987 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark35(-5.133891584187026,-13.833060044351342 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark35(53.103333149272174,44.327728760479545 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark35(-53.502871706552014,-709.8162612927653 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark35(-53.64202243577771,791.433618682417 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark35(-53.64811858238285,-95.36263542396262 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark35(-53.765343492701675,76.15682963437544 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark35(-53.828888210113135,-758.2850630274507 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark35(-53.882132669494176,23.166109979302462 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark35(-53.931286225180045,-709.8225145999526 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark35(-53.9808363553868,-709.8238325390839 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark35(-54.22309726539733,0.0 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark35(54.2257836336546,0 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark35(-54.283472608796735,-709.505121994956 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark35(-54.29540852823283,0.0 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark35(-54.34112780486269,-745.5804534038546 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark35(-54.44759681828357,-714.9077001491185 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark35(-54.51610329903455,-746.0 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark35(-54.601371371331,-40.19140624999999 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark35(-54.736690837734955,-711.6391378771148 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark35(-54.787651900517446,41.564560743381975 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark35(-54.974142165312266,17.78080600604271 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark35(-54.974142165312315,-26.40864507811219 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark35(-54.97414216531233,-740.8516157282186 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark35(-54.975241597182574,-765.77436967933 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark35(-54.97935488139626,100.0 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark35(-54.98160071033043,0.0 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark35(-54.981600710330476,71.71542125940182 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark35(-54.98160071033062,-738.1394444094914 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark35(-55.01119950474658,94.05876654046718 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark35(-55.04394428556195,-714.3841799264117 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark35(-55.06304676684479,-40.015233861822715 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark35(-55.08644468756688,0.0 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark35(-55.12170287607459,-55.903903974469074 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark35(-55.1400700492362,-72.33802110162482 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark35(-55.160394684638035,61.56891344446891 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark35(-55.23757799866348,-744.084667481451 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark35(-55.27859130013164,-728.5105016523049 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark35(-55.299383781268446,0.0 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark35(-55.30858981804285,-73.61282410606216 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark35(-55.32234314753043,-764.6985124327855 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark35(-55.33559636324706,0.0 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark35(-55.357011020402524,64.87633614424041 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark35(-55.358499296533616,-710.3437856296621 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark35(-55.37468604546397,-18.57414282293354 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark35(-5.537533572872462,-709.3257118158397 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark35(-55.40536462132268,0.0 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark35(-55.4061748496347,0 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark35(-55.40703720422948,75.52940759846717 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark35(-55.41078898373859,-28.975351604356874 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark35(-55.43241243835388,-720.1048704141823 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark35(-55.523627539204256,-724.7614963822392 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark35(-55.538185982543936,-745.9971210524365 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark35(-55.577837312060055,-709.6801633351029 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark35(-55.69350325463054,-83.47623005568161 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark35(-55.81639181213747,-709.5443868847253 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark35(-55.99383065258421,-740.622241773826 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark35(-56.01729038633481,-746.0 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark35(-56.062748552845484,-709.6199385851684 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark35(-56.064743119289176,-709.9970604418426 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark35(-56.089805992823074,0 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark35(-56.14133273581964,0.0 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark35(-56.190991236311014,0 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark35(-56.19858533667175,-714.85640835259 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark35(-56.27132978096731,92.31647340825201 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark35(-56.277144803021926,-714.4547230935439 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark35(-56.28371393165916,-745.9999491147931 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark35(-56.28497218439814,0.0 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark35(-56.32469921960119,-56.83504360997183 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark35(-56.32795313207855,17.253854262771043 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark35(-56.35125972465414,-709.9727862334078 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark35(-56.46383103059897,-1.494140625 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark35(-56.47893029829283,-717.818523921276 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark35(-56.51374274800845,0.0 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark35(-56.548580865895,-714.9882652733718 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark35(-57.807254824613196,0 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark35(-59.79022766444818,-715.4060646928185 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark35(-59.87196832342266,-746.1914062523922 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark35(-60.04256048225929,-10.706094660242954 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark35(-60.06386598370283,-746.0 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark35(-60.11126227414536,-739.7072756000548 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark35(-60.314977779949785,759.0992279922738 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark35(-60.349880396776044,0.0 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark35(-60.38911533697369,-746.0 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark35(-60.41964607551067,-34.5815167545736 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark35(-60.44231339449257,-80.57797040402448 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark35(-60.44959419583809,-709.783408847662 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark35(-60.49917279205542,-709.019039583386 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark35(-60.51915333937687,-709.0388441113339 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark35(-60.65665765793493,-9.195381402439466 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark35(-60.71869986901339,74.82380251826143 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark35(-60.816916470680795,-25.35684268391624 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark35(-60.89047422353686,-746.0 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark35(-6.093365388550168,-709.1884742856182 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark35(-60.940568647138264,-37.1493064979187 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark35(-6.095291269495178,0 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark35(-61.06453543141126,-709.5985894652745 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark35(-61.17494031123976,-746.0 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark35(-61.18057568158846,0.0 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark35(-61.2551444852435,-709.936530675297 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark35(-61.25732747249183,-709.0895688064903 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark35(-61.25732747249193,0.0 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark35(-61.25889994070022,-745.9999999923895 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark35(-61.26179216141615,0.0 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark35(-61.30525270902707,-709.1480355298161 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark35(-61.34438347777886,0 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark35(-61.38243174046123,-709.1611623777798 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark35(-61.531838121724135,19.961108864105086 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark35(-61.575945197678905,18.297313906385938 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark35(-6.166673468239708,-746.0 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark35(-62.27713480523109,61.37338242296471 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark35(-62.46050805887076,58.52248875075654 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark35(-62.5576858362836,-746.0 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark35(-62.68219118676019,0.0 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark35(-62.69906429620335,-709.6899997418021 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark35(-62.79523186193175,-68.48007108383698 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark35(6.283185307409766,0 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark35(6.283190580643689,0 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark35(6.283200565978779,0 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark35(6.283382485694053,0 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark35(6.2927559755869,40.23028765728483 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark35(64.15898876194498,-78.51163139654918 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark35(65.52447478059571,0 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark35(-65.98472226169687,-711.0981968797632 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark35(-66.10781024476026,726.5153772828537 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark35(-66.12717315748766,-746.0 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark35(-66.28132557740082,-1.494140625 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark35(-66.31936514793959,-746.0 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark35(-66.34211924303321,-745.7124386187187 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark35(-66.65358577921191,0.0 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark35(-66.67138758946209,-55.72664279559232 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark35(-66.68643235340869,-746.0 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark35(-66.83837149776694,90.62209722010414 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark35(-66.84428754783278,0.0 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark35(-66.84987715041245,88.2256816691407 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark35(-67.13636982369238,-746.0 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark35(-67.19261778062557,-746.0 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark35(-67.2463508029416,-709.8599679761347 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark35(-67.27190483304564,-40.191406249999964 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark35(-67.28521040361781,-717.9154831166246 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark35(-67.40535446881447,-746.0 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark35(-67.68585570250806,-709.3448240170557 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark35(-67.81877212178719,56.70431472450454 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark35(-67.82662242175026,-741.5658624025396 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark35(-67.87595059777178,30.28804413015922 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark35(-67.94367190108937,-89.34370402008642 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark35(-67.94953603639019,0 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark35(-68.15618406450882,-745.9999999998942 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark35(-68.23045471834041,2.3128091973147207 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark35(-68.91771004631275,-709.6208780902582 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark35(-68.92001746206205,-743.042073253979 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark35(-68.94339319172151,0 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark35(69.30473557480147,54.276201155931545 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark35(-71.2067062094877,0 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark35(-72.27187983265694,-746.0 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark35(-72.36572597374386,-709.1364501245762 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark35(-72.39778762674322,-19.167318409616982 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark35(-72.40737535045409,-715.9349938325751 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark35(-72.5422324067452,-746.0 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark35(-72.74998358495174,-99.25268049637073 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark35(-72.75423227209214,-712.4085953413539 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark35(-72.7612471076049,-709.5666192894108 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark35(-72.76416564120817,-745.2806153621322 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark35(-72.81383183380099,0.0 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark35(-72.82550755986236,-709.0012055535093 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark35(-72.87935947074274,-746.0 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark35(-72.88507751326057,-751.991574921093 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark35(-72.92077764679172,-746.0 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark35(-72.94084374992573,-24.304688014289027 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark35(-73.2547181956189,72.01789979204699 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark35(-73.28710787608284,0.0 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark35(-73.3029738176617,-729.4990518157517 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark35(-73.4481670437891,-746.0000022805258 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark35(-73.47653624740747,87.74599141925282 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark35(-73.57002530321468,-8.89167992296143 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark35(-73.73772554529253,-709.8414326418125 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark35(-73.78783943736487,0.0 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark35(-73.81313087772469,-709.0101248246098 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark35(-73.82549238622369,-779.4749188808142 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark35(-73.88878618633494,-709.0917904718526 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark35(-74.18893121279066,0.0 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark35(-74.19459071900332,0.3799793237445641 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark35(-74.21053960848504,0.0 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark35(-74.3469017768443,-48.01560181106805 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark35(-74.50626013674788,-82.98193123476214 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark35(-74.98236762047956,-1.494140625 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark35(-75.0385865790223,0.0 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark35(-75.06038074679807,-746.2420158059654 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark35(-75.08733961995435,-739.14193789575 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark35(-75.33629273887954,-40.19140624999994 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark35(-75.33760634240289,-68.05824374641756 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark35(-76.59321965857552,70.74245830543308 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark35(-7.846477861618922,0 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark35(7.853981633974483,0.0 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark35(7.853981633974483,-100.0 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark35(7.853981633974853,-709.7070759599163 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark35(7.853981635677923,-745.9966954438556 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark35(7.854866352289584,739.9419172148425 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark35(-78.55915293436924,-100.0 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark35(-78.5704279877411,-746.0 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark35(-78.8025812077074,-718.9445879595755 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark35(-78.81591859154287,-746.0 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark35(-78.94395799809197,63.88742295266192 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark35(-78.94738476564214,-745.9999999556181 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark35(-79.0264818837776,-713.0490690047722 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark35(-79.05484147705286,-709.1493688293447 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark35(-79.11336541112071,-45.69393494815288 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark35(-79.14622112302968,-729.8113658800081 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark35(-79.30607785320518,71.77800163433636 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark35(-79.34083746408966,-719.6441976682241 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark35(-79.79718788786624,67.6130068708365 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark35(-79.82489070909959,-746.0 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark35(-79.92566622053792,-709.7180077789351 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark35(-79.98044270275024,-709.161471007756 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark35(-80.06693296244889,-40.19140625 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark35(-80.10977557097745,-709.2816020131667 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark35(-80.11406746921972,-708.2017058526305 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark35(-80.11434193904883,83.9261192401803 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark35(-80.11434193904887,-717.0967801125349 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark35(-80.17310351728177,-810.5971560536666 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark35(-80.29242982681652,28.672665646926845 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark35(-80.32946170648592,-709.6964413090491 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark35(-80.60916040675843,0 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark35(-80.83110998641503,-745.5331823098722 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark35(-81.08993614693438,-734.7923913824129 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark35(-81.1600999698842,-745.9967854065721 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark35(-81.40627867950668,0.0 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark35(-81.49139414355658,-726.5534894472148 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark35(-81.61966921948853,-74.42796729307537 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark35(-81.68082970536446,-736.1532914962506 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark35(-81.68552582615376,0 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark35(-83.28127126458298,71.17334964136873 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark35(-83.75259874760903,-74.42959870209916 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark35(-8.375426580629906,0 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark35(-83.96696057965458,-17.11091628898052 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark35(-84.90183253481044,-88.30564267542205 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark35(-84.94522603376295,-84.10692335187437 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark35(-84.96164793759723,-9.659208013605266 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark35(-85.07010904504726,0 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark35(-85.29787884466849,-709.8000893603863 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark35(-85.30182440061513,-90.22289995323942 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark35(-85.34968292995649,-715.0356882439089 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark35(-85.417796459603,0.0 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark35(-85.56832092766975,-745.9999698237845 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark35(-85.7357773816299,88.39357835540787 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark35(-85.84075023769792,0.0 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark35(-85.85312740802142,-709.716300286998 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark35(-86.00348588545124,-29.091284244767053 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark35(-86.05666682101914,50.79304870096692 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark35(-86.10658029984285,-746.0 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark35(-86.14710606779462,-40.19140625 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark35(-86.39248127351861,0.0 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark35(-86.57094020693101,0.0 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark35(-86.7037660643239,0.0 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark35(-87.12620158766485,-746.1914062998148 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark35(-87.17172992249552,0.0 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark35(-87.22664252438015,8.881784197001252E-16 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark35(-87.27299221943846,1.314748431353479 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark35(-87.50881297919159,-41.84193324306753 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark35(-87.60748600753139,-709.0260836502197 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark35(-87.83401326153043,-100.0 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark35(-87.91918281295528,-89.75843522414606 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark35(8.853981634092012,-711.2345034626914 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark35(-89.64477983962729,0 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark35(-90.39238037829946,0 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark35(-91.14412142698396,-709.9999987315446 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark35(-91.31224992665328,44.63704871245474 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark35(-91.37605476643897,0.0 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark35(-91.38341832291854,78.92779420989174 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark35(-91.63661360581004,-709.8679414790727 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark35(-91.77794705224613,-709.2421413903533 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark35(-9.17907517611367,-74.62163436385907 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark35(-91.79077444948054,-15.51591470824141 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark35(-91.81728334198253,86.20620338701715 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark35(-91.83075020632279,-27.301407332127454 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark35(-91.92661732196541,775.1587698066849 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark35(-91.96828489570224,-759.8886272827367 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark35(-92.02667476145653,0.0 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark35(-92.11943806634714,85.22901305135557 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark35(-92.17531850824494,-746.0 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark35(-92.18445928800149,6.257183910096487 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark35(-92.19678775553692,-745.0836906999192 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark35(-92.23607479359681,-723.2060134856747 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark35(-92.23646891305857,0 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark35(-92.29971439077747,74.60310215783238 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark35(-92.45193341064208,-48.58729872603409 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark35(-92.50716193201104,-49.538114582821976 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark35(-92.52133711953343,18.649571381262575 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark35(-92.54366178952408,0.0 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark35(-92.67351101739335,-0.7788811791217471 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark35(-92.680712553408,-12.570954409740477 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark35(-92.94183151597633,97.87874405982896 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark35(-93.06012544479817,0 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark35(-93.12497542833825,22.39685640255628 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark35(-93.4007808555247,-709.4448611314428 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark35(-93.66154769140556,71.9219856021947 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark35(-94.0877600675505,-726.2904596094702 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark35(-94.12111575417718,-729.1714098797454 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark35(-94.72375740622554,0 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark35(-9.576202878806065,0.0 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark35(-9.68157178930646,-15.492357291929082 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark35(-97.3893722613177,0 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark35(-97.43897920051677,-40.073823858243436 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark35(-97.53425921051004,-1.4678641633844343 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark35(-97.54176446519311,79.38113183535913 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark35(-97.67494791957623,-746.0000226775948 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark35(-97.75017040885166,-77.03156121791383 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark35(-9.775344869155106,-4.4259034825979455 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark35(-9.781533662845376,0.0 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark35(-97.87194524800195,0.0 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark35(-97.97649454135416,0.0 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark35(-98.10233917449199,0.0 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark35(-98.1538558176138,0 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark35(-98.19855489070626,0.0 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark35(-98.2645580397904,0 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark35(-98.29041072822784,-709.7857546609271 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark35(-98.36575182373983,0.0 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark35(-98.39253433548552,-709.1678448847775 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark35(-98.44475452310026,-746.0 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark35(-98.5081856689473,-746.0 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark35(-98.59154047296401,-709.4041011407037 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark35(-98.60779801332052,-40.19140625 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark35(-98.85427347765628,0.0 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark35(-98.95734402737668,20.779084365351657 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark35(-98.95756536074975,-739.8859256443793 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark35(-98.95882969707898,-7.246979400653018 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark35(-98.96279842871955,-882.397010283751 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark35(-99.00287732987869,-709.2551103567279 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark35(-99.17351870033235,-40.19140625 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark35(-99.46248454903524,-76.76389298082816 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark35(-99.48722561082825,-726.114006800243 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark35(-9.960757180993895,-709.7692950679951 ) ;
  }
}
