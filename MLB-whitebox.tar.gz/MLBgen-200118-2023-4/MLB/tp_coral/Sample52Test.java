import org.junit.Test;

public class Sample52Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark52(0.0030084919517454622,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark52(0.013454046533146021,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948946,-1.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948948,1.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948948,-54.139393452303004 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-0.05035656477516308 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-0.06136283248058089 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,0.06255252523144286 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-0.07926584805584902 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-0.21953725056911821 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,0.28258196958007015 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-0.448261948132986 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,0.4947867072873765 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-0.5625881889402689 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,0.7100842400757008 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-0.7799705605775804 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,0.7873424365931196 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,0.8242530088150231 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-0.8655677282614127 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-0.8858267272392927 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,0.93361515253738 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,0.9366278653240405 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-0.9651440462071766 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-0.9809686433587279 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,0.9818093206771485 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,0.983751508800647 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,0.9857019696472071 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,0.9956741203992755 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,0.9999999999999999 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,1.0000000000000002 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-1.0000000000000004 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-1.0803268338473126E-16 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-1.196909393925218E-15 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-15.459517842982379 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,1.893665045283333E-17 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-1.9913648889043514E-59 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,22.70047781734842 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,2.2957621927301213E-16 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-2356.2910210829245 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,27.958378957812027 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,28.689033974998218 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,31.51582798091269 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-31.64010692682026 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,35.727734197445784 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-40.63799882061891 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-44.03015903599445 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-44.52263485318652 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,4.6096394957981184E-17 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-4.67822614546917E-9 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,4.727071454088533E-15 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,5.647553857304708 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,61.447027903414416 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-61.944731056763445 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-67.17293610126617 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-67.40946199768476 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,67.65323573201887 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,68.1964907396441 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-6.897066788371246 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,69.44135321639692 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-76.59531868558994 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,8.027140971480042E-17 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-88.30353862353215 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,8.881784197001252E-16 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,94.58495611189917 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,94.80890671110268 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,99.13675889520249 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-9.957036674364282 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948968,1.0 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948968,-2290.4772408051135 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.570796326794897,0.9578922411836388 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948974,0.999999999999987 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948983,1.0 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948983,2369.5045169894142 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948983,85.55031845144994 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948986,-0.9180620698827892 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark52(0.021557033719224687,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark52(0.021925253072312013,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-3.1416172522385897,0 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark52(0.04281801285058531,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark52(0.0777669829435585,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark52(0.0904539319511839,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark52(0.10460278563119102,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark52(0,1.0483041589700548,0 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark52(0,-11.95062281968167,0 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark52(0.12877110242565776,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark52(0.13361231473893298,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark52(0.14089808373240942,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark52(0.14583074742058955,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark52(0,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark52(0,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark52(0,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark52(0,-1.570796326794897,0 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark52(0,-1.570796326795009,0 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark52(0,-17.6745381909015,0 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark52(0.18294693315477417,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark52(0,-1.9721522630525295E-31,0 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark52(0,-20.96135908089805,0 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark52(0.2182059740008384,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark52(0,2.465190328815662E-32,0 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark52(0,-2623.859790152086,0 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark52(0,-2723.1718891535697,0 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark52(0,-33.19647478095679,0 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark52(0,-33.42717246546596,0 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark52(0.3508280056606381,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark52(0,38.01568727693433,0 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark52(0.39229548659540386,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark52(-0.4198596761561647,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark52(-0.4502581950793715,-1.5707963267948948,-1.0 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark52(0.46848953455021625,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark52(0,-4.930380657631324E-32,0 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark52(0,51.811145547480976,0 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark52(0.5182408298930111,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark52(0,52.75229603464581,0 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark52(0.5445354399702467,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark52(0,-5.632814580440865,0 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark52(0.5632972056302634,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark52(0,-57.259507656147576,0 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark52(0.5886010503608645,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark52(0,-59.569732974725476,0 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark52(0.7518935579317088,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark52(0.7550264430087426,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark52(0.7739729457530236,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark52(0,-7.770656579368534,0 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark52(0.7921998145996774,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark52(0,8.68714422840064,0 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark52(0,-88.98342501064215,0 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark52(0.9176792741975888,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark52(0.9317862102428502,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark52(0.9544930410722259,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark52(0.9884134187860667,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-1.5707963267948863,0.21464065367152366 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-1.5707963267948895,100.0 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.570796326794893,0 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-1.5707963267948966,0.0025047802648335976 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-1.5707963267948966,0.5066909547091918 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-1.5707963267948966,0.9999999999959824 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-1.5707963267948966,-0.9999999999999627 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-1.5707963267948966,-0.9999999999999748 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-1.5707963267948966,0.9999999999999939 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-1.5707963267948966,1693.1092208444434 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-1.5707963267948966,-1.9467177638862437E-208 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-1.5707963267948966,-67.21849851250886 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-1.5707963267948974,0.0 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-1.570796326794898,0.0 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.5707963267949019,0 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark52(10.021828459214527,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark52(10.021892584351207,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark52(10.053911017764726,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark52(10.0779093297581,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark52(10.10581668418044,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark52(10.111596579951211,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark52(10.151978163536285,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark52(10.178652021665329,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark52(-10.189884625672954,-1.5707963267948966,-11.815088478115731 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark52(10.224163245199698,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark52(10.226945973583128,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark52(1.0272645213584184,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark52(10.494740709576007,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark52(10.509787935072406,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark52(1.0678885970786531,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark52(10.76539230399736,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark52(10.795268023543766,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark52(10.828207360243848,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark52(1.0854651414245637,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark52(11.003121181123307,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark52(1.1203915618510853,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark52(11.405437119705546,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark52(-11.54650253017174,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark52(11.584082430081398,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark52(11.675941454023146,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark52(11.832416463488764,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark52(11.881102240646157,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark52(11.94172526649181,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark52(12.005758347599496,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark52(12.08691478148242,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark52(12.307663682878733,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark52(12.344541285931172,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark52(12.386815992583106,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark52(12.423457999752081,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark52(12.45692078668145,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark52(-12.472806018818353,-1.5707963267948966,0.008648297948130212 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark52(12.479626169431285,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark52(12.579490419835652,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark52(12.617914509020594,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark52(12.845803958122524,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark52(12.911380994681082,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark52(12.942226745684877,91.13441846104385,42.30963349168141 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark52(-12.944718375317294,-1.5707963267948968,-1.0 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark52(12.9867320420745,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark52(12.994726196421269,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark52(13.01122678986016,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark52(13.028506270361685,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark52(13.039030501971855,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark52(13.066174410568154,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark52(13.283555638227583,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark52(13.30130902171247,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark52(13.388647852012994,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark52(13.443103322093396,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark52(-1.3552527156068805E-20,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark52(13.577425653069113,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark52(-13.604417919429377,-1.5707963267948966,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark52(13.613772104643829,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark52(13.736887094398469,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark52(13.881406327632513,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark52(13.927905649771262,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark52(13.971254750397113,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark52(13.98514009676856,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark52(14.00521284876335,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark52(14.02070949469984,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark52(-1.4105770828049294E-24,-1.5707963267948966,1.0245735559714186 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark52(1.4142083162761665,-1.5707963267949019,0 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark52(14.165659121144522,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark52(14.330016147780952,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark52(1.4336689589912623,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark52(1.4337571867094088,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark52(14.363652745508704,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark52(14.401940806640482,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark52(14.44180128029634,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark52(14.461844660589835,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark52(1.4506184272553475,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark52(1.4646223554589,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark52(14.694560110649716,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark52(14.73072252738876,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark52(1.4787811196835179,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark52(14.791493249086301,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark52(1.484836431380372,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark52(14.955756893276355,-1.570796326794897,0 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark52(15.10926899988776,-1.5707963267948877,0 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark52(15.155810874954227,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark52(15.209591385375477,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark52(15.243155841984201,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark52(15.31916292334212,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark52(15.352772260738789,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark52(15.392460077283303,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark52(1.5440120004881056E-15,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark52(-15.574263918736602,-1.5707963267948966,-20.044406888846215 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark52(-1.5588129211563021E-15,-1.5707963267948983,-0.9792335457924481 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark52(1.5612683698360995E-28,-1.5707963267948966,-0.06255252523465027 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark52(15.653248334519335,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark52(15.7295319179795,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark52(15.753131414942633,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark52(1.5805216627652696E-14,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark52(15.913659247283688,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark52(15.94417390596294,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark52(16.040423596467733,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark52(16.097239989737517,-1.5707963267949019,0 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark52(16.16518840987753,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark52(16.193298990430183,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark52(-16.196147737011103,82.60720524871104,90.26695773836883 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark52(16.233551637531235,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark52(16.248287753462492,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark52(16.259814267005076,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark52(16.295264459108743,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark52(16.502154683806978,-1.5707963267949019,0 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark52(16.563647661001696,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark52(16.638668744689546,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark52(16.759375853696042,66.96806902223616,-94.91437391312336 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark52(16.85395228764777,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark52(16.867880641417557,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark52(16.887029346634325,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark52(-16.996215990827302,-1.5707963267948948,-0.058088858337730184 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark52(17.047732318725252,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark52(17.216144726949366,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark52(-17.235593807464394,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark52(17.33604748139868,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark52(17.372515269356068,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark52(17.483594520200782,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark52(17.517900539916177,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark52(17.557066656514763,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark52(17.602753121076205,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark52(17.63533807383603,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark52(1.7763568394002505E-15,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark52(1.7763568394002505E-15,-1.5707963267948966,-0.04650923237552677 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark52(1.7763568394002505E-15,-1.5707963267948966,-0.22068854992174602 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark52(17.764993690445426,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark52(17.789695764792995,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark52(17.80310607436505,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark52(17.81968510333482,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark52(17.985256464342598,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark52(18.03953881695743,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark52(18.100634592669095,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark52(18.14307185727941,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark52(1.8145638524247858,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark52(18.219667707288266,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark52(18.23895525197706,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark52(-18.24685450613265,-1.5707963267948966,71.90116034146429 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark52(18.50138137188701,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark52(18.530423843622213,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark52(18.589223126760118,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark52(18.68650511811272,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark52(-18.732784679554882,-1.5707963267948966,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark52(18.745493566838604,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark52(-18.75651431081831,-1.5707963267948966,53.76673810906031 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark52(18.776917239559168,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark52(1.8856130219169813,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark52(18.885834965716853,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark52(18.92708160130016,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark52(-18.949591773049708,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark52(18.967728515284904,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark52(18.97295519198761,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark52(19.134107132312344,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark52(19.185802668189467,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark52(-19.259920358720017,-1.5707963267948966,0.014999722475157878 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark52(19.35535911581618,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark52(19.39397438360406,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark52(19.48005147379368,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark52(19.550509510998566,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark52(19.58387501183934,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark52(19.660964463353295,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark52(19.94273569718342,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark52(2.00552857100067,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark52(20.083334367897777,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark52(20.152835216627686,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark52(20.17463300362857,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark52(20.217725996276002,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark52(20.222898116845272,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark52(-20.289765239282033,-1.5707963267948948,1.0000000000303169 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark52(20.376180533339394,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark52(20.428243321488704,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark52(20.528149044212583,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark52(2.075993619422519,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark52(20.804878678424643,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark52(20.821752494511234,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark52(-20.89252638679823,-1.570796326794897,69.13319453804058 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark52(-21.040710327764273,-1.5707963267948966,-57.49504928886597 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark52(21.17825855148267,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark52(21.199080652400767,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark52(2.1269813617804774,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark52(21.321362161049123,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark52(21.32689005070118,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark52(21.369039521831326,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark52(-21.417915398809384,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark52(21.497429460613215,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark52(-21.519574923634057,-1.5707963267948966,-77.74917346388817 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark52(21.52574026179661,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark52(21.60560046369966,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark52(21.63148830690595,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark52(21.683415969737343,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark52(21.692016707464617,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark52(21.794592909784583,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark52(21.840327246101847,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark52(21.878149459952837,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark52(22.004867650639174,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark52(22.07093358002828,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark52(2.2145822818367886,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark52(2.2164923788999746,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark52(2.2448396653363005,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark52(22.449818688721898,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark52(-2.2544714871834857E-27,-1.5707963267948966,2269.539963733614 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark52(22.551860080946362,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark52(22.706614340130653,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark52(2.304557514842738,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark52(23.13149856027374,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark52(23.196702760974645,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark52(23.209571141360787,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark52(23.217934348286207,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark52(23.238185839530587,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark52(23.269442795560863,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark52(23.353436205458863,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark52(23.37295423049654,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark52(23.460636908070093,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark52(23.49817895870119,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark52(23.625635380669095,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark52(23.73520767221964,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark52(23.754207691104735,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark52(23.796334912066467,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark52(23.851055976882854,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark52(23.89061319868775,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark52(24.004167611807983,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark52(24.012652041879107,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark52(24.07971395221707,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark52(-24.19892322473794,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark52(24.281126992387588,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark52(24.284959446055645,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark52(24.324764037401415,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark52(24.507643810205934,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark52(24.509322910864427,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark52(24.537318795196967,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark52(24.616207002565176,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark52(24.70025850347119,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark52(2.4736466158610417,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark52(-24.76833715156307,-1.5707963267948966,54.734551272802626 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark52(-24.782894630736536,-1.5707963267948966,0.7905087453784163 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark52(24.816696743080342,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark52(24.82058509508809,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark52(24.883028040657123,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark52(24.96587200767941,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark52(24.98506276286858,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark52(-25.07422071672527,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark52(25.141135088312986,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark52(25.17166937587053,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark52(25.25472020317747,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark52(25.2690907460099,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark52(25.299086566873452,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark52(25.33884325244822,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark52(25.342141819262366,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark52(2.5361193613750572,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark52(-25.48856055656279,-1.5707963267948966,34.83861885669518 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark52(25.561525350537465,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark52(25.68365672062161,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark52(25.7281401826804,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark52(25.771738982775947,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark52(25.806005878758455,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark52(2.591761435948129,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark52(2.5966690393484555,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark52(25.98409147958256,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark52(2.6010107539477616,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark52(26.013643354160823,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark52(26.046077502015358,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark52(26.08891985866208,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark52(26.183307144621878,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark52(26.201451628768126,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark52(2.6246592730325915,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark52(26.30347684169989,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark52(2.6342295359099897,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark52(26.366054270707707,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark52(2.6383460539813934,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark52(26.450529954217213,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark52(26.47891104196868,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark52(26.64057600570017,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark52(26.659207781363634,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark52(2.6671639610399467,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark52(26.681057006711654,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark52(2.6690237181207266,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark52(-26.699430408143236,-1.5707963267948966,-0.036230739991126276 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark52(26.727728603718358,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark52(26.73189266021272,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark52(26.738944703770592,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark52(-26.93049177772764,-23.024265319397855,-60.79311886838368 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark52(-26.947826155103904,-1.5707963267948966,-0.49279754279905497 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark52(26.95507662486051,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark52(27.161960600278423,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark52(27.162724381151904,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark52(27.168361216586746,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark52(27.172659395921997,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark52(27.261890056302533,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark52(-27.298288468391934,-1.5707963267948966,-0.9999999999999999 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark52(27.3225903068047,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark52(27.34106114525278,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark52(2.7497436070528708E-17,-1.5707963267948966,1.000000000000156 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark52(27.519475369028896,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark52(27.532208350180063,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark52(27.62597890072516,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark52(27.62947723866212,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark52(27.67305372329604,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark52(27.683085758076402,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark52(27.776284725352834,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark52(27.787469521825614,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark52(27.799832750770562,-20.103159420447,71.39376927000873 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark52(27.86546725282382,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark52(27.895668364671806,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark52(27.946984617555255,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark52(-28.044849458925363,-1.5707963267948966,7.1746481373430634E-43 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark52(28.049430682722885,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark52(28.055379378615783,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark52(28.061384623885584,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark52(28.10072012233607,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark52(-28.161559963173772,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark52(28.166437860865436,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark52(28.281514235436653,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark52(-28.31414302711667,-1.5707963267948966,0.7575843229125687 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark52(28.31683001600372,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark52(28.335578954941976,-1.5707963267949019,0 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark52(2.8339160177111892E-24,-1.5707963267948966,0.04888864962235927 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark52(28.35878216993949,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark52(28.474098774029983,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark52(28.58759155106935,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark52(28.630560544656333,-1.5707963267949019,0 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark52(28.673379923460033,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark52(2.880198139332873,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark52(28.895168799477844,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark52(28.902326978098415,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark52(2.892282041578767,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark52(29.0153159986793,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark52(29.08357130364316,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark52(29.10234214382571,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark52(29.260925936746702,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark52(29.39867208969611,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark52(-29.6140827839022,-1.5707963267948966,0.7235511975402995 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark52(29.618527136942056,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark52(29.692724710669097,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark52(2.972769571003648,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark52(29.743906333202226,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark52(2.975974571831557,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark52(29.816871937697986,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark52(29.958490470158388,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark52(3.0067355325965455,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark52(30.08285982550561,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark52(30.10701437251456,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark52(30.10776412536555,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark52(30.170932054326755,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark52(30.253347108510894,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark52(30.268655619483326,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark52(30.268699695744523,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark52(3.030438398939367,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark52(3.035782069837806,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark52(30.414885120500458,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark52(-30.54484129630224,-1.5707963267948966,64.20766652506265 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark52(3.05761422600726,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark52(30.621154820935807,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark52(30.673456654476293,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark52(30.67993273255638,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark52(30.691809247358606,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark52(3.07066954083804,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark52(30.770604133769446,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark52(30.808745426679017,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark52(30.856158602207472,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark52(31.022608510373065,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark52(3.1026746541523096,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark52(31.048019925379947,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark52(31.086120589745754,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark52(31.094023745987734,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark52(3.1111337378030473,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark52(-31.37996569222759,-1.5707963267948966,38.120041829825574 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark52(31.48272460058098,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark52(31.68820511295946,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark52(31.69156925144591,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark52(31.71013262983752,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark52(-31.742330452454794,-1.5707963267948966,-72.76132151752972 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark52(-31.751420875478686,-1.5707963267948966,0.2984434269669869 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark52(31.862852770996227,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark52(31.89717738070201,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark52(31.937904255145735,-1.5707963267949,0 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark52(-31.983710563786097,-1.5707963267948966,-0.04243018273541749 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark52(-32.095837621454955,-1.5707963267948966,15.196418565518378 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark52(32.134307537639955,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark52(-3.2156309768656866,-1.5707963267948966,-0.7110445066554353 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark52(32.242498334274664,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark52(-32.253186678945745,-1.5707963267948966,-56.696628987605145 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark52(32.26309969749222,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark52(32.30082904580627,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark52(3.235517320585643,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark52(32.440875399455955,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark52(32.49236991878,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark52(32.54265644367567,-1.5707963267948886,0 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark52(32.60503058383878,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark52(32.69401184879871,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark52(3.2796646824015765,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark52(32.824331169810506,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark52(32.83878081026187,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark52(32.8946111395953,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark52(32.98514416442512,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark52(32.98633459976597,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark52(33.02173365764759,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark52(33.03613874404647,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark52(-33.07544230229935,-1.5707963267948966,-25.5765213820582 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark52(33.16679162203309,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark52(-3.329876842294837,48.93029806008539,-29.206340379230895 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark52(33.40762434511538,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark52(33.460041009034704,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark52(33.544508909939395,-1.5707963267949072,0 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark52(3.3595117192182493,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark52(-33.719850185003175,-1.5707963267948966,0.6568269948321408 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark52(33.73406766492807,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark52(-33.735474522737384,-1.5707963267948983,0.4428431222291984 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark52(33.85688866535875,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark52(33.93320449839756,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark52(33.96693953310239,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark52(34.03052327729908,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark52(3.4045314468081327,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark52(34.17689675247235,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark52(3.423640278196678,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark52(34.269673917876844,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark52(3.443412790462542,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark52(34.50607936940534,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark52(34.642373997371934,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark52(3.4651462072157386,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark52(34.65809819681445,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark52(34.78534868494783,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark52(34.8710572081543,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark52(34.89528667350433,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark52(34.91448973458964,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark52(34.982304805090614,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark52(34.99717038517221,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark52(-35.06078124569389,-1.5707963267948966,-0.680618145394419 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark52(3.508612095778915,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark52(35.08799921106106,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark52(35.09033655500248,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark52(35.091701164340236,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark52(35.21098075756569,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark52(35.21552498388688,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark52(35.239700969857644,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark52(35.257920742268254,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark52(35.48946693531752,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark52(35.507282216996565,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark52(3.552713678800501E-15,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark52(3.552713678800501E-15,-1.5707963267948966,-64.59500559190893 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark52(3.5537276789876415,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark52(35.5602334444645,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark52(35.646855223604284,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark52(-35.69486407925866,-1.5707963267948983,1.0 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark52(35.818504156529144,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark52(35.877477268746915,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark52(35.91320553354997,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark52(35.92463152266211,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark52(35.95893804888797,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark52(3.5E-323,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark52(36.09771793566907,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark52(-3.610388751729659E-276,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark52(36.14972883314337,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark52(36.19894311241089,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark52(36.307632138371126,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark52(-3.633176489418732E-19,-1.5707963267948966,-1.0000000346864317 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark52(36.42350450165776,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark52(36.42771104905765,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark52(36.429731051172155,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark52(36.43815732707564,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark52(36.50227201464327,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark52(36.50796945495952,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark52(36.61901337159651,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark52(3.665174276929646,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark52(36.6604906400716,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark52(36.81743784202149,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark52(3.6880416600988974,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark52(36.89884249723783,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark52(36.993255089248024,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark52(37.04750667515188,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark52(37.13270487286951,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark52(37.198937845050196,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark52(37.21921598401519,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark52(37.32054735000176,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark52(37.44025209856142,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark52(37.48297550286202,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark52(3.753407135281148E-15,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark52(-37.57788017803498,-1.5707963267948966,95.04150862395781 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark52(37.610010394459465,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark52(37.612425040394854,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark52(37.68668102301419,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark52(37.79142099317225,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark52(37.90800570016941,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark52(37.91775931621199,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark52(37.94931041189472,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark52(38.023819498976366,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark52(38.1142880124733,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark52(38.14682850967533,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark52(38.15104188610373,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark52(38.2217947172625,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark52(38.28208996604247,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark52(38.500615478812946,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark52(-38.54720950161909,-1.5707963267948912,1.0 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark52(-38.54810072845038,-1.5707963267948966,0.958658600073663 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark52(38.642601174823845,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark52(38.807317283599176,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark52(38.83156556988502,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark52(38.90453844229668,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark52(3.894824050411046,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark52(38.967305355345054,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark52(3.918647809504005,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark52(-39.204671800225434,-1.5707963267948966,0.029212874966520197 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark52(39.22618984509009,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark52(39.23507418944379,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark52(3.9325843641073543,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark52(39.42883316681825,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark52(39.46392348575516,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark52(39.46921947421045,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark52(3.9535912430107114,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark52(39.69860769272514,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark52(3.971035050580611,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark52(39.73185715373296,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark52(39.76317194202902,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark52(39.76687006588524,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark52(39.78016697231988,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark52(-39.84373101762626,-1.5707963267948983,-0.44054416926489304 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark52(39.86110645187297,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark52(40.03319402439509,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark52(40.12153429438752,-1.570796326794897,0 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark52(4.0206303920458356E-17,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark52(40.258192146594716,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark52(40.27052276633637,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark52(40.27971099801973,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark52(40.4063817630381,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark52(-40.45154240679665,-1.5707963267948983,-75.16639886762948 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark52(40.456404078770156,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark52(40.46176717200498,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark52(40.46445380703406,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark52(40.62747011655605,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark52(40.680692103740114,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark52(40.821786467464165,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark52(40.905743586110084,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark52(40.912581272856016,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark52(40.9244967052463,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark52(40.945306753268966,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark52(40.997585135725984,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark52(4.0E-323,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark52(41.04873014342099,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark52(41.160546972408895,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark52(41.21305163819912,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark52(4.122141538791695,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark52(41.44282089549786,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark52(41.52084591340099,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark52(41.548122544351514,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark52(41.721834206285486,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark52(41.809102553631504,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark52(41.837317402297145,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark52(41.83939869719812,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark52(42.111040165204315,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark52(42.13158121332506,26.06336687923161,-64.14017482079541 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark52(-42.13338810997649,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark52(42.32049928672505,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark52(42.352443155790226,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark52(42.37882824341105,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark52(4.244627698354879,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark52(42.77193963637821,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark52(42.80439882756717,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark52(42.85203232504335,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark52(42.87560840104965,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark52(42.885749749540494,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark52(42.88908048084925,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark52(42.90374321866953,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark52(42.93840177378114,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark52(43.06130113765259,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark52(43.062410783922566,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark52(-43.28001427914312,-1.5707963267948966,11.781870022446924 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark52(43.334397659907886,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark52(4.3368086899420177E-19,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark52(43.44185047837834,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark52(43.44599085467496,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark52(43.47243584736873,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark52(43.48862593644492,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark52(-43.53433059913848,-1.5707963267948966,-1.0000000000000036 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark52(43.7181554113219,96.15633694669009,-7.363053974181838 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark52(4.376843371299667,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark52(43.939612537551625,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark52(44.17599646524374,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark52(44.20093179617831,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark52(44.230998208880976,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark52(44.241985855611404,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark52(-4.440892098500626E-16,-1.5707963267948948,1.0 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark52(4.440892098500626E-16,-1.5707963267948968,-1.0 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark52(44.42223840121197,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark52(4.446075854277231,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark52(44.465310344534736,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark52(44.48206128684886,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark52(44.526573377337385,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark52(-44.69516865636994,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark52(44.711485075268314,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark52(44.715424439534104,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark52(44.84528816780866,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark52(44.86447073375399,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark52(44.893836710409204,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark52(44.98255604277438,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark52(45.160655242550135,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark52(45.2008514133135,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark52(45.217134256315475,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark52(-45.233061959873055,-1.5707963267948966,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark52(45.28693664079964,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark52(45.34363977226941,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark52(45.363188745934295,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark52(45.388549317138555,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark52(-45.46858126912625,-1.5707963267948966,50.838352768384006 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark52(45.51626087703458,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark52(45.59557230406794,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark52(45.5999854463584,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark52(45.81029094210178,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark52(45.86574842493127,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark52(46.05353290640949,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark52(46.123838435754436,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark52(46.13108511690726,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark52(46.23449816071223,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark52(46.2621269255004,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark52(-46.305549936777254,-1.5707963267948966,-0.7613335508106573 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark52(46.3060522173507,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark52(46.397135519998756,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark52(-46.4277121173459,-1.5707963267948966,0.6774849729923883 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark52(46.498748865752205,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark52(46.60761696547527,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark52(4.677132181241524,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark52(46.78777431092288,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark52(4.680246146942858,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark52(46.8413230969806,-1.5707963267949,0 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark52(46.85007102666198,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark52(46.89094504726623,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark52(4.689178102836024,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark52(-46.957812536579304,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark52(46.97009351144872,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark52(47.02149849059543,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark52(47.079293173122885,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark52(47.08032649063125,94.70343126626034,11.596551367514579 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark52(4.722228643508849,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark52(47.24369404447936,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark52(47.25310910982083,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark52(47.31078603302987,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark52(47.343949272296726,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark52(47.38916982385527,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark52(47.49650241851185,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark52(47.56281639537998,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark52(47.69776271309526,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark52(47.73024989549455,-1.570796326794897,0 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark52(47.76060402770662,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark52(47.78672326066772,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark52(47.810647986609574,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark52(4.787225917324768,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark52(47.915053272551205,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark52(47.98560512070412,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark52(-47.994687513262576,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark52(-48.15374702824359,-1.570796326794897,40.61189134819144 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark52(-48.30675970079194,-1.5707963267948966,-0.9999999999999993 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark52(4.8438946381807995,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark52(48.46800702591098,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark52(48.52308274202605,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark52(48.6181147906895,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark52(48.73135435114301,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark52(48.7619853902633,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark52(48.78256482726642,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark52(48.807986414750275,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark52(-48.81330065302245,-1.5707963267948966,-0.5132009876298369 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark52(48.87457159710995,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark52(4.908284116537871,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark52(49.11793520548301,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark52(49.15389745610129,-1.570796326794897,0 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark52(4.919211574969168,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark52(49.20908970677462,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark52(4.925444044211118E-16,-1.5707963267948983,-10.495237705423705 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark52(49.30460882104643,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark52(49.31525753451734,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark52(49.351344320362955,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark52(49.36007848030488,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark52(49.39896915151269,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark52(49.42749591838512,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark52(-49.472089190441935,-1.5707963267948966,6.1427581497165044E-238 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark52(49.50677465723777,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark52(-49.57113114715687,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark52(49.600810276659686,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark52(-49.64331204942204,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark52(49.74844188672018,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark52(49.767987081979456,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark52(49.800540788073036,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark52(4.984909847559324,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark52(49.92938610180602,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark52(49.98619868688886,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark52(50.14382077008132,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark52(50.29907362878655,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark52(50.304394596253374,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark52(50.3575683193402,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark52(50.376388596387415,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark52(50.403734045209006,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark52(5.0645516040541025,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark52(50.678701793752616,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark52(5.068637080151387,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark52(5.06E-321,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark52(50.70355821996324,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark52(50.75696710767531,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark52(50.78560162288246,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark52(51.03768063001712,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark52(51.2396381093999,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark52(51.36703293263038,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark52(5.149269992020902,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark52(51.51490868659321,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark52(-51.59890389806876,38.393891199829085,-6.2735741577801605 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark52(51.68069054305036,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark52(51.68593373375598,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark52(51.76385087313771,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark52(51.775419478609535,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark52(51.82067720047723,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark52(51.82629569682297,-1.5707963267949054,0 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark52(51.85694432016144,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark52(-5.190952457079834,-1.5707963267948966,-0.5972893350119131 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark52(-51.929071075460016,-1.5707963267948966,-2537.5749109836975 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark52(51.982816879335445,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark52(52.057867066447145,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark52(52.17050970996792,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark52(52.263917306444036,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark52(52.287386444149575,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark52(52.292564573754156,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark52(52.31126546109515,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark52(52.33526803343926,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark52(-52.43571581836544,-1.5707963267948966,1.0358216782587806 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark52(52.47703968219558,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark52(5.247795505837956,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark52(52.51985575883958,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark52(-5.261787273843793E-23,-1.5707963267948966,-0.36211618281423796 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark52(5.263277636896967,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark52(52.649627695612935,-1.570796326794897,0 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark52(52.66009215848203,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark52(52.66946261530447,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark52(52.72574528341898,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark52(52.747195121199326,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark52(53.05926142662797,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark52(53.12483169870137,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark52(53.14026587338438,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark52(53.27628717702019,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark52(53.36425861279561,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark52(53.43540008829396,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark52(53.50895464628769,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark52(53.74724671431807,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark52(53.79601656610733,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark52(53.819668388018925,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark52(5.383130712372051,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark52(53.868193245549975,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark52(53.878460512587736,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark52(53.88657548108679,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark52(53.948342813823984,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark52(53.96674011190628,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark52(54.04141182339984,-1.5707963267949019,0 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark52(-54.15669222482197,-1.5707963267948966,65.35613161775241 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark52(-54.1653830516201,-1.5707963267948966,0.09228972084890535 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark52(54.35301565374667,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark52(54.39856657529768,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark52(54.418528151588305,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark52(54.42353499267494,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark52(-54.49165554767379,-1.5707963267948966,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark52(54.54062100297705,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark52(5.456938966185822,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark52(54.670192194284624,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark52(5.467564975912168,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark52(5.47742173657597,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark52(54.95514564344785,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark52(55.084559436489116,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark52(55.0957107940633,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark52(55.11773497338237,-82.56862435801207,57.83508536900993 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark52(55.2348489286764,59.06220238020731,-28.005262370173867 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark52(5.5300285916399545,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark52(55.33996171926704,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark52(55.378681073760276,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark52(55.44666428979335,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark52(-55.46110429172718,-1.5707963267948972,-0.9999999999998367 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark52(55.47039513602337,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark52(-5.5479572981358825,-1.5707963267948966,-2448.5235797496302 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark52(55.512570893762934,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark52(55.53103469416868,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark52(55.58981297277746,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark52(55.64352451238213,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark52(55.69616288053735,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark52(-55.73269453931836,-1.5707963267948966,-6.49240868417624 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark52(55.73774891668925,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark52(55.76660043331925,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark52(55.77541778049921,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark52(55.79526890627644,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark52(55.973654067242784,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark52(56.02807296398719,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark52(56.24064234708976,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark52(56.273663994734136,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark52(5.631432075130888,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark52(56.36305344136529,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark52(5.639323221918056,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark52(56.40436259036723,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark52(5.641046714490618,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark52(56.450508721773296,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark52(56.49873427962345,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark52(5.655735894104367,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark52(56.597563999663045,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark52(56.73086737998506,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark52(56.745826661593824,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark52(56.881310330147684,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark52(56.98535409868728,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark52(56.996517547840014,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark52(57.00584437627512,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark52(-57.01584692821887,-1.5707963267948966,-1.0000000000000004 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark52(57.315826325692896,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark52(5.744340391752891,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark52(57.44702368720766,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark52(57.60705589275195,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark52(57.66139644891422,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark52(57.77047015528928,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark52(57.8083259488185,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark52(57.81591103298041,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark52(57.834110558096285,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark52(57.86893746121228,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark52(57.907293417858284,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark52(58.059489096265395,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark52(58.18592949151081,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark52(58.18949934205244,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark52(58.201082962303374,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark52(58.21294841179969,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark52(58.233785437305144,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark52(58.30077257759152,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark52(58.39263932532222,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark52(-58.39728057807327,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark52(58.42100530836947,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark52(58.45779481952823,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark52(5.846233092279763,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark52(58.465995684642884,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark52(58.58637450257014,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark52(58.60732945154433,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark52(58.61815147517059,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark52(58.63377501448909,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark52(58.64168038377173,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark52(58.69002522889871,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark52(58.97781145026618,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark52(58.99616662298896,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark52(59.00158635941449,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark52(59.04748974549082,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark52(59.109409232050616,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark52(59.131700571429214,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark52(59.17027183327427,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark52(59.321545098587166,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark52(59.36381958311098,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark52(59.39246510359618,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark52(59.47678141089297,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark52(59.52299744240157,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark52(59.52944488846417,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark52(59.54457330809264,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark52(59.61492754790163,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark52(59.699236083071696,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark52(59.71310902278083,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark52(5.9725456786349564,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark52(59.84076728599749,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark52(5.997077755602335,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark52(60.07458279465352,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark52(6.008955507932209,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark52(6.012430071995567,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark52(60.23878684433124,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark52(6.037633459681073,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark52(60.41620839577078,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark52(-60.429816889708405,-1.5707963267948966,-0.012640755160912176 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark52(60.45814883931658,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark52(60.45943700407622,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark52(60.49689458797221,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark52(60.587409003276974,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark52(60.597781581052054,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark52(60.6860057889551,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark52(60.75897530523566,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark52(-60.79492983542522,-1.5707963267948983,-53.14896079955696 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark52(60.87106624499306,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark52(60.94743479330472,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark52(61.00478296112752,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark52(61.06479342329857,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark52(61.11020182740793,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark52(61.123320696277666,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark52(61.174770303472314,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark52(61.25200044969616,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark52(61.34894987589058,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark52(61.36538932692785,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark52(61.37083119101216,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark52(6.1389849078633745,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark52(61.47016921362145,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark52(61.56655880536561,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark52(61.597664862114954,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark52(61.67955799165468,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark52(61.7810829158432,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark52(61.9017962194074,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark52(61.974488915695645,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark52(62.01673984613117,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark52(62.03137539889315,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark52(62.14436634534199,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark52(62.15006616936051,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark52(62.23908870916209,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark52(62.29437964812291,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark52(62.298004437500055,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark52(-62.409622777833846,-1.5707963267948966,-2.9358344067049253E-16 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark52(62.41354888738286,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark52(62.47730964808747,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark52(6.249098289731131,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark52(62.55256359621225,-1.570796326794893,0 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark52(62.800922769802256,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark52(62.94607133846967,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark52(63.00939431991033,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark52(-6.301641868177841E-16,-1.5707963267948966,-0.5711499076186053 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark52(63.05789667457097,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark52(6.309017802439485,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark52(63.11746944347003,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark52(63.13307475365838,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark52(63.16820181304769,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark52(63.221877412859286,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark52(63.29900629318215,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark52(-63.32934696175351,-1.5707963267948966,0.06255252524895755 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark52(63.35348171272679,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark52(63.57551775750777,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark52(63.63933730712549,-1.570796326794897,0 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark52(-63.65358140715862,-1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark52(63.90918031512895,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark52(-64.02504630827414,-1.5707963267948966,-33.03937511321228 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark52(64.12151621038386,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark52(64.16505396948085,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark52(6.443597055162115,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark52(64.49107186696804,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark52(64.49538790485798,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark52(64.51664045764163,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark52(64.5756737242466,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark52(-64.62560657357955,-1.5707963267948966,-0.06255252907762689 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark52(64.6797343018064,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark52(64.72730802910061,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark52(64.7340539928991,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark52(64.74735918698873,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark52(-64.75138789850263,-1.5707963267948966,1.0000000000000002 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark52(64.81538133486661,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark52(64.8685199592069,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark52(64.92333362558608,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark52(-64.92790937309977,-1.5707963267948966,-61.11449787407727 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark52(64.97267500215379,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark52(65.01738305957021,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark52(65.06463338522988,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark52(65.06512735432823,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark52(6.508986723175454,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark52(-65.0986900976012,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark52(65.1214783880176,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark52(65.1671520755011,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark52(65.2336011931653,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark52(-65.28463541887093,-1.5707963267948966,0.6331159637015453 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark52(65.34451032175983,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark52(65.50760448191494,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark52(-65.50907777233903,-1.5707963267948966,0.7865200327637385 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark52(6.551031074071801,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark52(65.51206355582424,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark52(65.57417151136367,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark52(65.62591636533531,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark52(65.63135116459169,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark52(65.66032585963987,-1.570796326794897,0 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark52(65.74787486005638,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark52(6.592971285693466,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark52(65.95483178141963,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark52(66.05909990008455,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark52(6.6063576069901035,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark52(66.06658385520527,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark52(66.185473802521,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark52(66.32226543173002,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark52(66.37788858718042,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark52(66.4446935311276,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark52(66.47468949704754,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark52(66.56299990984463,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark52(66.68411796766839,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark52(66.71368361506583,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark52(-66.73791870397154,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark52(66.81067459392949,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark52(66.86423854973468,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark52(-66.92125790402659,-1.5707963267949019,0.8193265648335046 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark52(6.692700187060414,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark52(67.05495106436813,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark52(67.08444060920533,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark52(67.10207547056771,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark52(67.10267398059219,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark52(6.720171121955817,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark52(67.2992801515951,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark52(67.43057111507304,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark52(67.54132167275375,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark52(67.62011131331329,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark52(67.62645802600306,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark52(67.64718162099444,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark52(-67.77434712439707,-1.5707963267948966,93.6750422245379 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark52(67.78838757932589,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark52(67.85145497559132,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark52(67.9505827135765,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark52(67.95831842878435,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark52(67.990894804329,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark52(68.0814066364614,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark52(68.0956626858997,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark52(68.18961932765492,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark52(68.20584634148972,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark52(68.2250575598975,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark52(68.28808469226216,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark52(68.33179474716582,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark52(68.41575512283971,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark52(68.43038141389675,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark52(68.4535931404723,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark52(-68.48907701847668,-1.5707963267948966,-0.30280061454062757 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark52(68.5483528384831,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark52(68.76932050720254,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark52(-6.884860897627197,-1.5707963267948966,-30.433845137103482 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark52(6.88938193856942,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark52(6.903224525820988,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark52(-69.10777988236754,-1.5707963267948966,0.058537291272832116 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark52(69.11598821129805,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark52(69.24381090365662,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark52(69.3919861377373,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark52(69.44788278701664,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark52(69.53158069507303,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark52(69.56219687502903,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark52(69.58125917962116,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark52(69.64110949408325,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark52(69.65370499407808,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark52(6.975358618193387,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark52(69.82754371369732,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark52(69.85093656426815,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark52(69.86087625042035,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark52(69.96117349331605,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark52(69.99688523652033,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark52(70.06941019863231,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark52(-70.08103776483378,-1.5707963267948966,-12.515655481195703 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark52(70.11316265637132,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark52(70.12119014590846,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark52(70.23835672159832,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark52(70.27664744445633,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark52(70.29320160548167,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark52(70.3192818376366,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark52(7.068817212548453,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark52(70.78314866459958,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark52(70.81117656682689,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark52(70.84497874596491,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark52(7.0855363399645865,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark52(70.92350671180374,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark52(7.098883510960782,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark52(-71.01603061050466,-1.5707963267948977,-0.3620920371369429 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark52(71.04537515611355,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark52(71.1167360703843,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark52(71.20963616863082,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark52(71.30135502096041,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark52(71.3051328194882,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark52(71.39508808063175,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark52(71.40670737167972,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark52(71.57106985972527,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark52(71.61596433277293,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark52(71.64977437167198,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark52(7.175755461381714,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark52(-71.77047154267501,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark52(71.92048475227807,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark52(72.1293391613217,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark52(72.21284143710434,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark52(7.221454410678776,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark52(7.237898523633475,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark52(72.66135215625292,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark52(72.66289571812061,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark52(72.75274484110273,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark52(73.20777902141617,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark52(73.24423645790102,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark52(73.29005662768509,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark52(73.42409937665029,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark52(-73.53821566341631,-1.5707963267948983,0.9999999999999964 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark52(7.355627029911744,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark52(73.73811305023546,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark52(7.377481932587557,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark52(7.3859558059379715,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark52(7.385989765666422E-127,-1.5707963267948966,3.5718355977571093E-102 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark52(73.8758728435586,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark52(73.97981951727934,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark52(74.03827065774274,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark52(-74.0646836977968,-76.35204158412516,0 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark52(7.424809548111796,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark52(74.28053733202493,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark52(74.45128827436591,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark52(74.6114700142069,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark52(74.65988039126238,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark52(7.4692040870322245,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark52(74.85084562906236,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark52(74.94778015274392,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark52(75.0244993416037,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark52(75.05085120269837,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark52(75.10050121371279,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark52(75.12929450054627,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark52(75.14317001391328,-1.570796326794893,0 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark52(75.23703841276665,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark52(75.33668894745577,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark52(75.40201796976534,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark52(75.42466438515319,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark52(75.50481543218444,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark52(75.58193631416657,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark52(75.6263522473425,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark52(75.67471817994664,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark52(75.77497158346532,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark52(75.80639405939405,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark52(75.92050887108485,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark52(75.92206127474945,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark52(-76.19964939336765,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark52(76.22883577983355,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark52(76.30656069469707,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark52(-76.38237583126656,-1.5707963267948966,2.1684043449710089E-19 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark52(76.41941459842973,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark52(76.46922198883499,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark52(76.53841548879419,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark52(76.66479372186379,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark52(76.73743666911972,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark52(7.690510332048493,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark52(76.95021471402714,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark52(77.24766030307578,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark52(77.32092708939305,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark52(77.42598110597521,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark52(77.4895915838311,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark52(77.60134556342274,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark52(77.63445965641475,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark52(77.63861163913015,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark52(77.75570278345305,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark52(77.76868557938172,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark52(77.84861578368799,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark52(77.89940330871829,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark52(77.95351133966324,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark52(78.0229071141284,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark52(78.03677011550593,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark52(78.10344835014396,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark52(7.81343102676416,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark52(78.15379217957404,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark52(78.22007795201523,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark52(78.38346069666704,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark52(78.41991311050717,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark52(78.43291788927309,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark52(-78.44042411541021,-1.5707963267948966,35.24675772404876 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark52(78.48715319165437,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark52(78.52383845274099,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark52(78.54246056931144,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark52(-78.56475964547732,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark52(78.80915151517337,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark52(-78.81360527355906,-1.5707963267948966,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark52(78.83139826873301,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark52(-7.888609052210118E-31,-1.5707963267948966,-9.833082866209754E-17 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark52(79.21174685811991,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark52(79.22014956423561,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark52(79.31867325852355,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark52(-79.39512864519989,-1.5707963267948966,-73.09484731189431 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark52(-79.45830218505719,-1.5707963267948948,83.98214445678862 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark52(79.58228626217854,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark52(79.61712424301113,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark52(79.63565943197311,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark52(79.69583949508309,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark52(79.71684889647841,-1.570796326794894,0 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark52(79.83705398649468,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark52(79.90136042072018,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark52(79.90485253193094,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark52(79.91255912455998,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark52(8.007716062641345,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark52(80.16414453113742,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark52(80.19397143192919,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark52(-80.28915625078383,52.21951305575655,27.093685167486314 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark52(80.30389791682134,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark52(-80.41718713852313,-1.5707963267948966,-1.0000000003711609 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark52(80.42907196420292,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark52(-80.44602121651822,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark52(-80.55525250994128,-1.570796326794905,1.0 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark52(80.5997779332944,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark52(80.78414274165206,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark52(-8.108787380538022E-17,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark52(8.109292057746046,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark52(81.15310628851466,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark52(81.16658354222906,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark52(81.3317233884748,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark52(8.14288988296947,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark52(8.14630780930841,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark52(8.156814958768507,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark52(81.59636833156782,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark52(-81.62510230596484,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark52(-81.81550361246661,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark52(8.197395392820368,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark52(8.200702406976006,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark52(82.00708601470438,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark52(82.04276291808821,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark52(82.1132356520988,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark52(82.11666614800139,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark52(82.14680048486815,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark52(82.15867619024075,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark52(-82.23816999185296,-1.5707963267948966,-1.96928866896666E-15 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark52(82.28862527657958,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark52(82.33587374123192,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark52(82.4415491514364,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark52(82.53184210981351,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark52(82.56047040418895,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark52(-82.67711637617579,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark52(82.75678173589137,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark52(82.86152776651073,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark52(82.86658219130605,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark52(8.30667745398592,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark52(83.07891691318935,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark52(83.09110683462131,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark52(83.26660650600823,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark52(-83.32192975893906,-1.5707963267948966,-6.082880131999261 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark52(83.36474674926956,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark52(83.48258577810094,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark52(83.54318859470354,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark52(83.6006074289848,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark52(83.6432899866676,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark52(83.66012111368333,-1.570796326794886,0 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark52(83.67116744212417,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark52(83.99901853196627,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark52(84.14917605609615,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark52(84.3907467815026,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark52(-84.47232953433358,-1.5707963267948966,-24.824492317996594 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark52(84.5150218855419,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark52(84.78261199954704,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark52(8.485794938672072,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark52(84.98876907240111,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark52(85.11622165124213,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark52(-85.23803915701693,-1.5707963267948966,-0.9999999999999978 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark52(85.2465761637589,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark52(85.26738436115257,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark52(-85.2906140636747,-1.5707963267948966,-0.9999999999999996 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark52(85.29085819979268,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark52(85.3845719928847,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark52(-8.551947786794665,-1.5707963267948966,74.17764772409673 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark52(85.52387166921855,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark52(85.85347835978617,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark52(85.96039763525673,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark52(86.05499807702586,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark52(86.15579483951419,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark52(8.625492412387038,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark52(86.26854912797741,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark52(86.32617331544229,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark52(86.3793925020002,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark52(86.39655672854128,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark52(86.52286032542631,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark52(86.53154579441221,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark52(8.656955162508275,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark52(86.6495112434643,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark52(86.68508659921825,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark52(-86.77691940169443,-1.5707963267948966,2420.4500007694987 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark52(86.79967049903945,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark52(86.92190912260821,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark52(87.01196424729395,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark52(87.06601489130429,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark52(87.0863930381519,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark52(-87.10349656640699,-1.5707963267948966,-81.87184955548739 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark52(87.12076002389928,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark52(87.20019549608637,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark52(87.25297947732886,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark52(87.25768105754891,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark52(87.43741637155433,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark52(87.59133484648194,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark52(87.59729245140288,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark52(87.83393453275443,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark52(87.88613543132405,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark52(8.79998732640135,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark52(88.00509561432236,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark52(88.09841400056774,-1.5707963267949019,0 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark52(88.15333793044101,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark52(8.818277829872663,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark52(88.23472918049798,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark52(88.24238334686157,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark52(8.829057782681783,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark52(88.33708724033758,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark52(88.54706850472914,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark52(-8.859419373306487,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark52(8.871996235162797,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark52(88.72311764852594,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark52(88.7238554232218,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark52(8.881784197001252E-16,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark52(8.88229125717993,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark52(88.83097439306053,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark52(-88.90463394858321,-1.5707963267948966,0.05290740256449993 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark52(88.91867390709635,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark52(8.898337074262557,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark52(89.02368472353442,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark52(89.28976505280778,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark52(89.35252658569723,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark52(89.45053421711035,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark52(8.96079418900627,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark52(8.96312092344095,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark52(89.64455390349369,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark52(-89.6854433271794,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark52(89.68591588008258,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark52(89.6949636423657,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark52(-89.71208721763067,-1.5707963267948966,-94.70223390984546 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark52(89.73568846466995,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark52(89.78862051518968,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark52(89.81341640253021,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark52(89.96813479626266,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark52(9.00347982113938,76.804005199111,0 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark52(90.12170626496668,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark52(90.17054036858494,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark52(90.23812836696064,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark52(90.3990120474258,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark52(90.43569028394919,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark52(9.05173727263158,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark52(-90.55809920782478,-1.5707963267948966,-0.024383100194543816 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark52(90.74023548843107,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark52(90.81674112964888,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark52(9.082686348257933,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark52(90.85741130591614,-1.5707963267948952,0 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark52(90.93454085276397,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark52(91.07813306855165,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark52(91.25715350277004,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark52(91.33742950131254,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark52(91.35728964403619,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark52(91.39052080575433,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark52(91.55306491750864,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark52(91.59163369854409,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark52(91.64452819792706,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark52(91.74597192941172,3.744670714056724,35.58784391394539 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark52(91.88830234017308,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark52(9.190758039776636,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark52(9.197542831664794,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark52(91.99089528252199,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark52(92.02243562725883,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark52(92.03585886279555,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark52(92.2837187260506,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark52(92.31086304304735,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark52(92.42770796995512,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark52(92.48799797744752,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark52(92.5095415183047,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark52(92.58422304652004,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark52(92.71225568273815,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark52(92.74311741340085,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark52(93.08534477610162,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark52(93.0870499673722,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark52(93.15260570125446,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark52(93.27998161778518,-1.570796326794897,0 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark52(93.39729713690954,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark52(93.48574927939373,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark52(93.50430489607099,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark52(93.56954689643125,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark52(-93.60428923208828,-1.5707963267948966,-0.4894228097917127 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark52(93.65459394249709,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark52(93.80369576886015,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark52(93.80734546090922,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark52(9.383865911343236,-86.93565039487392,32.62769644074268 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark52(93.88097883510973,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark52(93.91112993733692,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark52(94.0181817133647,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark52(94.1078429150769,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark52(94.19993650244253,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark52(9.4217155863432,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark52(94.25673330545673,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark52(94.26531079158056,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark52(94.2979271127156,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark52(94.42560777256213,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark52(94.42563250296794,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark52(94.435059649594,-1.570796326794897,0 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark52(94.5188797537297,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark52(94.55055916845438,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark52(94.57259727417818,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark52(9.458957396616881,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark52(94.60822427457015,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark52(94.68911188496233,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark52(9.470304575493273,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark52(94.71158612065757,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark52(9.48038505271853E-20,-1.5707963267948966,-1.0000000000000573 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark52(94.87532080296478,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark52(94.94212291065391,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark52(95.02886145827986,41.95249453817192,42.75261858283835 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark52(95.07904951339842,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark52(95.14128510012736,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark52(9.522608166783709,-1.570796326794897,0 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark52(95.26549630981135,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark52(95.28766228377621,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark52(95.31406287240462,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark52(95.34740119078644,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark52(95.42559849261784,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark52(-95.43595870149973,-1.5707963267948966,39.356843855999344 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark52(95.6703129924946,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark52(95.71119314551802,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark52(-9.58196544414376,-1.5707963267948966,17.203785581194253 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark52(96.00492462422913,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark52(96.2293022539505,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark52(9.630496797376995,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark52(9.645154713362487,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark52(96.4569025598507,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark52(96.45707465303887,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark52(96.63230473400539,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark52(96.72233813115423,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark52(9.67664558447047,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark52(96.79541150091643,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark52(96.81338103589137,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark52(97.00456677560919,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark52(97.03969757367946,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark52(97.06598093252609,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark52(9.707027148508018,-1.570796326794897,0 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark52(-97.07216486573567,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark52(97.07476262293355,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark52(97.10571134010814,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark52(97.17709884271284,4.421473917389733,95.07042640248562 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark52(97.28558497498295,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark52(97.45774633173085,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark52(97.49629842090874,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark52(97.57571002998448,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark52(97.5787326486188,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark52(-9.758020652699859,-1.5707963267948966,-0.6399777609923212 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark52(97.59912700072496,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark52(97.60011909447965,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark52(9.789889391379072,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark52(97.96139192252323,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark52(98.02675775882595,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark52(98.21456200801029,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark52(-98.25289092413708,-1.5707963267948966,1.0000000000000002 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark52(9.829957482710679,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark52(98.29967304848827,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark52(98.3787789594561,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark52(9.843812805369524,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark52(98.45921440474183,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark52(-9.860761315262648E-32,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark52(98.81955613015393,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark52(98.84701947277551,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark52(98.97466493926974,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark52(9.897658913781259,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark52(99.00683952353552,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark52(99.00816089783913,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark52(99.01539471217536,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark52(99.11912459622067,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark52(-99.16926436438072,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark52(-99.17897689716575,11.775316084975955,47.26148794120297 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark52(99.3076780980792,-1.5707963267949019,0 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark52(99.4879340671119,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark52(99.60861764793952,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark52(99.93610933334679,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark52(99.99999999999994,-1.5707963267948966,0 ) ;
  }
}
