import org.junit.Test;

public class Sample04Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark04(-10.931042046915678 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark04(11.309377868695591 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark04(-1.4701397534859915 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark04(-1.494140625 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark04(-18.272838412907902 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark04(-23.279693988899083 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark04(-34.00940847637004 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark04(-3.4167705350037494 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark04(-40.09687627877987 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark04(-40.19127446486492 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark04(-40.19140625 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark04(5.200724004309734 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark04(52.39025509319103 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark04(-59.74725716328879 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark04(-709.0077467096604 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark04(-709.2060498066342 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark04(-709.3446081979259 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark04(-709.3539648476253 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark04(-709.4672781156509 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark04(-709.6083595754739 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark04(-709.6874683077649 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark04(-709.7306123514871 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark04(-709.9170632994721 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark04(-709.9574668137949 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark04(-709.9960670946921 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark04(-709.9978671071311 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark04(-709.9992026605071 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark04(-711.4314297164723 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark04(-714.5047865974241 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark04(-715.0649212817963 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark04(-716.0274326384902 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark04(-720.4390404843202 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark04(-720.6218704700257 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark04(-722.3622340751532 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark04(-736.0787753353211 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark04(-745.302265668921 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark04(-745.8393992705957 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark04(-745.9999999953076 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark04(-745.9999999999999 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark04(-746.0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark04(-746.0000000000128 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark04(-746.0000000059116 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark04(-746.1914062500529 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark04(-748.1914062553415 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark04(75.23133778373412 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark04(-752.7622160925425 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark04(771.4125647265435 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark04(-84.89625374490456 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark04(90.45306696779605 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark04(-94.37712937774761 ) ;
  }
}
