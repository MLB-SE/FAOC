import org.junit.Test;

public class Sample62Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,-0.48627446281707876 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,-0.7788111393431763 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark62(0.14914453735932862,-1.734723475976807E-18,100.0,-100.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark62(0.944760749282893,32.34631162834327,31.401546537209356,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark62(100.0,1.0542197943230523E-81,-100.0,-70.38305204938546 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark62(100.0,1.0842021724855044E-19,-38.47983966598322,-92.60960419383495 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark62(100.0,-2.4074124304840448E-35,41.09927031214984,100.0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark62(100.0,27.30401404328427,37.88633530842388,89.41767873486039 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark62(100.0,3.0918615202968027,-27.713417079571983,76.34736088949201 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark62(100.0,4.276423536147513E-50,-86.09802919662066,71.22498881506303 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark62(100.0,-5.551115123125783E-17,63.04711428815973,-100.0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark62(10.39161528918661,3.0385816786431356E-64,-8.072027777182477,69.2226741139404 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark62(10.71295061773336,0.6931553139725577,-23.74454525933867,-9.130216859395674 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark62(1.148442662803585,70.45837242601225,70.4585043420455,1.1485745788368402 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark62(-16.7187300302231,18.318605818802624,-19.18195317061412,-11.989651513912294 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark62(17.90657564950333,-50.158862956907534,78.41242117783584,-0.3572546087335941 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark62(19.55150170442991,2.4768513015832063,-25.055605093846122,47.98873652977585 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark62(21.084217666848645,56.68168035860393,25.058467031206405,-61.38745767020728 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark62(2.167598227632096,-2.0278466481816255,2.312813415694578,16.54948618074292 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark62(24.172525074313597,-8.075964462861336,91.14382179942456,-17.580014794180187 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark62(27.628109609192023,0.0,0.5066538187703316,-92.91272788655974 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark62(27.768430351301433,3.0385816786431356E-64,-6.804282509117115,-100.0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark62(29.226656777642745,1.7763568394002505E-15,-53.32602241327788,-90.95995137602148 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark62(29.603671456888065,44.777236936210755,-47.162567276006314,-74.64400331381955 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark62(32.11195290246772,-34.45620407693963,-62.232253815711914,9.68779321373654 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark62(3.239339893373508,-5.4738221262688167E-48,33.90789276336615,-10.562753976555634 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark62(33.952020763376936,45.591840525862665,94.51443512701269,27.31485002390687 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark62(-35.74041446204225,95.42484117796974,16.25979917290725,98.57399294069629 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark62(36.00011114632904,7.74223247977648E-5,-6.293161059790258,-54.14651965728561 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark62(45.59052559800304,66.48754761082316,30.758917397628863,11.127621323887297 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark62(48.07841051113013,-23.132918633330974,94.88301188947781,-82.97857163618886 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark62(48.86163806877316,51.572097317457775,93.74679674434782,6.6869386418831205 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark62(50.764432043317335,3.0385816786431356E-64,-3.5328120291657834,51.823736486434406 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark62(52.37408600850449,6.018531076210112E-36,-62.26697918151251,100.0 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark62(53.35949536674369,1.2154326714572542E-63,-37.79334071459743,-99.30992871267031 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark62(54.023905493472455,-12.426834961503118,-95.79004962524797,50.941903003727504 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark62(54.650369066584275,5.345529420184391E-51,-100.0,-99.99999999999999 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark62(56.32773138520837,7.418412301374843E-68,-100.0,-59.681672353509946 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark62(56.41355213133298,-5.551115123125783E-17,12.389518541763824,26.605893654785092 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark62(-57.90672674350563,-92.38646212927594,61.63492341257836,-38.53937864316872 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark62(59.41541175850483,-24.025759741654962,58.92740044251764,-2.472987842939785 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark62(60.79487825081665,96.63050390866024,-32.8901882678871,42.88940878212401 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark62(67.39002160184705,8.976775984528857,73.69163380337373,91.060302391042 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark62(70.61217367964915,-21.892872415533034,-58.22940060153925,-77.54163818764607 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark62(71.11222670026143,36.230668561882965,79.04172586940692,67.26547882079231 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark62(71.84418675060067,-42.91798660928849,81.93121467121975,47.03377507084781 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark62(77.49155947924896,4.440892098500626E-16,-100.0,55.26412389324497 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark62(81.94538896148055,-56.86016272889027,42.79341218090647,-77.81349883524919 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark62(82.06093488056543,27.543688947833353,75.2601405628551,34.34448326554369 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark62(8.280451689492697,3.3409558876152446E-52,-76.15952000206477,-100.0 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark62(8.358494154984484,-2.6727647100921956E-51,100.0,-89.36397586023398 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark62(85.47188134042963,30.136273138677097,57.90233048712787,-22.729023443964167 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark62(89.05410567335821,0.98975223397486,-5.024900249814095,69.09275242451216 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark62(99.88385469029312,1.3877787807814457E-17,-82.97491090767556,78.85592013705134 ) ;
  }
}
