import org.junit.Test;

public class Sample28Test {

  @Test
  public void test0() {
//    0.9999926440963977;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark28(-0.03630253932067262 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark28(-0.04874112798046326 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark28(-0.07171981799936589 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark28(-0.10280139059652527 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark28(-0.11402435176917436 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark28(-0.12436874174335344 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark28(-0.17701643226297392 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark28(-0.1847012186893835 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark28(-0.2423881790718525 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark28(-0.26393129034416063 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark28(-0.31384598761638927 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark28(-0.3670435897564772 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark28(-0.42320827122297544 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark28(-0.4783828024704775 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark28(-0.4848166904512681 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark28(-0.5042209938152382 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark28(-0.5654344974541203 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark28(-0.5766239740249972 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark28(-0.5921972137197855 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark28(-0.6264880883498449 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark28(-0.6796479144287133 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark28(-0.7173225254039579 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark28(-0.788708833164236 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark28(-0.8165118697828149 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark28(-0.8390802269697701 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark28(-0.8467656444170615 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark28(-0.8503339287869238 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark28(-0.859010630492989 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark28(-0.8594567222115757 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark28(-0.8612000389477004 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark28(-0.866403393491197 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark28(-0.9337643596755356 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark28(-0.94837501543266 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark28(-0.9568993978355422 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark28(-0.9617269517196974 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark28(-0.9731237252224645 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark28(-10.055193002550908 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark28(-10.104249316750867 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark28(-10.143135145600496 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark28(-10.229370356521201 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark28(-10.236225807124114 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark28(-1.030642792810795 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark28(-10.31982445475579 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark28(-1.0329599614447744 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark28(-10.370229154047578 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark28(-10.382035867089414 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark28(-10.385545092702714 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark28(-10.389036152169155 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark28(-10.408843830969516 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark28(-10.413358998217674 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark28(-10.482923065959454 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark28(-10.549175115516846 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark28(-10.56811429818876 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark28(-10.612785409049351 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark28(-10.701276542352375 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark28(-10.714624370861657 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark28(-10.750184603404904 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark28(-10.776728291920406 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark28(-10.83573838860994 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark28(-10.847748392830255 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark28(-10.850722672220186 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark28(-10.920009749388512 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark28(-1.0932629544395382 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark28(-11.012066288281616 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark28(-11.015380750987887 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark28(-11.018683740173827 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark28(-1.1111562722655606 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark28(-11.145213766621083 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark28(-11.166554662467917 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark28(-11.193892567722386 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark28(-11.241702873271379 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark28(-11.272024007988918 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark28(-11.304886084537031 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark28(-11.352088050305767 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark28(-11.483766529744187 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark28(-11.520472801873737 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark28(-11.528293105374132 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark28(-11.60538174029297 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark28(-11.615246738449628 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark28(-11.653801825941045 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark28(-11.673760901859936 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark28(-11.79206514579225 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark28(-11.8202421519414 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark28(-11.86702341078869 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark28(-11.87980819765582 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark28(-11.892211614740347 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark28(-11.918328680137265 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark28(-1.1957150702607322 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark28(-11.960971957467834 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark28(-11.973867406240672 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark28(-12.055445394991722 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark28(-12.089045187368768 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark28(-12.122346978209734 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark28(-12.185249134751714 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark28(-12.190987453463492 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark28(-12.19815320540259 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark28(-12.218533333664453 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark28(-12.230037988326202 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark28(-12.265828200849981 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark28(-12.357077978713576 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark28(-12.381487943874319 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark28(-1.241093428039619 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark28(-12.435790536885392 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark28(-12.447298748266817 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark28(-12.466395044912431 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark28(-12.498413715673749 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark28(-12.621165270297979 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark28(-12.639760436080437 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark28(-12.679381470199786 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark28(-12.682795704023263 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark28(-12.703322355311911 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark28(-12.739185199282858 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark28(-12.76075247082457 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark28(-12.780299792471155 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark28(-12.888597615946978 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark28(-12.989246513347737 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark28(-13.103062762183711 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark28(-13.11737670157116 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark28(-13.117999082167955 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark28(-1.312508740694554 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark28(-1.3164627305363439 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark28(-13.16774247135723 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark28(-13.221356897186737 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark28(-13.232334434686962 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark28(-13.25954488087146 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark28(-13.28325265501789 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark28(-13.297506421680595 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark28(-13.312229786083705 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark28(-13.335353526566422 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark28(-13.338294931870664 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark28(-13.339576656687228 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark28(-13.356623349645162 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark28(-1.3366244491103174 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark28(-13.375101058525019 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark28(-13.399340004864314 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark28(-13.410915798199753 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark28(-1.3456102591773487 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark28(-13.499488593053528 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark28(-13.501610152176966 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark28(-13.513582039746268 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark28(-13.554170912777622 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark28(-13.556160187569205 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark28(-13.559529695134316 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark28(-1.3563738458770729 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark28(-13.577986874318398 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark28(-13.709360721421078 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark28(-13.740505880909623 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark28(-13.798925141444315 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark28(-13.800267354837374 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark28(-13.839708378318178 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark28(-13.876414895327073 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark28(-13.907121270124904 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark28(-13.939302931283336 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark28(-13.947192755825526 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark28(-13.991155662400104 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark28(-14.052779883228013 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark28(-14.159904777211835 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark28(-1.41691040524519 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark28(-14.213142765537398 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark28(-14.227668997047573 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark28(-14.25070022729642 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark28(-14.336565524333153 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark28(-14.350095709645046 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark28(-14.376789403700215 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark28(-14.381619850444949 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark28(-14.386655001222223 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark28(-14.40077955889197 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark28(-14.404706153823682 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark28(-14.421140237287446 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark28(-14.43878645534204 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark28(-14.459528855731094 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark28(-14.46390507831174 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark28(-14.46688111514247 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark28(-14.467524206414751 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark28(-14.479816797224657 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark28(-14.48406102859137 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark28(-14.489800725759366 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark28(-14.504269484353443 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark28(-14.555745565719903 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark28(-14.595002035449994 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark28(-14.678003473874782 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark28(-14.681389114382455 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark28(-14.735045257717474 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark28(-14.816888707922132 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark28(-1.4878462749315702 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark28(-14.899976479033668 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark28(-14.920103647873304 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark28(-14.933671801292789 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark28(-14.95979962559997 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark28(-14.972017246686647 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark28(-14.993930698133013 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark28(-15.093526701100174 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark28(-15.095408873169958 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark28(-15.113411197516058 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark28(-15.178451286619804 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark28(-15.178943590888878 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark28(-15.182638621340942 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark28(-15.199410717948837 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark28(-15.209570592221453 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark28(-15.230541296393625 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark28(-15.254063006695944 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark28(-15.258324860272367 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark28(-15.28211654584753 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark28(-15.288443068599733 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark28(-15.36044665356917 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark28(-15.38479080300597 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark28(-15.497645028312945 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark28(-15.518660749362567 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark28(-15.520266894684127 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark28(-15.528155281174307 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark28(-15.557175205993488 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark28(-15.557759800673438 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark28(-1.5721056994979108 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark28(-15.743211331982394 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark28(-15.77795000172361 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark28(-15.869620051450937 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark28(-15.880330626812139 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark28(-15.883616043754884 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark28(-15.939277057488297 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark28(-15.975617426499696 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark28(-16.018865834162924 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark28(-16.091311462101316 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark28(-16.099296368233524 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark28(-16.099533719183384 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark28(-16.113614191856712 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark28(-16.180356489877653 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark28(-16.18159253334521 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark28(-16.206120048624356 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark28(-16.21387088939524 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark28(-16.233732060920133 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark28(-16.239643722752703 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark28(-16.28554492452261 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark28(-16.290654689196487 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark28(-16.342961853327893 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark28(-16.353384068150078 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark28(-16.42673446454765 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark28(-16.511881840185055 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark28(-16.542864748144353 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark28(-16.5587774879494 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark28(-16.60868586178256 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark28(-16.656664719457922 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark28(-16.70024413880091 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark28(-16.707651384109525 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark28(-16.755131328865104 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark28(-16.760871455007702 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark28(-16.83858794454261 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark28(-16.84230001601368 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark28(-16.917786380157082 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark28(-16.927330628642935 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark28(-1.6948586249834392 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark28(-16.955666886804323 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark28(-16.982620166280384 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark28(-16.9841202057804 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark28(-17.01827553720301 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark28(-1.7024749055812265 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark28(-17.13813423969684 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark28(-17.16687162132156 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark28(-17.21050359862221 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark28(-17.266816170548353 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark28(-1.729587564117253 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark28(-17.312061448286897 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark28(-1.7331652213258053 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark28(-17.359630883171633 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark28(-17.405265934863138 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark28(-17.412358782518325 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark28(-17.421392102778555 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark28(-17.46284770393558 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark28(-17.540612676520382 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark28(-17.54337494729073 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark28(-17.54574433747564 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark28(-17.578505846620146 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark28(-17.579419628867555 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark28(-17.584936284447267 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark28(-1.7589649018330675 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark28(-17.62769817619065 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark28(-17.70754387314382 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark28(-17.73429764104945 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark28(-17.79655366556301 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark28(-1.7888554990158667 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark28(-18.006003134996178 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark28(-18.03978415336897 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark28(-18.063761596391885 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark28(-18.083831288860324 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark28(-18.2466307512325 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark28(-1.8290031263426414 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark28(-1.8418279331524445 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark28(-18.452272667726973 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark28(-18.49612775451483 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark28(-18.506650885501045 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark28(-18.51894584044736 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark28(-18.52942786468826 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark28(-18.531113705675196 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark28(-18.59160363012569 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark28(-18.612343744445383 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark28(-18.658493383973138 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark28(-1.872788771149672 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark28(-18.740003856896763 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark28(-18.755539526678817 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark28(-18.780452776185513 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark28(-1.881675004436275 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark28(-18.821690354101932 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark28(-18.821727825409624 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark28(-18.838904142835332 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark28(-18.84573235780411 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark28(-18.918006383764634 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark28(-18.926889181820712 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark28(-18.927575551813987 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark28(-19.04275748567315 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark28(-19.059118774710782 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark28(-19.077085010242655 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark28(-19.097900702034295 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark28(-19.104805213845836 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark28(-19.113494160764887 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark28(-19.125863926988714 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark28(-19.13280977870508 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark28(-19.147684101188787 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark28(-1.9155889409060052 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark28(-1.9177561225019986 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark28(-1.9246790155234947 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark28(-19.27557730799198 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark28(-19.28971318773533 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark28(-1.9297641062213842 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark28(-19.303211240377948 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark28(-1.9355909353805174 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark28(-1.9399770456418395 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark28(-19.408727128977432 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark28(-19.42937700697452 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark28(-19.429455778084076 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark28(-19.434740058771638 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark28(-1.9455423788884616 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark28(-19.4780882685517 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark28(-19.498486945230383 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark28(-19.564265475278162 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark28(-19.63560798956081 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark28(-19.743028832047457 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark28(-19.772164717908282 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark28(-19.786266600074057 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark28(-19.912179930028145 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark28(-19.976472957970913 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark28(-19.98281883741808 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark28(-1.9985716213029008 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark28(-19.999325876824898 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark28(-20.002187259300783 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark28(-20.071813449780436 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark28(-20.084319241321964 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark28(-20.09744625213486 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark28(-20.113115242381568 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark28(-2.01628188544764 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark28(-20.181733881057596 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark28(-20.27430800423356 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark28(-20.288124024225752 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark28(-20.2884469036791 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark28(-20.31730008780967 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark28(-20.327177995177266 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark28(-20.34785730606876 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark28(-20.35786420084311 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark28(-20.37357528523262 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark28(-20.43543075953427 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark28(-20.46047192922981 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark28(-20.475259743873025 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark28(-2.048766148403061 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark28(-20.53307301417871 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark28(-20.60647355774637 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark28(-20.614509208434015 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark28(-2.0674933203207075 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark28(-20.683034007822144 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark28(-20.723485666099634 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark28(-20.733844024312347 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark28(-20.87281155787572 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark28(-20.893479497727327 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark28(-20.908636651281995 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark28(-21.004827819223777 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark28(-21.02857052028071 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark28(-2.105163878995427 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark28(-2.1080746245130797 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark28(-21.099715553282252 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark28(-21.108310411157902 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark28(-21.156149303777866 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark28(-21.193870023924205 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark28(-21.219877859205894 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark28(-21.240169606639128 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark28(-21.265374270464932 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark28(-21.292724932764415 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark28(-2.1294948184502687 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark28(-21.3219654421209 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark28(-21.352017781475823 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark28(-21.353060945401523 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark28(-21.358434060718224 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark28(-21.412462700514993 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark28(-21.433521946962045 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark28(-21.470622596030893 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark28(-21.48641526666877 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark28(-21.487840061711523 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark28(-21.49019899241162 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark28(-21.512051081913924 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark28(-21.5346493601472 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark28(-21.596926749564844 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark28(-2.1600811984221053 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark28(-21.606617580918154 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark28(-21.624476702582584 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark28(-21.628392610249335 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark28(-21.64732938122222 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark28(-21.65369755495125 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark28(-21.65412343991096 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark28(-21.657673753872402 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark28(-21.717869131058976 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark28(-2.175957504536413 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark28(-21.76728021530525 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark28(-21.834513408293162 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark28(-21.848725804947236 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark28(-21.868089366344705 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark28(-21.907213645213886 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark28(-21.907743773480064 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark28(-21.937048234631604 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark28(-21.943150066803966 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark28(-21.996994120816254 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark28(-2.204015450305178 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark28(-22.05248241958722 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark28(-22.080292619228814 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark28(-22.087192543967532 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark28(-22.12839377399635 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark28(-22.143239645221342 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark28(-22.173641797919075 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark28(-22.223183861787504 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark28(-22.22413996397887 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark28(-22.28545924085985 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark28(-22.31978059458615 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark28(-22.349056468295686 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark28(-22.45087835888799 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark28(-22.46669317839121 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark28(-22.47314663906272 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark28(-22.514806061103826 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark28(-22.54181234379793 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark28(-22.542370601880663 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark28(-22.574669790980167 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark28(-22.680197132930417 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark28(-22.702881965490946 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark28(-22.74966659433278 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark28(-22.752657907051116 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark28(-22.76232385775367 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark28(-22.765198988966404 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark28(-2.2788508966660856 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark28(-22.82339026238651 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark28(-22.85035698078785 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark28(-22.85090321831538 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark28(-22.862939230633557 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark28(-23.000480270614204 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark28(-23.09990213381225 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark28(-23.135797250760405 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark28(-23.15242041932484 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark28(-23.211963873386935 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark28(-23.217322291034705 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark28(-23.25836312431204 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark28(-23.261794941059577 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark28(-23.271689603634456 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark28(-23.2963652912848 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark28(-23.298347418942626 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark28(-23.303848373593254 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark28(-23.33556949676145 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark28(-23.37513164431624 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark28(-23.376489335875974 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark28(-23.406779928635927 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark28(-23.46791599151838 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark28(-2.349242976914752 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark28(-23.580837275224113 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark28(-23.628112458616272 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark28(-23.665345681664675 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark28(-2.3665393723952093 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark28(-23.74105709170496 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark28(-23.75366437328094 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark28(-23.820623521420885 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark28(-23.82820558873513 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark28(-23.83051794645081 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark28(-23.851525961557712 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark28(-23.898440581533848 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark28(-24.026264942543378 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark28(-24.106437926409413 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark28(-24.130163106203995 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark28(-24.14249764555791 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark28(-24.178152626861134 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark28(-24.179586388324267 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark28(-24.207428742745734 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark28(-24.264732681384316 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark28(-24.275497798204555 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark28(-24.297675962665878 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark28(-24.40131154236265 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark28(-24.425747098543482 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark28(-24.49211677803818 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark28(-24.619075568469498 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark28(-24.645252707306824 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark28(-24.701441187422432 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark28(-24.740666069509487 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark28(-24.75891120131044 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark28(-24.806562462324806 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark28(-24.821575959785775 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark28(-24.834716832735367 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark28(-2.484820666347815 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark28(-24.90280030855199 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark28(-24.903015893958298 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark28(-24.905163650014387 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark28(-24.93618639695714 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark28(-24.94219443402963 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark28(-24.942946628505027 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark28(-24.955620692803862 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark28(-24.982329064147564 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark28(-24.98745342422974 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark28(-24.995115035999646 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark28(-25.001814356960892 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark28(-25.004317905338908 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark28(-25.057523242525306 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark28(-25.065686334140878 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark28(-25.132674967839662 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark28(-25.146739545091506 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark28(-25.160799434120747 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark28(-25.184835246497244 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark28(-25.193755570664564 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark28(-25.221520840600604 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark28(-25.225502462799426 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark28(-25.23792339547603 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark28(-25.2397953419933 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark28(-25.25610727286194 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark28(-25.29013953205603 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark28(-25.334334477283548 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark28(-2.5411218203261257 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark28(-25.413925924771917 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark28(-25.452549417321137 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark28(-25.453096267175738 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark28(-25.475452561402776 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark28(-25.489811830244307 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark28(-25.52281268802146 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark28(-25.586645419670504 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark28(-25.65297420919825 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark28(-25.693929906532105 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark28(-25.756399770179556 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark28(-25.763235691426118 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark28(-25.776909835234463 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark28(-25.817717720880523 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark28(-2.5825815481617127 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark28(-25.931649375521886 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark28(-25.993479809640505 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark28(-26.085042124914224 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark28(-26.094370753378726 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark28(-2.609448982651003 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark28(-2.6150043206164924 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark28(-26.185128881044605 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark28(-26.20427251525541 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark28(-26.204432173168698 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark28(-26.295401262604145 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark28(-26.29683941032124 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark28(-26.3212627424696 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark28(-26.37339987180127 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark28(-26.432666228291765 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark28(-26.480822523840473 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark28(-2.6548480469770226 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark28(-26.650994191924198 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark28(-26.67460131523201 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark28(-26.68810041027463 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark28(-26.704877458420498 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark28(-26.74355260331751 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark28(-26.821890934922862 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark28(-26.822342523808018 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark28(-26.876692281383384 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark28(-26.93233427743293 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark28(-26.934341629134792 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark28(-26.986817320113275 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark28(-27.088042766798395 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark28(-27.13274226564279 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark28(-27.133038224523773 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark28(-27.13821460937602 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark28(-27.246448383162303 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark28(-27.24825417313717 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark28(-27.32522667894628 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark28(-27.34057246656765 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark28(-27.389615319835087 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark28(-27.428350389885352 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark28(-27.42855685158534 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark28(-27.445941726727312 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark28(-27.502499816620144 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark28(-27.519789341430382 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark28(-27.57205511543674 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark28(-2.7575195181526198 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark28(-27.634433927604746 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark28(-27.64569355897983 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark28(-27.653060336498086 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark28(-27.686889733706295 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark28(-27.781028112428416 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark28(-27.783901885566806 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark28(-27.800247288894255 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark28(-27.893426918243037 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark28(-27.90268842155075 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark28(-27.915580261851034 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark28(-28.007534314398796 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark28(-28.01268403928478 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark28(-28.015355911010943 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark28(-28.058342767599626 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark28(-28.14032097871153 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark28(-2.815669956190604 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark28(-28.163785649013533 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark28(-28.31251903111773 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark28(-28.322447805391988 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark28(-28.41568505324466 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark28(-28.459423377475517 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark28(-28.463729047319134 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark28(-28.472143581631457 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark28(-28.500286231407372 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark28(-28.520312950790853 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark28(-28.52779981781029 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark28(-28.53535015232937 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark28(-2.8544630407867118 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark28(-28.557050464181373 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark28(-28.602254084008678 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark28(-28.634027589491268 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark28(-28.652832373190293 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark28(-28.67672372732197 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark28(-28.681668818245114 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark28(-28.687749313566414 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark28(-28.721468581266237 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark28(-28.777009702378436 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark28(-28.78042561039871 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark28(-2.882926268946747 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark28(-28.83309482359641 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark28(-28.87175858701613 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark28(-28.895720252346663 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark28(-28.932740749904568 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark28(-28.984202311001468 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark28(-29.003543239710552 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark28(-29.029777833652332 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark28(-29.076898612742298 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark28(-29.15973432344765 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark28(-29.1623254481908 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark28(-29.210545144629975 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark28(-29.213934175446397 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark28(-29.31108589535644 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark28(-29.346685437563096 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark28(-29.504330460378085 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark28(-29.50863638946292 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark28(-29.559174895708693 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark28(-29.587647153706456 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark28(-29.604158334422536 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark28(-29.607517056945554 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark28(-29.693884245737962 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark28(-2.9710432934116255 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark28(-29.825529073845473 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark28(-29.85186792203926 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark28(-29.87659623482388 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark28(-29.951436385412904 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark28(-29.965106748464777 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark28(-29.99775996064882 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark28(-3.0050453336279332 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark28(-30.08030818450331 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark28(-30.18215799464899 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark28(-30.2758703901645 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark28(-30.294258485100386 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark28(-30.301537754060817 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark28(-30.318975379311695 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark28(-30.344860306417786 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark28(-30.430986442232495 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark28(-30.448507504608585 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark28(-30.469840460103754 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark28(-30.51298232545456 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark28(-30.58906921559688 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark28(-30.5980279349765 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark28(-30.6290475540455 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark28(-30.64218717160398 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark28(-30.687792086343762 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark28(-30.709874605603105 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark28(-30.764772464268034 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark28(-30.767362581862272 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark28(-30.774986323503015 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark28(-30.777120925914986 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark28(-30.895250645673954 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark28(-31.01015206138831 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark28(-31.105233145201325 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark28(-31.15149098644578 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark28(-31.170447836285618 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark28(-31.170560513553312 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark28(-31.176172252243646 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark28(-31.284843963304468 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark28(-3.131443493559402 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark28(-31.33099503657239 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark28(-31.338117759632155 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark28(-31.43719191626542 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark28(-31.442008168410325 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark28(-31.46059353047535 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark28(-31.465553145067688 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark28(-31.472925128269026 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark28(-31.509970458897612 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark28(-31.591379793826462 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark28(-31.622073017409463 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark28(-31.673791779318265 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark28(-3.1688456343818387 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark28(-31.75783924178745 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark28(-31.773759255071795 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark28(-31.884092572464183 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark28(-31.88764877301564 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark28(-31.903605523139774 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark28(-3.1904639709288176 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark28(-31.915237192633427 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark28(-31.947632220000585 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark28(-31.956190525675936 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark28(-31.99388771587803 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark28(-32.041006777271264 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark28(-32.07744684048461 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark28(-32.09961758001121 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark28(-32.15134814671951 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark28(-32.161026229523486 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark28(-32.18406036623989 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark28(-32.241127824850224 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark28(-32.27213203008429 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark28(-32.34509515252586 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark28(-32.34859704158626 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark28(-32.35365884579218 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark28(-32.355564106373436 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark28(-32.375816705758126 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark28(-32.39331342947848 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark28(-3.2410698743558157 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark28(-32.54733865974322 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark28(-32.548866985829264 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark28(-32.572616227429904 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark28(-32.61247004768073 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark28(-32.636631771822394 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark28(-32.637161368838164 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark28(-32.661335347331416 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark28(-32.70033232807026 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark28(-32.7076869754284 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark28(-32.81469995684196 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark28(-32.81580499843706 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark28(-3.2828792176091213 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark28(-32.840596832406106 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark28(-32.855738403910735 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark28(-32.86192378640071 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark28(-3.2904468022213678 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark28(-32.94936354966458 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark28(-32.98315968090617 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark28(-33.06572030376998 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark28(-33.086912800113026 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark28(-33.14284830134888 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark28(-33.174145151992946 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark28(-33.183178280110354 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark28(-33.25431250017586 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark28(-33.27430262758723 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark28(-33.34394877984843 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark28(-33.3512400639605 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark28(-33.364365255500815 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark28(-33.380001197832996 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark28(-33.38474049229487 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark28(-33.39507220007181 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark28(-33.39978395692704 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark28(-33.422401974129 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark28(-33.42622195584015 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark28(-33.493581797171174 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark28(-3.3502104666466153 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark28(-33.50590588670144 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark28(-33.54025131157519 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark28(-33.54210387803869 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark28(-33.600287887985104 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark28(-33.62445282452889 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark28(-33.63032829982056 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark28(-33.77125017612495 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark28(-33.78899009914382 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark28(-33.98872367058527 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark28(-3.4031990584657734 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark28(-34.0575262818509 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark28(-34.07917974038833 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark28(-3.4086538602513485 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark28(-34.110399687009064 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark28(-34.164513541724844 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark28(-34.2090098570831 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark28(-34.34062074606048 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark28(-34.34690847102648 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark28(-34.362755252476674 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark28(-34.38110561929449 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark28(-34.405159129641476 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark28(-34.42742318233118 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark28(-34.450336633916635 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark28(-34.5116024596384 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark28(-34.51242702418398 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark28(-34.592705360409 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark28(-34.650038415785374 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark28(-34.664100817734806 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark28(-34.71604231384285 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark28(-34.7631522036865 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark28(-34.77867414588867 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark28(-34.89690941847658 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark28(-34.89740306131692 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark28(-34.9338728793241 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark28(-34.97144954188707 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark28(-34.9796253726016 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark28(-35.004021340947844 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark28(-35.06887505521176 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark28(-35.07950263406326 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark28(-35.093943915887166 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark28(-35.12083135807973 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark28(-35.21587398951445 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark28(-35.323045868898475 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark28(-3.5384354967034284 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark28(-35.43283921578258 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark28(-35.44366443009963 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark28(-35.474352159682184 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark28(-35.50412332956128 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark28(-3.5504735996958487 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark28(-35.56498793062211 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark28(-35.57297542626354 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark28(-35.576946762015666 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark28(-3.5591122321262816 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark28(-35.598669976381615 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark28(-35.6261110669077 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark28(-35.64484642917026 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark28(-35.66877025570547 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark28(-35.67610817703688 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark28(-35.7951364002611 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark28(-35.81930202938307 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark28(-35.86471909014605 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark28(-35.8862628166404 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark28(-35.946314546924725 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark28(-35.952355947850734 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark28(-35.98334128651575 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark28(-36.01038420321257 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark28(-3.6019182413836575 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark28(-36.06608143898289 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark28(-36.09593212793247 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark28(-36.107195773854706 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark28(-36.124050702213786 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark28(-36.16267744689887 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark28(-36.27895313048046 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark28(-36.31607791802982 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark28(-36.33140323257691 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark28(-36.35885694462932 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark28(-36.36877201438209 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark28(-36.423514178251935 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark28(-36.43506969175605 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark28(-36.456256054823946 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark28(-36.46159873803012 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark28(-36.47476769032847 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark28(-36.5971964950007 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark28(-36.60440654907193 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark28(-36.66793915386035 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark28(-36.67425022641007 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark28(-36.807368297399414 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark28(-36.809624303455244 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark28(-36.859457946944005 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark28(-3.6901819809308023 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark28(-36.906492099848045 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark28(-3.6928501692507893 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark28(-36.946559271626626 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark28(-37.02415223355307 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark28(-37.03498699505479 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark28(-37.062211122992814 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark28(-37.09265198211493 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark28(-37.142846619366466 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark28(-37.19696095596121 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark28(-37.23780787979809 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark28(-37.23939338303115 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark28(-37.26677021463936 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark28(-37.30004789726953 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark28(-37.32008020322557 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark28(-37.322489296242225 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark28(-37.35980742392946 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark28(-3.7370243338234985 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark28(-37.37678614537161 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark28(-37.40220503717844 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark28(-37.43883322085868 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark28(-37.45225080514067 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark28(-37.49417409527407 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark28(-37.50956887255714 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark28(-37.522365967191384 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark28(-37.570607536450936 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark28(-37.57609402579545 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark28(-37.59971147996095 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark28(-37.68238316793213 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark28(-37.718749366165596 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark28(-37.78989742027441 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark28(-37.79255277788944 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark28(-37.86322031100149 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark28(-3.7884748346054096 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark28(-37.89006014218561 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark28(-37.892838749340044 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark28(-37.9010355389491 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark28(-37.926267149478 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark28(-37.96620386843479 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark28(-37.97930708002135 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark28(-37.981938834476225 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark28(-37.98813066623434 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark28(-38.04995009499954 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark28(-38.104820543628115 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark28(-38.127712951477434 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark28(-3.8154576470775368 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark28(-38.18267049941477 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark28(-38.20616554923089 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark28(-38.23009738132874 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark28(-38.24556538433601 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark28(-38.2539116952618 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark28(-38.418800185609236 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark28(-38.512957440244854 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark28(-38.53424561760379 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark28(-38.540671973098405 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark28(-38.54283506998573 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark28(-3.8555317236545363 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark28(-38.57270423661288 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark28(-3.8639357087843393 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark28(-38.6440650392653 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark28(-38.64500265394324 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark28(-38.65322971185896 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark28(-38.66024778287098 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark28(-38.661785980228515 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark28(-38.715420997027735 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark28(-38.75462897796928 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark28(-38.79223014303357 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark28(-38.802872708033085 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark28(-38.80779046839697 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark28(-38.80962660166001 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark28(-38.82826226218008 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark28(-38.89213039137913 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark28(-38.918119565619705 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark28(-38.95053397146311 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark28(-38.95968833249637 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark28(-38.98759659138551 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark28(-38.989603754663534 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark28(-39.00246275643373 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark28(-39.008104022982714 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark28(-39.01014660992288 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark28(-39.019558445017545 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark28(-39.06320001409802 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark28(-39.114875728739776 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark28(-39.12378993165979 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark28(-39.15470270528487 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark28(-3.9216901415516787 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark28(-39.21769209071782 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark28(-39.22672767385187 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark28(-39.345120275754496 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark28(-3.9397211616207954 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark28(-39.397790193346324 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark28(-39.410926650191456 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark28(-39.41882025739118 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark28(-39.430797440765474 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark28(-39.49226720297787 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark28(-39.538439133228295 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark28(-39.54174368743799 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark28(-39.66547151018609 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark28(-39.67430201262117 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark28(-39.70726934083915 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark28(-39.75008053473279 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark28(-39.83174316068319 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark28(-39.84269078044973 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark28(-39.88096206876579 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark28(-39.9816120689743 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark28(-39.989559752697176 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark28(-39.99545106999296 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark28(-40.06246960825752 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark28(-40.15469384618031 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark28(-40.15852926929071 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark28(-4.017076124961491 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark28(-40.18735159286591 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark28(-40.19250992529537 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark28(-40.19400914680777 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark28(-40.22180426245319 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark28(-40.26062307202536 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark28(-4.026950833068327 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark28(-40.293026936051014 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark28(-40.310866423476185 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark28(-40.32033121865582 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark28(-40.34628444909529 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark28(-40.34823655179005 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark28(-40.35302474481992 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark28(-40.359018944927946 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark28(-40.365387581739995 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark28(-40.44094806759577 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark28(-40.53263226155699 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark28(-40.57041901922276 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark28(-40.591935829071524 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark28(-40.62098231954254 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark28(-40.6906261861871 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark28(-40.70034334953456 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark28(-40.72093428528587 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark28(-4.078509407778668 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark28(-40.8578778452531 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark28(-40.872810360973524 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark28(-40.93142290151861 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark28(-41.134097370138356 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark28(-41.14692251739669 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark28(-41.16926271856614 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark28(-41.21678641144308 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark28(-41.25434628297002 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark28(-41.2853832102245 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark28(-41.3333501502128 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark28(-41.34738279485324 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark28(-4.138771828508794 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark28(-41.39149169023708 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark28(-41.40504339211857 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark28(-41.41139975781283 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark28(-41.45298347317803 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark28(-41.45384775044087 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark28(-41.48526574146365 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark28(-41.488849931340745 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark28(-41.61845754691189 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark28(-41.638713547542515 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark28(-4.169004785404027 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark28(-41.7948740796384 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark28(-41.808104360279394 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark28(-41.886768822680274 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark28(-41.89495225888926 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark28(-41.903912349434755 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark28(-41.91913873611408 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark28(-4.19643354208128 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark28(-41.97517994194231 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark28(-42.00603380887043 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark28(-42.02606261715842 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark28(-42.02630186230159 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark28(-4.208557355488082 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark28(-42.194443074590325 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark28(-42.20580817600228 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark28(-42.256256294348034 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark28(-42.25930280522672 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark28(-42.268373236301485 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark28(-42.27801396751416 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark28(-42.2885060362667 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark28(-42.31778753252753 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark28(-42.33693022222518 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark28(-4.2340436159984876 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark28(-42.446483927162326 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark28(-42.44703959032805 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark28(-42.49532016937139 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark28(-42.521085633135435 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark28(-42.56067038385394 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark28(-42.68650698905394 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark28(-4.268998221951833 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark28(-4.27125584013109 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark28(-4.271564921580207 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark28(-4.272706065695587 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark28(-42.74662057093357 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark28(-42.84727487343767 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark28(-42.849226987273155 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark28(-42.85150208954778 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark28(-42.87297427944969 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark28(-42.87714020937339 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark28(-42.88094910726716 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark28(-42.897767585498194 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark28(-42.90714784991045 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark28(-42.93192507943551 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark28(-42.96095820686694 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark28(-43.02492394941475 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark28(-43.06109186226399 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark28(-43.06547093419548 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark28(-43.08090081815885 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark28(-4.309703380145407 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark28(-43.15363060216939 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark28(-43.16532826823003 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark28(-43.208595531492165 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark28(-43.21157716729549 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark28(-43.25337041746802 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark28(-43.26947240657173 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark28(-43.29305070971061 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark28(-43.29553417518896 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark28(-4.330557605006604 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark28(-43.30960560468009 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark28(-43.397425498804274 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark28(-4.341659360323405 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark28(-4.34808602919172 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark28(-43.591393789341446 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark28(-43.62321507369249 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark28(-43.62813166757646 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark28(-43.695545919522694 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark28(-43.709294655574716 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark28(-43.75112381723889 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark28(-43.79299260906831 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark28(-43.79934503611751 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark28(-43.966968532381024 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark28(-43.97229847442612 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark28(-43.97607860530599 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark28(-44.034881595342256 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark28(-44.07665188295506 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark28(-44.0863421200671 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark28(-44.23602720690199 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark28(-44.2507389024633 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark28(-44.323101884873964 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark28(-44.32972920235871 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark28(-44.3846900164919 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark28(-4.442166534099329 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark28(-44.48295384674892 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark28(-44.49935968456285 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark28(-44.52431508557662 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark28(-44.529237753347715 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark28(-44.54066102328562 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark28(-44.54682313056295 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark28(-44.556287031577256 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark28(-44.5709667558076 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark28(-44.57264330702788 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark28(-44.587738463001145 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark28(-44.605861020627025 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark28(-44.63291147174375 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark28(-44.64985474489429 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark28(-44.694187011497036 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark28(-44.74431631770543 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark28(-44.76694479938117 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark28(-44.77850537717403 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark28(-44.779283034180196 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark28(-44.81467801388164 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark28(-44.8449654562836 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark28(-44.92677241809226 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark28(-44.94394605171477 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark28(-44.95546594421689 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark28(-44.97953256122831 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark28(-45.00940273913281 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark28(-45.09895867503695 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark28(-45.11738478015015 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark28(-45.12747629785076 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark28(-45.17457084852923 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark28(-45.197573152175295 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark28(-45.253692487499045 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark28(-45.2929521611112 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark28(-45.31375084676623 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark28(-4.534942975638074 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark28(-45.39426708610807 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark28(-4.541957265467161 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark28(-45.42036710641612 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark28(-45.482176359512124 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark28(-45.510290419862145 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark28(-45.56537779736838 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark28(-45.61563908581614 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark28(-45.62573169097259 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark28(-45.70188915093403 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark28(-45.721778478141964 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark28(-45.73387190475948 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark28(-45.73720845869722 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark28(-45.81265394808132 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark28(-45.82670303449454 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark28(-45.83821085656261 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark28(-45.846371396677135 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark28(-45.85059323009444 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark28(-45.865140457732956 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark28(-45.90976718754478 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark28(-45.960792224692405 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark28(-45.98826706530663 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark28(-45.99572939112733 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark28(-46.12111667399363 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark28(-46.14108042911545 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark28(-46.14815620544051 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark28(-46.1848917157438 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark28(-46.192069924851694 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark28(-46.255034576826894 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark28(-46.27462585950957 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark28(-46.284867121887466 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark28(-46.295901515574855 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark28(-46.300276525502525 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark28(-46.301944540604325 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark28(-46.34198787277448 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark28(-46.35264728892039 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark28(-46.35876375963597 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark28(-4.637458034819943 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark28(-4.638273582748084 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark28(-46.48649174124453 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark28(-46.5769062613725 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark28(-46.5807146290298 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark28(-46.62432536240433 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark28(-46.631245153587855 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark28(-46.678639934160685 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark28(-46.76559764487174 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark28(-46.78836219771889 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark28(-46.801960015947785 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark28(-4.686487401832267 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark28(-46.95044114696585 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark28(-46.979577091566085 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark28(-46.9841080887426 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark28(-47.02442183057529 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark28(-47.07046992879682 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark28(-4.707517670315539 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark28(-47.08260057444078 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark28(-47.11328478010874 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark28(-47.13677179781606 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark28(-47.19649531381383 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark28(-47.1971382589371 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark28(-47.201241526664674 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark28(-47.21421662924019 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark28(-47.28336279238232 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark28(-47.313447049639336 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark28(-47.3223694729086 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark28(-47.32999832426448 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark28(-47.37010990878492 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark28(-47.483389928560605 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark28(-47.497433475652116 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark28(-4.751000071869996 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark28(-47.556695922199175 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark28(-47.565033545791024 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark28(-47.567953395812324 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark28(-47.62251434192572 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark28(-47.62971161161167 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark28(-47.632544179649614 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark28(-47.68146341903447 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark28(-47.77823145871258 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark28(-47.855436925580605 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark28(-4.791029736359832 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark28(-47.962994677339225 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark28(-47.96673403984077 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark28(-48.0002222886599 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark28(-48.003784933342075 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark28(-48.03147066717948 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark28(-48.05687653644419 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark28(-48.07772875228513 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark28(-48.101472550738535 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark28(-48.13768546906702 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark28(-48.17320054233585 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark28(-48.184084479094636 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark28(-4.825402728639446 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark28(-48.35883820084892 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark28(-48.36842322201764 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark28(-48.37316063004546 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark28(-48.440632706379304 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark28(-48.481177540041244 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark28(-48.48154896545977 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark28(-48.50398388826767 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark28(-48.517863107032234 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark28(-48.51819758015636 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark28(-48.54439239836299 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark28(-4.856199104248219 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark28(-48.58811121334669 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark28(-48.59295040372864 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark28(-48.69153837301241 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark28(-48.73162154036841 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark28(-48.75140800834505 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark28(-48.862188329313724 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark28(-48.92635156217611 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark28(-48.95330668449702 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark28(-48.96748158652065 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark28(-48.99091319084019 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark28(-4.902471912961289 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark28(-49.03453404734752 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark28(-49.042920554708445 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark28(-49.053086399575754 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark28(-49.15658345240812 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark28(-49.19345713364285 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark28(-49.20234071459604 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark28(-49.20802371089983 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark28(-49.261411537746504 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark28(-4.930380657631324E-32 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark28(-49.35745738880841 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark28(-49.39780159222194 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark28(-49.4306629657723 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark28(-49.43406292942083 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark28(-4.945302514156751 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark28(-49.501893270977426 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark28(-4.950996527841809 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark28(-49.59493184278658 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark28(-49.60344251131295 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark28(-49.63868728422254 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark28(-49.652404093742405 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark28(-49.6827691639669 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark28(-49.68398447674889 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark28(-49.68928545033455 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark28(-49.72375886027392 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark28(-49.72526884452155 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark28(-49.7519449041967 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark28(-4.975677478447253 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark28(-49.764137602379435 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark28(-49.78506019417593 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark28(-49.79323941390614 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark28(-49.80776226259989 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark28(-49.83405497214542 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark28(-49.836381968773466 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark28(-49.84837275967442 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark28(-49.87697102953599 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark28(-49.935053510198735 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark28(-50.05544236743695 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark28(-50.05787147266918 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark28(-50.05899598398615 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark28(-5.0088570480179015 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark28(-50.11819398986883 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark28(-50.121978468941286 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark28(-50.25145736069856 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark28(-5.027721415772277 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark28(-50.30214724417546 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark28(-50.33091254312734 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark28(-50.372298862929085 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark28(-50.445643030726515 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark28(-50.522772412381364 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark28(-50.53989590564942 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark28(-50.60180244814636 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark28(-5.069908188912464 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark28(-50.70991517015071 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark28(-50.73065981838065 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark28(-50.74755884365001 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark28(-50.801713650958625 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark28(-50.806548094874884 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark28(-50.85867896520335 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark28(-50.87152822704337 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark28(-50.89642190757644 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark28(-50.903098599512894 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark28(-50.90549014159866 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark28(-50.907371708874294 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark28(-50.908673836199235 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark28(-50.909056584203704 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark28(-50.916763022616564 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark28(-50.92474305797725 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark28(-50.9492576541454 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark28(-50.96126555864062 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark28(-51.009584725425626 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark28(-51.02340768982587 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark28(-51.140823912963775 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark28(-51.152274294050756 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark28(-51.1752929454039 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark28(-51.183672743961914 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark28(-51.21701600252977 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark28(-51.21842734252782 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark28(-51.27564001064775 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark28(-51.29400450182038 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark28(-51.35609375664851 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark28(-5.13698812959322 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark28(-51.39405657783291 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark28(-51.40241729640094 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark28(-51.43478792735383 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark28(-51.54381485135351 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark28(-51.606630534204 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark28(-51.65095389621324 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark28(-51.66651475416728 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark28(-51.67631991908876 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark28(-51.6775712280096 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark28(-5.1750656562978605 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark28(-5.177918742630766 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark28(-51.79553541475801 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark28(-51.79965069193435 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark28(-51.80396237545786 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark28(-51.850248060355916 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark28(-51.86226228292414 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark28(-51.868629597420664 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark28(-51.8976292094425 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark28(-51.90048254846111 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark28(-51.90068424349165 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark28(-51.93996453703238 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark28(-51.95711034958352 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark28(-51.96912427056548 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark28(-51.98866641766185 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark28(-52.00701934094651 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark28(-52.0165502474381 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark28(-52.03226104248979 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark28(-52.06947669797519 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark28(-52.07181146702658 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark28(-52.11119531857409 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark28(-52.16423527217362 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark28(-52.21260567620496 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark28(-52.25522345067961 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark28(-52.28628171699115 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark28(-52.29828248144051 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark28(-52.30349072451324 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark28(-5.230976210117603 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark28(-52.366492617851335 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark28(-5.240743920790706 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark28(-52.409959198496004 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark28(-52.44909534241178 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark28(-52.4556414648649 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark28(-52.49227896339861 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark28(-52.57437539371801 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark28(-52.5979354881811 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark28(-52.62445427250202 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark28(-52.64092918000287 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark28(-52.77696542294352 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark28(-52.80125502450406 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark28(-52.80501992844615 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark28(-52.90214043347501 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark28(-52.903693990316604 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark28(-52.929389263669876 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark28(-52.957863917923675 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark28(-52.97621518110187 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark28(-52.9803005700471 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark28(-53.01106196539893 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark28(-53.04927966043 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark28(-53.09929048887021 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark28(-53.128990815934365 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark28(-53.15906545527851 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark28(-53.15978378336155 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark28(-53.18771166207983 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark28(-5.321342166250773 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark28(-53.21422748431392 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark28(-53.30462347743501 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark28(-53.309085610759425 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark28(-53.35056796212538 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark28(-5.344331779947936 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark28(-53.52410207037161 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark28(-53.53963243407192 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark28(-53.55186176752085 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark28(-53.55308379893016 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark28(-53.62056117373795 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark28(-53.62441368300894 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark28(-53.636987666725425 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark28(-53.65996529563981 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark28(-53.7163559665073 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark28(-53.72587405801683 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark28(-53.73345458900447 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark28(-53.766925319551916 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark28(-53.9093144361974 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark28(-53.98080362212318 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark28(-54.005988377633486 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark28(-54.02647079100218 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark28(-54.06675601322944 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark28(-54.16635683941009 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark28(-54.187711423356674 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark28(-54.191721006925285 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark28(-54.20122674580634 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark28(-54.213209529767184 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark28(-54.27215002746642 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark28(-54.302744661529026 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark28(-54.32543361412676 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark28(-5.434815632095308 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark28(-54.37808416705887 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark28(-54.44072379486475 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark28(-54.45402733275173 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark28(-54.507671746081485 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark28(-54.63398437230784 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark28(-54.69002210239471 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark28(-5.470126107831177 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark28(-54.76516481081137 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark28(-54.78775127978517 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark28(-54.78886873209237 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark28(-54.80541079412886 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark28(-54.875048699147946 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark28(-54.87646176180281 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark28(-54.88547723796064 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark28(-54.91303741291782 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark28(-54.91341963607586 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark28(-54.933155320959436 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark28(-54.955916470314705 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark28(-54.97523538387439 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark28(-5.502922480840226 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark28(-55.06781976263453 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark28(-55.07555144277161 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark28(-55.0938295630063 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark28(-5.510160035904789 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark28(-55.14661614331475 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark28(-5.517582573954897 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark28(-55.21391512150782 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark28(-55.221798122583074 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark28(-55.2363528942529 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark28(-55.240075921613354 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark28(-55.291242434590224 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark28(-5.529546193811711 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark28(-55.302889128257206 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark28(-55.304225520697955 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark28(-55.34847605527209 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark28(-55.36653655768262 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark28(-55.411127410005314 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark28(-55.424336722954195 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark28(-55.43749363759998 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark28(-55.440699905558176 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark28(-55.44092377897154 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark28(-55.46285852495425 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark28(-55.492156078296226 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark28(-55.511465767861836 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark28(-55.56231073243276 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark28(-55.59647401478542 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark28(-55.64372040325034 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark28(-5.566699082173315 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark28(-55.74048967475904 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark28(-55.83210278507003 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark28(-55.85765164035463 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark28(-5.585802072032891 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark28(-55.88006104837107 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark28(-55.9384709224515 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark28(-55.948023443685834 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark28(-55.978045819758336 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark28(-55.99503271189421 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark28(-5.610413499772989 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark28(-56.113029155563844 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark28(-56.116436499393174 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark28(-56.1286860388756 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark28(-56.15035141325706 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark28(-56.15848198490121 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark28(-56.295274007225984 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark28(-56.315363392180174 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark28(-5.633156857913079 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark28(-56.35135972892093 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark28(-56.35735232455548 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark28(-56.41054320478629 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark28(-56.44265985733006 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark28(-56.47181468059554 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark28(-56.50472931174273 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark28(-56.53116239496106 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark28(-56.592819735346865 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark28(-56.605876309626325 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark28(-56.63165775776902 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark28(-56.6376584246131 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark28(-56.65967980675701 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark28(-56.678039214277234 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark28(-56.70459966628945 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark28(-56.70709643659624 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark28(-56.73139302450541 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark28(-56.73604801853431 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark28(-5.673856645293256 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark28(-56.80235967952414 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark28(-56.81205387453525 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark28(-5.681609477478929 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark28(-56.84433352762455 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark28(-56.87909020862414 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark28(-56.94971365551886 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark28(-5.700955668174771 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark28(-57.01351981369105 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark28(-57.09901839738629 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark28(-57.15515982936941 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark28(-57.281746594068125 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark28(-57.28413054944248 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark28(-57.31044201766346 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark28(-5.731256261734515 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark28(-57.32529860093176 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark28(-57.36238674854046 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark28(-57.371799915561674 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark28(-57.3749784219991 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark28(-57.3939319667774 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark28(-57.39478074579365 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark28(-57.43730685201696 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark28(-57.44098247961502 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark28(-57.45120111167423 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark28(-5.748040910763706 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark28(-57.4968099752003 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark28(-5.752242693961847 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark28(-57.53697809216969 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark28(-57.53944503511905 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark28(-57.54724694692543 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark28(-57.57336910354462 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark28(-57.60561817296692 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark28(-57.65576621493018 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark28(-57.73449896507674 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark28(-57.73638027891512 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark28(-57.76310392510513 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark28(-57.83050516877428 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark28(-57.863002435748825 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark28(-57.880652137031795 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark28(-57.88536353618774 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark28(-57.91059737181661 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark28(-57.911163615466755 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark28(-57.94263928808447 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark28(-58.003416537446604 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark28(-58.01991648991016 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark28(-58.05836277394327 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark28(-58.0873886489643 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark28(-58.10574354880524 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark28(-58.12291063953558 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark28(-58.172469418603676 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark28(-58.19964307780832 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark28(-58.20135111820175 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark28(-58.22185859694764 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark28(-58.23939920402368 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark28(-58.249113240344606 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark28(-58.25532007866605 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark28(-58.28271859044782 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark28(-58.34823723623255 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark28(-58.37767993468057 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark28(-58.43437062837269 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark28(-58.47863556724218 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark28(-58.48702894923961 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark28(-58.492207533427944 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark28(-58.504879295465905 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark28(-58.559698388617434 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark28(-58.70091055993862 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark28(-58.756412914956236 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark28(-58.778790859822735 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark28(-58.80079551851851 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark28(-5.883559658245346 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark28(-58.84183335857913 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark28(-58.85559197733126 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark28(-58.94281318866143 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark28(-58.95305637489816 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark28(-59.000978128623835 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark28(-59.025177444892066 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark28(-59.04175002873671 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark28(-59.049293047573116 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark28(-59.06835631730889 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark28(-59.1191901201743 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark28(-59.2428961768742 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark28(-59.26660348643984 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark28(-59.26881619831028 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark28(-59.29059448159 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark28(-59.32062750437868 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark28(-59.335376198456366 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark28(-59.343666653702634 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark28(-59.34500202502227 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark28(-59.37058243852618 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark28(-59.38742200723646 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark28(-59.42681395399416 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark28(-59.53932225115639 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark28(-59.57419358532978 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark28(-59.62251945870369 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark28(-59.66408728992365 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark28(-59.71364186910255 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark28(-59.76110445627043 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark28(-59.79594239378869 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark28(-59.852676724161945 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark28(-59.865107678761916 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark28(-59.976518018315076 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark28(-5.999488651550067 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark28(-60.050421528737544 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark28(-60.07035391746347 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark28(-6.010335732804222 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark28(-60.16742759489302 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark28(-60.220777495100684 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark28(-60.24625369155763 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark28(-60.26117085909648 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark28(-60.32719132174922 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark28(-60.34321269934988 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark28(-60.37376333992486 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark28(-60.37494560285024 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark28(-60.39270484255388 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark28(-60.41621225704379 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark28(-60.42419394293221 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark28(-60.49748298330086 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark28(-60.51555376096503 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark28(-60.598716556597296 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark28(-60.62946871126638 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark28(-60.66781247732522 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark28(-6.07156951512448 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark28(-60.74965352276722 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark28(-60.98476871198171 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark28(-61.00410047612805 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark28(-6.104807502807958 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark28(-61.099736281126305 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark28(-61.11056636094907 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark28(-61.17831261882534 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark28(-61.19071193420069 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark28(-61.193835542600894 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark28(-61.20362164402091 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark28(-61.21473015157788 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark28(-61.223817388897 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark28(-61.23847807736149 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark28(-61.28200675824198 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark28(-61.28875023164624 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark28(-61.37024649119751 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark28(-61.3983915714893 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark28(-61.50463107335176 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark28(-61.53448696067399 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark28(-61.540916628835674 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark28(-6.155678130753657 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark28(-61.591532794925556 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark28(-61.59373365896257 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark28(-61.60955096956406 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark28(-61.63838189385346 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark28(-61.67864951071884 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark28(-6.170839675862609 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark28(-61.74643170234426 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark28(-61.75598354460541 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark28(-61.83892200730201 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark28(-61.88952735770676 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark28(-6.1898585625122 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark28(-61.9276910049327 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark28(-61.92930111861315 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark28(-61.983233436257 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark28(-61.99344646595577 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark28(-62.00417857097011 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark28(-62.02960878542974 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark28(-62.08002707798239 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark28(-62.08412895772022 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark28(-62.115037594309854 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark28(-62.14975714603579 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark28(-62.164887941573134 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark28(-62.202201291400016 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark28(-62.230170715478586 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark28(-62.24745229328137 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark28(-62.30172280354751 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark28(-62.31155263184765 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark28(-62.37661301925965 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark28(-6.24093224742424 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark28(-62.42655442935998 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark28(-62.433547147171865 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark28(-62.436542368389404 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark28(-62.44485288233035 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark28(-62.45138129234784 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark28(-62.490038021572936 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark28(-62.51217502053166 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark28(-62.59034759654525 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark28(-62.633656277398345 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark28(-62.652398090999114 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark28(-62.67088114351584 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark28(-62.67651979447959 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark28(-62.83231675845797 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark28(-62.83399833567931 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark28(-62.86791592446863 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark28(-62.91016685492203 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark28(-62.91462544974704 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark28(-62.976788731960156 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark28(-62.979026726555155 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark28(-63.003001161386926 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark28(-63.052704356575376 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark28(-63.12200267054011 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark28(-63.13448564514952 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark28(-63.168698019219384 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark28(-63.16933340363362 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark28(-63.187223806176675 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark28(-63.207361655193765 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark28(-63.27112253847502 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark28(-63.288898556355136 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark28(-63.37760424017957 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark28(-63.41125373973706 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark28(-63.42046919318689 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark28(-63.437491502892776 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark28(-63.47369725273535 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark28(-63.47844352938709 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark28(-63.7667573533647 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark28(-63.82288888856347 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark28(-63.82679756634468 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark28(-63.835184040101154 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark28(-63.89413424933914 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark28(-63.91750086471226 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark28(-63.9534763896904 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark28(-64.03457686777318 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark28(-64.04200591693959 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark28(-64.05387895004355 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark28(-64.12778986749414 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark28(-64.13181592763891 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark28(-64.16329636337034 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark28(-64.19032686692083 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark28(-64.27018154986091 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark28(-64.27350656217655 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark28(-6.428364146336321 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark28(-64.30728130350471 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark28(-64.35080331579769 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark28(-64.36077850181476 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark28(-64.3632613869914 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark28(-64.46804843685987 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark28(-64.47306596175966 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark28(-64.51854654516956 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark28(-64.59077124283736 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark28(-64.61965311620344 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark28(-64.6297710146726 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark28(-64.63464489506754 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark28(-64.65639097126609 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark28(-64.65924800793547 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark28(-64.69238579939996 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark28(-64.6948056937585 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark28(-64.70187131956303 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark28(-64.79005962048555 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark28(-64.84171246150379 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark28(-6.487762272056116 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark28(-64.91248799316594 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark28(-64.97741752322383 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark28(-6.503786078962335 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark28(-65.09234825270897 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark28(-65.19547614926309 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark28(-65.22362635081296 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark28(-6.522461762333663 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark28(-65.23282916009012 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark28(-65.23297717515595 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark28(-65.23454269464999 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark28(-6.524745062088982 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark28(-65.26169462053471 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark28(-65.26610830654107 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark28(-65.2929029917417 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark28(-65.3013913778546 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark28(-65.30194411089813 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark28(-65.39536968946913 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark28(-65.46642132474467 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark28(-65.53092586877682 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark28(-65.53838102439435 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark28(-65.63242076357936 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark28(-65.65845868650092 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark28(-65.66198874951696 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark28(-65.71267286999421 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark28(-65.76449842881398 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark28(-65.80240323800496 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark28(-65.8708821872042 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark28(-65.87536128429514 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark28(-65.88533763870001 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark28(-65.90216542461306 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark28(-66.03884127450281 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark28(-6.611388662595857 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark28(-66.1150246993725 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark28(-66.12246531167602 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark28(-66.13247663048915 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark28(-66.15063969230495 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark28(-66.34235862460841 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark28(-66.34292117072442 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark28(-66.377418272674 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark28(-66.40869571919983 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark28(-6.640941754838295 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark28(-6.663428475064066 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark28(-66.65128936274232 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark28(-66.66881454876153 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark28(-6.66694232244231 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark28(-66.72752232480383 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark28(-66.74333203002027 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark28(-66.7453979569986 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark28(-66.75681313150147 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark28(-66.83261053098073 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark28(-66.8511091167457 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark28(-66.8624920857556 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark28(-66.88176814030346 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark28(-66.88665768577029 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark28(-66.93365237252209 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark28(-67.03139907679427 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark28(-67.08695114673868 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark28(-67.09015302243246 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark28(-67.12462373102441 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark28(-67.12649087216833 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark28(-67.1279663313062 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark28(-6.714546962233328 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark28(-67.19712916014105 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark28(-67.22751630123068 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark28(-67.3017869660905 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark28(-67.30425920348418 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark28(-67.33228784853608 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark28(-67.35377539880648 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark28(-67.37514845124883 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark28(-67.38987204156821 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark28(-67.39879784278986 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark28(-67.46617095187379 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark28(-67.47462378609009 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark28(-67.51897430034404 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark28(-67.51996898002241 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark28(-67.5759621003321 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark28(-67.71707643638638 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark28(-67.72649206223855 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark28(-67.7353762966491 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark28(-67.79837789320908 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark28(-67.80445323724564 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark28(-67.8187134141319 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark28(-67.82191366574462 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark28(-67.82645838850807 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark28(-67.83271934040233 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark28(-67.87500362359967 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark28(-67.88339464429566 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark28(-67.89218957016132 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark28(-67.90093841350765 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark28(-67.90938875937817 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark28(-67.92173140340563 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark28(-67.9314595663478 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark28(-67.93436124357711 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark28(-6.7961624156857425 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark28(-67.99161416420867 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark28(-68.05093540287521 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark28(-68.16891399090372 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark28(-6.819866811357599 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark28(-68.2069078796772 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark28(-68.20844590840073 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark28(-68.26929763696074 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark28(-68.279846585208 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark28(-68.3232213916699 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark28(-68.33265750888391 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark28(-68.3591039007279 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark28(-68.36489873942404 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark28(-68.4045871369884 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark28(-68.40915369217609 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark28(-68.42519276386909 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark28(-68.43696716705117 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark28(-68.49382373927145 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark28(-68.57705211391554 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark28(-68.61081556720137 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark28(-68.66220394540865 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark28(-68.70792468029998 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark28(-68.7794348740709 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark28(-68.79395198731788 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark28(-68.8838680013214 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark28(-68.93127265692351 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark28(-68.970811495357 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark28(-69.00659903462247 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark28(-69.00775728146711 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark28(-69.02464989566262 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark28(-69.03332478360642 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark28(-69.03496918232621 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark28(-69.0476094294902 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark28(-69.10750024200112 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark28(-69.19829693631175 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark28(-69.2195891716638 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark28(-69.25471139204409 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark28(-6.928012543153585 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark28(-69.3773309361537 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark28(-69.38687005708385 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark28(-69.46180370599501 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark28(-6.9462892953459345 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark28(-69.47404286798795 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark28(-69.47901647836645 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark28(-69.54118489907964 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark28(-69.62703562909418 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark28(-6.963710327978816 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark28(-6.969003366888344 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark28(-69.69834612302317 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark28(-69.80903692012872 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark28(-69.81176263873748 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark28(-69.83414567837853 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark28(-69.85552849407877 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark28(-69.8828117049969 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark28(-69.9116832137334 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark28(-69.94664137731746 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark28(-69.95047108156834 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark28(-6.996565820889657 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark28(-70.00189616418749 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark28(-70.01449384715319 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark28(-70.01831965912496 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark28(-70.09644225900335 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark28(-70.14823360624432 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark28(-7.018177243701643 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark28(-70.23877970617636 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark28(-70.33664644831457 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark28(-70.3371915358439 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark28(-70.36773799337672 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark28(-70.37213006017163 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark28(-70.45681213924888 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark28(-70.53635756102781 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark28(-70.5544316026464 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark28(-7.0556146791884515 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark28(-70.5948538610772 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark28(-70.64216187351829 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark28(-70.6819930095621 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark28(-70.72630204738462 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark28(-70.72995874813577 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark28(-70.77632309764543 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark28(-70.87010387543826 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark28(-70.91357478772775 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark28(-7.092094783720171 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark28(-70.92323731764594 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark28(-70.93262373811953 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark28(-7.094174042640432 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark28(-70.96178094330456 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark28(-70.9990175518156 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark28(-71.05804672361025 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark28(-71.13394085614945 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark28(-71.16631035090973 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark28(-71.24771261255079 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark28(-71.30276130284065 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark28(-71.30348550821826 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark28(-7.130392527391294 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark28(-71.34689125430444 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark28(-71.37023514009468 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark28(-71.40587620452831 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark28(-71.43290523843396 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark28(-71.44334421445417 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark28(-7.154751575916293 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark28(-71.61029146576399 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark28(-7.165521962503078 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark28(-71.7457739578515 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark28(-71.7505925774633 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark28(-71.75093732318231 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark28(-71.81942681003068 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark28(-71.83527799134208 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark28(-71.89478483991971 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark28(-71.89690900484953 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark28(-71.94787361927577 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark28(-71.95339502033227 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark28(-71.96935305256416 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark28(-71.97267312838349 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark28(-71.98262743468015 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark28(-72.00962212172223 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark28(-72.0268520028145 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark28(-72.05654964071924 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark28(-72.12164240432716 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark28(-72.12526078403826 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark28(-72.1352407701481 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark28(-72.24228311650778 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark28(-72.25759128161972 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark28(-72.28943830478613 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark28(-7.23155573145695 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark28(-72.34633870390199 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark28(-72.36502731372366 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark28(-72.40591136559466 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark28(-72.44851081375027 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark28(-72.4565507939876 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark28(-72.48123601051766 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark28(-72.49255172556508 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark28(-72.50836828789433 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark28(-72.54885458682325 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark28(-72.64126109334612 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark28(-72.6450227442196 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark28(-72.65465950083544 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark28(-72.6779406088537 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark28(-72.71053850376754 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark28(-72.71701590384608 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark28(-72.73741135985294 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark28(-72.74835202226535 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark28(-72.75328860738261 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark28(-72.8115615216511 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark28(-72.84523711575035 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark28(-7.2880414069122565 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark28(-72.88687192820389 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark28(-72.92820268777808 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark28(-73.02609341657259 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark28(-73.0485394409381 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark28(-73.05660771338495 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark28(-73.09293376489083 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark28(-73.14857324853286 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark28(-73.23498269086319 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark28(-73.29511202329738 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark28(-73.30263626055753 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark28(-73.35215302412215 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark28(-73.3667179586324 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark28(-73.39447139432397 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark28(-73.39963886194533 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark28(-73.4312146099279 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark28(-73.47658946602766 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark28(-73.56814730183807 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark28(-73.58591803082753 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark28(-73.59442140517147 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark28(-73.60703325707006 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark28(-73.63940138117518 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark28(-73.68555005400177 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark28(-73.69502569693603 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark28(-73.72464998851271 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark28(-73.76078109230646 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark28(-73.7704039617798 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark28(-73.79114649044052 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark28(-73.80467890778758 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark28(-73.81375772652554 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark28(-73.8409409895652 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark28(-73.91745297556021 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark28(-73.95915320777775 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark28(-7.41872500559937 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark28(-74.22823305281143 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark28(-74.24465804990186 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark28(-74.24981547560836 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark28(-74.3094682992475 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark28(-74.32134477995311 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark28(-74.32458306483771 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark28(-74.33710152287398 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark28(-7.435874672622717 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark28(-74.37739239051695 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark28(-74.41362118488306 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark28(-74.53052424704627 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark28(-74.62455591860703 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark28(-74.63736634228641 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark28(-74.69667390270271 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark28(-74.70967883877866 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark28(-74.72919571945107 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark28(-74.78198580800246 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark28(-7.479189428087892 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark28(-74.80860553927667 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark28(-74.81174000916522 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark28(-74.81605723664282 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark28(-74.81647025432913 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark28(-74.84694446077675 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark28(-74.91349357556336 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark28(-74.92994254461063 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark28(-74.93880527725966 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark28(-74.96064452020612 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark28(-74.98631582592732 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark28(-75.009241913055 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark28(-75.05821477270584 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark28(-75.0756380025303 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark28(-75.14610119895588 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark28(-75.1592560558889 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark28(-75.17126634734387 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark28(-75.19116307444915 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark28(-75.24475790484468 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark28(-75.25853530488105 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark28(-75.28052578634497 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark28(-75.28469997502827 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark28(-75.32693247793196 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark28(-7.539574197456588 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark28(-75.41724019718947 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark28(-75.41855851804388 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark28(-75.43390060827318 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark28(-75.5777046798274 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark28(-75.58630993993638 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark28(-75.63533178260349 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark28(-75.68410360960823 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark28(-75.71054942872675 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark28(-75.73094411092154 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark28(-75.73431514359126 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark28(-75.87804105428948 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark28(-75.88996849113687 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark28(-75.89451027812723 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark28(-75.89566078439891 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark28(-75.89815376556635 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark28(-75.94947212408785 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark28(-7.6086673789371275 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark28(-76.09260934775776 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark28(-7.6180073751554715 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark28(-76.19536407205823 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark28(-76.22867332157735 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark28(-76.31458142842385 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark28(-76.33942264060234 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark28(-76.34976657758799 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark28(-76.37870131525455 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark28(-76.41110800819638 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark28(-7.652100194480482 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark28(-76.52575639408346 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark28(-76.53798722412745 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark28(-76.58645304461032 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark28(-76.66566946580514 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark28(-7.667043723604564 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark28(-76.69146676412555 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark28(-76.74820666676227 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark28(-76.76049356328183 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark28(-76.83866335297607 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark28(-76.85651190835728 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark28(-76.85921104098547 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark28(-76.88490772898223 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark28(-76.94962744560536 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark28(-7.697154276120855 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark28(-76.97319913689664 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark28(-76.9908046645641 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark28(-77.252603944323 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark28(-7.727522423532562 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark28(-77.32715353421554 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark28(-77.3424489635195 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark28(-77.38259568152577 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark28(-77.4254905251278 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark28(-77.46264346251863 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark28(-77.50559512813602 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark28(-77.5102650116983 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark28(-7.757424218880018 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark28(-77.6280181667868 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark28(-77.63359048971714 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark28(-77.63734096671062 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark28(-77.6893424575942 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark28(-77.72538525408707 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark28(-77.76014076139133 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark28(-77.79591777046662 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark28(-77.8049730777571 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark28(-77.84527241981925 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark28(-77.9024207259248 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark28(-77.95436974281584 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark28(-78.00008002620496 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark28(-7.800616679058365 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark28(-78.01795104115934 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark28(-78.06302691481797 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark28(-78.07514350221999 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark28(-78.08379790881747 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark28(-78.10483426265328 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark28(-78.15416412875365 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark28(-78.18642496483326 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark28(-78.22847849083267 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark28(-78.25583598919164 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark28(-78.26271259736188 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark28(-78.26892287304925 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark28(-78.27305387024643 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark28(-78.36003444781056 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark28(-78.37689169131895 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark28(-78.40072801965363 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark28(-78.4196942812259 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark28(-7.845342994134953 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark28(-78.50777405943312 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark28(-7.853675917176702 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark28(-78.56297117920869 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark28(-78.594025905081 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark28(-78.68945365109165 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark28(-78.76375308385941 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark28(-78.76960587768258 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark28(-78.82970263604662 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark28(-78.84556667220413 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark28(-78.87088580310632 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark28(-78.89110620946795 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark28(-78.90758631316962 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark28(-78.94464706616068 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark28(-78.94645221524534 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark28(-78.95969422593336 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark28(-79.01300144443547 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark28(-79.02181335928731 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark28(-79.0883446843429 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark28(-79.15893816636628 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark28(-79.17163738409755 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark28(-79.22421931710136 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark28(-79.28240072855834 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark28(-79.32657030868278 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark28(-79.39236283289435 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark28(-79.39972226766305 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark28(-79.43037300722106 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark28(-79.53485567782124 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark28(-79.56365332002079 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark28(-79.5648236122739 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark28(-79.58254869388715 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark28(-79.67945753218419 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark28(-79.69150292088274 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark28(-79.73431187937992 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark28(-79.74968123028867 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark28(-79.75687674265042 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark28(-79.76047585153316 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark28(-79.77370897299856 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark28(-79.81491703169937 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark28(-79.82020422835232 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark28(-79.82556737552495 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark28(-79.92835046072304 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark28(-79.96614638746124 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark28(-79.99968615783337 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark28(-80.00683429260329 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark28(-80.03860919859528 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark28(-80.06842417979551 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark28(-80.08028783211161 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark28(-80.08073823383654 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark28(-80.08873944263865 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark28(-80.10476977754884 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark28(-80.14098488381636 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark28(-80.16100693375039 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark28(-80.16303463760326 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark28(-80.18898810424261 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark28(-80.20077577674414 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark28(-80.23343074453588 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark28(-80.23581905778985 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark28(-80.27921367501082 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark28(-80.2854564861005 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark28(-80.29856922285347 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark28(-80.35466345331604 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark28(-80.36781302191218 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark28(-80.37314245248264 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark28(-80.46315332788868 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark28(-8.047730447762788 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark28(-80.49994661627207 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark28(-80.62769244194166 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark28(-80.63136303398078 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark28(-80.70997513423002 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark28(-80.71561620298377 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark28(-80.72225212021856 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark28(-80.77742188789551 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark28(-8.087820991367977 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark28(-80.89898010698681 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark28(-80.90737481636961 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark28(-80.91433371091914 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark28(-81.02846513449188 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark28(-81.09247660173331 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark28(-81.1140666021592 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark28(-81.12150636650995 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark28(-81.14676814481857 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark28(-81.16835027723181 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark28(-81.17994294559689 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark28(-81.1973718760959 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark28(-81.24722954022144 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark28(-81.31661341566294 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark28(-8.1364483471218 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark28(-81.3672282819459 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark28(-81.39958219765167 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark28(-8.145299618046309 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark28(-81.54917726548842 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark28(-81.62867736519395 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark28(-81.63256369077195 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark28(-81.64289901206851 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark28(-81.65026535648596 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark28(-81.65354931810089 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark28(-81.66248508732991 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark28(-81.66821581719188 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark28(-8.171600193340268 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark28(-81.72041425548392 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark28(-81.75164610860466 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark28(-81.78940342616619 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark28(-81.80696335826802 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark28(-81.81289976492772 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark28(-81.81677459405296 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark28(-81.85019311029266 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark28(-81.86162816309313 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark28(-81.87026556907725 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark28(-81.87869283831337 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark28(-8.188107061407976 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark28(-81.88846764315285 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark28(-81.9199751488868 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark28(-82.01679348106528 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark28(-82.02996634899544 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark28(-82.08366621964882 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark28(-82.11175375738327 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark28(-82.1323804382442 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark28(-82.13536455281836 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark28(-82.2284775688431 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark28(-82.24829550819 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark28(-82.26759732544105 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark28(-82.30248169471449 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark28(-82.34591603759891 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark28(-82.3466858638654 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark28(-82.35611642342081 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark28(-82.39753781421275 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark28(-82.40564459531537 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark28(-82.48277192517193 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark28(-8.249164248148034 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark28(-82.49744078639722 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark28(-82.5278967231636 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark28(-82.52961820666731 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark28(-82.55365889464059 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark28(-82.56129380093424 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark28(-82.5754748953074 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark28(-82.58239429133107 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark28(-82.58545128058094 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark28(-82.59196159544206 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark28(-82.59690033719224 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark28(-82.61138567975902 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark28(-82.62618184679684 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark28(-82.63166790895309 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark28(-82.7370943931848 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark28(-82.74953372623723 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark28(-82.79860648863749 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark28(-82.80099508355003 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark28(-82.81233898863715 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark28(-82.84808117279675 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark28(-82.8670690954292 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark28(-82.94268135459748 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark28(-82.98913249109677 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark28(-83.0568681251436 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark28(-83.30487390911489 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark28(-83.34801706124114 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark28(-83.37902622504564 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark28(-83.40776602717298 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark28(-8.343419404434968 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark28(-83.44683643327879 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark28(-83.44887256367952 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark28(-83.48465508523492 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark28(-83.49878150798422 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark28(-83.49883949520384 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark28(-83.5281837287027 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark28(-83.53489716222451 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark28(-83.56739089115158 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark28(-83.67870026217864 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark28(-83.75281637521515 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark28(-83.75746024233048 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark28(-83.80583745819048 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark28(-83.85385694089092 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark28(-83.8692726625604 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark28(-8.394038041442613 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark28(-8.397131600651193 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark28(-83.9936894246168 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark28(-83.99908666777154 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark28(-84.0661526740388 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark28(-84.0836486407941 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark28(-84.1007004202857 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark28(-84.12351511599792 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark28(-84.13099103186175 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark28(-84.18859364102069 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark28(-84.29659446375521 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark28(-84.33902715006711 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark28(-84.34292564798733 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark28(-84.47068847682758 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark28(-84.47231638825694 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark28(-84.52290539221164 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark28(-84.53057794534844 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark28(-84.63521590374478 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark28(-84.67024798753988 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark28(-84.6944256170126 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark28(-84.71995398136947 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark28(-84.79128373787306 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark28(-84.85340578540375 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark28(-84.90750793129327 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark28(-84.91756873048912 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark28(-84.93266500641565 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark28(-84.95201481810331 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark28(-84.99164993240005 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark28(-85.02255435921109 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark28(-85.05335340942968 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark28(-85.06020326478132 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark28(-85.07910629893229 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark28(-85.18362753806502 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark28(-85.32065309253582 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark28(-85.38131799083052 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark28(-85.38316084108757 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark28(-8.539028246022795 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark28(-85.41670400221733 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark28(-8.55823471138389 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark28(-8.56173085249688 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark28(-85.69419793479187 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark28(-85.72999070990844 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark28(-85.73342180153283 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark28(-85.73569068108222 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark28(-85.74096957628575 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark28(-85.85287938977986 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark28(-85.8565619518673 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark28(-85.93113668747661 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark28(-85.9443841993468 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark28(-85.94598563096783 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark28(-8.595307527909085 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark28(-85.96726340052192 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark28(-85.99724127076593 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark28(-86.09838567529668 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark28(-86.09868355780299 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark28(-86.10283347379573 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark28(-86.14433802421154 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark28(-86.14642996627046 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark28(-86.16235637914312 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark28(-86.18333104440362 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark28(-86.21066949039724 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark28(-86.22708459117268 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark28(-86.23248414156892 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark28(-86.31554344589361 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark28(-86.31882987071175 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark28(-86.31965252550546 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark28(-86.35526855396344 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark28(-86.41417890100914 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark28(-86.5089847500508 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark28(-86.51154243454813 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark28(-86.52691556655405 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark28(-86.5676247256062 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark28(-86.6430585106855 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark28(-86.75847809910144 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark28(-8.676487278143298 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark28(-86.85920464461019 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark28(-86.8828554914046 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark28(-86.92130858260747 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark28(-86.92423451992077 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark28(-87.00522590324215 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark28(-87.01614669656814 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark28(-8.703539368943993 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark28(-87.05813236100828 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark28(-87.0816080531599 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark28(-87.13434424514097 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark28(-87.14783612376522 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark28(-87.19641540960154 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark28(-87.22595018858195 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark28(-87.311765711938 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark28(-87.37308177189539 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark28(-87.37673619340988 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark28(-87.38767565071446 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark28(-87.44784055018602 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark28(-87.46987603790622 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark28(-87.47209101663877 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark28(-87.4729766048483 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark28(-87.4774072940565 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark28(-87.51601922801547 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark28(-87.5923885920433 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark28(-87.60445597700866 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark28(-87.65932087258363 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark28(-87.68350510188516 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark28(-87.70743447174594 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark28(-87.72981804606594 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark28(-87.74435334277015 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark28(-87.74620250478134 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark28(-8.780356716480625 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark28(-87.85064101456967 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark28(-87.94839919590807 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark28(-87.97126846931324 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark28(-87.98083593792339 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark28(-87.99218203545469 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark28(-8.806396402986437 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark28(-88.11973911574907 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark28(-88.2350373540677 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark28(-8.823648020288516 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark28(-88.29637950481934 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark28(-88.3006382910456 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark28(-8.833014918306787 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark28(-88.34346067705391 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark28(-88.41474100937927 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark28(-8.846090949698478 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark28(-88.47320659282651 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark28(-88.48948817410482 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark28(-88.49833723884953 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark28(-88.54865635420992 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark28(-88.59736558458985 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark28(-88.59976409990003 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark28(-88.77584362940479 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark28(-88.78011465967207 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark28(-88.78667279117856 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark28(-88.83274176261745 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark28(-88.85360833842213 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark28(-88.86176177668163 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark28(-88.86430532192227 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark28(-88.88524465414112 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark28(-88.89589252871164 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark28(-88.98476946353118 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark28(-89.01772670550389 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark28(-89.05924396845084 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark28(-89.08889044970638 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark28(-89.10882815927165 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark28(-89.11372554317742 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark28(-89.11462674590214 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark28(-89.1960850982974 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark28(-89.21174875522351 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark28(-89.26585809744729 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark28(-89.34373222300694 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark28(-89.3581379228768 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark28(-89.37096579118429 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark28(-89.4017436977698 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark28(-89.41117601728573 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark28(-89.41538119997487 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark28(-89.44472932240936 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark28(-89.51089391226932 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark28(-89.51435864487753 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark28(-89.54333318118044 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark28(-89.55042567598481 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark28(-89.61986435891751 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark28(-89.64354308057476 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark28(-89.66437885496718 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark28(-89.68027440618127 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark28(-89.72978683879265 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark28(-89.764046800721 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark28(-89.8102487803464 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark28(-89.81479059964623 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark28(-89.827536487468 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark28(-89.8779763785578 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark28(-89.93521286662202 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark28(-89.99591341710223 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark28(-90.09043910972308 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark28(-90.11020955723865 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark28(-9.013227944750042 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark28(-9.015382156063083 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark28(-90.22219368048158 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark28(-9.024271045437743 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark28(-90.24993697613715 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark28(-90.30097703046513 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark28(-90.37359646246692 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark28(-90.37678638533843 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark28(-90.47874511809523 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark28(-90.48997608999758 ) ;
  }

  @Test
  public void test2476() {
    coral.tests.JPFBenchmark.benchmark28(-90.52183058297413 ) ;
  }

  @Test
  public void test2477() {
    coral.tests.JPFBenchmark.benchmark28(-90.52437351014599 ) ;
  }

  @Test
  public void test2478() {
    coral.tests.JPFBenchmark.benchmark28(-90.58951279564846 ) ;
  }

  @Test
  public void test2479() {
    coral.tests.JPFBenchmark.benchmark28(-90.60368970507344 ) ;
  }

  @Test
  public void test2480() {
    coral.tests.JPFBenchmark.benchmark28(-9.065197321584463 ) ;
  }

  @Test
  public void test2481() {
    coral.tests.JPFBenchmark.benchmark28(-9.069041803086165 ) ;
  }

  @Test
  public void test2482() {
    coral.tests.JPFBenchmark.benchmark28(-9.082995371523637 ) ;
  }

  @Test
  public void test2483() {
    coral.tests.JPFBenchmark.benchmark28(-90.92851558525297 ) ;
  }

  @Test
  public void test2484() {
    coral.tests.JPFBenchmark.benchmark28(-90.96063334665905 ) ;
  }

  @Test
  public void test2485() {
    coral.tests.JPFBenchmark.benchmark28(-90.97306948987676 ) ;
  }

  @Test
  public void test2486() {
    coral.tests.JPFBenchmark.benchmark28(-91.01296621579478 ) ;
  }

  @Test
  public void test2487() {
    coral.tests.JPFBenchmark.benchmark28(-91.02910715532877 ) ;
  }

  @Test
  public void test2488() {
    coral.tests.JPFBenchmark.benchmark28(-91.0753364451145 ) ;
  }

  @Test
  public void test2489() {
    coral.tests.JPFBenchmark.benchmark28(-9.10861032813051 ) ;
  }

  @Test
  public void test2490() {
    coral.tests.JPFBenchmark.benchmark28(-91.12143279446522 ) ;
  }

  @Test
  public void test2491() {
    coral.tests.JPFBenchmark.benchmark28(-91.12369850941968 ) ;
  }

  @Test
  public void test2492() {
    coral.tests.JPFBenchmark.benchmark28(-91.1334559011194 ) ;
  }

  @Test
  public void test2493() {
    coral.tests.JPFBenchmark.benchmark28(-9.120615413822591 ) ;
  }

  @Test
  public void test2494() {
    coral.tests.JPFBenchmark.benchmark28(-91.27536189475711 ) ;
  }

  @Test
  public void test2495() {
    coral.tests.JPFBenchmark.benchmark28(-91.27571715439917 ) ;
  }

  @Test
  public void test2496() {
    coral.tests.JPFBenchmark.benchmark28(-91.2883510870975 ) ;
  }

  @Test
  public void test2497() {
    coral.tests.JPFBenchmark.benchmark28(-91.32693331681814 ) ;
  }

  @Test
  public void test2498() {
    coral.tests.JPFBenchmark.benchmark28(91.33910489522748 ) ;
  }

  @Test
  public void test2499() {
    coral.tests.JPFBenchmark.benchmark28(-91.43369510394308 ) ;
  }

  @Test
  public void test2500() {
    coral.tests.JPFBenchmark.benchmark28(-91.53889569896394 ) ;
  }

  @Test
  public void test2501() {
    coral.tests.JPFBenchmark.benchmark28(-91.55003678224223 ) ;
  }

  @Test
  public void test2502() {
    coral.tests.JPFBenchmark.benchmark28(-91.56470076487591 ) ;
  }

  @Test
  public void test2503() {
    coral.tests.JPFBenchmark.benchmark28(-91.57768462008897 ) ;
  }

  @Test
  public void test2504() {
    coral.tests.JPFBenchmark.benchmark28(-91.65705404773112 ) ;
  }

  @Test
  public void test2505() {
    coral.tests.JPFBenchmark.benchmark28(-91.69494515237258 ) ;
  }

  @Test
  public void test2506() {
    coral.tests.JPFBenchmark.benchmark28(-91.74106132000466 ) ;
  }

  @Test
  public void test2507() {
    coral.tests.JPFBenchmark.benchmark28(-91.78932799430387 ) ;
  }

  @Test
  public void test2508() {
    coral.tests.JPFBenchmark.benchmark28(-91.7908380269895 ) ;
  }

  @Test
  public void test2509() {
    coral.tests.JPFBenchmark.benchmark28(-91.8257274103926 ) ;
  }

  @Test
  public void test2510() {
    coral.tests.JPFBenchmark.benchmark28(-91.83750039864908 ) ;
  }

  @Test
  public void test2511() {
    coral.tests.JPFBenchmark.benchmark28(-91.97975898618532 ) ;
  }

  @Test
  public void test2512() {
    coral.tests.JPFBenchmark.benchmark28(-91.9899709238658 ) ;
  }

  @Test
  public void test2513() {
    coral.tests.JPFBenchmark.benchmark28(-91.9945845841128 ) ;
  }

  @Test
  public void test2514() {
    coral.tests.JPFBenchmark.benchmark28(-92.00412520746433 ) ;
  }

  @Test
  public void test2515() {
    coral.tests.JPFBenchmark.benchmark28(-92.03607048077778 ) ;
  }

  @Test
  public void test2516() {
    coral.tests.JPFBenchmark.benchmark28(-92.0419135720121 ) ;
  }

  @Test
  public void test2517() {
    coral.tests.JPFBenchmark.benchmark28(-92.07497882560749 ) ;
  }

  @Test
  public void test2518() {
    coral.tests.JPFBenchmark.benchmark28(-92.08434790893753 ) ;
  }

  @Test
  public void test2519() {
    coral.tests.JPFBenchmark.benchmark28(-92.0893260567243 ) ;
  }

  @Test
  public void test2520() {
    coral.tests.JPFBenchmark.benchmark28(-92.15306275130482 ) ;
  }

  @Test
  public void test2521() {
    coral.tests.JPFBenchmark.benchmark28(-92.2336233893806 ) ;
  }

  @Test
  public void test2522() {
    coral.tests.JPFBenchmark.benchmark28(-92.23900106323664 ) ;
  }

  @Test
  public void test2523() {
    coral.tests.JPFBenchmark.benchmark28(-92.29171768345894 ) ;
  }

  @Test
  public void test2524() {
    coral.tests.JPFBenchmark.benchmark28(-92.31925969897208 ) ;
  }

  @Test
  public void test2525() {
    coral.tests.JPFBenchmark.benchmark28(-92.37867939657616 ) ;
  }

  @Test
  public void test2526() {
    coral.tests.JPFBenchmark.benchmark28(-92.39018966472958 ) ;
  }

  @Test
  public void test2527() {
    coral.tests.JPFBenchmark.benchmark28(-92.42440697219574 ) ;
  }

  @Test
  public void test2528() {
    coral.tests.JPFBenchmark.benchmark28(-92.43048456748193 ) ;
  }

  @Test
  public void test2529() {
    coral.tests.JPFBenchmark.benchmark28(-92.43459080886768 ) ;
  }

  @Test
  public void test2530() {
    coral.tests.JPFBenchmark.benchmark28(-92.43613498383989 ) ;
  }

  @Test
  public void test2531() {
    coral.tests.JPFBenchmark.benchmark28(-9.244822066484886 ) ;
  }

  @Test
  public void test2532() {
    coral.tests.JPFBenchmark.benchmark28(-92.46036894552896 ) ;
  }

  @Test
  public void test2533() {
    coral.tests.JPFBenchmark.benchmark28(-92.51984529543282 ) ;
  }

  @Test
  public void test2534() {
    coral.tests.JPFBenchmark.benchmark28(-92.6119241539759 ) ;
  }

  @Test
  public void test2535() {
    coral.tests.JPFBenchmark.benchmark28(-92.64877279516732 ) ;
  }

  @Test
  public void test2536() {
    coral.tests.JPFBenchmark.benchmark28(-92.71451560461878 ) ;
  }

  @Test
  public void test2537() {
    coral.tests.JPFBenchmark.benchmark28(-92.74398862217052 ) ;
  }

  @Test
  public void test2538() {
    coral.tests.JPFBenchmark.benchmark28(-92.75685887198424 ) ;
  }

  @Test
  public void test2539() {
    coral.tests.JPFBenchmark.benchmark28(-9.279868094884009 ) ;
  }

  @Test
  public void test2540() {
    coral.tests.JPFBenchmark.benchmark28(-92.80713118226183 ) ;
  }

  @Test
  public void test2541() {
    coral.tests.JPFBenchmark.benchmark28(-92.8416950039913 ) ;
  }

  @Test
  public void test2542() {
    coral.tests.JPFBenchmark.benchmark28(-92.86783881194796 ) ;
  }

  @Test
  public void test2543() {
    coral.tests.JPFBenchmark.benchmark28(-92.87474975342201 ) ;
  }

  @Test
  public void test2544() {
    coral.tests.JPFBenchmark.benchmark28(-92.89519736245279 ) ;
  }

  @Test
  public void test2545() {
    coral.tests.JPFBenchmark.benchmark28(-9.290487237063203 ) ;
  }

  @Test
  public void test2546() {
    coral.tests.JPFBenchmark.benchmark28(-92.97428292205079 ) ;
  }

  @Test
  public void test2547() {
    coral.tests.JPFBenchmark.benchmark28(-92.98164754050104 ) ;
  }

  @Test
  public void test2548() {
    coral.tests.JPFBenchmark.benchmark28(-93.07662147082105 ) ;
  }

  @Test
  public void test2549() {
    coral.tests.JPFBenchmark.benchmark28(-93.14296857054278 ) ;
  }

  @Test
  public void test2550() {
    coral.tests.JPFBenchmark.benchmark28(-9.325021973378838 ) ;
  }

  @Test
  public void test2551() {
    coral.tests.JPFBenchmark.benchmark28(-93.31058028126566 ) ;
  }

  @Test
  public void test2552() {
    coral.tests.JPFBenchmark.benchmark28(-93.3141296537027 ) ;
  }

  @Test
  public void test2553() {
    coral.tests.JPFBenchmark.benchmark28(-93.40101743203317 ) ;
  }

  @Test
  public void test2554() {
    coral.tests.JPFBenchmark.benchmark28(-93.41575772403796 ) ;
  }

  @Test
  public void test2555() {
    coral.tests.JPFBenchmark.benchmark28(-93.44145267330487 ) ;
  }

  @Test
  public void test2556() {
    coral.tests.JPFBenchmark.benchmark28(-93.47734865825419 ) ;
  }

  @Test
  public void test2557() {
    coral.tests.JPFBenchmark.benchmark28(-93.48451197771026 ) ;
  }

  @Test
  public void test2558() {
    coral.tests.JPFBenchmark.benchmark28(-93.4944945093023 ) ;
  }

  @Test
  public void test2559() {
    coral.tests.JPFBenchmark.benchmark28(-93.51514894487258 ) ;
  }

  @Test
  public void test2560() {
    coral.tests.JPFBenchmark.benchmark28(-93.53395387763605 ) ;
  }

  @Test
  public void test2561() {
    coral.tests.JPFBenchmark.benchmark28(-93.54502816433047 ) ;
  }

  @Test
  public void test2562() {
    coral.tests.JPFBenchmark.benchmark28(-93.57424566702386 ) ;
  }

  @Test
  public void test2563() {
    coral.tests.JPFBenchmark.benchmark28(-9.359622310708971 ) ;
  }

  @Test
  public void test2564() {
    coral.tests.JPFBenchmark.benchmark28(-93.59688207668664 ) ;
  }

  @Test
  public void test2565() {
    coral.tests.JPFBenchmark.benchmark28(-93.63419430968078 ) ;
  }

  @Test
  public void test2566() {
    coral.tests.JPFBenchmark.benchmark28(-93.68119552301815 ) ;
  }

  @Test
  public void test2567() {
    coral.tests.JPFBenchmark.benchmark28(-93.73101973857416 ) ;
  }

  @Test
  public void test2568() {
    coral.tests.JPFBenchmark.benchmark28(-93.73161907160701 ) ;
  }

  @Test
  public void test2569() {
    coral.tests.JPFBenchmark.benchmark28(-93.73646387120833 ) ;
  }

  @Test
  public void test2570() {
    coral.tests.JPFBenchmark.benchmark28(-93.74268914304744 ) ;
  }

  @Test
  public void test2571() {
    coral.tests.JPFBenchmark.benchmark28(-93.75938502096359 ) ;
  }

  @Test
  public void test2572() {
    coral.tests.JPFBenchmark.benchmark28(-93.79595534447608 ) ;
  }

  @Test
  public void test2573() {
    coral.tests.JPFBenchmark.benchmark28(-93.81645394783907 ) ;
  }

  @Test
  public void test2574() {
    coral.tests.JPFBenchmark.benchmark28(-93.90181910595207 ) ;
  }

  @Test
  public void test2575() {
    coral.tests.JPFBenchmark.benchmark28(-93.9102910330365 ) ;
  }

  @Test
  public void test2576() {
    coral.tests.JPFBenchmark.benchmark28(-93.96192588912986 ) ;
  }

  @Test
  public void test2577() {
    coral.tests.JPFBenchmark.benchmark28(-93.96906935944386 ) ;
  }

  @Test
  public void test2578() {
    coral.tests.JPFBenchmark.benchmark28(-93.98182066246538 ) ;
  }

  @Test
  public void test2579() {
    coral.tests.JPFBenchmark.benchmark28(-93.99757838193767 ) ;
  }

  @Test
  public void test2580() {
    coral.tests.JPFBenchmark.benchmark28(-94.01936011189657 ) ;
  }

  @Test
  public void test2581() {
    coral.tests.JPFBenchmark.benchmark28(-94.02867888686059 ) ;
  }

  @Test
  public void test2582() {
    coral.tests.JPFBenchmark.benchmark28(-94.04151902418687 ) ;
  }

  @Test
  public void test2583() {
    coral.tests.JPFBenchmark.benchmark28(-94.06384911154937 ) ;
  }

  @Test
  public void test2584() {
    coral.tests.JPFBenchmark.benchmark28(-94.06533019366692 ) ;
  }

  @Test
  public void test2585() {
    coral.tests.JPFBenchmark.benchmark28(-94.06840407154833 ) ;
  }

  @Test
  public void test2586() {
    coral.tests.JPFBenchmark.benchmark28(-94.08116827241642 ) ;
  }

  @Test
  public void test2587() {
    coral.tests.JPFBenchmark.benchmark28(-94.10400288258683 ) ;
  }

  @Test
  public void test2588() {
    coral.tests.JPFBenchmark.benchmark28(-94.17504484958121 ) ;
  }

  @Test
  public void test2589() {
    coral.tests.JPFBenchmark.benchmark28(-94.19771412174047 ) ;
  }

  @Test
  public void test2590() {
    coral.tests.JPFBenchmark.benchmark28(-94.23868612800759 ) ;
  }

  @Test
  public void test2591() {
    coral.tests.JPFBenchmark.benchmark28(-94.24183855260935 ) ;
  }

  @Test
  public void test2592() {
    coral.tests.JPFBenchmark.benchmark28(-94.25465069406975 ) ;
  }

  @Test
  public void test2593() {
    coral.tests.JPFBenchmark.benchmark28(-94.28172802246063 ) ;
  }

  @Test
  public void test2594() {
    coral.tests.JPFBenchmark.benchmark28(-94.28895864283449 ) ;
  }

  @Test
  public void test2595() {
    coral.tests.JPFBenchmark.benchmark28(-9.42922893347395 ) ;
  }

  @Test
  public void test2596() {
    coral.tests.JPFBenchmark.benchmark28(-94.34146634449792 ) ;
  }

  @Test
  public void test2597() {
    coral.tests.JPFBenchmark.benchmark28(-94.34491544432323 ) ;
  }

  @Test
  public void test2598() {
    coral.tests.JPFBenchmark.benchmark28(-9.441147139378714 ) ;
  }

  @Test
  public void test2599() {
    coral.tests.JPFBenchmark.benchmark28(-94.49990056306825 ) ;
  }

  @Test
  public void test2600() {
    coral.tests.JPFBenchmark.benchmark28(-9.450245813673305 ) ;
  }

  @Test
  public void test2601() {
    coral.tests.JPFBenchmark.benchmark28(-9.45174223139307 ) ;
  }

  @Test
  public void test2602() {
    coral.tests.JPFBenchmark.benchmark28(-94.59438339162831 ) ;
  }

  @Test
  public void test2603() {
    coral.tests.JPFBenchmark.benchmark28(-94.6074445033217 ) ;
  }

  @Test
  public void test2604() {
    coral.tests.JPFBenchmark.benchmark28(-94.63734744960801 ) ;
  }

  @Test
  public void test2605() {
    coral.tests.JPFBenchmark.benchmark28(-94.65442413083711 ) ;
  }

  @Test
  public void test2606() {
    coral.tests.JPFBenchmark.benchmark28(-94.68069115151134 ) ;
  }

  @Test
  public void test2607() {
    coral.tests.JPFBenchmark.benchmark28(-94.71167223636658 ) ;
  }

  @Test
  public void test2608() {
    coral.tests.JPFBenchmark.benchmark28(-94.74012883474971 ) ;
  }

  @Test
  public void test2609() {
    coral.tests.JPFBenchmark.benchmark28(-9.478935981460609 ) ;
  }

  @Test
  public void test2610() {
    coral.tests.JPFBenchmark.benchmark28(-94.80250786198343 ) ;
  }

  @Test
  public void test2611() {
    coral.tests.JPFBenchmark.benchmark28(-94.82093735091523 ) ;
  }

  @Test
  public void test2612() {
    coral.tests.JPFBenchmark.benchmark28(-94.83760701338191 ) ;
  }

  @Test
  public void test2613() {
    coral.tests.JPFBenchmark.benchmark28(-94.91401891750597 ) ;
  }

  @Test
  public void test2614() {
    coral.tests.JPFBenchmark.benchmark28(-9.509376185804626 ) ;
  }

  @Test
  public void test2615() {
    coral.tests.JPFBenchmark.benchmark28(-95.20583229592845 ) ;
  }

  @Test
  public void test2616() {
    coral.tests.JPFBenchmark.benchmark28(-95.23016215324228 ) ;
  }

  @Test
  public void test2617() {
    coral.tests.JPFBenchmark.benchmark28(-95.29672371143927 ) ;
  }

  @Test
  public void test2618() {
    coral.tests.JPFBenchmark.benchmark28(-95.31811928689524 ) ;
  }

  @Test
  public void test2619() {
    coral.tests.JPFBenchmark.benchmark28(-95.33657408764904 ) ;
  }

  @Test
  public void test2620() {
    coral.tests.JPFBenchmark.benchmark28(-95.36855608246104 ) ;
  }

  @Test
  public void test2621() {
    coral.tests.JPFBenchmark.benchmark28(-95.38935373598135 ) ;
  }

  @Test
  public void test2622() {
    coral.tests.JPFBenchmark.benchmark28(-95.40809833307644 ) ;
  }

  @Test
  public void test2623() {
    coral.tests.JPFBenchmark.benchmark28(-95.41449661918881 ) ;
  }

  @Test
  public void test2624() {
    coral.tests.JPFBenchmark.benchmark28(-95.58083108195548 ) ;
  }

  @Test
  public void test2625() {
    coral.tests.JPFBenchmark.benchmark28(-95.64426022829187 ) ;
  }

  @Test
  public void test2626() {
    coral.tests.JPFBenchmark.benchmark28(-95.74086410810543 ) ;
  }

  @Test
  public void test2627() {
    coral.tests.JPFBenchmark.benchmark28(-95.77935998890335 ) ;
  }

  @Test
  public void test2628() {
    coral.tests.JPFBenchmark.benchmark28(-95.78445964842008 ) ;
  }

  @Test
  public void test2629() {
    coral.tests.JPFBenchmark.benchmark28(-9.578813614621097 ) ;
  }

  @Test
  public void test2630() {
    coral.tests.JPFBenchmark.benchmark28(-95.7929690609265 ) ;
  }

  @Test
  public void test2631() {
    coral.tests.JPFBenchmark.benchmark28(-95.83543618107602 ) ;
  }

  @Test
  public void test2632() {
    coral.tests.JPFBenchmark.benchmark28(-95.93019485328892 ) ;
  }

  @Test
  public void test2633() {
    coral.tests.JPFBenchmark.benchmark28(-95.95738738292027 ) ;
  }

  @Test
  public void test2634() {
    coral.tests.JPFBenchmark.benchmark28(-95.95948848361193 ) ;
  }

  @Test
  public void test2635() {
    coral.tests.JPFBenchmark.benchmark28(-95.96195128130935 ) ;
  }

  @Test
  public void test2636() {
    coral.tests.JPFBenchmark.benchmark28(-95.99908909042483 ) ;
  }

  @Test
  public void test2637() {
    coral.tests.JPFBenchmark.benchmark28(-96.00353694326064 ) ;
  }

  @Test
  public void test2638() {
    coral.tests.JPFBenchmark.benchmark28(-96.05153608611967 ) ;
  }

  @Test
  public void test2639() {
    coral.tests.JPFBenchmark.benchmark28(-96.07422265105932 ) ;
  }

  @Test
  public void test2640() {
    coral.tests.JPFBenchmark.benchmark28(-96.07840228195596 ) ;
  }

  @Test
  public void test2641() {
    coral.tests.JPFBenchmark.benchmark28(-96.13412211971995 ) ;
  }

  @Test
  public void test2642() {
    coral.tests.JPFBenchmark.benchmark28(-9.613542022727415 ) ;
  }

  @Test
  public void test2643() {
    coral.tests.JPFBenchmark.benchmark28(-96.24483725222134 ) ;
  }

  @Test
  public void test2644() {
    coral.tests.JPFBenchmark.benchmark28(-96.25030310211939 ) ;
  }

  @Test
  public void test2645() {
    coral.tests.JPFBenchmark.benchmark28(-9.628527048971975 ) ;
  }

  @Test
  public void test2646() {
    coral.tests.JPFBenchmark.benchmark28(-96.33919492724894 ) ;
  }

  @Test
  public void test2647() {
    coral.tests.JPFBenchmark.benchmark28(-9.635224845408132 ) ;
  }

  @Test
  public void test2648() {
    coral.tests.JPFBenchmark.benchmark28(-96.38760137479298 ) ;
  }

  @Test
  public void test2649() {
    coral.tests.JPFBenchmark.benchmark28(-96.44274519397122 ) ;
  }

  @Test
  public void test2650() {
    coral.tests.JPFBenchmark.benchmark28(-96.46810494970823 ) ;
  }

  @Test
  public void test2651() {
    coral.tests.JPFBenchmark.benchmark28(-96.51262371276677 ) ;
  }

  @Test
  public void test2652() {
    coral.tests.JPFBenchmark.benchmark28(-96.57462586423328 ) ;
  }

  @Test
  public void test2653() {
    coral.tests.JPFBenchmark.benchmark28(-96.58096957465096 ) ;
  }

  @Test
  public void test2654() {
    coral.tests.JPFBenchmark.benchmark28(-96.59004697802544 ) ;
  }

  @Test
  public void test2655() {
    coral.tests.JPFBenchmark.benchmark28(-96.60358691224478 ) ;
  }

  @Test
  public void test2656() {
    coral.tests.JPFBenchmark.benchmark28(-96.62276550539413 ) ;
  }

  @Test
  public void test2657() {
    coral.tests.JPFBenchmark.benchmark28(-96.69634260879117 ) ;
  }

  @Test
  public void test2658() {
    coral.tests.JPFBenchmark.benchmark28(-96.75894274748553 ) ;
  }

  @Test
  public void test2659() {
    coral.tests.JPFBenchmark.benchmark28(-9.6805291164831 ) ;
  }

  @Test
  public void test2660() {
    coral.tests.JPFBenchmark.benchmark28(-96.84303288004332 ) ;
  }

  @Test
  public void test2661() {
    coral.tests.JPFBenchmark.benchmark28(-96.84833898716063 ) ;
  }

  @Test
  public void test2662() {
    coral.tests.JPFBenchmark.benchmark28(-96.88701098575663 ) ;
  }

  @Test
  public void test2663() {
    coral.tests.JPFBenchmark.benchmark28(-9.689483149343303 ) ;
  }

  @Test
  public void test2664() {
    coral.tests.JPFBenchmark.benchmark28(-96.9421669161767 ) ;
  }

  @Test
  public void test2665() {
    coral.tests.JPFBenchmark.benchmark28(-96.96948238909005 ) ;
  }

  @Test
  public void test2666() {
    coral.tests.JPFBenchmark.benchmark28(-96.99197156528227 ) ;
  }

  @Test
  public void test2667() {
    coral.tests.JPFBenchmark.benchmark28(-97.03414106126135 ) ;
  }

  @Test
  public void test2668() {
    coral.tests.JPFBenchmark.benchmark28(-97.04118895735824 ) ;
  }

  @Test
  public void test2669() {
    coral.tests.JPFBenchmark.benchmark28(-9.71080204301309 ) ;
  }

  @Test
  public void test2670() {
    coral.tests.JPFBenchmark.benchmark28(-9.71318015002889 ) ;
  }

  @Test
  public void test2671() {
    coral.tests.JPFBenchmark.benchmark28(-97.14305446930642 ) ;
  }

  @Test
  public void test2672() {
    coral.tests.JPFBenchmark.benchmark28(-97.14719010130499 ) ;
  }

  @Test
  public void test2673() {
    coral.tests.JPFBenchmark.benchmark28(-9.715298895149417 ) ;
  }

  @Test
  public void test2674() {
    coral.tests.JPFBenchmark.benchmark28(-97.17614756449291 ) ;
  }

  @Test
  public void test2675() {
    coral.tests.JPFBenchmark.benchmark28(-97.21863159366575 ) ;
  }

  @Test
  public void test2676() {
    coral.tests.JPFBenchmark.benchmark28(-97.26536354027522 ) ;
  }

  @Test
  public void test2677() {
    coral.tests.JPFBenchmark.benchmark28(-97.26783236506313 ) ;
  }

  @Test
  public void test2678() {
    coral.tests.JPFBenchmark.benchmark28(-97.30606901276573 ) ;
  }

  @Test
  public void test2679() {
    coral.tests.JPFBenchmark.benchmark28(-97.43266537416982 ) ;
  }

  @Test
  public void test2680() {
    coral.tests.JPFBenchmark.benchmark28(-97.44770999861134 ) ;
  }

  @Test
  public void test2681() {
    coral.tests.JPFBenchmark.benchmark28(-97.48881659122021 ) ;
  }

  @Test
  public void test2682() {
    coral.tests.JPFBenchmark.benchmark28(-97.49639519887606 ) ;
  }

  @Test
  public void test2683() {
    coral.tests.JPFBenchmark.benchmark28(-97.50512773565725 ) ;
  }

  @Test
  public void test2684() {
    coral.tests.JPFBenchmark.benchmark28(-97.54970491118569 ) ;
  }

  @Test
  public void test2685() {
    coral.tests.JPFBenchmark.benchmark28(-97.59607892430648 ) ;
  }

  @Test
  public void test2686() {
    coral.tests.JPFBenchmark.benchmark28(-97.60967876669343 ) ;
  }

  @Test
  public void test2687() {
    coral.tests.JPFBenchmark.benchmark28(-97.6175179366623 ) ;
  }

  @Test
  public void test2688() {
    coral.tests.JPFBenchmark.benchmark28(-9.763430006706969 ) ;
  }

  @Test
  public void test2689() {
    coral.tests.JPFBenchmark.benchmark28(-97.63622860643775 ) ;
  }

  @Test
  public void test2690() {
    coral.tests.JPFBenchmark.benchmark28(-97.65414419060987 ) ;
  }

  @Test
  public void test2691() {
    coral.tests.JPFBenchmark.benchmark28(-97.71346157345795 ) ;
  }

  @Test
  public void test2692() {
    coral.tests.JPFBenchmark.benchmark28(-97.72611096958892 ) ;
  }

  @Test
  public void test2693() {
    coral.tests.JPFBenchmark.benchmark28(-9.774225479321714 ) ;
  }

  @Test
  public void test2694() {
    coral.tests.JPFBenchmark.benchmark28(-97.75445599481772 ) ;
  }

  @Test
  public void test2695() {
    coral.tests.JPFBenchmark.benchmark28(-9.78436946370293 ) ;
  }

  @Test
  public void test2696() {
    coral.tests.JPFBenchmark.benchmark28(-97.87169645764982 ) ;
  }

  @Test
  public void test2697() {
    coral.tests.JPFBenchmark.benchmark28(-97.88173926829597 ) ;
  }

  @Test
  public void test2698() {
    coral.tests.JPFBenchmark.benchmark28(-97.8948592096966 ) ;
  }

  @Test
  public void test2699() {
    coral.tests.JPFBenchmark.benchmark28(-97.9335157911743 ) ;
  }

  @Test
  public void test2700() {
    coral.tests.JPFBenchmark.benchmark28(-97.95599602516059 ) ;
  }

  @Test
  public void test2701() {
    coral.tests.JPFBenchmark.benchmark28(-97.96431143978279 ) ;
  }

  @Test
  public void test2702() {
    coral.tests.JPFBenchmark.benchmark28(-97.9722565429604 ) ;
  }

  @Test
  public void test2703() {
    coral.tests.JPFBenchmark.benchmark28(-97.98777350298002 ) ;
  }

  @Test
  public void test2704() {
    coral.tests.JPFBenchmark.benchmark28(-97.99418256404797 ) ;
  }

  @Test
  public void test2705() {
    coral.tests.JPFBenchmark.benchmark28(-98.03393911923608 ) ;
  }

  @Test
  public void test2706() {
    coral.tests.JPFBenchmark.benchmark28(-98.06103698229455 ) ;
  }

  @Test
  public void test2707() {
    coral.tests.JPFBenchmark.benchmark28(-98.11681886167113 ) ;
  }

  @Test
  public void test2708() {
    coral.tests.JPFBenchmark.benchmark28(-98.1228267018067 ) ;
  }

  @Test
  public void test2709() {
    coral.tests.JPFBenchmark.benchmark28(-98.16411888786887 ) ;
  }

  @Test
  public void test2710() {
    coral.tests.JPFBenchmark.benchmark28(-98.30668913669467 ) ;
  }

  @Test
  public void test2711() {
    coral.tests.JPFBenchmark.benchmark28(-98.33529363683115 ) ;
  }

  @Test
  public void test2712() {
    coral.tests.JPFBenchmark.benchmark28(-98.42098322114326 ) ;
  }

  @Test
  public void test2713() {
    coral.tests.JPFBenchmark.benchmark28(-98.42372892950502 ) ;
  }

  @Test
  public void test2714() {
    coral.tests.JPFBenchmark.benchmark28(-98.45214441850378 ) ;
  }

  @Test
  public void test2715() {
    coral.tests.JPFBenchmark.benchmark28(-98.48060023872354 ) ;
  }

  @Test
  public void test2716() {
    coral.tests.JPFBenchmark.benchmark28(-9.849789346920758 ) ;
  }

  @Test
  public void test2717() {
    coral.tests.JPFBenchmark.benchmark28(-98.5086905824281 ) ;
  }

  @Test
  public void test2718() {
    coral.tests.JPFBenchmark.benchmark28(-98.53546359772658 ) ;
  }

  @Test
  public void test2719() {
    coral.tests.JPFBenchmark.benchmark28(-9.860761315262648E-32 ) ;
  }

  @Test
  public void test2720() {
    coral.tests.JPFBenchmark.benchmark28(-98.60958459898741 ) ;
  }

  @Test
  public void test2721() {
    coral.tests.JPFBenchmark.benchmark28(-98.62415640210165 ) ;
  }

  @Test
  public void test2722() {
    coral.tests.JPFBenchmark.benchmark28(-98.64094973952507 ) ;
  }

  @Test
  public void test2723() {
    coral.tests.JPFBenchmark.benchmark28(-98.67865773790744 ) ;
  }

  @Test
  public void test2724() {
    coral.tests.JPFBenchmark.benchmark28(-98.74132736215324 ) ;
  }

  @Test
  public void test2725() {
    coral.tests.JPFBenchmark.benchmark28(-98.75971745279686 ) ;
  }

  @Test
  public void test2726() {
    coral.tests.JPFBenchmark.benchmark28(-98.78593985333323 ) ;
  }

  @Test
  public void test2727() {
    coral.tests.JPFBenchmark.benchmark28(-9.879477946969857 ) ;
  }

  @Test
  public void test2728() {
    coral.tests.JPFBenchmark.benchmark28(-98.8072760847587 ) ;
  }

  @Test
  public void test2729() {
    coral.tests.JPFBenchmark.benchmark28(-98.82976520394023 ) ;
  }

  @Test
  public void test2730() {
    coral.tests.JPFBenchmark.benchmark28(-98.84962715058741 ) ;
  }

  @Test
  public void test2731() {
    coral.tests.JPFBenchmark.benchmark28(-98.8523334766683 ) ;
  }

  @Test
  public void test2732() {
    coral.tests.JPFBenchmark.benchmark28(-9.887387766282444 ) ;
  }

  @Test
  public void test2733() {
    coral.tests.JPFBenchmark.benchmark28(-98.87510817275778 ) ;
  }

  @Test
  public void test2734() {
    coral.tests.JPFBenchmark.benchmark28(-98.905650452684 ) ;
  }

  @Test
  public void test2735() {
    coral.tests.JPFBenchmark.benchmark28(-98.91256900377591 ) ;
  }

  @Test
  public void test2736() {
    coral.tests.JPFBenchmark.benchmark28(-98.91496939730774 ) ;
  }

  @Test
  public void test2737() {
    coral.tests.JPFBenchmark.benchmark28(-98.92492303552018 ) ;
  }

  @Test
  public void test2738() {
    coral.tests.JPFBenchmark.benchmark28(-98.92838024582255 ) ;
  }

  @Test
  public void test2739() {
    coral.tests.JPFBenchmark.benchmark28(-98.949783644647 ) ;
  }

  @Test
  public void test2740() {
    coral.tests.JPFBenchmark.benchmark28(-98.96696046039469 ) ;
  }

  @Test
  public void test2741() {
    coral.tests.JPFBenchmark.benchmark28(-98.9760112538465 ) ;
  }

  @Test
  public void test2742() {
    coral.tests.JPFBenchmark.benchmark28(-98.98090347173611 ) ;
  }

  @Test
  public void test2743() {
    coral.tests.JPFBenchmark.benchmark28(-9.900115713934724 ) ;
  }

  @Test
  public void test2744() {
    coral.tests.JPFBenchmark.benchmark28(-99.0324788608075 ) ;
  }

  @Test
  public void test2745() {
    coral.tests.JPFBenchmark.benchmark28(-99.06043536054948 ) ;
  }

  @Test
  public void test2746() {
    coral.tests.JPFBenchmark.benchmark28(-99.0622001825086 ) ;
  }

  @Test
  public void test2747() {
    coral.tests.JPFBenchmark.benchmark28(-99.07853947166299 ) ;
  }

  @Test
  public void test2748() {
    coral.tests.JPFBenchmark.benchmark28(-9.912609595358248 ) ;
  }

  @Test
  public void test2749() {
    coral.tests.JPFBenchmark.benchmark28(-9.91335403854336 ) ;
  }

  @Test
  public void test2750() {
    coral.tests.JPFBenchmark.benchmark28(-99.18464039364274 ) ;
  }

  @Test
  public void test2751() {
    coral.tests.JPFBenchmark.benchmark28(-99.2358759687037 ) ;
  }

  @Test
  public void test2752() {
    coral.tests.JPFBenchmark.benchmark28(-99.2599540524765 ) ;
  }

  @Test
  public void test2753() {
    coral.tests.JPFBenchmark.benchmark28(-99.26836658180271 ) ;
  }

  @Test
  public void test2754() {
    coral.tests.JPFBenchmark.benchmark28(-99.31371568447953 ) ;
  }

  @Test
  public void test2755() {
    coral.tests.JPFBenchmark.benchmark28(-99.34603251065492 ) ;
  }

  @Test
  public void test2756() {
    coral.tests.JPFBenchmark.benchmark28(-99.36018918020955 ) ;
  }

  @Test
  public void test2757() {
    coral.tests.JPFBenchmark.benchmark28(-99.36905694814482 ) ;
  }

  @Test
  public void test2758() {
    coral.tests.JPFBenchmark.benchmark28(-99.39354435036616 ) ;
  }

  @Test
  public void test2759() {
    coral.tests.JPFBenchmark.benchmark28(-99.42305638462057 ) ;
  }

  @Test
  public void test2760() {
    coral.tests.JPFBenchmark.benchmark28(-9.962062861638074 ) ;
  }

  @Test
  public void test2761() {
    coral.tests.JPFBenchmark.benchmark28(-99.68402979060922 ) ;
  }

  @Test
  public void test2762() {
    coral.tests.JPFBenchmark.benchmark28(-99.72944661129914 ) ;
  }

  @Test
  public void test2763() {
    coral.tests.JPFBenchmark.benchmark28(-99.73781172971357 ) ;
  }

  @Test
  public void test2764() {
    coral.tests.JPFBenchmark.benchmark28(-99.75109315518328 ) ;
  }

  @Test
  public void test2765() {
    coral.tests.JPFBenchmark.benchmark28(-99.76072823431356 ) ;
  }

  @Test
  public void test2766() {
    coral.tests.JPFBenchmark.benchmark28(-99.78208490047061 ) ;
  }

  @Test
  public void test2767() {
    coral.tests.JPFBenchmark.benchmark28(-99.93965315071678 ) ;
  }

  @Test
  public void test2768() {
    coral.tests.JPFBenchmark.benchmark28(-99.9515830770864 ) ;
  }

  @Test
  public void test2769() {
//    	UnSolved;
  }
}
