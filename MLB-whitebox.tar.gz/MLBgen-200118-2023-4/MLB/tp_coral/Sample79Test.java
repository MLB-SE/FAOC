import org.junit.Test;

public class Sample79Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark79(-0.0031173571755886975,-24.163280738735846,156.73711403937403,7.420322549028242,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark79(-0.004171750352799035,-142.19986914161967,39.076436792147746,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark79(0.009075831696264233,-33.461132456703936,56.53886754329605,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark79(0,-0.8774288523275403,-0.8774288523275402,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark79(0,-100.0,100.0,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark79(0,-100.0,80.3259982190326,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark79(0,-100.0,81.07978415355228,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark79(0,-101.39296956651322,90.0433725237468,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark79(0,-121.82077352044821,71.48586188401514,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark79(0,-1235.363642599474,1445.4375184913197,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark79(0,-12.405463393490152,79.87453262184613,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark79(0,-130.28393790907288,94.485870264906,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark79(0,-13.543246388588742,-13.54324638858874,0,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark79(0,-151.4946074610907,78.72605367362337,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark79(0,-1528.0791076831424,1246.3135824477035,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark79(0,-164.407176216164,15.708360909087045,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark79(0,16.504770256025324,75.57508661570716,0,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark79(0,-165.05078849042238,22.974551140518315,0,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark79(0,-170.96193871061857,66.33384079113914,0,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark79(0,-175.12316382156905,4.967691814131548,0,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark79(0,-17.897542979166545,72.10245702083346,0,0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark79(0,-18.23575352374998,-18.235753523749924,0,0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark79(0,1.8719934378666272,91.87199343786662,0,0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark79(0,-187.81609884186076,-7.815661709408864,0,0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark79(0,-19.494963050304264,29.759341345258463,0,0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark79(0,-199.30021386321943,37.995565641894714,0,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark79(0,-20.595213240079644,-2.7728892876673257,0,0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark79(0,-21.393039091973492,34.456646803346956,0,0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark79(0,-25.564647072150876,92.19492450520278,0,0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark79(0,-27.299415011585012,94.53131959523023,0,0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark79(0,-2.796376963278526,87.20362303672147,0,0 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark79(0,-30.91209339244824,59.08790660755176,0,0 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark79(0,31.004603516204497,60.516445205736744,0,0 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark79(0,-33.23938393297361,16.52181766166416,0,0 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark79(0,-33.44965562122455,47.85858109836525,0,0 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark79(0,3.4666737765132853,183.46667381036133,0,0 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark79(0,-35.53849187497735,-2.8351394619098316,0,0 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark79(0,-39.72686257204898,50.273137427951006,0,0 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark79(0,4.021218749231792,94.02121874923179,0,0 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark79(0,42.81774528251486,-27.207914175389035,0,0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark79(0,44.08890901767637,65.81867977933197,0,0 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark79(0,-45.58448317314871,21.206477608352188,0,0 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark79(0,-46.07758046429771,43.92241953570228,0,0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark79(0,48.933632364274274,60.42992355490986,0,0 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark79(0,50.507539303785165,-34.91601833855566,0,0 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark79(0,50.90942019028074,23.843875044937718,0,0 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark79(0,-5.092808408944041,84.90719159105595,0,0 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark79(0,5.551807226280921,95.55180722628091,0,0 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark79(0,-57.387212072267715,32.612787927732285,0,0 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark79(0,-60.73986918386089,126.2272601900427,0,0 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark79(0,-60.78887289068504,119.79916753539126,0,0 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark79(0,-61.18065400830615,28.819345991693815,0,0 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark79(0,-61.703798627192974,170.85595386015206,0,0 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark79(0,6.229105013518612,10.475972232268852,0,0 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark79(0,62.44725642749046,81.300882102213,0,0 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark79(0,-63.429682586891545,-32.27497793109906,0,0 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark79(0,-66.3256085270168,23.67439147298321,0,0 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark79(0,-66.7213714389475,51.79508495754217,0,0 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark79(0,-67.80642780136432,22.19357219863568,0,0 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark79(0,68.70370482850382,68.70370482850383,0,0 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark79(0,-70.1609017783292,19.8390982216708,0,0 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark79(0,-71.31391835809757,128.55658164379972,0,0 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark79(0,-72.34334387766994,61.92027132788647,0,0 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark79(0,-73.77137182745899,-73.77137182745898,0,0 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark79(0,-7.410966583200725,82.58903341679928,0,0 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark79(0,-75.80405982016008,14.19594017983992,0,0 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark79(0,-76.40774059782574,13.592259402174268,0,0 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark79(0,77.6975479278928,88.64302739271074,0,0 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark79(0,-78.15904450924111,11.840955490758878,0,0 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark79(0,7.822227061729218,187.82224072210767,0,0 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark79(0,-80.24613078731979,99.75386921329878,0,0 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark79(0,-82.96407131249794,-5.916215343166158,0,0 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark79(0,-83.36926291277805,6.630737087221943,0,0 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark79(-0.841580201045474,-81.33618430413587,123.44995967697263,-46.874434864785705,0 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark79(0,-84.46558828957471,133.55158472755926,0,0 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark79(0,-88.49636978048426,-88.49636978048424,0,0 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark79(0,-88.90945043959036,1.0905495604096247,0,0 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark79(0,-91.33076867790149,-22.63458521530862,0,0 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark79(0,91.52771342726894,65.84069435135041,0,0 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark79(0,92.72701035435148,-83.02718602234901,0,0 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark79(0,-93.11105443418208,-24.109760818156303,0,0 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark79(0,-93.42980327704868,86.57019672295145,0,0 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark79(0,-93.70829496856301,-89.74467021728125,0,0 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark79(0,-93.98208495321379,97.82481135047846,0,0 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark79(0,-95.62799643652909,120.42446552861273,0,0 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark79(0,-96.15374809730204,95.926597752291,0,0 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark79(0,-96.28304023845536,-14.877745698335161,0,0 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark79(0,-97.88726292966936,104.47868694608775,0,0 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark79(0,-98.80631642127761,-98.80631642127761,0,0 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark79(100.0,-37.91947206716395,52.08052793283599,0,0 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark79(1.0155802413002323E-4,-18.209502092612617,1.8280069517256408,0,0 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark79(-1.0402270260051942E-8,6.431094365305476,96.43109436530547,174.93189311597922,0 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark79(-1.0409800498968577E-36,-12.099043917010803,77.9009560829892,0,0 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark79(-1.432418529110678E-9,-50.32923526555683,39.670764734443104,53.37694199420743,0 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark79(-14.690348173665795,-54.20098717039319,35.79901282960681,0,0 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark79(-1.7082460827612143E-17,-81.39042975331834,100.0,0,0 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark79(1.7558031489284482E-28,40.476599677955036,40.47659967795504,0,0 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark79(-1.8844386526241604E-22,35.59322940969996,100.0,12.476044918431334,0 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark79(-1.9465120753712105E-28,-74.002246636601,-53.34585536066043,0,0 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark79(19.518988121639836,-27.75290324225375,62.247096757746256,0,0 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark79(-19.923764868765197,-22.42783177625747,67.57216822374252,0,0 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark79(2.0944566753460236,-11.177420442559068,8.437551548234623,0,0 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark79(24.814449720802237,-100.0,81.10059066392283,0,0 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark79(2.531540761748436E-6,-92.58576413981564,87.59146025923816,100.0,0 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark79(-25.84245048788405,-31.02010861019437,-31.020108610194313,-48.99814074790565,0 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark79(-27.412229202042003,-47.60727867958603,-47.607278679586024,71.36373197075648,0 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark79(-2.881689489154339E-32,-71.79303379044696,18.206966209553038,0,0 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark79(3.0361835316174536E-5,-100.0,80.92122282074538,0,0 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark79(3.056764483700166E-9,-41.607856434677075,48.39214356532293,-25.09739010684215,0 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark79(-3.0949986510092556E-9,-8.006014095348618,-8.006014095348611,96.41561487841389,0 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark79(31.071181222722203,-15.90504312241545,19.035083768540105,40.61481601246564,0 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark79(-3.137857153942806E-29,-35.04898108213931,54.951018917860694,55.37994947104589,0 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark79(31.70505917786642,-64.78291653791538,25.21708346208461,75.41020752768729,0 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark79(3.2035538282042353,-61.72643652003909,-61.72643652003896,34.10342401687643,0 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark79(-3.237881223042647E-22,78.7516187329352,78.75161873293526,36.03248347861948,0 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark79(-3.2726509050234763E-9,-80.31048603085668,100.0,0,0 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark79(-34.33344916383524,-81.7466831285165,100.0,0,0 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark79(3.6775769593090293E-9,31.248283110220484,31.248283110220488,0,0 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark79(3.798761431785006E-12,-99.99638653284876,80.00367321928705,71.6273854941786,0 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark79(38.47029782947223,-68.29090818012837,-51.69880726098537,-56.05294825686475,0 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark79(3.938921906689237E-9,-79.91364604488288,10.086353955117119,-100.0,0 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark79(4.04836987259668,-12.040378664295169,77.95962133570482,0,0 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark79(-4.107820502117871,-1.1442182536094165,88.85578174639056,0,0 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark79(4.227544723879779E-12,-99.98670789066334,80.01329218629459,100.0,0 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark79(-4.237293232347007E-22,-19.196403357883725,-17.528098993696027,-76.15645631787422,0 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark79(-43.08543641065554,-43.76072534784194,27.364988277557018,0,0 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark79(-4.350885123349057E-29,-13.80703666487406,76.19296333512592,0,0 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark79(-43.685086144025064,-93.00094206863491,-93.0009420686349,-74.81577627258034,0 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark79(-4.382525204706361E-9,1.7498219998824005,1.749821999882404,0,0 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark79(4.721817591050941E-17,-20.90125775689692,69.09874224310308,34.781479252865296,0 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark79(49.269192973310595,30.353666841772906,48.94222136737832,0,0 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark79(-53.84732046375771,7.632130101586155,97.63213010158614,-94.13133048165831,0 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark79(5.725126736299856E-26,-100.0,-10.0,-20.10795476799362,0 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark79(57.94858249415685,86.42982072175167,86.56929406959298,-17.51577660173875,0 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark79(-5.8791991046600624E-9,-149.23178320436136,30.881418303404914,52.265137241896156,0 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark79(-6.292416943904932E-10,-91.01881014736077,90.65844564776145,0,0 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark79(-6.610981391867043E-7,-108.69981616197747,71.4516855553168,60.621240375452516,0 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark79(-6.620150641447517E-25,71.73288750506708,71.7328875050671,99.99005999876441,0 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark79(66.86910684819404,-75.31365463054244,113.73806743462805,-88.78550237764333,0 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark79(68.42351508956742,-47.56920989311162,-20.86332752594953,0,0 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark79(-6.929599622862031E-23,-38.020263976508566,-38.02026397650856,-100.0,0 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark79(6.96703906421099E-32,-51.37754664129261,38.62245335870739,0,0 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark79(7.033371801285343E-29,-38.913539369550634,51.086460630449366,17.400959493596165,0 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark79(70.40639873095353,-54.87923361221385,-10.647935641882825,-36.01457315347314,0 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark79(-75.60889658925876,28.930319928655365,40.11850390100534,0,0 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark79(-7.57315721013615E-26,-38.20455529961897,143.23641626225555,0,0 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark79(-7.795563310698547E-34,-61.384395017954276,28.61560498204571,0,0 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark79(-79.57589191069427,-81.21553153992447,100.0,0,0 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark79(8.028826364494137,-91.51304827189766,108.8193122866587,6.866202846975099,0 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark79(-8.031862027997762E-26,-71.81805156897477,-40.404940703654546,0,0 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark79(-8.243888097701168E-33,-53.81085184337146,36.189148156628534,0,0 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark79(85.10032057186255,-6.015463592631498,83.9845364073685,0,0 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark79(-85.68832614129089,-41.765412055646664,48.23458794435333,80.43817253012865,0 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark79(87.21477082105226,-87.07229883796315,2.9277011620368416,0,0 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark79(87.70264025241761,-22.145599189367633,67.85440081063237,-59.428293398784106,0 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark79(-93.58329478753973,-46.45746766232679,-14.661542252483756,0,0 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark79(9.445685287579679E-5,-0.28954859122703525,89.71045140877295,100.0,0 ) ;
  }
}
