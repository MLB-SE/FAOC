import org.junit.Test;

public class Sample14Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark14(0,-0.09751305914993225,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark14(0,0.5616394265863534,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark14(0,-1.0691058840368783E-50,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark14(0,-11.766111319522892,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark14(0,-1.3163985556378748,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark14(0,-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark14(0,-21.507807984023785,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark14(0,2.1684043449710089E-19,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark14(0,25.354546859378033,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark14(0,-2597.669036553259,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark14(0,-2641.7988534073843,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark14(0,-27.057227276621873,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark14(0.35455912973987747,-1.5707963267948948,0,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark14(0,-44.11176114633193,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark14(0,46.007371472322575,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark14(0,-5.237119132392181,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark14(0,-62.88351561877794,0,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark14(0,-73.39750706420516,0,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark14(0,-86.82995918415554,0,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark14(-1.0000000000000009,-0.3809497092935791,-5.638297871093682,-1.0000069616914897 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark14(-1.0000000000000009,-1.2163099967267836,-29.014843853176377,-1.0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark14(-1.0000000000000016,-0.06823363247122372,0.865627820385175,0.0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark14(-1.0000000000000018,-0.23964313497053358,0.0,0.0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark14(-1.000000000000007,0.44548581463914416,30.592766787205647,0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark14(-1.0000000000000098,-0.6306668824122094,-1.8072421658502833,-2166.984770113579 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark14(-1.0000000000000142,-0.7811487592993908,-63.34888339373144,91.3459160249193 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark14(-1.0000000000000142,-0.9203495090956094,6.712388988714746,0.9743402240412375 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark14(-1.0000000000000142,-1.451163912331652,-66.3822422559157,1.0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.001230740426519447,-9.210100354455712,-0.03496857181734642 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.005718427946579396,-95.53718788059548,1.0742028066544307 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.007664166606714815,-91.99244369490316,-0.02100745780267732 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,0.009162467878904085,95.60666124192916,0.0 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark14(-100.00012864980319,-1.2032699441873533,14.429493786226558,5.551115123125783E-17 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.02139432014225262,-36.786039337058995,-0.06256217095863584 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.03405069972100115,1.5707963267948966,0 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.03441570917095013,1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.0349728519173808,-1.5707963267948966,-0.973529247297384 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.04503085716407866,-0.20598452948396784,93.02790342504974 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.04826512004574168,1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.05444995968363821,-73.76756621535932,-1.0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.07587016721639606,1.5707963267948966,-0.9932499474086784 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.08198011458465704,-1.1789605232453576E-15,-1.0 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.09489021164949978,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.09875892603716624,-43.79010293638763,-1.0 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.1157151667158064,54.84525966438014,0 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.11631605712792681,0.0,0 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.1267481143011261,37.80827493697923,1.0 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.12760984070089587,-77.62145117780477,1.0000003831004922 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.13021798598391376,1.5707963267948966,0.3620892884479908 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.13746193169425971,-92.14594017490398,1.0 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.14150397909932955,-31.93834154031822,-94.75053484372006 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.14506853357686733,-13.119261484067522,-0.003218571691927838 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.1489460855002444,-20.485354398151557,-0.9999999999999929 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.15701717585094954,-0.24980773804464096,-49.68304859987253 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.17261828915883032,-12.759275317213515,8.552847072295026E-50 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.17670945554425543,-54.286245757982584,0.0 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.17920201054576615,-32.76354001492833,1.0000021505021457 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.18202076255041622,-0.4623795847815054,0.7043806248788798 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.19333178668259687,-11.584875879534877,1.0 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.19681237472918234,-0.3384908525070368,38.49046697103465 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.2142029914459289,2.8718771541553543,1.001001178931627 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.21961970074243825,-19.196641872148355,0.8830572387894117 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.22990916681660764,0.42946569886360236,0 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.23180019984402217,-1.5707963267948963,1.0000001428507521 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.24142735876274035,1.5707963267948966,-2.5489470578119236E-57 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.2674830708766708,0.0,-61.89549182634351 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.26846281531645,1.5707963267948966,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.27440720123771967,14.548958209927314,0.0 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.2823251446154903,-11.194890007157994,1.9721522630525295E-31 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.2848441975160636,-0.18722084492654964,0.0 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.2899808252078895,-4.6841356537327385,-1.0 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.2932770424398582,0.028212087094144064,0.0 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.29583563782546224,-0.16641476021217377,1.328589489470254 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.3216381619541835,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.33427694127936974,-13.580420796485829,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.3363769933867814,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.33860323488002,88.37399277795458,72.61023722302045 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.3567464390126013,2332.1345911387875,0 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.36646682075229875,-67.78270790546145,-1.0 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.3668835856790623,1.5707963275666994,0 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.3775525019698982,-4.309492551755341,1.0 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.3962037132160493,0.47124859696250804,0.06255266849774341 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.4066694659674088,-49.489067811076204,0.9107005783218443 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.4419101152874987,-4.839914941656813,0.5321977267912352 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.4727524786574456,-1.5707963267948966,0.36221688082471687 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.4884379453166534,-72.70264770016315,-1.0 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.4896069926137194,-10.829744981914288,1.0 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.4904907205148348,-1.5707963267948966,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.49178588808911505,-1.5707963267948966,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.49673408097497207,-53.17523243346353,-1.0 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.4985490147199439,-100.0,1.0000000000000022 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.5415893470084963,-17.046450923375794,77.38057907937068 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.5518887497393649,38.82261153881349,0.0 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.5610066835597723,44.27884807742994,1.0 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.581652620308442,-100.0,5.551115123125783E-17 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.5851691559599365,-26.70433187286693,0.6070386887573151 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.6719150731748794,-14.7816474631435,0.7214578930324709 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.698954275324324,-87.43412842983888,0 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.7464621418270212,-11.80169956919045,1.0 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.7476130385418038,-1.5707963267948966,-0.051011437712784824 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.7596904547033904,-32.71494486495084,-4.3368086899420177E-19 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.7871349295057827,-89.12867959412667,-2.8853058180580424E-129 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.7880509222808401,-0.701967504858324,1.0000000000001439 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.8096541213612163,-11.20527154861854,-42.81350581975856 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.8104240296179008,-5.551115123125783E-17,1.0 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.8105892879368426,-1.5707963267948961,54.95781822528976 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.8111566566297936,-1.5707963267948966,-0.5737183115176074 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.8533671069465973,-37.77780185136481,26.18707964509592 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.8702864409171696,-40.5804014491827,-0.5452125727414541 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark14(-1.000088768745537,-1.208007481013768,-2.762729755433784,1.504632769052528E-36 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.8932412851814178,-11.806199636220867,0.043225363452095544 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.8979031803343815,-20.634806592663054,1.0 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.9443660726538357,-91.31601844446249,-0.005772159933317422 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.9704541174321282,-69.53560597716626,-0.4612648630281305 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.9719209369926471,-84.64665219592058,0.06351905195115548 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.9747841593358999,-36.1436612541906,-85.35569925050541 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.9772939875720761,-63.434927132172724,0.34508756945563646 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.9791136546243546,3.3897029334427855,-58.764567063697456 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.0287268749062506,-1.5707963267948966,-0.13177182257692377 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.060753684010497,-1.0695553283625856,1.0 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.073900458800285,-70.70323862330129,0 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.0852223237840466,-0.05878319406555277,0.06260192108525292 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.094296499916302,-21.885714864836174,-0.01719365068384282 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.1075281863447406,-1.6164045698681093,2.347085087147456 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.1102230246251565E-16,0.0,5.421010862427522E-20 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.1102230246251565E-16,1.4169089465363496,-3.248565551764031E-114 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.1102230246251565E-16,1.5707963267948966,-0.8633004209940831 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.1102230246251565E-16,1.5707963267948966,-13.05072734791024 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.1102230246251565E-16,1.5707963267948966,1658.1003554125673 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.163466658858405,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.1693604935783934,-100.0,-1.0 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.2352139173052037,-1.5707963267948983,0.9999999999999991 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.2358045617828672,-100.0,-3.3265311250063677E-111 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.2685394968291286,-0.3830781559201043,-0.7491529573878866 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.3283402107638653,-95.7094601242803,-0.9999999999999996 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.3287956273053836,-71.77050625164335,-0.9969928320863687 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.3293022777984809,-66.4073539384885,-1.00021012730176 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.3352979070759292,-84.38447801674275,1.000002832654828 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.336424611276548,-44.316961126681406,1.0 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.3527672323222162,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.3541689023392478,-96.42221983364442,-0.06255692942461928 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.3726377339260534,-92.27531730280549,7.174306959637562 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.3756087004959137,-0.5037487985098974,-100.0 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.3886370169747686,-0.16914686940254361,-248.46880198996232 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.416468534981669,-32.416169509201666,-1.0000006081312438 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.4210854715202004E-14,-98.95519190400121,1.0 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,14.429250868438238,25.75375516594312,36.61371954590071 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,14.42935519896156,1.302279421050777,-90.52478020784706 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,14.43307318387641,0.0,47.932717750541556 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,14.446251580427301,9.323873137105034E-16,1.0 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.4506622018578361,-53.89115713362991,1.0 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.4639386155926417,-26.406523782410943,-1.0 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.4745160334668574,-15.152841516710197,-1.0 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.4953002743006056,-25.753820610854493,-1.0 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5098962858772962,-24.66587087161932,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.515661175150993,-72.42083029726987,0.0 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.532403332776591,-11.281307395273995,-4.276423536147513E-50 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5369782230348428,-0.9652495513030405,-1.000000170015715 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.541585416527413,-88.50834879952092,0.06255711248558943 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.550765651777552,-0.05270705207597415,99.84893226040421 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5513918446532884,-76.59643666135455,0.48897347772323485 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5520245211591643,-87.75125786143643,62.28793512249425 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.555641337420435,-0.37225433092061444,-1.0 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5643969532002184,-7.818211200235077,84.59213994116507 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.568013365298714,-76.5259499008836,0.22520453443722266 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267946699,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948752,-48.03894890116307,-0.6662378320527425 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948806,-1.5707963267948988,3.3087224502121107E-24 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948806,-3.271796075221966,-37.58631329612601 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948817,-64.76837721014955,-1.0000165097611604 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948895,-20.892036858855473,-0.8419938991761242 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948903,-0.7413855973210857,-1.0 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948912,-1.2257185329656803,32.26488759036468 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948912,-14.842435391975577,-1.0 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948912,-1.5707963267948966,-55.62463692656743 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948912,-43.299882991815664,-58.493401048161765 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948912,-46.094302234218674,-0.4628043857074293 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948912,-47.9541342653061,-1.0 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948912,-92.83679865978561,41.03995711842646 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948912,-93.43087633421563,1.0 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948948,-1.5707963267948966,1.0665005500670782E-6 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948948,-15.9531478506544,1.0000000000000018 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948948,-31.396241954550085,1.0 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948948,-4.368812400556703,-54.794755131288355 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948948,-53.42920499631598,1.0 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948948,-54.1236067145336,-0.35569633644903575 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948948,-64.05495530828007,51.62529264725899 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.570796326794895,-0.8620785879885824,-1.000000004798143 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948963,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948963,-78.1123194440897,0.49151398588640555 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.7763568394002505E-15,0,0 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.7763568394002505E-15,-10.706072812645637,3.3881317890172014E-21 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.7763568394002505E-15,-1.6248791262801419,3.7241119680758317 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.7763568394002505E-15,3.1083832413179002,195.67950237112888 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,2.8306897818827834,0.0,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,2.9755241172826907E-4,0.0,-17.25811677931165 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-3.2322643929943067E-15,-64.87583268006588,-0.42205410179229474 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-3.7717952677603246E-4,38.908631584768955,0.0 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-4.440892098500626E-16,-90.26428519157749,1.0000000016681427 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-5.415813115655366E-4,1.5707963267948966,89.33190433031086 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-6.1281754923935146E-15,-89.75393656935236,-38.48773412799912 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,6.429762262410887,1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,6.430023468260946,44.34644036845597,1.0000000000000018 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,6.432663854948218,0.0,0 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,6.538499622094247,0.3217841071834336,0 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-7.105427357601002E-15,-32.72727039008221,1.0 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,7.772123166250265,0.0,0.9999999999999996 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-9.316601019328948E-16,-96.84683967398247,1.0 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-9.391363810701958E-5,-80.63832782201582,-0.6872654645839991 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark14(-1.0,-0.16735783948423688,-49.303848129763225,0 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark14(-10.050180849449605,-0.013689663754524291,-9.987741282610017,84.66924439299765 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark14(-10.11721658316763,-0.4113381390977672,-76.97597453707345,-2.0880974297595278E-53 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark14(-10.127757856284529,-3.552713678800501E-15,-81.70165805193025,0.08548604343193444 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark14(-1.0,-1.315670055613097,0,0 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark14(1.0,-1.3949076263366962,0,0 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark14(-10.145603305042268,-1.5707963267948957,-1.0461850958565448,-1.0 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark14(-10.18463035828084,-0.896248437052347,-1.5707963267948983,0.03437682744052856 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark14(-10.23514011480851,-0.5369362150532074,-17.40994980348388,-0.026149665294631586 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark14(-102.39078005091122,-1.2008224174665827,-88.28711067800701,3.790939299797543 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark14(-10.252162329169307,-1.4715121399152162,-1.4735695170707874,-1.0 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark14(-10.258665717941678,-0.22996780006092973,-57.78316309910021,1.0 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark14(-10.273619673629954,-0.46363290752231207,-1.5707963267948966,-31.432707352351805 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark14(-10.280447018465413,-0.15757418030058307,-21.723661828386682,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark14(-10.293927175720555,-0.1604930675569176,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark14(-10.375923553168604,-1.7763568394002505E-15,-66.34372399268509,-1.0 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark14(-10.392041958832703,-0.22052710094742434,-32.855328854988656,0.9999999999999982 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark14(-104.08251430082152,-1.4208245738178236,-9.515627319773476,1.0000146799160987 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark14(-10.408753971440888,-0.14815706511571847,-0.592027357304963,39.44476804428126 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark14(-104.10294737313858,-1.148121551021509,-81.43691475245363,-16.981383761551385 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark14(-10.563635811921841,-0.5239228545965648,-53.91097176683684,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark14(-105.63704639345792,-0.05994118390951397,-54.02311350941386,-1.0 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark14(-1.0645305212959908,-1.0316426440885507,-100.0,-1.0000000006462437 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark14(-106.50999105781607,-0.05957369568833926,-19.98158159764089,-1.0 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark14(-10.6617218683171,1.319913499999102,1.5707963267948966,56.108917584754515 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark14(-1.0693445022835881,-0.7317104295915453,-94.25084234381039,0.9999999999999986 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark14(-107.38311075196283,-1.0035296460409233,-0.18715739514622076,61.61270446120599 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark14(-10.74601780774374,-1.5303881546775813,-38.965422835541965,57.29146593271682 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark14(-10.855725884449845,-1.2842913158280016,-0.3533892573388664,-25.110243148920173 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark14(-10.86264394981009,-0.5781660157668189,-24.85572518997449,100.0 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark14(-10.898502802122678,-0.3199420627390585,-39.232604603149326,-54.86905363824143 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark14(-10.912974584367689,-2.220446049250313E-16,-53.53240071636751,80.22769875524517 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark14(-1.0954686104467826,-1.2950896995691348,-0.41256350454294977,67.19540804547822 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark14(-1.098399792760313,-0.1349472332835848,-1.4570361327165529,-0.9943733406814074 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark14(-10.995834288244179,-1.279675955416081,-25.1726118562066,1.0 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark14(-11.015585037733368,-0.7565331729252089,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark14(-11.037877550198889,-0.485742827255013,-30.709874187674135,1.027005389427052 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark14(-11.057470669100102,-0.23978752914602786,-10.46249492572209,-0.007285429946044197 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark14(-11.103529137796377,-1.5707963267948912,-77.74202726886607,-28.20135039847398 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark14(-1.110451851819116,-1.281871593315834,-56.47056239411588,0.36214324480220494 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark14(-111.10401045905658,-1.089621031198881,-1.5707963267948948,-2155.2866790204375 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark14(-11.13778288313587,-0.5054847313763897,-34.715464103553934,-1.0 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark14(-11.142250643255494,-0.22343478028761524,-14.926296295571904,0.36241664347172886 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark14(-111.62368261204274,-0.0784375572138113,0.0,-0.5666169787488554 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark14(-11.16352204526591,-1.5707963267948961,-1.5707963267948966,-0.003297893226624854 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark14(-11.170028652293153,-1.2120975396969957,-25.553591699520112,-0.06255353702787685 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark14(-112.65666588625513,14.437122097924828,38.82656938311689,0.0 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark14(-112.85507383693955,-0.3986010970307505,-121.26899329550011,-1.0000000133062978 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark14(-113.05866269648948,-1.0828409532891483,6.470347717590422,1.0 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark14(-11.316270303161486,-1.250948032652708,-1.505075003490552,1.0 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark14(-11.338502620858808,-1.3377698909277391,-1.5707963267948966,0.0297711481830681 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark14(-11.39920238882787,-1.570201719573459,-32.746454885541496,84.8577603361376 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark14(-11.406160445159752,-1.5707963267948912,-67.4906784915695,7.759329249354487E-17 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark14(-1.1418697381229508,-0.043485507758711545,-0.8039595097300803,-3.5036062698452923 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark14(-114.28591749373236,2.8592459476040477,132.83837085463142,-17.205362132339474 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark14(-11.439924341419578,-0.9372662306140945,-58.38699781191166,90.92461379823533 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark14(-11.45220090471325,-0.3702027523424435,0.0,1.0 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark14(-11.552359482162487,-0.3947045863460914,-16.02300453068863,-0.9559631687646967 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark14(-1.1611407826831481,-1.3522206793563356,0,0 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark14(-11.670999010894754,-1.5707963267948963,0,0 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark14(-11.699044413035397,-1.5591294239298938,-1.5696356995760523,1.0 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark14(-117.02586684572282,-0.644008529668568,-193.5593664216605,-0.0015967440556880685 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark14(-11.71841829492486,-0.537318559555457,-0.6463458530821288,-3.0137637936283385E-15 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark14(-11.748204443621063,-0.4231161960205725,-23.975282746532955,0.43849179216656253 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark14(-11.810959118129052,-1.5707963267948957,-0.5074736646271788,1.5226168719973145 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark14(-118.48088204951164,-0.7161335715308197,-32.83274502980693,-1.0 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark14(-11.902964804369851,-0.46824009031468095,1.5707963267948912,68.14930245069004 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark14(-1.194104249679626,-1.053705458669472,-1.4467316397767365,11.422470122665564 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark14(-12.018523203621028,6.431021881326626,0.7854374136225009,0.0 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark14(-12.063761507891229,-1.0219329520304825,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark14(-12.071298938209098,-0.8730216511940205,-51.995226409848925,-1.0 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark14(-12.111546032791912,-1.5707963267948912,-45.607830452803036,0.4706693646942503 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark14(-122.20603243946974,-1.4228407969802235,-59.338184881279034,2109.170569483882 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark14(-12.267876978249156,-0.9450399754955608,-1.5707963267949054,1.398230613519122 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark14(-122.69262780495222,-0.12988866632558072,-1.5707963267948966,-15.088754561309756 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark14(-12.270288772501432,-0.804086094557383,-42.30431758769695,-1.0 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark14(-12.32369809010378,-0.44349402159584483,-52.69460031223518,-17.97826042238083 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark14(-1.2360677222301355,-1.5368871760150378,-9.470740052377234,-54.50571136479103 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark14(-12.373605202105152,-7.105427357601002E-15,-90.52593034151771,1.0 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark14(-12.388936318324163,-1.5707963267948912,-61.01594908249716,2.1684043449710089E-19 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark14(-12.443153847605146,-1.476958529504118,-100.0,-0.9651559879648473 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark14(-1.2467567891104927,-1.5707963267948948,-1.5707963267948983,8.280954145855266E-7 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark14(-12.5332849557092,-0.011061552211910741,88.3845088100201,0 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark14(-125.77791160338484,-1.5580689738122977,-88.49583792634837,-2074.342987691858 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark14(-12.716511020601065,-0.02856888629997593,-42.99814704660668,-0.682408124094392 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark14(-12.720246171448878,-1.083784854236635,-0.0386579992595982,1.0000000000000004 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark14(-1.2764354591819895,-0.8908710094910557,-53.04699573787026,24.656144298643092 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark14(-1.2772107550129128,-0.5772907794746261,-5.6936602476267915,1.0 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark14(-12.85551230082015,-0.3590387170637086,-92.44362387178626,-71.31805578403134 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark14(-12.873543833872272,-1.5707963267948963,-32.66235554339395,3.469446951953614E-18 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark14(-12.88846737639447,-9.75447713294424E-4,-19.963437556548048,-1.0 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark14(-129.21623146327676,-1.1102230246251565E-16,1.5707963267948966,-2039.9086665668292 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark14(-129.86488607811293,-0.14952473783017428,-10.299040564769728,-0.584952827933811 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark14(-12.988546740804185,0.7692440909733331,1.5707963267948968,-1.0 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark14(-13.093890908567845,-0.4422940407847862,-8.13728426629467,-1.0 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark14(-1.3117521265572363,-1.4448240079425299,-0.5453505095208523,0.0 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark14(-13.147151593144542,-0.7444985271466479,-10.881620889575032,1.0 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark14(-13.169113489735778,-1.5707963267948954,-1.0839312149811617,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark14(-13.302356762013101,-1.5291157747919856E-4,-4.70897176089128E-4,0.8109408663988034 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark14(-133.02472295639268,-1.0362180353797394,-215.0535810575629,-0.9999999999999996 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark14(-13.418065485186746,-0.018906142404769587,-31.59632870829157,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark14(-13.52093887474669,-0.9030484185430818,-16.973938444931125,0.06255405547189777 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark14(-13.531973918756222,-7.105427357601002E-15,-14.40089997130957,-0.5338603772466789 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark14(-13.54523041493222,-0.7841059821256413,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark14(-13.654643531256449,-0.3801840966861559,-65.35377858109099,23.147405476373947 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark14(-13.678982188572562,-1.4705018001628931,-13.06945145846359,0.6425935524264657 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark14(-13.778022436964855,-1.471732451215682,-0.09073325770265929,-0.8493707396192912 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark14(-13.79986574677506,-1.4178652696310168,-22.935332881426554,0.22833066043637584 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark14(-13.86595375691569,-1.5707963267948961,-97.99612767524565,-0.5983945948005243 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark14(-13.909439064358232,-1.340192962261232,-67.33547499898718,0.8726355513816261 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark14(-13.913941451060236,-5.551115123125783E-17,-0.24960070897673564,0 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark14(-13.955957659764342,-0.4000365712097391,-90.6015325402223,1.0 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark14(-13.96925391639778,-0.20435205094344608,0.0,0 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark14(-1.3972571326783987,-0.5444826631552144,-5.5893714649585355,1.8033161362862765E-130 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark14(-14.008698411168051,-1.1325262480258118,-35.608815259646605,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark14(-14.08408285251596,-0.0019889586172206247,-7.668700692808752,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark14(-14.144946022379678,-0.462105245012286,-19.972595277698105,0.17782826571203958 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark14(-14.151862921809364,-0.9816442830179409,-10.704818642051418,96.51782283543287 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark14(-14.236556921227589,-1.3314233647481895,-0.1374429989069701,1.0 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark14(-14.275162369633406,-1.4881934381617228,-93.69206206176086,-0.9992131449317574 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark14(-14.280015144739608,-1.1809281310875832,-66.77102210005471,-100.0 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark14(-14.301014811023867,-0.16603347845380897,6.643518153103718,-30.859817874596303 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark14(-14.312101450654737,-1.5707963267948912,-61.41451017579064,-1.0 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark14(-14.353679711439973,-0.4940274436572983,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark14(-14.39753913302034,-1.0441533075377767,-54.074337597216214,1.0 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark14(-144.96520816580096,-1.5707963267948963,14.571397908840346,1050.8697082051494 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark14(-14.540074484635134,-0.6236011841996093,-81.16440841255948,-1.0 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark14(-14.543516495381905,-0.8816842920402117,-69.75315915965236,0.05081978381690688 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark14(-146.25446323912615,-1.4132408209723246,-90.80876571299133,2056.2068083606905 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark14(-1.4638615043012204,-1.4396871532525632,-4.614164094594603,0.7574838759730449 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark14(-146.7655436622817,-0.14001203702581366,0.009028002021807813,0.0 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark14(-14.70895970720508,-0.05965157642270136,0.0,0 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark14(-14.794395620988821,-0.5661816615684482,-1.5707963267948966,-0.9272048030667184 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark14(-14.797365291361913,-1.0135572474081869,-67.76650042127741,0.0 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark14(-1.482503146090643,-1.5707963267948948,-34.10482361543652,7.105427357601002E-15 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark14(-14.826059346155558,-0.20827244327025712,-0.2317744551316565,-0.3442959010387686 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark14(-14.842847160514822,-0.3138569177194199,-122.92066418764438,-0.7364521448016272 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark14(-14.86059843551277,-1.4000711999709936,-71.29958986268095,0.642152038806803 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark14(-14.868519558417022,-0.046949644257444245,-61.835578196797556,0.9348840533280982 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark14(-14.944659884753516,-0.029088766094228294,-6.061449018581346,-0.6450349010006602 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark14(-149.95904402489242,-1.0749435778680336,-84.17037001740452,-66.31062259273033 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark14(-15.074091044553844,-1.3024336887993986,-1.5707963267948966,-28.194535828664172 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark14(-1.5088759787658645,-0.02706925373559177,40.00631396117199,0 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark14(-15.113556920653366,-0.70869554814427,-54.10825316487843,0.9987309579947733 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark14(-15.13852380382994,-0.5051174669927383,-73.37048983942874,98.33989020987616 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark14(-15.138806535274943,-1.2453305196175162,-0.7569074254299919,0.0076669495433917545 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark14(-15.140254642997242,-1.0893195870344512,-1.5707963267948957,0.05956313513190692 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark14(-15.214971742162296,-0.9295249134359789,-1.7763568394002505E-15,-1.0 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark14(-15.27556951852403,-1.326198270432582,-100.0,-1.3552527156068805E-20 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark14(-152.7989083972388,-0.2391800898999661,-19.25725322155391,-71.24651532997848 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark14(-15.379887539643262,-0.7056496623619939,-23.58546162197503,0.9069463988158409 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark14(-15.39630714692569,-1.3177012632169076,-77.11559821907316,0.009085393777288842 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark14(-15.403019252493818,-1.340490952730908,-19.227599327220997,0.0 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark14(-15.481216028330334,-0.08901898740016817,-1.5707963267948966,48.0671068378875 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark14(-15.542783745331903,-1.5707963267948948,-100.0,0.0 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark14(-15.563139601340172,-0.20262485998095037,-6.274755369809839,2231.9474832375095 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark14(-15.618236214572121,-0.6536017725032434,-1.5707963267948963,0.0 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark14(-156.41199385403084,-0.40786970748643236,-148.94507105294363,1.1143030473353974 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark14(15.644860222647168,46.98119891651422,-56.190381553173395,0 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark14(-15.663042857888527,-0.6206694316561643,-0.09169097880855256,1.0 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark14(-15.685517813260525,-0.4157110749410057,-1.5707963267948966,-0.026142041990641893 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark14(-156.9427807432259,-1.4136933688101045,-3.9828517608104796,1.0 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark14(-157.9073395058666,-0.5143317547234147,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark14(-15.834390872828848,-1.5707963267948948,-50.25947584477652,0 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark14(-15.866612393071573,-0.5746865120020734,-16.685973244083446,0.02983725412834671 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark14(-1.593273071161202,-3.552713678800501E-15,-72.51208286992308,-0.032651937442326695 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark14(-16.019840322697547,-0.5837744104946267,-21.18378066153565,31.444904456946418 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark14(-16.038906611161124,-1.500092023294754,-90.0416817189662,0.5200991684804848 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark14(-16.046148794999382,-1.5707963267948963,-7.624826411369311E-5,-0.29253216294947243 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark14(-16.09550855416982,-1.228627981760918,-72.53536866219935,1.734723475976807E-18 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark14(-16.146370203366402,-0.2835655605102245,-65.27786387197085,0.03890955863066001 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark14(-16.166891535781375,-0.5278748834714386,-2347.793850683755,0 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark14(-16.191664924301666,6.447976650658664,0.0,730.104281350921 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark14(-1.6199148838744226,-0.2852205712314202,-68.19964492116874,1.0 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark14(-16.27580815704198,-1.1740991424006735,-78.53249453544402,14.39742883699283 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark14(-162.95684825153933,-0.20693024183255526,0.0,0.7199249016537466 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark14(-163.14900733110457,-0.031025635131238693,-37.86748781733215,0.0054298547471174925 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark14(-16.356133264953083,-1.3913183254280508,-53.88632696512672,7.105427357601002E-15 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark14(-16.393841604191458,-0.5329852470763263,-0.8572750929267494,-6.163055697431162 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark14(-1.6419408304784282,-0.73059455226493,-1.5707963267948983,-85.14213199225338 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark14(-16.450577142432408,-0.058406540212091684,-45.97645552968828,-0.0642194908425342 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark14(-16.508544424360736,-0.35591926969912446,-1.5707963267948912,-2267.5969110066408 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark14(-16.519618090230566,-0.5955130539359725,-3.981814150670054,1.0 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark14(-16.55064361142026,-1.5707963267948957,0,0 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark14(-16.55520373891214,-0.9218771161865345,-31.342419369246283,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark14(-16.562655370300668,-1.4123158902719803,-56.60857750319439,-43.74089655352317 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark14(-1.6652999081496818,-1.7763568394002505E-15,-31.66073069934178,-3.6531754905874863 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark14(-167.05020874108612,-0.1299197528896383,-94.35315519125162,1959.9366817675116 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark14(-16.732243299711243,-1.3450684057191726,-100.0,0 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark14(-16.74311799818058,-1.5702579797398208,-72.58753805987033,0.006779818905241264 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark14(-1.6751172044037013,-1.5707963267948841,-4.364159934918119,0.9479737877073626 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark14(-16.787281122118358,-0.4234392056059255,-97.5120056475335,-1.0 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark14(-169.1101294328742,-0.2498085589892981,-24.61667914979848,-2142.9908574352994 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark14(-17.016859069625028,-0.1640396615324362,-127.93235684926826,0.9997475624000806 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark14(-17.037743502945816,-1.1799714399824264,-10.585950294074564,-43.01677503711618 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark14(-1.7150542217667724,-0.5563646129150451,-4.552775935228553,0.06298360189982995 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark14(-17.24969090826221,-0.5922622456289748,-4.630531473878193,-0.7496623588988849 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark14(-1.7252914144958025,-0.26928639222938244,-3.2340721029193276,-0.2524836175525653 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark14(-17.41947276957952,-0.6223050787621354,-52.144919411520405,-78.89669362093376 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark14(-17.45757125255099,-0.11454596758756797,-11.623451612705233,-1.0 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark14(-17.465087830243505,-8.881784197001252E-16,-61.66384815029132,-16.54673986844423 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark14(-17.646909303967984,-1.021637040035389,-19.409285179078733,100.0 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark14(-17.65366527868622,-0.2714012007714691,-159.72356963768092,0.0 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark14(-17.73538303042264,-0.21028836341786483,-0.16990990720905685,35.39108306598304 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark14(-17.791575287188163,-0.6547311406203473,-0.31476398116322224,-15.182097890375701 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark14(-17.80195247124981,-1.5707963267948963,-64.8020118763485,-1.324391303711861E-13 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark14(-17.83068021575866,-0.00107051109884587,-77.4261458478781,0.01533449487831724 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark14(-17.922363742602837,-0.2713797109190758,-1.5707963267948966,-0.8838742227601849 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark14(-17.968544261835156,-1.5707963267948963,-58.205283161449834,-2241.317550463734 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark14(-17.985388343270206,-0.273181390590831,37.70973708767646,0.0 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark14(-18.04251588188083,-1.0883267583839034,-0.22442662784423204,0.0 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark14(-18.09858987248633,-0.09283874350770031,-1.5707963267948966,-7.621217228042049 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark14(-181.41495531692073,-0.28510260285351663,-28.202005439462454,1.0002539052007886 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark14(-18.167873087594035,-0.37727699498567824,-1.5707963267948966,-0.7813928670288152 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark14(-18.171117247147034,-1.1016312262971155,-3.552713678800501E-15,-2335.608895160519 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark14(-18.26646659400883,14.429216014594658,88.20684898617031,-62.33802770090737 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark14(-183.1463526618165,-0.10327639203011649,-53.80724248499314,1.0 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark14(-18.376075257848083,-1.492959840622618,-62.383542705506386,0.2487596324579197 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark14(-18.459834145423414,-1.5249789885164127,-73.79117119854429,1.0 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark14(-185.20536596277768,-0.778777219386562,-158.20284477805117,0.0033225266971669476 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark14(-18.560200827285023,-1.4080510320290955,-31.43101053903419,113.14084102888015 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark14(-18.57664825758249,-1.1102230246251565E-16,31.981619409806818,1.5906509572475258 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark14(-18.59366707362519,2.848379641662891,1.5707963267948966,-0.8139920953058297 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark14(-1.8594833212786734,-0.08852348914745589,0.125782066938671,0 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark14(-18.634612521065563,-0.0067341080499462155,1.13383714750698,-51.95419317914813 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark14(-18.656855392995112,-1.5707963267948948,-13.164413656537137,2403.99094642613 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark14(-18.659078132647764,-1.3324881071694914,-31.447335198960275,-0.9539922957227012 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark14(-18.67029113247196,-0.4397546495434072,0,0 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark14(-18.715483075216603,-1.3795158135023855,-31.490444500872968,1.0 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark14(-18.73642448499953,-0.9901704094992709,-89.98308347990181,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark14(-18.744780086473117,-1.5707963267948912,-100.0,1.0587911840678754E-22 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark14(-18.79569400573979,-0.08193937859451822,-40.15144970042142,3.7092061506874214E-68 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark14(-18.803441862232486,-1.1613039133401748,-82.67362704776893,0.5471274977722823 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark14(-18.807713684408906,-0.2656616427270251,-2.765067301700384,-0.11759970753813387 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark14(-18.845166528994422,-0.18919840581994785,-100.0,0.3620895247196008 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark14(-18.857609980483957,-3.552713678800501E-15,-74.84533669220254,2242.3527025701496 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark14(-18.87530585924062,-0.09541658294643482,-0.30269102657876634,-1.0 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark14(-18.900051631201634,-0.7929644983052802,-27.84375298695882,-11.517515888560268 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark14(-18.919029888043475,-1.5707963267948912,-19.321042177686632,1.0 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark14(-18.95185063099712,-0.01967627396787852,-19.372840883327285,-0.20661013492333768 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark14(-18.96240698104053,-1.5707963267948912,-26.995347731091027,0.9994315051179616 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark14(-19.057972958155347,-0.07992966320388242,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark14(-1.9176199223616806,-9.475576066294241E-16,-94.25123511310112,-0.9999999999999999 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark14(-19.248446913864242,-0.07812763265087483,-44.374101687014566,-92.04447036789432 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark14(-19.266055379937868,-0.6228865544893265,-81.00371992693152,-3.7581037092163094E-4 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark14(-19.27747363098841,-0.16926564039805492,44.443298935514456,0 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark14(-19.35518104370852,-1.5707963267948948,-89.64846385071297,1.0220819809294142 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark14(-19.382342042707435,-0.1589586299788208,-95.81128767807445,-0.5754672240851272 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark14(-19.389109110245045,-0.9438571074550794,-90.18015777642796,0.886907786329963 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark14(-19.415016106385238,-1.5707963267948912,-9.784700052325922,-1.016509439814647 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark14(-19.449974215438438,-1.4106535097816713,-72.27575235749212,100.0 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark14(-19.4849135836985,-0.9277896931553514,-77.09728267896857,-1.0 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark14(-196.49510115175917,-0.7199243629322165,-40.4547615669605,-0.09110546102185157 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark14(-19.667426819634883,-1.4628824328046257,14.430283939795494,-2.949465686999506E-17 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark14(-19.732514920459852,-1.3178303313058781,-39.21305634445776,13.808623761605137 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark14(-19.757736181191653,-1.4316532444242385,-75.34588003587014,-1.0 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark14(-19.792275021764883,-1.5365352542544604,-83.9812907145544,-0.9189789295519536 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark14(-19.808627622432972,-1.4625136504021479,-34.558255548266416,5.938420093573413 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark14(-19.821666736394587,-0.006158984575899188,-60.910218434086495,56.64938157083917 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark14(-19.845238889591457,-1.570796326794893,-52.497939608744026,1.0 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark14(-198.5078474272521,-0.095351696986365,-85.3461228952449,-8.60381787766566 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark14(-19.853364999419114,-0.20468195839825132,-91.74016562091727,-0.9161315173164855 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark14(-19.865691925246864,-1.5707963267948963,-1.5707963267948966,1.000000012308898 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark14(-19.9790205206437,-1.5707963267948948,-8.08367675452057,-23.70103582975773 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark14(-20.032047787739486,-0.1931414661077812,-34.581784960520196,63.01163861596443 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark14(-2.0035823544514706,-1.5390513189536656,-100.0,1.0 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark14(-20.1529123024987,-0.5077592674435774,-89.3755892958391,-1.0000029464870868 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark14(-2.016295703650055,-0.8009787346289772,-27.605267181456682,1.0 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark14(-20.18230985832867,-0.04527079576815225,0.3694917473723654,0 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark14(-20.2525674527508,-0.8927570412245636,-1.5707963267948963,-0.00973436675157452 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark14(-20.27154335037558,-1.4275454814209922,0,0 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark14(-20.30226704575754,-0.9756766580244153,-45.35655154702067,-1.0 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark14(-203.50080021303256,-0.0010798623568655241,-32.904494345976545,2022.7806407529317 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark14(-20.37177403725735,-0.34658072097698744,0.0,-0.0033719226566173433 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark14(-20.37554783515236,-0.23479154525131543,-10.292272308933121,1.0 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark14(-20.54301186946705,-1.5707963267948912,-6.916879689735314,-1.0 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark14(-20.565839920647242,-0.45108769384837155,1.5707963267948966,8.673617379884035E-19 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark14(-20.897230947119525,-1.084171549665574,-48.73526416155615,-0.9387135735610762 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark14(-21.060529564127407,-0.8726187915526135,-0.08236654332622725,-4.563924019237199 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark14(-21.070398073395303,-2.220446049250313E-16,-98.18160596028133,-0.1810501838237215 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark14(-21.07095243734141,-0.22113566591138922,-16.798484537554863,81.54602103397254 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark14(2.1081647363620135,-92.5670751623406,16.155944895787755,0 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark14(-21.121765716674904,-1.5633199826848792,-9.806433149298584,1.0 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark14(-21.203068085778188,-1.5707963267948948,-23.2672907321186,0.6860992328603955 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark14(-21.229423193374366,-0.9699019437795582,-52.5743457685516,-1.0 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark14(-21.235538230071654,-0.6807963937779309,-81.20633245517189,-0.9748672753518393 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark14(-21.271121011672726,-0.06149815110344892,-40.96951395491553,1.0 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark14(-21.317333852099665,-0.11093549059278529,-51.00441289783962,-86.49801001425332 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark14(-21.497340054814757,-1.7763568394002505E-15,-66.0822168666929,83.83712781134949 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark14(-2.152628039048949,-8.08296677177916E-4,-1.0331737562044658,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark14(-215.71427772721015,-0.04219827216185745,-71.11173448701884,-2293.220658921429 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark14(-21.596233975686662,-0.5798240438438365,-0.06549000469133456,0.9312705980465171 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark14(-21.665827069477388,-0.7212812976924983,-8.003086363417147,-1.0 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark14(-21.751738490597674,-0.4905569422903207,-10.451963581812848,54.697092744692156 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark14(-2.1779104347506277,-4.440892098500626E-16,-72.33217714690277,-38.69032616641454 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark14(-21.83499614529214,-6.8644861590895365E-15,-15.184734075144936,0.05308646712681819 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark14(-21.900938306173188,-1.5707963267948963,-71.24855174691169,0.34803626727778125 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark14(-22.024076209438523,-0.7852492842299021,-27.749565856394444,36.85263484187462 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark14(-22.095850099118337,-1.462842119452253,-54.16511662160027,-55.954030328427145 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark14(-22.121902176663703,-0.2785677674089082,-7.160560366614632,1.0 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark14(-22.134104612981037,-0.5494425075659753,-0.11084691821875034,-1.0 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark14(-22.230892403883836,-0.44157548401888325,-88.49140873646893,-1.0 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark14(-22.240158995532244,-0.007466584371996543,-86.85870477130479,-1.0 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark14(-22.271960807550776,-0.36772338133146953,-60.427428178507434,-1.0 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark14(-22.28038874316899,-0.13600837148873346,-73.73778709647823,0.18843848827664467 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark14(-22.353415138732462,-0.23882301921637178,-1.5543328635257398,0.9999999999999998 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark14(-22.3773033066356,-0.036852906856929324,1.5707963267948966,0 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark14(-22.423770087553066,-0.18913953850008625,-1.349371219715583,-44.98172080669873 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark14(-22.631149054850567,-0.11138350348024008,-1.5707963267948966,33.68948903618927 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark14(-22.636810230270946,-0.016576317051014366,-0.2431424408938867,-78.73901252147557 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark14(-22.71161759045209,-1.5424026746847934,-18.492653675616125,64.7143927230355 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark14(-22.754768984889942,-1.5707963267948963,-45.745650015520404,40.19963246023699 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark14(-22.763753544337696,-1.5640134628632292,-45.10788616932675,1.0 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark14(-22.943059484650043,-1.5707963267948948,-4.839654318354619,-0.031592513903006665 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark14(-22.95695325784007,-0.5505834473375444,-1.7476607080041906,0.6253700483313698 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark14(-22.97636332159907,-1.059628091810589,-92.59730439867026,0 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark14(-22.97833758494857,-0.44101537635302007,-1.5707963267948974,-34.21005794249847 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark14(-23.025319088228304,-1.5475145166472515,-10.672317417823628,-0.2395625407361975 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark14(-23.089103510904067,-1.5707963267948912,-72.54595074272501,-1.0 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark14(-23.114273418251194,-0.29264229826602434,-79.65183084029384,2.050361954618836 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark14(-23.115431996338454,-1.303289623223025,-66.04260782587636,56.131995364291356 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark14(-23.136080849147866,-1.500217497893929,-1.348496569937541,0.574834410011797 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark14(-23.141877093474164,-0.5582721440609901,-42.6489894469435,-1.0 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark14(-23.163981087988304,-0.5179580371691688,-44.147493139641725,-51.54382129931041 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark14(-23.165660512793018,-7.105427357601002E-15,-0.09155753890350156,99.58905086892477 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark14(-23.171514032146455,14.822108048755595,13.581903676391656,0.0 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark14(-23.25531604536487,-0.5537244090313125,-84.03901730900864,-1.0 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark14(-23.283766438098425,-0.7600229378303816,-34.313725784413414,5.551115123125783E-17 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark14(-23.31903616950443,-0.9614998151136547,-87.91212686538503,1.0 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark14(-23.356288267633058,-0.8382738448159256,-74.71550543943614,-35.72075018054748 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark14(-23.47851564982649,-1.5213616207223173,-33.72918654277526,-1.0 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark14(-23.501322895413114,-0.5049788767121063,-21.299181085850485,43.90370603104237 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark14(-23.581320951720613,-1.3018302390888623,-0.03336023809648608,-1.0 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark14(-23.60145058272567,-0.6049836403968492,-0.05285378632383797,40.04301703103437 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark14(-23.626438016671493,-0.11871741127018096,-10.820713907977435,-1.0 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark14(-23.642143603102866,-0.6999274142338647,-0.39472695040519457,58.36054602054406 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark14(-23.699840443457056,-1.5707963267948912,-93.29888492136757,-1.0 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark14(-23.796085055257535,-0.32913639203759537,-52.83537767262497,39.45131933455188 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark14(-23.800849916364243,-0.8601912395388638,0,0 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark14(-23.842174923722656,-0.5451245272517048,-130.37124342753233,-0.9397669323774718 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark14(-23.918910234775137,-1.5707963267948948,-45.49323342798847,0.7586014741943088 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark14(-240.85786563990519,-1.3784041351650895,-28.076470945919013,1.0 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark14(-24.176666778917298,-0.3876594365593352,82.6123602592353,0 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark14(-24.19083274624597,-1.5707963267948921,-1.5707963267948966,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark14(-24.262228669784335,-0.01568622060007019,-85.59193837626371,0.23046890039016077 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark14(-24.31421505375048,-0.621376691883283,-39.06132675905585,-0.23150307368206224 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark14(-24.32720318371105,-0.871859829803654,-27.924868420617585,-1.0 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark14(-24.387961224704455,-0.036134857747885184,-1.5707963267948966,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark14(-24.401868592897586,-1.4210854715202004E-14,-15.162976665665624,1.0 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark14(-24.55998054456161,-0.06130547548768228,-0.2398846114472151,-1.0 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark14(-24.58927437804784,-1.5707817062794205,-5.086845325843569,0.5899999436598584 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark14(-24.63047966737657,-1.4447481617357283,-0.18858412315908224,19.530849975905905 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark14(-24.64633118213668,-1.4415428795246934,-3.207748482054435,0.9999508530505247 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark14(-2.470246244478911,-1.570173401381432,-8.157437546738564,1.0 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark14(-24.779841789051325,-1.5707963267948912,-62.198324826532755,-1.0 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark14(-2.4790563348979653,-0.46686344401908825,-64.10988691166155,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark14(-24.810669534541297,-1.027305839642859,-44.36793913535209,1.0 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark14(-2.4815462689183545,-0.11106037585967547,-90.78137772609514,-0.005060783481016129 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark14(-24.82712767542997,-0.2840564653712401,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark14(-24.895376850154307,-1.4694211609673333,-55.020696255088595,0.9992793245814373 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark14(-24.898855575364074,-0.0949574471156123,-26.945915486637052,0.9008835280245715 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark14(-2.49283180557393,-0.9797714414431322,-81.57265789850018,17.11637237949992 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark14(-25.09271148615393,-0.9656833893329839,-0.560903657297458,39.82009864062445 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark14(-2.5121866542164417,-0.1932158192769032,0.2208011569164998,-1594.6941314366782 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark14(-25.135886535412602,-0.7773617923402814,-59.640691600693984,-6.791382710969053 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark14(-251.47356786170653,14.43205825236285,0.0,0 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark14(-25.15485278115848,-1.3305819308352367,-7.955934104076125,0.0625537593183767 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark14(-25.199928989785427,-0.16049028969007678,-39.104670213054725,81.5593257078149 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark14(-25.214098958788224,-0.028862453411343216,-49.07358059524966,1.0 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark14(-25.21786427624245,0.344240588325618,1.5144020041573334,0.0 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark14(-25.220428841667935,-1.3754266901914192,-84.03894745461528,-1.0 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark14(-25.260751603941852,-0.08177665389310224,-0.28965391610512864,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark14(-25.389033366777305,-0.8844797762204015,-49.170177816532046,-1.0 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark14(-25.401019963451123,-0.010173270010464752,1.5707963267948966,-12.184148323850355 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark14(-25.404696589604868,-0.15440017688800295,-3.974659240517653,0 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark14(-25.43119824421381,-0.8337514061764577,-44.43132105048734,-100.0 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark14(-25.449052625444878,-1.5214564131441282,-1.482601302355439,0.01777191866018173 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark14(-25.61010273336511,-0.45500616348160183,-67.93743171819045,0.7867969057017135 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark14(-25.654859590264106,-2.220446049250313E-16,-1.1102230246251565E-16,0.0 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark14(-25.731050111324233,-1.5707963267948963,-49.28562651745731,-0.31427212290868306 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark14(-25.744674031182882,-0.018635347734522162,-22.13871330701887,72.50999910828382 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark14(-25.75224846024831,-4.440892098500626E-16,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark14(-25.76642148939442,-1.5707963267948912,-18.838191249147894,0.9055091148761197 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark14(-2.579582274233123,-0.40908622493260216,-1.5707963267948966,0.9999999999999996 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark14(-25.91191507527806,-1.4526883322464164,-51.40366261073253,0.5619375105824522 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark14(-2.5927132353933633,-0.9704518172625725,-100.0,-0.054651480071982415 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark14(-25.941862069216615,-1.5592676798421805,-15.789450542666657,0.3620920761367244 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark14(-2.595716865100073,-1.5707963267948912,-1.5707963267948966,5.410004745572632 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark14(-25.970349889443305,-0.1361961086411735,-0.791931196709754,-21.614288252234804 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark14(-25.98793568944029,-0.5409001046318251,-11.31079493048664,-0.725567427665915 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark14(-26.110446343388844,-0.29813810698793475,-1.4784745088228723,-0.9987965359226354 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark14(-26.182757338517032,7.457421975227214,0.0,-7.006874541626802E-18 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark14(-26.241583764337076,-0.6698059216201118,-71.18836363768906,-0.9999999999999856 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark14(-26.283918396832412,-1.5022233224804882,-4.450113744983786,1.0 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark14(-26.300077347596847,-1.4318706484585602,-30.609533588910242,1.0 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark14(-26.331302409789462,-1.5707963267948948,-74.29973114171172,-0.016107546616093454 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark14(-26.415301241349308,-1.4176455363035405,-40.76782137376349,-1.0000008617922747 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark14(-26.415606793653314,-2.220446049250313E-16,-19.39457588431482,0 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark14(-26.433640118542968,-0.9446752093002279,-32.644111467005274,0.8604887945466262 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark14(-26.44893415780106,-0.3359745242454378,-0.7094594082181129,-49.62996782807399 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark14(-26.471443365314954,-1.1102230246251565E-16,0.0,-1.000005346011001 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark14(-26.586647921871755,-4.886272667138211E-5,-73.6806053578585,-0.0508136493321906 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark14(-26.596226191548407,-1.1535667860161596,-43.62914548799912,1.0 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark14(-26.69349981725394,-0.8222674374098227,-1.5707963267948966,-1.0000018356875833 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark14(-26.697188121461316,-0.06968611161089368,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark14(-26.977491075961048,-0.09510852947090948,-10.867897255623593,-49.94772631588297 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark14(-27.03121314435114,-1.5633923779671883,6.456533608708452,-0.1890750739696756 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark14(-2.7178597841838155,-1.3602688804335878,-50.714037072417064,1.0000018436809848 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark14(-27.21252166619001,-1.570796326794896,-1.2993092384343627,-0.0313711288488673 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark14(-27.21933830158294,-1.0128002237858484,-1.5707963267948963,3.0994853389650334 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark14(-27.24036840550204,-0.14378186445568236,-8.404018877871138,0.6557293822674715 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark14(-27.24059903883962,-0.3681243736998622,-87.84855645254008,0 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark14(-27.242775611808923,-0.8678984594804005,-72.70814818016642,0.015210692982790635 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark14(-27.294687862181007,-1.401437422936183,-77.96726425643953,0.9302655507835857 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark14(-27.366422274854404,-0.10497565178115609,-100.0,-71.15196503214284 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark14(-27.43269109378606,-0.020847109217069434,-25.18325222694816,1.0000000270441194 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark14(-27.511299648625,-0.8872277297994772,-77.59027524556004,1.0 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark14(-27.536590632277758,-1.5517844626941395,-1.5707963267948966,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark14(-27.536759388710607,-0.16877464985574275,-44.62078519322169,-2.276110245260761 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark14(-27.557232374223318,-1.31387602626185,0,0 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark14(-27.641125549229955,-1.4015453291148972,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark14(-2.764337170013359,-0.8891541087229707,-74.05125595327118,-0.9966643607339789 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark14(-27.658512498152557,-0.2114494570111342,-44.61628800627029,5.421010862427522E-20 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark14(-27.669115099906573,-8.881784197001252E-16,-1.5707963267948966,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark14(-27.887735526909,-1.4802803940909577,-67.72610987536129,0.02294938297934898 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark14(-27.912711487202174,-1.066908295913119,-4.489388478185086,1.0 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark14(-27.966044261998317,-1.314426959475335,-89.16061331681613,29.34680675397962 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark14(-28.048733455005628,14.4432315373138,0.20842759795276566,18.49765592276951 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark14(-28.071773986905733,-0.6582895607401529,-47.0980356761651,-31.031030858387748 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark14(-28.095953178149983,-7.105427357601002E-15,-15.4262569409223,4.748054112200828 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark14(-28.099993540613635,-0.1413080249067724,-63.556910004734945,22.09239560218616 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark14(-28.102414618924648,-1.493228364850506,-59.105751202117574,1.0 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark14(-28.13260257049418,-0.267960716491464,56.72579753623369,-1.8033161362862765E-130 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark14(-28.15307720205143,-0.5629093755437755,-0.49123725328299683,50.68573464275056 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark14(-28.179743274639563,-1.244381188433092,-40.57295482496377,29.96454096629617 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark14(-28.214540630347617,-0.04880521340070878,-53.45758286048331,-0.0020219532021460984 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark14(-28.214955373258757,-2.7209285300677128E-17,-1.1351368114064697,1.0 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark14(-28.27986901164205,-1.2339074694183934,-61.95157069594267,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark14(-28.34205828364591,-1.5707963267948963,6.429387332567853,0.2666625489727348 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark14(-28.38675209137887,-0.028143828630544248,-84.51636764652707,11.96493878346314 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark14(-28.43551211312353,-1.5023609872654387,-35.76188447204014,-1.0516536809972268 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark14(-28.455081602443776,-1.2127697595957363,-91.88515993035477,-1.0000059295141939 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark14(-2.846008480532749,-1.2281887103118816,-100.0,-100.0 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark14(-28.464373488882625,-0.19422452173202398,-36.387783600003786,-5.421010862427522E-20 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark14(-28.47764938651181,-4.3502155751431907E-17,-1.5707963267948966,-1.0000000000000018 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark14(-28.498536465027648,-0.05564110744711581,4.6014479383748054E-5,0 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark14(-28.513474874426528,-0.11295734563158588,1.5707963267948326,0.0 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark14(-28.525334334227832,-1.5707963267948912,-1.5707963267948966,-48.1994518397964 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark14(-28.705803404547222,-0.180680238634784,-58.14983412552226,1.0 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark14(-28.738749379700018,-0.3984383353343035,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark14(-28.803825693211394,-1.3613188360063484,-45.077846265778255,41.19234383830575 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark14(-28.815004335904817,-1.5578817791807202,-7.6995803107137135,1.0 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark14(-28.841335108137887,-1.5707960462418513,-31.634169321747777,0.0566848403786981 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark14(-28.86378312179585,-0.034358948032928514,-14.839728169728744,1.0 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark14(-28.957424982783547,-0.0044622163817875,-1.5317455128976885,-0.5205562396732922 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark14(-29.087242476837787,-0.398700187315371,-1.5707963267948966,-23.99830607897833 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark14(-29.08884509814402,-0.27794447281869783,1.5707963267948966,-4.073634868149995 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark14(-29.126667432507027,-1.5645851116753666,-38.342670550806375,-0.7191105634285264 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark14(-29.16748552345339,-1.2351813430232965,-28.609815374360963,1.0 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark14(-29.28679295942233,-3.552713678800501E-15,-63.43904645241221,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark14(-2.9391812667801105,-0.3476056298287755,-101.09922160237039,-0.9999998266707496 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark14(-29.462786405059845,-1.3833664191954884,-39.7502709963886,-2.967364920549937E-67 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark14(-29.466160004910495,-1.5707963267948948,-54.08068998518222,-0.9223058711101231 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark14(-29.47513999252955,-1.5707963267948948,-23.484379014245846,1.0 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark14(-29.585559300104784,-0.07271311870700536,-0.16404048707432473,1.0 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark14(-29.810254174119578,-0.2141680966418309,-9.63342833033647,-1.2781175342120565E-15 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark14(-29.8146406717903,-0.6926193432194507,-0.5664715016412375,30.32455450385741 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark14(-29.944119491185575,-0.3821188146408109,-1.4844765529066932,-1.0 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark14(-29.961990937538882,-0.9833990914256505,-1.1235511089051748,0.010145394975340394 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark14(-29.96957563303223,-1.2728547814967928,-81.68718088028461,0.010708571894239766 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark14(-30.069702538102455,-1.4596919612665566,-0.3864511545055922,-0.4584598838542512 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark14(-30.132389998222394,-0.8462037603452224,-0.40659032559673414,0.8387369952733783 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark14(-30.159431528352854,-1.5707963267948948,-81.98480686013099,-31.444634384903367 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark14(-30.242600204939716,-1.5707963267948948,-41.979533565001134,1.0 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark14(-30.273566019436537,-0.8562759210603613,-1.5707963267948981,0.9999999999999999 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark14(-30.291323074714445,-1.5707963267948961,-63.01176109046408,-1.0 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark14(-30.320834388070182,-1.5410374771568136,-1.5707963267948974,-0.2060859477518716 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark14(-30.406084074638585,-1.4467974107164987,-29.616690699814946,-1.0000112307791618 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark14(-30.412275025136406,-0.05034905539731238,0.0,1.0 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark14(-30.48149565083407,-0.05445775325794822,-0.33322837804954164,0.0 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark14(-30.578243404201682,-1.5055822798247502,-88.1452626391693,2.902270722659585E-14 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark14(-30.659618691274947,-1.1854458861866526,-1.5707963267948966,-23.86552178507452 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark14(-30.670209625592804,-0.25534800575412747,-9.530380649983197,69.42032719906089 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark14(-30.829170689352164,-1.2682669681177448,-4.533107113432571,-1.0 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark14(-30.851798456643888,-0.18335533301232576,-73.46393623943379,-2.967364920549937E-67 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark14(-30.87747560683541,-1.5707963267948912,-38.889337032966964,0.00635669222934393 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark14(-30.88365381463861,-0.023955349816169674,-66.21736259887939,0.2930707631451671 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark14(-30.89127036304481,-0.007319465756588067,-37.28062375902161,0.8293239755596536 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark14(-3.0937106833124774,-1.5707963267948912,-88.34552447449302,6.776263578034403E-21 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark14(-30.983519320764668,-1.57079632679489,-45.48063059886402,-1.0 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark14(-31.025180509389372,-1.2017782911233885,1.768437757316504,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark14(-31.085594101971125,-0.07879364559518645,-0.268327741553967,-1.232595164407831E-32 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark14(-31.10787414574086,-1.7763568394002505E-15,-45.11281822908544,-4.006475132315725 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark14(-31.123208978562502,-0.5588377251744703,-15.366185096760418,68.2189489607697 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark14(-31.172159309209494,-1.5222174380791107,-11.474320508214817,1.0842021724855044E-19 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark14(-31.179850452913655,-0.8574166997668442,-28.845570453255547,-0.5732394314265781 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark14(-31.210549439959635,-0.11421082277382766,-83.42443422643453,1.0 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark14(-31.244463858306766,-0.004615507911693073,49.68911455758326,0 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark14(-31.258802818238742,-0.8471992125769165,-120.49076153274592,1.0 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark14(-31.349162543052735,-0.8440770093724952,-1.5707963267948966,0.9999999999999939 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark14(-31.520269167467603,-1.2250147341145181,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark14(-31.528552332075794,-1.5707963267948948,-61.252714873311845,-1.232595164407831E-32 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark14(-31.59840122222377,-1.5707963267948948,-81.63827716840915,0.05790438795283764 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark14(-3.1621733163947696,-1.4098322267215995,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark14(-31.66679550605577,-0.7450089931147021,-19.090000775134232,-1.0 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark14(-31.766748076713046,-0.8663442619429006,-2.5959803197869045,-0.208456719818912 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark14(-31.7967024258108,-1.1802066644250324,-52.86099692667863,1.0 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark14(-3.179765413884788,-0.07947699657244878,0.0,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark14(-31.80337070195164,-0.007245804351316556,-50.69326862730502,-0.7560806539717075 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark14(-31.842513075543437,-1.156312255628381,-90.35256535969948,0.71325443343822 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark14(-31.991573478525645,-0.050314406158648246,-71.41650718208055,0.7819093434692319 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark14(-32.06654422865592,-0.3884151002968393,-0.01974398558176233,-0.9997486489732873 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark14(-32.13099444961305,-0.1298306947695001,-32.48315837863965,-0.897734390746102 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark14(-3.2166221554396652,-0.5785988962100457,-67.63312467563787,-1.0 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark14(-32.29459421758082,-0.40692513856332746,-60.08129527610815,-46.56787159731015 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark14(-32.3100217715989,-1.5707963267948912,-67.00410563153062,1.0 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark14(-32.33790881476877,-1.5609154053568242,-67.5047942072997,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark14(-3.2358431323811976,-1.5707963267948963,-81.0402373083784,1.0 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark14(-3.2501859638184314,-0.05423360989490018,0.0,-30.402095060577054 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark14(-3.2891557043184783,-1.3623994498956566,-1.1758938159034886,1.0 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark14(-32.923948925043575,-0.7571482260054513,-1.5707963267948966,-0.8374174813636075 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark14(-32.942397029811865,-0.09399497462060447,-1.8876851452983008,1.0 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark14(-32.975822482081554,-0.8778543567116627,-42.39957248567945,14.478267849536014 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark14(-33.09557069416597,-1.0997229451744481,-95.66540040280151,-1.0 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark14(-33.214304265471554,-1.4240020735825836,-76.77132185119757,-0.2103565871248465 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark14(-33.21435228018315,-0.18924558745661102,-22.52194949544632,1.0 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark14(-33.2923023443056,-1.4681861393343567,-1.551454319283077,12.571911246890227 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark14(-33.31683927538235,-0.42880110949935946,0.9823709454728741,-100.0 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark14(-33.38925175148683,-0.8281431821294563,-1.5707963267948966,81.2878352291486 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark14(-33.42930738362509,-0.9652139357506148,-45.195168997870894,-0.16375797236258904 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark14(-33.4914238601286,-0.3112448415820078,-72.52923668010851,2.5988524414112248E-113 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark14(-33.492088864468414,-0.9040071668327879,-65.98918214794551,-0.9994861112485114 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark14(-33.59843642648796,-0.508679862830664,-64.70810266791817,1.0 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark14(-33.66735047826023,-0.28331975890031197,-13.792756727686253,0.4413413594526999 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark14(-33.717530211484394,-0.2286897086889484,-60.97856513392432,-32.59369082312738 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark14(-33.718657442293946,-0.3506453346142308,-7.494889944155588,0 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark14(-33.76861504576034,-0.37707104111193745,0.7668927167002385,0.0 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark14(-3.378362072894703,-1.282910707206026,-5.435748489407089,1.0 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark14(-33.79898925750983,-1.5706379477943522,-45.43360259590738,0.03864574317528291 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark14(-33.800705345408474,-0.8745394550119008,-39.787103236763656,-0.02328163985248033 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark14(-33.8777276852004,-1.3535571338086783,-70.84596642308162,40.78155651453805 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark14(-33.90550815559881,-1.5707963267948957,-1.5707963267948966,-2.313210974185978 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark14(-3.3928463797612474,-0.05233314634500058,6.719161783462664,0.06343719207388807 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark14(-33.97360918511894,-0.3815218259692768,-1.5707963267948983,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark14(-34.03339833074131,-0.1428398522178366,-42.9325156772577,-2.710505431213761E-20 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark14(-34.10776636093468,-1.027850672953658,-51.0538876203772,-100.0 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark14(-3.4137424120936686,-1.5707963267948963,-0.9475240029586729,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark14(-34.152945537330126,-1.4574503092924727,-77.69372145622076,1.0 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark14(-34.183695878213264,14.42920906279464,44.995507450343496,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark14(-34.204512262664494,-0.06259242268238552,-88.58770451533131,0 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark14(-34.251824462391156,-1.178929747259076,-4.134572066376998,0.836263004440795 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark14(-34.272047563318196,-0.023851517090944116,-44.50565032165993,0.02036886391118324 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark14(-34.39355092974008,-1.446977670663093,-79.71569620030792,-1.0 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark14(-34.45029932660606,-1.5489308667006234,-57.93145603650978,0.05150406133394537 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark14(-34.636015900569845,-1.1324553444658185,-84.05990458938211,0.0 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark14(-34.67086013440419,-1.106025148399943,-2.7879845842173165,1.0 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark14(-34.689995715790076,-1.1279004227941698,-97.3584626418127,-67.6281816982718 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark14(-3.471933495396968,-0.6570196042291627,-15.068528758969734,45.0351631909345 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark14(-34.72028488073382,-1.3587056081040458,-60.52976666531209,0.06186441889795764 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark14(-34.801875204462156,-0.25957703243288643,-6.712389388321644,-100.0 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark14(-34.84119224836708,-1.5007270158903512,-31.3605828778065,1.0 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark14(-3.49032040154536,-0.7647507420210962,-41.81120512975656,50.50095958556656 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark14(-34.90528257934195,-1.1985234612980853,-0.9121757813109831,0.5807601050378262 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark14(-34.96801723042048,14.430189721201685,1.5707963267948966,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark14(-34.990565240974696,-1.5707963267948912,-53.06647254058876,-39.21510213390299 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark14(-35.04471033461247,-0.5283118753862439,-9.515338900041291,5.551115123125783E-17 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark14(-35.08009508581789,-4.759412328504036E-5,-1.192108283985459,0.9230467402594522 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark14(-35.12577200345258,-1.0010153125880663,-71.42543156315718,0.0 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark14(-3.5180851188760465,-0.032512641777536634,-6.162225391534905E-18,0.7582673075587301 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark14(-3.5264786351306725,-1.4304449383174955,-35.606361213050945,0.9825076433128217 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark14(-35.29032381425949,-0.5184970786245218,-88.3771955441092,-1.0 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark14(-35.304896462331854,-0.57546231826589,-70.18581620043527,-58.6732501773946 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark14(-35.34390068405902,-1.5707963267947491,-72.17816229608837,1.0 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark14(-35.37466602040128,-0.8366015556292958,-1.5707963267948963,0.3142679049517942 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark14(-35.39349230817125,-0.22018861754630203,38.074572989083094,0 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark14(-35.40743184761559,-1.4425725582291882,-96.18426370385703,-0.005584417369776183 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark14(-3.542706516287066,-1.2329542823523039,-1.5707963267948966,-0.05215101357301049 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark14(-35.45972271409605,-1.2821643361055541,-78.5628996297441,0.0 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark14(-35.48139854237604,-0.22156187412987105,-56.24776004906907,1.0 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark14(-35.558514801008215,-1.5707963267948948,-94.76510108649043,-1.0 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark14(-35.646409956295805,-0.16543165234796353,-41.420670796032596,0.5248774114675464 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark14(-35.70209019746004,-0.2986670576150397,-100.0,0.0 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark14(-35.715104995577576,-1.56296133671081,-15.267226613969356,-75.4100351490731 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark14(-35.74085152963261,-0.49746120761624013,-62.51541314217979,-29.8677886355825 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark14(-35.84670555277018,-0.47055267123783295,-0.0622314432103016,0.0 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark14(-35.85850637708346,-0.014174915385214931,-1.4198397340407611,-1.0 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark14(-35.970050584509096,-8.881784197001252E-16,-1.4597656579295082,0.7072851212620958 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark14(-36.04773060063211,-0.9700489766883399,-38.91461738681192,0.9828905134724693 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark14(-3.6055062829960844,-0.14382475353713164,-36.858053818852596,1.0 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark14(-36.08217822457761,-0.4617998719105976,-24.295078534431923,-37.537799193771676 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark14(-36.12563256960874,-0.059922752900164654,-90.67693099671695,0.8596663029615219 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark14(-36.170694731326215,-1.5707963267948963,-4.084071810767625,-0.9398522597828027 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark14(-36.29874172677468,-0.740552708012419,-36.328389977279066,-0.4441395061493387 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark14(-36.30372160411149,-1.368559430280711,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark14(-36.31072950781137,-1.734723475976807E-18,-0.4381976695808506,0.043598103927863646 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark14(-36.35240450112163,-0.024724652547363196,-100.0,1.0 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark14(-36.413493369333594,-0.8086435116607227,-36.02899671361308,-82.46031027350693 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark14(-36.49711824398889,-1.1102230246251565E-16,0.012795264795453625,0.0 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark14(-36.55043104429742,-1.0569441156495896,-38.89949139628399,-0.26878908339651275 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark14(-36.635932986713925,-1.5128804509290847,-18.435346495199553,1.0 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark14(-36.704702565303386,-0.25600561558413804,0.0,1.0 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark14(-36.72354304720047,-0.7903390096271009,-38.74012947997876,37.604470186047394 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark14(-36.73556853321881,-4.449881056184163E-15,-1.5707963267948966,0.05420903976128869 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark14(-36.78049600079487,-0.4747889326776984,-85.1614505741658,-1.0 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark14(-3.6796003868752227,-0.9176137008611789,-49.23644345404591,1.0 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark14(-36.798146896055925,-0.16629019915677412,-1.5707963267948983,-69.69411363753181 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark14(-36.81418553664539,-0.17466487714594336,-15.715337341624352,-0.06261562248357579 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark14(-36.83713575023439,14.43744495199622,1.0848323942857634,-0.8435051146322836 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark14(-36.98184665816678,-1.7763568394002505E-15,-25.112854769477842,96.9441020485209 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark14(-36.98767665119539,-0.8021376984762851,-1.2204243720776786,86.2362456580329 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark14(-3.7052881992948272,-2.220446049250313E-16,-12.892970242084772,-0.04211056484347314 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark14(-37.19593215498199,-1.0471461731737755,-1.5707963267948983,1.0 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark14(-3.7232216249084207,-1.3885893166423946,-10.19430337766801,-4.008956248873443 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark14(-37.43680111128717,14.432644912220056,94.31617418869016,1.0 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark14(-3.7441073618947627,-0.7243164180445143,-100.0,77.69791547524525 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark14(-3.7489950051991237,-0.13689657055119814,-59.95254063714684,9.51019325860427 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark14(-37.58225829457804,-0.5585298841651678,-59.787679248417525,-22.37354253853097 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark14(-37.60832527924418,-1.5707963267948957,-72.51962458710855,2.1252548900236263 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark14(-3.7741419422771685,-0.6331759104207839,-158.5171338681758,-0.9999999999999929 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark14(-37.80741060953854,-1.5239157398318794,-73.38790672268809,-1.0000000000000002 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark14(-37.818018814095566,-1.558500295119211,-88.52412199108876,-1.0 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark14(-37.8540239996716,-0.7604051656500317,-62.58005257074106,-35.73210697404837 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark14(-37.85709466723818,-0.7332610434178363,-0.3562233670534849,-5.635362925894614E-132 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark14(-38.03111258103129,-1.5607316645213019,-8.78842531059004,0.7477158765655332 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark14(-38.108142380792565,-1.4407975697420454,-64.93624633435647,-59.555315006276956 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark14(-3.8168619154470145,-0.05783416528879834,-38.43191560247737,-2.226315204501674 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark14(-38.1864336150645,-1.0018566052951527,-1.5707963267948983,-83.740018315208 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark14(-38.21572123135293,-1.4782487004735283,-47.48772681082152,-1.0 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark14(-38.239039322944535,-1.5251772985118086,-40.15746568981184,0.0 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark14(-38.25806568931689,-0.4111948183591599,-69.33750430302435,-1.0 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark14(-3.8296131067132535,-0.991135186147371,-13.635384385431253,-59.80954597796618 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark14(-38.354905046717676,-0.0025561645374751916,-26.728304323621217,0.23053694831726745 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark14(-38.35698821052813,-0.04440762153324063,0.0,0.7157264611919496 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark14(-38.362982252305684,-3.552713678800501E-15,-68.46134952277454,-1.0 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark14(-38.4287474506956,-0.8260610406789617,-1.5707963267948966,0.8860721313138644 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark14(-3.845151512439361,-2.220446049250313E-16,-26.40664874049651,-0.023133229115796856 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark14(-3.856386957823058,-0.3591287231777262,-31.54818157606804,1.0 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark14(-3.8569055471925333,-0.5732274145384413,-1.5674141310754677,0.9677013672143454 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark14(-38.569503848629346,-0.6538071839022256,-54.04710778695906,1.0 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark14(-38.591974462766245,-0.11733815723805571,57.41338441460181,-2.0638224518337855E-5 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark14(-38.66976017974648,-1.1503834261539072,-12.320099547288677,0.6500865367222831 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark14(-38.67374794553135,-6.456956692722721E-4,1.5707963267948966,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark14(-38.67686133805388,-1.1085775742547095,-27.967979600957577,-1.0000000000000004 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark14(-38.73266216032062,-0.212283478235278,-0.9776330864764194,71.3580327353259 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark14(-38.7817302942759,-0.1236200531851242,-0.9216929489921536,0.0 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark14(-38.79399271696342,-1.5699951076893799,-100.0,95.70162953444193 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark14(-38.89652535076366,-0.9588067518132171,-94.03411434758058,1.0 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark14(-39.002281534925686,-0.05475407212394168,-1.337627273634673,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark14(-39.08650056896847,-1.2586728829429177,-0.25010860283314573,-1838.0990620905077 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark14(-3.9154596104570127,-0.017786107744957966,-42.84977343775884,-1.0000003568274665 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark14(-39.240695152759,-0.975852784207305,-6.528743796503224,0.4001804338510826 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark14(-39.294578746132885,-0.7600399873024412,-1.5707963267948966,0.9697120972337562 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark14(-39.31766010569788,-0.20278677997078742,-34.05981229230248,1.0 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark14(-39.40149478723047,-0.05586326453502045,-95.5704089088269,-68.66221896221504 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark14(-3.9532155172485695,-0.08200453599909957,-1.5707963267948966,-0.06257772269010482 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark14(-39.60790801739305,1.1373949493373317,1.5707963267948966,-0.08044198776937869 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark14(39.665813966823464,-69.34889350177131,0,0 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark14(-39.673840400182115,-0.8316093938632114,-1.5707963267948912,1.0 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark14(-39.69353533172095,-0.9294692296472226,-0.5163668994186793,0.3066522346298939 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark14(-3.97788406385898,-1.5652673310317373,-86.15647030868081,-0.6193030874251699 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark14(-39.895651548592504,-0.8197758020266441,-41.240003144431,-3.6862730960310444 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark14(-39.94333988279567,-0.9970014884438692,-4.2964692274431115,1953.8660185928863 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark14(-39.95850015251953,-1.0025077982094885,-44.07041945822318,0 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark14(39.98894697421329,-1.5707963267948948,0,0 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark14(-40.032302194707235,-1.5707889315925985,-56.51601743377316,-0.9765825836237938 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark14(-40.07300574244231,-1.14189946483694,-66.30480532852883,2112.762571481813 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark14(-40.10756382488683,-0.03817527028847781,-0.47351849740834917,0.05230622920398309 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark14(-40.208314704029526,-0.15425089036439632,0.0,1.0 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark14(-40.28084626487269,-1.570796326794893,57.63239257341266,0 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark14(-40.3192102290226,-0.081248134711065,-122.8579369775062,-38.50865954647593 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark14(-40.325562597869656,-0.19398666683400023,-99.18789503969698,0.9790511009407572 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark14(-40.368689253609816,-1.2014393248010509,-70.49439465629182,0.945910227211071 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark14(-40.39165869669563,-1.5707963267948948,-63.04645783229853,-0.5524688395553408 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark14(-40.53108839178934,14.434749755700373,0.0,-2018.2653055128521 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark14(-40.543651565502394,-1.1437899750640828,-115.35011622361473,58.34482244091282 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark14(-40.5540330344177,-0.9637689387938349,-98.36568420506084,32.50876529291472 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark14(-40.66212806591558,-0.12228839953152293,-87.2023350258131,61.26716334004182 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark14(-40.66558362572748,-1.5325978866854726,-32.181866837854244,-1.0 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark14(-40.74982773656252,-1.4901682587015481,-53.68034068883315,0 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark14(-4.082294214477315,-0.4599696405788706,0.0,1.0 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark14(-40.83423274112972,-0.8792612605799199,-72.02704761071325,-0.6428242561386011 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark14(-40.9171744662637,-0.1534607878706301,0.07224819981919778,0 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark14(-4.092754880101118,-1.5707963267948948,-51.06687560492824,31.049268657732394 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark14(-40.957666404773164,-0.7316925502026972,-12.82840218036921,0.7732464426783675 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark14(-41.00497543999042,-1.5707963267948946,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark14(-41.08462629393529,-0.2070474666086215,-1.5707963267948966,33.9023691993754 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark14(-41.09010262526316,-0.06031956123647415,-1.5160542752122055,-1.0 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark14(-41.19616625068224,-0.6076939763368706,-2.8820521590193664,-4.2351647362715017E-22 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark14(-41.207635761382264,-0.3070244516934295,-66.83658680564366,71.1934043322603 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark14(-41.27737104921399,-0.23580670748124338,-51.478903873544866,3.469446951953614E-18 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark14(-41.30314686030307,-1.4647857379083153,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark14(-41.463625419257205,-1.570796326794893,-5.1496090602281726,-2.389091777779637E-14 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark14(-41.55997960195326,-0.716668990060766,-1.3103576449234258,-2.6978533579648456 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark14(-41.584065898389326,-1.1102230246251565E-16,1.5707963267948966,0 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark14(-41.71858016197854,-0.02142509947340443,-31.859797131272092,-0.12975639664225547 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark14(-41.779877251306424,-1.100807051267094,-89.48293132150727,-1.0 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark14(-41.89436058528794,-0.003768791434897402,-15.222190356313874,-1.0 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark14(-42.02320121453764,-1.5707963267948877,0,0 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark14(-42.08700899257617,-0.06179909793561267,-96.13578197896682,-1.0000095091561692 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark14(-4.216994199906537,-0.7073054413231574,-55.98042043342737,0 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark14(-42.17290763426222,-1.5707963267948912,-8.450654394391968,-0.724893269259125 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark14(-42.33318085210398,-0.4886454884160383,-46.66276222388328,1.0 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark14(-42.36463408552134,-1.5707963267948912,-73.757237254639,10.850183958900004 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark14(-42.377967933778265,-0.8918273369599393,-1.5707963267948966,52.35426032049811 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark14(-42.39511238368781,-1.330689501700393,2.9360108972551813,0.0 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark14(-42.471758304587226,-0.8585301051736599,-0.4256343255196233,2068.50721652967 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark14(-42.50297325268856,-1.5110128780552354,-7.035947107426851,-1.0 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark14(-4.274553802526375,-0.4880805485124916,17.532874344538797,0 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark14(-42.78466616449909,-0.04344015840355961,0.0,-0.9999999999999991 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark14(-4.281992894833536,-0.6238547368943114,-64.43990720624467,1.5520389882867676 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark14(-42.86738398240031,-1.2047309010100782,-1.5707963267948983,1.0 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark14(-42.913819173366406,-0.5119841628219641,-101.92039423464101,-0.5940164211522188 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark14(-43.0512123182587,-0.35004538434849825,-1.5707963267948966,0.38464058758366737 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark14(-43.079309480565485,-0.5794917061139842,-4.356281563018555,1.0 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark14(-43.117171182764665,-1.232358693759163,-67.29014493310271,-1.0 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark14(-43.18156954201834,-0.023714772209170898,-45.1367099557876,-0.05011927325291151 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark14(-43.407905091131155,-1.5707963267948735,-92.86459764438533,0.3463008028144426 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark14(-43.422670862989605,-0.7604441361933371,-36.405218260043824,-0.2569141973965432 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark14(-4.351330109673597,-0.8397396822035481,-31.59327852163917,-1.0 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark14(-4.358376819552727,-1.5707963267948948,-8.093208285925769,0.9798076075652967 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark14(-43.641812803576904,-0.3454094115219317,-25.3772204221406,1.0 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark14(-43.65271698109215,-0.3112177787497648,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark14(-43.750083212531166,-0.6995481682623819,-37.8781874995446,0.7626767865954296 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark14(-43.762742164538714,-0.7760367427645356,-100.0,1.0 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark14(-4.383130301617698,-1.5707963267948961,-14.669909907695967,-1.0652089060486167 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark14(-43.84123362431359,-4.827582660677156E-6,-61.742497656286844,0.0625656587201627 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark14(-4.385208279346166,-0.7523291672056994,-136.03769685986697,1.0 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark14(-43.90724217525981,-1.5685499485802932,-0.11780871746882901,-1.0 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark14(-4.410137304466448,-0.051505025793809944,-32.667589222912056,1.0 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark14(-44.114255285693474,14.429681743529933,0.0,6.665833213921519E-16 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark14(-44.15059182861164,-1.275966463881043,-1.5707963267948966,-90.73332530274385 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark14(-44.16277569489375,1.6491719463893222,0.0,0 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark14(-44.183821803529426,-1.038720528044106,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark14(-44.2843902288748,-1.2735167801456835,-32.14331206040361,0.0 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark14(-44.28605434148234,-1.1957100517960761,-53.12257855986464,0.6544006690099502 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark14(-44.29683271409681,-0.09549794300145575,-1.5707963267948966,9.363352709384397E-97 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark14(-44.32457037036585,-0.0060928613917957675,-0.2633532577464246,-0.06255278829238112 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark14(-44.34233216121429,-0.8741697534021746,-95.20366362669523,-15.569424757582013 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark14(-44.343569873078735,-0.8064968744465539,-63.0958338428906,-3.2383856937135613E-15 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark14(-44.34883122594399,-1.4789834248158857,-100.0,2.6727647100921956E-51 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark14(-44.38299606306911,-0.45313910335405805,12.76364317687981,0 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark14(-4.441482885526742,-1.5707963267948912,-53.7092249114123,-1.0 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark14(-4.459798501671202,-1.0325698828857708,-65.84759270187683,0.0 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark14(-44.61261971543207,-0.44577092781588457,-17.927781266601738,-1.0 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark14(-44.63620546635515,-0.9640858509475931,-100.0,1.0 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark14(-4.469290247146969,-0.834245941399259,-39.15872475564873,-57.36682335964812 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark14(-44.708261465866045,-0.17746168956144914,-10.295841089812562,-0.6142116929895001 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark14(-4.475316098786189,-0.30065208438537827,100.0,0 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark14(-44.77939778442057,-0.14037971673056937,-10.091592998261945,1.0 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark14(-44.843359604093685,-0.6463533373595709,-55.42270175044193,0.06298573592585657 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark14(-44.86989639677109,-0.07852433490043254,-95.18422943611321,42.55413404234611 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark14(-45.0788259856944,-4.440892098500626E-16,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark14(-45.084315187418895,-0.3454249126690577,0,0 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark14(-45.11283973299584,-0.9989557787660791,-36.3070299928302,-1.0 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark14(-45.19432605693162,-0.45771181401863414,19.35925779089871,0.0 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark14(-45.20585706233535,-1.5707963267948961,-88.51105766888449,-36.93566376293268 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark14(-45.221947230116214,-1.5707963267948957,0,0 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark14(-45.260326009447404,-1.1343484379414841E-14,-0.0163960249183287,0 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark14(-45.2698155211623,-0.010035669505376994,0.8088453758270853,0.0 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark14(-45.28871965614316,-0.0896486560084111,-72.70663596110441,0.0 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark14(-45.29501300430171,-0.2719668244744655,-32.477677801519505,0.0 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark14(-45.47303782369617,-0.5656948966342026,-53.23611562133701,21.53567711048632 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark14(-45.52319343463352,-1.5707963267948963,-1.5707963267948966,39.49629597356145 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark14(-45.5577401512518,-0.18917399395579015,-36.14854518879406,-53.849354422115006 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark14(-45.67782703538725,-0.30404040105313074,-0.73921399631189,-0.03652915737128991 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark14(-45.68726077886762,-0.185589623471496,-90.49418266742512,1.0 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark14(-45.7450917429737,-0.8687966468350895,-56.24714736113748,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark14(-4.588666669036918,-0.8408119623924674,-0.5228719190534875,-27.733756509943376 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark14(-45.890556432731785,-0.5992827700459351,-220.01585983666618,0.36733533743555036 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark14(-45.94330557470045,-0.7652472021396599,-1.5707963267948966,1.0000000000000004 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark14(-45.97225787005215,-1.3239652043057382,-92.0687414345568,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark14(-46.171972180593265,-0.13301432844640276,-82.08110055374513,95.63255290815792 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark14(-46.228485773728046,-0.007259942541065351,-27.31617827092336,67.58979147999838 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark14(-46.272974683360545,-0.033523853801318115,-1.5601068329110543,-0.9048283409183884 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark14(-46.342106323526735,-1.0011226251930054,-19.95839699198396,-2044.5491985168467 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark14(-46.3540448206213,-1.2538809803549236,-1.5707963267948983,-0.037381077234588056 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark14(-46.4092728182662,-0.5840577519547342,-0.7655342571671548,34.49460669583297 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark14(-46.41606746009308,-1.4928253523145822,-13.086588701775497,29.12636267322594 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark14(-46.458628750425994,-1.0458470005601198E-15,-1.5707963267948966,-71.88359668107492 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark14(-46.47397348491505,-0.22738931382990757,0.0,0 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark14(-46.57752608238065,-1.5707963267948961,-13.517656627767078,-0.9628699676119903 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark14(-46.57793896113553,-0.29235722356103555,25.19941870934204,0.0 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark14(-46.63210312879528,-0.7422175288888084,-35.74259677834415,-0.9513738411481308 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark14(-46.640268558936526,-1.4774307192297753,-31.798684757964352,0.0053022599064810605 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark14(-46.76436596033422,-0.11898741100279686,-62.532537421235034,-62.43757179504479 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark14(-46.94972961862145,-0.4281491137460165,-83.66121263436028,0.21730858009688148 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark14(-46.95363130087805,-1.5707963267948912,-26.734117863876165,-1.0345121782554432 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark14(-4.698448869192582,-0.9395422313170787,-100.0,80.83152174635364 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark14(-47.04602550752117,36.41987898556704,-79.5986301201699,0 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark14(-47.127615171341034,-7.105427357601002E-15,-56.88086498606755,43.34481508625208 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark14(-47.19185032222866,-0.7031288166709135,-129.01789804771786,-1.0 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark14(-47.23393256971265,-0.04928549849724139,32.92507172396151,1.0000010548315086 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark14(-47.23944202052985,-1.5707963267948735,-76.67095213628137,0.9999999999999942 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark14(-47.26055923222903,-0.042650677702231125,-136.1464519753692,-98.27576623862629 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark14(-47.29328620284564,-1.4484828569105632,-1.5707963267948966,-0.9914730158829523 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark14(-47.33233868655746,-1.4351591454949564,-74.7948196810662,0.3434528008898843 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark14(-47.54525885126457,-0.46152623958805405,1.0835527389239115,-21.98309176440801 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark14(-47.551487711094005,-0.13969592987744509,-2.2204247740516566E-16,-5.421010862427522E-20 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark14(-47.65553500273638,-4.257078108741789E-17,-27.288562695505988,-1.0 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark14(-47.79634400267931,3.3720905230509657,1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark14(-47.85642264211279,-1.498504674047924,-15.032764688829433,-58.29951918667269 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark14(-47.90630755189141,-0.22754833556721982,-0.03519054814163029,-0.2689083577290809 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark14(-47.9197094995289,-1.3734731938691067,-38.85254741247322,1.0 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark14(-47.926059497769074,-0.013516521836791032,-0.6263068609829404,-0.8036328198614693 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark14(-48.002127953687086,-1.7763568394002505E-15,14.465540545045847,-50.36068099800547 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark14(-48.20575270185691,-1.187891183318559,-50.54139500877082,-0.060696518612792114 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark14(-4.82128604596244,-0.7015946295601623,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark14(-48.23669135927686,-1.2947003256109255,-1.5707963267948857,-3.363857369940874 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark14(-48.266028853464135,-0.014374092318744657,-1.5707963267948983,-0.8949591874247441 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark14(-48.290198061191454,-1.5707963267948963,-4.668753750835362,-32.459378843470496 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark14(-48.32714595166,-0.8298070692631945,-100.0,64.42803310198806 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark14(-4.835473157123314,-1.5686405149987839,0,0 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark14(-48.59186145549644,-1.4512393171278146,-0.7044153173859117,-1.0 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark14(-48.724437795844636,-0.7399381085087646,-55.467151620542495,0 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark14(-48.75861937285381,14.4292334012112,4.3368086899420177E-19,-0.7115514549779044 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark14(-48.79014319650972,-0.5675644816456611,-88.21851202837419,1.0 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark14(-48.80329970257381,-0.06248947436819974,0.0,0.9603529150108666 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark14(-48.81064820000441,-1.298397527699407,-1.5707963267948966,67.0782650767916 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark14(-48.87276935273601,-1.0139439848044058,-67.4595283974549,0.9498125472511 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark14(-48.987357904083446,-0.11626276497555142,-1.5707963267948966,35.48597933131254 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark14(-49.02302403430498,-0.011209866200608968,-70.49720325328498,-0.9847394074587963 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark14(-49.0814116637587,-0.8551930719567764,-31.44137181358542,-26.975622398540395 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark14(-49.126522495819685,-1.3645213921674069,-1.570796326794695,-19.842192009123565 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark14(-49.132301994183095,-0.048633689555768134,-1.5707963267948966,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark14(-49.16932671224278,-0.9029885754131186,-26.092998395598244,-0.7230540531701735 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark14(-4.929596875431336,-1.5707963267948912,-90.06961891422772,1.0 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark14(-49.299823254811514,-1.3364243392426849,-37.86098351794997,-1.0 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark14(-49.470393424022966,-0.0428482390837367,-1.5707963267948966,-21.515914447769028 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark14(-49.495442954011594,-1.4791077709368128,-55.28188207974724,0.05223941511498298 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark14(-49.52144060428669,-0.17976144911891406,-44.41047585623433,0.027336579876940714 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark14(-49.53896921903546,-0.34059835113807607,-9.81023469850087,-1.0 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark14(-49.59228186293447,-0.4881174074981052,-66.01388538858666,1.0000000005537852 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark14(-49.63725519485737,-1.0170911628367376,-5.576133867084749,1.0 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark14(-49.69763405796872,-0.1838185508572784,-1.5707963267948966,-0.13223187503173328 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark14(-49.70722947240913,-22.80560216567622,0,0 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark14(-49.72701070548205,-1.5707963267948948,-31.15095259987869,42.350760614604354 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark14(-49.774414907024834,14.511810832453662,-0.03919243233632031,0 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark14(-49.814607719232626,-1.3386760148466559,-7.73932107998165,0.04056441946214276 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark14(-49.81505365570973,-0.3788929456301689,-97.46205655686299,-22.79418041674084 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark14(-49.820070573345966,-0.04297062802557661,-32.472860271488585,42.94116714520918 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark14(-49.856562633625025,-0.35037727134410024,-43.322240869613466,-29.7307220514325 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark14(-4.99549295553452,-1.4150802663731676,-1.2701773695251803,58.32850538054373 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark14(-50.01651552697446,-0.08123732412663531,-49.02153253855672,0.0 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark14(-50.045954279141846,-1.5707963267948957,-89.27911261047576,-32.74339793796927 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark14(50.081884783644256,25.16774322333559,-71.33582096020798,0 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark14(-50.160508607189605,-0.1782559630561579,-113.84346370731119,0.06270173990525213 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark14(-50.204647800731884,-1.3313101293681584,-37.01681553699641,-0.32047184610868984 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark14(-50.24680005152465,-0.5895591147283841,-1.5707963267948966,0.9562782897918543 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark14(-50.29918428015491,-0.3225610961635706,-0.45466153940008364,-9.876012283139787 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark14(-5.035792035128736,-0.6730013912151227,-151.94998480667903,49.86710743086641 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark14(-50.37338221053119,-0.4692733147860615,-1.193732010551841,-73.48950047377363 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark14(-50.47690529330457,-1.5707963267948948,-0.6524846710640025,51.68526663179986 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark14(-50.508246858937646,2.7244347577894383,95.29811133552198,0.0 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark14(-50.54151948748014,-0.8802594035497204,-0.2734571890441173,-39.13089658462088 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark14(-50.5517868979793,-0.05140971617935901,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark14(-50.66052301681677,-0.37936043853201906,-1.2245927732983288,100.0 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark14(-50.69049402141962,-0.8316025038418137,-70.1405069278795,-1.0 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark14(-50.77457852747283,-0.9826161572062755,-69.53838864466087,61.10362930865553 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark14(-50.88911434292723,-0.2770637534899266,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark14(-50.94582188855554,-0.48553874291283305,-1.5707963267948966,2035.198976318853 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark14(-50.946958675336894,-1.4819614730628579,-62.7375527920343,0.0 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark14(-51.09839788290385,-0.33162237925488647,-5.3369404930234055,0.36679367172728594 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark14(-51.12968842577207,-1.5169520810978128,-71.5379292050387,0.8246081836792902 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark14(-51.22620494910347,-1.5707963267948961,-99.35787957642233,0.016498463248943135 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark14(-5.124425052961669,-1.5E-323,0,0 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark14(-51.25791733724704,-1.1258966679539242,-31.94014416679194,-1.0 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark14(-51.33947339487979,-0.07673361065354957,-55.13918493256165,0.0966699380044247 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark14(-51.37330959043009,-1.5242918981600593,-8.881784197001252E-16,2084.9135413882773 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark14(-51.40739720100183,-0.2874827137469234,-49.52487303130625,0.04975366300906269 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark14(-51.420337461045115,-0.24280069859729886,-13.481803104230352,1.0 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark14(-51.42129746822471,-1.5666295185314087,-100.0,-9.326679268088 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark14(-51.523258074300045,-1.5269355609539486,-44.45140421765865,0.5113364924377981 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark14(-51.55743948503915,-1.0143141323292273,-24.139229157811187,34.7023194095307 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark14(-51.56544984348314,-1.40248662384632,-0.38101292603986536,-0.7737497253121778 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark14(-51.609609581671734,-0.008916157211808273,0.0,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark14(-51.63055868392051,-1.5707963267948948,-61.23953550249785,0.2102938574755443 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark14(-51.63509821989975,-1.2783297919481242,-18.131335965089605,-0.4179194241201104 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark14(-51.67047421708089,-0.23673217374404065,-1.5707963267948983,48.089009770971344 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark14(-51.831879539543955,-0.8437081894133884,-31.695954053869983,16.52035901646805 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark14(-51.8590775595221,-0.7227321685684132,0,0 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark14(-51.8808996369426,-1.5707963267948948,-90.43691250380132,-1.5130753293367017E-15 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark14(-51.91955313493033,-1.570796326794895,-1.5707963267948966,0.44040420110790973 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark14(-5.19487162906583,-1.3197359016908288,-11.448154054431939,0.13990349253159184 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark14(-51.960230344704584,-1.5707963267947385,-45.5217721749753,21.563307362958625 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark14(-5.198847784069784,-0.037831524534723604,-99.42261200155359,-0.48733013265838143 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark14(-52.082708943207116,-0.2544168792473991,-96.51878085605563,-64.17505532946993 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark14(-5.217728324558835,-0.9493038266972404,-9.91330801743662,1.025678352059785 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark14(-52.250995645457316,-1.5707963267948948,-8.776119557353539,-0.2026145863222082 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark14(-52.273993208401315,-7.105427357601002E-15,-99.74120644338078,-0.989895146587946 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark14(-52.28847402578858,-1.5707963267918785,-73.52684292720413,0.8348912431760367 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark14(-5.2306438708678895,-0.22312723884978725,-1.5707963267948966,13.058720648155422 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark14(-52.3322273282161,-0.08742320014808727,-27.208867318064613,0.05152402765656319 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark14(-52.474404217676955,-1.0982184088691798,-1.5387641736492306,21.420365901835645 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark14(-52.61948597030918,-1.5418545478575076,-91.57712975425909,-0.9430597191610192 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark14(-52.70619927283946,-0.007899444215056804,-44.0399787933884,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark14(-52.718440078419455,14.42922118324698,0.0,0.9999999999999252 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark14(-52.772680975203286,-0.97250063853572,-6.880169656375173,-0.028172501337722866 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark14(-52.78129907906856,-0.010015974772936436,-1.5707963267948966,0.035548856839971776 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark14(-52.81918189547241,-0.4164977094513801,0.0,1.0 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark14(-5.2864387005423445,-1.5707963267948912,-49.8095653208067,-0.03384242876925401 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark14(-52.90848529792393,-1.570796326794889,-67.97898055647217,1.0 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark14(-52.924620694616365,-0.39086562873915187,-45.80418271932948,5.421010862427522E-20 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark14(-53.16415407517802,-8.881784197001252E-16,-13.189997865350147,-2258.8897971375436 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark14(-53.20331368045865,-0.08324485987510562,-80.17251258499647,0.041680254914243875 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark14(-53.21797273252231,-0.1984642876709642,-61.90127706550579,-1.0 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark14(-53.235584399472586,-1.3421969180264774,-19.603517603942866,-0.9999999999999964 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark14(-53.46929604494919,-1.1656999472072003,-9.693499580058766,-0.5431259479493229 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark14(-53.47603370513646,-1.4605652325776064,-26.948217651680817,1.6543612251060553E-24 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark14(-53.49499121421098,-0.7659820625589095,-30.69299244712367,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark14(-53.68133744267489,-1.5393321298483398,-70.10304012902382,86.9209681040775 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark14(-53.689980583714025,-0.5615179576353017,0.7690157762104726,0.0 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark14(-53.735460099886204,-0.9631355813473863,-73.81239294956092,-0.9936594724776987 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark14(-5.376475337745376,-1.0046053256579053,-0.11376231898658687,1.0 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark14(-53.86239595751047,-0.5265386474023286,-66.29581429211683,-1.0 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark14(-53.87577061336762,-0.0188230259928085,-45.106402070828395,-0.5725566636963353 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark14(-53.903390513492006,-0.5503546967273584,-9.18853415427113,-75.4085799772716 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark14(-53.91746140431033,-0.7036228221006552,-11.673402300936685,-0.03263116581871506 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark14(-5.4102650439728315,-0.5184395415941019,-38.193853694841565,1.0076806347075384 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark14(-54.10482000080578,-1.5707963267948948,-78.11464706165204,25.98550459800928 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark14(-54.11701245462591,-0.13707045506957222,-52.62054330851971,68.77219700764954 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark14(-54.12310827464876,-1.277930092257204,-19.962849330354636,1.0 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark14(-54.30847539097934,-1.5707963267948948,-4.759801542858142,-87.69493426683326 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark14(-54.31697407709657,-1.5707963267948948,-47.36823183099309,-39.53353525832272 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark14(-54.43024104107678,-0.5814581315187521,-7.182054407803169,-1.0 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark14(-54.44575626500944,-1.145585167678198,-28.35624910018484,-0.3653024153004574 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark14(-54.49972139929812,-1.5241164355745982,-76.36649143977843,-1.0 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark14(-54.58456267364355,-1.5461320347452074,-87.34799137615661,-1.0 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark14(-54.643876216066054,-1.521806064262055,-21.457914637418398,-1.0 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark14(-54.64509260033285,-1.0124343847449901,-37.10128288178961,0.8928732496222014 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark14(-54.669019158539925,-1.273715412048503,0,0 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark14(-54.67380683362088,-1.5707963267948948,-1.2306990813178054,13.70531126650164 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark14(-5.469515295444015,-0.3629722439527896,-4.447532207387158,-2211.561719791305 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark14(-54.704893917764544,-1.2711503490663154,14.431381651216604,0.08091252704046191 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark14(-54.74711492040591,-0.9535774566019577,-44.30289544108638,-0.9999999999999999 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark14(-54.84344218834174,-1.4906071297094914,-1.5707963267948966,-1.0000000032348473 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark14(-55.07631569439567,-1.5707963267948948,-34.92314730683515,-0.3744168241616723 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark14(-55.09121385752015,-0.0741011876347539,-15.217091979300257,-0.01485181002378238 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark14(-55.14433799026885,-0.9571551909672023,-7.580472653835798,-1.0 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark14(-55.284499408341766,-1.3153521820365892,-39.027956238528084,0.7682765709478468 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark14(-55.320955312049264,-1.2720765964365626,-9.000091227400972,-40.968936462269845 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark14(-55.33608979808173,-1.317229403446523,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark14(-55.3702847037935,-1.2121350217497735,-45.39155127171459,0.37211290643951944 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark14(-55.38966069838781,-1.238762053314382,-1.3225884538836723,-70.25695761154479 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark14(-55.46942574865361,-1.5707963267948963,-65.7164306140854,0.48677443039212775 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark14(-55.69816207713659,-1.57079632679487,-22.85517613646661,2324.828240080757 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark14(-5.582561570858644,-1.2032909609780715,-95.7895765119717,0.32561688055334626 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark14(-55.8554730198892,-0.08947019827510871,-5.996343752966606,-4.460222118845891 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark14(-5.586294063270453,-0.199439101647794,-0.4976561514249891,0.6027628078263945 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark14(-56.121014499199696,-0.08105833758488812,-136.31946818888866,-73.35268655474806 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark14(-56.17869276376947,-0.87123013954261,-41.65547675763314,-1.0 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark14(-56.216080229156496,-0.5431815309764536,-62.13077673765941,-19.059710575059214 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark14(-56.22563397128315,-0.48955493832997377,-64.70057452572163,-1.0 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark14(-56.23992937131722,-0.15722513072464034,-14.92292945815182,-0.7750222622814591 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark14(-56.32908755474564,-0.31765335308002385,-79.15467057297883,-57.17918400416273 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark14(-56.44318286007272,-0.006397689084720548,-53.87719871858872,0.6551226143483863 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark14(-56.455515898693626,-2.220446049250313E-16,14.430279575795502,13.666279040853047 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark14(-56.48636079760551,-0.7067842840421755,-72.01936697471126,-1.0 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark14(-56.65412191779329,-1.1213853688254927,-77.8578359921597,0.5999216515420194 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark14(-56.713560934537895,-0.7194037747315818,-1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark14(-56.7329975354381,-0.7720271519764889,-96.38026509147886,-0.024123079923695556 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark14(-56.790046248091144,-0.7638273667155393,-51.55366067451637,1.0 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark14(-56.80443742035726,-0.5136550792479514,18.17434920990995,0 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark14(-5.680892217081235,-0.0783892392940825,-26.788894529495956,-0.027768856138176923 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark14(-56.9014919758871,-1.557839186129311,-94.21785497149908,0.9999999999999999 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark14(-56.93056390010969,-1.5647338977860827,-0.38630630542471345,0.0 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark14(-56.9443665071907,-1.00321969630939,-1.570796326794896,-1.0 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark14(-56.967017709623356,-1.1200855827869702,-52.11950418027882,1.0 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark14(-57.033228987791034,-1.1102230246251565E-16,0.0,100.0 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark14(-57.06265633867013,-1.4578760723755313,-38.18278777721633,1.0 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark14(-57.182274450047245,-0.19561578517759243,-83.47703135944093,15.284256097319826 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark14(-57.306481688362766,-0.6254081620181182,-81.50096153346988,15.656227225901741 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark14(-57.3296736647727,-1.5707963267948963,-9.4606215485591,50.241074485785234 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark14(-5.734945503231368,-1.2451074169667848,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark14(-57.36518710143072,-1.5707963267948948,-1.5707963267949019,-0.0625548055251516 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark14(-57.374002881050835,-1.5707963267948961,-34.48144583257847,-1.0 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark14(-5.741789719498521,-0.5237599537292589,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark14(-57.49957949746078,-1.5707963267948948,-26.585768226745536,-1.0 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark14(-57.585033870487756,-0.4416864263945395,-1.5707963267948966,0.979306722905546 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark14(-57.59683238489385,-0.5236127490350437,-32.793798064734524,1.0 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark14(-57.67932081443692,-1.088365110105613,-0.39888266567744834,-1.0 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark14(-57.836618234530704,-1.30826483235026,0.1862982708360289,1.0017780111457524 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark14(-57.85124840259472,-1.5707963267948912,-73.51467463128951,-91.83508942402787 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark14(-57.90216567416736,-1.0465938065177758,-58.910061547640204,-0.9999999999999929 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark14(-57.985766846703754,-0.20555084798910173,-100.0,0.9971510678885604 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark14(-58.0919557408659,-0.6820691951091978,-35.679871258041295,-0.05282136962258463 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark14(-58.14505347397932,-1.515447543331857,-26.576641698870304,1.0 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark14(-58.16672884571046,-1.5707963267948912,-102.45270709175821,-0.41994162449875105 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark14(-58.27642350315264,-1.082888884280929,-111.28346681837036,0.4682440711454785 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark14(-58.3121242640002,-1.165671775545254,-67.30675046136946,1.0 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark14(-58.35545511094797,-1.1787762336379832,-11.96396568968298,-68.37561021701494 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark14(-58.572846493583945,-1.4603179199060021,-1.5707963267948966,0.9256469240167773 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark14(-58.73523477410269,-2.220446049250313E-16,-8.670046317152224,0.960826677926255 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark14(-58.7430281100964,-0.525705320966542,-0.3505671848902885,0.0 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark14(-5.875720001687746,-0.30599543089180603,-88.20656905939606,-1.0 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark14(-58.76471221356943,-1.4171903961062189,-40.68844526599389,0.9999999999999998 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark14(-58.77803738307428,-1.4054960334951123,-42.97914875707593,-1.0 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark14(-5.885078958613406,-0.1400681674413832,-10.465721465521561,1.0 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark14(-5.889920572451345,-0.4662170902638282,-42.35138310344602,-1.0 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark14(-59.003639006036025,-0.09078707295498019,-1.4524873579653743,0.9980848249905453 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark14(-59.01395087708271,-0.19117291314842544,-59.77423099662305,0.7689012878468962 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark14(-59.08512874274434,1.9721522630525295E-31,0,0 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark14(-59.08625865548675,-1.0094710477890214,-1.5707963267948966,159.2863281024715 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark14(-59.10871989772641,-1.5707963267948912,-14.862756943214592,6.938893903907228E-18 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark14(-59.14776735291557,-1.1846658278508009,-66.16298038262363,0.483758240724789 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark14(-59.22199186368572,-0.23602898929070132,0,0 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark14(-59.25459553344805,-0.9667415603488161,-26.832368162570305,15.184090591086616 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark14(-59.32493827175646,-1.445974747610692,-0.9515236279972273,-1.0587911840678754E-22 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark14(-59.34150795471504,-1.0847343493640473,-19.357063614769714,95.38185223824743 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark14(-59.36982248116945,-1.5707963267948948,-1.6390492758569168,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark14(-59.493979030993664,-0.08865340161874442,0.0,-13.401463175926589 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark14(-59.647459486245616,-0.25656559223160724,-27.013888851385033,-0.15210251505996664 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark14(-59.699366990752516,-1.0296816320344782,-11.75333001462051,-1.0 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark14(-60.02029947222368,-0.14588279096866769,-1.5707963267949012,0.9779098214687763 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark14(-60.25405855573464,-0.032086600006181076,-5.027487355434625,-0.8606708935445639 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark14(-60.30860056958856,-0.3214926969097718,-102.05466814105283,0.999996453262907 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark14(-60.34504202215516,-0.006827572462025281,-21.021330786090275,0 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark14(-60.42194921447923,-1.0268940563688744,-23.598482295020226,38.569490927018116 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark14(-60.42869612653291,-0.21003291204644312,-38.07521960353204,0 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark14(-60.44059020968384,-0.8136856228188328,-3.234032152655871,-0.9999999999999992 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark14(-60.47840385262495,-0.46451554462773365,-28.02314063234573,-23.645599987544415 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark14(-60.48385299972722,-0.9069751518984597,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark14(-60.51276605572775,-1.5707963267948963,-0.3277693375782733,0.7097045218768152 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark14(-6.058557048267609,2.4961413512731307,4.736050586472009,0 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark14(-60.59055970659587,-1.5707963267948963,-82.86985371133754,20.64157054890168 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark14(-60.7132950676504,-0.9216243404898168,-70.1747486440444,0.0 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark14(-60.73739981809259,-1.4888874296601584,-8.980477997688938,-0.1389147591314479 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark14(-60.7456295093464,-0.9738534656496967,-112.89821839844704,0.0 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark14(-6.0753586787842275,-1.231584998211599,-44.32026320195825,0.0 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark14(-6.080110490170025,-0.9034047936646813,-15.753353054896639,0 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark14(-60.82083664369546,-1.269045113913748,-1.5707963267948966,35.374212595812 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark14(-60.916141140262646,-0.9170779877981867,-10.890510463171271,-0.7935163578277731 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark14(-60.951924317928,-0.6770324955126892,-59.451575043367555,-1.0 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark14(-60.97969193665422,-1.5707963267946248,-72.2312158416673,0.04325627310446123 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark14(-61.012360286245325,-0.5605427069957855,0.0,-0.4690216452639272 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark14(-61.09534318295098,-0.24290977724179863,88.08994918465042,1684.1225586953574 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark14(-61.13672982105538,-0.6834042034455986,-83.10624222396193,20.436902112060068 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark14(-61.307020738338544,-1.2958023530862368,-94.28960241127488,-58.038952896724204 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark14(-61.496440983242586,-0.18557876130011233,-94.34160567813906,-62.707740661637914 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark14(-61.558774893493116,-0.002317607978746139,-90.02064080989798,1.0 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark14(-61.64078463304017,-0.2672067597109118,-1.5707963267948963,10.07355243914471 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark14(-61.701842095288924,-9.803121688977518E-4,-64.31297615589537,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark14(-61.703726965619026,-0.04651497041956376,-1.5707963267948983,4.6386475466691195 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark14(-6.173882962585367,-0.13169964777163967,-1.174847031338711,63.224642204727516 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark14(-6.181831199887355,-0.39192565439030125,1.4270919109781182,-2050.6084551695494 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark14(-61.82990861450314,-0.08800506971070989,-1.5707963267948966,-0.9999999999999996 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark14(-61.89390392188508,3.8816793373308154,0.0,0.0 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark14(-61.91215430333409,-2.220446049250313E-16,-69.96854173815643,0.023482524874468447 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark14(-62.034062281730805,-0.07592711972394856,-57.759911656588905,1.6940658945086007E-21 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark14(-62.07713767637601,-0.2632330760885351,-24.16213452161803,1.0000020527661586 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark14(-62.255478276198765,-0.09497017912498841,-11.407549147535427,53.498066738026914 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark14(-62.72064847958061,-0.24551300560869427,-45.434245130171895,76.72144570939679 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark14(-62.76620288623108,-1.0822889662320145,-45.804661824250026,-44.52186196912808 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark14(-62.84684676865926,-1.5707963267948037,-31.055126918334494,-1.0000000628701595 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark14(-62.99289184408893,-0.031162618781144583,-27.260263778682372,5.551115123125783E-17 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark14(-63.01297267802229,-0.5579730200699957,-37.57591173404682,-74.9412286613512 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark14(-63.07975322671669,-0.8503955132862361,-10.98078937628927,0.05710771288053074 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark14(-63.36335780334723,-0.06971088274886483,-10.868364222975174,-6.662320159462894 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark14(-63.40014712550122,-0.05737769618408316,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark14(-63.528757918604796,-0.365897300499032,-1.5707963267948966,-6.452457792349577 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark14(-63.54992642472732,-0.5897512853724072,-78.09361801117106,-1.0 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark14(-63.58593561749199,-1.5707963267948963,-1.5707963267948966,1.0108373048916945 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark14(-63.68861697921242,-0.7281248561764986,-0.22129644634091394,-0.9999999999999998 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark14(-6.374151752358273,-8.881784197001252E-16,-71.9020877457595,-90.92644430942782 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark14(-63.876873623682776,-0.7701021443651881,-83.80393371315061,1.0 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark14(-63.88094420325603,-1.5707963267948912,-0.19510727564972286,0.0 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark14(-63.89672565892154,-0.6185810736731145,-21.98632662626541,0 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark14(-63.916440964056825,-0.3639110708966176,-68.7182088752839,-23.71159540054326 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark14(-63.92038597041221,-1.2673113211247218,-24.686396246433617,-1.0 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark14(-64.08765225304568,-0.2519974170952023,0.0,0.0 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark14(-64.1859765396346,-0.4881377631045014,-39.76491950598129,0.01774420557231973 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark14(-6.423677143363847,-1.5707963267948948,-47.07544633988865,2039.446713444109 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark14(-64.24706009122832,-0.41622503188351523,-31.9018059950312,-100.0 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark14(-64.28141106276918,-1.0002648031021253,-20.697785232834473,75.43241903671444 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark14(-64.3762965195119,-1.3706837831874699,-99.34551063848728,-18.27725316147391 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark14(-64.37910255365271,-1.1915153796262592,-89.47141385819296,1.0 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark14(-64.43878225417501,-1.2675885342804096,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark14(-64.52822648657194,-0.07531438708688132,-2383.250824016707,0 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark14(-64.57239377189201,-1.5707963267948957,-59.22465435222529,-1.0 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark14(-64.57327383108417,-0.06358466067641522,-63.98925605710941,34.815723980563206 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark14(-64.58807904532834,0.0019339400758998648,0.0,-2130.954558890366 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark14(-64.59514518321961,-1.2258381322621528,-193.1870262112042,14.436363480901363 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark14(-64.67294551088007,-0.3483072266610421,-10.627135002356653,-1.0 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark14(-64.74002219094778,-0.7152352959131072,-77.30922376633339,-1.0 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark14(-64.74748057865142,-3.552713678800501E-15,-78.0458698066235,-9.641037421235538 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark14(-64.87163173000721,-1.459014705901883,-24.366262858207225,-0.09783761339771235 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark14(-64.89430809151116,-0.14667562604309659,-61.599352746549755,1.0 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark14(-64.97101247195636,-0.8065269218173228,-81.08132273021596,-1.0 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark14(-64.97258935449634,-0.8206124089024917,-23.732910893450196,0.0031392606868727024 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark14(-65.07710042797409,-0.45453948138154143,44.19199304687916,1.0 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark14(-65.12799221239113,-1.4988222483576457,-97.09394606455466,-0.42573280173689243 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark14(-65.13861594331956,-1.021715536929861,-58.988671807437754,69.54339124900243 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark14(-6.525243128092988,-0.9791487799236532,-45.123139820718215,-1.0010415475915505E-146 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark14(-65.38486889181145,-0.19072594655083688,-87.02122011329615,99.02181333914984 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark14(-65.4569233014957,-0.773426648192061,-49.716130978671266,-73.96488549701643 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark14(-65.46376279134637,-0.12054011502045237,-34.390576643370885,-1.0 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark14(-65.46672098910523,-0.765122209918718,-68.25246944964991,-0.052876146632288096 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark14(-6.550002940195448,-1.164365377381962,-0.9257376249082112,0 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark14(-65.54734460495482,-0.21719405224663718,-1.5707963267948963,-44.269360562840205 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark14(-65.58309110968356,-1.1725694051718452,-73.32193519945655,1.0081601731035097 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark14(-65.64122985253606,-1.5177482477481608,-45.022078786632974,1.0 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark14(-65.7190594961877,-1.5707963267948912,-74.51546802233827,0 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark14(-6.575114747698633,-0.5591533811676763,-67.62404412602865,0.012439559871011707 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark14(-65.85872784218688,-0.4025839907698854,-1.3630504041050642,-1.0279973461803997 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark14(-6.599458384515683,-1.479428263089005,-89.50661140449698,1.0 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark14(-66.01190298713725,-0.6356237711996338,-35.16663974175901,0.015085790344321386 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark14(-66.01397476492674,-0.11867407437769373,-13.798071012559348,-76.74595893991854 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark14(-66.065800764661,-0.5283682328332588,-14.569703512360348,0.007977057524687386 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark14(-66.12256217761025,-1.7763568394002505E-15,-97.10256183645667,16.45346567517641 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark14(-6.6124146869735565,-0.11060370117561885,-1.5707963267948841,-0.5616118918116361 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark14(-66.23891748959589,-0.8490673193309064,-63.833789645199346,0.9999999999999996 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark14(-66.24062219860065,-2.220446049250313E-16,-44.38022579443122,14.99882879406713 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark14(-66.28173286648473,-0.9800854435058286,-88.30746372493411,-1.1463673765882373E-7 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark14(-66.32542042755725,-0.8022928198500985,-1.5707963267948983,0.6287441356055276 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark14(-66.3353872783234,-0.5977562688970303,-157.1915798563604,0.2937986013581 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark14(-66.39958941404822,-0.47255268660203054,-73.41008888759663,-0.060704699781197746 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark14(-66.4780083556264,-0.9880810713329348,-39.118306755466804,-0.971506878481455 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark14(-66.54457757626564,-1.5120489423319659,-4.100401234212157,0.0 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark14(-66.57528819466025,-1.204526850724458,-1.5707963267948966,65.40666615937216 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark14(-6.6592068505871715,-0.003698036772920896,-1.5707963267948817,1.0 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark14(-66.59290154606711,-1.501145561739695,-157.15036991284336,0.13869389873270788 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark14(-66.7461437675729,-0.6396204226267151,-158.18992465887777,1.0000001094463578 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark14(-66.85482466366302,-1.5594141150675378,-9.542303558487179,-0.0625671908581984 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark14(-6.688053140862276,-1.2767361979941523,-51.881778031909846,2186.4742435617877 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark14(-6.692435007247028,-0.7992150978815237,-0.01350680221285494,4.372240008223827 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark14(-66.9276268706207,-0.6094644879780737,-56.28173617097455,0.3766108057710511 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark14(-67.03305893210629,-0.1266308929590969,-57.274394728415224,1.0 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark14(-67.0405559889812,-1.5676800866898726,-67.04796063044348,0.11720477243757599 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark14(-67.09184009048565,-1.5292085291715773,-66.06660821581853,1.0 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark14(-67.11095121677353,-0.046944051172766565,-2.9548572677629608,-0.37260918517455965 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark14(-67.12213262701796,-0.11466801845344944,-94.29029707932445,1.0000019272674097 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark14(-67.188259980175,-0.006681149871350501,-96.32721213871828,0.0 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark14(-6.71889041362758,-0.08133321432245044,0.0,-57.311885294914774 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark14(-67.21608002412584,-1.5705026877050183,-1.1102230246251565E-16,0.390993415365469 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark14(-67.2173972439431,-0.043244647416430936,-100.0,0.7762008290261043 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark14(-67.38148616833577,-0.03785481277458628,-1.5707963267948966,-0.058440627777910197 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark14(-67.59760656792929,-0.5148758478425044,-0.2643719657532305,-49.48752475799364 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark14(-67.63964406126152,-0.13318319587133634,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark14(-67.63979627160852,-0.4361247069816871,-53.94223203563359,-0.16587631278267778 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark14(-67.64322782031897,-1.2983383388420404,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark14(-67.73203730413142,-1.254697605749104,-0.1470747376495545,-58.64510470747766 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark14(-67.81547419873232,-0.42837112691438617,-73.6543353970387,87.49861749205488 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark14(-67.8266016239352,-0.16483565718439053,-57.86028655964834,0.43477379252785614 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark14(-67.89969135871598,-3.587554765747374E-15,-66.19091952358377,-0.9999789865590273 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark14(-67.9140719304648,-0.08296622496539956,-47.28758158139232,1.0 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark14(-6.798611151423863,-1.7763568394002505E-15,-24.694174957441025,-1.0 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark14(-68.06451723752862,-0.00645089207369947,-73.10566348367477,0.7340818356124208 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark14(-68.0673849643312,-1.5707963267948957,-71.25378442333253,-62.12702985029862 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark14(-68.60793812415592,-1.5707963267948912,-42.22251197486865,-1.0 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark14(-68.69657891345302,-1.256380106316906,-93.64273325171824,0.48104974253573374 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark14(-6.8712204857055355,-1.520628861664619,-0.1467882761779823,1.0000000000000004 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark14(-6.871555717505148,-0.9273128357146951,0.12032588940049006,-1.0 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark14(-68.753251422748,-0.9954514078322645,-1.0796391706774264,-1.0 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark14(-68.76963277993399,-0.8419995261899693,-72.5952058649923,1.0 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark14(-68.88502836413453,-2.6949318721185304E-5,-37.703532773273366,0.9999999999999858 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark14(-6.902147732560387,-0.24948427521065786,-90.41975331175965,42.698195698654615 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark14(-69.110182505882,-0.009509722261584412,0.0,0.3964303254482716 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark14(-69.20540141750716,14.445448429383703,32.47932294205646,0.0 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark14(-69.22845697848751,-0.04128585128807982,-47.51221923365983,-2203.7123644676967 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark14(-69.52482215793736,-0.22951680935027455,-44.391725429392196,0.9920932875370737 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark14(-69.55453776028457,-1.2669829994948199,-37.35536253596692,0.6636744462471724 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark14(-6.957003717042632,-1.5707963267948948,-49.7539828227646,0.2156161577702158 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark14(-69.70445265785317,-1.5707963267948961,-35.84153198440127,-1.0010415475915505E-146 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark14(-69.70878011737682,-0.4521089800286817,-0.6207450039262031,95.18603526129876 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark14(-69.71795390293546,-0.1449050694488758,-49.76831035319655,0.03883675573621098 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark14(-69.98807985956779,-1.5707963267948957,-66.3822956149821,-1.0 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark14(-70.09627594891057,-1.5707963267948912,-0.41681349926216715,0.9672466458060405 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark14(-70.12576581019268,-1.5707963267948912,-159.4897131135533,-24.247230490344847 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark14(-70.18647023096065,-0.06840569329257193,0.0,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark14(-70.22322889891568,-1.5707963267948948,-100.0,6.6174449004242214E-24 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark14(-70.32882310207674,-1.1958567909077904,-94.00442440178355,-31.724274947767668 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark14(-70.39443489389387,-0.26091872572476404,-51.54375205145262,-0.47693259216142025 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark14(-7.044726957779979,-1.2811545241634814,-11.395492786984672,-2146.018338086631 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark14(-70.4776016617725,-0.07974829146358897,-14.348217255148537,1.0 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark14(-70.63699997501973,-0.11712976406018916,-65.14801433645177,1.0 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark14(-70.70901816044248,-0.6988634996480692,-95.5914835866442,-2149.8385092491344 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark14(-70.89429317177832,-1.7763568394002505E-15,-62.36452102432092,-0.014849655080379165 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark14(-7.106964573994477,-0.35162145999605043,0.0,-1.6940658945086007E-21 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark14(-71.24388864069056,-1.7763568394002505E-15,-1.5707963267949019,1.0 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark14(-71.29414832252579,-1.861357979150226E-4,1.570796326794893,-63.38566920568816 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark14(-71.39137769967533,-1.5427303340856255,-3.2266985272466115,-1.0 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark14(-71.41266543928606,-1.5707963267948895,-44.02544855661027,1.0 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark14(-7.1427394896338825,-1.0532290109534124,-5.180677288197176,-0.1657870753747981 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark14(-71.46477694265218,-0.34093610717206024,-1.5707963267948966,-0.9999999999999964 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark14(-71.53277649215676,-1.5707963267947704,-87.07674455496104,-1.0 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark14(-71.55664992913887,-1.5004721651216046,-31.619407728624502,1.0 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark14(-71.5827637199707,-0.10026204619518775,-1.5707963267948983,-0.12200058331305108 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark14(-71.61824785046795,-1.5707963267948912,-44.11845750937613,1.0 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark14(-71.66432667354346,-1.5707963267948948,-13.228274260709782,0.06205589818204367 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark14(-71.71102347169938,-1.5707963267948912,-12.436815090409363,0.0 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark14(-71.77388140072833,-0.56927834794638,69.31593727117767,0.0 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark14(-71.89429969536212,-0.16051908071126952,-37.863026849177196,1.0268488647417984 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark14(-71.91453971729791,14.43229716355384,1.2460520100246943,-17.812256967092466 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark14(-71.92816669459323,-0.6132533720176178,-41.5977866508482,-0.01975230844412368 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark14(-71.95367656089036,-0.1256402854448011,-25.022516930919195,-44.55610535070825 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark14(-72.0446001886229,-1.541015222752748,-1.5707963267948966,-5.137797606994769 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark14(-72.10954923474318,-0.354685281951702,0.04362391746776623,-0.7350353393326398 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark14(-72.19794600039185,-1.5707963267948963,-1.7838337180162591,25.505560218280085 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark14(-72.22947040179747,-0.24070582779159666,-1.5707963267948966,-1.0000000000000018 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark14(-72.24128840719095,-0.08536800555545135,-4.17397066282534,-2208.1451721647145 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark14(-72.26974384994794,-0.616290348926534,-45.21200976907542,0.6589283956055599 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark14(-72.52683440144861,-1.0538496883682757,-40.50879083178776,-51.08106469772225 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark14(-72.52724245708728,-1.5707963267948963,-10.673902816158307,60.575886989947264 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark14(-72.56786027860696,-0.6083337287148674,-1.5707963267948912,-0.06157053066293455 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark14(-72.58522509938346,-1.4220413769670466,-42.39373898417129,-0.023570396725967988 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark14(-7.259515334490177,-0.2573911032041603,-22.68355772858983,-1.0 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark14(-72.60654401548332,-0.5165447492177595,-89.73758642871552,-1.0 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark14(-7.262313655672008,-0.9804661184401963,-32.80580585631816,-1.0 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark14(-72.67636481145058,-1.313663280741288,-63.58235931040783,-100.0 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark14(-72.77070218846501,-1.55021500706598,-0.2095981578924487,16.256202595905666 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark14(-7.277750566823901,-1.550494650684325,-39.7252615700463,-0.9777731019543646 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark14(-72.90566692448455,-0.11855892554567558,-1.5707963267948961,0.6754574993403355 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark14(-73.06163998313572,-1.198306166689754,-40.68904626243438,0.9996561074780277 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark14(-73.07082513640319,-0.036069357065709476,-13.475187101691958,-0.6927326164790953 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark14(-73.17420297097922,-0.5642986585047431,14.431394301878349,72.77687306772373 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark14(-73.34508537094399,-0.22673849217728365,-66.24755866809303,-1.0000211987399679 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark14(-73.41330243809175,-0.17053834141981739,-20.118756634064283,1.0 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark14(-7.344431138067125,-1.068188410463792,-42.901771188630875,-0.7495389215400522 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark14(-73.47730513003413,-0.7938499817528211,-49.434468653694644,0.3867723739450568 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark14(-73.48878205404918,-0.44159838299576704,-10.709139596736193,-1.0 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark14(-73.53465762952435,-0.7385665480206057,-1.1682138394714698,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark14(-73.59929133248218,-1.1486597933958977,-0.2368501625933016,0.0 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark14(-74.06375337916167,-0.2654252905055965,-49.33660284465071,-1.0 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark14(-74.08024656249799,-8.881784197001252E-16,-0.5377614913842336,3.2833756389116497 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark14(-74.09362274360497,-0.5093771059686596,-90.9973570395718,69.12675930538238 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark14(-74.10493777483659,-8.881784197001252E-16,-17.45555401532559,-0.44090399605548836 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark14(-74.14588485466226,-0.6594410524217376,-1.5707963267948966,-51.28803961993289 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark14(-74.18197426720633,-1.283268279097354,-1.046844626903518,0.7283939662144066 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark14(-74.20044439292089,-0.39576932718923014,-1.5707963267948966,-1.1372492994716055 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark14(-74.29985131356484,-1.5707963267948948,-8.893936992776183,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark14(-74.35332084814613,-0.4840881186750522,-73.46633412211338,0.4191722523082998 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark14(-74.39385024145567,-1.5707963267948912,-81.04948658683344,-60.32876644047849 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark14(-74.40090551236646,-1.1948773246719304,-1.5707963267948966,-1.0842021724855044E-19 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark14(-74.41641306198734,-0.08750220504216175,63.53748880230131,0.0 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark14(-74.42543210979079,-1.4001221373829054,-5.800397892404346,0.039096207974827046 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark14(-74.44304026254194,-0.6144454019957271,-19.478186590240714,80.74077516692432 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark14(-7.447315698343085,-0.18363725306481166,-1.439526322358717,-0.0077739606845527165 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark14(-7.449693370816399,-0.6946874374130336,-5.715602136533118,-0.6921815749582532 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark14(-7.454054544345109,-0.009184224470085345,1.5707963267948957,0.0 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark14(-74.72022621372129,-0.398390295538238,0.0,-0.6918441482906229 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark14(-74.86549298406297,-0.18108831962513172,1.5707963267948948,-100.0 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark14(-74.88926861998283,-1.5707963267948948,-4.261273289718204,-0.6791999644936237 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark14(-75.00114660595008,-0.9921722240686147,-87.1327892583615,1.0 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark14(-75.0465984548238,-1.5707963267948486,-93.74589514685563,-40.749833210869355 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark14(-75.10148244438804,-0.7125432542028847,-1.5707963267948966,-2.465190328815662E-32 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark14(-75.12739027527252,-0.2372664292681268,-18.632747938052464,66.33545411442753 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark14(-75.17873221346102,6.519563575017767,0.0,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark14(-7.521152950487389,-0.28410372920171173,-46.66973347428313,-1.0 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark14(-75.33821026995746,-0.6562589563044846,-38.369299659154166,-14.433111764219456 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark14(-75.36358766931008,-1.5707963267948912,-1.3613171197001304,-1.0 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark14(-75.40419485915791,-0.4779923895046956,-121.68955824567591,-1.015131355242885 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark14(-75.48657857609929,-0.9996004976115656,-31.490340627579545,40.23808074933002 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark14(-75.6508533916934,-1.5707963267948948,-58.15521600592402,-1.0 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark14(-7.570029978362239,-0.6171256077636168,-44.19709833279466,-64.677920955641 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark14(-75.80741434300664,-0.5784159806149404,-45.212423570598006,0.0 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark14(-76.06767106195267,-0.3256995428379849,-86.28756741503915,-2212.7569687719174 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark14(-76.17591742212066,-0.1572323426863646,-18.927168580894257,-80.40728092749453 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark14(-76.26981975203208,-1.1188255246256023,-1.6477180669164788,84.49751066835061 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark14(-76.36480921531961,-1.256782481497803,-67.53045071932814,39.698126778434165 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark14(-76.4131676867585,-1.3710549999211696,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark14(-76.45988672590751,-0.9762260481358832,-1.5707963267948966,-0.4161936507283315 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark14(-76.5011188364875,-0.8552069835650127,-65.28991615825916,-1.0 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark14(-76.55269018090863,-0.5951491386732808,-5.314741707278088,-67.34910769643503 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark14(-76.64476601385269,-1.5707963267948344,-1.3685850129858466,0.0 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark14(-76.65604004921583,-0.416925386250256,0.0,0 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark14(-76.66725195370665,-0.507835710216192,14.485674103753745,-0.9808583960110592 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark14(-76.67698479833157,-0.43302385555291034,45.01408738291401,0.0674342344487254 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark14(-76.85599717575325,-0.5546085553407073,70.85637787979883,0 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark14(-76.88434454679347,-1.5278063965281938,-32.5631646786872,0.9999999999999988 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark14(-76.89596098780243,-1.5214035151607055,-12.847963459370224,1.0 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark14(-76.97981687935481,-1.7763568394002505E-15,-16.956415625203228,-76.80345332064634 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark14(-77.0197611132527,-0.2963988316747669,39.22813180184433,1.0000867780253828 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark14(-77.1697341139396,-0.7169672966067091,-63.16371727017183,1.0 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark14(-77.17404136703315,-0.6263743986011308,-75.0449802174586,0 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark14(-77.25547958327628,-1.4243551987466638,-77.35593036321315,0 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark14(-77.28840084032375,-0.7733312311771996,-96.00504774786027,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark14(-77.36209363816887,-1.0107040024236074,-1.5707963267948966,0.0625588872383021 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark14(-77.54041713147215,-1.1507198736654978,-20.72820787638703,-0.2977874557612359 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark14(-7.756808918151372,-1.5707093009167357,-22.46741091456907,-2.710505431213761E-20 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark14(-77.64117042214556,-1.2099726946811487,-4.429052702780789,12.722350374305137 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark14(-7.767892767886494,-1.5707963267948912,-49.67694566520103,-0.979469911767026 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark14(-77.77564779347193,-1.2537146547526816,-1.471297772542436,5.2710989716152616E-82 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark14(-77.82324617058238,-1.5707963267948948,-11.893013933338395,4.225861109438725 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark14(-77.8756774420285,-1.5707963267948957,-41.071950920288145,73.66028057338582 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark14(-77.9074685444618,0.40118173861054485,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark14(-77.94436362668009,-0.11735637038026248,-17.211547287913163,0.9999999999999994 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark14(-77.94640092305875,-0.29728017018449865,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark14(-77.95144942971572,-0.501571528661696,-7.997953158331342,-0.7910661858571537 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark14(-78.01392784247435,-0.046121769883960155,-7.287850018670844,-92.96529713556284 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark14(-78.11400956043332,-1.2222953060775388,-72.45988052498018,1.0 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark14(-78.24674707080044,-1.0656668984577229,-11.977951062673114,-1.0 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark14(-78.31989280187906,-1.4585618983688002,-42.13665340543111,90.24986195469386 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark14(-78.50435914387941,-0.05299825243233158,-66.19466348160483,-0.5660036232999637 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark14(-78.51738049282247,-1.5652985621553654,-44.40517824396734,1.0 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark14(-78.52105218195028,-1.3358938566409595,-11.12027383253374,-9.426805336047721 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark14(-78.63395750178371,-1.137757892491421,-31.874119979850928,1.0 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark14(-78.71241436358312,-0.2511325305704869,0.0,0 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark14(-78.71966194029301,-0.9310248903310981,-25.305705734507494,-38.976315225029026 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark14(-78.8177831222962,-1.5408377675274894,-68.80089315309704,-0.5579816093596096 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark14(-78.92624738668474,-1.5707963267948963,-13.151813986500203,-21.219517058020422 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark14(-78.94290033245179,-0.6419353741010694,-61.757222778625305,-45.68097513574948 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark14(-78.94902185218898,-0.8032827013034874,-89.91441015372064,-0.019953140276907533 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark14(-78.98205806760812,-0.5607720351775042,1.389082706708936,-40.035004125891916 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark14(-79.02651964754469,-0.5501035550797028,0.0,0 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark14(-79.0965963245873,15.093802850627405,100.66070454440276,1906.6830927549552 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark14(-79.24585295275023,-0.2790727975625878,-62.93465165632849,-0.9787549736700583 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark14(-79.2743162308837,-1.0708267732798504,-56.67125348914499,-1.0580762909266728 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark14(-79.2784886025772,-1.3589261700028152,0.2864428251574406,-0.04785836031325549 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark14(-79.28592170471077,14.778083463100721,100.97521561676622,0.0019823407885066757 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark14(-79.34678943446099,-0.40948093661733864,-58.50622372932961,-1.84187867972092 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark14(-79.42238635820084,-0.016834020926123443,-21.984058670924398,26.92299375367782 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark14(-79.49713307693088,-0.02888407295422657,-1.570796326794893,4.950939149586844 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark14(-79.6074595439299,-0.2959198025995473,-59.888316695761986,0 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark14(-79.63703760252855,-0.41498281363121103,-97.51020410037238,-1.0 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark14(-79.67689816308108,-1.480313374028675,-24.95157848747885,-1.0000000000000036 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark14(-79.74644815346754,-0.45181558045622916,-2.7495819085813054,-70.18510402740874 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark14(-79.75666910644128,-1.4514816714845966,-28.151047942721707,-8.870519115682166E-6 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark14(-79.77900124387062,-0.5225465530259337,-47.889907709713114,1.0 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark14(-79.78193771644314,-1.5707963267948912,-56.21003566663165,-27.751319699714777 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark14(-79.78630508582471,-1.4664996681738292,-45.71450020793336,-0.3620911776959318 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark14(-80.00601678533575,7.16763256190366,1.5707963267948966,5.551115123125783E-17 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark14(-8.000830135315113,-0.08619610642309293,-1.5707963267948966,0.15176772300422836 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark14(-80.03463072317203,-0.6107297413477388,-53.94497245114358,-16.75620343954388 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark14(-80.04904654714343,-1.5707963267948912,-56.3115285230474,1.0 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark14(-8.008756731501848,-9.228823564579227E-16,-90.1834379541257,-1.0 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark14(-80.44444964099088,-0.5141201630642758,-65.60280908489611,0.913497118805482 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark14(-80.45536778617468,-1.1606315154770218E-5,-123.94399869529738,0.5576938590178258 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark14(-80.52520562602086,-1.3835272860311394,-10.087416572348308,-1.0 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark14(-80.52933625416776,-0.023611549023818054,-10.969471502726023,-1.0 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark14(-80.58360811486114,-2.220446049250313E-16,-100.0,-2201.7879125114528 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark14(-80.7779707267004,-1.5707963267948912,-73.02128325038429,0.8021678515857293 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark14(-80.88948740647665,-0.03339741757648085,-1.5707963267948983,-100.0 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark14(-80.93273139033528,-1.3221602582529086,-1.5567309510664842,0.6967391393595991 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark14(-80.97852781639625,-7.105427357601002E-15,-88.16709614382845,-1.0 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark14(-81.09564574374943,-0.1251665655102999,88.50812475669485,1.0 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark14(-81.14820599080754,-0.4296799344373504,0.3135506768394224,0.0 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark14(-81.16089755314879,-1.168209924627589,-8.036825404359037,3.469446951953614E-18 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark14(-81.23278610472697,3.863062419029658,1.5707963267948966,-0.048517899827195565 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark14(-81.25194637723496,-1.5686373409211352,-16.993500409323758,-88.37514291133708 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark14(-81.3269253968554,-0.398089402902153,-65.16320625294577,0.030494087071421098 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark14(-81.50759186703169,-0.7047478331545937,-0.010768035047090422,-0.7618602057565056 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark14(-81.50951503648079,-0.6048738406675758,-100.0,-1.0 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark14(-81.96645095865304,-0.20486168992250472,0.09757627411359984,-12.233163199444554 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark14(-81.97250606622751,-0.28399903427056583,-15.15393363251161,-0.8408841458061018 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark14(-82.00467175058577,-0.9922260594427067,-1.1102230246251565E-16,26.794158800198684 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark14(-82.0893731298998,-1.7763568394002505E-15,-21.331645458396505,-1.0 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark14(-82.30530450269568,-0.7687370021938776,-67.06642616363116,-1.0 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark14(-82.45468775648186,-0.7367628618623142,-5.034980244403101,-0.30426802818315934 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark14(-82.4782975706056,-0.46634375247423754,-34.52152974216415,-2158.5121038171383 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark14(-8.261203681901554,14.429490617360294,1.1370276923664853,-40.48038005547667 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark14(-82.64750934547143,-0.10835116453468507,-45.54507353554635,-34.66914681954553 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark14(-82.65768898797869,-1.5707963267948963,-1.570796326794893,2025.3686391259564 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark14(-82.780270004256,-0.40971374377914727,0.0,0.05191813533748099 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark14(-8.281598267188405,-0.9126767731277021,-93.04274737997684,-1.0 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark14(-82.85744248575473,-1.3917441887176674,-12.898324917613941,0 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark14(-83.01180153920815,-1.2555674010412048,-30.464138423899612,-43.140227907661576 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark14(-8.302905842330006,-0.433263348299457,-91.6761761696356,-41.42990984137451 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark14(-83.05875759415304,-1.2460922947106936,-17.862374398354227,-62.042257650107246 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark14(-83.11053701711721,-1.5707963267948912,-0.09348622078687562,0.6996537825274559 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark14(-83.36819121896482,-1.2432231788913768,-63.853340830119855,-0.06417083051912198 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark14(-83.39212953806643,-0.9558969523587912,-39.73714082555346,1.0 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark14(-83.47990273388189,-0.561642418622033,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark14(-83.53241390706785,-1.4047335954533762,-36.77604386509324,-2116.4823465109394 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark14(-83.8411213825615,-0.12972707807401296,-24.698473391661018,-0.7071231290083385 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark14(-83.8661372596896,-0.8353341848539833,-1.2145200432802652,-0.17658097512537796 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark14(-84.00545183453363,-0.04575900952865197,-20.78231214322104,0.0 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark14(-84.12143674699688,-0.7721694275570137,-0.674994879561787,-1.0 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark14(-84.21060659227572,-1.5707963267948948,-86.17366784151889,-0.04979485355607009 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark14(-84.22284595764748,-0.9084592875435478,-78.23212716763013,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark14(-84.32859534130259,-1.5707963267948948,-0.03531232051595738,0.21003808395876167 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark14(-84.47869712769136,-1.1363498518367348,-27.682639477670847,0.9405848567945896 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark14(-8.458655872940907,-0.4694181313462794,-6.494282495977466,0 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark14(-8.458699969889992,-0.006665529825371267,-22.38293062694882,-0.9550133447825709 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark14(-8.46156247688494,-0.2385168247330044,31.91580735728084,63.758562437188544 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark14(-84.70675319607757,-0.37847039436843327,-2.55928461080903,-3.1751042334306554 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark14(-84.74416830583004,-0.5296523088534013,-1.5707963267948966,-0.6365001113825884 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark14(-84.8051283931282,-0.20033277407399983,0.5678370600425802,1.000003122234014 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark14(-84.8134580737788,-1.4216676833770088,-51.70806507312765,-0.9930332778207713 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark14(-84.95365107754247,-1.5694562532990364,-45.437427971962215,0.0 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark14(-84.95568010135918,-0.2094052727293444,1.3112594098988888,0.0 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark14(-84.97184683864494,-0.5066882375165136,-69.2764347738326,3.552713678800501E-15 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark14(-84.975150455748,-1.5707963267948948,-53.764564810986656,-50.50492012975836 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark14(-84.9995947517633,-0.060158013884277724,0.0,0 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark14(-85.06723699349288,-0.8533038446185746,-73.54455092982367,0.0 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark14(-85.08390902558455,-1.1542047577735768,-78.75375023660779,1.0719092932514007 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark14(-85.08574085764934,-1.3375610885567353,-1.5707963267948966,78.08308210405221 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark14(-85.09593936303122,6.50119932035635,0.0,-0.0268039532344288 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark14(-85.24492877216724,-1.5707963267948912,-66.13727418103694,0.0 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark14(85.31593269355588,-0.8656401025828444,0,0 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark14(-85.38711847794939,-0.15836061369091925,-66.28467063225698,1.0 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark14(-85.53851564867803,-0.8567380179270394,-15.825800320386879,17.937402213031532 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark14(-85.54312033061146,-0.13376751970408568,-88.90389885658304,-0.35219704587558454 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark14(-85.64343728285533,-0.00301900372566346,-1.5707963267948966,0.996498192533086 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark14(-85.64819319528453,-0.032474225303245174,0.0,-0.19017858672138088 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark14(-85.66338408368586,-1.5707963267948912,-99.5801835284466,-1.0 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark14(-85.73903742301283,-1.2905303131564096,-10.504939235905091,-20.940402581476626 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark14(-85.92090330125379,-1.3310066797953,-11.177500280558064,0.2892887031264806 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark14(-85.92183042877596,-0.3703273506200162,-1.5707963267948966,27.99756487534809 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark14(-85.93247357223679,-0.3906933064948449,0.0,27.337534978405394 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark14(-85.93703192049942,-0.9831617590808293,-52.52371976340309,106.96348549033829 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark14(-85.96400047016505,-0.27118952598851304,-41.97291280072215,2236.736164814038 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark14(-8.597792783804614,-1.1348856917336307,-25.640823821926343,-1.0000002807176438 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark14(-86.01121457765406,-1.5707963267948963,0,0 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark14(-8.60397580923641,-1.374435391388289,-58.11548222571914,-55.64325660501714 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark14(-86.16123407770024,-1.4292695791738304,-82.86711462576596,-23.558282898227617 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark14(-8.633098198320587,-0.5570258950806766,-17.295095938933798,-1.0 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark14(-86.37840402705912,-0.8283463827364571,-66.09418806810646,-45.24511369432674 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark14(-86.41330949209046,-1.5614729192407615,-63.330502672414354,1.0 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark14(-86.46525038780351,-1.4095497324742465,-68.67135326299842,-1.0 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark14(-86.4703827539221,-1.4907871913724566,-26.89084708450642,-66.72610044557177 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark14(-8.666762051479507,-0.14214813026276593,1.1248900611890142,0.0 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark14(-86.7423682968063,-0.9073531207757022,-41.94891517013468,0.0 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark14(-86.79900950269862,-0.5744553927796032,-53.407332320582704,0.5312755032309573 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark14(-86.80969654665478,-1.355623693190589,-9.51297777212997,21.498564219196453 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark14(-86.92606955575754,-0.05768145538631157,-39.45365096096338,-1.0 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark14(-86.95915675857043,-0.4940596202719678,-24.86127873472922,-79.46712109511338 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark14(-86.96180941997709,-1.1644782076461122,-32.65747482695745,-18.36324119541732 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark14(-86.97735841428042,-0.5202850131681203,-80.11061266848269,0 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark14(-87.05598399775141,-1.5707592116202518,-56.39843776693705,-0.10117179639037532 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark14(-87.06921118497159,-1.1102230246251565E-16,1.5707963267948983,-1970.4949262501088 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark14(-87.10555897769514,-1.2111308912924175,-100.0,39.56678351280509 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark14(-87.12179876090379,14.481733131450348,127.29274314047191,0 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark14(-87.20415428801806,-1.7763568394002505E-15,-72.73815439222852,8.876884676509817 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark14(-87.3074713734768,-0.03777568246997706,-68.4621359567339,-1.0 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark14(-87.34856186480756,3.3469001035576045,37.7957876309397,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark14(-87.42105314352669,-0.6358066291533511,-4.442252433776174,-1.0 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark14(-87.44864418695789,-1.2837493930219608,-80.20004397907874,2125.5312213444017 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark14(-87.52644115629033,-1.570342607404431,-53.86192870614406,-0.017707868065480414 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark14(-87.53318826395724,-1.0839232690039786,-15.994738457012474,0.7437957343904671 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark14(-87.72506989936457,-0.09333578662282416,-71.54267775960965,1.0 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark14(-87.81476711304353,-1.4750760843929944,-0.860936606225696,1.0 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark14(-87.84938778872441,-0.8881040194789649,-61.516583412098115,1.0 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark14(-87.9428170744972,-0.08220026114923967,-73.24850132550938,0.011056710918034951 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark14(-87.98018837345998,-0.6871650380891783,-1.1700282170852785,-49.122136092362204 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark14(-88.14707184266169,-0.6655558738943392,-68.4452349305343,-0.026703981023018294 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark14(-88.25854151668918,-1.4397179299297382,-1.5707963267948966,-0.0356028238743098 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark14(-88.53363967668177,-1.5707963267948912,-35.29924714842161,1.0000131474119804 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark14(-88.66571651393082,-1.2921334553840296,-44.05500831861351,-1.0 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark14(-88.75286580941449,-1.3016674163186828,-123.03316705288118,-33.87491657662312 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark14(-88.80950524427658,-0.5836541438076388,-10.67358799336585,-0.9246016983859633 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark14(-88.8186447800567,-8.881784197001252E-16,-34.24988739859242,22.470128606230503 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark14(-88.97514870491115,-0.8925771306492578,-93.32530775103083,1.0 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark14(-89.08211726246222,-0.772872903219993,-58.22938254401724,-0.43039535912404503 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark14(-89.1348367988801,-0.11066458972492388,-103.80669530753487,-78.09025630811158 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark14(-89.19759727397019,-1.1942857150075252,-100.0,1.0 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark14(-89.3444662252445,-0.3335152720045129,-34.49212870696239,-1.0 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark14(-89.42681010156505,-93.18168469444699,60.46441959582637,0 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark14(-89.45210654002709,-1.0377080688260483,-49.64787813275883,0.7928409531600461 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark14(-89.48372231558524,-0.016262552925745022,-40.43307490678863,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark14(-89.54327124304713,-1.520947586173321,-25.014075221068843,0.8965847798391096 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark14(-89.60188657879384,-1.5707963267948948,-88.46895255219312,17.018465036501023 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark14(-89.72128962815457,-0.695629830430866,-1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark14(-89.72149272270423,-1.2218417903422667,-58.55030538974865,1.0 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark14(-89.75354444285516,-0.7518240999357227,-53.363201178670806,0.8363443234080223 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark14(-8.976121562282518,-1.3951070194842838,-3.9920486776801045E-4,-0.0038895606204094532 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark14(-89.78490778790407,-0.44960407203360575,415.91660994969754,0 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark14(-89.800576794929,-1.2768664730201,-50.4279996419486,40.0282625249836 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark14(-89.88605773629169,-1.1688594343705838,-24.309760580884635,-1.0 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark14(-89.9119829757299,-0.4580434811889106,0.062108449483241304,0.0 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark14(-9.003681747573566,-0.34335718999473486,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark14(-90.08056306756605,-0.21870053128867672,-52.29116822275986,-1.0 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark14(-90.14134503553726,-0.4529490881787086,-68.72683947107785,-1.0 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark14(-90.25022297689645,-0.1636408957137956,-1.5577040199471783,1.0 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark14(-9.028704850126772,-3.4637590706513702E-15,-41.632907597511725,0.05527216550287481 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark14(-9.032311508070583,-0.16163500878413306,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark14(-90.38251200911161,-0.06609920049645268,-26.73285827685558,-31.32617869829933 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark14(-9.042520863871507,-1.5707963267948948,-1.5707963267948966,-2244.696148484224 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark14(-90.48712821608984,-1.191382748932392,-66.04737689729005,0.8221782464753566 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark14(-9.055819351312993,-1.1872297066001407,-0.6141791260382237,-0.9997083104968119 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark14(-90.61901257074607,-0.34418282690937574,38.794076990852986,0.0 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark14(-90.65781862985239,-0.5263466098540539,-0.8394126491446247,1.0 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark14(-90.77398496616074,-3.552713678800501E-15,-36.59774859567928,98.25637829096371 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark14(-90.77615428701773,-1.394237002658599,-96.02067891925901,7.808756744040622 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark14(-9.07860765757393,-0.005720335440269717,-0.9280572369044903,-1.0 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark14(-90.88636965289622,-0.15628025672238754,-29.38799675192452,1.0 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark14(-90.95094719810344,-1.5424773465761104,-41.44682708206694,-1.0 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark14(-90.95317349413577,-0.9862782618129273,-36.84710746778434,-0.02937910035233354 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark14(-90.97039584303602,-0.3776805661738518,-14.216345145557568,-1.0 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark14(-91.21094387028417,-0.2534638881235045,-46.667195152916754,0 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark14(-91.35094964492306,-1.5707963267948912,-123.89875275369783,-9.370187725311084 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark14(-91.44632656140577,-1.4985157805555644,-37.092774875944244,25.593684095076824 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark14(-91.49368988645409,-1.5707963267948963,-43.81253486629163,34.88011898450469 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark14(-91.84740849755354,-1.1102230246251565E-16,-1.7763568394002505E-15,788.5931497535391 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark14(-91.86624719432734,-0.8010375265427783,-97.12432973945666,-42.464522861548495 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark14(-9.187172301881473,-0.04862180599228031,-1.5707963267948966,0.96391692984818 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark14(-91.94862977012785,-0.654784029119341,-53.72687150853808,-1.7064164557631472 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark14(-91.98158573245018,-1.5707963267948948,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark14(-92.01197586079785,-0.5235987755982994,-22.733103590279253,-1.0 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark14(-92.07570751645162,-0.07150471887647109,-0.014617352470310152,85.4834406091284 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark14(-92.12264550553274,-0.8892509959945687,6.429232724937742,84.99009936422283 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark14(-92.28594968673471,-0.1609580948561251,-50.10623612212807,18.079228136914452 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark14(-92.2926405759623,-0.01489647693083234,-2.220446049250313E-16,1.1307254862356956E-7 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark14(-9.230073993500357,-0.8582511816803707,-86.74075148443688,-0.9999999999999988 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark14(-92.38249519569254,-1.5707963267948948,-100.0,-41.71792083263905 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark14(-92.39962082896847,-1.041347498904058,-57.85417657364465,33.8062087280976 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark14(-92.73736101659324,-0.06454626670601181,-48.40604771203844,0 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark14(-92.78928883103734,-0.8522955201805427,-3.375768677469779,-19.085408508012392 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark14(-92.89362717911693,-1.2616104284844938,-0.0795890813755733,-1.0 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark14(-9.29853183258966,14.432515250412898,0.7246736279155479,-1.0 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark14(-93.05272964630463,-0.6519118862690387,-47.89259738529441,-69.28821888547392 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark14(-9.30606339868427,-0.4049500775921356,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark14(-93.1841049945624,-0.002181486118377338,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark14(-93.32191378351354,-1.5707963267948948,-1.564450736845764,0.0 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark14(-93.42657074851546,-0.3417796592458149,-31.518473920508963,-1.036523964875584 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark14(-9.344969733368176,-1.0370281300721944,-43.29583064435286,0.6185225012912046 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark14(-93.50647163100294,-1.4233889708404688,-57.16155469195476,-0.772609713680487 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark14(-93.57714206388665,-1.5707963267948908,-66.47397521913562,-0.16877051066865423 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark14(-93.59083945961389,14.429217768903456,73.21109440626029,0 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark14(-93.62116625906971,-1.5107471006069177,-80.12211788381656,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark14(-93.76293922694055,-0.7043828185714851,-9.828730743369263,-46.157461591713876 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark14(-93.77902320521159,-0.21004489170837726,-100.0,-0.018612734281356208 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark14(-93.89484067110507,-1.5707963267948912,-67.55248437651447,-59.31156591748909 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark14(-9.437105273536028,-1.2770215945796128,-0.259955979571625,19.038441217430634 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark14(-9.448209923452389,-1.570796326794886,-158.40303600909087,-91.53047126886568 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark14(-94.49238519404734,-0.7995386370130761,-73.03317454761945,56.19012032244382 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark14(-94.49893702856103,-0.6350410966613271,-21.32447950413289,-64.85208218491337 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark14(-94.53018813271078,-1.3081202971761177,-1.5707963267948912,1.0 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark14(-94.68451858886193,-0.017873128149842148,-1.5707963267948966,-0.6549058483375587 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark14(-94.77453898312235,-0.33485690510088495,-44.29574509775849,-50.90599225747432 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark14(-9.483131610311633,-0.09924942293406136,-46.452311114117194,-48.3560746265653 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark14(-94.84293167608135,-0.18118462856431983,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark14(-94.84880008621914,-0.3397569189694192,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark14(-94.92511189446006,-1.5536723916833672,-73.638799177062,-1.0 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark14(-94.94302147485668,-1.5707960684896394,-100.0,-0.06255339053235806 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark14(-94.99296867787157,-1.0023726607323769,-1.088529057384561,-0.43486184577087805 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark14(-95.02049410417666,-0.15205834590594947,-62.40524518105606,0.70734322957445 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark14(-95.11995875604666,-1.011295181047347,-64.64278155260148,61.318976845320684 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark14(-95.15803165941487,-2.220446049250313E-16,-39.635266341239536,-0.9869567206783472 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark14(-9.516890097840019,0.40180486081748945,1.5707963267948966,-25.527692678684332 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark14(-95.22111423189081,-0.9862804222474335,-61.531381608853884,-0.0336962453187523 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark14(-95.25989590615401,-1.411117850367123,-31.771808698483127,-1.0 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark14(-9.534396451797752,-4.6602080158443656E-4,-1.5707963267948912,85.50776308958058 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark14(-95.58843646787214,-0.20682783998081142,-3.142447020779451,0.6937717130989421 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark14(-95.65382093961797,-1.2890499143094347,-53.845916332975996,1.0 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark14(-95.66018504410134,-1.4040494486112407,-74.06081166662148,-21.85463097924263 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark14(-9.568094641725551,-0.653228447366934,-15.119309277612103,64.6888480417461 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark14(-95.8346366206034,-1.2016032057223214,1.5707963267948968,0 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark14(-95.90094002198165,-0.10694832432145063,-17.752827361975534,-1.0 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark14(-96.15574110107057,-1.5707963267948952,0,0 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark14(96.15857669986366,75.2926057591828,21.174391986495905,0 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark14(-96.23552733661998,-8.881784197001252E-16,-0.3221540097858344,-1.0 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark14(-96.26617921123224,-4.440892098500626E-16,-67.03131537115837,2.6469779601696886E-23 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark14(-96.28333109685285,7.219045646975812,0.0,-1.0 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark14(-9.631646844048376,-1.7763568394002505E-15,0,0 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark14(-96.3499697867292,-1.2470901313118399,-1.5707963267948966,-4.6365076883592767E-69 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark14(-96.37313458290352,-1.0858603851080773,-100.0,2195.936982530678 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark14(-96.54679669721419,-1.325667997164835,-45.33377857983485,-1.0000000000000036 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark14(-96.75151702841829,-1.5707963267948961,-0.05242208715641224,1.0 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark14(-97.03977136848846,-1.5707963267948948,-75.7560130245054,-0.9999999999999858 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark14(-97.18080822190579,-1.2460130025035694,-100.0,0.0 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark14(-97.21225132147697,-1.3390780203831447,-1.5707963267948948,1.0 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark14(-97.59020025351232,-0.26814217726930595,-10.607954748757152,0.05893426557175224 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark14(-9.763686463325161,-0.512011481711556,-58.51690084774846,-0.6157906332202223 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark14(-97.69601978672526,-1.3198723452797114,-12.189456004716405,-1.0 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark14(-97.96185486271533,-0.10031640954652721,-63.63011049171471,0.2748648323634575 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark14(-97.98641120942011,-1.5695559522490203,-1.5707963267948966,0.9983841305908063 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark14(-98.01343401386407,-1.570796326794886,-4.523892783136677,23.972225679736447 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark14(-98.02800401552317,-0.5215331665973079,19.413027601782986,3.8869074256774496 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark14(-98.04012965072253,-0.009314935998685775,-77.73869159083222,-45.90706188438249 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark14(-98.09421066127015,-0.20490466799076124,-78.79216509056526,-0.9691999904234999 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark14(-98.11927628105124,-1.5707963267948948,-12.413214439181951,-0.7992012533899819 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark14(-98.22580107299086,-0.3875837504427295,-9.346964064694525,-90.33007404449745 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark14(-98.27392423631697,-0.3323015207671203,-79.37156189567524,0.6428401761083649 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark14(-98.32895636458322,-1.5707963267948963,-23.776249636528615,0.8470116357467122 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark14(-98.33837339119475,-0.7046012320666271,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark14(-98.34335358342635,-1.568221194035628,-73.3722717039471,0.047421952103937626 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark14(-98.66062081923477,-0.5512149576631492,0.1505145518846832,-25.385183491487975 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark14(-98.72349483996774,-1.173292905024265,-1.5707963267948966,-0.7654759636349359 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark14(-9.881552084764678,-1.208808863254026,-4.01477355718965,4.780607516225647E-8 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark14(-98.82764230396398,-0.4257198860465792,-83.24067921013096,2229.347679664055 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark14(-98.8954692628006,-1.162655029569777E-16,-60.35989723558057,1.427389409506584E-17 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark14(-98.95825477539051,-0.8997312024678195,-80.60003698396253,-58.986457182492224 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark14(-98.96773881801906,-1.5616813193279688,-32.605888771524164,-0.9823981208372538 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark14(-99.0121268572703,-0.1949683627662421,-67.81022176419742,-1.0 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark14(-99.01857541876466,-1.5707963267948948,-1.580315089691993,-77.39703562205209 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark14(-99.05421088236959,-0.37792146740797117,-1.043795847880577,1.0 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark14(-99.20256546584523,-1.3877738084915507,-1.5707963267948912,-1.0 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark14(-99.22734862748858,-1.5707963267948912,-2.190123803615222,-50.75090873577337 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark14(-99.25506110859607,-0.30127853467557275,0.10868601271018385,-49.79789001452248 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark14(-99.34977109274352,-1.2790908778386854,-1.516500097769605,1.0 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark14(-99.40671591950179,14.429279571986491,1.5707963267948966,210.93644692914722 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark14(-99.55644550902798,-0.5519353565292562,-71.68053920376977,-21.941447873197845 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark14(-99.56878547840779,-0.2053075225008688,1.5707963267948966,2.269327508455976E-15 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark14(-99.57147388431848,-1.3659778360446584,-1.5707963267948966,9.359044250489214 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark14(-99.60503065258034,-0.9705636059714916,-53.47797833672977,8.552847072295026E-50 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark14(-99.73544603333313,-1.0683413862463453,-89.62239101368142,-75.06936718728298 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark14(-99.74404246492878,-0.08672586186729211,-0.12872386559408044,-0.6630557188975619 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark14(-99.75994422644911,-0.2651627792275263,0.0,0 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark14(-99.78181717066936,-0.7609919800881642,-39.194498363299715,54.855770327205306 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark14(-99.80828967013589,-1.5551438712016623,-61.81664038097518,1.0 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark14(-99.83780856115095,-0.3085191036348345,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark14(-99.88094171170056,-0.42639137586704057,-51.93321417906397,-0.36211729877568577 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark14(-99.89493075991925,-0.9711927576309239,-12.360197994431076,-37.28183253505306 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark14(-99.92121678619299,-1.1533169947393376,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark14(-99.92184491494193,-0.3802742932871954,-25.243916315614804,-1.0 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark14(-99.95193336038396,-0.5092794902578816,-4.47820821799536,0.9990626376842974 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark14(-99.9575667361526,-0.4802658230292727,-38.85592375196376,-40.114089274014624 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark14(-99.96020458862658,-1.101004099927978,-42.784093976135296,-15.813139508192492 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark14(-99.96036577710588,-1.4790671482736446,-34.778286015816455,1.0000000050403355 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark14(-99.99976389332208,14.430729456886112,45.346213603753014,1.0 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark14(-99.999912339117,-1.5707848426541675,-1.5707963267948966,0.2515075588439877 ) ;
  }
}
