import org.junit.Test;

public class Sample60Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.0020735035771661803,81.65178968493828,-76.68554356123282 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.014375116207411935,-3.715291736637354,28.23600343192666 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.014827088688137091,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.024937253181425922,-0.07236490381071903,7.050663565258554E-15 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.0275689955934888,-0.13398750986265107,11.723453390581707 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.04054926765821232,0.0,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.042548057133966755,8.95743189971789,-84.50289618489 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.04546390200950957,1.0658141036401503E-14,8.881784197001252E-16 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.22684322058457784,-1329.9071219861235,1195.7570415450023 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.4472059671542894,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.9660275565750709,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.9999999999999987,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.9999999999999999,1294.957584329654,-1109.243393477723 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-1.0,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-100.0,-0.027912890756526837,-9.66573609117069,0.12359521427592379 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-100.0,-0.04116618488763886,-0.014436338937251795,-3.2521645520298232 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark60(0.0,100.0,-1.1102230246251565E-16,0.043577397464496404,-36.04612524358865 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-1.1064879508633787,-0.041159606467584486,0.21004482311336636,-7.432196667503029 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-1.1102230246251565E-16,0,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-1.1102230246251565E-16,-23.222588148337753,12.766658213437895 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-1.1102230246251565E-16,29.91165264239082,-43.225882730791795 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-11.35681302621475,-0.05310221062354817,-4.114779318098793,0.3816993425148665 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-12.139800984441264,-0.013130095426102342,-54.883290691917594,0.028614602740193628 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark60(0.0,121.62876104033285,-0.01839745227252404,-2.449908169695115,-0.7073699492262225 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-1.2878879013169674E-7,-3.0713790748582522E-238,1.7105694144590052E-49 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-14.166461123548379,-0.019548072285399343,-10.479161207253345,0.14989701375696882 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-14.294118407428854,-9.723567523099925E-17,-1.0876854852368583,-2.0558611042275463 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-1.7763568394002505E-15,-4.5734166086523254E-14,-61.01154410349629 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-20.137985773577356,-39.84862236187294,-56.19432682419927 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-2.220446049250313E-16,0,0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-2.220446049250313E-16,-88.12856214628493,70.9050619921911 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-2.465190328815662E-32,0,0 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-2515.6853781998343,0,0 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-26.22544166904216,-1.4412986049672523E-4,0.2893348896920906,-3.9144717757549596 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-2748.2155200032967,0,0 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-2.7755575615628914E-17,-10.030977235617156,0.15659454606410872 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-27.987040610119095,-0.04280577690104459,6.938893903907228E-18,-9.575593673555954 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-29.76399875228864,-0.0025274386911808833,-6.802233970578234,0.23092359562888845 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark60(0.0,32.23904451479743,-6.177744011002553E-22,-3.814055976000489,0.32041232012417276 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark60(0.03303199284405115,-99.31713860221045,-0.039446333911723905,-20.185312045699614,0.06764040420310541 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark60(0,0,33.69644987043873,0,0 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark60(0.0,3.3881317890172014E-21,-0.17982048125959485,3.2463179723818055E-16,-13.979723280862672 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-37.21149302387592,-0.036698407105644815,0.09664621835310402,-16.245764883450647 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-4.014536062810976,0,0 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-4.930380657631324E-32,0,0 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-49.91493865403429,0,0 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-5.1803818546656295,-0.05229417691573823,-88.06058424247168,0.01614552748953889 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark60(0.0,54.67786003927092,-4.4782915599387804E-5,-2.396205682921179,-0.7454813473646209 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-55.84010835240462,-0.060726247576282574,-3.3186298827698164,1.125097688280121E-19 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark60(0.0,5.798563172354801,-0.052728156420779125,-2.0370032215586593,-1.1071450624305916 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark60(0.0,71.30116200842193,-0.013210513208888275,2.2455358244120004E-4,-53.543570372478634 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-72.60386943760525,13.768544299587248,-61.537277245315906 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark60(0.0,73.49243080225939,-1.1102230246251565E-16,0.30965333215508695,-3.8171189356822084 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark60(0.0,81.79192696396642,-0.04658802958712149,-7.083096106568132,0.04005984372305804 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark60(0.0,84.00330228002662,-0.03900053848742933,-60.880473776975656,0.025798010959629056 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-8.881784197001252E-16,-34.61360809102438,68.49486247102602 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-89.03298566235773,0,0 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-93.94382540215615,-0.015441571741647064,-16.004896035229304,0.06604964024010138 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-96.61292095361601,-0.008915192057999514,0.3653674855904322,-4.299223080172273 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-98.57279533094099,0,0 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-99.9071615331166,-0.058714649052568235,-15.908934289474447,0.02419144722908817 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark60(0,-100.0,-0.048074933707540374,-8.715488554322002,0.18023043883362533 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark60(0,-100.0,-0.055219877124243394,-56.598646805656315,0.02591491773455168 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark60(0,-100.0,-0.05545824890642184,9.624901880593345,-11.124901880593345 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark60(0,-100.0,-2.7755575615628914E-17,0.3928703755599443,-3.9982559757937297 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark60(0,-12.327686851897738,-0.05338471731050154,-122.22843724652664,0.012851204858670572 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark60(0,-187.53949095729936,-0.015582869275871512,5.273213749906229,-6.844010076701127 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark60(0,19.33890372254703,-0.06122065019722394,0.02816658567590682,-55.76807728380535 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark60(0,-22.041785811349083,-0.008522800532216504,0.07732855155102747,-19.04223358698605 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark60(0,-23.65637410482222,-6.806093757341304E-17,-2.302761502352634,0.8024061962160792 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark60(0,-25.64517811064448,-6.938893903907228E-18,0.00785586499316715,-191.53986267759652 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark60(0,-30.139651392107563,-0.015868907728508595,-14.715199778115199,0.01856583120577867 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark60(0,33.7424844596073,-1.1102230246251565E-16,0.773282755324044,-1.9608209767092672 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark60(0,3.552713678800501E-15,-0.03536327094567633,7.541745885756007,-7.540626169774944 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark60(0,-3.7104904736166695,-1.1102230246251565E-16,-0.6245711627930035,-0.946225164001893 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark60(0,37.48780293940795,-0.049087131840587966,-3.0877700096360883,0.5087154554558341 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark60(0,-37.52043024562294,-0.016214119415535883,2.8273129100664534,-4.39810923686135 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark60(0,37.74826165060706,-0.0012056806468417405,0.1476565969577167,-0.14765659695771677 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark60(0,37.93378208874973,-0.013803660609144064,-3.812245085343164,0.38689576982034923 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark60(0,-40.097214339230256,-7.105427357601002E-15,-23.389486883072756,0.06651901613278888 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark60(0,43.975391093463514,-0.04086789697849929,1.2166650514744415E-4,-6.3256013289437645 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark60(0,-44.97635670698739,-2.7755575615628914E-17,0.14634986119426685,-10.733158979286983 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark60(0,-48.595345394796894,-0.01914264480839729,-7.943494238645277,0.10719867939987182 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark60(0,48.912219148983695,-1.1102230246251565E-16,6.967937238369844,-6.967937238369844 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark60(0,-49.26940208451855,-0.06117912908040779,-61.017111076275896,0.025743538149999523 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark60(0,52.462838860416696,-0.07942736127518335,6.857691970987853,-8.410519602370767 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark60(0,53.43043504212058,-0.05189638634398175,1.3322676295501878E-15,-19.064937567422675 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark60(0,55.12274787080557,-0.00332870280655315,-29.63757222966168,2.0392963452607604E-4 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark60(0,-55.9264869859621,19.796879858556167,90.19123871551952,17.978510439733483 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark60(0,56.70302988559331,-0.5475778222417669,1.6371929529337024,-2.9698210079191276 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark60(0,-57.98083004213264,-0.03788970595088692,-10.425720142402158,8.925720142402158 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark60(0,60.19685549076067,-0.04179456668249115,-1.2753396101111583,1.119761533454577 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark60(0,-60.29448223070773,-0.062463400870901686,3.552713678800501E-15,-48.19983866207466 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark60(0,62.67166074377307,-0.05185931474305713,4.263256414560601E-14,-28.582626408420197 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark60(0,-63.88238243457391,-0.03405727396413853,6.878081659252169,-0.22226821178836015 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark60(0,67.5332690416246,-87.01642716936624,76.95568293276904,25.08747845724386 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark60(0,71.8097764757532,-0.0246302558401698,-6.821577898382232,1.4747279752912516E-15 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark60(0,-74.70992930210035,-1.1102230246251565E-16,3.944304526105059E-31,-14.554516901425345 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark60(0,77.51121107241667,-1.3877787807814457E-17,0.8765378382768879,-1.7920462280131486 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark60(0,-78.73303431147997,-0.015780068976290584,-2.1997011089000376,0.699701108900038 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark60(0,-81.40628175978347,-0.025394278512544704,-6.246970453667728,3.105348949008686 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark60(0,-94.94381324494879,-0.004629531335753417,3.552713678800501E-15,-41.716227939824265 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark60(0,-97.89210946695542,-0.007321029339274522,0.4155512082821589,-1.969025995370991 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark60(0,98.80095681071782,-0.016009718965245168,-6.3534018272484305,1.681975566719578 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark60(0,99.69511900182471,-0.05704193197197975,-2.125076606341091,0.6250766063410913 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark60(100.0,100.0,-3.0555498410015907E-37,0.4240517666068635,-3.704256061385955 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark60(-100.0,-15.095746105353532,-0.11572663899339804,0.02828778906900639,-3.1943999414749404 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark60(1.0316746372888166E-14,-40.98939405332746,-2.4107941702239792E-5,-41.41315731718297,4.4276714430495153E-16 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark60(1.0904918366517774E-20,-12.55328127574283,-0.02730056357664823,-8.036653236643158,0.19498576863198436 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark60(1.3725935456087178E-22,1.8775776890554534E-12,-0.6458717587333694,-3.1957639395078274,-0.23057417679821712 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark60(-1.3958294802763442E-17,-24.250217877873805,-0.019977443176803014,0.11662238419379456,-13.469080894321635 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark60(1.472446084600538E-19,-4.8148248609680896E-35,-0.9999999999999999,-10.555134295369525,0.14881822275667345 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark60(1.6356936860962797E-12,-98.87450323306638,-0.15615087283574847,-1.3698890531301546,-1.7925988947712932 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark60(18.15267144582478,-59.13631323837466,-0.0482936496770609,1.7763568394002505E-15,-13.092415218114212 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark60(3.1406474027695556E-45,-100.0,-0.05887724593967386,3.5639871464974576E-45,-40.970385521231634 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark60(-32.04087489304219,43.91214597305131,-44.026046454461934,11.07866819406766,33.29834905504944 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark60(-3.552713678800501E-15,-28.54453798726567,-0.03055210666746687,-6.6482757669107855,0.08006263583088341 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark60(-40.671895671490276,-9.060088550773514,-70.0101311798598,49.8261984006549,-46.11899059968718 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark60(4.562641838014555E-34,-87.85935966388986,-4.7928656626483934E-34,-2.1127951415829207,-1.0288078363345705 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark60(51.500289866262236,100.0,-1.1102230246251565E-16,-31.87240813545594,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark60(54.790465256173675,85.7495433602809,-0.030198558680819165,1.1359900880444994E-6,-3.1479050936970765 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark60(5.72319769837571,5.88076234165473,-0.047351742459391694,0.03723554777525173,-42.18539596291117 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark60(71.75231481470641,-28.86702496109487,-0.02160053014166577,-6.794625420724365,0.1994453515568257 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark60(-74.8905754897936,6.3218571244003385,8.501223360983488,50.49897424769213,-24.39510774605516 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark60(-9.053045085184044E-38,-41.53362934261272,-6.079712820977352E-29,-13.613345858540267,0.07102489223596858 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark60(-93.41359513600689,36.85158795291045,-57.897778555305464,-4.6358504779565095,93.41428966374173 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark60(94.34708149377533,-50.08108356078475,-0.04044233308460539,0.013589633067920211,-47.31932973436408 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark60(98.54300834576233,56.156602944805776,-7.54423642382632E-37,0.023568668076698884,-66.64764939972596 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark60(99.90439843719102,59.26109789589339,-5.93726107703679E-29,0.18030548492368878,-7.781295794327489 ) ;
  }
}
