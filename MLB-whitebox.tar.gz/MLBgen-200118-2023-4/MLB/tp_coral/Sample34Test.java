import org.junit.Test;

public class Sample34Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark34(0.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark34(0.0024400010922140188 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark34(-0.02182009180751475 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark34(-0.052549570148889675 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark34(-0.15543062219754855 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark34(-0.16735123463367074 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark34(-0.24516876665527665 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark34(-0.3416338806418793 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark34(-0.5707955809926896 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark34(-10.14600182951886 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark34(-1.0337921311288878 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark34(-10.603680698812411 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark34(-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark34(-1.240401640072795 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark34(14.42920367719507 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark34(14.429214958798006 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark34(-1.4950661670347927 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark34(-1.5637524131861056 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark34(-1.5706460190024607 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark34(-1.5707963267948912 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark34(-1.5707963267948943 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark34(-1.5707963267948948 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark34(-1.570796326794895 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark34(-1.5707963267948957 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark34(-1.5707963267948963 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark34(-1.5707963267948966 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark34(-1.5707963267948968 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark34(-1.5707963267948974 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark34(-1.5707963267948983 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark34(-1.5707963267948992 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark34(-15.771813074163992 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark34(-15.879988616317632 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark34(-16.129138134660593 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark34(1.734723475976807E-18 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark34(-18.195052575016945 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark34(-185.39832831373553 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark34(-23.178481342430374 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark34(-2633.4360813757085 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark34(-2714.1062417463113 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark34(-3.1415926535897953 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark34(-3.1415926535917813 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark34(-3.1415926535970695 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark34(3.251502474643451 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark34(-3.2665926535897936 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark34(-34.77218537844293 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark34(-34.87506678408668 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark34(-3.4970880194907608 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark34(-35.265501688000384 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark34(-3.7982270983039195E-65 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark34(38.78948852695598 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark34(-39.99795693078823 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark34(-425.6858045610382 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark34(43.29633807792575 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark34(-437.6762439576443 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark34(-46.13450553108702 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark34(-4.930380657631324E-32 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark34(-5.040358692781737 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark34(50.66573741909633 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark34(-53.60577828154151 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark34(-53.63779871142016 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark34(-5.421010862427522E-20 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark34(-54.83142211397074 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark34(5.551115123125783E-17 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark34(-56.234772704615835 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark34(-60.842186516407935 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark34(-66.8911257998898 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark34(-6.784614049590701 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark34(70.3509505408773 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark34(-84.06407026516725 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark34(-84.48120701168892 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark34(-84.82300166182559 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark34(-85.05393979103695 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark34(8.881784197001252E-16 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark34(-89.00855719293747 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark34(-8.91289043745978 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark34(-8.920586724754727 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark34(-9.109238965752283 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark34(91.54768225957963 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark34(-95.18757462437092 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark34(-97.71221322956065 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark34(-98.00762515107103 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark34(-98.6033374477701 ) ;
  }
}
