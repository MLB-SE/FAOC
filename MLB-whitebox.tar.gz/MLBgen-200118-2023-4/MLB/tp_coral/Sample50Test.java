import org.junit.Test;

public class Sample50Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark50(-0.004975861241210539,3.7439659721357105E-5 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark50(-0.010567466555241161,5.095436872877632E-7 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark50(-0.03296340058709124,1.4027190849650716E-4 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark50(1.041593603515344E-8,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark50(-1.0471805285939756E-39,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark50(11.517303759322637,38.48269624067736 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark50(-1.2241785975264548E-5,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark50(13.429980506949047,26.42998050694905 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark50(15.968914024443535,16.802849785779884 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark50(1.6228414927876533E-5,2.0553239026834825E-7 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark50(17.148408957681426,30.148408957681426 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark50(18.669838870786776,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark50(2.2359608681164223,5.3349719199551 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark50(2.2360309791696269E-4,4.8396981120268863E-4 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark50(2.6193081530200004,5.241483834269033 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark50(30.98378166527621,61.26356037805968 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark50(3.4841882164711086E-29,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark50(35.880674022558395,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark50(3.6084692672872336,11.491563329022455 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark50(3.7408030230129308,5.66189008950577 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark50(39.982934464900154,55.23478548917703 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark50(4.484497314520297,84.73694855396721 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark50(-4.91731270741196E-40,0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark50(6.5459170783372874E-9,0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark50(7.538330172036552,58.70533798897094 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark50(-84.59427566304328,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark50(9.095479880252029,44.94925907385749 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark50(-9.14886825152672E-11,3.6438123089090687E-7 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark50(9.306802749418779,50.67341472234639 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark50(-99.6087252802188,3.8824772613587015 ) ;
  }
}
