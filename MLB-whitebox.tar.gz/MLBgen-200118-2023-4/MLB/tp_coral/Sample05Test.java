import org.junit.Test;

public class Sample05Test {

  @Test
  public void test0() {
//    0.6776058033090038;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark05(-0.0011410562764141573,-98.91005808825018,61.2623088060557 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark05(-0.0011672293172245683,-1.5707963138775718,-82.1339878169367 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark05(-0.0011709823841141095,-42.188669478495314,-108.03320078929863 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark05(-0.0013815303041368743,-1.5707963267948966,32.0547775807989 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark05(-0.0013939261859171829,-9.509199711312096,-1.5707963267948963 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark05(-0.0014197897323824588,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark05(-0.0014430440867022154,-122.55409244389742,1.5707963267948928 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark05(-0.0014924357943897348,-1.5707963267948966,9.19721800106965 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark05(-0.0015711887060092522,-0.049252815843143456,21.097026907056417 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark05(-0.001803553927496068,-1.3577453465902742,44.0423428973016 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark05(-0.0020254134852593147,-1.1102230246251565E-16,-4.71238953674253 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark05(-0.00205861303299593,-9.65838779821797,-1.5707963271821175 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark05(-0.002110031885326824,-0.23195433209784966,-88.79575331278201 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark05(-0.002150702739151744,-2.1175823681357508E-22,-48.371537804565335 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark05(-0.0024082107424080214,-3.2665927539677715,84.46102189563499 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark05(-0.0024198644511625456,-1.5707963267948948,24.729883688320207 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark05(-0.002424420654663636,-7.105427357601002E-15,13.04423788029176 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark05(0.002463960234940908,-0.32955321779789415,165.88578670614615 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark05(-0.0025189179668123392,-78.77618607847675,-1.5707963267948966 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark05(-0.0026465879429069285,-1.1018488831583335,-0.007206625312149995 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark05(-0.002738243480864988,-1.530731902395188,56.548667764534684 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark05(-0.0029934672155938944,-1.5707963267948966,-38.530274508558634 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark05(-0.0030856810416576364,-4.387114235581621E-4,111.5323763107438 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark05(-0.0031545589965363587,-1.5707963267948966,-39.038368727324446 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark05(-0.00323649054000508,-31.05624761624983,-67.41690037516184 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark05(-0.00328223965413808,-9.97494080359466,-98.77675605301106 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark05(-0.00349049593362738,-1.4364761215593724,54.047186528326165 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark05(-0.003578391743105317,-0.8141819747790181,18.99694370722429 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark05(-0.0035886916073529507,-105.06810127564613,-109.68180439635528 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark05(-0.0036123832745002115,-98.67917257605541,-17.278759594743864 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark05(-0.0039325829806215315,-0.30159015277610834,-25.5906791984546 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark05(-0.0040230491556027086,-22.36218805081769,-1.301520601130151 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark05(-0.004229917604107367,-78.96812530395084,8.103981635821697 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark05(-0.004389812999982351,-1.4496698219247661,-0.5624171722262977 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark05(-0.004389977258341508,-1.5707963267948966,-9.390203288362997 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark05(-0.0046015612377135065,4.141592653589847,-1.5707963267948983 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark05(-0.004653143312651719,-60.7417129637794,-1.5707963267948966 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark05(-0.004785232658426453,-0.2271464208441879,19.762049358160397 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark05(-0.005205702033323025,-35.22231287253649,-56.47770700661979 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark05(-0.005250211908326429,-3.143545975838271,1.5707963267948983 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark05(-0.005263688474081218,-0.7952251968587384,-457.06522423841704 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark05(-0.005375940284090901,9.860761315262648E-32,0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark05(-0.005467861136886715,-0.42636711667528054,-28.166364006851314 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark05(-0.005565786303572888,-0.05942774163193587,0.8806406556328218 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark05(-0.005573196596044976,-72.90363155963729,64.39354070776645 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark05(-0.005806994163653364,-1.2965140881969828,31.633895230608243 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark05(0.006017744905452302,-1.5707963267948966,59.18781998318062 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark05(-0.00605194387949165,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark05(-0.006193116067770049,-1.5707963267948966,-55.78542689527119 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark05(-0.006638784682902589,-1.023447237137781,34.71493397539663 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark05(-0.0066706455448048985,-230.59150057036385,-107.60230038742652 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark05(-0.007044587969460365,-1.5707963266584595,-64.1159962907523 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark05(-0.007178240129067182,-1.5707963267948966,94.2401218093664 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark05(-0.007233914711880974,-0.1270258439104613,7.8539817744062725 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark05(-0.0073205208850201965,-66.94865300329974,66.50561380581821 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark05(-0.007904407657807606,28.70353758984617,-4.713216914935641 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark05(-0.007982224426518676,-1.5707963267948966,-0.22302966559459686 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark05(-0.007984860834938424,-1.5707963268070706,-1.5707963267948966 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark05(-0.007998432765472806,-1.5707963267948966,-84.29634191473022 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark05(-0.008007780091743966,-0.1346005418742623,-15.793559493921364 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark05(-0.00827983065716569,4.141598835719663,-3.1416879675381146 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark05(-0.008643383644371932,-15.99297819816059,-2.8574684782056875E-101 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark05(-0.00881507679121753,-48.55965342820779,192.18773997966605 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark05(-0.008864855871891564,-217.6874326330626,-89.83049822464696 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark05(-0.009130391663518367,-0.4491167733415704,-6.138770277680308 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark05(-0.009369041261050093,-1.5707963267948966,0.17691936475796913 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark05(0.009800068522566686,-3.863232730971173,51.44304175895294 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark05(-0.00985478531085328,-1.428866992984774,39.26954999556944 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark05(-0.009891862525220785,-1.5707963267948966,-26.743822091071795 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark05(-0.009971227650914918,-1.5707963267948948,61.06287280949313 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark05(-0.009980980909769349,-0.40144811634554856,98.71461491644484 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark05(0.010037711544499107,-6.938893903907228E-18,51.633207667319724 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark05(-0.010359182969867325,-4.104613807267506,1.446905282922912 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark05(-0.010365803638018225,-54.45010176300309,85.3581170805342 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark05(-0.010689196380770543,-1.5099798387306171,-36.31534557327522 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark05(-0.010774075982057235,-1.5707963267948966,76.04731975659851 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark05(-0.010857768150779632,-1.5707958173544052,17.115660299836236 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark05(-0.01097860836491625,-3.141602954919394,-38.21666202268814 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark05(-0.011123712945243336,2.5849394142282115E-26,-4.659644094512984 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark05(-0.01148583608658028,-1.5707963267948966,-4.712389306648536 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark05(-0.011712344551570246,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark05(-0.011752380431939713,-1.5707963267948966,73.73457892143296 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark05(0.011960737356134466,-3.141600283783013,78.27765974129031 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark05(-0.012127390196089141,-0.10887566866004385,-47.204174562667276 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark05(-0.012178113134753669,-72.50101782129886,-6.4736397005271735 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark05(-0.012204809135306822,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark05(-0.012368131569683591,-1.5707963267948966,-19.812491056515977 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark05(-0.01243444515225367,-98.94551669640943,-34.528305375427266 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark05(-0.012880718528205048,-0.7019682270813453,-3.7118885633743446 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark05(-0.01292285476498986,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark05(-0.012997553330315579,-1.5707963267948968,-78.04495217295728 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark05(-0.013337154463377637,-1.5457624113826367,1.8887804574177949 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark05(-0.013376365436459176,-0.6486436963454124,980.0634219580757 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark05(-0.013604681042026372,-0.5168483154562901,3.5233153016298715 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark05(-0.013896355016294553,-1.5707963267948966,-57.56301279780333 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark05(-0.014066473458921203,-1.5707963267948966,13.747717158432648 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark05(-0.014141318878267178,-72.40328247811887,44.92388600597945 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark05(-0.014304632187760263,-61.25941376063684,1.5707963267948983 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark05(-0.014349183830752892,-5.6902623986817984E-160,56.74373218320106 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark05(-0.014441257380912566,-1.5707963267948966,0.023714861025113443 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark05(-0.014617034723694387,-1.5707963259529538,-49.83456081536202 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark05(-0.014714992545537063,-1.4606491531477663,4.712388980450983 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark05(-0.014893379454542976,-1.5707963267948966,-34.6944213167657 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark05(-0.015185283731054915,-79.03246054819601,55.85318696628366 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark05(-0.015270584181328414,-1.5707963267948983,-26.100594232802436 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark05(-0.01529474987592535,-1.5707963267948966,-69.79900285680071 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark05(-0.015475162631042467,-1.5707963267948966,-4.3368086899420177E-19 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark05(-0.015490592236092993,-34.55758022480002,-6.2847933418563 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark05(-0.01635576202344957,-1.5707963267948966,0.17999211787812325 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark05(-0.01684303825474824,-0.17872475465731283,-2.001858668132071 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark05(-0.016938556598042,-129.47586010772295,52.41809334472404 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark05(-0.016952468533791027,-16.059180899486506,-67.05164369203459 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark05(-0.017447370385515658,-1.5707963267948912,7.227945206873328E-16 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark05(-0.01778155459478703,-16.165777536901643,0.2553366262994956 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark05(-0.018302684841348893,-1.5707963267948966,1.5707963267949054 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark05(-0.01836420865612435,-1.5705498085871792,0.5383720309799315 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark05(-0.018564197410135208,-1.5707963267948966,-51.20338161384341 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark05(-0.018690549640541843,-1.391332321306894,9.425241280621446 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark05(-0.018759674154328554,-60.99730698076677,-65.06187733975415 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark05(-0.0188206570790721,-1.5707963267948966,-27.9864682389692 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark05(-0.0190920761049311,-1.5707963267948966,-1.3552527156068805E-20 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark05(-0.01926989266802733,-3.1417406852599385,56.04479009086752 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark05(-0.01945918471348731,-0.045671448068124176,47.12388980384694 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark05(-0.019483419172085313,-1.7763568394002505E-15,1.3524726306964634 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark05(-0.01954924966660021,-1.5707963267948966,40.76915356704271 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark05(-0.019601404652654558,-3.469446951953614E-18,-75.63230448751395 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark05(-0.019756966199659935,-0.03249316430221936,-64.52100386593457 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark05(-0.02002321737743351,-98.3663597879258,60.696537490335245 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark05(-0.020209275274410018,-0.1408053093432301,6.284161870415048 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark05(-0.020403669567363805,-9.616771385903121,-1.417842585873794 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark05(-0.020412487930801783,-7.706083080433234E-15,-20.674397985312197 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark05(-0.0205335226270865,-3.1416087174592633,-47.692095856669305 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark05(-0.02071628164101469,-1.5707963267948966,1.5707963267948957 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark05(-0.0217341021202323,-0.4635921326977274,32.72224793900307 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark05(-0.02191458144538053,-1.5707963267948966,86.71684217849312 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark05(-0.02195974977969961,-2.220446049250313E-16,19.932829312461866 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark05(-0.022361107161398865,-1.5707963267948963,-18.6387822941181 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark05(-0.022466369349696647,-15.840589387684945,-3.141616163249378 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark05(-0.02261329927645417,-1.5707963267948966,21.4622610302267 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark05(-0.022870373239518405,-1.1792287384206868,3.149405481620426 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark05(-0.023761921999480747,-66.27997132091599,42.87404705330879 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark05(-0.023864227852307192,-0.0023792553604918268,-55.393403397877684 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark05(-0.024163794881937907,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark05(-0.024488625884412002,-1.5707963267948966,62.97434618452874 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark05(-0.024630598417459983,-22.45499844640471,-48.66986902577178 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark05(-0.024994110462310926,-1.5707963267948923,22.45761738069571 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark05(-0.025512523337655052,-1.5707963267948912,32.43394096376542 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark05(-0.025817557573152523,4.141592653589916,78.35605458298528 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark05(-0.026007986193118685,-1.5707963267948948,-69.36063693468537 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark05(-0.026579410116161096,-42.050361650203286,12.171907282225131 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark05(-0.02658635479085103,-0.8748118517976818,88.29092401326224 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark05(-0.02662258414314069,-1.5707963267948966,9.620081548429242 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark05(-0.027017503052987932,-0.20953931047871907,7.854012940875764 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark05(-0.027299030950617142,-35.41396252885281,6.284163174090235 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark05(-0.02737662104118499,-22.476634222541094,26.703537555513243 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark05(-0.027555591416971777,-1.1695613826928137E-4,-35.44179787735091 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark05(-0.02763243226325954,-34.92348397681934,0.0 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark05(-0.02767819614014011,-1.5707963267948966,2.9261191204363826 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark05(-0.027690956928409297,-3.143545778596586,-8.37573968151591 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark05(-0.027715939825994074,-1.5707963267948966,65.62122032104175 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark05(-0.027727923705025144,-3.141593002087852,0.0 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark05(-0.027770986518802988,-2.7016136048916335E-225,0.0 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark05(-0.028056925698890556,-1.5707963267948966,3.17284267601027 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark05(-0.0281175505170026,-1.5707963267948948,-0.10954221465778063 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark05(-0.028123073988907357,-1.5707963267948912,-111.8255402790468 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark05(-0.02848918331313921,-0.9277836899134397,100.0 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark05(-0.028545319104868794,-1.5707963267948966,26.96330740402954 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark05(-0.028584442123104133,-0.16078601826420316,-0.9569084581461258 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark05(-0.028687307882692407,-2.220446049250313E-16,-4.5783630259548005 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark05(-0.028714744425785144,-98.17713749471142,50.18724153106186 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark05(-0.029148216053745166,-1.5707963267948966,0.09257936831430413 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark05(-0.02925982645165475,-1.5707963267948912,-100.0 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark05(-0.029301656333572124,-1.5707963267948966,-30.87744885308517 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark05(-0.029683978387799646,-0.6764546944559251,54.89678027631854 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark05(-0.03049368282608622,-0.4678448002419948,0.056725645578867834 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark05(-0.030514013391496064,14.429283006921764,4.7125623501068326 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark05(-0.030718120300543557,-78.88535321405814,0.0 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark05(-0.030748705646191254,-54.517199679473535,-22.76282407725111 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark05(-0.03122779120771446,-1.5707963267948817,44.8066925428628 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark05(-0.03171801933135151,-9.612203510720875,3.1420809348810503 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark05(-0.03224065092354165,6.607932070860053,12.569858884370593 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark05(-0.032785670982165366,-105.11355506306327,-210.4286954271599 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark05(-0.03331818298807328,-1.5707963267948966,0.18417466091816248 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark05(0.033488902682107836,-3.1630602037749105,-79.54572710679574 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark05(-0.033689287183815704,-3.1415926696061405,21.547469751227823 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark05(-0.03371067900528288,-0.7770648587547702,-8.539543342102823 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark05(-0.034034379511916235,-1.3519296236835363,-62.984033640597104 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark05(-0.03453965365757322,-53.407075111026614,-21.809205827494225 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark05(-0.03472203064433817,-1.5707963267948966,77.85762854810045 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark05(-0.0347539573606017,-154.32153092080767,2.7791472511154935E-13 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark05(-0.035755459075326096,-16.17859625382021,79.1895466491174 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark05(-0.035763087459085956,-1.5707963267948966,13.388159034651778 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark05(-0.036107330841609775,-1.5707963267948966,-21.76508282180054 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark05(-0.03631826288399873,-3.141593911103385,-1.5707963267948966 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark05(-0.03644786396608122,-98.4188822388339,-1.4130520461375426 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark05(-0.03693099419790593,-1.5394957871093298,66.55138965294816 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark05(-0.03726116034136984,-1.570796326791219,97.35658048213232 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark05(-0.03755581840023661,-6.094735384562312E-15,-0.24526960128800512 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark05(-0.03812060316107866,-1.5707963267948966,-1.570796326794896 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark05(-0.03833695254022411,-1.520575068298397,2.7484072643211235 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark05(-0.03836788106078352,-0.0025152063374137765,10.5658129375994 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark05(-0.03838109528280103,-61.08995787787104,-6.314435307183053 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark05(-0.039549958097174986,-167.16645651138316,21.169639366832314 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark05(-0.03962951632191247,-1.529513587400909,-1.5707963267948484 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark05(-0.03967867483414615,-61.256808957595354,60.958587323075065 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark05(-0.039821908378439984,-94.64406941453132,0.0 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark05(-0.03993528412027213,-1.5707963267948948,94.36488351497877 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark05(-0.04012101648588384,-42.17822569702465,-147.84695156962093 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark05(-0.04028235761184548,-35.082680684170334,-67.67173647138517 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark05(-0.04032674290603681,-1.1395579007333936,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark05(-0.04057453985267697,1.0842021724855044E-19,34.21840407908048 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark05(-0.040657141861642244,-42.130566311158354,201.21120424603237 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark05(-0.04066120193837078,-78.76131283560217,60.900490109164764 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark05(-0.040804282769098525,-1.5707963267948906,-50.295924892735975 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark05(-0.04080549372625514,-35.77933835833809,-20.641460451611245 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark05(-0.0408351127653086,-66.36612266115802,-76.21620443867319 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark05(-0.04090683017755263,-54.64584911316034,-5.141592659196704 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark05(-0.04170517445866178,-9.9345751674046,-0.85361923106024 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark05(-0.041858806502576645,-1.1030045863618487,4.141592654947922 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark05(-0.04187789541947409,-0.21081893566878837,77.45451125022993 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark05(-0.04188349134814276,-34.93084736121877,-45.24425768059267 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark05(-0.04259494508538764,-3.552713678800501E-15,88.11363815207886 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark05(-0.0425976009690752,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark05(-0.04293877005231295,-9.964280868854358,29.030023916098656 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark05(-0.04294490129555506,-1.5707963267948966,-51.54105183096324 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark05(-0.04328373049882611,-0.04261935291160007,72.97620034145606 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark05(-0.04336844414148645,-909.1801781182833,-68.12022471324444 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark05(-0.04340315713584708,-61.04648175105186,-55.595739996442475 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark05(-0.04365485885601181,-15.735294260059135,-60.441683734932 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark05(-0.04382390748865144,-1.5707963267948966,-19.760290064401204 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark05(-0.04391163576328039,-0.30489396192886664,-1.835719458592422 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark05(-0.044280854718892426,-1.5707963267948966,54.198998377828914 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark05(-0.044600523903173823,-0.22356715790942722,30.737060783819675 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark05(-0.044792649197276546,-0.34212610129246257,18.66012158860893 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark05(-0.04494046457453771,-1.5707963267948966,-56.71799478874855 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark05(-0.04521824160863941,-40.97922964187473,4.1415926535899565 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark05(-0.045663963643995054,-1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark05(-0.04580366279904266,-34.82704648344692,16.47015589353302 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark05(-0.04619195291823092,-1.3786646833868654,34.187677722005276 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark05(-0.047033099200220876,-1.5707963267948966,-96.5619012233415 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark05(-0.04703642253265119,-0.028025581627695438,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark05(-0.047254571854659255,-36.0069974542393,0.0 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark05(-0.04808424583127868,-0.18659499807781715,32.197330588258026 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark05(0.04808593318761147,-78.92433536350235,6.985228921067463 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark05(-0.0481538962866905,-98.46151898119149,-7.057615959628009 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark05(-0.0494152827683406,-1.5707963267948966,6.636655826788001 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark05(-0.0494632377478883,-0.3015258958536604,-48.55685548546046 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark05(-0.04982521834245068,4.2351647362715017E-22,42.5498848447354 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark05(-0.05002477259542215,-0.40662961985649837,-91.38157308901904 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark05(-0.05017845828978425,-3.522101828684134E-133,-48.837180610533835 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark05(-0.050613931598215256,-15.893204437327167,1595.4460776071455 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark05(-0.05121514016124362,-1.5707963267948912,-69.73222939290527 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark05(-0.05121971972429179,-0.7860673970495731,64.72873768562431 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark05(-0.05136357165346694,-0.7957267617253246,35.04337648240532 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark05(-0.05139177018309576,-1.5707963267948966,8.103981767953092 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark05(-0.05153399517204699,-66.2833450271508,26.2482957940039 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark05(-0.05157866428683083,-1.1715767368923247,54.221152449725395 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark05(-0.05197864591430752,-0.4801627878601077,76.74263708862955 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark05(-0.05217326695952751,-9.555851684994963,-63.43760041883665 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark05(-0.052342148131614676,-588.999670071097,-78.72162556743278 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark05(-0.05252918088328532,-66.36803126075048,-57.49154104800704 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark05(-0.05262867534534159,-9.652819332576724,-4.712389142124548 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark05(-0.05277808006026116,-1.5707963267948966,34.97068584196728 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark05(-0.05290883612565267,-60.80923293216074,0 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark05(-0.05353115037573588,-1.5707963267948966,79.26110501556545 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark05(-0.05377916223089771,1.6599926055355645,19.414665618559557 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark05(-0.05379417043020873,-1.4770959967751773,5.621036779825825 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark05(-0.05444461906938458,-3.321669048350392,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark05(-0.054550571189286474,-1.5707963267948966,52.025129652461686 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark05(-0.05540700178271454,3.1494216447452583,203.13001739488783 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark05(-0.055886235752292075,-1.3108214834616447,1.5707963267948966 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark05(-0.05603607291450885,-73.1943089526753,1.5707963267948983 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark05(-0.05627218463534689,-1.5707963267948948,2475.1300425002437 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark05(-0.05650469874763606,-0.14616365777167747,2.5379418373156492E-116 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark05(-0.05661819610517682,-22.406142284442133,-1312.3813082579975 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark05(-0.05663440827627022,-1.3857848090120466,-53.69678459480682 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark05(-0.057276947934176814,-1.5707963267948966,-56.084597725584395 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark05(-0.05737981647531232,-41.86845877997685,118.10971689743845 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark05(-0.0577824087570491,-1.1546057202074251,-86.62993862268989 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark05(-0.05792042617151541,-0.5380045529670852,-61.95241370521529 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark05(-0.05806165270491981,14.429937328933164,100.0 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark05(-0.05841013638891468,-1.5006956257009403,1.5707963267948983 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark05(-0.0587481924542455,-0.7395300903120152,48.22843419528331 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark05(-0.058802370908453576,-1.5707963267948948,73.01179693913005 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark05(-0.05898785287664949,-0.6813952049497678,86.5955574249361 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark05(-0.059039548648625664,-1.5707963267948966,14.821152849840175 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark05(-0.05904220953001744,-123.09943880902262,120.09061467534767 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark05(-0.05924975940785199,-0.5570856325490022,85.93973250551821 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark05(-0.059605169468633354,-98.35118394099769,-98.56948131602228 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark05(-0.06000694908197908,-0.7984572404255869,5.141592693960301 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark05(-0.06018170895656544,-1.568401299617215,-58.119464091411174 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark05(-0.060436225049643744,-41.434343117140045,-39.514729885850564 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark05(-0.06058858221788577,-9.537284814913585,-13.73066302511414 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark05(-0.060774821785559555,-41.91165034826351,51.82830072547188 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark05(-0.061015824317670844,-0.06087564971941939,12.794733071627991 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark05(-0.06136011572983959,-1.4544829227155844,-42.403449798187076 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark05(-0.061426983881217694,-9.232978617785736E-128,-3.6543930514341545 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark05(-0.061829243771112596,-1.5707963267948966,-1.5707963083771297 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark05(-0.062358130982861824,-40.98738653001509,95.0629705055953 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark05(-0.06250507510492054,-3.3371550066517983,-48.141847635512065 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark05(-0.06253999373905966,-1.5707963267948966,21.90718084626636 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark05(-0.06276562621289994,-147.81364042145714,-28.46215718979252 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark05(-0.0629460677065603,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark05(-0.06312451208143044,-78.71012166763084,-23.036861191373106 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark05(0.0635007417679651,-22.48153091541377,-1.5707963267948966 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark05(-0.06372010513240714,-54.88054689134995,56.38118850793455 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark05(-0.0639106376566233,-15.78179745294173,-89.74104260808227 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark05(-0.06439115655593142,-550.3123430185318,0.35659182698069913 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark05(-0.06489907687018537,-10.113734962979004,-69.3766870710375 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark05(-0.0651947523209575,-110.44711212148164,-32.210582156901616 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark05(-0.06561528279917984,0.41917099866401697,1.0812459771354395 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark05(-0.06578679396896582,-0.1622098840040683,-63.56706054787837 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark05(-0.06585495245348671,6.6174449004242214E-24,40.413572086826576 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark05(-0.06646025056922708,-1.2813331809171846E-144,-68.94253999803381 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark05(-0.06670666341783349,-4.025952588788854,0.0 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark05(0.06678282468355012,-1.2702245787141089,50.03638831080342 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark05(-0.06679890428275373,-3.1416791568357887,0.0 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark05(-0.06709106879783978,-1.5707963267948966,-81.57287067413111 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark05(-0.06778895577023447,-110.10910751688658,-58.31554559051857 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark05(-0.06789096559615354,-0.3365384948842919,10.799333440328326 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark05(-0.0681449764277809,-1.5707963267948966,2.2607656964297433 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark05(-0.06835864487904744,-3.141593676030958,-3.9953493865995213 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark05(-0.06836940346790688,-1.5707963267948966,20.692279278717766 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark05(-0.06870162388456436,-6.838807103405287,114.56159627307022 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark05(-0.06881726025500612,-0.5347345485348646,0.0 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark05(-0.0693802010030451,-1.4973127595395965,33.03641715006211 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark05(-0.06954664417540195,-3.141696351048067,92.54692841740959 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark05(-0.06970545458526023,-38.61722030803077,59.061569051087844 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark05(-0.07009355011905113,-1.5707963267948966,-1.5707963267948961 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark05(-0.07019327785073569,-1.5707963267948966,8.104005473398663 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark05(-0.07036466250794492,-688.3690285310225,75.93808615417637 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark05(-0.07041914107843915,3.3251257859082357,-6.287787442358048 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark05(-0.07061540972324865,-1.5707963267948966,-75.86772628989868 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark05(-0.07066625305080951,3.448226047864537,27.854484944488703 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark05(-0.07081192576561925,-1.1714582054997522,-86.39890256836877 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark05(-0.07131201486443572,-59.74861538016252,0.04082646590906299 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark05(-0.07169804075865989,-0.7973207339975148,51.83563895753656 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark05(-0.0719069329604547,-1.0332665144169,20.69984610708144 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark05(-0.07214703267799903,-1.8033161362862765E-130,18.50072641009109 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark05(-0.07256350001428355,-0.06197440130966656,3.2960213926199247 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark05(-0.07289839799734131,3.469446951953614E-18,-33.23683150733871 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark05(-0.07330109112944463,-0.46351789727556836,-83.5683095061631 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark05(-0.07391408003599165,-78.85775602637418,158.24737737728543 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark05(-0.07396053575255936,-1.744073885657531E-15,-1.5707963267948966 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark05(-0.07397573266816436,-0.3027152145689207,-75.77705239029744 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark05(-0.07402024198961796,-0.08007077942003282,70.64562765231543 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark05(-0.07418966287876494,-7.213264545145106E-130,53.51419495774451 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark05(-0.074333046553,-1.5707963267948963,4.141592653949237 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark05(-0.07511671573761902,-3.172734956875984,-133.9277715059885 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark05(-0.07546142851456623,-1.5707963267948957,-1.5707963267948968 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark05(0.07559804884357336,-0.41314657612364947,3.266964786017691 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark05(-0.07674206645174203,-1.5707963267948977,91.10433977989778 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark05(-0.07675207754362967,-1.5707963267948983,-25.7217068943982 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark05(-0.07689692175130702,-1.5707963267948966,16.744108918244873 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark05(-0.0769156263615075,-47.123957349595166,55.038946756230914 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark05(-0.07745126959433239,-1.5707963267948966,6.287100048205434 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark05(-0.07813658356673223,-1.1834043843299902,-53.960453295659335 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark05(-0.07863363221388231,-0.014096049914190978,-63.86704225419375 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark05(-0.07886358300786435,-66.40413090418409,3.141685022600084 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark05(-0.07896515589042974,-0.22596222713647252,3.3433455904545752 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark05(-0.07920610768704951,-9.956200763267766,-37.403925381513574 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark05(-0.079592204598821,-1.5707963267948966,67.1643175641749 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark05(-0.07963483638807778,-3.1416008930110983,-1.5707963267948966 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark05(-0.07975126321684911,-0.7211981049479537,-169.9550080437266 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark05(-0.08016779140543145,-9.949480268429761,-556.956503530051 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark05(-0.0802589232486497,-73.11664319485507,-32.37955701153021 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark05(-0.08040487054154921,-35.89911691146449,38.96692903473531 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark05(-0.08074412196208697,-1.5707963267948957,76.80957426533834 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark05(-0.08079323365353486,-1.5707963267948966,-56.901087402145166 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark05(-0.0814881856943298,-66.30765210198861,73.69596508313019 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark05(-0.08154508574435926,-0.06881013461609914,40.84070449666731 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark05(-0.08159428325302587,-1.5707963267948966,91.21318922703193 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark05(-0.0819587285136502,-48.33904187600937,0.0 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark05(-0.08203982279575397,-3.141600453176876,1.5707963267948961 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark05(-0.08217814089073272,-47.28999338011503,141.0226986894973 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark05(-0.08258833822353506,-3.469446951953614E-18,41.07914025360265 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark05(-0.08319564258195422,-0.2859217004730101,-23.577503542399484 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark05(-0.0834695644037522,-1.5707963267948948,-43.299880991118094 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark05(-0.08347506827466136,-48.668046044284466,-67.1007719990077 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark05(-0.08372578992664434,-3.5691320343123545,-94.53524152867081 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark05(-0.08393115334213577,-53.50187122852081,71.18486986123955 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark05(-0.08442635146366789,-16.098230475056,69.72708154548394 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark05(-0.08444381815285568,-1.5707963267948948,-44.22800329523929 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark05(-0.08479536698708896,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark05(-0.08490312891942602,4.141592653589839,-100.0 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark05(-0.08534030327363729,-1.5707963267950502,-189.36238283451638 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark05(-0.08623362937519151,-35.918093041346886,-8.853981630113458 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark05(-0.08665980035900431,-48.540815152134975,-45.49415924420883 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark05(-0.08685744007220486,-1.5707963267948966,9.860761315262648E-32 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark05(-0.0870577196848986,-1.5707963267948966,81.41267864871075 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark05(-0.08719550170563212,-1.5707963267948946,-4.481331802012387 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark05(-0.08754205994638636,-1.5707963267948966,40.44647109033369 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark05(-0.08764546695286601,-0.4575225866223734,41.04975959156948 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark05(-0.08793458511843573,-1.5707963267948966,-21.26199770908444 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark05(-0.08802656761742648,-1.5707963267948966,39.97918662712377 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark05(-0.08825667060981492,-1.5707963267948983,66.20994874448114 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark05(-0.08847583898343608,-688.2585220278622,80.7198638736104 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark05(-0.08869296524829237,-0.07230573237379836,15.81772618365514 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark05(-0.0887959608323925,-0.9842180224048748,18.425794028306804 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark05(-0.08896258967457599,-1.5707963267948966,35.19654346275798 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark05(-0.08902305881267758,-1.5707963267948966,-31.95300864785869 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark05(-0.0895046341932056,-1.0893825531504127,15.850317676853692 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark05(-0.08987733639945306,-1.1912126170975874,66.34811420761392 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark05(-0.08990644087969127,-0.005721960638843315,89.72155638700389 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark05(-0.09057095820817329,-1.5707963267948912,0.0 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark05(-0.09063444011712196,-1.5707963267948966,436.29513581587315 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark05(-0.09102163758935117,-22.469734334574824,-1.5707963267948966 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark05(-0.0911845477455726,-1.5707963267948966,-63.37196687630469 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark05(-0.09134154713220277,-1.5707963267948948,-79.80615881816738 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark05(0.0,-9.15200557235685,56.38997320188727 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark05(-0.09274219497810714,-1.3690851156113197,359.6921908401554 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark05(-0.09298233429774568,-0.6430301604348583,-40.48701555954027 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark05(-0.09342207573361747,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark05(-0.09384442036616351,-3.1435458124290534,-64.11384531785474 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark05(-0.09388936224149869,-0.22859887152405228,-100.0 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark05(-0.09410410200051875,-1.4292643809196701,51.57058115714466 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark05(-0.09428148238118829,-47.429104618884985,-32.276573568259415 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark05(-0.0949202246347629,-48.380166006496225,1.5707963267948966 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark05(-0.0949674303694037,-0.25882009562011454,0.0 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark05(-0.09554554366240797,-48.2450031994494,67.91620506881515 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark05(-0.0956294124724021,-97.8781394771969,-22.208410601490193 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark05(-0.09567578327266116,-1.5707963267948966,9.044682200498336 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark05(-0.09644913240665316,-1.477619785239435E-16,1.5707963267948983 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark05(-0.09659541025287509,-1.5378188597228435,8.881784197001252E-16 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark05(-0.09701390561945261,-1.5707963267948966,157.52019259294693 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark05(-0.09726484745919184,-53.53490794562623,70.28210403770493 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark05(-0.0975292815346892,-1.5707963267948966,51.64676733105841 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark05(-0.09754883747150031,-0.11427796156096592,-8.20462718582739 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark05(-0.09823955565624337,-6.786903522159008,-2.9242092003357385 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark05(-0.09889758661226367,-0.2961640443148963,-529.2131803611586 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark05(-0.09981814233154443,-1.5707963267948966,-3.8285686989269494E-16 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark05(-0.09985938198698562,-3.552713678800501E-15,47.824808359773535 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark05(-0.10001569478968282,-3.4561217373328272,3.1415926535897976 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark05(-0.10076318320831237,-1.5707963267948966,-89.61323243595751 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark05(-0.1009729798494679,-1.480732462749245,-59.59772537009942 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark05(-0.10098351878117207,-1.5547630874129936,12.671929983223997 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark05(-0.10166280286273836,-135.65447480709088,-8.107409804307288 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark05(-0.10170518333884737,-1.5707963267948966,-6.283185315541158 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark05(-0.10213418339027092,-1.1248774728015496,-70.23141717583678 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark05(-0.10216382391871176,-40.970598514700185,-22.324724191066686 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark05(-0.10218831147565244,-4.5917748078995606E-41,79.60910046673955 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark05(-0.10278838941388962,-48.67561287728249,-28.54073534788104 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark05(-0.10293555449392322,-1.5707963267948966,-1.5707963267948968 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark05(-0.10353109397298872,-84.82300164692828,-15.731733012263819 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark05(-0.10397573201742799,-66.64579811762049,26.536200448943532 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark05(-0.10413465219750627,-0.08771075721804045,57.262046439293385 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark05(-0.10428372586506288,-0.7695443867760494,73.48737807870829 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark05(0.10438373556150464,-0.8611911278877175,0.0 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark05(-0.10439472700738861,-48.34918347277799,-90.83613238122415 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark05(-0.104767379179979,-3.865834105362461,60.963268088285986 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark05(-0.10527705287477845,-1.5707963267948966,-40.844610791624774 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark05(-0.10528140305372907,-41.7743308701449,-21.271594293003247 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark05(-0.10618416902279001,-1.5707963267948966,-26.898659827906584 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark05(-0.10691870364451239,-1.2129054994477972,75.3984018366085 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark05(-0.10733441314332184,-0.8514688144630388,-74.74001404944153 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark05(-0.10769856788404532,-1.5707963267948983,88.64721468055076 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark05(-0.10774170225907653,-0.06567692107126777,1.734723475976807E-18 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark05(-0.10783864562399531,-0.2698040681972538,25.53368380321352 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark05(-0.10793178424129052,-1.5707963267948966,-10.626188031769926 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark05(-0.1081082504752542,-1.4768268238797533,-3.1494054965079656 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark05(-0.10832467394746459,-66.31864710518286,-4.692277037315241 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark05(-0.10839136647785039,-122.81061124889928,-1.359016029038699 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark05(-0.10854183157522991,-3.406382647836054,1.5707963266544827 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark05(-0.10872918967353425,-1.5707963267948912,4.217119658008656 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark05(-0.10874046743635113,-0.4795010436088427,-30.74730723888773 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark05(-0.10874146437629673,-128.82165435852133,-27.83775691210584 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark05(-0.10885379042999604,-0.4368540758605706,-13.638334027693944 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark05(-0.10906478250415219,-1.3552527156068805E-20,3.889023591817316E-16 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark05(-0.10915064966705235,-1.0994683361642543,-31.555385173058482 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark05(-0.10917082199329853,-1.5707963267948966,-28.64844830021283 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark05(-0.10929725464630433,-0.7342773683209942,66.04124493580441 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark05(-0.10938894101660157,-1.5707963267948966,9.055679078826712E-72 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark05(-0.11009602058342366,-0.15634758347898342,72.66681544947683 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark05(-0.1101902008715578,-9.501888435240515,-1.0440487148797639E-53 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark05(-0.11043679893499263,-1.5707963267948957,-27.38474153389229 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark05(-0.11063493517738096,-1.1946229653700806,-1.5707963271341867 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark05(-0.11090615774419466,-0.6290157272635511,-13.626436660436509 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark05(-0.11095798470512683,-1.5706221332247174,-94.81706164612035 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark05(-0.11175146728931717,-7.105427357601002E-15,-24.391968786395807 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark05(-0.11178471777674352,-1.570796326743898,0.10107886344362538 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark05(-0.11184822668173972,-98.05725011503583,-1.570796326287576 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark05(-0.11195007304093263,-1.5707963267948966,-16.543139738750426 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark05(-0.112342268033872,-48.29376284300761,-100.0 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark05(-0.11262135773744009,-0.5572284763165802,47.29151766673565 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark05(-0.112864975407137,-0.30729892905235223,59.69026041820607 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark05(-0.11295225553687321,-1.5707963267948966,2.4461466141616626 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark05(-0.11375405228228885,-1.5707963267948966,52.616620771746284 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark05(-0.11386069718343651,-1.3860507868099714,39.41769815926348 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark05(-0.11397349670389213,-161.7549879346438,-8.108075762348202 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark05(-0.11409175960117426,-1.3921076263162118,35.65783415661621 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark05(-0.11421254800562508,-61.238655226515725,12.224455736456456 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark05(0.11486417359179071,-41.04530820419594,1.5707963267948966 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark05(-0.11487568240754326,-3.266592653589798,71.40554144355423 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark05(-0.11504184262193892,-0.9907177434601613,6.345738970268702 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark05(-0.11554553707504844,-0.5934046904275879,-66.90182324218776 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark05(-0.1157063041364178,-10.044634394957669,1.5707963267948983 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark05(-0.11587065541361785,-15.969465932338679,-97.08799278230256 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark05(-0.11664958707345562,-1.5707963267948966,8.103981687870256 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark05(-0.1166573249782906,-1.5712685658716004,-84.35946047768309 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark05(-0.1173576471700235,-73.04401884556302,-10.705522451423818 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark05(-0.11739107255043002,-1.570796326794897,-29.8677613877778 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark05(-0.11756674332239166,-0.37833213344076244,-49.92903444111208 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark05(-0.11776508388075335,-122.90947240087084,1.5707963267948966 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark05(-0.11788137443027413,-1.5707963209513982,-65.81790327989569 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark05(-0.11823635787589218,28.703537555513265,-57.514011504830805 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark05(-0.11829627199620936,-1.5707963267948966,4.712425424389864 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark05(-0.11835423874946349,-1.5707963267948966,-26.56328398533745 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark05(-0.11878267487515037,-98.84411783066555,-82.52870731502453 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark05(-0.11883504276776263,-1.5707963267948966,6.5331853107187365 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark05(-0.11900037679836084,-1.0406185196078468,18.86541860034154 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark05(-0.11928524505056076,-15.888705544079256,36.68786484830852 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark05(-0.11948933504190024,-1.5707963267948966,28.08835872894454 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark05(-0.1196014318855827,-72.48564796960369,-25.136647561512095 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark05(-0.11979125574590585,-0.5761381280617185,45.43468492988015 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark05(-0.12001987639207201,-3.1415926536010637,63.72525010258667 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark05(-0.12031893936718471,-1.5707963267948966,-72.25668281979394 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark05(-0.12050678759093371,-7.187790341278667E-16,-78.07774898042007 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark05(0.12059989990006227,-0.8104035877732899,0.0 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark05(-0.12107341663187299,-2.220446049250313E-16,20.42055245593725 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark05(-0.12108924803108893,-48.263563202908024,59.49193490528043 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark05(-0.12191644432392224,-1.5707963267948966,-67.11002528782876 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark05(0.12256854237734273,-36.05599875423628,78.86414970474704 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark05(-0.12324110065152834,-1.5707963267948966,-73.82742735936014 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark05(-0.12329669045277744,-0.01807122798168237,-1.5707963267948966 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark05(-0.12345475103847678,-1.5707963267948966,77.5505486769694 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark05(-0.12386502629740237,-1.570796326794892,-56.88297307019649 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark05(-0.12388933893410664,-53.42320184547534,-12.725282419283179 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark05(-0.12409022053811734,-1.5707963267948966,-1.291897811547642 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark05(-0.1241644333045158,-78.97145420118571,4.14159317956665 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark05(-0.12427537563504576,-0.04520457896129038,98.89195791711428 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark05(-0.12453601992506541,-0.23943790775575502,-105.25629975755214 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark05(-0.12511193253476097,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark05(-0.12561367627618697,-1.374325535087603,78.07045735780423 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark05(-0.1256550045889041,-1.5405628459063487,-1.3342688451540439 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark05(-0.12604872914885765,-9.424951263535844,1.5707963267948966 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark05(-0.12658469305466724,-66.50254180636875,-69.95664113758826 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark05(-0.12678294134144474,-10.37654749822022,108.26162890299753 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark05(-0.1269838164498216,-1.5707963267948966,-75.70249414880439 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark05(-0.12750199875840545,-4.6365076883592767E-69,28.056713394855468 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark05(-0.12759853150424272,-78.86517589241113,-86.17047610883773 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark05(-0.12761164723237073,-1.5707963267949054,61.36517220511308 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark05(-0.12791141987907598,-34.59750974443408,-77.04646675325276 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark05(-0.1283162121699666,-1.5707963267948966,48.64473314258559 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark05(-0.12954399962029536,-1.5707963267948966,-1.6291978687632984 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark05(-0.13001927170775585,-1.0295115178936058E-84,-32.859925124321144 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark05(-0.13003280330122724,-22.431887025468058,-73.4782403477385 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark05(-0.13003449263721545,-1.5707963267948966,-80.11061266653972 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark05(-0.13022419123365483,-35.80906512887047,-0.34798295139721347 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark05(-0.13046013814270685,-53.5866663676843,38.99062960406329 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark05(-0.13050764730033246,-1.7197762835371747E-136,-58.551520445708086 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark05(-0.1309497409287621,-73.09627445980088,-44.8763268430386 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark05(-0.13113563826876437,-0.5842267471780023,625.6418850292079 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark05(-0.13165109568137454,-4.527839539413356E-72,85.10989574685236 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark05(-0.13170678764679522,-48.3163534361801,-15.705316704184398 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark05(-0.13193361318417768,-60.943957199823984,39.566605108645035 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark05(-0.1321281744475551,-1.5707963267948966,97.76980298363937 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark05(-0.13234390713884825,-1.5707963267948966,-75.99597431160967 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark05(-0.13235638659419308,-10.06499793896163,-89.65928974066044 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark05(0.13274164523625132,91.06546389486721,-28.82317568813788 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark05(-0.13316089617578936,-98.04251664753656,-2.1717660684561078 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark05(-0.1332548939351309,-0.6135185359131187,18.849587927543283 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark05(-0.13337462585942372,-1.5707963267948966,-56.17557037788089 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark05(-0.1335218099872586,-0.9850717014226535,-44.2564216157359 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark05(-0.1335524696023463,-0.4951601065444905,-13.01201792851976 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark05(-0.13395545381096152,-1.3907222690731276,14.137786385417053 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark05(-0.13492546078059078,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark05(-0.13525763200893678,-2.0876931694149572E-19,-1.5707963267948966 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark05(-0.1354403341483046,-1.5707963267948966,-94.53218866276274 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark05(-0.13646677671269483,-0.5664536150740679,16.43906649445447 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark05(-0.13669200909817833,-1.5707963267948966,61.124481647804174 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark05(-0.1375747943304556,-1.5707963267948966,-532.4998074541766 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark05(-0.13767443113869562,-34.57955619503831,-3.1728426592387455 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark05(-0.13799830027696036,-1.5707963267948966,-26.90794487962485 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark05(-0.13802480531964847,-0.01119100562317975,-52.713399415056834 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark05(-0.13831446175805906,-3.4976551920677528,49.754299790714654 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark05(-0.1385144661165173,-1.5707963267948966,-75.6869533208868 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark05(-0.1386150259096507,-0.5246846567009871,20.420352248333657 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark05(-0.138966621056087,-0.4486381984041515,98.68052761516901 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark05(-0.13915395990326712,-110.34223582142505,54.85756115429067 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark05(-0.13941613105989126,-1.5707963267948966,10.528003582472154 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark05(-0.1407879313203327,-1.5707963267948966,27.724150230811322 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark05(-0.14092464899036447,-1.3382757651698407,48.81236744879863 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark05(-0.1417255184306417,-0.25077432173693975,1.5707963267948966 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark05(-0.14181015276115327,-0.586743974099005,-743.180575324908 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark05(-0.1421543164368952,-1.5707963267948966,37.10655587311266 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark05(-0.14296676102056305,-2.7755575615628914E-17,-89.01756099863833 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark05(-0.14314017780010763,4.141596063185391,-100.93601328455469 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark05(-0.14381990985801174,-0.12219183521597721,112.688857232093 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark05(-0.14390692927890086,-78.57548237591341,1.5707963267948968 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark05(-0.14481039061224849,-73.18690365351092,39.15149403841257 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark05(-0.14548564213214205,-0.15618079372141747,75.76703107565149 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark05(-0.14589865064529994,-4.041302158303466,-1.5707963267949019 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark05(-0.14606080449129877,1.3234889800848443E-23,90.6610685456476 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark05(-0.14667619179257996,-41.54286172103821,1.5707963267948966 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark05(-0.14669525114144213,-84.90425258410319,48.00482230232291 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark05(-0.14792854560660817,-1.1315832450078673,-1.5707963267948966 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark05(-0.14846368825911066,-0.2894997336730692,-0.9378219161201681 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark05(-0.14875321090191324,-2.7755575615628914E-17,1.5707963267948957 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark05(-0.1491529090786204,-78.82682932703679,8.66637447932061 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark05(-0.14920600874021636,-0.2736001705214433,-6.791196528908266 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark05(-0.1492710617220221,-98.11539004160605,-16.02763935805811 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark05(-0.14973133546666884,8.966326006850135E-18,0.0 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark05(-0.1499722206204428,-54.69952136760639,282.88888713958715 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark05(-0.14999443632062467,-66.36047821103945,-1.5707964219226318 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark05(-0.15025635359070177,-10.183298436097637,35.83019625093985 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark05(-0.15047904220443903,-98.32049116914496,1.2468604114729716 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark05(-0.15063132127732787,-72.87389759458016,-54.878485447915516 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark05(-0.1511570773556775,-0.0200455395435886,-69.29688519856096 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark05(-0.151318026521545,-1.3317973425476612,-1.5707963267948966 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark05(-0.15149150003776413,86.14193776894595,-99.5800786855153 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark05(-0.1515028207869652,-0.5251115704350633,-4.712403357243864 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark05(-0.15194176309148222,-1.5707963266744187,-48.11260833036748 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark05(-0.15234459979885173,-0.23206441846643244,-40.117863510610064 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark05(-0.1526873652156553,-0.14731346225507325,1.5707963267948966 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark05(-0.15405611827853982,-0.427592349638581,98.27780312532965 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark05(-0.15464511993184227,-1.5707963267948966,-15.990938228043902 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark05(-0.154749116339305,4.141735949229953,8.221274321826556 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark05(-0.15541745917059097,-1.42188716263997,79.1098028531357 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark05(-0.1554605492554637,-98.84134415053576,1.5707963267948983 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark05(-0.1556215104897719,-1.5707963267948966,33.14856005687407 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark05(-0.15591203671635867,-161.55510164128617,-21.385909673792554 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark05(-0.1559858465819417,-97.91401140082532,-98.28285972705957 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark05(-0.15703114936752227,-185.83046755173572,-27.947560469906715 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark05(-0.1572693401671863,-72.43919659507662,-53.118968925442275 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark05(-0.15763143068552798,-0.393102760315579,-9.536955977260448 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark05(-0.1577724537317834,-3.1415926536096084,10.993806529387541 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark05(-0.15781636611897532,-98.83995145903198,66.084067579979 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark05(-0.1578660699507172,-9.976025843602883,-16.014265123004307 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark05(-0.15865672020934782,0.11266265309445513,-123.81153589160624 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark05(-0.1587833201460267,-0.7163362476843828,-97.68578753381756 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark05(-0.15884963444923947,-0.7487026369862414,4.621708893902692 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark05(-0.15953970380426563,-0.8576737978305169,-58.317907438095105 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark05(0.15970500968122017,-0.565559742949086,56.44165518446968 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark05(-0.16001757949289583,-0.8825870881904357,88.29714035592485 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark05(-0.1611537495883224,-3.1446112785652254,2.1382117680737565E-50 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark05(-0.16277789365178058,-9.996660016495477,1.5707963267948966 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark05(-0.16290571667813403,-3.1481204785063666,-45.29198816962976 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark05(-0.16299297874638663,-98.81080208193038,1.5707963267948968 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark05(-0.1633296240310796,-0.20898616004017678,0.2029099329910943 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark05(-0.1633689598642712,-36.109173331814596,-11.004553813361547 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark05(-0.163538941151935,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark05(-0.16423758168642222,-0.7142878115953916,66.9573097840879 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark05(-0.16429671315803226,-1.5707963267948966,75.54970242927055 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark05(-0.1644092778399542,-168.10655101581435,-56.690862108962925 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark05(-0.16450919658021249,-738.6959490285033,-141.3010417581507 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark05(-0.16467314891456195,-1.5707963267948954,7.709885485746211 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark05(-0.16481684805047747,-22.352133638272328,73.80615399661833 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark05(-0.1648415656038053,-98.87416678350361,1.1589375833044744 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark05(-0.16531555643314078,0.09644686316821438,1.0842021724855044E-19 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark05(-0.16653694509730732,-34.560259994023255,-2317.236071419364 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark05(-0.16688361876698649,-66.731731464031,-5.0262355229654645 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark05(-0.16779069538255892,-3.1415926542864914,-0.05413557279356833 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark05(-0.16839501463192852,-1.5707963267948963,66.85437381974694 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark05(-0.16879480644421924,-34.883295835895616,-83.25272120809421 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark05(-0.16902423622797214,-53.635418803325415,-27.157371702233604 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark05(-0.16976036687935236,-1.5707963267948966,83.1406038908552 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark05(-0.170172744697256,-1.5707963267948966,-7.9361780994789575 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark05(-0.17020819574629936,3.1494051536341883,10.571642915796172 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark05(-0.1702101429742413,-2.710505431213761E-20,-53.43796175510269 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark05(-0.17036610378560457,-1.5168275948478955,-57.974704875091646 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark05(-0.17068797351677384,-1.5707963267948957,1.5707963267948966 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark05(-0.1715743806133353,-78.94984478757912,50.92737446379851 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark05(-0.171770594591653,-35.42935700702286,69.94058715632704 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark05(-0.17229140859105974,-1.3892037831848025,6.28426332008178 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark05(-0.1724761558339396,-61.172751290943324,-1.5707963267948966 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark05(-0.172556507318129,-0.5332186393725227,55.472716502890734 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark05(-0.1725972819633895,-9.48727796080623,19.677720678001254 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark05(-0.17262299018837818,-1.5149399538381463,2.4333972048578046E-209 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark05(-0.17305906258320833,-1.5703810840322892,98.5245800950772 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark05(-0.17346468784365743,-1.5707963267948966,-34.95800026964817 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark05(-0.17415345430120155,-9.647497182107314,2.5997146286254207 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark05(-0.17425284199925506,-0.5605790754205372,-16.409021169298363 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark05(-0.1745329251994261,-1.5707963267948966,97.16106458282027 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark05(-0.1746828362384698,-2.926047721682624E-98,-32.0097511544361 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark05(-0.17531010430861815,-1.5707963267948966,13.04303140070154 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark05(-0.17609502282961134,3.1416231975792397,34.91452229510763 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark05(-0.17669255858336702,4.141592856673434,71.3912245663031 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark05(-0.17677653473546034,-98.90886095642846,78.29438071618688 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark05(-0.17748489634434353,-1.5707963267948966,25.279368197643052 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark05(-0.1777681658450972,-16.183937944327084,-1.5707963267948966 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark05(-0.17868934100511993,-3.8142901606302786,-0.038118685740740565 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark05(-0.17916919514739,-28.363329104224952,-49.53904300146031 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark05(-0.17919714366650474,-1.5707963267948966,51.19938982767679 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark05(-0.17924385135333198,-3.1435458651407573,22.019862067848138 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark05(-0.17926662912824798,-78.85752730253805,-61.48141934147753 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark05(-0.17989965592200677,-69.30608856951184,-1.5707963267948966 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark05(-0.18008972576350674,-1.5707963267948966,-7.130795290182206E-16 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark05(-0.18048861926333204,-0.5361194245882819,2.2541451703578456E-131 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark05(-0.18147827400103544,-154.60769301979695,-98.39758639514667 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark05(-0.1817058945762896,-0.11210471586239912,55.51769552565551 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark05(-0.182110024703502,-4.3368086899420177E-19,1.5707963267949054 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark05(-0.18279365373136808,-1.5707963267948966,-0.2583898573270802 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark05(-0.18279575269497075,-0.6369570084944143,18.84955711744526 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark05(-0.18289073026418468,-9.5314578177014,-49.10226028341806 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark05(-0.18335065179634577,-1.5204876073713194,98.58996225109064 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark05(-0.1837683321177179,-0.5856827731634553,-84.43149153058758 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark05(-0.18405373699607638,-1.5697817132590388,0.0 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark05(-0.18546035662469695,-0.5248542825871336,-52.64999025147697 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark05(-0.1855721721455651,-35.043547031766565,-1.5707963267948966 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark05(-0.18623969620418182,-35.5147393622236,-1.5707963268002865 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark05(-0.18647973121773664,-1.5707963267948966,-79.81473573897948 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark05(-0.18761349782152453,-0.5700200376131611,1.5707963267948983 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark05(-0.18804102149569435,-1.5707963267948966,0.32213225555073677 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark05(-0.18810371308284246,-1.5707963267948912,4.712388980384691 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark05(-0.18813823738336255,-3.1435457789468493,70.53347597397064 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark05(-0.18844435161036643,-1.5707963267948966,-25.430802131207344 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark05(-0.18867679278017935,-1.5707963267948966,-37.04328212497626 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark05(-0.1888182565249596,-1.5707963267948963,0.0 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark05(-0.18915995562834542,-1.194603794079342,1.5707963267948966 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark05(-0.1894007515927241,-1.5707963267948415,3.141592695338007 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark05(-0.18988813773999866,-1.3341285583716533,51.08505049842247 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark05(-0.19017999553264675,-1.5707963267948966,-0.18253691799130278 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark05(-0.1902102312112257,-3.1415929080706837,-21.74119251522335 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark05(-0.19085507890682973,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark05(-0.19167322581255405,-1.5707963267882796,4.021336066228002 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark05(-0.1920209192822131,-1.5707963267948966,-1.5707963267948963 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark05(-0.19264443025449218,-1.5707963267948912,69.84047011649551 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark05(-0.1927777138498418,-60.790216960217485,69.85044154894143 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark05(-0.19322033030119934,1.5777218104420236E-30,62.639249485497146 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark05(-0.19397384331829134,-0.1923235654715154,2.220446049250313E-16 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark05(0.19425760400136605,-1.9062797060340197E-4,-229.34903084105028 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark05(-0.19430258247237672,-0.4385272875906463,-80.37799126104477 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark05(-0.19470684946310804,-0.2824742340864391,68.29012658698198 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark05(-0.19490700758366852,-1.5707963267948966,-33.189478911115614 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark05(-0.19626526389989837,-0.26699161096294866,66.12171091362029 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark05(-0.19659610844527875,-0.5484427040890397,-900.8924488241569 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark05(-0.19667489225816404,-0.3641031431035534,-1.311111013053772 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark05(-0.19713674146883578,-1.5707963267948966,1.5707963267948968 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark05(-0.19731554239247906,-1.5707963260872397,78.26077338494045 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark05(-0.19781113599057062,-42.14981162729788,67.88221526264255 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark05(-0.19844231172339807,-1.5707963267948966,-0.9463813811914861 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark05(-0.1998732967871571,-0.1274270755770066,-49.863309179984924 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark05(-0.19991583904045562,-0.9741529493599671,-1.5707963267948966 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark05(-0.20097007373567732,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark05(-0.20122780973221643,-3.913641802376013,1.5707963267948983 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark05(-0.20124945767340885,1.3877787807814457E-17,-50.11193087939417 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark05(-0.20134605419256307,0.6221848586701,-83.80056320091333 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark05(-0.2014558440785064,-0.5704716990539064,63.891931784397144 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark05(-0.20179488773313514,-66.83406213993412,-77.04467236074083 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark05(-0.20180155438649194,-92.48942534347655,0 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark05(-0.20187716668940311,-1.5707963267948966,-73.1741745560131 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark05(-0.20261354827606226,-1.5707963267948966,-91.54447796081033 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark05(-0.20333200926247558,-78.70623959909314,-88.80696746299881 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark05(0.2034343884770128,-1.5707938225435054,-84.25533125576273 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark05(-0.20392537935552477,-72.94412575761183,-100.0 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark05(-0.20482821949619956,-0.5626472871668173,88.69804347460354 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark05(-0.20535369574026013,-155.15887170563053,66.13079810411871 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark05(-0.20539728831168702,-41.47916143028635,-7.220260144757987 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark05(-0.20682009498281928,-1.5707963267948966,83.0114265987109 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark05(-0.20688726914897837,-0.2966178444968381,44.317949338079785 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark05(-0.20721880808117532,-0.003383674896463422,-72.87750559132941 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark05(-0.2072998146091829,0.18187183148461317,-38.944121565956664 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark05(-0.20730609785790732,-34.670164552688064,-21.80413907365883 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark05(-0.20764094641350977,-1.5707963267948966,22.01131522454278 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark05(-0.20787971527829124,-28.34124214001927,-45.08988240497169 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark05(-0.208037788613051,-1.5707964255111069,116.03619479937035 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark05(-0.20865002715588096,-1.5707963267948966,96.2100957995219 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark05(-0.20940654703141792,-1.5707963267948952,182.50891878156483 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark05(-0.20946673498410096,-72.38556028048731,-807.348112842282 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark05(-0.2099500325942673,-0.06615351794031454,50.06561733604133 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark05(-0.21040660944513465,-1.5707963267948961,-14.510854402751868 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark05(-0.21100292830001877,-927.7490042994333,-85.1624778034051 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark05(-0.21109340643092933,-1.570796326670193,97.55435202684625 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark05(-0.2114750184049838,-9.646518960494873,-95.63045670925317 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark05(-0.21175296649033537,-1.0842021724855044E-19,-3.9183848177130025E-4 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark05(-0.2125944276713121,-0.6301193336833659,107.74070344568625 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark05(-0.2126803208009652,-5.635362925894614E-132,72.15918738045646 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark05(-0.21281121438240583,-72.42815772487279,-39.0057533357643 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark05(-0.21292765610414413,-0.17279830312950684,20.522971054652686 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark05(-0.213362459181063,-41.514773927789754,6.287096952789562 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark05(-0.2134487870543509,-1.5707963267948983,21.688452588988355 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark05(-0.21362425726108825,-42.40814772565497,81.13562562654626 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark05(-0.2153066903342169,-1.5707963267948966,4.2270284318524585 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark05(-0.21548632792081435,-0.29183123154193297,0.025977667298502937 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark05(-0.21565201157241687,-0.026302480116195234,42.14019060719022 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark05(-0.21632629453789018,-22.391025328765437,91.82085665403159 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark05(-0.21725529870567328,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark05(-0.21808158599914443,-0.06058153592411186,79.11053304495056 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark05(-0.2181052852420621,-1.5536713516274419,7.8539816339851445 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark05(-0.218177207319263,-0.2651224210157147,1.5707963267948912 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark05(-0.21882762169140257,-1.4709204220096346,44.11780294187591 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark05(-0.2191932575142752,-185.86784280353064,58.25570132253402 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark05(-0.21928078242872262,-129.6764677479627,9.515752467571048 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark05(-0.21935572943964088,-1.5707963267948966,-55.1718113045091 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark05(-0.2197869326809514,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark05(-0.2198902151598313,-1.4037843077494552,45.39505589452594 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark05(-0.22008989842203563,-97.65299533666338,-26.40297576600338 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark05(-0.22060769086570478,-35.7310445575945,1.5707963267948966 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark05(-0.22245523020615754,-3.858630587685102,77.46226795715482 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark05(-0.22262207516089771,-36.07005994928011,-2.5043909307497056 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark05(-0.2232501779996714,-1.570796326794895,-32.81959246810095 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark05(-0.2241073734488672,-1.5703758340256777,55.68595780720247 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark05(-0.2243630196497861,-53.50778575590891,51.56608806755997 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark05(-0.22437710621901769,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark05(-0.22473318275413323,-0.5637753041423755,-5.721276863605348 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark05(-0.22474337156751945,-1.4446411187556794,26.98988935351941 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark05(-0.2248135273902185,-36.05662543728535,22.047788640906575 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark05(-0.22542993389680882,-1.1449932206146372,91.08719118179735 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark05(-0.22546178972896788,-1.1699654160831536,33.36905058364434 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark05(-0.22655234797103305,-1.5707963267948983,-68.46057427986963 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark05(-0.22722662686445866,-1.5707963267948948,91.106186954104 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark05(-0.2274547580088202,-66.79201917183985,-35.97789323591325 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark05(-0.22815245645230087,-0.6128418326942169,57.56031065828979 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark05(-0.22880459992595092,-0.6602543452387748,-21.976887330678082 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark05(-0.22940734399670204,-1.5707963267948963,-18.93982092473981 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark05(-0.22947584685240052,-135.60936534823685,-3.1572391952212304 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark05(-0.22970698302815118,-98.7184025423204,38.044142943560395 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark05(-0.23060936711995325,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark05(-0.23082237900389813,9.674926952989779,-15.35559536848961 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark05(-0.2310323265552845,-1.4489964065187189,3.178354865246174 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark05(-0.23168998394298268,-98.24486337459449,-28.044295621934843 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark05(-0.2324681969492533,-66.30149669862251,-30.078570402072287 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark05(-0.23363449329976604,3.2311742677852644E-27,-57.07629577060543 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark05(-0.23383924293460956,-1.5707963267948966,25.196739225890603 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark05(-0.2338558136594802,-1.5707963267948983,-91.00398688362705 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark05(-0.23388468762055617,-42.03153844901789,-47.48550746978458 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark05(-0.23601223362902846,-1.5707963267948963,-0.08861576732486785 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark05(-0.23636305810065394,-0.22414428474334103,-47.3865545969453 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark05(-0.23674763245171704,-78.94372819860365,22.39471603850987 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark05(-0.236803166838655,-129.72792060486782,-32.973745145924255 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark05(-0.23695049563222453,-97.69979338849005,-91.01487371081069 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark05(-0.23740823666207334,-1.5707963267948966,51.480639949680864 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark05(-0.23775800708994774,-1.5707962604331478,25.716762926090666 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark05(-0.23815721641812213,-34.557548723757094,0.0 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark05(-0.24066636788033746,-0.21289588161693773,13.362898530719065 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark05(-0.24257027452927105,-47.540731439594374,3.778092486513657 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark05(-0.24270018561211515,-97.64373577394765,-63.700132672441676 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark05(-0.24284797435595512,-0.10483050946544586,-66.02903400718817 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark05(-0.2428872541488185,-0.19492967169177597,-42.821641234332105 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark05(-0.24302820982932938,-47.491620646815655,-77.2104758509111 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark05(-0.24306610966630193,-3.1416015292401496,59.97479744137358 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark05(-0.2432384700544563,-3.141592696303008,-1.5707963267948966 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark05(-0.2437558805403876,-61.1897476080076,-8.1039816872751 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark05(-0.24381856483016487,-1.5707963267948957,-50.0965857523465 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark05(-0.2441270325669632,-1.5707963225650692,98.09303945313027 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark05(-0.24473274377783993,-1.5707963267948966,73.52070104268124 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark05(-0.24606061852074257,-1.340737177554228,-61.079161991312006 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark05(-0.24706883207428254,-1.5707963267948966,-38.85028539210621 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark05(-0.24712852053977752,-1.5707963267948948,-92.31206461429903 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark05(-0.2475522975887876,-0.7116749043786399,35.71908934251982 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark05(-0.2478259699119978,-0.4303805357386544,70.25523815609336 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark05(-0.2479420545571948,-66.50206494728104,1.5707963267948966 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark05(-0.24812182974699204,-1.5707963267948983,-17.539114975405234 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark05(-0.24855878551797622,-3.5893342531064767,6.283185307509047 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark05(-0.24863572772764986,-1.5707963267948966,-85.3816570987023 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark05(-0.2487856701852815,-98.34768752236162,-95.8755050630684 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark05(-0.2490506367932508,-0.09422027211266804,-0.8152779898600759 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark05(-0.24927361231685513,-1.567620447551782,174.3636493956036 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark05(-0.24947467583275973,-0.028489414004929877,-97.17119818549666 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark05(-0.2503449223076899,-54.97920545374508,-12.768258986779099 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark05(-0.25035389184496787,-3.1465430397363425,-1.5707963267948966 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark05(-0.2506900208087131,-9.614852932744952,-4.712399041525245 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark05(-0.2512668269630418,-1.5707963267948966,-40.923992963737874 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark05(-0.2513099954731701,4.141592654719116,-117.56074034366897 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark05(-0.25209862797361693,-0.5355361245232123,47.69579215870476 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark05(-0.2529910888637801,-1.4380759471559414,37.46378747936089 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark05(-0.2543711478603679,-1.5707963267948966,97.6063954710463 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark05(-0.25460569826142465,-1.5707963267948912,32.680649709082644 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark05(-0.2552381109006797,-1.2546059468678439,48.64658930160701 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark05(-0.2554433944713167,-3.8180467640744475,77.30642235362141 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark05(-0.2555357827554793,-66.8817957193996,16.06898726571491 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark05(-0.2560147955664063,-0.20582983979597747,1.5707963267948983 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark05(-0.25649657618379623,-22.363435521393342,-15.710400118543689 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark05(-0.2571782566767837,-1.5707963267948966,-1.5707964480889747 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark05(-0.2572987717929771,-0.33578318031211707,118.06520636149972 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark05(-0.25741877234162913,-9.6489719046454,-0.1780461531306986 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark05(-0.2574596341779578,-98.47461569422344,55.54211536551206 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark05(0.25754749317126124,-1.3744030527197821,-73.9577021576875 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark05(-0.2583703575989473,-0.4619289577546458,-12.568333938827685 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark05(-0.2584578879288657,-0.19282995940020253,70.57603039688516 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark05(-0.25872659064730047,-0.6755776357341565,39.24066705668446 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark05(-0.25873152304133706,-0.5701284565155961,-90.80024909582072 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark05(-0.2590813091076805,-28.27434151220688,-100.0 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark05(-0.2590959673741494,-15.953265595364616,80.39608372701574 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark05(-0.25912454054538925,28.704052229008234,-1.5707963267948968 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark05(-0.2592035730075253,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark05(-0.259424571769411,-41.065844733393185,75.77730495509944 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark05(-0.259616769892704,-1.5707963267948966,1.570796294345475 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark05(-0.2597542818026573,-4.101630197672794,56.533029772052615 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark05(-0.26001339820844294,-0.29729674176756565,-52.3070341988334 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark05(-0.26034307738454127,-1.064255950918597,18.906909248102828 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark05(-0.26070891831616283,-475.90628640410193,-88.44430152214093 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark05(-0.26142393190679813,-1.5707963267948983,112.07957965654967 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark05(-0.26175470147303725,-9.64166575007511,-15.72359270015029 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark05(-0.26185269694396596,-0.6030578179710091,17.13942678015921 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark05(-0.2619222232020224,-0.4195531018905388,-14.157455965540926 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark05(-0.2619703725318645,-1.1110969598294107,75.72466265969072 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark05(-0.2621272054421411,-1.5707963267948966,-45.13365874737034 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark05(-0.2631750482561246,-0.9829930092535686,544.6590954405254 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark05(-0.2640592215064032,-97.84443829269698,3.1416536887809277 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark05(-0.26543676175165765,-1.4414603992061463,204.544928822166 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark05(-0.26572556907881734,3.1494051535897962,-31.629765755851764 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark05(-0.26806701645496667,-1.5707963267948966,-49.98910069247171 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark05(-0.26833293132662833,-1.3998971474229105,-1.5707963267948966 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark05(-0.26843884547558694,-0.4814429549851322,17.05017491205942 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark05(0.26850471637418794,9.160856005818533E-5,89.35148935081247 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark05(-0.2687555265546256,-35.85504606339,1.5707963267948968 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark05(-0.2689868413419659,-1.5707963267948966,31.618963712772022 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark05(-0.269095581292464,-48.28726868168434,-90.56764494652279 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark05(-0.26936195486531844,-41.92884607634886,-90.68485016636349 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark05(-0.27082127942551937,-1.0542197943230523E-81,-1.5707963267948912 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark05(-0.2708577302748899,-1.5707963267948966,79.47904245384683 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark05(-0.2713261334524931,-3.1415928963931514,23.037302886073963 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark05(-0.27133723201465165,-15.849487429162476,-9.618115870438942 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark05(-0.27205357001944436,-1.5707963267948948,-90.88630634123814 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark05(-0.27217580887850623,-79.0041788388655,66.37290494389278 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark05(-0.2729403983060859,-1.5707963267948963,-12.164064476286757 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark05(-0.273281403120023,-160.72184702077834,88.0537272452017 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark05(-0.27336228578038385,-72.97649426319283,55.77895871911227 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark05(-0.2739646406820012,-0.38910882983083817,41.717372342092695 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark05(-0.27441608832529873,-1.5677441866296704,-44.94500656362325 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark05(-0.2748155158295825,-0.4693229864759058,3.1437177660723297 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark05(-0.2751608133099546,-66.04906327499867,-1.5707963267948983 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark05(-0.2755464894220888,14.692961018888411,-100.0 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark05(-0.2761073055247054,-1.2615682600721068,-3.1502712075528656 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark05(-0.2764613165414123,-1.5707963267948966,14.034507149133892 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark05(-0.27662295675438686,-1.0718904740493942,-76.42529484401048 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark05(-0.2769519694272633,-1.5707963267948966,-8.103982365205423 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark05(-0.2777618143232171,-66.3718072715882,-70.9490065162737 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark05(-0.27887199226521514,-35.13901520219537,-18.93259917293531 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark05(-0.2791534667711327,-66.0364932785879,-21.494389921216083 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark05(-0.27993118077391443,-1.5707963267948966,3.3477902381541895 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark05(-0.27994609149714017,-100.0,1.5267664642689232 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark05(-0.27997249780279687,-66.68899330611072,10.546666268591526 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark05(-0.28100323503721736,-15.840090363934342,126.30294126880057 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark05(-0.2812535240702216,-66.06378101352944,79.71454313267944 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark05(-0.28321937608717995,-1.5707963267948966,-4.401598927259156 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark05(-0.2832199922950167,-0.8424059915428046,44.975738114226004 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark05(-0.28329185738043544,-1.5707963267948966,-7.967268954731232 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark05(-0.2836001154524236,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark05(-0.28401068429726173,-1.5707963267948966,-64.43339187603407 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark05(-0.28413213573743656,-78.7276449833318,100.0 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark05(-0.2844894436575416,-1.4210854715202004E-14,-26.892780127403526 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark05(-0.2848457119085923,-15.77896083447095,-1.5707963267948983 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark05(-0.2869301352221354,-1.5278972210861754,-6.284161882259237 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark05(-0.28723369867868453,-1.5707963267948966,1.5707963273955665 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark05(-0.28780191768817875,1.2003054236048423E-17,1.5707963267948966 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark05(0.2886935652610404,-0.3640629184714114,-56.455754914215845 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark05(-0.28894548483179316,-35.8563153557067,51.898833457021354 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark05(-0.28967433038528567,-3.469446951953614E-18,-95.15503455658359 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark05(-0.2900196656730083,-3.6933254800513424,56.79344787709941 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark05(-0.29026113110252494,-116.23999062330437,-109.19919112170786 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark05(-0.2905334496655785,-35.12626533825957,-1.3124053077367819 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark05(-0.2908905355525531,-1.5707963267948966,-64.92031737874221 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark05(-0.291634660867066,-42.109181825511,-549.9781225663523 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark05(-0.29218099454006596,0.22858533702273234,-15.747623338965083 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark05(-0.2922520106476878,-1.570796326793505,-1.570796326794895 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark05(-0.2936628293058653,-0.3354179722437154,0.0 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark05(-0.2941040284874983,-0.27309473515489296,54.05380567881821 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark05(-0.2950904455974704,-28.355752371124467,90.05360230949688 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark05(-0.29523146866227024,-10.40428594594249,116.61612189110119 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark05(-0.2958261926391259,-1.5707963267948966,-69.61372482706932 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark05(-0.29624052121083866,-3.1435457787485594,30.279642852935016 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark05(-0.29680464548583446,-0.4087678125672537,-84.22778338400818 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark05(-0.2976549967019394,-9.938782829967266,-1.046205839315218 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark05(-0.29852655799517025,-0.09845693553002532,66.42739742401078 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark05(-0.300934451570823,-3.944304526105059E-31,-40.36722692951547 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark05(-0.3014756338566621,-1.438252510808475,-1.5707963267948963 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark05(-0.30149366649674303,-1.329415385932156,1.5707963267954526 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark05(-0.30183251173243036,-1.1720075865104962,-76.52063565339326 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark05(-0.30191988731981234,-7.105427357601002E-15,-55.203778175244956 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark05(-0.30199066785946244,-0.10491783180081848,-34.79334890873247 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark05(-0.3026308286140134,4.141592653591927,-0.10858803265786943 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark05(-0.3027775417736782,-60.80527541956308,849.8364902697098 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark05(-0.3028071590415866,-1.5707963267948966,56.03797417545302 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark05(-0.3034278002437051,-1.5707963267948966,8.115331497615328 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark05(-0.30364306131716073,-48.14199739718548,-30.36742555316154 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark05(-0.3036524480613709,-0.11872620226364569,88.5084436772208 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark05(-0.3036789461894722,-22.009099681517963,1.5707963267948966 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark05(-0.30568497475412426,-41.0304608181519,-90.79891856269923 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark05(-0.3064016817356954,-1.5707963267948966,-12.933427592332691 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark05(0.30687843143342197,-1.544141147290731,-48.09178385446969 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark05(-0.30709303558851225,-22.395063449233138,20.599216709959528 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark05(-0.3073839825338946,-1.5707963267948966,47.463942584947354 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark05(-0.3074852460878302,-97.65085480556215,-20.99337668395026 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark05(-0.3078707094340754,-1.5707963267948966,47.93184211499018 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark05(-0.3079905144872327,-1.5707963267948966,-78.12140223856318 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark05(-0.3081587658632676,-908.1254129193387,-20.37565778235041 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark05(-0.3093136712802564,-0.023029189328873052,-92.19998393879547 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark05(-0.30954879122261425,-1.5707963267948966,53.47558407281592 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark05(-0.31024306200286494,-174.22709720525918,-31.499228120262117 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark05(-0.3103927114984019,-9.640648170897439,-70.91239267581233 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark05(-0.31061562642723817,-1.5707963267948966,-41.267676994082436 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark05(0.3125961749393483,-3.43798296382143E-4,-19.752845907328265 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark05(-0.31266733855128,-1.5707963267948966,83.83786868726669 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark05(-0.3129636097606417,-1.5707963267948966,-61.00291362820184 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark05(-0.31337110071139707,-78.67510660852508,-7.3022782079229245 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark05(-0.3135728762275712,-0.45630160669292114,-75.80628237249644 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark05(-0.31390903874240905,-66.79813716660856,-1.4460775592087067 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark05(-0.31392438051987226,-78.92766443854731,3.104766447803235 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark05(-0.3139486100207475,-0.048593543166392014,16.013711802141188 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark05(-0.3140466767252068,-3.955543812502043,-99.15647570362196 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark05(-0.3150668919209299,-47.56864338409847,-55.51103661287258 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark05(-0.3157219081223963,-0.07836601887578498,-31.886864986233434 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark05(0.315729256721207,-1.5707963267948895,19.999639888536677 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark05(-0.3159139501738336,-0.24617338632405578,69.79373804571048 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark05(-0.3161283815645959,-1.447372007745514,67.01122633735005 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark05(-0.3163324866695675,-3.266592662264287,0.0 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark05(-0.31706124484677556,-1.5707963267948966,-16.45275905374662 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark05(-0.3171132298136896,-66.04648748623686,-21.796292828986964 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark05(-0.31742478615688585,-4.2351647362715017E-22,0.6539835383855974 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark05(-0.3177484100816015,-1.5707963267948948,54.9951836268085 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark05(-0.3177897086168429,-98.52042342056882,5.141668656203137 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark05(-0.31849330626234595,-1.2196552827063267,54.620510302829985 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark05(-0.3190381177464301,-1.5707963267948966,70.91505878618204 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark05(-0.31952870601771394,-60.96002618249086,378.4503281017938 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark05(-0.3219278734807248,-1.5707963267948966,0.9449235428799827 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark05(-0.322164485779858,-61.13506000724746,42.691932938564534 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark05(-0.32233160010661355,-1.5010205252529156,-20.268208545190735 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark05(-0.3230201328229576,-1.5707963267948966,14.12292542411764 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark05(-0.3244614598799853,-0.3525224043236126,0.0 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark05(-0.3260092037081822,-34.93528006958064,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark05(-0.3260173118427992,-1.5707963267948966,-44.06602604940409 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark05(-0.32610806142090537,-1.776675163639552E-15,-2.6501429003495057E-17 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark05(-0.3271544975303931,-34.6482338782361,5.141592655198452 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark05(-0.3276273162386172,-42.01799032941008,4.337407822689414 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark05(0.32802672068621097,-2.6469779601696886E-23,-92.30525702516367 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark05(-0.32804343176828676,-0.43263985814894923,-57.280221451120944 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark05(-0.3282835602165627,-0.5675004281710435,-1.5707963267948912 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark05(-0.32867916236435374,-22.004145295049682,-3.882639962730594E-16 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark05(-0.32940228860825027,-1.5067692832399762,60.58998656959301 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark05(-0.3328847769853835,-78.58405791029105,91.10619069920546 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark05(-0.3337505123841177,-0.07119932232261376,91.86913581936479 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark05(-0.334141469344991,-1.5707963267948966,26.412704207798086 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark05(-0.33427264096487974,-1.252738873275805,-0.4109517591763625 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark05(-0.3345539320989473,-72.99074161613952,-53.916982382484534 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark05(-0.3351907108191623,-3.5397044868831813,55.07047966074306 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark05(-0.33531087009180127,-47.57918717221481,67.54424205218055 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark05(-0.3359078564281193,-1.1797199362067592,-16.28987249978541 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark05(-0.33624782279302995,-1.2146662733585003,8.10398465311207 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark05(-0.33774883193280214,-1.1817006564185513,123.79325868357185 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark05(-0.33783338698670606,-54.43640901153965,-26.83995606329313 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark05(-0.338219216222164,-0.3634963958285846,46.85468285782451 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark05(-0.3382341649134082,-97.86215406649981,65.35588862439153 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark05(0.33838744335423854,-1.5684392168154508,1.5707963267948983 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark05(-0.33877795190517734,-1.5707963267948966,1.5707963607070234 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark05(-0.338820364379086,-36.11007069537252,142.0316329339907 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark05(-0.33888710137233935,-1.5707963267948966,-42.88288056016518 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark05(-0.3389818432873176,-0.03731319566231372,56.29690335247126 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark05(-0.3390705120223542,-3.1416002850281917,70.47481658381611 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark05(-0.3392831906050384,-1.5707963267948966,1.5707963267948968 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark05(-0.3396893852956206,-0.05777597505304248,9.550650817672388 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark05(-0.3400973545926296,-1.5707963267948966,-1.5707963267948983 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark05(-0.34126614179038095,-1.2847203741381283,98.40201153595495 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark05(-0.3413147654998198,-42.2756523037424,1.0585741359189287 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark05(-0.34142771048849074,-0.03736621431438608,3.14160028298446 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark05(-0.3416006492863046,-41.626987543636204,42.708607578530234 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark05(-0.34222386732877436,-1.180615211142786,46.02176618338852 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark05(-0.3422703283733255,-1.5707963268008833,-16.64016687047953 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark05(-0.34237917499388754,-122.55497875485432,-1.570801156623043 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark05(-0.34319676800475696,-1.5707963267949054,100.0 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark05(-0.34377200142528697,-0.9100980585682104,-8.726213041614468 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark05(-0.34416568990361956,-1.570796326794896,30.446947025572936 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark05(-0.34442583749522626,-0.07377195685333522,-0.14500634716948912 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark05(-0.34468903457682026,-0.04956130197313986,-6.844082988036353 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark05(-0.3447753383138519,-1.1193461826761393,-1.5707963267948983 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark05(-0.345063349839199,-0.10635180633557491,48.11035100073988 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark05(-0.34550480342674933,-1.5707963267948966,0.22175069366678457 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark05(0.3459149079669078,-1.5707963267948966,26.83044531872022 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark05(-0.3459757463698651,-1.5707963267948966,-79.39871588725302 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark05(-0.3462815047031541,-0.9528922112656217,-26.703734352300454 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark05(-0.34633126008858883,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark05(-0.3468579871820291,-1.5707963267948943,12.566370852778958 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark05(-0.3473486876027919,-1.5707963267948966,-78.24847689629439 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark05(-0.3483190939108185,-1.5707963267948948,-32.38838569231652 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark05(-0.34846325986919047,-9.775796363198735E-150,0.6680196235454259 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark05(-0.3489071875403056,-1.5707963260863826,-36.884192258842425 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark05(-0.3490578723747495,-53.58163150174515,-26.608381784127744 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark05(-0.34916367678720633,-1.5707963267948957,-1.5707963267948966 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark05(-0.34951385866000884,-61.227181150359584,74.00212679621451 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark05(-0.35015814463325734,-0.9213800232497734,61.26105674500097 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark05(-0.3504454723691378,-1.5707963267948966,-1.5707963045017652 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark05(-0.35097785867450026,-60.977794230543566,42.73353587021224 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark05(-0.35135469163711,-0.12774772698860593,-58.47163713039387 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark05(-0.3519482624250893,-1.5707963267948966,-6.2862577001173685 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark05(-0.3520711751816241,-1.5554138672735915,76.96902001294994 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark05(-0.35393215413398005,-1.1102230246251565E-16,-39.15676016874694 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark05(-0.35460320891356856,-0.4137557931131115,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark05(-0.3553846131235556,-1.5707963267948966,3.377299235383805 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark05(-0.3558368953709627,-35.325422168025426,69.5220238722066 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark05(-0.35588121919717597,-0.6470096120206341,22.48231955160513 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark05(-0.35591610332333445,-84.82546601397762,-29.137603623977483 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark05(-0.3576112083418328,-0.6358602168762358,-72.40865422369055 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark05(-0.35770433886250175,-3.143546852812503,12.362602644004951 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark05(-0.35777256790424944,-1.5707963267188876,-100.0 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark05(-0.3587564462623337,-1.5707963267948966,-44.25323810048055 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark05(-0.35948136201340697,-3.8534422207783656,-95.26705331623288 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark05(-0.3601752207415345,-3.2665926536506102,8.241907651016408 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark05(0.36197532422045675,-3.1435457796449398,49.707827242004555 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark05(-0.3620343073379322,-1.5707963267948966,-10.807724205322218 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark05(-0.3622362681528367,-1.5707963267948963,-6.283185308118202 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark05(-0.3625169723409846,-2.220446049250313E-16,49.31089982985134 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark05(-0.3635112195133425,-35.63870880138662,67.54178685935598 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark05(-0.3638369815262532,-66.33801840633988,169.42479747028068 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark05(-0.364220582141507,-48.41304781268668,42.839970879052146 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark05(-0.364249190637026,-84.94649487161352,-28.10397835882665 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark05(-0.3660264304231191,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark05(-0.36623637952195837,-1.304971346547658,-66.43319754444687 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark05(-0.36702295650705913,-1.5707963267948966,-99.73709909675996 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark05(-0.36749774357465115,-1.415894442777379,94.8326765671975 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark05(-0.3684965701950379,-0.005663791763968149,-24.588204653536387 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark05(-0.369360305906865,-0.6605944358882082,1.5707963267949019 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark05(-0.369397191261452,-543.6724554097364,84.42983700808388 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark05(-0.36954040451190734,-97.78502095711022,28.38558574339288 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark05(-0.36957565859204067,-4.3368086899420177E-19,1.5707963267948966 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark05(-0.3705461561920986,0.45687071814889124,-52.46975960224982 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark05(-0.37085804036016334,-1.5707963267948966,-39.95456221986603 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark05(-0.37155075834542706,-1.5707963267948966,-7.2591051091771135 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark05(-0.37245345079870285,-0.2560906449128383,-42.8745716323697 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark05(-0.3749907014558958,-1.5707963267948966,-84.40543402234363 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark05(0.3750701078483164,-0.14640668798684398,16.05685726770585 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark05(-0.3753877681884363,-78.74939563289264,43.149044245278446 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark05(-0.377235928993708,-1.5707963267948966,-50.25347168160582 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark05(-0.37729283580106043,-0.26070175516418237,-112.5686017410843 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark05(-0.3788372181092259,-66.05204773829979,-95.64389681181436 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark05(-0.3788433875252464,-1.5707963267948966,-1.5707963267948983 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark05(-0.3793273598630328,-1.5707963267948966,50.52818513102889 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark05(-0.3793446490029381,-98.43953455304082,-3.1765041635913858 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark05(-0.37953327161953754,-1.5707963267948966,-57.23719155223279 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark05(-0.37983833849564913,-1.5131475565019719,-21.815970315699374 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark05(-0.3810051172427511,-4.440892098500626E-16,-0.013651161824043384 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark05(-0.3828261635223803,-1.0910929312977227,138.72355678778442 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark05(-0.3835941679108083,-1.5707963265623446,18.994410600664807 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark05(-0.38569257270720736,-53.58155052851886,-26.793160066314975 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark05(-0.386129968214755,-1.5707963267948966,54.734694402471014 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark05(-0.38729253814042164,-0.5606203232064978,18.858226703345228 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark05(-0.387800979753467,-0.40113118957709465,-4.057711132928638 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark05(-0.3896668841162893,-1.5707963267948966,-9.181449430460983 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark05(-0.3905054599052922,-1.5707963267948966,1.5707963267948968 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark05(-0.3907888704286679,-0.7053816982971605,-10.902666807893102 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark05(-0.3911893608632717,-9.635537553319118,-43.46352125728573 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark05(-0.39225904730696204,-1.5707963267949008,1.5707963267948966 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark05(-0.39347380060651793,-1.5707963267948963,-32.07203995452457 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark05(-0.3936617176156148,-1.5707963267948948,-76.62413783808331 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark05(-0.3937876960385741,-1.5707963267948966,-26.19117008886338 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark05(-0.39415625024182055,-0.3263067497393774,1.9360552541979423 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark05(-0.3942800900183482,-1.434182035442345,22.300890959077492 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark05(-0.3946411982684132,-1.5707963267948966,-5.141593464795485 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark05(-0.3948272297196752,-34.949175765800106,-92.422148765461 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark05(-0.39530792292406947,-413.11913974146916,55.98197133693966 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark05(-0.395332177105826,-41.468469690947174,92.6769832808989 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark05(-0.39559060912399235,-1.5707963267948966,1.5707963267416019 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark05(-0.39607258676733725,-41.679109886967595,50.187257291374806 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark05(-0.3965555763752864,-3.537500827402571,10.995574287564276 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark05(-0.39804479386077285,-9.860761315262648E-32,13.002310987090278 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark05(-0.3991402822731893,-97.69898704789586,-180.27390086142765 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark05(-0.4000556167569145,-66.47093139499657,-107.71267034750369 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark05(-0.40114172364177725,-1.5707963267948966,14.941269644860288 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark05(-0.40202394834110605,-0.20384946405982063,4.282409643160534 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark05(-0.4038231903776808,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark05(-0.4039832998751771,-66.46208840163683,-57.66587262009077 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark05(-0.40415864202410307,-61.07738596706274,56.92912091990118 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark05(-0.4048301917257122,-5.421010862427522E-20,1.5707963267948966 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark05(-0.4051851580059475,-1.3530591861137466,0.0 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark05(-0.40524167226993213,-1.5707963267948966,6.287091557295134 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark05(-0.40579145010532613,-1.5707963267948948,-4.24244012611274 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark05(-0.4068612260932293,-1.5509830842429453,-23.49416287248009 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark05(-0.40740616987365325,-1.5707963267948983,83.33835183753186 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark05(-0.4075035190236368,-1.5707963267948983,59.401156467336975 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark05(-0.4075147697144921,-0.04004645019299906,-17.268654275385558 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark05(-0.4077685563065878,-141.86981568696046,42.71253556563603 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark05(-0.4086350540833088,-42.23038234369092,83.13646386279228 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark05(-0.40870332684049515,-3.7456865980474845,1.5707963267948983 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark05(-0.41299913209547773,-98.17298896481792,6.28318893449204 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark05(0.41304813581807787,-0.8954539247762119,79.85050304629763 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark05(-0.41379465840236307,-61.22348407375112,-1.5707963267948912 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark05(-0.4138975496043292,-42.21259980754286,-62.82222168981686 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark05(-0.41457499045856583,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark05(-0.4148154238678483,-42.179793906246,-66.52368526471348 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark05(-0.41499494378445756,-36.11022444469628,26.878186910561887 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark05(-0.4150681338618095,-47.548975227108656,-42.4565991191147 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark05(-0.41511727210357746,-41.860600968286505,1.5707963267948966 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark05(-0.41516515349660477,-801.2714730682518,82.86922577874955 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark05(-0.4152452035736861,-0.36618398857999973,3.141804483799834 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark05(-0.41556195007030816,2.429285313729213,34.85656123010269 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark05(-0.41645249769429493,-0.2366035611052106,35.67159865508967 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark05(-0.4170917413747094,-0.5224666070625503,-26.771892554198878 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark05(-0.4171998919944048,-1.5707963267948961,-20.4460557618749 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark05(-0.4174230549620826,-0.06545665395832397,56.25175459388208 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark05(-0.4179654743949752,-1.5707963267948966,88.76898705398712 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark05(-0.4182542992238728,-53.48538539867226,32.16357418246077 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark05(-0.4184882866732522,-1.5707963267948948,50.495005738383064 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark05(-0.41881713337547083,-1.5707963267948966,-8.126961136321725 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark05(-0.4193433332083088,-0.958562184596884,91.11175050048399 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark05(-0.41993621453666363,-78.59217483848767,-42.21265380890227 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark05(0.4201648124672589,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark05(-0.42041830911830574,-66.46252064756054,0.5855542492763776 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark05(-0.42111703489017754,-0.06355814824358844,33.36783287591426 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark05(-0.42131724682445226,-1.5707963267948966,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark05(-0.42145534266975293,-3.3672182793990686,-1.5707963267948983 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark05(-0.4214876281165907,-66.45543766958994,33.038401283950634 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark05(-0.42252857103805186,-0.8454415732087687,0.19849349935877747 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark05(-0.42349278873049967,-0.48073409213658574,-1.5707963267949694 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark05(-0.42352930448765796,-1.5707963267948966,78.34323721854588 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark05(-0.4244852465161668,-1.5707963267948966,-1.5707963267948983 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark05(-0.4245210815586307,-1.5707963267948966,-65.15702053505494 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark05(-0.4250522573849268,-9.487277960895879,-3.17205661890163 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark05(-0.4252196747373791,-1.5707963267948966,13.021627241055898 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark05(-0.4254546086834412,-1.5707963256102158,48.396144101626625 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark05(-0.4260812203219464,-0.40498677615757295,-329.7770528848043 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark05(-0.4262107174909131,-1.5707963267948966,-44.4235569439003 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark05(-0.42696233760868324,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark05(-0.42707316445189075,-66.0529230857895,-51.767806966455595 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark05(-0.42800808976045446,-3.1445263735675213,-100.0 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark05(-0.4290279069173413,-129.51813622833737,-84.76765347225282 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark05(-0.42925335297348344,-60.89693107742599,0.0 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark05(-0.4296474279271994,-1.5707963267948966,6.15350163087682 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark05(-0.4298126262211426,-1.5707963267908651,-29.614021638061594 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark05(-0.43077473007675776,-1.5707963267948966,95.9871842002036 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark05(-0.43129348914696264,-1.5707963267948966,-57.830876326830705 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark05(-0.4315838662473517,-6.776263578034403E-21,-29.734433662355595 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark05(-0.43199211136182025,-73.25576954944745,4.712393420291401 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark05(-0.4321665385382416,-10.155759596463355,-8.077935669463161E-28 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark05(-0.432771880051511,-192.29211392424813,-73.48303235286372 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark05(-0.4330801146089096,-1.5707963267948966,76.35570649758014 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark05(-0.4332738786823782,-66.96335229040274,-403.2868857190007 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark05(-0.4334504879591137,-10.193060138682469,-152.37658375580406 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark05(-0.4335846847119367,-0.40555937173247586,0.15814192052226816 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark05(-0.4343103215336519,-1.5707963267948983,32.744038948340325 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark05(-0.4343380818959321,-35.84405283075399,54.994908135398404 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark05(-0.43481727505913037,-59.693761583167415,1.5707963267948966 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark05(-0.43497654097888444,-1.5707963267948963,-55.25654725973561 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark05(-0.43530096080189085,-1.5707963267948983,-84.51695265094936 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark05(-0.435535858762929,-61.15587435200654,-78.53739137935872 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark05(-0.4363111521039167,-1.0809383811333668,36.56629669355169 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark05(-0.4364744959087432,-98.55713537007637,67.28439134335173 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark05(-0.4366781622651709,-35.82584421066709,-355.97740279222165 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark05(-0.4368911681327389,-0.3532242837092118,6.287157900773204 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark05(-0.4374306498570734,-66.95166888449566,-33.644142440731684 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark05(-0.4380153396670342,-1.5707963267948963,35.07946850000077 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark05(-0.4390186712167684,-1.5707963267948966,-26.832721528973195 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark05(-0.43904721211067593,-1.560382017248363,16.215011290780154 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark05(-0.44018696773523047,-35.97622666278452,0.0 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark05(-0.4413150815731811,-1.5707963267948912,-51.19315651069872 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark05(-0.4421843857346957,-78.91204738811406,-12.59801098708603 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark05(-0.44234330980236103,-41.940353434204354,12.571423350068018 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark05(-0.4425617110259634,-1.5707963267948966,-84.62182995122245 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark05(-0.4427621164234224,-1.5707963256113373,1.5707963267948983 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark05(-0.44389700539110816,-15.790638426956818,-70.44723005868798 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark05(-0.4443031230351313,-98.93001265546407,-28.781530802393053 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark05(-0.44432788587594063,-1.0253147044398319,89.28526815685811 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark05(-0.44473830443183093,-1.5707963267948966,-11.042396602373032 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark05(-0.4456996080695789,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark05(-0.4462822226638793,-0.051280147203732085,108.44125002729322 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark05(-0.4464279243069136,-9.424777960769381,61.058215241640866 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark05(-0.4469236922847333,-0.15751232335093626,-83.96084128705789 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark05(-0.44768974119073823,-1.5707963267948966,90.34714654965714 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark05(-0.4490340259307103,-1.3877787807814457E-17,-39.665897147961196 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark05(-0.44920202671163467,-4.071967613324552,3.142212653574622 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark05(-0.4494844468858003,-1.5707963267948966,-3.142080935053087 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark05(-0.4495737212546086,-0.569446890555764,51.37144070998804 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark05(-0.4496193368959818,-54.88204018582444,-98.09721044711253 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark05(-0.4500750744388943,-0.10265819491157598,-14.43756508809117 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark05(-0.4505251153526469,-0.8497371593552833,94.8986157862922 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark05(-0.4518533460948767,-0.08629011752305354,1.5707963267948966 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark05(-0.4535357823658893,-1.0436521237399683,1.5707963267948957 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark05(-0.4547065076121942,-66.43435777006377,78.58146831715062 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark05(-0.45510528794007243,-1.5707963267948966,32.044996049594594 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark05(-0.45531538444657355,-1.2935359066837542,-35.38772496479901 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark05(-0.45552603425989024,-3.1416002829850167,85.04070784370603 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark05(-0.4568711599324061,-3.1435457785897936,-43.665816209026204 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark05(-0.4569283027274404,-0.45114174891804787,-4.0572948912554025 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark05(-0.4574763100011284,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark05(-0.4579851853446957,14.43420798344377,1.2569653296855054E-5 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark05(-0.460925046673926,-0.015449723048162714,-48.77831352305221 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark05(-0.46108737550274803,-1.5707963267948983,-35.3937615660726 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark05(-0.4621833143692521,-66.96280773956218,30.819224750985587 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark05(-0.462501349866848,-85.0063328519743,51.213788707755356 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark05(-0.4626498790282365,-1.5707963267948966,-168.00019294960515 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark05(-0.4629756864622038,-0.15166334301703638,45.22183674439706 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark05(-0.46298829838803107,6.776263578034403E-21,0.25698548388076503 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark05(-0.463559958871199,-1.5707963267948966,44.1436617532228 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark05(-0.4637969218675232,-1.2298964671428436,3.552713678800501E-15 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark05(-0.46392761129343013,-3.8290458980644937,-5.141592653590473 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark05(0.4646798833314809,-0.04175656455228268,3.1576418737893586 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark05(-0.46473119580922556,-1.5707963267948966,51.07681993482957 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark05(-0.4648705757616993,-47.43191525381696,-57.793105461862474 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark05(-0.4648962786295888,-1.5707963267948966,-7.391295525311634 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark05(-0.4649690771550171,-42.13374065876773,-33.49765818122277 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark05(-0.46618918053607555,-35.74269421836655,0.0 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark05(-0.46685738730694964,-66.23417845140956,1.5707963203375501 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark05(-0.46730658843291817,-0.4734330959897013,-367.5760951055421 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark05(-0.4675563916009598,-66.08336252022269,14.429272233335062 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark05(-0.4675855753887896,-9.997964383927123,-3.1415926685027813 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark05(-0.46930074983874026,-0.5505943634171296,-26.616210625406005 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark05(-0.47004183366274926,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark05(-0.4702159421521466,-35.932948731017646,-78.48516993976683 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark05(-0.4703371800628969,-54.75097323064101,75.015238092998 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark05(-0.47087631959960613,-34.66416981846453,0.7878044440273597 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark05(-0.4709245807937912,-66.27555694420604,-1.3891811888650532 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark05(-0.47261289056536937,-1.5707963267948957,0.7484662979888 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark05(-0.47272247925978306,-22.29928621818662,10.949050116182946 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark05(-0.47353817938642156,-2.710505431213761E-20,-82.54240951174924 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark05(-0.4737778100621909,-35.1103946288858,-20.491288712863398 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark05(-0.4740000339939142,-3.2665945869947626,63.46295029500982 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark05(-0.4750149928419979,-1.5274656015383403,15.727918995135383 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark05(-0.47517878882592957,-66.32822891050128,-13.388462794556233 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark05(-0.47544448649863114,-185.63486127564477,-15.591963802976252 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark05(-0.4755365111830902,-35.05137168269873,6.8111433944340165 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark05(-0.47595146345827954,-35.72452642215582,-7.872003254524316 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark05(-0.4760265923286278,3.1494051535935075,4.988750462304338 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark05(-0.4761539270886601,-35.528384640026445,80.00603988633955 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark05(-0.47707098127932834,-41.95364087053362,67.54424205218055 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark05(-0.47798408028744716,-1.5707963267948957,-27.707228565540934 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark05(-0.4781107013863985,-1.5707963267948966,6.724403505988377 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark05(-0.47868859145442744,-7.514961731124248E-6,-80.17658768795994 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark05(-0.4790438428924289,-0.17792175031000618,28.27433380417135 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark05(-0.48039902114514943,-0.06324162890661908,-16.026642751695256 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark05(0.4806299286689967,-98.67018249561886,49.85985820454892 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark05(-0.4808627195802763,4.141592653600737,-10.938327772771487 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark05(-0.48125633241839055,-1.5707963267948966,-9.560294409522365E-6 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark05(-0.4812563392705002,-216.992380068222,-374.1236287622079 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark05(-0.4814301692116203,-1.5707963267949019,-51.008947760601544 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark05(-0.48162040215042623,14.433431380417694,-84.53204349515065 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark05(-0.4821502867381101,-1.5707963267948966,-47.26009123282362 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark05(-0.4823371621776903,-141.63058547068053,18.043297161005356 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark05(-0.48240482148499036,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark05(-0.4824099639567162,-3.814321770791965,-19.800885502389747 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark05(-0.48247003919503206,-0.195047273458556,199.4913225163112 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark05(-0.4836522568992746,-1.5707963267948966,69.98727011294895 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark05(-0.4850931480898068,-5.551115123125783E-17,-46.59886112560023 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark05(-0.48558191519376703,-122.7908654890004,-23.562328392774084 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark05(-0.48708223122646643,-1.5619928614435066,64.94311485042905 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark05(-0.487418645029375,-1.5707963267948963,0.0 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark05(-0.48761880872769936,-1.5707963267948966,-23.87636870567347 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark05(-0.48796685207045715,-0.08115309857859289,-64.21155093747151 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark05(-0.4887723773180741,-1.4464843503188822,3.1416536887718496 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark05(-0.48921634445779744,-0.584557279515769,1.5707963267948966 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark05(0.4893394847753084,-98.0914119171432,-100.0 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark05(-0.49030872170552614,-1.5707963267948966,60.004508772543865 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark05(-0.4915162579469623,-0.7493029824948674,99.46971750669641 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark05(-0.4915635730091005,-1.410115130523748,79.79861550535782 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark05(-0.4918410338520929,-41.037183519008316,-49.4118596916532 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark05(-0.4934445811103068,-41.9237358038702,1.915254994554361E-17 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark05(-0.4944045459762779,-1.5707963267164042,79.36134142237326 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark05(-0.49515207060592736,-0.012827239977920124,62.83963048315268 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark05(-0.4955516692573704,-72.96522017330122,-33.20693165943489 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark05(-0.4958635827929119,-1.5707963267948966,-39.88043888105683 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark05(-0.49588930440548595,-16.179206363001448,1.5707963267948966 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark05(-0.4968963583074128,-1.5707963267948966,70.68583470577035 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark05(-0.49714079685782553,-1.5707963267947462,-95.78453513651361 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark05(-0.49772958410916757,-60.7365393209936,-62.62069527072647 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark05(-0.49817256591359665,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark05(-0.4982505895577818,-1.5693494251477853,-72.38500559797654 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark05(-0.49858303678041793,-1.5707963267948966,27.662465085833162 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark05(-0.4991010744028171,-66.5244901071795,76.40249602332457 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark05(-0.49969477925496886,-1.5707963267948948,49.788023910552475 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark05(-0.5002239254571746,-6.462348535570529E-27,-82.03138161666662 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark05(-0.5007778619557032,-128.83495594937042,-2.0186109486824665E-10 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark05(-0.500852648350218,-41.47520329490686,-1.5707963267948963 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark05(-0.5010775712668741,-1.5707963267948963,-2.3408381773460992E-97 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark05(-0.5011645086592331,-0.358328178588904,10.190041618124376 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark05(-0.5012349269353847,-0.9488158359490118,0.1760876519239361 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark05(-0.5013739158327191,-0.5965441344723914,-65.3367403831386 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark05(-0.5028336738879573,-3.141592653591615,-90.00310248054575 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark05(-0.5045272772875258,2.710505431213761E-20,57.162297655153466 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark05(-0.5051506994624059,-41.551659705272684,88.63203753505894 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark05(-0.5051715091369254,-1.1387870234620863,3.640159158416907 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark05(-0.5053051018954121,-0.11369507695676456,-26.096364734409264 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark05(-0.5062869487682005,-72.8340221255282,55.08613062354972 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark05(-0.5063301816848528,-47.46296019990679,9.92195875501858 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark05(-0.5063387339077545,-1.5707963267948912,-607.627597460254 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark05(-0.5064879472970151,-1.3118010166485643,37.89163546724457 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark05(-0.50698646291481,-1.5707963267948983,-75.43176808491168 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark05(-0.5079210768497553,-1.5707963267948963,12.853484142245183 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark05(-0.5090125633108824,-3.5317784214142485,1.5707963267948972 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark05(-0.509580810871892,-0.8433130049103648,-2174.4726994704274 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark05(-0.5129988677384402,-15.869864732349678,68.52060857650918 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark05(-0.513867375187262,-3.148956631332524,-1564.4486542368456 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark05(-0.514678395424938,-1.1058644866543774,-29.410829896773308 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark05(-0.5146982076617933,-78.83280958439936,0.9600590975324088 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark05(-0.5150126270371385,-160.84289311227906,-9.551711117072763 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark05(-0.5151514044900719,-53.53018531584783,-33.49660779588386 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark05(-0.5164936273915459,-9.672615427373788,-358.4678303066842 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark05(-0.5167433113143166,-1.5707963261627014,69.53951741155333 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark05(-0.5169779242963034,-41.510128914777475,6.577880383327474 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark05(-0.5170082666611823,-1.5707963267948966,-20.757261788887654 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark05(-0.5171442244465442,-0.7122594104050737,-92.96570979553954 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark05(-0.5179283823285179,-147.88412126456126,0.12936083796894782 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark05(-0.5181176279194399,-53.57673048510595,12.597797545278604 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark05(-0.5183637062768538,-61.07537926519271,-28.617559839462814 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark05(-0.5191299337354094,-1.5707963267948832,11.643483906262901 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark05(-0.519266702681061,-0.6807044512450907,79.90129301544113 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark05(-0.5200733829105997,-9.988918230180206,-0.7472949146189161 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark05(-0.5203405970609829,-1.0496996872506938,-2.847999127033148 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark05(-0.5203625759395202,-1.5525253514073005,88.94962497740484 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark05(0.5214079894903421,55.04486877263122,44.12743608862269 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark05(-0.5216269902231518,-1.5707963267948968,-15.317615721993464 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark05(-0.5224096477490804,-1.5707963267948948,69.37402345699502 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark05(-0.5224582678412503,14.430393269612267,51.225715564801135 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark05(-0.5226903212510337,-186.24634402281995,-22.482862083378432 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark05(-0.5232145889982356,-9.620367579444007,-100.0 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark05(-0.5234055871336166,-9.93711137318266,-1.5707963267948968 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark05(-0.5239287152868997,-116.40795920156967,42.759625053361205 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark05(-0.5248151134050869,-1.5707963267948966,-76.96926414293274 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark05(-0.5270943258526013,-78.56805758209273,83.27763004903379 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark05(-0.527404390312869,-1.0822334578849497,30.652953974612018 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark05(-0.5279085372512784,-1.5707963267948912,384.26604823196317 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark05(-0.5281332594256298,-1.5707963267948966,352.18605159960316 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark05(-0.5295724052109347,-1.5707963267948966,1.5707963664914164 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark05(-0.5298850300485785,-0.5649750686822865,89.53539062730911 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark05(-0.5318275088358311,-66.25349155076776,-62.89757798715856 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark05(-0.5335962850389833,-0.057135359783309414,-29.89709766262393 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark05(-0.533702008884501,-1.1345889847908674,0.0 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark05(-0.5337425287339763,-61.14152068570304,-66.28862442579126 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark05(-0.5337625384394453,-1.5707963267948966,-47.289250471515345 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark05(-0.5340986897906866,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark05(-0.5342802492729576,-1.5707963267948963,0.0 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark05(-0.5343040385463702,-0.5050785567034496,-1.5707963267948966 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark05(-0.5358723070845456,-1.5707963267948966,-1657.7071405508402 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark05(-0.5360283773509785,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark05(-0.536427551614486,1.4831519045402857E-10,85.17774609522024 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark05(-0.5371381923351911,-1.5707963267948948,9.714882582997278 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark05(-0.5376350254614933,-3.3328782298957276E-9,42.76193488840974 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark05(-0.5379131277435887,-1.5707963267948966,-163.73712800293487 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark05(-0.5380092222811498,-4.136834940593117,-8.486891663767395 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark05(-0.5385951855161828,-0.021345998380804337,-77.34184274965659 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark05(-0.5385965777730354,-1.420000089762416,28.125244384045715 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark05(-0.5388498807301777,3.1728426538775967,28.313696868485966 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark05(-0.5390830240741029,-9.960185604516742,-3.142080939342076 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark05(-0.5392452382653747,-1.5707963267948966,95.0428144788859 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark05(-0.5399308510651358,-1.5707963267948966,-47.7983744196971 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark05(-0.5405034885303479,-1.345482868626343,-6.811922923066717 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark05(-0.5411599028913816,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark05(-0.5412865839426831,-72.42539542558187,-1.5707963267948626 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark05(-0.5414409826824602,-35.06419482099136,-37.48346143084328 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark05(-0.5415659325277061,-1.5707963267948983,-51.1171448619714 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark05(-0.5419926017034511,-9.582538610517435,-719.0156316182558 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark05(-0.5422300365857234,-0.02897557612307869,18.9030304933638 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark05(-0.5423949245313461,-155.38332525864908,64.02952924602005 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark05(-0.5426824772290152,-0.16431657733849647,75.62590393155182 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark05(-0.5430266509071151,-9.487277960769925,-68.54412597775188 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark05(-0.5433026708362847,-154.35143759076243,-83.73562484389267 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark05(-0.5435619839880228,4.141592653589797,94.1839636447805 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark05(-0.5444856554381444,-10.327122919829323,-29.601723152005974 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark05(-0.545079113400071,-3.4147958326572168,79.81499047685571 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark05(-0.5458841299872074,-0.004448587547280119,-15.768478122174095 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark05(-0.546313627374973,-98.03693287392846,-1.5707963266481684 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark05(-0.5466084032937332,-1.0037920121070674,-27.7619834278279 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark05(-0.5466921014595655,-47.31720216255438,22.17190307662682 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark05(-0.5472489844878923,-1.024412333835399,-55.371098733169234 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark05(-0.548140948947967,-1.5707963267948921,89.0559654329745 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark05(-0.5506426254501928,-0.555471635456124,100.0 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark05(-0.5516700484724094,-61.195104338520984,0.0 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark05(-0.5517929421464599,-1.5707963267948983,-78.69073508873754 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark05(-0.5517963525081662,-41.84921279322862,-1.5707963267948968 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark05(-0.5519692124271853,-48.2845161833921,-14.412964480709602 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark05(-0.5523130339655125,-1.5707963267948966,-28.13329714999371 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark05(-0.5523684421060366,-66.03906494605285,13.307391742973579 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark05(-0.552510746774777,-9.48848838996578,6.283185921093089 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark05(-0.5525291457168806,-42.065197480585184,90.85369533191584 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark05(-0.5534609586646315,-97.4497397473208,-1.5707963267948966 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark05(-0.5542732730686591,-1.5707963266392626,-62.977052641157314 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark05(-0.5553369968683871,-1.5707963267948966,-0.9126107924354216 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark05(-0.5554881991072018,-1.33730380273591,1.5707963267948948 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark05(-0.5555179451579566,-36.12531477467469,17.65080774002817 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark05(-0.5555488282469866,-1.5540989876050813,51.82278065679453 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark05(-0.5555607636328129,-1.5707963267948966,-94.86371331204433 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark05(-0.5556714726902359,-59.72982928187038,-60.990863918274805 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark05(-0.5584619771490519,-1.5707963267948966,-78.32464643817255 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark05(-0.5587274915043411,-1.5707963267948963,73.62729305292649 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark05(-0.5592787151655536,-0.5540177453216379,41.48110154846465 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark05(-0.559316647385366,-1.5707963267948966,77.31901327523141 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark05(-0.5609346487769511,-0.650632956117418,-6.283246509370212 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark05(-0.5628153840941174,-1.5707963267948966,14.462214410228256 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark05(-0.5647046923652648,-1.2230467330893617,-616.7765044286846 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark05(-0.5649483751747297,-1.5707963267948912,-53.282182166763086 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark05(-0.5658426995643855,-1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark05(-0.5661140242067599,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark05(-0.566505656628868,-0.48875237383847,1.5707963267948966 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark05(-0.5671877365061223,-1.5707963267948966,-10.209865275567575 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark05(-0.5672949967413358,-0.9077924552632228,34.35411639503687 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark05(-0.5679583272628609,-41.759942193078594,-1.0676809020314943 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark05(-0.5682694616763274,-35.31214482077515,31.315834927302294 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark05(-0.5684170521089955,-3.979431641666295,81.84294193939417 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark05(-0.568649171362178,-122.89088599879963,-44.97937135432211 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark05(-0.5688011118254299,-41.84165657128662,-21.283874750776064 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark05(-0.5697686490368779,-1.5707963267948966,-34.77620928883851 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark05(-0.569978627790092,-66.3605850791343,-78.96852185073327 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark05(-0.5700003111098126,14.606378474608618,-20.144955051166264 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark05(-0.5701659088298292,-0.6411547690258455,-55.13656000339263 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark05(-0.5703725241157824,-48.22233503896498,-73.79468946328065 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark05(-0.5706705469021486,-1.5707963267948966,7.8540674966679545 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark05(-0.5707982091564066,-1.3359367525305297,15.77149974123758 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark05(-0.5729256017780017,-1.5707963267948966,78.52495288714476 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark05(-0.5744304262751818,-3.761081736033006,70.01116639702649 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark05(-0.5745259584498168,-48.64360900481319,7.141437614420838 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark05(-0.5746502866527123,-0.5134391138383658,28.48512536613822 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark05(-0.5750197950542201,-1.5707963267948966,-5.972017745649637 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark05(-0.5751845277634254,-1.195219442706267,-85.19347966600148 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark05(-0.5751984215165654,-1.5707963267920806,168.09983991453163 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark05(-0.5762642936030047,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark05(-0.5763039510919943,-1.152906624253816,27.07590850481087 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark05(-0.5770371594818153,-41.807617700968805,66.08501031707463 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark05(-0.5776748524373025,-97.95850926440248,35.919145768598845 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark05(-0.5779261352712075,-73.15719287972243,72.47948120800808 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark05(-0.5782366382285818,-0.8737727029150534,-66.3051045342419 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark05(-0.5794879474019775,-1.5707963267948912,-111.53608949380869 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark05(-0.5796088760686682,-35.01338428510221,-1.5707963267948963 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark05(0.5799017739517772,-48.668353493594275,-10.754292612194718 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark05(-0.581236106074871,-1.5707963267948966,-22.365046319616802 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark05(-0.5818305176148612,-3.3881317890172014E-21,34.72872719774486 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark05(-0.5826106252191542,6.431630531899146,66.28668620896073 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark05(-0.5861649993652635,-0.04977940897216204,-14.174338607312194 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark05(-0.5870461230493753,-66.05827016494621,-36.12831551628262 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark05(-0.5882333924025014,-1.4138629694531801,-1.5707963267948966 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark05(-0.5886205960469528,-1.056364368589482,-1.5707963267948948 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark05(-0.5886705373234326,-1.5707963267948966,14.979850534867367 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark05(-0.5888457562619049,-1.5707963267087854,28.24840262466556 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark05(-0.5890781166193959,-0.24889041206888315,10.545865270950998 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark05(-0.589348840105751,-0.1041066578290793,51.84811528842371 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark05(-0.5897154464808186,-0.20763236182979689,-119.37310486171397 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark05(-0.5900149182379675,-3.1573677016751116,-133.93894351500114 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark05(-0.5903163767351252,-1.045607949796358,-26.49025302429378 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark05(-0.5917541943622262,-0.7273849186658896,9.949358780528584 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark05(-0.5918963460302864,-1.4008051675722635,-4.3368086899420177E-19 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark05(-0.5921906412313049,-1.5707963267948961,0.0 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark05(-0.5922533384502474,-1.5707963267948966,4.712389713674931 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark05(-0.5925277759913321,-3.8256572989350985,0.0 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark05(-0.5927787815585907,-160.25695056013694,112.94628839639017 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark05(-0.5931924646616852,-1.5707963267948966,-1.5707963267948983 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark05(-0.5932226414304792,-2.220446049250313E-16,-20.87528870290351 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark05(-0.5951763400088679,-0.5088421375964649,34.10060470495287 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark05(-0.5955527667510139,-1.5707963267949014,-137.80646476759944 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark05(-0.5957244763213712,-1.5707963267948966,-71.03224411349115 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark05(-0.5970385885706808,-1.5674770596296828,0.0 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark05(-0.5971663681979127,-0.5547506513867562,15.603654475063706 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark05(-0.597178251910041,-60.8390332432279,-0.03314835238157948 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark05(-0.5977191409750273,-41.64319494198361,-98.90856483010914 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark05(-0.5978795859783106,-1.1637792290912214,36.834924108405005 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark05(-0.5984479324408031,-60.89532136486366,58.025530117612234 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark05(-0.5984716317512612,-35.99182872996647,-37.79803887087803 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark05(-0.5992146027802777,-3.894698961055454,35.39832887517017 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark05(-0.5999047235794497,-0.19796940410093333,-64.42182345958715 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark05(-0.6003202220922783,-35.43577538410655,-24.141304298138024 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark05(-0.6003652454293276,-1.5707963267948966,47.4478678781473 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark05(-0.6010336045421475,4.141592655933906,72.34290095166844 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark05(-0.6015056524345632,-707.6370375965972,79.16002118182288 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark05(-0.6030905471632091,-1.5707963267948966,41.018159607444666 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark05(-0.6033547740220015,-3.1415926685063638,-27.52882953098085 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark05(-0.6039781761363705,-3.8160394493642116,-32.952060381354386 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark05(-0.6046363513810175,-0.10397680290083244,0.0 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark05(-0.6046491617489002,-0.266069116513988,4.141593840879363 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark05(-0.6051375998779301,-1.33870510553067,-50.47268245913568 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark05(-0.6064489901331631,-37.2132775974505,34.426610240758784 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark05(-0.6077694555003486,-1.1299236546701246,45.44539737249272 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark05(-0.6080427806825311,-1.5707963267948957,-1.5707963267948966 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark05(-0.6081642938918606,-16.071340298799157,-7.311574862015121 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark05(-0.6082346077534193,-0.8659648259950217,44.3484912413343 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark05(-0.6087652546574064,-66.45806744558017,324.0840189554926 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark05(-0.6099381919283281,-47.50978069395009,88.03809436409719 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark05(-0.6103061698906629,-92.16689905696373,0 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark05(-0.6105122857168558,-0.3089377745140649,0.04934245252938358 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark05(-0.610954424405147,-0.8413171680362586,-95.64816954636154 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark05(-0.6112683976425012,-0.29832512344812284,-46.77477102277767 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark05(0.6120695928798495,-1.5707963267948966,-174.49621100443107 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark05(-0.6135548808227704,-1.5707963267948966,33.37213824556343 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark05(-0.6136384784291979,-1.5707963267948948,-26.12832401126512 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark05(-0.6142844948789761,-1.474975891973405,112.67281444394993 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark05(-0.6157829538070025,-0.35538391100959627,-49.9861219946511 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark05(-0.6158407204432844,-3.8405471843133205,84.71964246004481 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark05(-0.6158630973538439,-0.6087218250049274,54.089611295247906 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark05(-0.6162689010184216,-1.5707963265962195,-48.03325904494052 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark05(-0.6194342457265707,-1.1915762910537253,0.0 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark05(-0.6194587107138274,28.703537555516107,1.5707963267948966 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark05(-0.6202156763203526,-66.43025655948844,-97.58922074779686 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark05(-0.6211356004424169,-1.570796326628085,-22.46606229842969 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark05(-0.6221001065799775,-0.024608417247086907,-3.0838896296424565 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark05(-0.6221114288481413,-1.5032674274927782,66.26380087508693 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark05(-0.6223499100202758,-1.5707959851786326,-147.9151636471205 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark05(-0.6235158451528662,-3.653409894533297,-63.249054413146155 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark05(-0.6248348443163323,-191.71244406119888,-4.712389182777613 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark05(-0.6250637633814962,-3.72572352690689,28.63710037758922 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark05(-0.6260053802053617,-1.5707963267948966,-35.27590571606849 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark05(-0.6265512241323645,-1.5707963267948912,-12.648099959680565 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark05(-0.6269355604510827,-1.570796326794896,-41.02824943934935 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark05(-0.6271683158501362,-1.5707963267948966,-43.959131703955975 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark05(-0.6275688965842205,-1.4770778203513868,-0.24019101332183063 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark05(-0.6285655650101581,-1.5707963267948966,-0.7206648387786736 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark05(-0.6287322692073882,-66.3846042356284,0.0 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark05(-0.6301486730561834,-98.82451608846729,-60.372090033433224 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark05(-0.6306338326367585,-98.57698850308465,61.48725172093202 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark05(-0.6309459498171266,-0.14083514551549156,-99.72594266254598 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark05(-0.6310005640522048,-48.541513104936925,94.57411238343462 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark05(-0.6312361810926916,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark05(-0.6317068437509055,-1.1090535771048033,500.8529493976238 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark05(-0.6322348452491315,-1.5180510473998834,0.0 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark05(-0.6329864534116467,-1.2100596939370676,-50.36472712096824 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark05(-0.63313357875478,-66.24524167793273,-98.32813313085273 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark05(-0.6331667576959783,-808.3109569462979,80.47879720794799 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark05(-0.6333666189547112,-1.5707963267948966,-14.726193662108358 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark05(-0.635117719016268,-54.61273124055208,-51.768154878057324 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark05(-0.6362815866813354,-1.5707963267948963,-56.29007401873306 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark05(-0.6364102766527169,-1.1704960062280776,1.5707963267948966 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark05(-0.6366981717796705,-0.25650352962748185,-35.76350699297091 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark05(-0.6388395510064948,-1.5626058981472317E-15,-1.5707963267948966 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark05(-0.6400368974786707,-72.98595808816826,-636.0126243488453 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark05(-0.6404781988199488,-0.4987958445459374,46.08037973738094 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark05(-0.6405728438274025,-72.39772690467662,-18.849556875238733 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark05(-0.6417390476585387,-0.4160390082457883,70.2067862809854 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark05(-0.6423133397576156,-1.0512280042721196,3.285375025236732 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark05(-0.6425552241981457,-3.143732707505495,140.286165034906 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark05(-0.6427820009437865,-1.2520390681467355,44.54490160408048 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark05(-0.6434282964171649,-66.6373051975116,-1.5707963267948966 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark05(-0.6438740493309054,-1.5707963267948966,-21.634072071850213 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark05(-0.6444312732894386,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark05(-0.6445417473555081,-845.3894918411092,38.90952381609853 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark05(-0.6448826729786222,-3.484981415470921,59.690261028500004 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark05(-0.6451397468892621,-180.34601715315515,-75.64930342321064 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark05(-0.6462775947796305,-1.5707963267948966,28.597860331673587 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark05(-0.6463390617326656,-1.5008218752814475,-1.5707963267948966 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark05(-0.6483457193354472,-1.5707963267948966,-35.627541443700906 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark05(-0.6496087800040606,-0.1651019586239798,-1.5707963267948966 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark05(-0.6502685158769786,-98.37562461172213,37.48676164286504 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark05(-0.6506922620187119,-1.07256659803455,168.07901286128703 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark05(0.6511757854447697,-1.3682289433577992,-51.36202351865452 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark05(-0.6517069610874824,-129.58706683365176,45.18437847019604 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark05(-0.6519277603624816,-4.12191041811181,41.778869029830105 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark05(-0.6527693059339379,-1.5707963267948966,-36.12928317410376 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark05(-0.6528375050102144,-41.45973326188328,4.712389028038539 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark05(-0.6540382240615541,-4.013132161218682,-14.432714073326416 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark05(-0.6541675252980196,-1.5707963267948966,64.0755740364074 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark05(-0.6564991229897015,14.456175470862277,9.428917847862628 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark05(-0.6569165527178735,-1.5707963267948966,-50.71444970219006 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark05(-0.6572047872737278,-0.32686637335467555,-1.5707963267948983 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark05(-0.6585817576586107,-1.5707963267948966,45.26233414011075 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark05(-0.6608357878989977,-1.5707963267948963,47.199046963295785 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark05(-0.6612397055304162,-3.7444870184109647,163.71754625012454 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark05(-0.6615257650422083,-0.06364688406911691,-20.978427148353866 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark05(-0.6630676410285598,-1.5707963267948966,-20.47865919047875 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark05(-0.6636988760794754,-1.5707963267948966,-1.5707963268125102 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark05(-0.6657675965949288,-1.5518716380962436,26.267503383176628 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark05(-0.6658207533893926,-1.4593892575024512,37.88726164896937 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark05(-0.6666525881366442,-0.2697318058104021,60.06666993905303 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark05(-0.6669380966696851,-47.4438751059443,-107.02214757056139 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark05(-0.6682279288631108,-42.25844352306358,450.77692903981824 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark05(-0.6684741741679293,-1.1022525955431954,8.333588465448635 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark05(-0.6685962088050927,-72.87824181858724,83.51210070755388 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark05(-0.6688711005290173,-1.5707963267948966,79.2970348119473 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark05(-0.6700012831434513,-41.488622450510995,20.91158195350227 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark05(-0.6710890067467188,-65.97344658069792,31.76472884073922 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark05(-0.6716917412522349,-1.3877787807814457E-17,-1.5707963267948966 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark05(-0.6717362787912771,-60.89235325975482,41.19315521147443 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark05(-0.6718708232441553,-73.08141961687386,-123.5299902956735 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark05(-0.6720262935877143,-37.690311201169905,-83.83268429726725 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark05(-0.6720273540520945,-9.016580681431383E-131,-32.772479243681346 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark05(-0.6729460100082345,-1.5707963267948966,-1.5707961996581103 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark05(-0.6733128697945164,-1.5707963267948966,1.5707963267948957 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark05(-0.6734904523597085,-97.77210781283911,3.552713678800501E-15 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark05(-0.6744976174066244,-0.617327846003878,-87.48567864796286 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark05(-0.6755100199809002,4.1415926662650095,15.877980134676562 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark05(-0.6755804400852767,-34.65854334370009,86.60060521055578 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark05(-0.6756699720504835,-72.50158472728165,52.02262069115661 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark05(-0.6757360056083788,-1.0868393867476986,1.5707963267948966 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark05(-0.6764040508059088,-15.848295762520252,-51.35794701421426 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark05(-0.6764406844963234,-0.9511782239584995,98.54120733241272 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark05(-0.6783035366006221,-3.7782779341173893,-73.33296300396958 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark05(-0.6799864301438339,-15.906791871635434,21.78038962357193 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark05(-0.6802610545822124,2.4314085451877623,-4.3368086899420177E-19 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark05(-0.6830824319734292,-0.7565406497560239,56.037961603515676 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark05(-0.6846325489790017,-0.824180497664695,66.3972543114819 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark05(-0.6849445473020205,-0.22138256397000003,55.20152566857888 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark05(-0.6850583167780968,-28.2832552013371,65.26494589151586 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark05(-0.6852914177739962,-42.05042059443201,183.75307024437728 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark05(-0.6854940081751408,-0.6729385659641306,-4.211425758052751 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark05(-0.685527920707952,-0.9201040776534732,32.77397832996856 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark05(-0.6858434153470085,-1.7763568394002505E-15,-21.74456218057919 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark05(-0.6868125994879288,-36.11593777401261,60.020561023182864 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark05(-0.6868228158580576,4.141592653589794,33.80987403176597 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark05(-0.6875422258514374,-41.04136562240954,112.85208011876557 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark05(-0.6887226908632597,-1.5707963267948966,-12.562478124729946 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark05(-0.6887337357824661,-0.5078579035003757,-38.9873609474484 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark05(-0.6895188036720966,-1.5707963267948948,0.47003768186812195 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark05(-0.6902708767903561,-0.10862309264460546,89.9812172649186 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark05(-0.690348645571711,-1.5707963267948966,-6.284161871854633 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark05(-0.6909762157417116,-84.90489597742186,-90.94179903635616 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark05(-0.6912016404346426,-47.59681973896832,-78.16344628754412 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark05(-0.6923845273843461,-1.4859664466371267,-15.274223002834749 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark05(-0.6930793897671272,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark05(-0.6932007262111934,-0.8065207503820632,-50.08665399216896 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark05(-0.6932566895073222,-28.373332366649663,-7.491047027255189 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark05(-0.6939201389915023,-122.79188915477422,-45.23747108860707 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark05(-0.6940928996972389,-1.0858339151536427,-49.840857175182975 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark05(-0.6943422451235324,-1.5707963267948966,1.5588439729667878 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark05(-0.6949389877395191,-122.97657397137111,588.172753132075 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark05(-0.6964165295351958,-16.159664308117897,-0.03358981414503459 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark05(-0.6978126597526347,-72.96688439357084,632.0682478664919 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark05(-0.6982410539623531,-42.184932722020264,-32.35312292953222 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark05(-0.700473980363852,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark05(-0.7004801682094399,0.7730038234008709,1.5707963267948966 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark05(-0.7008169698487314,-66.74559341010615,350.39879250275374 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark05(-0.702088354976275,-1.3931202140784702,-8.103981633975714 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark05(-0.702096669654063,-0.9503709836406458,0.1620700543292699 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark05(-0.7021416710944255,-47.452848903386766,-107.65559418199068 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark05(-0.702248609768833,-0.27013056967566357,-0.3135681206621498 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark05(-0.7029657436126864,-9.505457831475799E-212,-22.328541603233347 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark05(-0.703373927387787,-78.74895029039328,-3.2579706959339205 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark05(-0.7044099485242786,-1.3992793091679394,15.922286077237203 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark05(-0.704696738720775,-35.131998886687875,4.930380657631324E-32 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark05(-0.7048935126570779,-0.30044244334234954,-14.070278294730414 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark05(-0.7059588561740391,-1.5707963267948941,-26.80743120663202 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark05(-0.7068192578115138,-0.32477524980995653,-84.2972910275426 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark05(-0.70702937641407,-1.5707963197534436,-92.7548419764212 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark05(-0.7070663786623886,-1.1404298964314425,-70.88269850177068 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark05(-0.7080177724224123,-61.210814324923525,-141.17147894664444 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark05(-0.7093450767948977,-1.4298992108459792,60.361757403716 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark05(-0.7096062918310962,-173.2788822178008,33.692644279046206 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark05(-0.7108230757446385,-0.4763345099797968,119.3150454018596 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark05(-0.7113483823380755,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark05(-0.7118495171343044,-1.5707963267989067,0.3126627768940721 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark05(-0.7124956613851476,-0.002250320899040592,-1.5707963267948948 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark05(-0.7130859905872169,-61.18994302124689,46.977457582009016 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark05(-0.7138777316801915,-10.225684035920404,-3.1420828402631815 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark05(-0.7146424091309708,-0.29124560155194607,-1.5707963267948966 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark05(-0.7176020494115045,-3.3451115404781593,62.92774216929601 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark05(-0.7181344412751564,-54.752768042731915,-73.42432550677417 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark05(-0.7184981042092918,-122.79652473732946,56.09496339157586 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark05(-0.7185322766007253,-550.4625978464127,103.7699327496391 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark05(-0.71962254294793,-1.5707963267948981,89.66749588308993 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark05(-0.7210325177165657,-1.5707963267948948,76.26981700604304 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark05(-0.7217284703489772,-1.5707963267948966,-8.33737885765807 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark05(-0.7219444071164982,-3.6206751036943334,39.560415011139156 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark05(-0.7230795086313718,-1.5591019309189138,-48.6946861306418 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark05(-0.7231034816995267,-154.99045970116572,-66.78337024357705 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark05(-0.7231179191672238,-1.5707963267948966,6.394949206456458 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark05(-0.725144795621179,-97.85120457364673,-1.5707963267948968 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark05(-0.7262795838333055,-78.9716371667264,52.25502616728406 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark05(-0.7270342478795989,-1.4913308789580255,9.42477796081167 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark05(-0.7270719877211534,-708.4269074058743,-146.79609934736547 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark05(-0.7273508263549401,-1.5707963267948966,46.75533801692305 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark05(-0.7276912033614771,-72.40929261704282,8.401948151648384 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark05(-0.7282911801517129,-3.26659266921006,-54.79914086156581 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark05(-0.7287261449272584,-0.6281240916880364,75.91796191536127 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark05(-0.7291141605369044,-3.2665928568149845,-73.71279626461121 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark05(-0.7314965583588793,-1.5707963192626517,100.0 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark05(-0.731814935938238,-3.1619603485340217,-47.534788355548876 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark05(-0.7326378591969971,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark05(-0.7352999878369448,-72.48885494463092,56.52373570541955 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark05(-0.7353266169595452,-1.1102230246251565E-16,-31.992725801349607 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark05(-0.7372216863411929,-1.540335161537137,-1168.382345109304 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark05(-0.7376264514637063,-1.1409659483321448,15.489162997303723 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark05(-0.7386784975852319,-1.5707963267948966,72.7318968052639 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark05(-0.7394106065434265,-2.220446049250313E-16,-17.136419120574445 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark05(-0.7408565118892314,-84.84809018039473,84.9404974056293 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark05(-0.7422074351807975,-1.5707963265659157,-1.5707963267948966 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark05(-0.742670835027061,-2.2227587494850775E-162,-90.65482366997415 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark05(-0.7436519894036797,-47.364258102919734,63.15483861289968 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark05(-0.7437464228138352,-1.5041336690058955,0.0 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark05(-0.7439509932767487,-53.637671185208596,-98.76053714620174 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark05(-0.7441438452768723,-1.4026805717482693,1.3420153219628619 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark05(-0.7452245139005594,-0.47148243065835604,-13.454295330971462 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark05(-0.7455483414963052,-78.77647183817966,1.2374352347820707 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark05(-0.7456833117090881,-1.5707963267948966,-91.11009324699488 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark05(-0.7464356397623392,-1.5707963267948966,-90.52576172273008 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark05(-0.7485648062103689,0.062481951898447755,1.2704914803998093 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark05(-0.7485750822951314,-0.8272360975880942,-41.67807723942596 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark05(-0.7493683370288879,-0.8750671172289213,31.680612630376373 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark05(-0.7496704266909889,-0.7934387646173755,-4.712388983660242 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark05(-0.7502554697433643,-1.290698053241598,-1.5707963267948966 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark05(-0.7514370271271824,-48.32981398601335,-62.72881571260369 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark05(-0.7516639412023396,-1.1102230246251565E-16,83.26720636448991 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark05(-0.7517542023223216,-1.5707963267948966,-19.464052722112555 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark05(-0.7519931423734428,-42.02858568946806,1.5707963267948966 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark05(-0.7523707069474228,-41.89080179343225,54.67216226730631 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark05(-0.7527161537006999,-54.97326885218299,40.9656056803737 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark05(-0.7542753352829517,-0.847188913769295,98.5050004498664 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark05(-0.7548104209944428,-123.31734022767077,10.84133249102031 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark05(-0.7563945113827728,-1.5707963267948966,1.5707963267948626 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark05(-0.7566526133966813,-1.5707963267948966,1.3353164482103014E-15 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark05(-0.7567429037434168,-1.5707963267948966,-1.1508036987161738 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark05(-0.757784851982031,-4.0898160321948325,-90.85179176436576 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark05(-0.7580988778958719,-1.5707963267948966,82.38788046266131 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark05(-0.7591428167722702,-48.50961003286698,3.552713678800501E-15 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark05(-0.7596456922884407,-72.82257126454672,47.79383066791064 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark05(-0.7598406515922062,-330.1000928578571,-1.2255318318017097E-5 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark05(-0.7600703937722485,-0.13553680816822455,13.976500872820345 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark05(-0.760288169814892,-42.09794709472493,1.2804170913201922 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark05(-0.76035192310016,-0.057018219584030305,-71.87385650776233 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark05(-0.7618232856295862,-84.92550753097697,-45.095902445729116 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark05(-0.762140126094505,-72.26327617660637,-55.93434020029457 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark05(-0.7630929589400897,-0.46849952884238233,2.7066091172276714 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark05(-0.7639210869998289,-0.28446252193529675,-92.40260589056173 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark05(-0.7641936185105322,-54.75251839087121,76.23931263024897 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark05(-0.7648756671309026,-0.3407843181507433,55.72568141625967 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark05(-0.7649498573554496,-1.048321409507061,77.23540264402303 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark05(-0.7655405842298507,-0.5745936344832836,-4.712389044970629 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark05(-0.7655987324178288,-1.5707963267948966,18.773743852347707 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark05(-0.766083020853078,-1.5707963267948966,-29.810950563413485 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark05(-0.766506938476782,-66.2678609333429,-0.742446358330517 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark05(-0.7669491743768206,-0.22644799183400519,30.632637156380962 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark05(-0.7671860584794827,-505.8460235728392,1.5707963267948983 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark05(-0.7680912046403474,-1.5707963267948966,-53.69866237178963 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark05(-0.7684571401823064,-78.80433423135716,13.209115314306402 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark05(-0.7684963006278736,-1.132577592202856,94.334959209609 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark05(-0.7689945647768289,-34.55751946432529,79.80717150435979 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark05(-0.7704852824838521,-41.40601290007781,-13.957384696156666 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark05(-0.7715649509776319,-42.20470414955686,-0.4504512997512283 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark05(-0.7727436242225423,-1.3729639272033882,-75.34698898318375 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark05(-0.7730551169694848,-53.57017795956211,1.5707963267948966 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark05(-0.7732483519904327,-1.5707963267948966,-8.103981635398094 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark05(-0.7738600363023694,-3.552713678800501E-15,1.5707963267948966 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark05(-0.7742907345702297,-42.211405320119745,-157.53162245250746 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark05(-0.7748247557519203,-0.6859635148695693,1.5707963267948966 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark05(-0.7750407694733388,-1.5707963267948963,1.5519492681746139 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark05(-0.7753704354772676,-0.19753874433999385,0.0 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark05(-0.7766960229266422,-0.9453948768800745,122.664264768892 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark05(-0.7775223614874927,-1.215723028974767,-0.9833801279681669 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark05(-0.7779690414213429,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark05(-0.7780258151873181,-34.598917818476565,-13.501958523644472 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark05(-0.7794862791861209,-1.5707963267948966,-95.47145779898422 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark05(-0.7802463955009473,-1.5707963265451532,32.62635789720747 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark05(-0.7833731031152698,-1.5707963267948966,8.220157507344314 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark05(-0.7836348580254926,-48.159045864297774,-136.49445916419808 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark05(-0.783811480544641,-3.3441796384058478,18.26079729130127 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark05(-0.7841021262788606,-1.5707963267948966,-998.3902422030269 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark05(-0.7846964704747853,-0.03426198143809384,-1.5707963267948963 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark05(-0.7848125603327767,-1.5707963267948963,-4.264549233836407 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark05(-0.7859886390502338,-1.5707963267948966,-16.10020812089272 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark05(-0.7861270786690905,-1.5707963267948966,3.1415926535897962 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark05(-0.786279178353261,-54.92606785850693,-1.508386137986065 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark05(-0.7863553373010005,4.14159731671736,-43.42778542370634 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark05(-0.7867232212565276,-1.5707963267948966,-22.832859038548335 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark05(-0.788256151304494,-16.169456455520816,100.0 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark05(-0.7885288914659768,-1.5707963267948961,-51.95146572878471 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark05(-0.7892590509086777,-3.802792314844055,22.614689974382273 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark05(-0.791123890837472,-0.38657377518637914,-1.517622680226756 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark05(-0.7911924924863418,-9.424777960769381,-69.85019918236684 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark05(-0.7923523608374804,-9.506390814430901,9.987186122576801 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark05(-0.7935556120087166,-0.0991976433622169,-100.0 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark05(-0.794353967541988,-1.570796326794893,-1.5707963267948963 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark05(-0.7949115695395427,-0.003675228986178623,-1.5707963267948966 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark05(-0.7963024441858501,-0.1316877256887865,26.029687218497727 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark05(-0.7964449235680392,-1.5707963267948966,0.6942987071606138 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark05(-0.7964538638954579,-48.50280433776324,1.654337500948966E-16 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark05(-0.7964781300694639,-65.97344573014458,1.5707963267948966 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark05(-0.7972769660976468,-1.5707963267948966,-0.5706014287577023 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark05(-0.7975398774462801,-1.297709748357052,19.920838103013793 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark05(-0.7975754731930706,-34.95164482583312,-8.254536778629951 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark05(-0.7978765137797681,-54.53457191149618,-5.141592657466101 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark05(-0.7982824589432501,-1.5707963267948966,0.26862012052879064 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark05(-0.7999930194895546,-84.98441168734968,-86.23812108244255 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark05(-0.8003289094552906,-0.14647816162401273,-97.76794514827344 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark05(-0.8004681703474636,-0.3318210931216612,79.84355187551553 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark05(-0.8020146037909076,-1.5707963267948966,64.30701486406838 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark05(-0.8020189830719098,4.544883461617161,-2.234063930805789 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark05(-0.8022339830103168,-0.04260824013695757,1.4706223899844655 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark05(-0.8024428530535663,-16.073084563509525,96.21958610888476 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark05(-0.8037316825900875,-0.38683476474103823,44.01981516379719 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark05(-0.8038304475417022,-1.5707963267948966,-1.5707963267977756 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark05(-0.8040962573304853,-10.0671346339333,-86.71798182710609 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark05(-0.805151020344743,-98.46126681470389,175.4278804286215 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark05(-0.8053942213176688,-34.55849575198782,-0.8064293558409956 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark05(-0.8058951698671919,-41.599505053452184,1.5707963267948966 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark05(-0.8080526544430243,-0.044158052439279186,-0.8538531889303542 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark05(-0.8092973350746441,-42.05755663934002,34.653605902999246 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark05(-0.8118889815145743,-35.95567542658303,1.3383705842594367 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark05(-0.8123497198722314,-1.5707963267948966,25.558800325846804 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark05(-0.8124416262983071,-0.3834368024971955,-94.65782931552442 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark05(0.8128368987173786,-39.85802521827628,86.67338375529263 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark05(-0.8134053215155388,-47.54125171455301,-73.5342774532418 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark05(-0.8136773274679491,-3.1415928920088083,100.0 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark05(-0.8139684969976497,-0.8575280968010439,52.57436360596147 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark05(-0.8145647392068837,-0.27608377946534335,26.782808869131436 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark05(-0.8152348351168923,4.141592653630864,-56.889509982715325 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark05(-0.815292265263389,-15.881376242651505,0.5471733640785603 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark05(-0.8159959169715165,-98.12453708431737,35.81087566312462 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark05(-0.8162017532183492,-1.570796326794879,20.708888518878638 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark05(-0.816774126096079,-161.4816746284895,5.674958075596117E-15 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark05(-0.8169674127644533,-1.5707963267948961,63.00767027703314 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark05(-0.8174076249872559,-9.55666514796054,16.829285676509418 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark05(-0.8180059120905793,-34.905333705031765,-6.8156815245622795 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark05(-0.8190658242749681,-84.83207976327535,40.52075769313165 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark05(-0.8204459781019198,-1.5707963267948966,2294.633817065406 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark05(-0.8212290776352615,-41.79554886491933,1.5707963267948966 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark05(-0.8216236780286095,-1.349331328041682,1.5707963267948966 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark05(-0.8237399526584783,-1.5707963267948966,-0.6446699137204707 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark05(-0.8238845424363442,-0.7244419439815479,-58.92738641182321 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark05(-0.8242175111241281,-1.5707963267948912,27.109816009756987 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark05(-0.8260170022678316,-72.40082726811812,-45.768957623149646 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark05(-0.8263932646910114,-97.42184715880391,-1.5707963267948974 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark05(-0.8265644911811182,-1.5707963267948966,34.173568637470765 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark05(-0.8266980806501305,-2550.8493895495844,0 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark05(-0.8269680426042364,-9.617813513234637,-1.4533638764553833 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark05(-0.8294272198729402,-54.53380197358043,-45.24826252811028 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark05(-0.8300290122476943,-0.8767738407941972,-55.05149452632077 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark05(-0.830115132849556,-1.03730201419723,-1.5707963267948966 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark05(-0.8305460574057817,-1.5135843572427545,-41.24129344823173 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark05(-0.8312084364150201,7.427840208526168,0.0 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark05(-0.8313542006826463,-1.5707963267948963,-100.0 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark05(-0.8321339600635472,-13.805339796933936,9.55573012271192 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark05(-0.8322648392315433,-0.14348736247373067,128.8074371440051 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark05(-0.8327493077818633,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark05(-0.8329186421251507,-1.5707963267948966,78.79946039572717 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark05(-0.8332008714999135,-0.3243192104770223,91.80027800872924 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark05(-0.8334055433396217,-1.5707963267948966,-77.96278052519921 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark05(-0.8358051068973525,-1.5765180477682876E-17,-1.570796326767843 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark05(-0.8366653498145253,-1.5707963267948966,99.49236305680094 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark05(-0.8366829329464017,-3.1622356960223,62.86674084049929 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark05(-0.8367117749779371,-66.84881603275687,-1.5707963267948966 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark05(-0.8371527738101747,-41.91218898637571,-0.35524824769500185 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark05(-0.8374451836570431,-1.5707963267948912,4.141668825249196 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark05(-0.8382449949807147,-35.34545626305916,-97.58993987798621 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark05(-0.8383750750637959,-78.77953260955921,68.3559263840268 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark05(-0.8389654830980741,-54.55911287901938,92.6769832808989 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark05(-0.8399038374152249,-3.1416002829843355,41.58100715837074 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark05(-0.8399191865183151,-10.1229522577012,1.5707963267948966 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark05(-0.8412689890279359,-0.5821499313209219,-22.3389865922935 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark05(-0.8414344523990973,-36.091816411029306,-83.58283307834809 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark05(-0.8426119505402262,-98.78441283273564,-8.103983128631503 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark05(-0.8429707657937129,-34.5959133797355,-98.96016858807849 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark05(-0.8431465877700914,-41.06367430297324,78.06835284372119 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark05(-0.8433543371506901,-54.82101821969023,-10.149122255176579 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark05(-0.8436201040841076,-3.1415926540585364,55.06751553107696 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark05(-0.8438532283781203,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark05(-0.8459078632667709,-1.5707963267948966,-3.488120700934677E-105 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark05(-0.8469917061270991,-35.607971113645405,-105.61677991557514 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark05(-0.8470493530578977,-98.72022458702892,-49.81633567887063 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark05(-0.8480480997732159,-123.1997649383103,-9.424777967170987 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark05(-0.8494708343603866,-41.85210693105776,35.93357048136198 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark05(-0.8496172071626452,-0.2643350426773936,47.25732417701053 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark05(-0.8507438734823213,-35.73947257035748,-21.475121398223905 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark05(-0.8508760699206576,3.1415945609384917,-85.76753855545826 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark05(-0.8517236115815496,-1.5707963267948966,31.522743558383226 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark05(-0.8576481112558071,-1.2811101652044017,48.90356324658596 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark05(-0.8587370894910259,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark05(-0.8595598089003087,-34.62454607236945,-8.104025564901125 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark05(-0.8597048394108374,-1.5707963267948966,77.23828241641007 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark05(-0.8597607474600953,-1.5707963267948963,-69.54668737590058 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark05(-0.8606329153525962,-66.39897403884535,1.5707963267948966 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark05(-0.8620954523898262,-97.91495650158886,16.208991891346038 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark05(-0.862269574453199,-36.124921013904384,110.18996059286994 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark05(-0.8628219635397826,-41.68219757616747,-1.0404925798059517 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark05(-0.8630044541625019,-1.5707963267931075,20.16661425134866 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark05(-0.8632407040314191,-66.24272764447184,82.12146512672652 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark05(-0.8633784700927429,-1.5707963267948966,-28.37664282561032 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark05(-0.8634687398657555,-40.96634185542189,29.845130209103036 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark05(-0.8636483265409467,-3.344610262735555,27.464792649995324 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark05(-0.8640037317553788,-3.8206082465345236E-16,89.44301136724184 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark05(-0.8650828320551515,-1.7763568394002505E-15,-2338.871450477479 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark05(-0.8653394493616184,-0.2615599327149951,20.725712601716715 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark05(-0.865348823181165,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark05(-0.8654854109774941,-66.3606149028801,53.14892015742179 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark05(-0.8668481013620133,-54.8734801507322,47.76194567945606 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark05(-0.8675232192925746,-1.5707963267948983,0.9727733749078343 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark05(-0.868877844704114,-15.707963267948967,14.891453505314175 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark05(-0.8690079174118204,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark05(-0.8692265257567591,-53.407075111026515,99.49870981086985 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark05(-0.869580007663151,-185.87532484732364,50.15339964975496 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark05(-0.8696036580551172,-0.5022575269251656,7.853981639811559 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark05(-0.8706457393814091,-1.4896847414230292,4.712389191149104 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark05(-0.8711491409708527,-9.516352713410697,21.525911359871856 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark05(-0.8742807098131461,-1.5707963267948966,97.93413670289107 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark05(-0.8743767619475565,-1.5707963267948966,-55.191848648290936 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark05(-0.874797847090437,-15.809783420281676,89.53539062730911 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark05(-0.8748521899196181,-1.5707963267948966,541.907441333781 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark05(-0.8757377622540741,-0.5062234703596208,-3.266592690959964 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark05(-0.8761827986862109,-3.2029587817634117E-4,77.17578000433437 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark05(-0.8776150565175633,-34.904230194408846,-8.103981953099268 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark05(-0.8780213146673717,-42.200619702732524,0.0 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark05(-0.8780353609545277,-3.2667803756791187,-100.0 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark05(-0.8780669307398687,-1.5707963267948983,-67.1770069478544 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark05(-0.8784404604127785,-48.66942825814341,-53.495538768228975 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark05(-0.8787623574420396,-1.5707963267948983,935.0944020843706 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark05(-0.8802359236467848,-66.05398523420594,-14.467988654495826 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark05(-0.8803930192465552,-1.5707963267948966,1.5707963267948912 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark05(-0.8807042977436321,-1.2549950058777077,-90.93506841436064 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark05(-0.8808899060048571,-3.391253050934793,1.5707963358623478 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark05(-0.8816951668076587,-129.06350706326145,-21.792924708540255 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark05(-0.8817737707736522,-66.76851264192341,0 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark05(-0.8824490990085925,-1.5707963267948968,-48.024309621775316 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark05(-0.8825520765747825,-1.5707963267948966,-87.23484230065029 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark05(-0.8832225801557669,-3.1415926535928307,1.5707963267948966 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark05(-0.8837728233231041,-42.17036149797504,-21.758336676957015 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark05(-0.8839112051838587,-0.4739784198810304,1.2501172988612694 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark05(-0.8843562910777844,-1.570796326535717,83.95948081532362 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark05(-0.8849593588132052,-53.4539835301776,-1.5707963267948966 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark05(-0.8851667535677539,-1.0728508359415905,-75.53511745074401 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark05(-0.8856861682032031,-42.141450797295235,-79.61265462740771 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark05(-0.886245414506557,-67.82678315006429,-20.18696378480888 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark05(-0.8863816559578268,-15.950871750606414,-1.5707963267948983 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark05(-0.8871681100393587,-1.5707963267948966,-72.43763075392336 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark05(-0.8877935932706341,-1.5707963267948966,-79.58615911441376 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark05(-0.8894864401304067,-1.5707963267948966,80.11061268574211 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark05(-0.8917952388101483,-1.1102230246251565E-16,-6.28331730828965 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark05(-0.8923244440095719,-2.220446049250313E-16,-95.29435465384663 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark05(-0.8932888992289609,-35.68769402909818,-5.1977048828224496E-113 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark05(-0.8943589837082102,-0.540182785123565,50.068951069418546 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark05(-0.8943835447385304,-48.546087287260974,20.633080184752828 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark05(-0.8944647195173872,-0.5662184608102941,1.5707963267948966 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark05(-0.8948684810079316,-1.5707963267948966,-1.9225004440310112 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark05(-0.8953093243321892,-3.4648111740266643,78.70741441100616 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark05(-0.8955428568365765,-0.3910557668166701,-73.75631845650045 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark05(-0.8966743890568261,-35.7161711053877,76.6836135979539 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark05(-0.89686126906872,-0.6279209829643557,-21.93880977479484 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark05(-0.8973281586504308,-1.5707963267948966,-16.633307142409432 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark05(-0.8977933583184683,-1.570796326794886,11.233095874287045 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark05(-0.8979690199820201,4.141592653589871,-77.23487971866675 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark05(-0.8991846145856863,-1.5707963267948966,41.18148649003277 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark05(-0.900151661852151,-42.36984797765013,90.77734021085104 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark05(-0.9005968862170711,-1.5707963267948966,-35.23864096390096 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark05(-0.9009007587104961,-1.5707963267948966,0.03903757642252978 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark05(-0.9009191357660024,-1.3184238867817462,6.283346980899458 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark05(-0.9014062878911233,-1.5707963267948966,-49.91419573967448 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark05(-0.9025920781693202,-15.974722866343786,60.53393264980643 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark05(-0.9029392830951364,-0.008033230813097154,-21.635526862905145 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark05(-0.9030816284952974,-1.570796326794897,72.14196163042925 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark05(-0.9044263103422127,-16.175237001537653,83.25220532012952 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark05(-0.9057783039596615,-122.7363016534752,-132.8694900487315 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark05(-0.9061864387504595,-1.5707963267950533,183.30557628617072 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark05(-0.9067958631233985,-35.126126009217415,-16.610030827247186 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark05(-0.9078749107828306,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark05(-0.9079715277433076,-72.40627440069034,-1.5707963267948966 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark05(-0.9095707681092071,3.187461867172195,56.78284343046447 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark05(-0.9109686473669975,3.142080935767495,0.0 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark05(-0.91137210349183,-1.5707963267948966,84.13515586901968 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark05(-0.9117138435487916,-0.36068139706800967,56.094206288306566 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark05(-0.9120055204157991,-1.5707963267948912,-2272.8759889865837 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark05(-0.9128295622648686,-0.1091032349026417,1.5707963267948966 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark05(-0.913306525303091,-84.95590526816328,-0.18440473544486208 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark05(-0.9139951046963359,-1.4364377048666115,1.5707963267948957 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark05(-0.9142725914747137,-1.5707963267948966,66.08484475658702 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark05(-0.9150656568335632,-191.85573582230893,5.141592655017425 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark05(-0.9151304911247682,-1.5707963267933467,0.0 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark05(-0.9157424071944086,-0.11333600892517545,0.7951465130597573 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark05(-0.9158883402876856,-1.5707963267948966,58.6711043442671 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark05(-0.9161480804834383,-41.02329943546918,49.916506399220346 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark05(-0.917189218170267,-1.5707963267948966,-87.11713296933539 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark05(-0.9173255987397306,-1.5707963267948966,-14.169821560668183 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark05(-0.9181596490188825,-3.5923122951079307,21.658601909456436 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark05(-0.9205360856268414,-1.5707963267948966,26.574899736125065 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark05(-0.9205463398223713,-1.5707963267948963,-1.5707963267948966 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark05(-0.9209063164691598,-10.206076708791706,-3.169036909865245 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark05(-0.92242760064687,-0.5612440994487126,-19.913094462883357 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark05(-0.9241280056509558,-1.5707963265360858,-1.5707963267948966 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark05(-0.9244952551133141,-9.943312885148941,-1.5707963267948963 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark05(-0.9250375990766884,-1.5707963267948966,-68.95194435065201 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark05(-0.9260418468428551,-41.92900361354135,0.0 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark05(-0.9270590622606658,-1.5707963267948963,1.3602258126964024 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark05(-0.92748490959152,-1.5707963267948966,7.816453102790754E-16 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark05(-0.9280448690645687,-60.799305395,-303.1613373909896 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark05(-0.9281370666277109,-1.5001945991683137,84.5295435017048 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark05(-0.9283676040853948,-1.5707963267948912,88.63681972317079 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark05(-0.9293625044074063,-0.5016203355061699,-92.82015313311021 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark05(-0.9294920394352663,-16.028846556454184,37.231358315974205 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark05(-0.931497993332469,-0.1646496294904513,7.861850128639973 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark05(-0.9315111662984945,-0.30435065028115393,-806.6966908273223 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark05(-0.9335807146029058,-1.5707963267948966,-210.43396816748768 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark05(-0.9337423547648994,-1.5707963267948966,27.96705321228889 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark05(-0.9358734125006404,-0.03920972612453887,65.07166343350148 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark05(-0.9361763933592165,-16.10995692667185,55.98603326925135 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark05(-0.9388381374257495,-66.28163273094798,-56.980707419427645 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark05(-0.9388715261044276,-1.463958781973389,-97.9820461066933 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark05(-0.9393559301268017,-1.5707963267948966,-1.5707963267948986 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark05(-0.9403686117313015,-1.5707963267948966,52.96457722762058 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark05(-0.9404513878660985,4.141597305360383,-6.28336060172564 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark05(-0.9409721707352184,-1.5707963267948966,43.53706290483006 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark05(-0.9414686650130515,-538.6978882336856,82.82150900115914 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark05(-0.941597986112608,-1.5707963267948961,-30.99267175768297 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark05(-0.9419784894571791,-97.96145146281586,0.5220370904839272 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark05(-0.942752987871337,-1.5707963267948892,-0.052164432128156524 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark05(-0.9436439738772876,-3.500706764083361,77.20509861925056 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark05(-0.9442717905268978,-1.5707963267948963,-47.82811198232035 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark05(-0.946773822315459,-1.5707963267948966,15.339540952483956 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark05(-0.9469667675189379,-48.28494426879393,-76.66373519181874 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark05(-0.9471434404290271,-1.5707963267948966,-85.05053591463346 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark05(-0.9472646831376345,-48.27290970082723,-7.85398167732863 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark05(-0.948113695596501,-54.638068835874655,-1.5707963267948966 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark05(-0.9483565380169351,-0.10958112526275246,26.70353755551324 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark05(-0.9490122736576401,-1.5707963267948966,-55.29699743527139 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark05(-0.9497471330789349,-35.36293847685354,26.862565927013602 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark05(-0.9500245682653743,-0.24447727354181692,168.4339182223609 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark05(-0.9507398306995803,-1.5314109456046616,-47.12486636634779 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark05(-0.9521345790141422,-2.0303534698525194E-115,63.41519452963854 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark05(-0.9522175044577068,-0.4417008245571308,-1.570796326703876 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark05(-0.9528672998317171,-300.1908020748128,1.439423448562016E-4 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark05(-0.9571303206091502,-3.1682886095749723,47.07211819555975 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark05(-0.9575789753901794,-1.5707963267948948,1.5707963267948948 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark05(-0.9578103416427459,-42.350369188746306,239.89632455457047 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark05(-0.9581815763394628,7.865967025002896,8.1213470607292 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark05(-0.9587431951849901,-1.0087542680713995,56.16676414421072 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark05(-0.9602964051918053,-0.8797576175443962,0.4861685365548394 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark05(-0.9615336370163892,-98.22574563708166,1.5707963267948966 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark05(-0.96213279551817,-0.08885027921790266,59.645026454566676 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark05(-0.9630457635291687,-0.15402107457819014,-1.5707963267948983 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark05(-0.9633283301006532,-198.48343722586563,92.2426307173786 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark05(-0.9653810189365375,-1.5707963267948948,20.525360837497786 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark05(-0.9658096579072377,-1.5707963267948966,-53.99750929552043 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark05(-0.9662831125240131,-3.1435457807344656,-32.6944265178025 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark05(-0.9678227616140465,-0.6664233737772409,-44.61184217489398 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark05(-0.9681009267972185,-10.326076367873455,13.969933083316281 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark05(-0.9690120429974406,-1.5707963249473917,-55.16964835745928 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark05(-0.9692691093170087,-0.520761250780959,8.103981633977392 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark05(-0.970015175979333,6.459625819110326,-1.5707963267948966 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark05(-0.9701174228801418,-411.8005962998451,84.65955984074475 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark05(-0.9701777030127966,-111.32988608893179,3.266592720965256 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark05(-0.9724306588325701,-1.5707963267948912,897.968397447971 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark05(-0.9726155860941454,-1.5707963267948966,155.48798597011887 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark05(-0.9741734254503629,-85.03937464327608,-1.5707963267948966 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark05(-0.9744169205259867,-66.07957677958345,-100.0 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark05(-0.9744358849518946,-0.09087585505682466,-56.51595629557714 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark05(-0.9746863801546917,-0.08755653190458557,1.5707963267948963 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark05(-0.9747714685257787,-1.5707963267948966,19.186291608913624 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark05(-0.9748028984712795,-1.5707963267949019,-17.02636327155281 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark05(-0.9750267431220679,-1.1270725851789228E-131,58.29982686395983 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark05(-0.9760322157928671,-47.278827213049986,-7.853983122166194 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark05(-0.9768579409829803,-54.73358779666464,28.138832150862065 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark05(-0.9772420327110554,-36.11562753902196,-1.5707963267948966 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark05(-0.9777233975640485,-1.5707963267948966,-62.17270879093648 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark05(-0.9779159872984544,-78.55962959886848,-35.655323512104985 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark05(-0.979024925439826,-4.087093452475607,25.799329422244796 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark05(-0.9797474176423344,-41.505331465721696,50.02524323876284 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark05(-0.9801675304189981,-1.5707963267948966,447.29443759243156 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark05(-0.9809856303439006,-40.84583601401512,-1.5707963267948966 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark05(-0.9815650747350299,-35.67951978566691,10.299175964665743 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark05(-0.9820769980857792,-3.2962355298626704,34.65582386326449 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark05(-0.982191655238047,-54.91289110061302,28.396803132593536 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark05(-0.9827418946887602,-0.7614942512076268,-494.781839435912 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark05(-0.9830370432422342,-48.139484199800876,-3.141592906933486 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark05(-0.9837859914751457,-1.5707963267948912,57.74554896686982 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark05(-0.9841248705254768,-1.5707963267948974,78.44598974887805 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark05(-0.98441454843448,-1.5707963267694403,57.05639898611116 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark05(-0.9848192597241836,-2.465190328815662E-32,-53.559060585635756 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark05(-0.9848552152352026,-1.5707963267948966,80.86460916168929 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark05(-0.9852306957518199,-0.2756750610917598,-0.009469349791278963 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark05(-0.9855131397169294,-1.0290922282554644,6.28320056598018 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark05(-0.9859015561528517,-154.34142517058496,-14.429205492522556 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark05(-0.9861483469905127,-9.64940759826088,-42.134432058230864 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark05(-0.9866324161542102,-1.034628168397052,78.60538702879954 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark05(-0.9870971579059784,-1.5707963267949054,100.0 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark05(-0.9875662182953749,-60.81678089329512,-1051.6457057579953 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark05(-0.9879869929450752,-1.5707963267948966,61.401437287579355 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark05(-0.9883616654234849,-3.141687134795914,-69.6602341945665 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark05(-0.9890497835222378,-1.5707963267948966,28.056196330334274 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark05(-0.9891517985722131,-1.1129259611473217,-77.44105453587444 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark05(-0.9901159805709066,-1.5707963267948966,-80.21491718635805 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark05(-0.9908182375853016,-72.45908029397162,-48.47187082083075 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark05(-0.9909618883226755,-66.62334063071341,-61.402503090763005 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark05(-0.9916949970250403,-0.34274533002338614,-39.01771816607073 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark05(-0.9921928049341162,-0.2829806258500651,118.10523895308978 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark05(-0.9936995919784115,-72.99893349625833,4.3920042409114295 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark05(-0.9939318586708773,-35.44916667210884,41.95973777716357 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark05(-0.9957411980171247,-3.16672992825022,-416.25996535310423 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark05(-0.9959193381853912,-1.509435888602396,-1.5707963228018305 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark05(-0.9961659792394929,-0.38857322023263674,1.9742063534922827E-177 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark05(-0.9965356412273149,-0.22762856013955157,82.56493787273959 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark05(-0.9966705218450678,-66.25237104033965,-6.34332351146773 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark05(-0.9991379306453301,-35.49505359771216,20.839724098440268 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark05(-0.9998208357264957,-0.15930224925098446,1.5707963267948966 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark05(-1.0007143449190306,-10.245446091203036,62.114623665818954 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark05(-1.0007693894297063,-0.23095578775986114,-37.33634411719049 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark05(-1.0029633698970617,-1.7763568394002505E-15,-90.79944275446583 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark05(-1.003777684700912,-66.82043312989845,42.285586781806444 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark05(-1.0038073749024899E-7,-1.5707963267948966,1.566263513047861 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark05(-1.0041047690068317,-72.87271633795997,210.36534984356274 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark05(-1.0054166472308943,-98.85721471673855,1.5707963267948966 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark05(-1.0057181738437242,-47.55322961583826,-88.40389574535945 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark05(-1.0058665655093209,-1.5707963267948961,-45.476617532545745 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark05(-1.0063561033901535E-7,-1.5707963267948966,58.11770866811667 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark05(-1.008084465544934,-28.372923754255957,-89.5702324163938 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark05(-1.0099494666763578,-0.15952814798246284,1.4524420089136383 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark05(-1.0100450709433444,-16.065367863603,94.88692000556499 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark05(-1.010776362995479,-22.306132284288687,-157.17889742940218 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark05(-1.0111727227535576,-3.9539146220091084,-97.63753936435117 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark05(-1.0115906689089038,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark05(-1.0117465776785366,-48.63639923072224,85.72406480647882 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark05(-1.0119199134735161E-6,-161.71588898535876,10.995574287564276 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark05(-1.0120667893370117,-48.88586838165685,-1.5380883686219053 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark05(-1.0131458396752904,-1.5707963267022498,56.302114062894745 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark05(-1.0143879880884277,-1.5707963267948966,26.312075222716928 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark05(-1.0145924742165846,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark05(-1.0156064109795522,-0.49436895994853236,0.0 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark05(-1.0157676199612524,-167.26994837503278,-612.5533408583519 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark05(-1.0165712574551526,-0.42313715004431585,-63.59960690021298 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark05(-1.0169810048323464,0.026992228514146763,-45.163902858848346 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark05(-1.0171084081466952,-122.90016832698934,-34.674959808548415 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark05(-1.0173140930185127,-1.5707963267948966,15.762551588209945 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark05(-1.017794867703262,-1.5707963267948966,-95.63607970469695 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark05(-1.0179377840445358,-0.5642970373725101,86.35860829912966 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark05(-1.0181303210726242,-1.570796326793826,-20.251942645820208 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark05(-1.018494214833939,-3.581551216842329,1.5707963271751404 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark05(1.0185832160099142,-1.2560552995692897,78.69288899670272 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark05(-1.0188737006357083,28.70353755551336,-46.67247564563507 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark05(-1.0190297727000217,-0.3159074147299604,-96.22101590483653 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark05(-1.0197795086224035,-1.1102230246251565E-16,83.39340979455062 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark05(-1.0198350001734398,-66.50782132580552,-0.75227326132439 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark05(-1.020247727514735,-1.5707963267948966,-29.845130209103036 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark05(-1.0203460822510948,-1.5707963267949019,58.28288590159096 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark05(-1.0205445354864007E-14,-1.5707963267948966,38.80347949953629 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark05(-1.020649059688239,-1.5707963267948966,77.99627831012978 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark05(-1.0214094911479004,-595.1800217240481,-1.5707963267948966 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark05(-1.0225582433684013,-1.0842021724855044E-19,1.4141230247537162 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark05(-1.0243899486359458,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark05(-1.0248155005224069,-0.0257966819882907,66.70342437432767 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark05(-1.0259030459015648,-160.91051516671683,8.10398325505396 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark05(-1.0267678519665253,-122.75182146690248,-86.77191223406118 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark05(-1.0270219927763944,-1.4212221939284273,41.24126668361342 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark05(-1.0270393482882336,-1.560721357898701,-20.46692188934402 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark05(-1.0272119614404,-1.5707963267948966,20.782520016206377 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark05(-1.0291699464417945,-66.50096274890277,-1406.2892265206951 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark05(-1.0295685938811838,-42.051935327069934,36.29196873580872 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark05(-1.0303463351115705,-1.5707963267948966,5.141595391636912 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark05(-1.0313067533664562,-1.4489728811105912E-16,57.2326566835235 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark05(-1.0319974036964936,-100.0,12.984144018273136 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark05(-1.0322422810407028,-79.01453124583199,-12.568442552744612 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark05(-1.0334265899560409,-0.3897343381601943,70.66455269440014 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark05(-1.033444508871672,-1.2513019344894381E-147,-52.89964174663608 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark05(-1.0335826614050045,-48.252360019555304,-92.86178638232184 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark05(-1.033595216906173,-73.18205511981387,-32.75226628240358 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark05(-1.0341049137975973,-1.5707963267948966,-8.752340976526789 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark05(-1.0341099802758817,-0.060749596930268775,-1.570796330729502 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark05(-1.034288355715245,-1.5707963267948966,0.06244523439502769 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark05(-1.0347563741753647,-84.90689472214106,-99.33883674964935 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark05(-1.0356154273512175,-0.23354811292256272,-333.1176776358074 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark05(-1.0371362340882198,-0.7001962633695903,-32.57212839526544 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark05(-1.0375627638373592,-1.5707963267948966,101.98442482549117 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark05(-1.0376013123456382,-61.048040759424815,3.1420809927760507 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark05(-1.0378662867229167,-0.49893360577178353,-77.98573984251864 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark05(-1.0381189025249253,-1.5707963267948966,-91.35155892393757 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark05(-1.0388649939126187,-97.7605168008338,1.5707963267948966 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark05(-1.0389010305229245,-0.37417888030842444,-3.1415929781956984 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark05(-1.0392695291641973,-1.5371654501535545,32.635117443440585 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark05(-1.039447563573063,-1.5707963267948966,28.193006617619563 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark05(-1.0400127390385974,-0.48149543552694496,-0.696469046647235 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark05(-1.0400761951090988E-178,-1.5707963267948966,-1.5707963267948957 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark05(-1.04110674916216,-48.629143661591975,0.30547668710726006 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark05(-1.0415753228310574,-15.7922351040212,-4.3225817678266135E-224 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark05(-1.0418430462863597,-1.0673426383251297,-26.13916183656663 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark05(-1.0422857826516536,-1.5707963267948963,81.76988120415183 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark05(-1.0425016669691045,-48.645961946932495,0.0 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark05(-1.0425215310867304E-15,-2.220446049250313E-16,94.67269383111017 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark05(-1.0430846905456441,-48.27254390576818,-1.5707963267948966 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark05(-1.0432195079697504,-1.5707963267948966,-92.66649638110441 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark05(-1.0443195484414451,-104.19665986053077,111.18552322018054 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark05(-1.0444708470440696,-5.69316119069974E-11,117.17635562381943 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark05(-1.0447115087307282,-0.2458412704302318,-110.19666610348925 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark05(-1.0448091683242813,-1.3012917970839282,-1.6622127194038627 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark05(-1.0448939490380669,-2.8890438267709123E-17,-55.267795576540315 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark05(-1.044917234914224E-7,-1.5707963267948966,20.446572406676182 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark05(-1.0449292835850803,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark05(-1.0458872621718693,-1.5707963267948966,96.49886401066021 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark05(-1.0462952904036995,6.589122129969238,83.29760097028631 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark05(-1.046899370308861,-0.5219698547942527,-19.16179941663465 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark05(-1.047109641990968,-1.5707963267948966,-8.25150392079082 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark05(-1.047313836023727,-78.96466174428694,0.0 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark05(-1.0486043934553986,-1.1786680336454447,770.2827283731165 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark05(-10.494624662318031,-95.30221230467524,30.782822790327714 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark05(-1.0496174942003418E-16,-1.5707963267948966,8.813866031600215 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark05(-1.0499603856596238,-1.5707963267948966,-26.812192170677875 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark05(-1.0501247114253998,-0.09214899932028131,45.430919677610206 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark05(-1.0511653481468366,-66.33539283749795,1.5707963267948983 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark05(-1.0513478783084833,-66.9417249916292,75.99382201736755 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark05(-1.0516931563827776,-0.5561054720802361,-36.4997890328235 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark05(-1.051850267913449,-0.3469451889529954,0.0 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark05(-1.051941073437348,-3.1576356247128716,-96.33944946847048 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark05(-1.0526481427512702,-0.7301513364193957,-0.6647513761706279 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark05(-1.0527200691891863,-18.008632300331087,8.293519648440792 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark05(-1.0528287154654905,-47.200546622240026,-8.42477797994796 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark05(-1.053493968778641,-1.5707963268531977,2.8952327124946415 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark05(-1.053675231503846,-98.53073607548416,181.91345685773183 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark05(-1.0537772778107355,-1.5707963267948948,60.34977187035619 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark05(-1.0539289325152352,-34.636213326343096,296.8147363313976 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark05(-1.0545198075569908,-1.5707963267948966,-42.63374143590304 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark05(-1.0553178144107943E-227,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark05(-1.056744673478024,-1.5707963267948966,-20.47052233477674 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark05(-1.056817006494463,-9.496039308718638,8.413745606979107 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark05(-1.0579594179161678,-35.6732356683361,40.14926997237228 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark05(-1.0583170817712384,-3.14159265362787,-16.07097564635519 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark05(1.0587911840678754E-22,-0.164059306190512,53.40707511102649 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark05(-1.0587911840678754E-22,-1.5707963267948966,89.53548796676104 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark05(1.0587911840678754E-22,-3.362059237305085,-35.26458932982125 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark05(1.0587911840678754E-22,-66.69873205573832,33.6588986204157 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark05(-1.058902085907775,-22.294700614571177,-83.26398517173867 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark05(-1.0599965047071966,-1.0814572416300052,-3.266592654161537 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark05(-1.0605365812451983,-9.424900031082837,-38.454634554385464 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark05(-1.062001633994182,-0.32790267290241376,69.79080718538911 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark05(-1.0625494405282732,-1.5707963267948961,1.5707963267948966 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark05(-1.0635716602173195,-1.5707963267948966,-4.712412018461225 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark05(-1.0644633172602056,-1.5707963267948966,7.492198988910118 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark05(10.646441623776838,-17.844088930533403,-15.673026562041613 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark05(-1.0647292071969687,-1.5707963267948957,85.93189542605818 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark05(-1.065103924421848,-1.5707963267948344,-15.287078526445441 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark05(-1.0667502117994216,-9.603510225570332,-82.57445157517482 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark05(-1.0669368653696236,-3.141601189908749,6.197777308600134 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark05(-1.0670975551128754,-98.7589585975308,1.5707963267948963 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark05(-1.0688495969699119,-0.3554454660335454,-1.5707963267948966 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark05(-1.0708574910874322,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark05(-1.0722294678219413,-61.10661680393238,18.061986785018576 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark05(-1.0722876513763158,-48.132391328132336,-4.7124019823431444 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark05(-1.0737102811843187,-0.06781535636930891,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark05(-1.07405783918264,-1.5707963267948966,-89.19481424099865 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark05(-10.764533045736883,-43.02929934463107,23.75729130383087 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark05(-1.0767000982184124E-16,-1.5707963267948966,35.83841096933994 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark05(-1.0768136089751708,-28.397083845059655,-4.144116195327108 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark05(-1.0770449609196346,-0.35198374093394863,26.06772557513994 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark05(-1.077871028077162,-0.35511703823773255,1.5707963267948948 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark05(-1.0782113384835759,-48.58780994757268,62.000345840854976 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark05(-1.078439481863538,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark05(-1.0787475022071507,2.7744599600143363,41.06879403953076 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark05(-1.080245877501668,-1.5707963267948966,-3.1415926547224937 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark05(-1.0806454419566534E-224,-1.5707963267948966,-69.21987162288815 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark05(-1.0808486311748833,-0.4644646461973436,-28.743146004671445 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark05(-1.0809176362265605,-3.5998390670719687,1.5707963239093081 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark05(-1.0825310495780538,4.141640478885613,-521.7434099268098 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark05(-1.082612578075981,-1.5707963265758786,-161.24407616531602 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark05(-1.0837749619066646,-1.5707963267948912,-56.19787790283229 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark05(1.0842021724855044E-19,-0.5754108085939408,-1.5707963267948966 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark05(1.0842021724855044E-19,-1.265686000177955,-24.564330132061617 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark05(-1.0842021724855044E-19,-1.5707953004763402,-25.13665284062443 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark05(-1.0842021724855044E-19,-1.5707963267948966,-2.465190328815662E-32 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark05(1.0842021724855044E-19,-48.22583436840233,-77.87473157160612 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark05(-1.0851885307840157,-97.41665629892229,93.86931337024598 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark05(-1.08524951258741,-1.5707963267948912,10.339807049929782 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark05(-1.0853314206470105E-165,-1.5707963267948966,36.21377364001751 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark05(-1.0854890400934818,-22.399861228674045,-9.912952110362411 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark05(-1.0855027617043405,-66.43230866704789,-10.91725973714177 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark05(-1.0868936272665977,-1.5707963267948983,-347.1458544151583 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark05(-1.086899454089196,-2.1684043449710089E-19,32.16869534211986 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark05(-1.087674992838267,-53.47637336589237,100.0 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark05(-10.878441471073927,98.74530062417605,8.76771190951456 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark05(-1.0882422495113402,-1.5707963267948966,-52.97105864208069 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark05(-1.0884540184915128,-0.010951994292713837,40.73554681239413 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark05(-1.088487608484158,-47.53375874725114,38.82044913743985 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark05(-1.089058315333773,-1.5707963267948966,-30.007989976332734 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark05(-1.0892697855611568,-1.5707963267948966,-1.5707963268167404 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark05(-1.0897765091077691,-1.5707963267948966,-920.190707350062 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark05(-1.090152066566784,-0.042905522437196086,-99.59468474051565 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark05(-1.0902034035048145,3.173139214220575,1.5707963267948966 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark05(-1.0904776808556844,-1.570796326577143,-88.05884194613816 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark05(-1.0907510728312837,-66.79091542114156,-98.41803756058168 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark05(-1.0922857000092776,-1.1738051029804535,6.283185307179591 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark05(-1.0926196660533187,-3.1435457785947407,12.596168537090975 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark05(-1.093188753893833,-1.5707963267948966,-92.59447585816781 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark05(-1.0934967791128798,-601.6009247052249,15.410329380331447 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark05(-1.09518287969943,-0.07196356359716616,7.854007544773003 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark05(-1.0960237771858299,-1.5707963267948966,11.772280518563164 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark05(-1.0960780591502477,-1.5707963267948966,5.141592653589794 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark05(-1.0969123527219213,-34.60529496337044,-20.42035500644709 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark05(-1.0984518077495498,-1.5707963267948966,59.24591532913908 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark05(-1.0988483462762173,-100.0,7.534407294747157 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark05(-1.0996274129152201,-1.5707963267948966,0.7193177592133381 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark05(-1.1000191164729034,-0.30133163034066,0.18298316801387476 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark05(-1.100296987849355,3.944304526105059E-31,-46.54845040760989 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark05(-1.1012762860889713,-1.5707963267948966,-16.26000305618138 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark05(-1.1015220153257257,-1.0837238257292432,28.920331202573834 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark05(-1.1016502085496818,-1.3316222114082732,5.141592661162734 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark05(-1.101932338520598,-1.570796325385237,8.3330178740426 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark05(-1.1022933551320717,-1.5531118741705026,83.3713320352993 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark05(-1.1034542726363523,-1033.7073842546224,-1.5707963267948966 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark05(-1.1047001313193636,-1.5707963267948966,-60.969947863907414 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark05(-1.1061837626776574,-0.7144863421175308,55.14579081611698 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark05(-1.10676326158742,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark05(-1.1067644430725778,-0.17788723784477284,1.5707963267948966 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark05(-1.106845247339414,-1.5707963267948948,72.70985498848287 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark05(-1.10736318213447,-1.5707963267948957,100.0 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark05(-1.1093255522206746,-0.45069639399683614,-100.0 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark05(-1.1095790051957044,-1.5707963267948966,-73.17942347809972 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark05(-1.1101049192890173,-1.5707963267948966,21.81187698377271 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-0.046370238898264145,32.52350498865829 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-0.07246626398379373,-48.77718397406244 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-0.2847128508822138,-76.51700017584447 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-0.44807674154353744,32.210052651513124 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-0.49442915854647107,60.82330898065328 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-0.5100806360886074,-98.84550700582469 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-0.6185377864008217,-35.66686803980788 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-0.7745548666945501,63.09876964065814 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-0.9257415561816495,21.991149353097168 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.0842021724855044E-19,-0.6185716956316951 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.0852661590257873,-53.56073621015052 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.185684827092609,58.052891808412824 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.263138804455547,-100.0 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.3447683038596923,0.0 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.3524305221781627,-83.11570840534684 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.5705757110075445,-70.81219484437007 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.5707963267888982,1.5707963267948966 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.5707963267937706,35.223720390226795 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.5707963267948957,28.360794978365327 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.5707963267948966,13.647065353061292 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.5707963267948966,-21.553974174397133 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.5707963267948966,-22.588859219187036 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.5707963267948966,-32.44624172027521 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.5707963267948966,32.849199140168786 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.5707963267948966,-4.141592653601949 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.5707963267948966,-56.632194923534 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.5707963267948966,70.9908953772893 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.5707963267948966,77.44700600351175 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.5707963267948966,87.9683437320591 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.5707963267948968,74.42193197692274 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.5707963267949008,50.59241753540367 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-2.85845488146334E-15,-27.169625261602896 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-35.08250280512958,6.284161869679763 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-35.282497871386326,49.30963185350765 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-4.002165965133783E-18,-1.2537683456875883 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-47.3549623217945,-77.35047618381802 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,7.658499449383215,57.46457785213242 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark05(-1.1105488967817625,-66.79277348379874,2376.4451963018623 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark05(-1.1113793747425387E-162,-1.273751504410922,-92.52334701223172 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark05(-1.111414148486773,-66.37417354837139,43.57432713136594 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark05(-1.1119850406230563,-0.5802447946891447,-37.30222723604211 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark05(-1.1120424400983113,-0.8994087601125003,114.65305408463038 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark05(-1.113202728080003,-2.4223884568381186E-17,-8.767237396033612E-193 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark05(-1.113815379104454,-1.5474099477708114,-5.815168399889586 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark05(-1.1139197986429725,-1.2752587191793265,-22.8686647702857 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark05(-1.1164003209342104,-9.53459363584112,-44.226081746011694 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark05(-1.1167011962810354,-1.5707963267948948,-8.114226933297367 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark05(-1.1182071880095226,-1.0302636199084803,42.9515029220386 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark05(-1.1182340957234165,-1.5189859868151632,55.258545355590684 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark05(-1.1183533561155226,-9.497450085022777,-1.5707963267948966 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark05(-1.118753773044002,2.0679515313825692E-25,35.086830274469925 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark05(-1.1192842192768977,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark05(-1.1193222772750746,-1.1102230246251565E-16,-0.6034030817835158 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark05(-1.12009391510105,-98.93212188224382,67.90065008215777 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark05(-1.1202071156451456,-1.5707963267948966,40.99190637000612 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark05(-1.1204862809017241E-4,-1.5707963267948966,0.688002459801617 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark05(-1.1210250819265042,-1.5707963267948966,69.24166643646691 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark05(-1.1212921766754234,-0.030963916651645433,-1.570796326794897 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark05(-1.1219675579868376,-54.80557873211599,-72.46502059403522 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark05(-1.1221548988025494,-1.5707963267948966,85.56318037929424 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark05(-1.122217944953376,-1.5707963267948948,25.827486530344615 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark05(-1.1224265930849762,-1.3127357224246765,-1.5707963267949507 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark05(-1.1225600562149844,-1.5707963267948966,12.566375421601455 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark05(-1.122581495033255,-1.570796326793117,1.1699419752276652 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark05(-1.1230166143924452E-14,-1.5707963267948966,9.174922788878177 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark05(-1.1235755843602362,-0.20422738827918527,-290.803224453633 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark05(-1.123621097811907,-9.936190199824434,-100.0 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark05(-1.1239884763415975,-28.277560011992357,-0.792609805444727 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark05(-1.1248778085030509,-60.70985755783653,91.41419114859917 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark05(-1.1252216962104945E-14,-1.5707963267948966,81.12627801076013 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark05(-1.1253409557727867,-1.5707963267948966,-1.0346279032841421E-15 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark05(-1.1275008063630738,-8.673617379884035E-19,-95.1810849335526 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark05(-1.128039108446149,-66.96339206366616,1.5707963267948966 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark05(-1.1293707752904831,-0.3519921957665972,40.840704496667314 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark05(-1.1299063084924346,-15.761064585755506,625.2630501515338 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark05(-1.1299442124514865,-1.5533221553225238,-6.284165704368225 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark05(-1.1300501798474958,-3.1415929069340804,1.5707963267948983 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark05(-1.130739225322503,-1.5707963267949023,272.13073441290953 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark05(-1.1311663762316893,-0.4829650328570789,-87.34165994778633 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark05(-1.131959884853339E-72,-1.5707963267948966,50.98223602858197 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark05(-1.1328017794678917,-47.6113101344643,-0.44822254985301097 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark05(-1.1328875186502358,-0.04321816847752316,-32.83258881821109 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark05(-1.1332146434966894,-1.5707963267949,0.9055663128242566 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark05(-1.1336616871352443,-1.5707963267948966,-8.103982921698488 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark05(-1.1338858278812481E-14,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark05(-1.134499031133887,-1.0942900516350826,6.947462593553745 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark05(-1.1347259997444508,-6.73528287352962E-15,-1.5707963267948966 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark05(-1.1347802201831145,-0.06482929007284798,1.5707963267948966 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark05(-1.1352111433429246,-34.66988231918884,89.65970611446963 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark05(-1.1356226227680482,-1.5707963267948966,-56.474385068781594 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark05(-1.13692683717969,-60.723430086967966,-50.97092105733896 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark05(-1.1371509415463423,-35.92166381040361,95.29460688461025 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark05(-1.1381330457400185,-0.07829644932208346,-1.5707963267948966 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark05(-1.1390408734284592,-72.93484966986048,-1.5707963267948983 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark05(-1.139160805273999,-41.38951506538068,-67.05556227287947 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark05(-1.1394151032780933,-1.5707963267948966,26.077159110205216 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark05(-1.1399337453672933,-550.4461317824367,-0.1123573792559398 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark05(-1.1402717981759558,-35.281588861537855,57.50120787093914 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark05(-1.1410016249787327,-0.5946078228936837,-47.61134238681441 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark05(-1.1410548782619798,-1.5707963267948966,4.3601508761683463E-106 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark05(-1.1417959467971868,-1.5707963267948961,77.2261525252702 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark05(-1.1421862588019325,-66.07386143138669,57.610984230758376 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark05(-1.1422315504369616,-98.45492348512674,-100.0 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark05(-1.1423291502497337,-0.2503426088255375,-0.939456144301051 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark05(-1.1424477154163417,-1.570796326794896,-14.604268554124218 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark05(-1.1426577662950148,-0.34317346997218146,-90.51204078239682 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark05(-1.1432310476091487,-1.5707963267948966,1.4621943418488152 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark05(-1.1438513230857037,-1.4683110940810218,31.875953334744892 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark05(-1.144136339431625,-1.5707963267948952,4.712389702455276 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark05(-1.144201208799712,-1.5707963267948968,61.13796638653897 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark05(-1.1442718277381236,-1.0771144151842975,180.6871177542033 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark05(-1.1446535501720891,-105.0459512982204,-19.191575455315473 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark05(-1.1467783618197407,-41.965486674012595,-41.66842026686004 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark05(-1.1471275476981702,-1.570796326794626,-8.158027175873315 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark05(-1.148136069408825,-9.535258784652363,6.298862250904046 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark05(-1.1486314588524469,-3.1435467527306713,-122.94047119216421 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark05(-1.1491107539091772,-98.14726974256625,39.62614282424215 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark05(-1.1493359628182929,-1.5707963267948966,37.075000889801984 ) ;
  }

  @Test
  public void test2476() {
    coral.tests.JPFBenchmark.benchmark05(-1.1495222211761695,-1.5707963267538487,-103.78128892675132 ) ;
  }

  @Test
  public void test2477() {
    coral.tests.JPFBenchmark.benchmark05(-1.1497644501647823,-694.3522735238691,-78.802374903806 ) ;
  }

  @Test
  public void test2478() {
    coral.tests.JPFBenchmark.benchmark05(-1.1508105491423715,-1.4523369738402763,14.473343454623155 ) ;
  }

  @Test
  public void test2479() {
    coral.tests.JPFBenchmark.benchmark05(-1.1509149045416662,-22.25240172451616,-1.5707963267948966 ) ;
  }

  @Test
  public void test2480() {
    coral.tests.JPFBenchmark.benchmark05(-1.1525939547239061,-0.9756969104075234,1.5707963267948983 ) ;
  }

  @Test
  public void test2481() {
    coral.tests.JPFBenchmark.benchmark05(-1.1530626528192225,-47.59276628926209,79.27856846324511 ) ;
  }

  @Test
  public void test2482() {
    coral.tests.JPFBenchmark.benchmark05(-1.1539409591987475,-98.73787389090471,-30.904471000071712 ) ;
  }

  @Test
  public void test2483() {
    coral.tests.JPFBenchmark.benchmark05(-1.1539961021649652,-34.55936633247207,55.37616576789321 ) ;
  }

  @Test
  public void test2484() {
    coral.tests.JPFBenchmark.benchmark05(-1.154119144619746,8.50986477737639E-17,13.846271157668431 ) ;
  }

  @Test
  public void test2485() {
    coral.tests.JPFBenchmark.benchmark05(-1.1552576355034034,-0.32601580392099194,-159.102484026716 ) ;
  }

  @Test
  public void test2486() {
    coral.tests.JPFBenchmark.benchmark05(-1.1553244005534909E-274,-1.282378755955585,1.5707963267948966 ) ;
  }

  @Test
  public void test2487() {
    coral.tests.JPFBenchmark.benchmark05(-1.1563574763212756,86.00939205931505,-46.93702233175294 ) ;
  }

  @Test
  public void test2488() {
    coral.tests.JPFBenchmark.benchmark05(-1.156439947335853,-1.5707963267948966,210.56523254665888 ) ;
  }

  @Test
  public void test2489() {
    coral.tests.JPFBenchmark.benchmark05(-1.1568568093558553,-135.8193148459784,29.54202985833757 ) ;
  }

  @Test
  public void test2490() {
    coral.tests.JPFBenchmark.benchmark05(-1.1576907095279194,-0.7762385046566,7.31511930420656E-99 ) ;
  }

  @Test
  public void test2491() {
    coral.tests.JPFBenchmark.benchmark05(-1.1582848713616343,-48.6119894617136,-75.50637903490255 ) ;
  }

  @Test
  public void test2492() {
    coral.tests.JPFBenchmark.benchmark05(-1.1593997555655113,-299.9711326372333,123.98115283672809 ) ;
  }

  @Test
  public void test2493() {
    coral.tests.JPFBenchmark.benchmark05(-11.5965933071069,-48.857427779468686,-50.46462380392005 ) ;
  }

  @Test
  public void test2494() {
    coral.tests.JPFBenchmark.benchmark05(-1.1601798434138875,-1.5707963267948912,-155.49662769324544 ) ;
  }

  @Test
  public void test2495() {
    coral.tests.JPFBenchmark.benchmark05(-1.161632304277207,-41.51783036113405,3.1416002949927524 ) ;
  }

  @Test
  public void test2496() {
    coral.tests.JPFBenchmark.benchmark05(-1.162142760674853,-1.5707963267948912,-77.43451698918851 ) ;
  }

  @Test
  public void test2497() {
    coral.tests.JPFBenchmark.benchmark05(-1.1621533414855598,14.429591567980452,55.07076905050431 ) ;
  }

  @Test
  public void test2498() {
    coral.tests.JPFBenchmark.benchmark05(-1.1625661120629776,-61.017599558134755,141.05531226097702 ) ;
  }

  @Test
  public void test2499() {
    coral.tests.JPFBenchmark.benchmark05(-1.1632046439617305,-0.06465254948812897,20.215602735008233 ) ;
  }

  @Test
  public void test2500() {
    coral.tests.JPFBenchmark.benchmark05(-11.634703748014658,-7.777521008839727,12.498677317562652 ) ;
  }

  @Test
  public void test2501() {
    coral.tests.JPFBenchmark.benchmark05(-1.1637948190454155,-1.4278658013540158,-133.97461618860544 ) ;
  }

  @Test
  public void test2502() {
    coral.tests.JPFBenchmark.benchmark05(-1.1659185804287848,-1.5707963253615276,-1.5707963267948961 ) ;
  }

  @Test
  public void test2503() {
    coral.tests.JPFBenchmark.benchmark05(-1.1670476781244468,-0.11898179880408367,35.64853073981888 ) ;
  }

  @Test
  public void test2504() {
    coral.tests.JPFBenchmark.benchmark05(-1.1673267357768673,-3.329019559264181,-1.5707963267948963 ) ;
  }

  @Test
  public void test2505() {
    coral.tests.JPFBenchmark.benchmark05(-1.168140108892082,-0.25208441930257186,-0.3023963614786941 ) ;
  }

  @Test
  public void test2506() {
    coral.tests.JPFBenchmark.benchmark05(-1.1688274939438643,-1.5707963267948966,40.00773522305582 ) ;
  }

  @Test
  public void test2507() {
    coral.tests.JPFBenchmark.benchmark05(-1.1715974137834975,-1.5707963267948966,87.71424266086677 ) ;
  }

  @Test
  public void test2508() {
    coral.tests.JPFBenchmark.benchmark05(-1.1716272344385388,-41.941817568470974,118.13474674697588 ) ;
  }

  @Test
  public void test2509() {
    coral.tests.JPFBenchmark.benchmark05(-1.1720585672861845,3.142080934839808,-21.676360965268167 ) ;
  }

  @Test
  public void test2510() {
    coral.tests.JPFBenchmark.benchmark05(-1.1720913867509282,-0.1776540168131917,-1.5707963267948983 ) ;
  }

  @Test
  public void test2511() {
    coral.tests.JPFBenchmark.benchmark05(-1.1725095671692607,-0.4999930309268308,1.5707963267948966 ) ;
  }

  @Test
  public void test2512() {
    coral.tests.JPFBenchmark.benchmark05(-1.1732293326422523,-1.5707963267948968,22.503558509485174 ) ;
  }

  @Test
  public void test2513() {
    coral.tests.JPFBenchmark.benchmark05(1.17360454678215,-167.51037743048857,110.58064069420152 ) ;
  }

  @Test
  public void test2514() {
    coral.tests.JPFBenchmark.benchmark05(-1.1774426145944477,-6.32E-322,0 ) ;
  }

  @Test
  public void test2515() {
    coral.tests.JPFBenchmark.benchmark05(-1.1779761780898497,-1.5707963267948966,26.68158981842628 ) ;
  }

  @Test
  public void test2516() {
    coral.tests.JPFBenchmark.benchmark05(-1.1780602545512684,-53.491509304421434,-5.589018323941957 ) ;
  }

  @Test
  public void test2517() {
    coral.tests.JPFBenchmark.benchmark05(-1.1788528425177212,-35.781268406779155,-51.52469875819797 ) ;
  }

  @Test
  public void test2518() {
    coral.tests.JPFBenchmark.benchmark05(-1.1791461940045583E-17,-1.5707963267948966,1.5707963267944725 ) ;
  }

  @Test
  public void test2519() {
    coral.tests.JPFBenchmark.benchmark05(-1.1794610805583667,-1.4008908434866278,-1.5707963267948966 ) ;
  }

  @Test
  public void test2520() {
    coral.tests.JPFBenchmark.benchmark05(-1.1797759875144587,-154.0652632421534,100.0 ) ;
  }

  @Test
  public void test2521() {
    coral.tests.JPFBenchmark.benchmark05(-1.1804481209355335,-0.8092777814973162,-95.33011958687472 ) ;
  }

  @Test
  public void test2522() {
    coral.tests.JPFBenchmark.benchmark05(-1.1807774841440155,-54.87303404777164,15.618937614662116 ) ;
  }

  @Test
  public void test2523() {
    coral.tests.JPFBenchmark.benchmark05(-1.1812877648434192,-35.843627921326714,1.5707963267948963 ) ;
  }

  @Test
  public void test2524() {
    coral.tests.JPFBenchmark.benchmark05(-1.1816631692642772,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test2525() {
    coral.tests.JPFBenchmark.benchmark05(-1.182680958302278,-1.5707963267948966,-56.54867668034385 ) ;
  }

  @Test
  public void test2526() {
    coral.tests.JPFBenchmark.benchmark05(-1.1828684704919223,-1.5707963267948957,43.05055987823998 ) ;
  }

  @Test
  public void test2527() {
    coral.tests.JPFBenchmark.benchmark05(-1.183233620219306,-1.5707963267948966,7.247211572525146 ) ;
  }

  @Test
  public void test2528() {
    coral.tests.JPFBenchmark.benchmark05(-1.1837486443608696,-1.2566225322358993,21.487597367179873 ) ;
  }

  @Test
  public void test2529() {
    coral.tests.JPFBenchmark.benchmark05(-1.1838607060770112,-41.81676256625683,-6.28318530717729 ) ;
  }

  @Test
  public void test2530() {
    coral.tests.JPFBenchmark.benchmark05(-1.1841993650458615,-1.5707963267948912,34.55849609120191 ) ;
  }

  @Test
  public void test2531() {
    coral.tests.JPFBenchmark.benchmark05(-1.1845546465436845,-97.74968986926513,49.72659650686768 ) ;
  }

  @Test
  public void test2532() {
    coral.tests.JPFBenchmark.benchmark05(-1.184828414694934,-0.9221383283372652,209.01494660859825 ) ;
  }

  @Test
  public void test2533() {
    coral.tests.JPFBenchmark.benchmark05(-1.1849755726227993,-3.157217670283423,24.57032952132643 ) ;
  }

  @Test
  public void test2534() {
    coral.tests.JPFBenchmark.benchmark05(-1.1856543547267546,-42.148502372898015,-55.61228501010602 ) ;
  }

  @Test
  public void test2535() {
    coral.tests.JPFBenchmark.benchmark05(-1.1862731700206106,-55.12235366112811,-78.18508752958812 ) ;
  }

  @Test
  public void test2536() {
    coral.tests.JPFBenchmark.benchmark05(-1.1863421354904897,-98.1244270116455,62.805425870248115 ) ;
  }

  @Test
  public void test2537() {
    coral.tests.JPFBenchmark.benchmark05(-1.187209287688077,-1.5707963267948966,-5.237275593577323 ) ;
  }

  @Test
  public void test2538() {
    coral.tests.JPFBenchmark.benchmark05(-1.1878319186414814,-98.12127865797255,-70.89893524292066 ) ;
  }

  @Test
  public void test2539() {
    coral.tests.JPFBenchmark.benchmark05(-1.1879727247629475,-3.1416557161035192,55.44296527228977 ) ;
  }

  @Test
  public void test2540() {
    coral.tests.JPFBenchmark.benchmark05(-1.188084765296996,-72.4776181391587,-46.96526439031828 ) ;
  }

  @Test
  public void test2541() {
    coral.tests.JPFBenchmark.benchmark05(-1.1881453048844897,4.141592653783779,6.2833075501288045 ) ;
  }

  @Test
  public void test2542() {
    coral.tests.JPFBenchmark.benchmark05(-1.1885578301626152,-15.793387753035603,95.84210793899601 ) ;
  }

  @Test
  public void test2543() {
    coral.tests.JPFBenchmark.benchmark05(-1.1909434601793363,-1.0442614778665788E-13,182.10606858579806 ) ;
  }

  @Test
  public void test2544() {
    coral.tests.JPFBenchmark.benchmark05(-1.1931214588613468,-1.570796326794896,97.7189232601918 ) ;
  }

  @Test
  public void test2545() {
    coral.tests.JPFBenchmark.benchmark05(-1.1932858662572285,-0.13128805581152037,92.0779126830427 ) ;
  }

  @Test
  public void test2546() {
    coral.tests.JPFBenchmark.benchmark05(-1.1939548367975101,-1.5707963267948966,-19.594179207703473 ) ;
  }

  @Test
  public void test2547() {
    coral.tests.JPFBenchmark.benchmark05(-1.1942323197442342,-47.15286369934686,21.765157091677906 ) ;
  }

  @Test
  public void test2548() {
    coral.tests.JPFBenchmark.benchmark05(-1.1956665403002766,-1.5707963267948961,-21.066566942143375 ) ;
  }

  @Test
  public void test2549() {
    coral.tests.JPFBenchmark.benchmark05(-1.1961272104225384,-1.5707963267948966,-62.06540719925463 ) ;
  }

  @Test
  public void test2550() {
    coral.tests.JPFBenchmark.benchmark05(-1.1962420765383734,-0.06795957524587865,-100.0 ) ;
  }

  @Test
  public void test2551() {
    coral.tests.JPFBenchmark.benchmark05(-1.1970170219621552,-3.26973533717036,46.29364315174318 ) ;
  }

  @Test
  public void test2552() {
    coral.tests.JPFBenchmark.benchmark05(-1.197684351303973,-0.8357406977490338,-0.3797304296145435 ) ;
  }

  @Test
  public void test2553() {
    coral.tests.JPFBenchmark.benchmark05(-1.1976882685991468,-72.44187370445678,-50.73222071983523 ) ;
  }

  @Test
  public void test2554() {
    coral.tests.JPFBenchmark.benchmark05(-1.1981020559107707,3.142080937303079,211.82449772322587 ) ;
  }

  @Test
  public void test2555() {
    coral.tests.JPFBenchmark.benchmark05(-1.1982966900893883,-0.2952516297137204,26.87451903330658 ) ;
  }

  @Test
  public void test2556() {
    coral.tests.JPFBenchmark.benchmark05(-1.198712740994674,-1.5707963267945886,-66.504547177994 ) ;
  }

  @Test
  public void test2557() {
    coral.tests.JPFBenchmark.benchmark05(-1.1988390690588406,-0.00876543969975709,171.17633961268695 ) ;
  }

  @Test
  public void test2558() {
    coral.tests.JPFBenchmark.benchmark05(12.00109587169726,3.1665800267080044,-47.18950187320796 ) ;
  }

  @Test
  public void test2559() {
    coral.tests.JPFBenchmark.benchmark05(-1.2008062803062698,-66.83096694030155,-9.95534531143768 ) ;
  }

  @Test
  public void test2560() {
    coral.tests.JPFBenchmark.benchmark05(-1.2010083557340263,-0.5814937810363621,0.8758902875172833 ) ;
  }

  @Test
  public void test2561() {
    coral.tests.JPFBenchmark.benchmark05(-1.2013811976056656,-0.4040356504834542,29.70219045509595 ) ;
  }

  @Test
  public void test2562() {
    coral.tests.JPFBenchmark.benchmark05(-1.2015200743226844,3.5814987183855247,77.31132311007573 ) ;
  }

  @Test
  public void test2563() {
    coral.tests.JPFBenchmark.benchmark05(-1.203201699264877,-3.775497343260554,-88.0220509849965 ) ;
  }

  @Test
  public void test2564() {
    coral.tests.JPFBenchmark.benchmark05(-1.2035160107396612,-48.717658041217945,-257.9052413647124 ) ;
  }

  @Test
  public void test2565() {
    coral.tests.JPFBenchmark.benchmark05(-1.2039609202274968,-1.570796325839568,-78.28065122565903 ) ;
  }

  @Test
  public void test2566() {
    coral.tests.JPFBenchmark.benchmark05(-1.20440573663601,-0.6409923006018745,-90.63797031560736 ) ;
  }

  @Test
  public void test2567() {
    coral.tests.JPFBenchmark.benchmark05(-1.2048096114638858,-9.55318483687387,-3.143681497738663 ) ;
  }

  @Test
  public void test2568() {
    coral.tests.JPFBenchmark.benchmark05(-1.2051463203294046,-0.1805675742791586,-44.19888797275169 ) ;
  }

  @Test
  public void test2569() {
    coral.tests.JPFBenchmark.benchmark05(-1.2061224403621402,-1.5707963267948966,-63.20062428541929 ) ;
  }

  @Test
  public void test2570() {
    coral.tests.JPFBenchmark.benchmark05(-1.2066094426053062,-1.4084176546183262,-24.019955401324907 ) ;
  }

  @Test
  public void test2571() {
    coral.tests.JPFBenchmark.benchmark05(-1.2079631537200324,-3.1436796354186334,-1.5707963267949054 ) ;
  }

  @Test
  public void test2572() {
    coral.tests.JPFBenchmark.benchmark05(-1.2086732876259774,-1.5707963267948966,-84.42918329156441 ) ;
  }

  @Test
  public void test2573() {
    coral.tests.JPFBenchmark.benchmark05(-1.2091009965548718,-682.4697401871879,33.15173620604486 ) ;
  }

  @Test
  public void test2574() {
    coral.tests.JPFBenchmark.benchmark05(-1.2097276468686358,-59.69029093700764,-65.98689146518075 ) ;
  }

  @Test
  public void test2575() {
    coral.tests.JPFBenchmark.benchmark05(-1.2099145805473688,-1.5707963267948966,26.802936048642767 ) ;
  }

  @Test
  public void test2576() {
    coral.tests.JPFBenchmark.benchmark05(-1.2107248135455009,-1.5704150666182497,0.00314648463139053 ) ;
  }

  @Test
  public void test2577() {
    coral.tests.JPFBenchmark.benchmark05(-1.2108013500195054,-3.141601039609937,57.9153942138214 ) ;
  }

  @Test
  public void test2578() {
    coral.tests.JPFBenchmark.benchmark05(-1.2124172212328683,-3.14159265359163,-100.0 ) ;
  }

  @Test
  public void test2579() {
    coral.tests.JPFBenchmark.benchmark05(-1.2126339582702537,-34.8838159269353,3.469446951953614E-18 ) ;
  }

  @Test
  public void test2580() {
    coral.tests.JPFBenchmark.benchmark05(-1.212665433623343,-48.42662614776377,-1.5707963267948912 ) ;
  }

  @Test
  public void test2581() {
    coral.tests.JPFBenchmark.benchmark05(-1.213047596358334E-4,-1.5707963267948966,-40.83995318428497 ) ;
  }

  @Test
  public void test2582() {
    coral.tests.JPFBenchmark.benchmark05(-12.133971520154788,0,0 ) ;
  }

  @Test
  public void test2583() {
    coral.tests.JPFBenchmark.benchmark05(-1.21371128591678,-53.50669230109622,-152.594121422388 ) ;
  }

  @Test
  public void test2584() {
    coral.tests.JPFBenchmark.benchmark05(-1.2139778169235313,-0.7928384215815001,27.09240169475295 ) ;
  }

  @Test
  public void test2585() {
    coral.tests.JPFBenchmark.benchmark05(12.147498478690167,7.838342228847878,22.452861601572423 ) ;
  }

  @Test
  public void test2586() {
    coral.tests.JPFBenchmark.benchmark05(12.154414724726507,-49.89690579288395,59.86709464677725 ) ;
  }

  @Test
  public void test2587() {
    coral.tests.JPFBenchmark.benchmark05(-1.2161549326908272,-1.5707963267948966,-12.56637061418629 ) ;
  }

  @Test
  public void test2588() {
    coral.tests.JPFBenchmark.benchmark05(-1.2163209362656222E-15,-0.7444198480855917,79.17429912844695 ) ;
  }

  @Test
  public void test2589() {
    coral.tests.JPFBenchmark.benchmark05(-1.216450554638166,-78.9214404599312,-23.36870628405515 ) ;
  }

  @Test
  public void test2590() {
    coral.tests.JPFBenchmark.benchmark05(-1.2166986024289023E-209,-1.5707963267948948,-95.84534436872299 ) ;
  }

  @Test
  public void test2591() {
    coral.tests.JPFBenchmark.benchmark05(-1.2166986024289023E-209,-1.5707963267948966,29.447471724205247 ) ;
  }

  @Test
  public void test2592() {
    coral.tests.JPFBenchmark.benchmark05(-1.216865253780079,-0.37370544207332757,-1.5707963267948966 ) ;
  }

  @Test
  public void test2593() {
    coral.tests.JPFBenchmark.benchmark05(-1.2173744012046583,-66.31374427975783,-18.849555921538762 ) ;
  }

  @Test
  public void test2594() {
    coral.tests.JPFBenchmark.benchmark05(-1.2174440309074603,-0.44013566467117893,-63.302745726452756 ) ;
  }

  @Test
  public void test2595() {
    coral.tests.JPFBenchmark.benchmark05(-1.2178682573491528,-0.5845197630907799,-136.66337509768135 ) ;
  }

  @Test
  public void test2596() {
    coral.tests.JPFBenchmark.benchmark05(-1.2185574021534276,-48.33313723317923,-31.867117091467605 ) ;
  }

  @Test
  public void test2597() {
    coral.tests.JPFBenchmark.benchmark05(-1.218753089016155,-42.30642298210301,100.0 ) ;
  }

  @Test
  public void test2598() {
    coral.tests.JPFBenchmark.benchmark05(-1.2197008294366771,-54.925344523672635,-3.9698376520452143 ) ;
  }

  @Test
  public void test2599() {
    coral.tests.JPFBenchmark.benchmark05(-1.2208941594999394,-22.423483936023672,27.9445275802053 ) ;
  }

  @Test
  public void test2600() {
    coral.tests.JPFBenchmark.benchmark05(-1.2211601244670256,-1.5707963267948966,-39.22572279359327 ) ;
  }

  @Test
  public void test2601() {
    coral.tests.JPFBenchmark.benchmark05(-1.22184046117043,-1.5707963267948948,256.03589093171064 ) ;
  }

  @Test
  public void test2602() {
    coral.tests.JPFBenchmark.benchmark05(12.226208100482452,-88.67013484027777,31.155828795306775 ) ;
  }

  @Test
  public void test2603() {
    coral.tests.JPFBenchmark.benchmark05(-1.2226581376996108,-66.5123178443255,1.357952097677611 ) ;
  }

  @Test
  public void test2604() {
    coral.tests.JPFBenchmark.benchmark05(-1.2228719909328007,-1.5707963267948966,-36.780068695370794 ) ;
  }

  @Test
  public void test2605() {
    coral.tests.JPFBenchmark.benchmark05(-1.224045646775295,-0.46008171683359045,30.054519337822427 ) ;
  }

  @Test
  public void test2606() {
    coral.tests.JPFBenchmark.benchmark05(-1.2246828934217718E-16,-15.929131009055137,25.95333433280571 ) ;
  }

  @Test
  public void test2607() {
    coral.tests.JPFBenchmark.benchmark05(-1.227359043089639,-63.75855585554007,42.70646769707832 ) ;
  }

  @Test
  public void test2608() {
    coral.tests.JPFBenchmark.benchmark05(-1.2273824160673146,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2609() {
    coral.tests.JPFBenchmark.benchmark05(-1.2282060311148335,-15.807500635957703,-77.9822183089269 ) ;
  }

  @Test
  public void test2610() {
    coral.tests.JPFBenchmark.benchmark05(-1.228484066329015,-1.5707963267948948,-24.44221943780522 ) ;
  }

  @Test
  public void test2611() {
    coral.tests.JPFBenchmark.benchmark05(-1.2287715193947129,-1.5707963267948948,44.306818738424816 ) ;
  }

  @Test
  public void test2612() {
    coral.tests.JPFBenchmark.benchmark05(-1.2287751679108994,-41.52932260441556,-63.84526099153968 ) ;
  }

  @Test
  public void test2613() {
    coral.tests.JPFBenchmark.benchmark05(-1.2293666849162095,-0.5779555541218135,-66.53256639032139 ) ;
  }

  @Test
  public void test2614() {
    coral.tests.JPFBenchmark.benchmark05(-1.2303994196675774,-1.5005346542911755,9.935026116539285 ) ;
  }

  @Test
  public void test2615() {
    coral.tests.JPFBenchmark.benchmark05(-1.23172864068097,-41.98824034699109,104.02568666226618 ) ;
  }

  @Test
  public void test2616() {
    coral.tests.JPFBenchmark.benchmark05(-1.2321527426382854E-13,-1.5707963267948966,-27.94939753528841 ) ;
  }

  @Test
  public void test2617() {
    coral.tests.JPFBenchmark.benchmark05(-1.2331934264839781,-0.5116915199076646,-29.341773550204348 ) ;
  }

  @Test
  public void test2618() {
    coral.tests.JPFBenchmark.benchmark05(-1.233833663737509,-1.3642930920496963,34.27914965362851 ) ;
  }

  @Test
  public void test2619() {
    coral.tests.JPFBenchmark.benchmark05(-1.2338789709326767E-178,-1.570796326794896,26.893140820837893 ) ;
  }

  @Test
  public void test2620() {
    coral.tests.JPFBenchmark.benchmark05(-1.2340051149745896,-98.4471215595715,-15.707963267948967 ) ;
  }

  @Test
  public void test2621() {
    coral.tests.JPFBenchmark.benchmark05(-1.234422388208338,-3.2033329522929615E-145,6.307199977515378 ) ;
  }

  @Test
  public void test2622() {
    coral.tests.JPFBenchmark.benchmark05(-1.2345897144852767,-1.5707963267948966,15.974302043624363 ) ;
  }

  @Test
  public void test2623() {
    coral.tests.JPFBenchmark.benchmark05(-1.237278588746922,-3.6089842619265804,-7.855602081390783 ) ;
  }

  @Test
  public void test2624() {
    coral.tests.JPFBenchmark.benchmark05(-1.2372789599310516,-1.5707963267822793,-15.028735174812253 ) ;
  }

  @Test
  public void test2625() {
    coral.tests.JPFBenchmark.benchmark05(-1.237433065361481,-0.8487199274238082,-27.410154058958504 ) ;
  }

  @Test
  public void test2626() {
    coral.tests.JPFBenchmark.benchmark05(-1.2376008313554419,-61.22959525333205,0.0 ) ;
  }

  @Test
  public void test2627() {
    coral.tests.JPFBenchmark.benchmark05(-1.2390674558327006,-0.8065387317208884,-6.283200941315402 ) ;
  }

  @Test
  public void test2628() {
    coral.tests.JPFBenchmark.benchmark05(-1.2410992594020462,-1.5707963267948966,3.3388091713274455 ) ;
  }

  @Test
  public void test2629() {
    coral.tests.JPFBenchmark.benchmark05(-1.2424174901432468,-54.51403550570249,-100.0 ) ;
  }

  @Test
  public void test2630() {
    coral.tests.JPFBenchmark.benchmark05(-1.2428040683213005E-15,-42.089594337386835,1.5707963267948966 ) ;
  }

  @Test
  public void test2631() {
    coral.tests.JPFBenchmark.benchmark05(-1.2436111329808375,-22.481028968194934,63.998374581903335 ) ;
  }

  @Test
  public void test2632() {
    coral.tests.JPFBenchmark.benchmark05(-1.244864065737034E-15,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2633() {
    coral.tests.JPFBenchmark.benchmark05(-1.2451908504002054,-1.5707963267948966,-1.5707963267948968 ) ;
  }

  @Test
  public void test2634() {
    coral.tests.JPFBenchmark.benchmark05(-1.245905401333161,-0.40231960009394907,-89.11987658403731 ) ;
  }

  @Test
  public void test2635() {
    coral.tests.JPFBenchmark.benchmark05(-1.2469858458813263,-0.2639022436540075,-62.2088811802875 ) ;
  }

  @Test
  public void test2636() {
    coral.tests.JPFBenchmark.benchmark05(-1.2495224216376748,-1.5707963267948966,20.312970206910506 ) ;
  }

  @Test
  public void test2637() {
    coral.tests.JPFBenchmark.benchmark05(-1.2496970938694203,-47.53961262707254,-968.0641873937317 ) ;
  }

  @Test
  public void test2638() {
    coral.tests.JPFBenchmark.benchmark05(-1.2502012535691835,-66.57255126673098,-33.05478200883056 ) ;
  }

  @Test
  public void test2639() {
    coral.tests.JPFBenchmark.benchmark05(-1.2508387115101667,-35.44712391825979,-57.061691094950206 ) ;
  }

  @Test
  public void test2640() {
    coral.tests.JPFBenchmark.benchmark05(-1.2511921453464132,-41.51415968810039,92.6769832808989 ) ;
  }

  @Test
  public void test2641() {
    coral.tests.JPFBenchmark.benchmark05(-1.2519934059828302,-1.5707963267948966,1.5707963267948977 ) ;
  }

  @Test
  public void test2642() {
    coral.tests.JPFBenchmark.benchmark05(-1.2534722831302307,-16.009940404765395,8.166602821501868 ) ;
  }

  @Test
  public void test2643() {
    coral.tests.JPFBenchmark.benchmark05(-1.2547284390038917,-1.5707963267948966,-52.0694473098692 ) ;
  }

  @Test
  public void test2644() {
    coral.tests.JPFBenchmark.benchmark05(-1.2548278223606542,-1.4996784993173122,99.51220519195437 ) ;
  }

  @Test
  public void test2645() {
    coral.tests.JPFBenchmark.benchmark05(-1.2553170187759342,-65.99682906039726,-1.5707963041587976 ) ;
  }

  @Test
  public void test2646() {
    coral.tests.JPFBenchmark.benchmark05(-1.2555572644949238,0.37702998153366607,-119.24484390621417 ) ;
  }

  @Test
  public void test2647() {
    coral.tests.JPFBenchmark.benchmark05(-1.256470178325948,-54.41891081851193,0.0 ) ;
  }

  @Test
  public void test2648() {
    coral.tests.JPFBenchmark.benchmark05(-1.2566238280307929,-1.5707963267948966,-69.57168793251539 ) ;
  }

  @Test
  public void test2649() {
    coral.tests.JPFBenchmark.benchmark05(-1.256971960182508,-1.5707963267948966,-1.5707963245901782 ) ;
  }

  @Test
  public void test2650() {
    coral.tests.JPFBenchmark.benchmark05(-1.2572325964985043,-1.570796328968488,-73.2455705539628 ) ;
  }

  @Test
  public void test2651() {
    coral.tests.JPFBenchmark.benchmark05(-1.2572520091329038E-14,-1.5707963267948966,26.610750273908195 ) ;
  }

  @Test
  public void test2652() {
    coral.tests.JPFBenchmark.benchmark05(-1.2574385486448971,-15.891752008015374,26.952521579562443 ) ;
  }

  @Test
  public void test2653() {
    coral.tests.JPFBenchmark.benchmark05(-1.2584972137083241,-4.06697773001963,15.211570562373524 ) ;
  }

  @Test
  public void test2654() {
    coral.tests.JPFBenchmark.benchmark05(-1.259902617116011,-5.284620304773626E-15,-66.11903670136871 ) ;
  }

  @Test
  public void test2655() {
    coral.tests.JPFBenchmark.benchmark05(-1.2603961245067694,-9.662093417864412,21.488017904419863 ) ;
  }

  @Test
  public void test2656() {
    coral.tests.JPFBenchmark.benchmark05(-1.2605334422561603,-78.66581718626603,79.37624199909752 ) ;
  }

  @Test
  public void test2657() {
    coral.tests.JPFBenchmark.benchmark05(-1.2619603861273763,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2658() {
    coral.tests.JPFBenchmark.benchmark05(-1.2621207313897555E-15,-1.5707963267948966,-1.5707963267948963 ) ;
  }

  @Test
  public void test2659() {
    coral.tests.JPFBenchmark.benchmark05(-1.263328484538172,-526.1850714912918,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test2660() {
    coral.tests.JPFBenchmark.benchmark05(-1.2633417770944586,-123.03287600395451,-43.119935385658614 ) ;
  }

  @Test
  public void test2661() {
    coral.tests.JPFBenchmark.benchmark05(-1.2645674307643484,-1.5707963267948966,48.24559646868486 ) ;
  }

  @Test
  public void test2662() {
    coral.tests.JPFBenchmark.benchmark05(-1.2647224316890515,-2606.087924740046,0 ) ;
  }

  @Test
  public void test2663() {
    coral.tests.JPFBenchmark.benchmark05(-1.265458596310781,-1.5707963267948948,46.627109718880114 ) ;
  }

  @Test
  public void test2664() {
    coral.tests.JPFBenchmark.benchmark05(-1.2655466641597357,-1.5707963267948966,-42.987187616825516 ) ;
  }

  @Test
  public void test2665() {
    coral.tests.JPFBenchmark.benchmark05(-1.2676966815295967,-61.21310254896159,712.0163519285643 ) ;
  }

  @Test
  public void test2666() {
    coral.tests.JPFBenchmark.benchmark05(-1.2683313551143698,-66.62114928575629,-90.75333459265408 ) ;
  }

  @Test
  public void test2667() {
    coral.tests.JPFBenchmark.benchmark05(-1.268333327192865,-34.60064451480655,-6.283185806314435 ) ;
  }

  @Test
  public void test2668() {
    coral.tests.JPFBenchmark.benchmark05(-1.2690924406976227,-35.07664530435676,42.873811166251265 ) ;
  }

  @Test
  public void test2669() {
    coral.tests.JPFBenchmark.benchmark05(-1.2697249270030573,-1.5707963267948966,-1.2879537880922651 ) ;
  }

  @Test
  public void test2670() {
    coral.tests.JPFBenchmark.benchmark05(-1.2700490277107066,-72.80292396431322,10.995574287564276 ) ;
  }

  @Test
  public void test2671() {
    coral.tests.JPFBenchmark.benchmark05(-1.2713397215132831,-122.74941151723684,-46.73742127251048 ) ;
  }

  @Test
  public void test2672() {
    coral.tests.JPFBenchmark.benchmark05(-1.2716066237672445,-36.021352784901104,41.699472681332125 ) ;
  }

  @Test
  public void test2673() {
    coral.tests.JPFBenchmark.benchmark05(-1.2739179484291565,-1.5707963267948966,-186.79128673553444 ) ;
  }

  @Test
  public void test2674() {
    coral.tests.JPFBenchmark.benchmark05(-1.2754654233466391,-1.5707963267948966,81.82194553956847 ) ;
  }

  @Test
  public void test2675() {
    coral.tests.JPFBenchmark.benchmark05(-1.2759022777463174,-4.440892098500626E-16,147.30956702737038 ) ;
  }

  @Test
  public void test2676() {
    coral.tests.JPFBenchmark.benchmark05(-1.2761790941513633,4.141592653631701,-1.000764725840901 ) ;
  }

  @Test
  public void test2677() {
    coral.tests.JPFBenchmark.benchmark05(-1.2766395928460001,-16.002000284683056,-82.70131878167915 ) ;
  }

  @Test
  public void test2678() {
    coral.tests.JPFBenchmark.benchmark05(-1.277357827970664,-1.0349962667332435,0.0 ) ;
  }

  @Test
  public void test2679() {
    coral.tests.JPFBenchmark.benchmark05(-1.2774663911344266E-15,-1.5707963267948966,-50.29179600395539 ) ;
  }

  @Test
  public void test2680() {
    coral.tests.JPFBenchmark.benchmark05(-1.2788047549970152,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2681() {
    coral.tests.JPFBenchmark.benchmark05(-1.2790135429804197,-1.5698976763062433,84.81204753739533 ) ;
  }

  @Test
  public void test2682() {
    coral.tests.JPFBenchmark.benchmark05(-1.2808917047552475,-1.5707963267948966,-40.54132273740994 ) ;
  }

  @Test
  public void test2683() {
    coral.tests.JPFBenchmark.benchmark05(-1.2823849915152365,-1.5707963267948966,-14.219589774880205 ) ;
  }

  @Test
  public void test2684() {
    coral.tests.JPFBenchmark.benchmark05(-1.283308119125362,-1.5707821914492688,192.99170048003668 ) ;
  }

  @Test
  public void test2685() {
    coral.tests.JPFBenchmark.benchmark05(-1.2835578144041553,-1.5707963267948966,-0.11307289381894729 ) ;
  }

  @Test
  public void test2686() {
    coral.tests.JPFBenchmark.benchmark05(-1.284233201312695,-1.5707963267948966,4.712388981886593 ) ;
  }

  @Test
  public void test2687() {
    coral.tests.JPFBenchmark.benchmark05(-1.2844093793075442,-66.35600294764457,-25.60696795144868 ) ;
  }

  @Test
  public void test2688() {
    coral.tests.JPFBenchmark.benchmark05(-1.284972333623462,-0.7247182800493024,-29.360688445395873 ) ;
  }

  @Test
  public void test2689() {
    coral.tests.JPFBenchmark.benchmark05(-1.2852360313452373,-1.5707963267948966,-2325.321039880201 ) ;
  }

  @Test
  public void test2690() {
    coral.tests.JPFBenchmark.benchmark05(-1.2862691607608274,-1.5707963267727254,44.276855821909514 ) ;
  }

  @Test
  public void test2691() {
    coral.tests.JPFBenchmark.benchmark05(-1.2867260096834894,-9.936679131948553,-3.1435470456398327 ) ;
  }

  @Test
  public void test2692() {
    coral.tests.JPFBenchmark.benchmark05(-1.287011397546399,-1.040482389757826,31.845276874788325 ) ;
  }

  @Test
  public void test2693() {
    coral.tests.JPFBenchmark.benchmark05(-1.2882284437351803,-1.5707963267948966,2.5026038689788762E-147 ) ;
  }

  @Test
  public void test2694() {
    coral.tests.JPFBenchmark.benchmark05(-1.2888816011594462,-1.5707963267948966,88.85696594677484 ) ;
  }

  @Test
  public void test2695() {
    coral.tests.JPFBenchmark.benchmark05(-1.289223607331618,-1.5707963267948941,27.048144758458434 ) ;
  }

  @Test
  public void test2696() {
    coral.tests.JPFBenchmark.benchmark05(-1.2896788368691336,-47.61762952713007,0.0 ) ;
  }

  @Test
  public void test2697() {
    coral.tests.JPFBenchmark.benchmark05(-1.2902125534863806E-4,-0.6432533474191369,84.84440960342857 ) ;
  }

  @Test
  public void test2698() {
    coral.tests.JPFBenchmark.benchmark05(-1.2909985445987477,-0.006531680616005515,-51.310081165050725 ) ;
  }

  @Test
  public void test2699() {
    coral.tests.JPFBenchmark.benchmark05(-1.291599263109636,-1.2660939586309543,-168.45034738168818 ) ;
  }

  @Test
  public void test2700() {
    coral.tests.JPFBenchmark.benchmark05(-1.2918714601859262,-198.51440296897368,-32.77375551296586 ) ;
  }

  @Test
  public void test2701() {
    coral.tests.JPFBenchmark.benchmark05(-1.2927634419331007,-41.92523376562117,3.1416002945526857 ) ;
  }

  @Test
  public void test2702() {
    coral.tests.JPFBenchmark.benchmark05(-1.2929964132502894,-0.9832857901200366,-97.39718476296373 ) ;
  }

  @Test
  public void test2703() {
    coral.tests.JPFBenchmark.benchmark05(-1.2936836359339363,-1.5707963267948877,-3.141664398498904 ) ;
  }

  @Test
  public void test2704() {
    coral.tests.JPFBenchmark.benchmark05(-1.2943187523318045E-4,-1.5707963267948966,3.1415926568416 ) ;
  }

  @Test
  public void test2705() {
    coral.tests.JPFBenchmark.benchmark05(-1.2969939021256511,-1.5707963267948966,57.40187310446411 ) ;
  }

  @Test
  public void test2706() {
    coral.tests.JPFBenchmark.benchmark05(-1.297284806659996,-191.82474723109934,-469.07279015277464 ) ;
  }

  @Test
  public void test2707() {
    coral.tests.JPFBenchmark.benchmark05(-1.297732520355673,-41.90183678523755,-79.07934661469871 ) ;
  }

  @Test
  public void test2708() {
    coral.tests.JPFBenchmark.benchmark05(-1.2979587330538922,-0.013981128488932192,-6.283701051815919 ) ;
  }

  @Test
  public void test2709() {
    coral.tests.JPFBenchmark.benchmark05(-1.2980538379159348,-122.73395248411173,-12.59769727111414 ) ;
  }

  @Test
  public void test2710() {
    coral.tests.JPFBenchmark.benchmark05(-1.2991965464357458,-1.5707963265140492,54.866688993827815 ) ;
  }

  @Test
  public void test2711() {
    coral.tests.JPFBenchmark.benchmark05(-1.2992797823575741,-123.06063304448921,-35.120651093800426 ) ;
  }

  @Test
  public void test2712() {
    coral.tests.JPFBenchmark.benchmark05(-1.3008706291871318E-6,-1.5707963267948966,-25.136670504216475 ) ;
  }

  @Test
  public void test2713() {
    coral.tests.JPFBenchmark.benchmark05(-1.3011299568718604,-0.8984071361052856,86.11266612204935 ) ;
  }

  @Test
  public void test2714() {
    coral.tests.JPFBenchmark.benchmark05(1.3017799421422376,-0.04317643593817311,-1.5707963267948881 ) ;
  }

  @Test
  public void test2715() {
    coral.tests.JPFBenchmark.benchmark05(-1.3018315794909163,-0.01267170883877501,5.141592657749106 ) ;
  }

  @Test
  public void test2716() {
    coral.tests.JPFBenchmark.benchmark05(-1.3037210802023078,-1.5707963267948966,-1.3154189050784577 ) ;
  }

  @Test
  public void test2717() {
    coral.tests.JPFBenchmark.benchmark05(-1.30509648701229,-66.06714724259723,-6.287100409017662 ) ;
  }

  @Test
  public void test2718() {
    coral.tests.JPFBenchmark.benchmark05(-1.305839649205496,-1.5707963267948966,-54.2910671948284 ) ;
  }

  @Test
  public void test2719() {
    coral.tests.JPFBenchmark.benchmark05(-1.3064422170282288,-1.1072257074434193,26.751004602322055 ) ;
  }

  @Test
  public void test2720() {
    coral.tests.JPFBenchmark.benchmark05(-1.306639102499562,-1.5707963267948806,100.0 ) ;
  }

  @Test
  public void test2721() {
    coral.tests.JPFBenchmark.benchmark05(-1.3066661243116118,-3.1416015181179686,-9.264033492761016 ) ;
  }

  @Test
  public void test2722() {
    coral.tests.JPFBenchmark.benchmark05(-1.3070149849959622,-22.4389403466852,-1.5707963267948966 ) ;
  }

  @Test
  public void test2723() {
    coral.tests.JPFBenchmark.benchmark05(-1.3084368564941733,-1.0355852691437597,50.92729366471049 ) ;
  }

  @Test
  public void test2724() {
    coral.tests.JPFBenchmark.benchmark05(-1.3084707421990265,-98.5662011823776,89.91983977358628 ) ;
  }

  @Test
  public void test2725() {
    coral.tests.JPFBenchmark.benchmark05(-1.3088577900597216,-0.034107128687922775,1.5707963267948966 ) ;
  }

  @Test
  public void test2726() {
    coral.tests.JPFBenchmark.benchmark05(-1.3097214927905234,-35.407470749291264,-1.57079632581677 ) ;
  }

  @Test
  public void test2727() {
    coral.tests.JPFBenchmark.benchmark05(-1.309740720441711,-41.71196978919965,3.469446951953614E-18 ) ;
  }

  @Test
  public void test2728() {
    coral.tests.JPFBenchmark.benchmark05(-1.3101041588273774,-1.5707963267948966,-6.974661058325509 ) ;
  }

  @Test
  public void test2729() {
    coral.tests.JPFBenchmark.benchmark05(-1.310261632402747,-1.5707963267948966,12.196027006261994 ) ;
  }

  @Test
  public void test2730() {
    coral.tests.JPFBenchmark.benchmark05(-1.31044128307674,-9.590977889805995,-7.681987434086096 ) ;
  }

  @Test
  public void test2731() {
    coral.tests.JPFBenchmark.benchmark05(13.105690423625234,5.269749608664554,94.9156408924965 ) ;
  }

  @Test
  public void test2732() {
    coral.tests.JPFBenchmark.benchmark05(-1.3108013418427564,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2733() {
    coral.tests.JPFBenchmark.benchmark05(-1.3125291414747364,-48.17668060073408,0.0 ) ;
  }

  @Test
  public void test2734() {
    coral.tests.JPFBenchmark.benchmark05(-1.3134517764154804E-287,-1.4430702370029422,-0.5484725395607445 ) ;
  }

  @Test
  public void test2735() {
    coral.tests.JPFBenchmark.benchmark05(-1.314227725458046,-28.397793633206803,45.409037523200325 ) ;
  }

  @Test
  public void test2736() {
    coral.tests.JPFBenchmark.benchmark05(-1.315199388968588,-9.506851731207504,-6.287091557180191 ) ;
  }

  @Test
  public void test2737() {
    coral.tests.JPFBenchmark.benchmark05(-1.3160464289909355,-0.3352921897935171,-1.5707963267948968 ) ;
  }

  @Test
  public void test2738() {
    coral.tests.JPFBenchmark.benchmark05(-1.3164789539701331,-0.18647477552542968,21.78935416517222 ) ;
  }

  @Test
  public void test2739() {
    coral.tests.JPFBenchmark.benchmark05(-1.3168356074998224,-1.5707963267948963,-51.66955462515561 ) ;
  }

  @Test
  public void test2740() {
    coral.tests.JPFBenchmark.benchmark05(-1.3172289969360729,-1.5707963267948966,6.28330740006865 ) ;
  }

  @Test
  public void test2741() {
    coral.tests.JPFBenchmark.benchmark05(-1.31853618008348,-0.28996962546897637,119.27262057806166 ) ;
  }

  @Test
  public void test2742() {
    coral.tests.JPFBenchmark.benchmark05(-1.318978091240524,-1.1396019437670872,1.570796328641336 ) ;
  }

  @Test
  public void test2743() {
    coral.tests.JPFBenchmark.benchmark05(-1.319313380638051,-16.056565026445483,-8.25914284756264 ) ;
  }

  @Test
  public void test2744() {
    coral.tests.JPFBenchmark.benchmark05(-1.319404128271743,-8.881784197001252E-16,26.934603069077113 ) ;
  }

  @Test
  public void test2745() {
    coral.tests.JPFBenchmark.benchmark05(-1.319538401209091,-0.011813522548742232,-49.728404441259286 ) ;
  }

  @Test
  public void test2746() {
    coral.tests.JPFBenchmark.benchmark05(-1.3196518383042175,-122.662232702224,4.7123890197282865 ) ;
  }

  @Test
  public void test2747() {
    coral.tests.JPFBenchmark.benchmark05(-1.3200042718595066,-34.82259263250553,-1.5707963267948966 ) ;
  }

  @Test
  public void test2748() {
    coral.tests.JPFBenchmark.benchmark05(-1.3211030417323038,-1.5707963267948966,-10.326701077799168 ) ;
  }

  @Test
  public void test2749() {
    coral.tests.JPFBenchmark.benchmark05(-1.3212555530043335,28.703537555548188,-100.0 ) ;
  }

  @Test
  public void test2750() {
    coral.tests.JPFBenchmark.benchmark05(-1.3221541781696322,-1.4376759017750738,60.672103982941564 ) ;
  }

  @Test
  public void test2751() {
    coral.tests.JPFBenchmark.benchmark05(-1.3226349940912789E-12,-1.5707963267948342,-156.02314529233237 ) ;
  }

  @Test
  public void test2752() {
    coral.tests.JPFBenchmark.benchmark05(-1.3240537026310073,-72.85324346711137,19.110267994332233 ) ;
  }

  @Test
  public void test2753() {
    coral.tests.JPFBenchmark.benchmark05(-1.324497851546144,-0.5581941398892276,-78.07053479089004 ) ;
  }

  @Test
  public void test2754() {
    coral.tests.JPFBenchmark.benchmark05(-1.324505441691374,-42.25546434709949,-14.13912006616861 ) ;
  }

  @Test
  public void test2755() {
    coral.tests.JPFBenchmark.benchmark05(-1.324692150613629,-73.17415455228408,12.568323739552042 ) ;
  }

  @Test
  public void test2756() {
    coral.tests.JPFBenchmark.benchmark05(-1.324889249396516,-0.22659798253434493,-1.5707963267948983 ) ;
  }

  @Test
  public void test2757() {
    coral.tests.JPFBenchmark.benchmark05(-1.3257689864590159,-1.420362046826711,-0.8648231943188307 ) ;
  }

  @Test
  public void test2758() {
    coral.tests.JPFBenchmark.benchmark05(-1.3261420085867452,-0.16950659004471846,0.0 ) ;
  }

  @Test
  public void test2759() {
    coral.tests.JPFBenchmark.benchmark05(-1.3270836201937202,-72.7660163082333,1.5707963267948912 ) ;
  }

  @Test
  public void test2760() {
    coral.tests.JPFBenchmark.benchmark05(-1.3273934316633922,-15.938848981489073,1.5707963267948966 ) ;
  }

  @Test
  public void test2761() {
    coral.tests.JPFBenchmark.benchmark05(-1.3276700994099397,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test2762() {
    coral.tests.JPFBenchmark.benchmark05(-1.3279980743204955,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2763() {
    coral.tests.JPFBenchmark.benchmark05(-1.3285197988439537,-1.2500113838840463,39.39146449560542 ) ;
  }

  @Test
  public void test2764() {
    coral.tests.JPFBenchmark.benchmark05(-1.3293588100822866,-9.565171107602367,-107.47603359375941 ) ;
  }

  @Test
  public void test2765() {
    coral.tests.JPFBenchmark.benchmark05(-1.3296578378941754E-15,-1.5707963267948966,2.3995149022330095E-240 ) ;
  }

  @Test
  public void test2766() {
    coral.tests.JPFBenchmark.benchmark05(13.297225589992664,7.452968480828574,-74.8867032815942 ) ;
  }

  @Test
  public void test2767() {
    coral.tests.JPFBenchmark.benchmark05(-1.3306263610257123,-1.2192779801953824,-31.795134881561452 ) ;
  }

  @Test
  public void test2768() {
    coral.tests.JPFBenchmark.benchmark05(-1.3324319135717637,-1.5707963267948966,54.7887950339948 ) ;
  }

  @Test
  public void test2769() {
    coral.tests.JPFBenchmark.benchmark05(-1.332459987665219,-3.66065604268055,31.621281761793256 ) ;
  }

  @Test
  public void test2770() {
    coral.tests.JPFBenchmark.benchmark05(-1.332925598265649,-0.2650698900911471,-1.5707963267949054 ) ;
  }

  @Test
  public void test2771() {
    coral.tests.JPFBenchmark.benchmark05(-1.333834466381212,-42.03321272213432,-88.25800869549968 ) ;
  }

  @Test
  public void test2772() {
    coral.tests.JPFBenchmark.benchmark05(-1.3347146692919256,-0.8535969112184056,0.0 ) ;
  }

  @Test
  public void test2773() {
    coral.tests.JPFBenchmark.benchmark05(-1.3349576714427194,-1.3161082323829478,10.606147824664276 ) ;
  }

  @Test
  public void test2774() {
    coral.tests.JPFBenchmark.benchmark05(-1.3353526484398062,-1.57079632663002,1.5707963267948966 ) ;
  }

  @Test
  public void test2775() {
    coral.tests.JPFBenchmark.benchmark05(-1.3353579659595156,-1.5707963261443159,-42.63331507912212 ) ;
  }

  @Test
  public void test2776() {
    coral.tests.JPFBenchmark.benchmark05(-1.3354877161595882,-1.5707963267916547,34.25529243411748 ) ;
  }

  @Test
  public void test2777() {
    coral.tests.JPFBenchmark.benchmark05(-1.336171839732835,-1.5707963267948966,-25.51300275251178 ) ;
  }

  @Test
  public void test2778() {
    coral.tests.JPFBenchmark.benchmark05(-1.33621784856588,-84.92512757110505,55.28203998144475 ) ;
  }

  @Test
  public void test2779() {
    coral.tests.JPFBenchmark.benchmark05(-1.3366290385795403,-72.8304994304437,1.5707963267948966 ) ;
  }

  @Test
  public void test2780() {
    coral.tests.JPFBenchmark.benchmark05(-1.3378465817290826,-1.1119838795765986,34.66984999046804 ) ;
  }

  @Test
  public void test2781() {
    coral.tests.JPFBenchmark.benchmark05(-1.3382445468148714,-1.5707963267948966,-28.237750370716668 ) ;
  }

  @Test
  public void test2782() {
    coral.tests.JPFBenchmark.benchmark05(-1.3400576685534606,-1.5707963267950404,97.74564846970641 ) ;
  }

  @Test
  public void test2783() {
    coral.tests.JPFBenchmark.benchmark05(-1.3421031941976587,-1.5707963267948966,78.44707983119463 ) ;
  }

  @Test
  public void test2784() {
    coral.tests.JPFBenchmark.benchmark05(-1.3425815578293538,-1.5707963267948974,-1.5707963267948966 ) ;
  }

  @Test
  public void test2785() {
    coral.tests.JPFBenchmark.benchmark05(-1.3426542093575375,-48.35093218697453,0.23713177071577315 ) ;
  }

  @Test
  public void test2786() {
    coral.tests.JPFBenchmark.benchmark05(-1.3432195804866556,-191.77520032867523,-46.59883259230468 ) ;
  }

  @Test
  public void test2787() {
    coral.tests.JPFBenchmark.benchmark05(-1.3444597475288873,-3.4453977438233867,-9.386378928361935 ) ;
  }

  @Test
  public void test2788() {
    coral.tests.JPFBenchmark.benchmark05(-1.345594297802485,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2789() {
    coral.tests.JPFBenchmark.benchmark05(13.459615921929569,-53.581939659572456,93.04456541200051 ) ;
  }

  @Test
  public void test2790() {
    coral.tests.JPFBenchmark.benchmark05(-1.3459810371457301,14.581840706331612,79.78178223629416 ) ;
  }

  @Test
  public void test2791() {
    coral.tests.JPFBenchmark.benchmark05(-1.3462604021694702,-0.9434997032676897,-8.352228132934467 ) ;
  }

  @Test
  public void test2792() {
    coral.tests.JPFBenchmark.benchmark05(-1.3465659837831352,2.429840079339756,-40.47757566156095 ) ;
  }

  @Test
  public void test2793() {
    coral.tests.JPFBenchmark.benchmark05(-1.3468596856512938,-1.5707963267948957,1.5707963267948966 ) ;
  }

  @Test
  public void test2794() {
    coral.tests.JPFBenchmark.benchmark05(-1.348420688893744E-16,-2.7755575615628914E-17,-15.758419072838702 ) ;
  }

  @Test
  public void test2795() {
    coral.tests.JPFBenchmark.benchmark05(-1.3489944942117575,-0.3918205442149356,70.09340826787988 ) ;
  }

  @Test
  public void test2796() {
    coral.tests.JPFBenchmark.benchmark05(-1.3491707308437646,-1.3789392415728585,-85.88785208277012 ) ;
  }

  @Test
  public void test2797() {
    coral.tests.JPFBenchmark.benchmark05(-1.350104697560115,-0.3521560137557609,-1.5707963194387837 ) ;
  }

  @Test
  public void test2798() {
    coral.tests.JPFBenchmark.benchmark05(-13.505619547938835,75.94645691259555,1.2013553014383263 ) ;
  }

  @Test
  public void test2799() {
    coral.tests.JPFBenchmark.benchmark05(-1.3518029368423923,-1.5707963266169007,100.0 ) ;
  }

  @Test
  public void test2800() {
    coral.tests.JPFBenchmark.benchmark05(-1.3519402368008695,-192.41561337780539,77.49902073792018 ) ;
  }

  @Test
  public void test2801() {
    coral.tests.JPFBenchmark.benchmark05(-1.3528173629052227,-35.61912605959285,-68.73383682661621 ) ;
  }

  @Test
  public void test2802() {
    coral.tests.JPFBenchmark.benchmark05(-1.3535765080956919,-22.464279747494526,56.1002420671705 ) ;
  }

  @Test
  public void test2803() {
    coral.tests.JPFBenchmark.benchmark05(-1.3536049880069663,-41.71530353124363,-78.57449616050873 ) ;
  }

  @Test
  public void test2804() {
    coral.tests.JPFBenchmark.benchmark05(-1.3543029452325008,-85.01044010926275,-53.85912143023599 ) ;
  }

  @Test
  public void test2805() {
    coral.tests.JPFBenchmark.benchmark05(-1.3547203378957913,-4.070940510726716,-44.109522352019724 ) ;
  }

  @Test
  public void test2806() {
    coral.tests.JPFBenchmark.benchmark05(-1.3548796397084857,-1.5707963267948966,66.53835591301319 ) ;
  }

  @Test
  public void test2807() {
    coral.tests.JPFBenchmark.benchmark05(-1.3552527156068805E-20,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2808() {
    coral.tests.JPFBenchmark.benchmark05(1.3552527156068805E-20,-22.36527822095193,-89.45206667306871 ) ;
  }

  @Test
  public void test2809() {
    coral.tests.JPFBenchmark.benchmark05(-1.3552527156068805E-20,-72.8526572449667,29.451255699884484 ) ;
  }

  @Test
  public void test2810() {
    coral.tests.JPFBenchmark.benchmark05(-1.3552570599246607,-1.5707963267948966,15.893921394425398 ) ;
  }

  @Test
  public void test2811() {
    coral.tests.JPFBenchmark.benchmark05(-1.3555384923849374,-1.0362151345528128,1.5707963534046656 ) ;
  }

  @Test
  public void test2812() {
    coral.tests.JPFBenchmark.benchmark05(-1.3562002129475243E-5,-98.07649912531417,-114.43744752557218 ) ;
  }

  @Test
  public void test2813() {
    coral.tests.JPFBenchmark.benchmark05(-1.3569023161131355,-1.5707963267948957,-51.79256013506666 ) ;
  }

  @Test
  public void test2814() {
    coral.tests.JPFBenchmark.benchmark05(-1.3570443139458304,-2.7755575615628914E-17,28.026729764491858 ) ;
  }

  @Test
  public void test2815() {
    coral.tests.JPFBenchmark.benchmark05(-1.3572690696149534,-15.982159290398243,91.6911096476893 ) ;
  }

  @Test
  public void test2816() {
    coral.tests.JPFBenchmark.benchmark05(-1.357595817665433,-1.5707963267948966,8.08279833488055 ) ;
  }

  @Test
  public void test2817() {
    coral.tests.JPFBenchmark.benchmark05(-1.3576498179913221,-1.1908549335301708,-66.48665681212954 ) ;
  }

  @Test
  public void test2818() {
    coral.tests.JPFBenchmark.benchmark05(-1.3580685747941112,-0.25456081184915436,1.3136000383640896 ) ;
  }

  @Test
  public void test2819() {
    coral.tests.JPFBenchmark.benchmark05(-1.358256335831789,-34.573946418301375,-147.6112485193067 ) ;
  }

  @Test
  public void test2820() {
    coral.tests.JPFBenchmark.benchmark05(-1.3586489868151261,-1.2594450892801714,-952.9299204983433 ) ;
  }

  @Test
  public void test2821() {
    coral.tests.JPFBenchmark.benchmark05(-1.3588512914054962,-41.43795455484721,5.611031933461512E-191 ) ;
  }

  @Test
  public void test2822() {
    coral.tests.JPFBenchmark.benchmark05(-1.359104088595072,-1.5707963267948966,-0.6500006286880282 ) ;
  }

  @Test
  public void test2823() {
    coral.tests.JPFBenchmark.benchmark05(-1.3593127616495995,-15.949736340918424,26.83133289246198 ) ;
  }

  @Test
  public void test2824() {
    coral.tests.JPFBenchmark.benchmark05(-1.359390597414224,-98.51023443728842,-67.60691531804878 ) ;
  }

  @Test
  public void test2825() {
    coral.tests.JPFBenchmark.benchmark05(-1.3614577292256516,-1.5707963267948966,-12.568323952018854 ) ;
  }

  @Test
  public void test2826() {
    coral.tests.JPFBenchmark.benchmark05(-1.3615244579829975,-0.033375702552968824,232.4424575299127 ) ;
  }

  @Test
  public void test2827() {
    coral.tests.JPFBenchmark.benchmark05(-1.3627984781618854,-1.5707963267948966,77.76754536378655 ) ;
  }

  @Test
  public void test2828() {
    coral.tests.JPFBenchmark.benchmark05(-1.3629566056265918,-3.306648328476981,0.0 ) ;
  }

  @Test
  public void test2829() {
    coral.tests.JPFBenchmark.benchmark05(-1.3630949512163812,-73.10195914024445,32.478632664046955 ) ;
  }

  @Test
  public void test2830() {
    coral.tests.JPFBenchmark.benchmark05(-1.363167080296591,-9.492430155317384,1.5708882910378725 ) ;
  }

  @Test
  public void test2831() {
    coral.tests.JPFBenchmark.benchmark05(-1.36331195308774,-66.46311592439466,14.42920403994426 ) ;
  }

  @Test
  public void test2832() {
    coral.tests.JPFBenchmark.benchmark05(-1.3635195645488352,-9.99368662044374,22.381309451464745 ) ;
  }

  @Test
  public void test2833() {
    coral.tests.JPFBenchmark.benchmark05(-1.3636597368974481,-72.25752538329654,-47.04070059895193 ) ;
  }

  @Test
  public void test2834() {
    coral.tests.JPFBenchmark.benchmark05(-1.3637150398520852,-1.549548438947064,39.559410187098244 ) ;
  }

  @Test
  public void test2835() {
    coral.tests.JPFBenchmark.benchmark05(-1.364126245672582,-48.70200558801956,1.5707963267948966 ) ;
  }

  @Test
  public void test2836() {
    coral.tests.JPFBenchmark.benchmark05(-1.365708997909722,-1.459584659454182,-0.01766651340745489 ) ;
  }

  @Test
  public void test2837() {
    coral.tests.JPFBenchmark.benchmark05(-1.3662036688051273,-10.215460924837359,0.0 ) ;
  }

  @Test
  public void test2838() {
    coral.tests.JPFBenchmark.benchmark05(-1.3662863449023894,-0.7750386982640278,1.5707963267948963 ) ;
  }

  @Test
  public void test2839() {
    coral.tests.JPFBenchmark.benchmark05(-1.366547996839273,-2.220446049250313E-16,51.49183970356182 ) ;
  }

  @Test
  public void test2840() {
    coral.tests.JPFBenchmark.benchmark05(-1.3674630212795384,-66.09667741355103,20.47447381002027 ) ;
  }

  @Test
  public void test2841() {
    coral.tests.JPFBenchmark.benchmark05(-1.3682034799951879,-1.5707963267948966,-9.573334647180303 ) ;
  }

  @Test
  public void test2842() {
    coral.tests.JPFBenchmark.benchmark05(-1.3682448860275447,-34.64113913357008,-1.5707963267948966 ) ;
  }

  @Test
  public void test2843() {
    coral.tests.JPFBenchmark.benchmark05(1.3683462205040893,-3.2679555576536843,-135.89129711472592 ) ;
  }

  @Test
  public void test2844() {
    coral.tests.JPFBenchmark.benchmark05(13.6857472638726,-90.00748495519272,-57.816298316477614 ) ;
  }

  @Test
  public void test2845() {
    coral.tests.JPFBenchmark.benchmark05(-1.3695529891522304,-1.5434871379182227,-36.64961914803144 ) ;
  }

  @Test
  public void test2846() {
    coral.tests.JPFBenchmark.benchmark05(13.696955226941881,-5.879459579384431,90.09364560038361 ) ;
  }

  @Test
  public void test2847() {
    coral.tests.JPFBenchmark.benchmark05(-1.3702702197223295,-1.5707963267948966,-83.77249398869634 ) ;
  }

  @Test
  public void test2848() {
    coral.tests.JPFBenchmark.benchmark05(-1.3714500316454403,-3.1618553161776575,-1.228988357478464 ) ;
  }

  @Test
  public void test2849() {
    coral.tests.JPFBenchmark.benchmark05(-1.371614144455988,-1.5707963267948912,-1.5707963267948966 ) ;
  }

  @Test
  public void test2850() {
    coral.tests.JPFBenchmark.benchmark05(-1.3731703965317714,-34.890517372817115,100.77976813703138 ) ;
  }

  @Test
  public void test2851() {
    coral.tests.JPFBenchmark.benchmark05(-1.3734857991122305,-1.5707963267948963,1.4555072542979985 ) ;
  }

  @Test
  public void test2852() {
    coral.tests.JPFBenchmark.benchmark05(-1.3736747873028117,-1.5707963267948961,-83.4428218778981 ) ;
  }

  @Test
  public void test2853() {
    coral.tests.JPFBenchmark.benchmark05(-1.3737441087187852,-1.5507783004508597,0.0 ) ;
  }

  @Test
  public void test2854() {
    coral.tests.JPFBenchmark.benchmark05(-1.3740228430588157E-6,-1.5707963267948912,31.983298344111656 ) ;
  }

  @Test
  public void test2855() {
    coral.tests.JPFBenchmark.benchmark05(-1.3744995832776823,-0.45766988822908017,-72.92923078555047 ) ;
  }

  @Test
  public void test2856() {
    coral.tests.JPFBenchmark.benchmark05(-1.3745266740171749,-1.5707963267948948,-47.150466556184774 ) ;
  }

  @Test
  public void test2857() {
    coral.tests.JPFBenchmark.benchmark05(-1.3750243900975292,-98.91517486243653,98.32225771487359 ) ;
  }

  @Test
  public void test2858() {
    coral.tests.JPFBenchmark.benchmark05(-1.3752032700203405,-41.05502041520887,6.28318532041752 ) ;
  }

  @Test
  public void test2859() {
    coral.tests.JPFBenchmark.benchmark05(-1.3765427937135317,-1.5707963267948966,-524.4497019920917 ) ;
  }

  @Test
  public void test2860() {
    coral.tests.JPFBenchmark.benchmark05(-1.3769407152881918,-952.9352662282072,1.5707963267948961 ) ;
  }

  @Test
  public void test2861() {
    coral.tests.JPFBenchmark.benchmark05(-1.3769499413359445,-1.5707963267931964,-83.61078284652967 ) ;
  }

  @Test
  public void test2862() {
    coral.tests.JPFBenchmark.benchmark05(-1.3769530526371416,-0.38187783478583315,0.0 ) ;
  }

  @Test
  public void test2863() {
    coral.tests.JPFBenchmark.benchmark05(-1.3771107667956333,-1.0106174620987646E-31,-40.369199093911526 ) ;
  }

  @Test
  public void test2864() {
    coral.tests.JPFBenchmark.benchmark05(-1.3779370058651352,0.7809067481120537,75.63188500283437 ) ;
  }

  @Test
  public void test2865() {
    coral.tests.JPFBenchmark.benchmark05(-1.3783239147836537,-66.24093502675426,-37.078232585321835 ) ;
  }

  @Test
  public void test2866() {
    coral.tests.JPFBenchmark.benchmark05(-1.3788507610975884,-16.024997653171106,-0.29883807086518743 ) ;
  }

  @Test
  public void test2867() {
    coral.tests.JPFBenchmark.benchmark05(-1.3788578710465056,-61.20231278811195,92.87480057571494 ) ;
  }

  @Test
  public void test2868() {
    coral.tests.JPFBenchmark.benchmark05(1.3792840856292798,0,0 ) ;
  }

  @Test
  public void test2869() {
    coral.tests.JPFBenchmark.benchmark05(-1.3794222917415435,-47.23546964672721,-1.570796326794897 ) ;
  }

  @Test
  public void test2870() {
    coral.tests.JPFBenchmark.benchmark05(-1.3801661174085849,-1.5707963267948912,-88.78830882399443 ) ;
  }

  @Test
  public void test2871() {
    coral.tests.JPFBenchmark.benchmark05(-1.3805191666130967,-0.7312942989061932,26.883865568937864 ) ;
  }

  @Test
  public void test2872() {
    coral.tests.JPFBenchmark.benchmark05(-1.3806340381994933,-1.5707963267948912,-111.87631297245694 ) ;
  }

  @Test
  public void test2873() {
    coral.tests.JPFBenchmark.benchmark05(-1.3816180498983888,-1.3679844691861405,22.47337600323273 ) ;
  }

  @Test
  public void test2874() {
    coral.tests.JPFBenchmark.benchmark05(-1.3822587865914906E-17,-1.5707963267948966,-43.986203400317656 ) ;
  }

  @Test
  public void test2875() {
    coral.tests.JPFBenchmark.benchmark05(-1.3829909269391225,-72.40019636878766,-6.285076799730907 ) ;
  }

  @Test
  public void test2876() {
    coral.tests.JPFBenchmark.benchmark05(-1.3833802242769078,3.3881317890172014E-21,100.0 ) ;
  }

  @Test
  public void test2877() {
    coral.tests.JPFBenchmark.benchmark05(-1.3841431746589956,-0.5683390401467179,-50.15597903730593 ) ;
  }

  @Test
  public void test2878() {
    coral.tests.JPFBenchmark.benchmark05(-1.3848107209093492,-0.015971484891968202,111.85287999310492 ) ;
  }

  @Test
  public void test2879() {
    coral.tests.JPFBenchmark.benchmark05(-1.3851357166395148,4.141592653610029,1.138493222237532 ) ;
  }

  @Test
  public void test2880() {
    coral.tests.JPFBenchmark.benchmark05(-1.3851726897829595,14.429282394490393,6.326712947728015 ) ;
  }

  @Test
  public void test2881() {
    coral.tests.JPFBenchmark.benchmark05(-1.3853516410904476,-0.9073135300761502,90.09651169081592 ) ;
  }

  @Test
  public void test2882() {
    coral.tests.JPFBenchmark.benchmark05(-1.3858245895347634,-54.46956832420598,-89.82807075389714 ) ;
  }

  @Test
  public void test2883() {
    coral.tests.JPFBenchmark.benchmark05(-1.3867505920796734,-0.8904482882589778,548.2079159832228 ) ;
  }

  @Test
  public void test2884() {
    coral.tests.JPFBenchmark.benchmark05(1.3877787807814457E-17,-1.3379429917987768,100.0 ) ;
  }

  @Test
  public void test2885() {
    coral.tests.JPFBenchmark.benchmark05(-1.3877787807814457E-17,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2886() {
    coral.tests.JPFBenchmark.benchmark05(-1.3877787807814457E-17,-1.5707963267953131,-0.7610960396471182 ) ;
  }

  @Test
  public void test2887() {
    coral.tests.JPFBenchmark.benchmark05(-1.3877787807814457E-17,-3.298339834484718,1.5153274809896402 ) ;
  }

  @Test
  public void test2888() {
    coral.tests.JPFBenchmark.benchmark05(-1.3877787807814457E-17,4.141592653589848,1.4723663958659197 ) ;
  }

  @Test
  public void test2889() {
    coral.tests.JPFBenchmark.benchmark05(-1.3877787807814457E-17,-4.2351647362715017E-22,98.96016858807849 ) ;
  }

  @Test
  public void test2890() {
    coral.tests.JPFBenchmark.benchmark05(-1.3883205935616911,-9.940912221196285,3.1435457837111755 ) ;
  }

  @Test
  public void test2891() {
    coral.tests.JPFBenchmark.benchmark05(-1.3884395865194996,-1.3374869348079503,-32.159861140544734 ) ;
  }

  @Test
  public void test2892() {
    coral.tests.JPFBenchmark.benchmark05(-1.3885882016128965,-0.007564871488701559,-17.32588374898546 ) ;
  }

  @Test
  public void test2893() {
    coral.tests.JPFBenchmark.benchmark05(-1.3892374139291122,-0.6252198526393851,4.3368086899420177E-19 ) ;
  }

  @Test
  public void test2894() {
    coral.tests.JPFBenchmark.benchmark05(-1.389344853063494,-1.5707963267948948,23.019336255948787 ) ;
  }

  @Test
  public void test2895() {
    coral.tests.JPFBenchmark.benchmark05(-1.3897903392678082,-97.70581826870063,48.38157946680897 ) ;
  }

  @Test
  public void test2896() {
    coral.tests.JPFBenchmark.benchmark05(-1.3899167169973412,-1.5707963267948966,3.967375508960444 ) ;
  }

  @Test
  public void test2897() {
    coral.tests.JPFBenchmark.benchmark05(-1.3905482352528304,-1.5707963267948966,41.935249885631606 ) ;
  }

  @Test
  public void test2898() {
    coral.tests.JPFBenchmark.benchmark05(-1.3911322907319006,-0.09947716333727709,-96.24311864812812 ) ;
  }

  @Test
  public void test2899() {
    coral.tests.JPFBenchmark.benchmark05(-1.3911516995029842,-15.895552107089841,-82.65687295111105 ) ;
  }

  @Test
  public void test2900() {
    coral.tests.JPFBenchmark.benchmark05(-1.391292343596388,-48.639799774458396,44.50895028451147 ) ;
  }

  @Test
  public void test2901() {
    coral.tests.JPFBenchmark.benchmark05(-1.3921984871436806,-191.81295464152456,-1.5707963267948963 ) ;
  }

  @Test
  public void test2902() {
    coral.tests.JPFBenchmark.benchmark05(1.3925344762356247,-78.3072753349024,76.10873767833826 ) ;
  }

  @Test
  public void test2903() {
    coral.tests.JPFBenchmark.benchmark05(-1.3928025372185289,-66.65309607499856,-1.5707963267949054 ) ;
  }

  @Test
  public void test2904() {
    coral.tests.JPFBenchmark.benchmark05(-1.3928975267129882,-41.80537978755619,-31.97392949316017 ) ;
  }

  @Test
  public void test2905() {
    coral.tests.JPFBenchmark.benchmark05(-1.3936125458931832,-16.029751451987934,55.32432227409882 ) ;
  }

  @Test
  public void test2906() {
    coral.tests.JPFBenchmark.benchmark05(-1.3937937859010225,-66.72661262180014,-10.255646385765743 ) ;
  }

  @Test
  public void test2907() {
    coral.tests.JPFBenchmark.benchmark05(-1.3949433881126136,-60.815856208240035,-31.35299454597694 ) ;
  }

  @Test
  public void test2908() {
    coral.tests.JPFBenchmark.benchmark05(-1.3960432524064208,-1.5707963267948948,-36.161887699594146 ) ;
  }

  @Test
  public void test2909() {
    coral.tests.JPFBenchmark.benchmark05(-1.3960579761753238,-47.38820427613872,-16.634268818171684 ) ;
  }

  @Test
  public void test2910() {
    coral.tests.JPFBenchmark.benchmark05(-1.3964074762984544,-16.169211431889153,47.73967743003109 ) ;
  }

  @Test
  public void test2911() {
    coral.tests.JPFBenchmark.benchmark05(-1.3964368655530874,-1.5707963267948912,40.35440612696236 ) ;
  }

  @Test
  public void test2912() {
    coral.tests.JPFBenchmark.benchmark05(-1.3966929794294387,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2913() {
    coral.tests.JPFBenchmark.benchmark05(-1.3970922640808363,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test2914() {
    coral.tests.JPFBenchmark.benchmark05(-1.3972090186812753,-1.5707963267948966,-59.56800519504662 ) ;
  }

  @Test
  public void test2915() {
    coral.tests.JPFBenchmark.benchmark05(-1.399299075237111,-0.9776586612283482,1.5707963267948968 ) ;
  }

  @Test
  public void test2916() {
    coral.tests.JPFBenchmark.benchmark05(-1.4002356040644734,-53.53984360499007,31.59720569165637 ) ;
  }

  @Test
  public void test2917() {
    coral.tests.JPFBenchmark.benchmark05(-1.400834921715174,4.1415926535964465,-1.5707963267948972 ) ;
  }

  @Test
  public void test2918() {
    coral.tests.JPFBenchmark.benchmark05(-1.4014025716712444,-72.38214938129832,-32.482521049735496 ) ;
  }

  @Test
  public void test2919() {
    coral.tests.JPFBenchmark.benchmark05(-1.4015655909318923,-15.762914982614141,1.570796326794893 ) ;
  }

  @Test
  public void test2920() {
    coral.tests.JPFBenchmark.benchmark05(-1.4016258207613037,-0.9735234944977462,85.83343788925276 ) ;
  }

  @Test
  public void test2921() {
    coral.tests.JPFBenchmark.benchmark05(-1.4024131454869293,-0.05453609565936812,2247.265703126668 ) ;
  }

  @Test
  public void test2922() {
    coral.tests.JPFBenchmark.benchmark05(-1.4026221282962446,-66.26934902430331,-12.511524847053977 ) ;
  }

  @Test
  public void test2923() {
    coral.tests.JPFBenchmark.benchmark05(-1.4027885011435621,-1.552132984582324,-135.61186261670838 ) ;
  }

  @Test
  public void test2924() {
    coral.tests.JPFBenchmark.benchmark05(-1.4029295777995965,-15.725094489550171,-44.645185673091845 ) ;
  }

  @Test
  public void test2925() {
    coral.tests.JPFBenchmark.benchmark05(-1.4033233322113563,-1.5707963267948948,639.2495542692175 ) ;
  }

  @Test
  public void test2926() {
    coral.tests.JPFBenchmark.benchmark05(-1.4043170973527035,-66.08793450654765,-64.65975005433621 ) ;
  }

  @Test
  public void test2927() {
    coral.tests.JPFBenchmark.benchmark05(-1.4058991699049432,-47.22949608322074,44.6992560290806 ) ;
  }

  @Test
  public void test2928() {
    coral.tests.JPFBenchmark.benchmark05(-1.405989361896281E-17,-1.5707963267948966,-17.278759594741288 ) ;
  }

  @Test
  public void test2929() {
    coral.tests.JPFBenchmark.benchmark05(-1.4060395838001805,-1.3736507768444497,182.16338535314128 ) ;
  }

  @Test
  public void test2930() {
    coral.tests.JPFBenchmark.benchmark05(-1.4063775421934868,-1.5707963267948966,-97.95628110508487 ) ;
  }

  @Test
  public void test2931() {
    coral.tests.JPFBenchmark.benchmark05(-1.4069778719547903,-3.141592668490961,26.913372177539415 ) ;
  }

  @Test
  public void test2932() {
    coral.tests.JPFBenchmark.benchmark05(-1.407794771182814,-8.881784197001252E-16,-50.83931604654953 ) ;
  }

  @Test
  public void test2933() {
    coral.tests.JPFBenchmark.benchmark05(-1.4088407314736535E-132,-16.19764586468167,-20.311887541484765 ) ;
  }

  @Test
  public void test2934() {
    coral.tests.JPFBenchmark.benchmark05(-1.4090715449746476,-1.5707963267948963,-90.85181510686307 ) ;
  }

  @Test
  public void test2935() {
    coral.tests.JPFBenchmark.benchmark05(-1.40944111198516,-1.5707963267948948,-0.6874566501779475 ) ;
  }

  @Test
  public void test2936() {
    coral.tests.JPFBenchmark.benchmark05(-1.4095766448215261,-1.5707963267948966,24.435829242069413 ) ;
  }

  @Test
  public void test2937() {
    coral.tests.JPFBenchmark.benchmark05(-1.409642982086329,-0.9754284654849199,75.05102437690307 ) ;
  }

  @Test
  public void test2938() {
    coral.tests.JPFBenchmark.benchmark05(-1.4103319322998331,-22.415786364894956,-100.0 ) ;
  }

  @Test
  public void test2939() {
    coral.tests.JPFBenchmark.benchmark05(-1.4106926464755638,-0.355153074493459,1.5707963267948966 ) ;
  }

  @Test
  public void test2940() {
    coral.tests.JPFBenchmark.benchmark05(-1.411669940398549,-1.5707963267948983,674.3328481327463 ) ;
  }

  @Test
  public void test2941() {
    coral.tests.JPFBenchmark.benchmark05(-1.411824264180898,-122.79817503911437,-19.673505171670875 ) ;
  }

  @Test
  public void test2942() {
    coral.tests.JPFBenchmark.benchmark05(-1.4118734783466471,-1.5707963267948992,-181.13588730450059 ) ;
  }

  @Test
  public void test2943() {
    coral.tests.JPFBenchmark.benchmark05(-1.4129954921191943,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2944() {
    coral.tests.JPFBenchmark.benchmark05(-1.4145345058257262,-1.4720112778724683,36.40027029035909 ) ;
  }

  @Test
  public void test2945() {
    coral.tests.JPFBenchmark.benchmark05(-1.4145394716555586,-186.2799451315027,64.46018107990955 ) ;
  }

  @Test
  public void test2946() {
    coral.tests.JPFBenchmark.benchmark05(-1.4145409953354255,-3.1415926547865625,-7.082950154005995 ) ;
  }

  @Test
  public void test2947() {
    coral.tests.JPFBenchmark.benchmark05(-1.4146192416100902,-40.97598297399917,-69.47333157229225 ) ;
  }

  @Test
  public void test2948() {
    coral.tests.JPFBenchmark.benchmark05(-1.4154759763082243,-1.5707963267948966,77.75449088708689 ) ;
  }

  @Test
  public void test2949() {
    coral.tests.JPFBenchmark.benchmark05(-1.4157587007561778,-1.5707963267948966,-39.12122904197397 ) ;
  }

  @Test
  public void test2950() {
    coral.tests.JPFBenchmark.benchmark05(-1.4164047622772624,-35.691228973419626,57.205490942527774 ) ;
  }

  @Test
  public void test2951() {
    coral.tests.JPFBenchmark.benchmark05(-1.4170243682738537,-0.5008000236925483,-1.5707963267948966 ) ;
  }

  @Test
  public void test2952() {
    coral.tests.JPFBenchmark.benchmark05(-1.4173820511572242,-0.31065670135632073,-29.24921180618974 ) ;
  }

  @Test
  public void test2953() {
    coral.tests.JPFBenchmark.benchmark05(-1.418987944552577,-78.55563835061662,164.5635218139841 ) ;
  }

  @Test
  public void test2954() {
    coral.tests.JPFBenchmark.benchmark05(-1.4191628167917751,-0.26046832722032287,-7.213264545145106E-130 ) ;
  }

  @Test
  public void test2955() {
    coral.tests.JPFBenchmark.benchmark05(-1.4197550105401187,-1.5707963267948966,-6.283727915564683 ) ;
  }

  @Test
  public void test2956() {
    coral.tests.JPFBenchmark.benchmark05(-1.4199444623160649,-1.570796326794058,23.512350121556906 ) ;
  }

  @Test
  public void test2957() {
    coral.tests.JPFBenchmark.benchmark05(-1.4202291171849553,-1.5707963267948966,-54.68949928605458 ) ;
  }

  @Test
  public void test2958() {
    coral.tests.JPFBenchmark.benchmark05(-1.4202820262906644,-0.3566611139471171,21.597925228261207 ) ;
  }

  @Test
  public void test2959() {
    coral.tests.JPFBenchmark.benchmark05(-14.203001226255708,17.246451064940686,42.06775845995327 ) ;
  }

  @Test
  public void test2960() {
    coral.tests.JPFBenchmark.benchmark05(-1.4205826918993678,-1.5707963267948948,4.474828493109017 ) ;
  }

  @Test
  public void test2961() {
    coral.tests.JPFBenchmark.benchmark05(-1.420792875786687,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2962() {
    coral.tests.JPFBenchmark.benchmark05(-1.4210781051334007,-9.662507553169768,-33.81433506828424 ) ;
  }

  @Test
  public void test2963() {
    coral.tests.JPFBenchmark.benchmark05(-1.4218450338805722,-0.3052718760825802,4.14159327289282 ) ;
  }

  @Test
  public void test2964() {
    coral.tests.JPFBenchmark.benchmark05(-1.4221168073288035,-0.9949427022308113,3.141592653589796 ) ;
  }

  @Test
  public void test2965() {
    coral.tests.JPFBenchmark.benchmark05(-1.4223670393288828,-66.2977371396883,34.82201195886108 ) ;
  }

  @Test
  public void test2966() {
    coral.tests.JPFBenchmark.benchmark05(-1.4227389216827715,-0.4389372981753132,1.5707963267948968 ) ;
  }

  @Test
  public void test2967() {
    coral.tests.JPFBenchmark.benchmark05(14.22943752529207,46.47611305703805,59.64725974302414 ) ;
  }

  @Test
  public void test2968() {
    coral.tests.JPFBenchmark.benchmark05(-1.4242042205942078,-1.5707963267948966,19.52559110072447 ) ;
  }

  @Test
  public void test2969() {
    coral.tests.JPFBenchmark.benchmark05(-1.4242137706988722,-41.54408084217782,19.933515167327116 ) ;
  }

  @Test
  public void test2970() {
    coral.tests.JPFBenchmark.benchmark05(-1.4244905073757166,-1.5707963267948966,8.359386360246923 ) ;
  }

  @Test
  public void test2971() {
    coral.tests.JPFBenchmark.benchmark05(-1.424566653703938,-1.5707963267948966,-69.41165715801978 ) ;
  }

  @Test
  public void test2972() {
    coral.tests.JPFBenchmark.benchmark05(-1.4258286670956244,-35.42570123098679,-21.99114857512855 ) ;
  }

  @Test
  public void test2973() {
    coral.tests.JPFBenchmark.benchmark05(-1.4259208367305263,-1.3650074121725786,22.285906936642778 ) ;
  }

  @Test
  public void test2974() {
    coral.tests.JPFBenchmark.benchmark05(-1.4262893263016458,-15.727846041749178,72.34334597533746 ) ;
  }

  @Test
  public void test2975() {
    coral.tests.JPFBenchmark.benchmark05(-1.42658064105876,-1.5707963267948966,657.9797951620118 ) ;
  }

  @Test
  public void test2976() {
    coral.tests.JPFBenchmark.benchmark05(-1.4266957397750557,-1.5707963267948966,-1.5707963267948806 ) ;
  }

  @Test
  public void test2977() {
    coral.tests.JPFBenchmark.benchmark05(-1.4275084819621526,-9.499858221105088,-1.5707963267948966 ) ;
  }

  @Test
  public void test2978() {
    coral.tests.JPFBenchmark.benchmark05(-1.4280291108090593,-22.358592168300873,3.36406813353274 ) ;
  }

  @Test
  public void test2979() {
    coral.tests.JPFBenchmark.benchmark05(-1.4280372865835023,9.42527210110975,-44.36665847955826 ) ;
  }

  @Test
  public void test2980() {
    coral.tests.JPFBenchmark.benchmark05(-1.4281085991496383,-1.5707963267948948,-3.141592653589795 ) ;
  }

  @Test
  public void test2981() {
    coral.tests.JPFBenchmark.benchmark05(-1.4281837003352007,-1.5707963267948966,3.1437248416796875 ) ;
  }

  @Test
  public void test2982() {
    coral.tests.JPFBenchmark.benchmark05(-1.428587291681432,-1.5707963267948966,-466.126421697444 ) ;
  }

  @Test
  public void test2983() {
    coral.tests.JPFBenchmark.benchmark05(-1.4298960469217352,-122.8303384641975,-6.283198433728497 ) ;
  }

  @Test
  public void test2984() {
    coral.tests.JPFBenchmark.benchmark05(-1.429931415309386,-1.5490367659397273E-120,-4.577446090374227 ) ;
  }

  @Test
  public void test2985() {
    coral.tests.JPFBenchmark.benchmark05(-1.4305087852964575,-47.28031024192708,87.96467165151016 ) ;
  }

  @Test
  public void test2986() {
    coral.tests.JPFBenchmark.benchmark05(-1.4316991864825015,-54.554309837518815,45.19605700000764 ) ;
  }

  @Test
  public void test2987() {
    coral.tests.JPFBenchmark.benchmark05(-1.4317294918749308,-1.5707963267948966,49.13797474824968 ) ;
  }

  @Test
  public void test2988() {
    coral.tests.JPFBenchmark.benchmark05(-1.4322589129703776,-10.179257423379196,3.1415943456135254 ) ;
  }

  @Test
  public void test2989() {
    coral.tests.JPFBenchmark.benchmark05(-1.4322691950647228,-84.93017742532132,-56.59487889448253 ) ;
  }

  @Test
  public void test2990() {
    coral.tests.JPFBenchmark.benchmark05(-1.4323256516631173,-1.015029406487888,-24.113877085831216 ) ;
  }

  @Test
  public void test2991() {
    coral.tests.JPFBenchmark.benchmark05(-1.4337083200572516,-66.56179662021837,-56.859003405717736 ) ;
  }

  @Test
  public void test2992() {
    coral.tests.JPFBenchmark.benchmark05(-1.4343540916081359,-16.19110517771429,-76.9699849014034 ) ;
  }

  @Test
  public void test2993() {
    coral.tests.JPFBenchmark.benchmark05(-1.4359268827066842,-54.89257695079976,-18.850544193937495 ) ;
  }

  @Test
  public void test2994() {
    coral.tests.JPFBenchmark.benchmark05(-1.4369883890310633,-104.48149559311878,42.16150739203957 ) ;
  }

  @Test
  public void test2995() {
    coral.tests.JPFBenchmark.benchmark05(-1.4372076056156597,-1.484203982353745,-146.0866631624762 ) ;
  }

  @Test
  public void test2996() {
    coral.tests.JPFBenchmark.benchmark05(1.4376802443141372,35.68145194538383,-16.65581221682811 ) ;
  }

  @Test
  public void test2997() {
    coral.tests.JPFBenchmark.benchmark05(-1.4382408084210025,-35.812025465814145,-35.52718639143885 ) ;
  }

  @Test
  public void test2998() {
    coral.tests.JPFBenchmark.benchmark05(-1.4385287859702691,-1.5707963267948963,-27.91748628901675 ) ;
  }

  @Test
  public void test2999() {
    coral.tests.JPFBenchmark.benchmark05(-1.4389185419371973,-1.26999592142276,137.72438560717706 ) ;
  }

  @Test
  public void test3000() {
    coral.tests.JPFBenchmark.benchmark05(-1.4392657220752578,-1.5707963267948966,-64.59797188053096 ) ;
  }

  @Test
  public void test3001() {
    coral.tests.JPFBenchmark.benchmark05(-1.4393549333374578,-1.5707963267948966,20.624143829876914 ) ;
  }

  @Test
  public void test3002() {
    coral.tests.JPFBenchmark.benchmark05(-1.4394836150874037,-1.5707963267948966,83.25220532012952 ) ;
  }

  @Test
  public void test3003() {
    coral.tests.JPFBenchmark.benchmark05(-1.4398371083173025,-0.4125272038575837,-13.884873313406729 ) ;
  }

  @Test
  public void test3004() {
    coral.tests.JPFBenchmark.benchmark05(-1.4402437551103175,-0.0011798121595387877,32.974859475735876 ) ;
  }

  @Test
  public void test3005() {
    coral.tests.JPFBenchmark.benchmark05(-1.44084794367325,-1.5707963267948966,-9.772603932728288 ) ;
  }

  @Test
  public void test3006() {
    coral.tests.JPFBenchmark.benchmark05(-1.4409429307273702,-0.020583994623374926,-70.48257139221823 ) ;
  }

  @Test
  public void test3007() {
    coral.tests.JPFBenchmark.benchmark05(-1.4410598714953613,-0.9103164768535723,581.1927216047931 ) ;
  }

  @Test
  public void test3008() {
    coral.tests.JPFBenchmark.benchmark05(-1.4415217128292963,-0.05380364684398806,-44.235829371617925 ) ;
  }

  @Test
  public void test3009() {
    coral.tests.JPFBenchmark.benchmark05(-1.441782264627328,-1.1040202554740608,1.5707963267948968 ) ;
  }

  @Test
  public void test3010() {
    coral.tests.JPFBenchmark.benchmark05(-1.4420738790502172,-3.1415926536113425,-39.00481852805895 ) ;
  }

  @Test
  public void test3011() {
    coral.tests.JPFBenchmark.benchmark05(14.429204220265575,-0.006176640939057634,0.5998712421039114 ) ;
  }

  @Test
  public void test3012() {
    coral.tests.JPFBenchmark.benchmark05(14.429204548147233,-0.23177386052864568,-81.95235209504702 ) ;
  }

  @Test
  public void test3013() {
    coral.tests.JPFBenchmark.benchmark05(14.429207295258202,-0.21879341683841128,7.868617493247584 ) ;
  }

  @Test
  public void test3014() {
    coral.tests.JPFBenchmark.benchmark05(14.429209064568951,-41.69963190997297,-84.97477851396383 ) ;
  }

  @Test
  public void test3015() {
    coral.tests.JPFBenchmark.benchmark05(14.429219430445265,-1.162136817666686,-1.5533800831919122 ) ;
  }

  @Test
  public void test3016() {
    coral.tests.JPFBenchmark.benchmark05(14.429226344714046,-1.5707963267948966,68.38138579529104 ) ;
  }

  @Test
  public void test3017() {
    coral.tests.JPFBenchmark.benchmark05(14.429253898722898,-1.5707963267948966,-1.5707963267948948 ) ;
  }

  @Test
  public void test3018() {
    coral.tests.JPFBenchmark.benchmark05(14.429256658056559,-41.03216174755204,6.940235999014596 ) ;
  }

  @Test
  public void test3019() {
    coral.tests.JPFBenchmark.benchmark05(14.429262236187363,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3020() {
    coral.tests.JPFBenchmark.benchmark05(14.429301218156986,-41.89363325715321,64.91823808543117 ) ;
  }

  @Test
  public void test3021() {
    coral.tests.JPFBenchmark.benchmark05(14.42931285913668,-1.5707963180070632,82.70180658586621 ) ;
  }

  @Test
  public void test3022() {
    coral.tests.JPFBenchmark.benchmark05(14.429325508120002,-1.0339757656912846E-25,198.77934958469655 ) ;
  }

  @Test
  public void test3023() {
    coral.tests.JPFBenchmark.benchmark05(14.429360187787175,-3.1435475107366684,10.281148590478464 ) ;
  }

  @Test
  public void test3024() {
    coral.tests.JPFBenchmark.benchmark05(14.429365642393336,-1.3819679306611496,-96.93519600953684 ) ;
  }

  @Test
  public void test3025() {
    coral.tests.JPFBenchmark.benchmark05(14.429389918770894,-3.9364437439832445,-0.03454271174925294 ) ;
  }

  @Test
  public void test3026() {
    coral.tests.JPFBenchmark.benchmark05(14.429394574479275,-22.444135169718887,100.0 ) ;
  }

  @Test
  public void test3027() {
    coral.tests.JPFBenchmark.benchmark05(14.42940450472085,-0.1481730349602571,-55.36390114575647 ) ;
  }

  @Test
  public void test3028() {
    coral.tests.JPFBenchmark.benchmark05(14.429419531548866,-8.673617379884035E-19,83.39263235174016 ) ;
  }

  @Test
  public void test3029() {
    coral.tests.JPFBenchmark.benchmark05(14.429421292333473,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test3030() {
    coral.tests.JPFBenchmark.benchmark05(14.429423794463808,-41.03377562110455,-86.18549535517201 ) ;
  }

  @Test
  public void test3031() {
    coral.tests.JPFBenchmark.benchmark05(14.429473781733662,-1.2024092464047376,-90.8781622209365 ) ;
  }

  @Test
  public void test3032() {
    coral.tests.JPFBenchmark.benchmark05(14.429509754744771,1.0842021724855044E-19,-63.07857174377161 ) ;
  }

  @Test
  public void test3033() {
    coral.tests.JPFBenchmark.benchmark05(14.429521782568337,-0.26224770435430195,44.242731441249646 ) ;
  }

  @Test
  public void test3034() {
    coral.tests.JPFBenchmark.benchmark05(14.4296076063888,-3.1415936262317956,-84.29243074154212 ) ;
  }

  @Test
  public void test3035() {
    coral.tests.JPFBenchmark.benchmark05(14.429772848728547,-1.5707963267948963,100.0 ) ;
  }

  @Test
  public void test3036() {
    coral.tests.JPFBenchmark.benchmark05(14.42992617476029,-0.032552969470037996,-55.13798614714038 ) ;
  }

  @Test
  public void test3037() {
    coral.tests.JPFBenchmark.benchmark05(14.43000993972614,-1.5707963267948966,4.186637303030221 ) ;
  }

  @Test
  public void test3038() {
    coral.tests.JPFBenchmark.benchmark05(14.43024804348559,-1.5707963267948957,38.877749818552374 ) ;
  }

  @Test
  public void test3039() {
    coral.tests.JPFBenchmark.benchmark05(14.430513650184828,-1.5707963267948966,-1.5707963267948992 ) ;
  }

  @Test
  public void test3040() {
    coral.tests.JPFBenchmark.benchmark05(14.430684052960885,-0.4820325074750743,-76.45097248203308 ) ;
  }

  @Test
  public void test3041() {
    coral.tests.JPFBenchmark.benchmark05(14.431091664203699,-129.24626798746556,-170.1196133297096 ) ;
  }

  @Test
  public void test3042() {
    coral.tests.JPFBenchmark.benchmark05(14.431458303012313,0.3425103381524738,69.92521192245502 ) ;
  }

  @Test
  public void test3043() {
    coral.tests.JPFBenchmark.benchmark05(14.43210974079436,-1.3925294647594463E-6,-175.397505419349 ) ;
  }

  @Test
  public void test3044() {
    coral.tests.JPFBenchmark.benchmark05(-1.4433120270535134,-3.6093979923087858,-1.5707963267948966 ) ;
  }

  @Test
  public void test3045() {
    coral.tests.JPFBenchmark.benchmark05(14.433178246227769,-1.2088195417852525,78.77145350117888 ) ;
  }

  @Test
  public void test3046() {
    coral.tests.JPFBenchmark.benchmark05(-1.4433572747072487,-9.50160557974944,-76.45948569458015 ) ;
  }

  @Test
  public void test3047() {
    coral.tests.JPFBenchmark.benchmark05(14.433906372693862,-6.394115671312808E-31,0.0 ) ;
  }

  @Test
  public void test3048() {
    coral.tests.JPFBenchmark.benchmark05(14.434021088803718,-1.539692184352699,12.5683402657058 ) ;
  }

  @Test
  public void test3049() {
    coral.tests.JPFBenchmark.benchmark05(14.434940596665847,-78.79696979968558,0.0 ) ;
  }

  @Test
  public void test3050() {
    coral.tests.JPFBenchmark.benchmark05(14.435198478204157,-3.469446951953614E-18,-59.38892251545097 ) ;
  }

  @Test
  public void test3051() {
    coral.tests.JPFBenchmark.benchmark05(14.43541649159748,-1.1072691218704767,42.805925048333336 ) ;
  }

  @Test
  public void test3052() {
    coral.tests.JPFBenchmark.benchmark05(-1.4436546989963333,-84.99914421212576,20.390891391475208 ) ;
  }

  @Test
  public void test3053() {
    coral.tests.JPFBenchmark.benchmark05(14.436866885211806,-60.70643831724231,0.3867269827010545 ) ;
  }

  @Test
  public void test3054() {
    coral.tests.JPFBenchmark.benchmark05(-1.4438854826998462,-0.14693352431706963,-3.1736449217262623 ) ;
  }

  @Test
  public void test3055() {
    coral.tests.JPFBenchmark.benchmark05(14.440078802346079,-1.4956828969051155,83.36778914781976 ) ;
  }

  @Test
  public void test3056() {
    coral.tests.JPFBenchmark.benchmark05(14.443084686841999,-0.33891503887358515,28.767075693672638 ) ;
  }

  @Test
  public void test3057() {
    coral.tests.JPFBenchmark.benchmark05(-1.4444107876060035,-167.14629808192717,1.9363309303444887E-8 ) ;
  }

  @Test
  public void test3058() {
    coral.tests.JPFBenchmark.benchmark05(14.447867202062525,-1.5707963267948966,-26.002855164239048 ) ;
  }

  @Test
  public void test3059() {
    coral.tests.JPFBenchmark.benchmark05(-1.4450735257325065,-0.1831992729546388,91.2365552364032 ) ;
  }

  @Test
  public void test3060() {
    coral.tests.JPFBenchmark.benchmark05(14.451619468216336,-1.5707963267948966,45.315324347768836 ) ;
  }

  @Test
  public void test3061() {
    coral.tests.JPFBenchmark.benchmark05(14.452467931340024,-1.5707963267948988,121.62140032233461 ) ;
  }

  @Test
  public void test3062() {
    coral.tests.JPFBenchmark.benchmark05(-1.4453935136205476,-1.5707963267948966,16.086632881523784 ) ;
  }

  @Test
  public void test3063() {
    coral.tests.JPFBenchmark.benchmark05(-1.4460735904574198,-0.04934226262622676,-25.48782485457913 ) ;
  }

  @Test
  public void test3064() {
    coral.tests.JPFBenchmark.benchmark05(-1.4463836675710553,-0.16010447950024997,1.5707963267948966 ) ;
  }

  @Test
  public void test3065() {
    coral.tests.JPFBenchmark.benchmark05(-1.446445153205838,-22.347553268515902,0.6881733929579451 ) ;
  }

  @Test
  public void test3066() {
    coral.tests.JPFBenchmark.benchmark05(14.468937110182416,-117.33593465178062,1.5707963267948983 ) ;
  }

  @Test
  public void test3067() {
    coral.tests.JPFBenchmark.benchmark05(-1.4469418268367653,-1.5707963265883527,0.0 ) ;
  }

  @Test
  public void test3068() {
    coral.tests.JPFBenchmark.benchmark05(14.473065883779547,-1.5707963267948966,9.058170259555072E-15 ) ;
  }

  @Test
  public void test3069() {
    coral.tests.JPFBenchmark.benchmark05(-1.44751798076322,-0.03759698560772082,-68.73904025354058 ) ;
  }

  @Test
  public void test3070() {
    coral.tests.JPFBenchmark.benchmark05(-1.4476978589397833,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3071() {
    coral.tests.JPFBenchmark.benchmark05(14.480477495957587,-1.3815702848345168,-1.5707963267948966 ) ;
  }

  @Test
  public void test3072() {
    coral.tests.JPFBenchmark.benchmark05(-1.448340978540525,-9.969635281429376,78.19474905608425 ) ;
  }

  @Test
  public void test3073() {
    coral.tests.JPFBenchmark.benchmark05(-1.4484578976535352,-1.5707963267948966,-76.98659202895092 ) ;
  }

  @Test
  public void test3074() {
    coral.tests.JPFBenchmark.benchmark05(-1.4487821557024319,-97.94161195700471,91.93354495653233 ) ;
  }

  @Test
  public void test3075() {
    coral.tests.JPFBenchmark.benchmark05(-1.448987170589561,-0.30524105779111776,-73.43219408924608 ) ;
  }

  @Test
  public void test3076() {
    coral.tests.JPFBenchmark.benchmark05(-1.4495598354737531,-48.18806224164558,-1.5707963267948966 ) ;
  }

  @Test
  public void test3077() {
    coral.tests.JPFBenchmark.benchmark05(-1.4500292767024092,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3078() {
    coral.tests.JPFBenchmark.benchmark05(-1.4500670491267442,-0.07162481146148172,27.740989420911006 ) ;
  }

  @Test
  public void test3079() {
    coral.tests.JPFBenchmark.benchmark05(-1.4516012469491475,-1.570796326794931,1.5707963267948983 ) ;
  }

  @Test
  public void test3080() {
    coral.tests.JPFBenchmark.benchmark05(-1.452142486394421,-1.5684601168446222,-0.025448976844476848 ) ;
  }

  @Test
  public void test3081() {
    coral.tests.JPFBenchmark.benchmark05(-1.453619485503471,-10.360602602924459,-73.1162197017056 ) ;
  }

  @Test
  public void test3082() {
    coral.tests.JPFBenchmark.benchmark05(-1.4550033982805652,-66.43807621965226,-0.05021357763873945 ) ;
  }

  @Test
  public void test3083() {
    coral.tests.JPFBenchmark.benchmark05(-1.456145241224383,-676.154132604495,41.08624729894029 ) ;
  }

  @Test
  public void test3084() {
    coral.tests.JPFBenchmark.benchmark05(-1.456487890192848,-66.25091343505468,1.5707963268048346 ) ;
  }

  @Test
  public void test3085() {
    coral.tests.JPFBenchmark.benchmark05(-1.4565711588446648,-1.5707963267948966,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test3086() {
    coral.tests.JPFBenchmark.benchmark05(-1.4573363641143455,-1.5707963267948948,-12.772057723026691 ) ;
  }

  @Test
  public void test3087() {
    coral.tests.JPFBenchmark.benchmark05(-1.4575946384679133,-1.5707963267948957,-25.571887528596413 ) ;
  }

  @Test
  public void test3088() {
    coral.tests.JPFBenchmark.benchmark05(-1.4578139550050344,-0.2342404917702594,98.06590337245433 ) ;
  }

  @Test
  public void test3089() {
    coral.tests.JPFBenchmark.benchmark05(-1.4578658783170084,-41.63845026456623,-1.5707963267948961 ) ;
  }

  @Test
  public void test3090() {
    coral.tests.JPFBenchmark.benchmark05(-1.458116673778611,-1.5707963267948966,-16.806253670949175 ) ;
  }

  @Test
  public void test3091() {
    coral.tests.JPFBenchmark.benchmark05(14.584666862892988,-1.5707963267948966,-73.2247767033151 ) ;
  }

  @Test
  public void test3092() {
    coral.tests.JPFBenchmark.benchmark05(-1.459099563475725,-0.07129415319274962,-1.5707963267948966 ) ;
  }

  @Test
  public void test3093() {
    coral.tests.JPFBenchmark.benchmark05(-1.459333177671163,-53.615878209721316,56.367140222689756 ) ;
  }

  @Test
  public void test3094() {
    coral.tests.JPFBenchmark.benchmark05(-1.4594950044951733,-3.5282277482278914,32.03051128934234 ) ;
  }

  @Test
  public void test3095() {
    coral.tests.JPFBenchmark.benchmark05(-1.459602895875037,-66.2968975470697,3.1496060523510603 ) ;
  }

  @Test
  public void test3096() {
    coral.tests.JPFBenchmark.benchmark05(-1.4596990190633476,-0.029716500460727983,-29.16165873150696 ) ;
  }

  @Test
  public void test3097() {
    coral.tests.JPFBenchmark.benchmark05(-1.4597693844094783,-1.5707963267948966,-18.601163385761456 ) ;
  }

  @Test
  public void test3098() {
    coral.tests.JPFBenchmark.benchmark05(-1.460214077280739,-1.5707963267948966,-72.33570467450295 ) ;
  }

  @Test
  public void test3099() {
    coral.tests.JPFBenchmark.benchmark05(-1.4606574709596132,3.4135365466463443,-1.5742196547296905 ) ;
  }

  @Test
  public void test3100() {
    coral.tests.JPFBenchmark.benchmark05(-1.4610553784192104,-15.9189621384699,63.232619785864316 ) ;
  }

  @Test
  public void test3101() {
    coral.tests.JPFBenchmark.benchmark05(-1.4614320891974568,-1.0555582329822402,-61.5311590345635 ) ;
  }

  @Test
  public void test3102() {
    coral.tests.JPFBenchmark.benchmark05(-1.4616375645573465,-9.513193817278248,27.34365162477122 ) ;
  }

  @Test
  public void test3103() {
    coral.tests.JPFBenchmark.benchmark05(-1.4630457425767327,-66.06062590928533,-32.90920457068679 ) ;
  }

  @Test
  public void test3104() {
    coral.tests.JPFBenchmark.benchmark05(-1.46334822092742,-1.5707963267948966,60.4280183416175 ) ;
  }

  @Test
  public void test3105() {
    coral.tests.JPFBenchmark.benchmark05(-1.4637154568395498,-10.105333239468523,19.460144715394225 ) ;
  }

  @Test
  public void test3106() {
    coral.tests.JPFBenchmark.benchmark05(-1.4642830091568695,-41.68436090349341,-613.0172291318001 ) ;
  }

  @Test
  public void test3107() {
    coral.tests.JPFBenchmark.benchmark05(-1.4643621702778158,-1.5707963267948966,48.44585693720027 ) ;
  }

  @Test
  public void test3108() {
    coral.tests.JPFBenchmark.benchmark05(-1.4646317165619105,-0.8507485084885179,62.71735330953695 ) ;
  }

  @Test
  public void test3109() {
    coral.tests.JPFBenchmark.benchmark05(-1.4651066287861298,-1.5707963267948966,78.56547439533179 ) ;
  }

  @Test
  public void test3110() {
    coral.tests.JPFBenchmark.benchmark05(-1.4653230507873407,-1.5707963267948966,88.27970809564889 ) ;
  }

  @Test
  public void test3111() {
    coral.tests.JPFBenchmark.benchmark05(-1.4654488660002427,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3112() {
    coral.tests.JPFBenchmark.benchmark05(-1.4655516422383998,-1.7763568394002505E-15,14.138234564554736 ) ;
  }

  @Test
  public void test3113() {
    coral.tests.JPFBenchmark.benchmark05(-1.465587542731631,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3114() {
    coral.tests.JPFBenchmark.benchmark05(-1.4657181472695042,-47.30531933031277,-66.7955336283952 ) ;
  }

  @Test
  public void test3115() {
    coral.tests.JPFBenchmark.benchmark05(-1.4659401653254882,-1.5707963267948966,20.460353273419898 ) ;
  }

  @Test
  public void test3116() {
    coral.tests.JPFBenchmark.benchmark05(-1.4667081347560909,-0.005793438160955333,59.495825523394615 ) ;
  }

  @Test
  public void test3117() {
    coral.tests.JPFBenchmark.benchmark05(-1.466745517178248,-1.5707963267948966,-1.570796326794897 ) ;
  }

  @Test
  public void test3118() {
    coral.tests.JPFBenchmark.benchmark05(-1.4669608345559253,-1.5707963267948961,-20.533740647273135 ) ;
  }

  @Test
  public void test3119() {
    coral.tests.JPFBenchmark.benchmark05(-1.4673735716535485,-9.539770783464288,1.5707963267948966 ) ;
  }

  @Test
  public void test3120() {
    coral.tests.JPFBenchmark.benchmark05(-1.4673789738539853,-10.225654042601334,1.5707963267948983 ) ;
  }

  @Test
  public void test3121() {
    coral.tests.JPFBenchmark.benchmark05(-1.4676199903979292,-1.5707963267948966,-22.218478700283924 ) ;
  }

  @Test
  public void test3122() {
    coral.tests.JPFBenchmark.benchmark05(-1.4685331318012635,4.1415926536395755,-75.3946725199518 ) ;
  }

  @Test
  public void test3123() {
    coral.tests.JPFBenchmark.benchmark05(-1.4688005721511246,-0.5350845193263054,55.38578295846579 ) ;
  }

  @Test
  public void test3124() {
    coral.tests.JPFBenchmark.benchmark05(-1.4690768615539205,-98.03253603350512,-100.0 ) ;
  }

  @Test
  public void test3125() {
    coral.tests.JPFBenchmark.benchmark05(-1.4691882031931311,-35.114838175371744,18.974141186291817 ) ;
  }

  @Test
  public void test3126() {
    coral.tests.JPFBenchmark.benchmark05(-1.4693857511831396,-1.5707963267948983,-58.45859479724608 ) ;
  }

  @Test
  public void test3127() {
    coral.tests.JPFBenchmark.benchmark05(-1.4698993676405643,-1.5707963267948817,50.20466081173579 ) ;
  }

  @Test
  public void test3128() {
    coral.tests.JPFBenchmark.benchmark05(-1.4705569770637859,-1.5707963267948966,8.853981633974481 ) ;
  }

  @Test
  public void test3129() {
    coral.tests.JPFBenchmark.benchmark05(-1.470563189808262,-54.79433579589402,-25.19564398150405 ) ;
  }

  @Test
  public void test3130() {
    coral.tests.JPFBenchmark.benchmark05(-1.470840145964753,-1.5707963267948983,78.31907175578624 ) ;
  }

  @Test
  public void test3131() {
    coral.tests.JPFBenchmark.benchmark05(-1.4708491622971864,-66.07043827048699,67.47833211719951 ) ;
  }

  @Test
  public void test3132() {
    coral.tests.JPFBenchmark.benchmark05(-1.4709809436118206,-78.59059419245109,0.0 ) ;
  }

  @Test
  public void test3133() {
    coral.tests.JPFBenchmark.benchmark05(-1.4720425041836098,-0.47746499233838624,12.338338601147651 ) ;
  }

  @Test
  public void test3134() {
    coral.tests.JPFBenchmark.benchmark05(14.723016084961735,-1.5707963267948966,8.7535426540733 ) ;
  }

  @Test
  public void test3135() {
    coral.tests.JPFBenchmark.benchmark05(-1.472463025536713,-1.5707963267948966,19.85559322249304 ) ;
  }

  @Test
  public void test3136() {
    coral.tests.JPFBenchmark.benchmark05(-1.4726416468035939,-0.881949954636068,1.5707963267948966 ) ;
  }

  @Test
  public void test3137() {
    coral.tests.JPFBenchmark.benchmark05(-1.4727588179547182,-1.5707963267948966,-4.712393420756729 ) ;
  }

  @Test
  public void test3138() {
    coral.tests.JPFBenchmark.benchmark05(-1.473058242815215,-1.5707963267948912,-34.462463644866155 ) ;
  }

  @Test
  public void test3139() {
    coral.tests.JPFBenchmark.benchmark05(-1.4731175154424473E-6,-3.157053216938222E-5,-26.94852270824032 ) ;
  }

  @Test
  public void test3140() {
    coral.tests.JPFBenchmark.benchmark05(-1.4731462934024275,-66.79490198306016,43.74799369478171 ) ;
  }

  @Test
  public void test3141() {
    coral.tests.JPFBenchmark.benchmark05(-1.4732332481420156,-42.41021880569575,-56.55392373111435 ) ;
  }

  @Test
  public void test3142() {
    coral.tests.JPFBenchmark.benchmark05(-1.4734173702254347,-0.03664115918174072,-6.533290886351888 ) ;
  }

  @Test
  public void test3143() {
    coral.tests.JPFBenchmark.benchmark05(-1.4737340272172477,-983.9507642348855,-10.916219380512132 ) ;
  }

  @Test
  public void test3144() {
    coral.tests.JPFBenchmark.benchmark05(-1.4738462418460958,-1.5707963267948966,-181.9493964892913 ) ;
  }

  @Test
  public void test3145() {
    coral.tests.JPFBenchmark.benchmark05(-1.473887550204386E-14,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test3146() {
    coral.tests.JPFBenchmark.benchmark05(-1.4743654112542066,-1.5707963267948966,62.473738220352324 ) ;
  }

  @Test
  public void test3147() {
    coral.tests.JPFBenchmark.benchmark05(-1.4753526695743726,-48.39777584264081,-0.557857768865702 ) ;
  }

  @Test
  public void test3148() {
    coral.tests.JPFBenchmark.benchmark05(-1.4757963168869055,-0.33436368182527,1149.0975142536886 ) ;
  }

  @Test
  public void test3149() {
    coral.tests.JPFBenchmark.benchmark05(-1.4762779929013572,-78.59156324793643,14.557223398508341 ) ;
  }

  @Test
  public void test3150() {
    coral.tests.JPFBenchmark.benchmark05(-1.4775299026910986,-0.1038068430353887,11.059666658704685 ) ;
  }

  @Test
  public void test3151() {
    coral.tests.JPFBenchmark.benchmark05(-1.4776401195190028,-0.11803801938685865,-44.99119496031494 ) ;
  }

  @Test
  public void test3152() {
    coral.tests.JPFBenchmark.benchmark05(-1.4780741000364752,-0.5731123483750054,69.2727386928208 ) ;
  }

  @Test
  public void test3153() {
    coral.tests.JPFBenchmark.benchmark05(-1.4787545112893419,-1.5707963267948966,-3.1458189878526337 ) ;
  }

  @Test
  public void test3154() {
    coral.tests.JPFBenchmark.benchmark05(-1.479203745350116,-1.5707963267948966,-33.355735249469575 ) ;
  }

  @Test
  public void test3155() {
    coral.tests.JPFBenchmark.benchmark05(-1.479767059568971,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3156() {
    coral.tests.JPFBenchmark.benchmark05(-1.4805252711855843,-66.52712197890598,6.292526534571654 ) ;
  }

  @Test
  public void test3157() {
    coral.tests.JPFBenchmark.benchmark05(-1.4814888308153904,-117.69858905242535,4.676504867280315 ) ;
  }

  @Test
  public void test3158() {
    coral.tests.JPFBenchmark.benchmark05(-1.482075156342641,-97.65176989493138,0.0 ) ;
  }

  @Test
  public void test3159() {
    coral.tests.JPFBenchmark.benchmark05(-1.4831795055288124,4.141592710196164,-48.26623670967523 ) ;
  }

  @Test
  public void test3160() {
    coral.tests.JPFBenchmark.benchmark05(-1.4834497757240603,-66.74722105653137,-39.54271233882687 ) ;
  }

  @Test
  public void test3161() {
    coral.tests.JPFBenchmark.benchmark05(-1.4835166801730217,-9.523117804887463,-39.10043187158218 ) ;
  }

  @Test
  public void test3162() {
    coral.tests.JPFBenchmark.benchmark05(-1.484401747756416,-1.5707963267948966,-64.19829501010202 ) ;
  }

  @Test
  public void test3163() {
    coral.tests.JPFBenchmark.benchmark05(-1.484660036498946,-48.2258672340452,0.0 ) ;
  }

  @Test
  public void test3164() {
    coral.tests.JPFBenchmark.benchmark05(-1.4850601086334851,-9.5352165229362,7.430461913753096 ) ;
  }

  @Test
  public void test3165() {
    coral.tests.JPFBenchmark.benchmark05(-1.485272602253744,-1.5707963267948948,-35.55748956637915 ) ;
  }

  @Test
  public void test3166() {
    coral.tests.JPFBenchmark.benchmark05(-1.4860024385447312,-3.5976548436629034,-6.31998144861534 ) ;
  }

  @Test
  public void test3167() {
    coral.tests.JPFBenchmark.benchmark05(-1.4865066411073418,4.141592655663363,4.7126700891685385 ) ;
  }

  @Test
  public void test3168() {
    coral.tests.JPFBenchmark.benchmark05(-1.4867578234186576,-35.79717381960354,91.10618695325984 ) ;
  }

  @Test
  public void test3169() {
    coral.tests.JPFBenchmark.benchmark05(-1.48772395571892,-98.41696677135863,105.06807028982757 ) ;
  }

  @Test
  public void test3170() {
    coral.tests.JPFBenchmark.benchmark05(-1.4880478897533742,-7.105427357601002E-15,-4.712768286548153 ) ;
  }

  @Test
  public void test3171() {
    coral.tests.JPFBenchmark.benchmark05(-1.488568915542654,-3.141592668490955,1.5707963267948966 ) ;
  }

  @Test
  public void test3172() {
    coral.tests.JPFBenchmark.benchmark05(-1.488862618326704,-42.06233312378773,14.843673366310696 ) ;
  }

  @Test
  public void test3173() {
    coral.tests.JPFBenchmark.benchmark05(-1.4894477732354947,-1.5707963267948966,-43.31346276536697 ) ;
  }

  @Test
  public void test3174() {
    coral.tests.JPFBenchmark.benchmark05(-1.490688358380136,-60.957495310758844,20.60671456107213 ) ;
  }

  @Test
  public void test3175() {
    coral.tests.JPFBenchmark.benchmark05(-1.4910575861387778,-10.375657084982365,-0.16679904629592573 ) ;
  }

  @Test
  public void test3176() {
    coral.tests.JPFBenchmark.benchmark05(-1.4911171896219741,-1.5707963267948966,-8.187795596628948 ) ;
  }

  @Test
  public void test3177() {
    coral.tests.JPFBenchmark.benchmark05(-1.491939710714135,-28.36700442146494,130.05459894522753 ) ;
  }

  @Test
  public void test3178() {
    coral.tests.JPFBenchmark.benchmark05(-1.4921449072408617,-53.48358355920626,1.5707963267948966 ) ;
  }

  @Test
  public void test3179() {
    coral.tests.JPFBenchmark.benchmark05(-1.49267226266794,-54.52077866558092,0.0 ) ;
  }

  @Test
  public void test3180() {
    coral.tests.JPFBenchmark.benchmark05(14.932332866709665,-53.47679543752144,-210.42730468481668 ) ;
  }

  @Test
  public void test3181() {
    coral.tests.JPFBenchmark.benchmark05(-1.4933985714931797,-0.9052948474351722,90.88261090010968 ) ;
  }

  @Test
  public void test3182() {
    coral.tests.JPFBenchmark.benchmark05(-1.4941193637389238,-1.5707963267948966,7.488307900473141 ) ;
  }

  @Test
  public void test3183() {
    coral.tests.JPFBenchmark.benchmark05(-1.4942423685817414,-1.5707963267948966,1.570796326649967 ) ;
  }

  @Test
  public void test3184() {
    coral.tests.JPFBenchmark.benchmark05(-1.4944701192936085,-9.494962962299367,-93.93548139759342 ) ;
  }

  @Test
  public void test3185() {
    coral.tests.JPFBenchmark.benchmark05(-1.4946725937915435,-9.489651859542624,-36.29863461052013 ) ;
  }

  @Test
  public void test3186() {
    coral.tests.JPFBenchmark.benchmark05(-1.4950513249509114,-500.1133736498268,113.96165422247779 ) ;
  }

  @Test
  public void test3187() {
    coral.tests.JPFBenchmark.benchmark05(-1.4959454719272138,-0.287148423763329,-597.598980224431 ) ;
  }

  @Test
  public void test3188() {
    coral.tests.JPFBenchmark.benchmark05(-1.4972974458900206,-36.08074840155039,-30.36365342853796 ) ;
  }

  @Test
  public void test3189() {
    coral.tests.JPFBenchmark.benchmark05(-1.4976511027706327,-48.462743452736206,1.5707963267948966 ) ;
  }

  @Test
  public void test3190() {
    coral.tests.JPFBenchmark.benchmark05(-1.4981364335015035E-95,-1.5707963267948966,-75.46829531675117 ) ;
  }

  @Test
  public void test3191() {
    coral.tests.JPFBenchmark.benchmark05(-1.4990476305539973,-0.5625342441657258,54.97801679968477 ) ;
  }

  @Test
  public void test3192() {
    coral.tests.JPFBenchmark.benchmark05(-1.4991021730493614,-54.65293835881336,-63.530666748029255 ) ;
  }

  @Test
  public void test3193() {
    coral.tests.JPFBenchmark.benchmark05(-1.5000635765572077,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3194() {
    coral.tests.JPFBenchmark.benchmark05(-1.5007268744460038,-0.8358933407637608,-4.495471637555298 ) ;
  }

  @Test
  public void test3195() {
    coral.tests.JPFBenchmark.benchmark05(-1.5009494873994573,-1.5707963267948963,-47.09795381173802 ) ;
  }

  @Test
  public void test3196() {
    coral.tests.JPFBenchmark.benchmark05(-1.501884583291567,-3.1416002829844953,1.5707963267948966 ) ;
  }

  @Test
  public void test3197() {
    coral.tests.JPFBenchmark.benchmark05(-1.5021188274761614,-0.5556041446897184,78.0586633894496 ) ;
  }

  @Test
  public void test3198() {
    coral.tests.JPFBenchmark.benchmark05(-1.5021532347083353,-85.00039089877893,100.0 ) ;
  }

  @Test
  public void test3199() {
    coral.tests.JPFBenchmark.benchmark05(-1.5021558923337759,-1.5707963267948966,-42.97992904309901 ) ;
  }

  @Test
  public void test3200() {
    coral.tests.JPFBenchmark.benchmark05(-1.5022521043692698,-98.86083527797848,26.306109424796887 ) ;
  }

  @Test
  public void test3201() {
    coral.tests.JPFBenchmark.benchmark05(-1.5025251381671016,-0.22840956929451428,-1.5707963267948963 ) ;
  }

  @Test
  public void test3202() {
    coral.tests.JPFBenchmark.benchmark05(-1.502761987317036,14.4292073697235,-78.00535785509632 ) ;
  }

  @Test
  public void test3203() {
    coral.tests.JPFBenchmark.benchmark05(-1.5029501295179017,-9.500183595638715,1.5707963267948966 ) ;
  }

  @Test
  public void test3204() {
    coral.tests.JPFBenchmark.benchmark05(-1.5029598246445668,-1.1137525315310193,6.283185311705249 ) ;
  }

  @Test
  public void test3205() {
    coral.tests.JPFBenchmark.benchmark05(-1.5031257753927276,-66.35968055498233,-119.7492124995137 ) ;
  }

  @Test
  public void test3206() {
    coral.tests.JPFBenchmark.benchmark05(-1.5036241907339942,-36.036872350430514,60.68976360320495 ) ;
  }

  @Test
  public void test3207() {
    coral.tests.JPFBenchmark.benchmark05(-1.5040057094123496,-66.86289495366154,1.5707963267948966 ) ;
  }

  @Test
  public void test3208() {
    coral.tests.JPFBenchmark.benchmark05(-1.5046004291973105,-1.5707963267948966,50.31276238821496 ) ;
  }

  @Test
  public void test3209() {
    coral.tests.JPFBenchmark.benchmark05(-1.504632769052528E-36,-1.5707963267948966,-20.99114796449999 ) ;
  }

  @Test
  public void test3210() {
    coral.tests.JPFBenchmark.benchmark05(-1.5049828805548702,-1.2224135584669698,1.5707963267948966 ) ;
  }

  @Test
  public void test3211() {
    coral.tests.JPFBenchmark.benchmark05(-1.5053953578478452,-1.233777559005004,-17.094666837287477 ) ;
  }

  @Test
  public void test3212() {
    coral.tests.JPFBenchmark.benchmark05(-1.5054197532891898,-1.3628543736092735,-49.80175644470664 ) ;
  }

  @Test
  public void test3213() {
    coral.tests.JPFBenchmark.benchmark05(-1.5058424395763388,-0.46480606151958664,83.48345777524071 ) ;
  }

  @Test
  public void test3214() {
    coral.tests.JPFBenchmark.benchmark05(-1.5060645068905274,-1.5707963267948963,0.0 ) ;
  }

  @Test
  public void test3215() {
    coral.tests.JPFBenchmark.benchmark05(-1.5061650467106378,-1.5707963267948966,-45.42527685019293 ) ;
  }

  @Test
  public void test3216() {
    coral.tests.JPFBenchmark.benchmark05(-1.5064971351743057,-1.5707963267948966,0.14782153421568456 ) ;
  }

  @Test
  public void test3217() {
    coral.tests.JPFBenchmark.benchmark05(-1.5068632999691118,-29.943020592360426,0 ) ;
  }

  @Test
  public void test3218() {
    coral.tests.JPFBenchmark.benchmark05(-1.5069183050582224E-6,-42.22009784337891,-77.01739794466467 ) ;
  }

  @Test
  public void test3219() {
    coral.tests.JPFBenchmark.benchmark05(-1.507096983335214,-1.5707963267948957,-27.565009128541405 ) ;
  }

  @Test
  public void test3220() {
    coral.tests.JPFBenchmark.benchmark05(-1.5072454068058596,-9.498414953458017,-86.94272018749383 ) ;
  }

  @Test
  public void test3221() {
    coral.tests.JPFBenchmark.benchmark05(-1.5073988366617155,0.3084515524679706,26.457442547018942 ) ;
  }

  @Test
  public void test3222() {
    coral.tests.JPFBenchmark.benchmark05(-1.5077047235850873,-78.9874049023097,-29.177072358444065 ) ;
  }

  @Test
  public void test3223() {
    coral.tests.JPFBenchmark.benchmark05(-1.5080478845320855,-41.93293645136575,10.025490640470297 ) ;
  }

  @Test
  public void test3224() {
    coral.tests.JPFBenchmark.benchmark05(-1.508528813283295,-1.5707963267948966,78.20817165122614 ) ;
  }

  @Test
  public void test3225() {
    coral.tests.JPFBenchmark.benchmark05(-1.5090455121685142,-1.5707963267948966,-4.1044511118094675 ) ;
  }

  @Test
  public void test3226() {
    coral.tests.JPFBenchmark.benchmark05(-1.5092592190277956,-1.5707963267948966,23.9863872025576 ) ;
  }

  @Test
  public void test3227() {
    coral.tests.JPFBenchmark.benchmark05(-1.509281764382873,-84.828645354369,0.0 ) ;
  }

  @Test
  public void test3228() {
    coral.tests.JPFBenchmark.benchmark05(-1.509404640585744,-0.787487389300399,176.47279084204445 ) ;
  }

  @Test
  public void test3229() {
    coral.tests.JPFBenchmark.benchmark05(-1.5095451042058996,-1.5707963267948912,20.297837307924738 ) ;
  }

  @Test
  public void test3230() {
    coral.tests.JPFBenchmark.benchmark05(-1.5098385095820286,-0.08330771353057807,2.2877317042282073 ) ;
  }

  @Test
  public void test3231() {
    coral.tests.JPFBenchmark.benchmark05(-1.5099369782932242,-0.971972921699876,76.26928397513585 ) ;
  }

  @Test
  public void test3232() {
    coral.tests.JPFBenchmark.benchmark05(-1.5100617895765645,-1.4626042496904919,-3.1420831350862413 ) ;
  }

  @Test
  public void test3233() {
    coral.tests.JPFBenchmark.benchmark05(-1.5109468396199466,-98.44466106946517,118.7402331063744 ) ;
  }

  @Test
  public void test3234() {
    coral.tests.JPFBenchmark.benchmark05(-1.5113997391910265,-60.936568729281525,-64.12945892671718 ) ;
  }

  @Test
  public void test3235() {
    coral.tests.JPFBenchmark.benchmark05(-1.5118167993050713,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3236() {
    coral.tests.JPFBenchmark.benchmark05(-1.5119341647027595,-3.143545779058202,0.4624458556292657 ) ;
  }

  @Test
  public void test3237() {
    coral.tests.JPFBenchmark.benchmark05(-1.5121602549316184,-35.931601440739485,-60.70382577695779 ) ;
  }

  @Test
  public void test3238() {
    coral.tests.JPFBenchmark.benchmark05(-1.5121718352771893,-1.5707963267948961,3.3888315890257275 ) ;
  }

  @Test
  public void test3239() {
    coral.tests.JPFBenchmark.benchmark05(-1.5131550751137568,3.141594562237161,83.47660705392447 ) ;
  }

  @Test
  public void test3240() {
    coral.tests.JPFBenchmark.benchmark05(-1.5131577449332383,-0.8297658785666981,-795.329810339633 ) ;
  }

  @Test
  public void test3241() {
    coral.tests.JPFBenchmark.benchmark05(-1.5133817321716452,-1.5707963267949,-20.626170881221896 ) ;
  }

  @Test
  public void test3242() {
    coral.tests.JPFBenchmark.benchmark05(-1.5136673900549447,-1.5707963267948966,0.2065335559805661 ) ;
  }

  @Test
  public void test3243() {
    coral.tests.JPFBenchmark.benchmark05(-1.5137162403503948,-1.5707963267948966,63.283263575478266 ) ;
  }

  @Test
  public void test3244() {
    coral.tests.JPFBenchmark.benchmark05(-1.5141801728037732,-0.36138012139118786,-146.46911934592552 ) ;
  }

  @Test
  public void test3245() {
    coral.tests.JPFBenchmark.benchmark05(-1.514338215763384,-16.191787857049402,-85.9127170046938 ) ;
  }

  @Test
  public void test3246() {
    coral.tests.JPFBenchmark.benchmark05(-1.5145991740457934,-35.49156926124149,26.246501375675724 ) ;
  }

  @Test
  public void test3247() {
    coral.tests.JPFBenchmark.benchmark05(-1.51466902395579,-1.0867811829478535,3.1415926545955513 ) ;
  }

  @Test
  public void test3248() {
    coral.tests.JPFBenchmark.benchmark05(-1.5151242845583106,-54.41793498460836,0.0 ) ;
  }

  @Test
  public void test3249() {
    coral.tests.JPFBenchmark.benchmark05(-1.5156292731334633,-1.5707963267948903,18.379947083481667 ) ;
  }

  @Test
  public void test3250() {
    coral.tests.JPFBenchmark.benchmark05(-1.515639608624613,-42.382287053625035,-6.284169450416203 ) ;
  }

  @Test
  public void test3251() {
    coral.tests.JPFBenchmark.benchmark05(-1.5158232401711518,-0.39112000955292336,-1.5707963267948983 ) ;
  }

  @Test
  public void test3252() {
    coral.tests.JPFBenchmark.benchmark05(-1.5161847376830586,-0.2910671244287735,-97.18457970710345 ) ;
  }

  @Test
  public void test3253() {
    coral.tests.JPFBenchmark.benchmark05(-1.5165720149072635,-1.5707963267948954,-60.555581756700086 ) ;
  }

  @Test
  public void test3254() {
    coral.tests.JPFBenchmark.benchmark05(-1.5172862966177023,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3255() {
    coral.tests.JPFBenchmark.benchmark05(-1.517321709262541,-47.2291622832175,91.36813499257335 ) ;
  }

  @Test
  public void test3256() {
    coral.tests.JPFBenchmark.benchmark05(-1.519414283512633,-35.52483371242505,-3.1494051535898198 ) ;
  }

  @Test
  public void test3257() {
    coral.tests.JPFBenchmark.benchmark05(-1.5202765402027911,1.4678428793696552,-0.08683959434382492 ) ;
  }

  @Test
  public void test3258() {
    coral.tests.JPFBenchmark.benchmark05(-1.5203560622422998,-3.1415926536169643,-91.50177522013459 ) ;
  }

  @Test
  public void test3259() {
    coral.tests.JPFBenchmark.benchmark05(-1.5208732530361279E-210,-10.214104752119288,-1.3624371221632864E-213 ) ;
  }

  @Test
  public void test3260() {
    coral.tests.JPFBenchmark.benchmark05(-1.5208732530361279E-210,-1.5707963267948966,-99.94332981070305 ) ;
  }

  @Test
  public void test3261() {
    coral.tests.JPFBenchmark.benchmark05(-1.5208882549639156,-0.03341011413960815,-21.747934122209134 ) ;
  }

  @Test
  public void test3262() {
    coral.tests.JPFBenchmark.benchmark05(-1.5211013716410218,-72.50439544089306,-100.0 ) ;
  }

  @Test
  public void test3263() {
    coral.tests.JPFBenchmark.benchmark05(-1.5217694723972182,-1.5707963267948966,-25.630528387411516 ) ;
  }

  @Test
  public void test3264() {
    coral.tests.JPFBenchmark.benchmark05(-1.5219922872282707,-61.19764236773086,-1.5707972256429301 ) ;
  }

  @Test
  public void test3265() {
    coral.tests.JPFBenchmark.benchmark05(-1.522298417978265,-1.5707963267948966,3.141592655323577 ) ;
  }

  @Test
  public void test3266() {
    coral.tests.JPFBenchmark.benchmark05(-1.5227157196133585,-2.83276944882399E-16,50.14838818011247 ) ;
  }

  @Test
  public void test3267() {
    coral.tests.JPFBenchmark.benchmark05(-1.5227993588203153,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3268() {
    coral.tests.JPFBenchmark.benchmark05(-1.5236441905387095,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3269() {
    coral.tests.JPFBenchmark.benchmark05(-1.5239084195015948,-122.91631215028836,1.5707963267949445 ) ;
  }

  @Test
  public void test3270() {
    coral.tests.JPFBenchmark.benchmark05(-1.524537400064745,-7.105427365077254E-15,31.572388772433868 ) ;
  }

  @Test
  public void test3271() {
    coral.tests.JPFBenchmark.benchmark05(-1.5249289009541998,-1.3877787807814457E-17,-54.48420470323592 ) ;
  }

  @Test
  public void test3272() {
    coral.tests.JPFBenchmark.benchmark05(-1.5250280202791515,-41.773042799927794,51.73380688550159 ) ;
  }

  @Test
  public void test3273() {
    coral.tests.JPFBenchmark.benchmark05(-1.5252184111152998,-1.558855961587323,1.5707963267949054 ) ;
  }

  @Test
  public void test3274() {
    coral.tests.JPFBenchmark.benchmark05(-1.5255900448322819,-78.53981633974485,-18.554053348996668 ) ;
  }

  @Test
  public void test3275() {
    coral.tests.JPFBenchmark.benchmark05(-1.52561217912479,4.141592653589854,78.71191396210446 ) ;
  }

  @Test
  public void test3276() {
    coral.tests.JPFBenchmark.benchmark05(-1.525711360062745,-48.51321891331096,7.8539830259583185 ) ;
  }

  @Test
  public void test3277() {
    coral.tests.JPFBenchmark.benchmark05(-1.5257255625162078,-72.38899582429332,1.5707963267948966 ) ;
  }

  @Test
  public void test3278() {
    coral.tests.JPFBenchmark.benchmark05(-1.5259206532774112,-618.9648077548276,-139.17928497510624 ) ;
  }

  @Test
  public void test3279() {
    coral.tests.JPFBenchmark.benchmark05(-1.5260429960553201,-2.465190328815662E-32,6.284456385960942 ) ;
  }

  @Test
  public void test3280() {
    coral.tests.JPFBenchmark.benchmark05(-1.5261749478848041,-1.5707963267948966,52.08978964254055 ) ;
  }

  @Test
  public void test3281() {
    coral.tests.JPFBenchmark.benchmark05(-1.5263171374180047,-0.5159207755546853,-92.15020943888057 ) ;
  }

  @Test
  public void test3282() {
    coral.tests.JPFBenchmark.benchmark05(-1.5265150522938407,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3283() {
    coral.tests.JPFBenchmark.benchmark05(-1.5266036352009564,-104.29926335646914,20.90191943452022 ) ;
  }

  @Test
  public void test3284() {
    coral.tests.JPFBenchmark.benchmark05(-1.5266739510482512,-98.7896862182592,-42.73637930556727 ) ;
  }

  @Test
  public void test3285() {
    coral.tests.JPFBenchmark.benchmark05(-1.526693381146129,-35.607385140838346,-0.7622240399951704 ) ;
  }

  @Test
  public void test3286() {
    coral.tests.JPFBenchmark.benchmark05(-1.5269408137770555,-1.2338789709326767E-178,-1.5707963267948966 ) ;
  }

  @Test
  public void test3287() {
    coral.tests.JPFBenchmark.benchmark05(-1.5269454392734993,-24.36018777311051,111.68505841356122 ) ;
  }

  @Test
  public void test3288() {
    coral.tests.JPFBenchmark.benchmark05(-1.5275846011347696,-9.63989072303066,1.5707963267948966 ) ;
  }

  @Test
  public void test3289() {
    coral.tests.JPFBenchmark.benchmark05(-1.5277849098701466,4.141592972504635,-32.42158683783234 ) ;
  }

  @Test
  public void test3290() {
    coral.tests.JPFBenchmark.benchmark05(-1.5279858907650203,-3.1639721507417073,-65.56271393985062 ) ;
  }

  @Test
  public void test3291() {
    coral.tests.JPFBenchmark.benchmark05(-1.5291007334148012,-3.390494891209947,23.30161504874657 ) ;
  }

  @Test
  public void test3292() {
    coral.tests.JPFBenchmark.benchmark05(-1.5294195122111063,-0.7670146180753861,-92.7456315424866 ) ;
  }

  @Test
  public void test3293() {
    coral.tests.JPFBenchmark.benchmark05(-1.529545704696312,-61.35828211321506,-21.705604816852887 ) ;
  }

  @Test
  public void test3294() {
    coral.tests.JPFBenchmark.benchmark05(-1.5303160000202407,-0.004172141563384105,50.26564570774145 ) ;
  }

  @Test
  public void test3295() {
    coral.tests.JPFBenchmark.benchmark05(-1.5303283729426889,-3.1416003242742647,20.11256426266901 ) ;
  }

  @Test
  public void test3296() {
    coral.tests.JPFBenchmark.benchmark05(-1.5309052799857026,-1.5707963267948966,73.76617328490883 ) ;
  }

  @Test
  public void test3297() {
    coral.tests.JPFBenchmark.benchmark05(-1.531183868280894,-1.5707963267948966,85.09810327859046 ) ;
  }

  @Test
  public void test3298() {
    coral.tests.JPFBenchmark.benchmark05(-1.5315231591801508,-66.43462669590954,-7.014448077266874 ) ;
  }

  @Test
  public void test3299() {
    coral.tests.JPFBenchmark.benchmark05(-1.5315368039822663,-4.010498668523013,64.779305727842 ) ;
  }

  @Test
  public void test3300() {
    coral.tests.JPFBenchmark.benchmark05(-1.5317099882565444,-1.5193334729975536,-1143.5362685053026 ) ;
  }

  @Test
  public void test3301() {
    coral.tests.JPFBenchmark.benchmark05(-1.532152645112517,-3.1712037476651984,1.5707963267948966 ) ;
  }

  @Test
  public void test3302() {
    coral.tests.JPFBenchmark.benchmark05(-1.5323491735289674,-1.5707963267948966,12.691370660355092 ) ;
  }

  @Test
  public void test3303() {
    coral.tests.JPFBenchmark.benchmark05(-1.5326174816637002,-1.5707963267948966,-82.45908982222583 ) ;
  }

  @Test
  public void test3304() {
    coral.tests.JPFBenchmark.benchmark05(-1.5334753951814282,3.142098485907703,144.54881494054376 ) ;
  }

  @Test
  public void test3305() {
    coral.tests.JPFBenchmark.benchmark05(15.33686800296907,-47.31177207327335,-82.50369848885643 ) ;
  }

  @Test
  public void test3306() {
    coral.tests.JPFBenchmark.benchmark05(-1.5339743452698866,-1.5707963267948966,5.293955920339377E-23 ) ;
  }

  @Test
  public void test3307() {
    coral.tests.JPFBenchmark.benchmark05(-1.5342127035753967,-48.374341739980494,1507.4195104742041 ) ;
  }

  @Test
  public void test3308() {
    coral.tests.JPFBenchmark.benchmark05(-1.5346270724271507,-1.5707963267948983,-55.25262500183441 ) ;
  }

  @Test
  public void test3309() {
    coral.tests.JPFBenchmark.benchmark05(-1.534781986638378,-1.5707963267948966,28.02784904686907 ) ;
  }

  @Test
  public void test3310() {
    coral.tests.JPFBenchmark.benchmark05(-1.5353464726467405,-3.2671184875813952,50.01772138299675 ) ;
  }

  @Test
  public void test3311() {
    coral.tests.JPFBenchmark.benchmark05(-1.535525011774955,-1.5707963267948966,-56.54866824145365 ) ;
  }

  @Test
  public void test3312() {
    coral.tests.JPFBenchmark.benchmark05(-1.5356033834831877,-78.68339721061692,-4.712393320411304 ) ;
  }

  @Test
  public void test3313() {
    coral.tests.JPFBenchmark.benchmark05(-1.5356895374291261E-238,-1.5707963267948966,-55.483679189991726 ) ;
  }

  @Test
  public void test3314() {
    coral.tests.JPFBenchmark.benchmark05(-1.5363477044761833,-47.54402231192012,-29.026691698271556 ) ;
  }

  @Test
  public void test3315() {
    coral.tests.JPFBenchmark.benchmark05(-1.5363546473136775,-0.2199492177800932,-237.47887043679438 ) ;
  }

  @Test
  public void test3316() {
    coral.tests.JPFBenchmark.benchmark05(-1.5368678830790534,-0.4838889600706483,-18.997183164878223 ) ;
  }

  @Test
  public void test3317() {
    coral.tests.JPFBenchmark.benchmark05(-1.536957256930113,-1.428350847830007,-32.627450041733596 ) ;
  }

  @Test
  public void test3318() {
    coral.tests.JPFBenchmark.benchmark05(-1.5370572100895594,-1.5707963267948974,0.9538380564829303 ) ;
  }

  @Test
  public void test3319() {
    coral.tests.JPFBenchmark.benchmark05(-1.5377301015158176,-72.50408376607844,47.535823362648586 ) ;
  }

  @Test
  public void test3320() {
    coral.tests.JPFBenchmark.benchmark05(-1.5377675659182484,-53.473969294997914,100.0 ) ;
  }

  @Test
  public void test3321() {
    coral.tests.JPFBenchmark.benchmark05(-1.5378102815797512,-1.5704831783625837,-0.3877558411974228 ) ;
  }

  @Test
  public void test3322() {
    coral.tests.JPFBenchmark.benchmark05(-1.5378896833418845,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3323() {
    coral.tests.JPFBenchmark.benchmark05(-1.538338151800298,-0.00975284177272262,-31.694061319880383 ) ;
  }

  @Test
  public void test3324() {
    coral.tests.JPFBenchmark.benchmark05(-1.5387038813907508,-66.9570285507425,0.0010212231775270585 ) ;
  }

  @Test
  public void test3325() {
    coral.tests.JPFBenchmark.benchmark05(-1.5394070203941976,8.470329472543003E-22,-31.027209327017886 ) ;
  }

  @Test
  public void test3326() {
    coral.tests.JPFBenchmark.benchmark05(-1.5401786893008418,-1.453105570825245,7.8539816422644355 ) ;
  }

  @Test
  public void test3327() {
    coral.tests.JPFBenchmark.benchmark05(-1.540420447294747,-1.5707963267948966,37.74422639649485 ) ;
  }

  @Test
  public void test3328() {
    coral.tests.JPFBenchmark.benchmark05(-1.5404393871230035,4.141592655800902,57.68852917983737 ) ;
  }

  @Test
  public void test3329() {
    coral.tests.JPFBenchmark.benchmark05(-1.54047823266307,-1.5707963267948948,3.6547334854269025 ) ;
  }

  @Test
  public void test3330() {
    coral.tests.JPFBenchmark.benchmark05(-1.5405197056651119,-48.680238577203625,151.06286309000942 ) ;
  }

  @Test
  public void test3331() {
    coral.tests.JPFBenchmark.benchmark05(-1.5405969630015799,-1.5707963267948863,19.4009627483901 ) ;
  }

  @Test
  public void test3332() {
    coral.tests.JPFBenchmark.benchmark05(-1.5412987462876493,2.710505431213761E-20,40.20431534029484 ) ;
  }

  @Test
  public void test3333() {
    coral.tests.JPFBenchmark.benchmark05(-1.541368908866331,-0.49148316832287264,7.526041886244911 ) ;
  }

  @Test
  public void test3334() {
    coral.tests.JPFBenchmark.benchmark05(-1.541725143692036,-0.7705221294980564,0.0 ) ;
  }

  @Test
  public void test3335() {
    coral.tests.JPFBenchmark.benchmark05(-1.5417314008963485,-0.007153268733251449,146.2012371362099 ) ;
  }

  @Test
  public void test3336() {
    coral.tests.JPFBenchmark.benchmark05(-1.5420290960788392,-91.11931245507071,38.926426359106955 ) ;
  }

  @Test
  public void test3337() {
    coral.tests.JPFBenchmark.benchmark05(-1.542414501213372,-2.220446049250313E-16,-1.5307180092413055 ) ;
  }

  @Test
  public void test3338() {
    coral.tests.JPFBenchmark.benchmark05(-1.5429501970496617,-1.5707963267948948,-18.011666216288397 ) ;
  }

  @Test
  public void test3339() {
    coral.tests.JPFBenchmark.benchmark05(-1.543274173468413,-0.184045587009214,45.43319490203457 ) ;
  }

  @Test
  public void test3340() {
    coral.tests.JPFBenchmark.benchmark05(-1.543442304999258,-4.1359030627651384E-25,-1.5707963267948966 ) ;
  }

  @Test
  public void test3341() {
    coral.tests.JPFBenchmark.benchmark05(-1.5437653111506844,-1.0343141914511662,37.835893362013266 ) ;
  }

  @Test
  public void test3342() {
    coral.tests.JPFBenchmark.benchmark05(-1.5440173640491466,-48.41364086702406,-1.5707963267948961 ) ;
  }

  @Test
  public void test3343() {
    coral.tests.JPFBenchmark.benchmark05(-1.5440320600305595,-98.48710543930244,-12.446558058509902 ) ;
  }

  @Test
  public void test3344() {
    coral.tests.JPFBenchmark.benchmark05(-1.5442866274460294,-0.4512727420770647,-1.570791266463531 ) ;
  }

  @Test
  public void test3345() {
    coral.tests.JPFBenchmark.benchmark05(-1.5443615015754706,-3.3979799698428534,6.283539046915136 ) ;
  }

  @Test
  public void test3346() {
    coral.tests.JPFBenchmark.benchmark05(-1.5447336124636406,-1.3234889800848443E-23,-89.95875459415217 ) ;
  }

  @Test
  public void test3347() {
    coral.tests.JPFBenchmark.benchmark05(-1.5453826259348311,-1.5707963267948966,-0.07706627087746204 ) ;
  }

  @Test
  public void test3348() {
    coral.tests.JPFBenchmark.benchmark05(-1.5454027171447196,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3349() {
    coral.tests.JPFBenchmark.benchmark05(-1.5455206998843989,-1.5707963267948966,77.22902379627865 ) ;
  }

  @Test
  public void test3350() {
    coral.tests.JPFBenchmark.benchmark05(-15.457576298405968,-79.82264264488225,47.10871620326563 ) ;
  }

  @Test
  public void test3351() {
    coral.tests.JPFBenchmark.benchmark05(-1.5458053599789703,-1.4053189966944482,1.5707963268883343 ) ;
  }

  @Test
  public void test3352() {
    coral.tests.JPFBenchmark.benchmark05(-1.546133927867132,-66.31395980864355,-6.805219095898153 ) ;
  }

  @Test
  public void test3353() {
    coral.tests.JPFBenchmark.benchmark05(-1.546302006657892,-1.5707963267948966,-4.71238898038469 ) ;
  }

  @Test
  public void test3354() {
    coral.tests.JPFBenchmark.benchmark05(-1.5463714772178239,-1.5707963267948966,-1.0806454419566534E-224 ) ;
  }

  @Test
  public void test3355() {
    coral.tests.JPFBenchmark.benchmark05(-1.547000296090472,-0.6930505383954505,-3.141592651966273 ) ;
  }

  @Test
  public void test3356() {
    coral.tests.JPFBenchmark.benchmark05(-1.5471291256748716,-135.60212673721372,-52.00603935834909 ) ;
  }

  @Test
  public void test3357() {
    coral.tests.JPFBenchmark.benchmark05(-1.5471478098962922E-16,-1.5707963267948966,33.53206908314769 ) ;
  }

  @Test
  public void test3358() {
    coral.tests.JPFBenchmark.benchmark05(-1.5471984329556552,-36.5478209637497,1.5707963267948966 ) ;
  }

  @Test
  public void test3359() {
    coral.tests.JPFBenchmark.benchmark05(-1.547262783153458,-66.4672281152472,-48.623066909667 ) ;
  }

  @Test
  public void test3360() {
    coral.tests.JPFBenchmark.benchmark05(-1.5474679283811779,-48.204731791309264,-1.5707963267948966 ) ;
  }

  @Test
  public void test3361() {
    coral.tests.JPFBenchmark.benchmark05(-1.5475789142019494,-1.5707963267948966,92.85519172887109 ) ;
  }

  @Test
  public void test3362() {
    coral.tests.JPFBenchmark.benchmark05(-1.5485456167870435,-3.1416023970013134,35.598904323110695 ) ;
  }

  @Test
  public void test3363() {
    coral.tests.JPFBenchmark.benchmark05(-1.5486762701921635,-3.141592654680531,57.57171170651904 ) ;
  }

  @Test
  public void test3364() {
    coral.tests.JPFBenchmark.benchmark05(-1.548862759486936,-1.5707963267948966,12.599540479994213 ) ;
  }

  @Test
  public void test3365() {
    coral.tests.JPFBenchmark.benchmark05(-1.5488725217783539,-1.5707963267948966,-18.964338858780664 ) ;
  }

  @Test
  public void test3366() {
    coral.tests.JPFBenchmark.benchmark05(-1.5490537281842442,-1.246267599215087,-55.45686905111646 ) ;
  }

  @Test
  public void test3367() {
    coral.tests.JPFBenchmark.benchmark05(-1.5494022860685501,4.141592752128455,-43.291148744687675 ) ;
  }

  @Test
  public void test3368() {
    coral.tests.JPFBenchmark.benchmark05(-15.494748520081657,-32.41746727837803,84.64241296103438 ) ;
  }

  @Test
  public void test3369() {
    coral.tests.JPFBenchmark.benchmark05(-1.5495701426312745,-3.1415926536065464,-22.069489098145773 ) ;
  }

  @Test
  public void test3370() {
    coral.tests.JPFBenchmark.benchmark05(-1.5504944739614448,-1.5707963267948983,20.789589479087542 ) ;
  }

  @Test
  public void test3371() {
    coral.tests.JPFBenchmark.benchmark05(-1.550496729225421,-1.5707963267948966,-5.141592668163645 ) ;
  }

  @Test
  public void test3372() {
    coral.tests.JPFBenchmark.benchmark05(-1.5512810142203002,-1.414794566904901,1.5707963267948963 ) ;
  }

  @Test
  public void test3373() {
    coral.tests.JPFBenchmark.benchmark05(-1.5514929623123386,-1.5707963267948966,-50.102172780828724 ) ;
  }

  @Test
  public void test3374() {
    coral.tests.JPFBenchmark.benchmark05(-1.5516558617485687,-1.5707963267948966,-76.52697676028059 ) ;
  }

  @Test
  public void test3375() {
    coral.tests.JPFBenchmark.benchmark05(-1.5516639669428787,-1.3877787807814457E-17,-96.74270614315839 ) ;
  }

  @Test
  public void test3376() {
    coral.tests.JPFBenchmark.benchmark05(-1.552089358888271,-1.3473966001567592,0.0 ) ;
  }

  @Test
  public void test3377() {
    coral.tests.JPFBenchmark.benchmark05(-1.5521224392434128,-1.5707963267948966,14.06174796852963 ) ;
  }

  @Test
  public void test3378() {
    coral.tests.JPFBenchmark.benchmark05(-1.5522180328915736,-1.106335950892611,42.55044029169474 ) ;
  }

  @Test
  public void test3379() {
    coral.tests.JPFBenchmark.benchmark05(-1.552370786176077,-160.40159079469797,1.5707963267948966 ) ;
  }

  @Test
  public void test3380() {
    coral.tests.JPFBenchmark.benchmark05(-1.552390662080258,-48.40441667241186,-1.5707963267948966 ) ;
  }

  @Test
  public void test3381() {
    coral.tests.JPFBenchmark.benchmark05(-1.5531002034906929,-0.5291773710622287,56.779191968181976 ) ;
  }

  @Test
  public void test3382() {
    coral.tests.JPFBenchmark.benchmark05(-1.5532988871901825,-1.5707963267948966,72.99966359804691 ) ;
  }

  @Test
  public void test3383() {
    coral.tests.JPFBenchmark.benchmark05(-1.5533124329640724,-0.023525482975476287,1.5707963267948966 ) ;
  }

  @Test
  public void test3384() {
    coral.tests.JPFBenchmark.benchmark05(-1.5540659603787021,-1.3770497228109289,-75.23793299196532 ) ;
  }

  @Test
  public void test3385() {
    coral.tests.JPFBenchmark.benchmark05(-1.5551083049887735,-1.5707963267948966,-88.93547056540507 ) ;
  }

  @Test
  public void test3386() {
    coral.tests.JPFBenchmark.benchmark05(-1.5552926897132635,-60.728311989130844,-37.71473687326274 ) ;
  }

  @Test
  public void test3387() {
    coral.tests.JPFBenchmark.benchmark05(-1.555379784226206,-47.49911417567051,-8.103981736346327 ) ;
  }

  @Test
  public void test3388() {
    coral.tests.JPFBenchmark.benchmark05(-1.5554729357425363,-35.43570879128177,-73.00411697504957 ) ;
  }

  @Test
  public void test3389() {
    coral.tests.JPFBenchmark.benchmark05(-1.555490925868351,-1.5707963267948966,-50.756946453099516 ) ;
  }

  @Test
  public void test3390() {
    coral.tests.JPFBenchmark.benchmark05(-1.5557960079930382,-1.5707963267948966,-90.0557638478101 ) ;
  }

  @Test
  public void test3391() {
    coral.tests.JPFBenchmark.benchmark05(-1.5558053780724344,-0.553006855541092,1.5707963267948966 ) ;
  }

  @Test
  public void test3392() {
    coral.tests.JPFBenchmark.benchmark05(-1.5563969784191256,-1.5707963267948912,-48.28533669310167 ) ;
  }

  @Test
  public void test3393() {
    coral.tests.JPFBenchmark.benchmark05(-1.5565935816853216,-3.1416003394711702,100.0 ) ;
  }

  @Test
  public void test3394() {
    coral.tests.JPFBenchmark.benchmark05(-1.5567007388357323,-9.59096169529436,-8.461890600817867 ) ;
  }

  @Test
  public void test3395() {
    coral.tests.JPFBenchmark.benchmark05(-1.5567377587995987,-3.266867424063314,0.2623708362384078 ) ;
  }

  @Test
  public void test3396() {
    coral.tests.JPFBenchmark.benchmark05(-1.5570805742964064,-1.5707963267948966,-57.7823904539174 ) ;
  }

  @Test
  public void test3397() {
    coral.tests.JPFBenchmark.benchmark05(-15.576234440184678,-75.43441280861614,-62.03743043621088 ) ;
  }

  @Test
  public void test3398() {
    coral.tests.JPFBenchmark.benchmark05(-1.5576579882240984,-72.39973581874683,90.75922341308292 ) ;
  }

  @Test
  public void test3399() {
    coral.tests.JPFBenchmark.benchmark05(-1.5582038879491154,-1.5707963267948966,-26.919304017563903 ) ;
  }

  @Test
  public void test3400() {
    coral.tests.JPFBenchmark.benchmark05(-1.5582745562780624,-40.89931647810265,-1.5707963460730647 ) ;
  }

  @Test
  public void test3401() {
    coral.tests.JPFBenchmark.benchmark05(-1.5584103852047346,-1.5707963267948966,-418.0714065964685 ) ;
  }

  @Test
  public void test3402() {
    coral.tests.JPFBenchmark.benchmark05(-1.5586027595234762,-1.5707963267948966,6.283189139118149 ) ;
  }

  @Test
  public void test3403() {
    coral.tests.JPFBenchmark.benchmark05(-1.5586930273022552,-1.5707963267948966,1.5707963248529049 ) ;
  }

  @Test
  public void test3404() {
    coral.tests.JPFBenchmark.benchmark05(-1.5588386021061829,4.141592653589794,55.51561748802652 ) ;
  }

  @Test
  public void test3405() {
    coral.tests.JPFBenchmark.benchmark05(-1.5589479883223762,-0.10669372971879401,-25.601462780958883 ) ;
  }

  @Test
  public void test3406() {
    coral.tests.JPFBenchmark.benchmark05(-1.5595053750711965,-1.5707963267948966,3.4074642390923566 ) ;
  }

  @Test
  public void test3407() {
    coral.tests.JPFBenchmark.benchmark05(-1.5595346070793719,-66.7377102713277,-3.2944368572595385E-83 ) ;
  }

  @Test
  public void test3408() {
    coral.tests.JPFBenchmark.benchmark05(-1.5596445310626794,-73.08302438653679,0.17763616655551506 ) ;
  }

  @Test
  public void test3409() {
    coral.tests.JPFBenchmark.benchmark05(-1.5601657228614012,-1.5707963267948966,-18.459779384499637 ) ;
  }

  @Test
  public void test3410() {
    coral.tests.JPFBenchmark.benchmark05(-1.5603116066419433,-47.35898364588253,-0.949353693111143 ) ;
  }

  @Test
  public void test3411() {
    coral.tests.JPFBenchmark.benchmark05(-1.5605861244401094,-1.5707963267948948,-1.5707963267948966 ) ;
  }

  @Test
  public void test3412() {
    coral.tests.JPFBenchmark.benchmark05(-1.5608200205385572,-15.851397262678717,-73.45590561090778 ) ;
  }

  @Test
  public void test3413() {
    coral.tests.JPFBenchmark.benchmark05(-1.5612299104383327,-1.5707963222567232,-84.25607682722752 ) ;
  }

  @Test
  public void test3414() {
    coral.tests.JPFBenchmark.benchmark05(-1.5613488008322105,-3.3881317890172014E-21,33.06339686406088 ) ;
  }

  @Test
  public void test3415() {
    coral.tests.JPFBenchmark.benchmark05(-1.56167259512398,-98.47463056180095,-26.066906239266693 ) ;
  }

  @Test
  public void test3416() {
    coral.tests.JPFBenchmark.benchmark05(-1.5624560178260025,-0.38594889752704226,33.082137385763474 ) ;
  }

  @Test
  public void test3417() {
    coral.tests.JPFBenchmark.benchmark05(-1.562644130546529,-0.044260725426457564,-6.283279291149622 ) ;
  }

  @Test
  public void test3418() {
    coral.tests.JPFBenchmark.benchmark05(-1.562653591827857,-1.5707963267948966,-0.6267766566568866 ) ;
  }

  @Test
  public void test3419() {
    coral.tests.JPFBenchmark.benchmark05(-1.5628029249026536,-35.60832144440526,17.05643837356332 ) ;
  }

  @Test
  public void test3420() {
    coral.tests.JPFBenchmark.benchmark05(-1.5633575647595124,-61.240049055054854,-16.03013561911881 ) ;
  }

  @Test
  public void test3421() {
    coral.tests.JPFBenchmark.benchmark05(-1.563490901734151,-1.2549948294341533,-1.0842021724855044E-19 ) ;
  }

  @Test
  public void test3422() {
    coral.tests.JPFBenchmark.benchmark05(-1.5637455208829023,1.3552527156068805E-20,0.0 ) ;
  }

  @Test
  public void test3423() {
    coral.tests.JPFBenchmark.benchmark05(-1.5637455689827897,-72.47461630698471,3.1416002829883913 ) ;
  }

  @Test
  public void test3424() {
    coral.tests.JPFBenchmark.benchmark05(-1.5639087315471478,-581.741852603177,-8.414554655701977 ) ;
  }

  @Test
  public void test3425() {
    coral.tests.JPFBenchmark.benchmark05(-1.564163266010857,-78.8837276041664,-81.57803257697287 ) ;
  }

  @Test
  public void test3426() {
    coral.tests.JPFBenchmark.benchmark05(-1.5642765096282505,-54.46071291030155,-6.28318723608084 ) ;
  }

  @Test
  public void test3427() {
    coral.tests.JPFBenchmark.benchmark05(-1.5643259779493137,-1.5707963267948966,99.71526183075049 ) ;
  }

  @Test
  public void test3428() {
    coral.tests.JPFBenchmark.benchmark05(-1.564483165782164,-41.7009136493685,-1.5707963267948966 ) ;
  }

  @Test
  public void test3429() {
    coral.tests.JPFBenchmark.benchmark05(-1.5649768940140791,-48.15015577589407,-3.29876426394077 ) ;
  }

  @Test
  public void test3430() {
    coral.tests.JPFBenchmark.benchmark05(-1.5650108134743212,-22.00895175114838,1.3572213075629842 ) ;
  }

  @Test
  public void test3431() {
    coral.tests.JPFBenchmark.benchmark05(-1.5653878858233126,-34.95072221749478,42.53650082355218 ) ;
  }

  @Test
  public void test3432() {
    coral.tests.JPFBenchmark.benchmark05(-1.5655694707210301,-0.1337924071661608,1.5707963267948974 ) ;
  }

  @Test
  public void test3433() {
    coral.tests.JPFBenchmark.benchmark05(-1.5655870374696195,-1.5707963267948966,0.5702547950580806 ) ;
  }

  @Test
  public void test3434() {
    coral.tests.JPFBenchmark.benchmark05(-1.5659641602423378,-0.4096535653146499,-45.1992176695844 ) ;
  }

  @Test
  public void test3435() {
    coral.tests.JPFBenchmark.benchmark05(-1.566095733368348,-1.320917175425107,1.5707963267948948 ) ;
  }

  @Test
  public void test3436() {
    coral.tests.JPFBenchmark.benchmark05(-1.5663693641563596,-1.3206811505028662,1.5406003638200136 ) ;
  }

  @Test
  public void test3437() {
    coral.tests.JPFBenchmark.benchmark05(-1.5665062320390126,-54.6849690536491,-31.425062401762375 ) ;
  }

  @Test
  public void test3438() {
    coral.tests.JPFBenchmark.benchmark05(-1.5672077931747275,-1.5707963267948966,-80.41005615783362 ) ;
  }

  @Test
  public void test3439() {
    coral.tests.JPFBenchmark.benchmark05(-1.5672156354420845,-160.3703089795539,-5.278738473488927 ) ;
  }

  @Test
  public void test3440() {
    coral.tests.JPFBenchmark.benchmark05(-1.5672317413860468,-34.96057253470089,94.50397506083485 ) ;
  }

  @Test
  public void test3441() {
    coral.tests.JPFBenchmark.benchmark05(-1.567248106010183,-84.97398684991116,-1262.5711965423277 ) ;
  }

  @Test
  public void test3442() {
    coral.tests.JPFBenchmark.benchmark05(-1.567440036188632,-3.290916322110953,82.47970747963683 ) ;
  }

  @Test
  public void test3443() {
    coral.tests.JPFBenchmark.benchmark05(-1.5675196045557271,-1.5707963267948961,1.5707963267948968 ) ;
  }

  @Test
  public void test3444() {
    coral.tests.JPFBenchmark.benchmark05(-1.5675269178387137,-84.83073759149426,18.488857476644924 ) ;
  }

  @Test
  public void test3445() {
    coral.tests.JPFBenchmark.benchmark05(-1.5677538878884385,-15.895843933947205,156.03081101609894 ) ;
  }

  @Test
  public void test3446() {
    coral.tests.JPFBenchmark.benchmark05(-1.5678778621663416,-4.114333213393461,-62.746690926523364 ) ;
  }

  @Test
  public void test3447() {
    coral.tests.JPFBenchmark.benchmark05(-1.5682685774725435E-15,-1.5707963267948966,-37.7522225878884 ) ;
  }

  @Test
  public void test3448() {
    coral.tests.JPFBenchmark.benchmark05(-1.5683235926650325,-1.1211012915253673,82.42228375139841 ) ;
  }

  @Test
  public void test3449() {
    coral.tests.JPFBenchmark.benchmark05(-1.5686405915044284,-3.3771999320516954,1.5707963267949125 ) ;
  }

  @Test
  public void test3450() {
    coral.tests.JPFBenchmark.benchmark05(-1.5687262641336392,-1.5707963267948963,-1.5707963267948966 ) ;
  }

  @Test
  public void test3451() {
    coral.tests.JPFBenchmark.benchmark05(-1.5687902026759317,-9.496020046472736,-64.8114964962937 ) ;
  }

  @Test
  public void test3452() {
    coral.tests.JPFBenchmark.benchmark05(-1.56913207138036,-48.1314048023828,-169.5701786678809 ) ;
  }

  @Test
  public void test3453() {
    coral.tests.JPFBenchmark.benchmark05(-1.569355376533674,-1.5707963267948966,-387.75426814607715 ) ;
  }

  @Test
  public void test3454() {
    coral.tests.JPFBenchmark.benchmark05(-1.5695124699621041,-1.570796326794367,28.37758868447755 ) ;
  }

  @Test
  public void test3455() {
    coral.tests.JPFBenchmark.benchmark05(-1.5695700759079922,-53.42852789409787,-6.283185296227971 ) ;
  }

  @Test
  public void test3456() {
    coral.tests.JPFBenchmark.benchmark05(-1.5700541314061265,-98.58584945352102,0.23668886079376172 ) ;
  }

  @Test
  public void test3457() {
    coral.tests.JPFBenchmark.benchmark05(-1.570127811065874,4.141592653591158,-1.5707963267948966 ) ;
  }

  @Test
  public void test3458() {
    coral.tests.JPFBenchmark.benchmark05(-1.570218513650251,2.710505431213761E-20,-56.48780943418759 ) ;
  }

  @Test
  public void test3459() {
    coral.tests.JPFBenchmark.benchmark05(-1.5703187291156113,-53.40709100720424,83.25232467683229 ) ;
  }

  @Test
  public void test3460() {
    coral.tests.JPFBenchmark.benchmark05(-1.5704093032576891,-6.707715118938736E-7,1.5707963267948966 ) ;
  }

  @Test
  public void test3461() {
    coral.tests.JPFBenchmark.benchmark05(-1.570422473897087,-1.1968035802445136,-50.101479215844776 ) ;
  }

  @Test
  public void test3462() {
    coral.tests.JPFBenchmark.benchmark05(-1.5704395424003974,-0.10498766946193612,-4.7123892102928835 ) ;
  }

  @Test
  public void test3463() {
    coral.tests.JPFBenchmark.benchmark05(-1.5704548746657871,-9.487286796563215,1.5707963267948966 ) ;
  }

  @Test
  public void test3464() {
    coral.tests.JPFBenchmark.benchmark05(-1.5704994892031625,-9.571257693291479,2.220446049250313E-16 ) ;
  }

  @Test
  public void test3465() {
    coral.tests.JPFBenchmark.benchmark05(-1.5705761208865292,-1.5707963267948966,-3.1497207625343515 ) ;
  }

  @Test
  public void test3466() {
    coral.tests.JPFBenchmark.benchmark05(-1.5705962664609985,-0.3389251270924891,73.65869660208554 ) ;
  }

  @Test
  public void test3467() {
    coral.tests.JPFBenchmark.benchmark05(-1.5706544033907694,-1.5707963267948966,-35.12389944521769 ) ;
  }

  @Test
  public void test3468() {
    coral.tests.JPFBenchmark.benchmark05(-1.5706696795697663,-48.644505524171464,-37.697877425459474 ) ;
  }

  @Test
  public void test3469() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707039418144801,-53.64016131099285,4.712400106757611 ) ;
  }

  @Test
  public void test3470() {
    coral.tests.JPFBenchmark.benchmark05(-1.57071925049884,-61.21481917151125,6.283535558344789 ) ;
  }

  @Test
  public void test3471() {
    coral.tests.JPFBenchmark.benchmark05(-1.570733424697905,-3.143657188424335,-1.008145388275338 ) ;
  }

  @Test
  public void test3472() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707405876055456,-5.421010862427522E-20,56.54516711167863 ) ;
  }

  @Test
  public void test3473() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707731668515863,-0.23480641909578648,-91.11251933032524 ) ;
  }

  @Test
  public void test3474() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707762726964702,-3.634514628540425,19.404318408436527 ) ;
  }

  @Test
  public void test3475() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707889845733203,-3.231773649658751E-15,7.853977914715625 ) ;
  }

  @Test
  public void test3476() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707916257665901,-4.3761175009996574E-15,87.96452282293795 ) ;
  }

  @Test
  public void test3477() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707936596248306,-1.2591996035416636E-5,-131.95827953239404 ) ;
  }

  @Test
  public void test3478() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707944676150871,-0.1499173291908667,64.29858363016439 ) ;
  }

  @Test
  public void test3479() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707960246208084,-5.5380685651448084E-17,0.42903969613507675 ) ;
  }

  @Test
  public void test3480() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707960823803193,-122.56711888481604,-1.570852329740366 ) ;
  }

  @Test
  public void test3481() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707962042186654,-1.5638593102290124,-89.58725574932078 ) ;
  }

  @Test
  public void test3482() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707962271966667,-41.901013775276155,0.0 ) ;
  }

  @Test
  public void test3483() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707962839591856,-60.773693696172295,-5.108785017084766 ) ;
  }

  @Test
  public void test3484() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707962907476838,-1.2040122065581398,6.2831854098442355 ) ;
  }

  @Test
  public void test3485() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707962917929965,-1.5707963267948966,-8.240133578554994 ) ;
  }

  @Test
  public void test3486() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707962972013554,-1.5707963267948912,-42.98145575487034 ) ;
  }

  @Test
  public void test3487() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963035954724,-98.01948148694481,156.07020507819857 ) ;
  }

  @Test
  public void test3488() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963062195134,-66.49088287097237,1.734723475976807E-18 ) ;
  }

  @Test
  public void test3489() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963073369335,-34.55849575274942,1.5707963267948966 ) ;
  }

  @Test
  public void test3490() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963147162989,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3491() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963162379324,-42.11279693417643,90.77064047035421 ) ;
  }

  @Test
  public void test3492() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963183664477,-2.220446049250313E-16,194.74377595075043 ) ;
  }

  @Test
  public void test3493() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796318647936,-1.492624799847936,0.6694070682182868 ) ;
  }

  @Test
  public void test3494() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963204984148,-1.5707963267948966,-1.1171501764539018 ) ;
  }

  @Test
  public void test3495() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963207556004,-47.26237160753594,85.12980420735038 ) ;
  }

  @Test
  public void test3496() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963232697115,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3497() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963235194702,-1.5707963267948966,40.42590551182962 ) ;
  }

  @Test
  public void test3498() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963237496954,-1.5707963267948966,-73.77557167672649 ) ;
  }

  @Test
  public void test3499() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963239191642,-0.7164664179824015,-1.350608638440314 ) ;
  }

  @Test
  public void test3500() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963239214806,-1.5707963267948966,45.52497907876187 ) ;
  }

  @Test
  public void test3501() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963240969536,-1.5707963267948966,83.16540243650614 ) ;
  }

  @Test
  public void test3502() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963242927743,-141.69920922809337,0.33677811383109957 ) ;
  }

  @Test
  public void test3503() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963243139746,-1.538912486502937,-32.46202008902236 ) ;
  }

  @Test
  public void test3504() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796325053789,-1.1694231846946848,160.904109628056 ) ;
  }

  @Test
  public void test3505() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963251936146,-1.5504201385089555,-56.31907214787729 ) ;
  }

  @Test
  public void test3506() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963253061694,-0.08196597713221715,-1.5707963267948966 ) ;
  }

  @Test
  public void test3507() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963254769641,-42.35419482143899,-1.5707963267948966 ) ;
  }

  @Test
  public void test3508() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963255729318,-98.03640623649143,59.1021970367724 ) ;
  }

  @Test
  public void test3509() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963255969413,-48.414867485647136,-198.07452238217425 ) ;
  }

  @Test
  public void test3510() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963256072237,-1.5707963267948966,-44.4550862832875 ) ;
  }

  @Test
  public void test3511() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963257062107,-1.5407439555097887E-33,69.1130135082311 ) ;
  }

  @Test
  public void test3512() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796325715678,-47.37507327940839,-1.5707963267948966 ) ;
  }

  @Test
  public void test3513() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963259557585,-34.90741908121405,-5.725592491604948 ) ;
  }

  @Test
  public void test3514() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963260380666,-1.5707963267948966,92.37557178697183 ) ;
  }

  @Test
  public void test3515() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326051396,-61.140831440536644,-20.659175372219362 ) ;
  }

  @Test
  public void test3516() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963261182318,-1.5707963267948966,32.83943206241659 ) ;
  }

  @Test
  public void test3517() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963261667812,-1.474203589202731,42.70828959206793 ) ;
  }

  @Test
  public void test3518() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963261824662,-0.2511856164563523,-1.5707963267948966 ) ;
  }

  @Test
  public void test3519() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963262320548,-1.5707963267948966,-26.608003050772865 ) ;
  }

  @Test
  public void test3520() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963263176887,-35.2939876008911,-34.70774460696168 ) ;
  }

  @Test
  public void test3521() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963263360507,-1.5707963267948966,-42.80150047754892 ) ;
  }

  @Test
  public void test3522() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963264250107,-1.5707963267948966,-0.6212614963523808 ) ;
  }

  @Test
  public void test3523() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265035552,-110.20262331558106,-44.65289490364131 ) ;
  }

  @Test
  public void test3524() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265056815,-1.5707963267948966,-59.49946318078877 ) ;
  }

  @Test
  public void test3525() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265116824,-0.5676830392550872,-1.5707963267948983 ) ;
  }

  @Test
  public void test3526() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265138212,-22.36038532792776,-3.456709978513327 ) ;
  }

  @Test
  public void test3527() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265170806,-1.5707963267948983,27.795959411565747 ) ;
  }

  @Test
  public void test3528() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265249993,-1.5707963267948966,-49.54525861322181 ) ;
  }

  @Test
  public void test3529() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265316907,-97.9981962796324,-1.126547225412364 ) ;
  }

  @Test
  public void test3530() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265320546,-0.6942026317848595,1.5707963267948966 ) ;
  }

  @Test
  public void test3531() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326536788,-0.08214433240035272,-30.942402383401124 ) ;
  }

  @Test
  public void test3532() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265427989,-1.1982552059669225,1.5707963267948948 ) ;
  }

  @Test
  public void test3533() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265433955,-4.05225031888969,14.017711059808796 ) ;
  }

  @Test
  public void test3534() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265498006,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test3535() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326555239,-1.5707963267948912,64.14011090275507 ) ;
  }

  @Test
  public void test3536() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265598182,-0.7680564843440386,0.0 ) ;
  }

  @Test
  public void test3537() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265761054,-1.5707963267948983,35.688216556708554 ) ;
  }

  @Test
  public void test3538() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265776628,-3.7980311142908505,1.5707963267948983 ) ;
  }

  @Test
  public void test3539() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265823202,-0.19003253962366692,95.32622689486928 ) ;
  }

  @Test
  public void test3540() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265902847,-1.2979743269746582,100.0 ) ;
  }

  @Test
  public void test3541() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265942777,-35.51170322361544,100.0 ) ;
  }

  @Test
  public void test3542() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266007297,-2.7016136048916335E-225,1.5707963267948966 ) ;
  }

  @Test
  public void test3543() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266020761,-10.100810953600426,-9.808419827093935 ) ;
  }

  @Test
  public void test3544() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266028524,-0.7247254925907359,-28.757050526348507 ) ;
  }

  @Test
  public void test3545() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326603296,-1.0630178642507238,35.3963592050599 ) ;
  }

  @Test
  public void test3546() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326607552,-1.5707963267948963,77.97500925658056 ) ;
  }

  @Test
  public void test3547() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266078495,-41.780253842243376,35.007895554414205 ) ;
  }

  @Test
  public void test3548() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266099847,-1.5707963267948983,-16.07290532050498 ) ;
  }

  @Test
  public void test3549() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266128435,-1.5707963267949019,60.257205180625704 ) ;
  }

  @Test
  public void test3550() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266146867,-60.871832896086445,0.0 ) ;
  }

  @Test
  public void test3551() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266166123,-1.5707963267948912,-56.49551977620024 ) ;
  }

  @Test
  public void test3552() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326625579,-1.5707963267847909,-1.5707963267948966 ) ;
  }

  @Test
  public void test3553() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266319565,-1.5707963267948966,48.57586362642738 ) ;
  }

  @Test
  public void test3554() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266473306,-54.91392767579483,-15.758808003674107 ) ;
  }

  @Test
  public void test3555() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326648243,-0.48734503970453136,-1.5707963267948961 ) ;
  }

  @Test
  public void test3556() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266629204,-10.183340506644576,-32.52841989878725 ) ;
  }

  @Test
  public void test3557() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266642242,-1.5707963267948966,-20.667068634284778 ) ;
  }

  @Test
  public void test3558() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266679177,-1.5707963267948966,0.07146188189306564 ) ;
  }

  @Test
  public void test3559() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266759954,-1.5707963267948983,-10.893376263737878 ) ;
  }

  @Test
  public void test3560() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266866074,-1.5475146175091654,52.54023224430095 ) ;
  }

  @Test
  public void test3561() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266884424,-1.5707963267948966,-44.04535973361664 ) ;
  }

  @Test
  public void test3562() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326706541,-1.5707963267948983,77.37236404421918 ) ;
  }

  @Test
  public void test3563() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267136975,-1.5707963267948966,87.39594427874987 ) ;
  }

  @Test
  public void test3564() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267191465,-78.55555711497648,1.5707963267948966 ) ;
  }

  @Test
  public void test3565() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267233387,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3566() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267274423,-2.220446049250313E-16,-1.5707963267949054 ) ;
  }

  @Test
  public void test3567() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267358391,-0.4595007085381056,6.254374736733155 ) ;
  }

  @Test
  public void test3568() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267431992,-10.229016053899459,16.090153072641765 ) ;
  }

  @Test
  public void test3569() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267460747,-61.1275326246241,100.0 ) ;
  }

  @Test
  public void test3570() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267468439,-0.5706525002582628,88.97751012664217 ) ;
  }

  @Test
  public void test3571() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267472789,-1.5707963267948966,-19.038948167917408 ) ;
  }

  @Test
  public void test3572() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267501588,-1.5707963267948966,-51.13155229444335 ) ;
  }

  @Test
  public void test3573() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267517895,-54.82937227085817,0.0 ) ;
  }

  @Test
  public void test3574() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326765344,-16.12080669636625,-13.551041561320165 ) ;
  }

  @Test
  public void test3575() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267706742,-47.51437450456825,0.10968333729292357 ) ;
  }

  @Test
  public void test3576() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267715854,-1.5707963267948983,-78.40789664141163 ) ;
  }

  @Test
  public void test3577() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267734066,-72.77648939183894,175.36228091923857 ) ;
  }

  @Test
  public void test3578() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326773762,-1.570796326794926,110.32485952706874 ) ;
  }

  @Test
  public void test3579() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267746905,-0.38498344139270957,-1.5707963267948983 ) ;
  }

  @Test
  public void test3580() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267772858,-1.3618334038221054,3.552713678800501E-15 ) ;
  }

  @Test
  public void test3581() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326779319,-0.3285535839819741,1.5707963267948966 ) ;
  }

  @Test
  public void test3582() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267794185,-154.7242666200012,8.27689655909353 ) ;
  }

  @Test
  public void test3583() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267811527,-0.24762001892818225,15.765875730541005 ) ;
  }

  @Test
  public void test3584() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267830334,-72.45752196771915,1.5707963267948966 ) ;
  }

  @Test
  public void test3585() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267830543,-0.2505868335025796,64.72157623706451 ) ;
  }

  @Test
  public void test3586() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267875105,-1.5707963267948966,25.894678888634118 ) ;
  }

  @Test
  public void test3587() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267879848,-1.5707963267948966,-54.14965516174084 ) ;
  }

  @Test
  public void test3588() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267882419,-0.6010835954185288,94.76953038760985 ) ;
  }

  @Test
  public void test3589() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326789086,-0.04653641311275126,0.0 ) ;
  }

  @Test
  public void test3590() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267892273,-61.21537096254657,-95.80597688778826 ) ;
  }

  @Test
  public void test3591() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267901996,-0.7676503033438455,1.5707963267948966 ) ;
  }

  @Test
  public void test3592() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267904925,-1.4927778219527157,-1.5707963267948966 ) ;
  }

  @Test
  public void test3593() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326790978,-66.4304849183962,-8.986816509415195 ) ;
  }

  @Test
  public void test3594() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267911118,-3.7114398189235374,91.95584536451351 ) ;
  }

  @Test
  public void test3595() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326791739,-66.24872585122984,56.06602356984595 ) ;
  }

  @Test
  public void test3596() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267917895,-1.5707963267948966,10.968659657695042 ) ;
  }

  @Test
  public void test3597() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267920766,-28.367357082672257,-48.13690836733095 ) ;
  }

  @Test
  public void test3598() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267922571,-41.65436231217754,-1.54226457172118 ) ;
  }

  @Test
  public void test3599() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267925802,-1.5707963267948966,45.0481314169684 ) ;
  }

  @Test
  public void test3600() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326792582,-0.8625831126093289,50.09376024472883 ) ;
  }

  @Test
  public void test3601() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326792942,-1.5707963267948966,-1.3344924073805935 ) ;
  }

  @Test
  public void test3602() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267932223,-0.9460628055130186,0.0 ) ;
  }

  @Test
  public void test3603() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267935519,-1.5707963267948966,20.991016263543074 ) ;
  }

  @Test
  public void test3604() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267937675,-47.190861634027065,-1.5707963267948966 ) ;
  }

  @Test
  public void test3605() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267939462,-4.440892098500626E-16,0.0 ) ;
  }

  @Test
  public void test3606() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267939817,-1.5707963267948966,62.775721811956885 ) ;
  }

  @Test
  public void test3607() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267940395,-1.5707963267948966,-14.47169111857604 ) ;
  }

  @Test
  public void test3608() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267942109,6.3108872417680944E-30,-1.5707963267948963 ) ;
  }

  @Test
  public void test3609() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267942544,-59.74247959683484,24.084658579092434 ) ;
  }

  @Test
  public void test3610() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267943208,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3611() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794361,-1.4462638207706764,64.33889003647914 ) ;
  }

  @Test
  public void test3612() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267943952,-1.53705452417221,13.561084867547208 ) ;
  }

  @Test
  public void test3613() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267944791,-72.48882778974527,-6.283200565976923 ) ;
  }

  @Test
  public void test3614() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267945297,-1.5707963267948966,-6.430326025151236 ) ;
  }

  @Test
  public void test3615() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267946146,-1.183520263657296,-22.71348773530828 ) ;
  }

  @Test
  public void test3616() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267946166,-42.168263185803106,27.96040436648864 ) ;
  }

  @Test
  public void test3617() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794646,-1.5707963267949019,18.928592362922814 ) ;
  }

  @Test
  public void test3618() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267946656,-48.42156859145136,-60.00024166083925 ) ;
  }

  @Test
  public void test3619() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267947047,-54.83648759425161,0.002757903838315181 ) ;
  }

  @Test
  public void test3620() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794778,-1.349817219993442,63.43497330067919 ) ;
  }

  @Test
  public void test3621() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267947942,-1.5707963267948906,-28.92113894227412 ) ;
  }

  @Test
  public void test3622() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794799,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3623() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948009,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3624() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948024,-0.7600128583853765,100.0 ) ;
  }

  @Test
  public void test3625() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948093,-1.5707963267948966,32.46544318082542 ) ;
  }

  @Test
  public void test3626() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948128,-1.5707963267948966,38.59942192731398 ) ;
  }

  @Test
  public void test3627() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948202,-10.119168422924409,56.584854414886024 ) ;
  }

  @Test
  public void test3628() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948224,-54.56824805556517,0.7653488929568439 ) ;
  }

  @Test
  public void test3629() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794833,-1.5707963267948966,10.185158671856424 ) ;
  }

  @Test
  public void test3630() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948362,-15.826976211764759,14.44023944853361 ) ;
  }

  @Test
  public void test3631() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794838,-0.62428952310316,-31.44717654485807 ) ;
  }

  @Test
  public void test3632() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948415,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3633() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794845,-1.5707963267948966,-202.84362175133356 ) ;
  }

  @Test
  public void test3634() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948462,-42.26071798743254,-89.98784004586827 ) ;
  }

  @Test
  public void test3635() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948486,1.5777218104420236E-30,-76.65627851959609 ) ;
  }

  @Test
  public void test3636() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794851,-2.220446049250313E-16,-25.981977816581022 ) ;
  }

  @Test
  public void test3637() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948521,-0.009958783885252842,555.5338611986647 ) ;
  }

  @Test
  public void test3638() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948537,-1.5707963267948943,-20.65916478485896 ) ;
  }

  @Test
  public void test3639() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948546,-1.2308605801922765,-1.5707963267948966 ) ;
  }

  @Test
  public void test3640() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794855,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test3641() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948586,-1.5707963267948966,-3.1435467954843204 ) ;
  }

  @Test
  public void test3642() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948593,-1.4719717927907998,1.5707963267948966 ) ;
  }

  @Test
  public void test3643() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948626,-1.5707963267948983,-1.5707963267948966 ) ;
  }

  @Test
  public void test3644() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948637,-48.60272392671045,-1.5707963267948983 ) ;
  }

  @Test
  public void test3645() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948641,-53.50434761150629,100.0 ) ;
  }

  @Test
  public void test3646() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794864,-1.5707963266845322,1.1357762311333293 ) ;
  }

  @Test
  public void test3647() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794864,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3648() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794864,-1.5707963267948966,-94.88456407788185 ) ;
  }

  @Test
  public void test3649() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794866,-3.141594540082051,-57.913554490874105 ) ;
  }

  @Test
  public void test3650() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948664,-73.14459620178023,-82.95776566619644 ) ;
  }

  @Test
  public void test3651() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794868,-1.0899620960063354,3.149405224430785 ) ;
  }

  @Test
  public void test3652() {
    coral.tests.JPFBenchmark.benchmark05(-1.57079632679487,-0.2805899942150515,-92.70778278239746 ) ;
  }

  @Test
  public void test3653() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948704,-1.0010415475915505E-146,1.2783149201760455 ) ;
  }

  @Test
  public void test3654() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794871,-1.2311181819892596,-1.5707963267948966 ) ;
  }

  @Test
  public void test3655() {
    coral.tests.JPFBenchmark.benchmark05(-1.57079632679487,-1.1746462083030724,4.141592656646972 ) ;
  }

  @Test
  public void test3656() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948715,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3657() {
    coral.tests.JPFBenchmark.benchmark05(-1.57079632679487,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3658() {
    coral.tests.JPFBenchmark.benchmark05(-1.57079632679487,-1.5707963267948966,20.54600503511773 ) ;
  }

  @Test
  public void test3659() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794872,-1.5707963267946146,1.5707963267948966 ) ;
  }

  @Test
  public void test3660() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948724,-9.948264264711476,3.1494051546066735 ) ;
  }

  @Test
  public void test3661() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794873,-1.4525711516978295,-75.74766581781176 ) ;
  }

  @Test
  public void test3662() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948735,-1.5707963267948972,20.27901506102299 ) ;
  }

  @Test
  public void test3663() {
    coral.tests.JPFBenchmark.benchmark05(-1.57079632679487,-35.1679140826169,-81.74675267710317 ) ;
  }

  @Test
  public void test3664() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948748,-1.5707963267948966,-79.32589081551085 ) ;
  }

  @Test
  public void test3665() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794875,-35.17533849298107,96.01597834909079 ) ;
  }

  @Test
  public void test3666() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794876,-1.5707963267948948,23.176763236319616 ) ;
  }

  @Test
  public void test3667() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794877,-15.912286147384842,51.282934520175985 ) ;
  }

  @Test
  public void test3668() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794877,-22.27192514087752,117.7126688779351 ) ;
  }

  @Test
  public void test3669() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794877,-22.37854357401374,-82.18464531552448 ) ;
  }

  @Test
  public void test3670() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794877,-28.28870172464015,1.349162204844514 ) ;
  }

  @Test
  public void test3671() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794877,-34.990051404067486,1.5707963267948968 ) ;
  }

  @Test
  public void test3672() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794877,-3.7169306055513474,-33.564378079802964 ) ;
  }

  @Test
  public void test3673() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948775,-1.5707963267948966,18.336320684391065 ) ;
  }

  @Test
  public void test3674() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948775,-1.5707963267948966,-75.4621999349543 ) ;
  }

  @Test
  public void test3675() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794877,-59.699666068653315,53.80280710669575 ) ;
  }

  @Test
  public void test3676() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794878,-1.5089637354013974,0.0 ) ;
  }

  @Test
  public void test3677() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948786,-0.26989644944561697,-53.821569421469874 ) ;
  }

  @Test
  public void test3678() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948786,-1.5707963267948966,45.26157092187252 ) ;
  }

  @Test
  public void test3679() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948801,-35.34719681881255,-1.5707963267948966 ) ;
  }

  @Test
  public void test3680() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794881,-3.6093241279795336,-2.417306807232825 ) ;
  }

  @Test
  public void test3681() {
    coral.tests.JPFBenchmark.benchmark05(-1.57079632679488,-1.5707963267948966,-21.901717137947045 ) ;
  }

  @Test
  public void test3682() {
    coral.tests.JPFBenchmark.benchmark05(-1.57079632679488,-1.5707963267948966,90.09001477994384 ) ;
  }

  @Test
  public void test3683() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948821,-72.42394407463595,-3.1422065178007146 ) ;
  }

  @Test
  public void test3684() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948841,-0.013131159028807562,86.47174044357408 ) ;
  }

  @Test
  public void test3685() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948841,-1.5707963267948912,62.40835874444787 ) ;
  }

  @Test
  public void test3686() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948841,-1.5707963267948966,-49.85454696960181 ) ;
  }

  @Test
  public void test3687() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948841,-66.07854472454636,71.8275648188331 ) ;
  }

  @Test
  public void test3688() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948841,-66.76964220834309,-167.0507660769942 ) ;
  }

  @Test
  public void test3689() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948841,-97.9846060802831,100.0 ) ;
  }

  @Test
  public void test3690() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794886,-1.5707963267948983,154.4669585038344 ) ;
  }

  @Test
  public void test3691() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794886,-36.05158484559965,0.0 ) ;
  }

  @Test
  public void test3692() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948863,-98.14641421772608,-1.5707963267948957 ) ;
  }

  @Test
  public void test3693() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948866,-1.5707963267948966,-63.419853868344475 ) ;
  }

  @Test
  public void test3694() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948872,-1.5707963267948966,-92.25988889528469 ) ;
  }

  @Test
  public void test3695() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948877,-0.46299758246871847,0.0 ) ;
  }

  @Test
  public void test3696() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948877,-0.5402748434614058,-27.776997813027492 ) ;
  }

  @Test
  public void test3697() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948877,-35.81689305646438,34.376080343316346 ) ;
  }

  @Test
  public void test3698() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948881,-1.5707963267948966,95.17805625062095 ) ;
  }

  @Test
  public void test3699() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794888,-3.485520406923117E-15,1.5707963267948966 ) ;
  }

  @Test
  public void test3700() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948886,-1.5707963267948966,-17.674852067674674 ) ;
  }

  @Test
  public void test3701() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948886,-1.5707963267948966,26.985966203420787 ) ;
  }

  @Test
  public void test3702() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948888,-1.5707963267948966,34.12977643993722 ) ;
  }

  @Test
  public void test3703() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948888,-1.5707963267948966,66.5856315831768 ) ;
  }

  @Test
  public void test3704() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948895,-1.5461737434191676,1.5707963335089274 ) ;
  }

  @Test
  public void test3705() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948895,-1.5707963267948966,-57.37300434766779 ) ;
  }

  @Test
  public void test3706() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948895,-66.40856413802612,-67.6234512242082 ) ;
  }

  @Test
  public void test3707() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948895,-66.4544888606565,-30.617126494901584 ) ;
  }

  @Test
  public void test3708() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948895,-97.72305044465125,19.918020207212336 ) ;
  }

  @Test
  public void test3709() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948897,-1.5707963267948963,41.526213646119515 ) ;
  }

  @Test
  public void test3710() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948901,-3.1837983372366913E-87,50.085286924328386 ) ;
  }

  @Test
  public void test3711() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948903,-0.7470425344128913,-84.80449245605354 ) ;
  }

  @Test
  public void test3712() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948903,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3713() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948906,-1.5707963267948963,-21.95533482886728 ) ;
  }

  @Test
  public void test3714() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948906,-1.5707963267948966,18.662084692961344 ) ;
  }

  @Test
  public void test3715() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948908,-1.5707963267948966,29.66349408838768 ) ;
  }

  @Test
  public void test3716() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794891,-1.5707963267948966,60.01232708596058 ) ;
  }

  @Test
  public void test3717() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.013783352264735954,-12.786450085862768 ) ;
  }

  @Test
  public void test3718() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.0665328286376555,-50.75498347501026 ) ;
  }

  @Test
  public void test3719() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.1461598210233127,78.02588452644821 ) ;
  }

  @Test
  public void test3720() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.26663583818124975,29.924913704846887 ) ;
  }

  @Test
  public void test3721() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.3137852564823076,-55.309483340056374 ) ;
  }

  @Test
  public void test3722() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.3225600286710204,-226.30270357281435 ) ;
  }

  @Test
  public void test3723() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.42180487840256675,21.641684030321116 ) ;
  }

  @Test
  public void test3724() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.4527699502489214,0.3189001132892607 ) ;
  }

  @Test
  public void test3725() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.5306240930256427,96.10171884530361 ) ;
  }

  @Test
  public void test3726() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.5657834552618288,17.007804959961177 ) ;
  }

  @Test
  public void test3727() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.5774714304981852,3.4030962213471403 ) ;
  }

  @Test
  public void test3728() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.6042844624280477,-42.12756750215946 ) ;
  }

  @Test
  public void test3729() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.6478909097197612,-87.73652621869017 ) ;
  }

  @Test
  public void test3730() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.6580402822471099,-69.38586885031526 ) ;
  }

  @Test
  public void test3731() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.6758060609675125,37.15660280915819 ) ;
  }

  @Test
  public void test3732() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.7226020765899593,-100.0 ) ;
  }

  @Test
  public void test3733() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.8593950986369707,41.32184759304321 ) ;
  }

  @Test
  public void test3734() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.8879900634228193,-23.352473040713065 ) ;
  }

  @Test
  public void test3735() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-10.186784700147514,3.4084577106593503 ) ;
  }

  @Test
  public void test3736() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-10.237638653008887,-56.09318635807308 ) ;
  }

  @Test
  public void test3737() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.0310903967068303,1.5707963267948977 ) ;
  }

  @Test
  public void test3738() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-10.342371423295816,25.315033919037717 ) ;
  }

  @Test
  public void test3739() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-10.376603407444833,-0.4241648796732036 ) ;
  }

  @Test
  public void test3740() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-10.422812575237359,0.0 ) ;
  }

  @Test
  public void test3741() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-104.69043641169486,-82.76972502218977 ) ;
  }

  @Test
  public void test3742() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.1102230246251565E-16,73.22517984112667 ) ;
  }

  @Test
  public void test3743() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.1566109678780805,92.55777001127399 ) ;
  }

  @Test
  public void test3744() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.213147687990828,1.3837952982029549 ) ;
  }

  @Test
  public void test3745() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-122.6980869761341,-71.74045635471487 ) ;
  }

  @Test
  public void test3746() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-123.33737346486461,46.22287707932718 ) ;
  }

  @Test
  public void test3747() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-123.50546351215856,56.492223404061974 ) ;
  }

  @Test
  public void test3748() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.2376905169228116,88.47106984214287 ) ;
  }

  @Test
  public void test3749() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.280418904194704,90.64250691463579 ) ;
  }

  @Test
  public void test3750() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.3378118071931744,-29.82094493066812 ) ;
  }

  @Test
  public void test3751() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-135.7790648968982,3.7195889779499254 ) ;
  }

  @Test
  public void test3752() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-135.82786435864085,-11.372976831541465 ) ;
  }

  @Test
  public void test3753() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5046801100589724,6.284926491921403 ) ;
  }

  @Test
  public void test3754() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5392919427691292,-56.921093554101155 ) ;
  }

  @Test
  public void test3755() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-154.4860000141694,-7.099070453610494 ) ;
  }

  @Test
  public void test3756() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267891465,-32.95316736637093 ) ;
  }

  @Test
  public void test3757() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948912,-44.83432593864154 ) ;
  }

  @Test
  public void test3758() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948928,-168.58567939271245 ) ;
  }

  @Test
  public void test3759() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948948,-50.15146576847065 ) ;
  }

  @Test
  public void test3760() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948948,-55.34418941594467 ) ;
  }

  @Test
  public void test3761() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948948,-79.25180885616196 ) ;
  }

  @Test
  public void test3762() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948948,8.322480584343992 ) ;
  }

  @Test
  public void test3763() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948948,-90.57326557051204 ) ;
  }

  @Test
  public void test3764() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3765() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3766() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,17.7448070340385 ) ;
  }

  @Test
  public void test3767() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,-20.58088768272684 ) ;
  }

  @Test
  public void test3768() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,-20.692280083572086 ) ;
  }

  @Test
  public void test3769() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,2.220446049250313E-16 ) ;
  }

  @Test
  public void test3770() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,24.41981839004717 ) ;
  }

  @Test
  public void test3771() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,27.061566838491842 ) ;
  }

  @Test
  public void test3772() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,-27.148898707803667 ) ;
  }

  @Test
  public void test3773() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,29.735499697871926 ) ;
  }

  @Test
  public void test3774() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,3.141600282984325 ) ;
  }

  @Test
  public void test3775() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,32.94795542478631 ) ;
  }

  @Test
  public void test3776() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,-34.76559573915874 ) ;
  }

  @Test
  public void test3777() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,-49.82772463429974 ) ;
  }

  @Test
  public void test3778() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,57.91495819708197 ) ;
  }

  @Test
  public void test3779() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,67.46485707131438 ) ;
  }

  @Test
  public void test3780() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,-68.84187957275716 ) ;
  }

  @Test
  public void test3781() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,74.83524269838742 ) ;
  }

  @Test
  public void test3782() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,-84.9302826612291 ) ;
  }

  @Test
  public void test3783() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,-8.759164794551928 ) ;
  }

  @Test
  public void test3784() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948974,0.0 ) ;
  }

  @Test
  public void test3785() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948983,-45.90847825334621 ) ;
  }

  @Test
  public void test3786() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948983,-53.51269284589626 ) ;
  }

  @Test
  public void test3787() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948983,77.26467760969194 ) ;
  }

  @Test
  public void test3788() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-15.853897347184436,59.573797958650644 ) ;
  }

  @Test
  public void test3789() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-167.0596298097441,-64.45621259862031 ) ;
  }

  @Test
  public void test3790() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.7763568394002505E-15,-44.28379311213537 ) ;
  }

  @Test
  public void test3791() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.8033161362862765E-130,-99.48176393479669 ) ;
  }

  @Test
  public void test3792() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-2.6911534158661682E-15,355.6533018696098 ) ;
  }

  @Test
  public void test3793() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-3.1415926535897953,-1.4424533152933647 ) ;
  }

  @Test
  public void test3794() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-34.59339624465771,27.964707112765158 ) ;
  }

  @Test
  public void test3795() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-34.841406793581015,1.5707963267948966 ) ;
  }

  @Test
  public void test3796() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-34.88208447704615,52.086402256098665 ) ;
  }

  @Test
  public void test3797() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-35.08284388533908,-1.5707963267948983 ) ;
  }

  @Test
  public void test3798() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-35.151497319648044,1.5707963267948966 ) ;
  }

  @Test
  public void test3799() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-35.31883286411342,-15.227926162842294 ) ;
  }

  @Test
  public void test3800() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-35.34256562704621,-67.11203498847661 ) ;
  }

  @Test
  public void test3801() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-35.48083725199117,-84.73593328097562 ) ;
  }

  @Test
  public void test3802() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-35.49602588798679,-45.76297386027193 ) ;
  }

  @Test
  public void test3803() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-35.54174855116861,-20.737460378478943 ) ;
  }

  @Test
  public void test3804() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-35.664116581099805,21.47840952635329 ) ;
  }

  @Test
  public void test3805() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-35.714963148777116,0.0 ) ;
  }

  @Test
  public void test3806() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-35.73280101865504,-21.101101169678866 ) ;
  }

  @Test
  public void test3807() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-35.75879293759028,79.65696733110431 ) ;
  }

  @Test
  public void test3808() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-35.84147074042576,-46.85079500153879 ) ;
  }

  @Test
  public void test3809() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-35.9122161897009,1.5707963267948966 ) ;
  }

  @Test
  public void test3810() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-35.95312082455842,77.46099524524993 ) ;
  }

  @Test
  public void test3811() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-36.108062626613936,6.2831886279574976 ) ;
  }

  @Test
  public void test3812() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-3.688067358228622,1.5707963267948983 ) ;
  }

  @Test
  public void test3813() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-3.883802848646405,106.69588957597227 ) ;
  }

  @Test
  public void test3814() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-41.081071416767465,29.379515274329435 ) ;
  }

  @Test
  public void test3815() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-41.39687186907823,-2.710505431213761E-20 ) ;
  }

  @Test
  public void test3816() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-41.487984434611214,-51.5018244715394 ) ;
  }

  @Test
  public void test3817() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-41.539575556871355,76.96902001294994 ) ;
  }

  @Test
  public void test3818() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-41.55167348398312,57.13664297947166 ) ;
  }

  @Test
  public void test3819() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-41.628337234539984,3.4447926823635697 ) ;
  }

  @Test
  public void test3820() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-41.65631234899904,1.5707963267948966 ) ;
  }

  @Test
  public void test3821() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-41.6774494992487,64.36826908320535 ) ;
  }

  @Test
  public void test3822() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-41.84488504737373,57.70979362372958 ) ;
  }

  @Test
  public void test3823() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-41.99108088896202,-1.5707963267948966 ) ;
  }

  @Test
  public void test3824() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-42.175064554644884,-72.57307070592955 ) ;
  }

  @Test
  public void test3825() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-47.1395148038469,89.53539062730911 ) ;
  }

  @Test
  public void test3826() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-47.357642918170356,-22.017091997156257 ) ;
  }

  @Test
  public void test3827() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-47.40693094135333,-100.0 ) ;
  }

  @Test
  public void test3828() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-47.41034775960958,56.125301621074996 ) ;
  }

  @Test
  public void test3829() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-4.799029804466019E-240,98.78000313886106 ) ;
  }

  @Test
  public void test3830() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-48.16035308905471,0.020742694888759086 ) ;
  }

  @Test
  public void test3831() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-48.319096167109144,-1.5707963267948966 ) ;
  }

  @Test
  public void test3832() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-48.51989216782584,88.11766810464664 ) ;
  }

  @Test
  public void test3833() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-48.59811416479289,1.5707963267948966 ) ;
  }

  @Test
  public void test3834() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-48.61318703090838,15.081660158495524 ) ;
  }

  @Test
  public void test3835() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-48.64073086349266,1.5883381936131968 ) ;
  }

  @Test
  public void test3836() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-53.43555370179709,-90.04185182249185 ) ;
  }

  @Test
  public void test3837() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-53.52340908456108,1.570796326794893 ) ;
  }

  @Test
  public void test3838() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-54.42761076885846,-60.105787246349855 ) ;
  }

  @Test
  public void test3839() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-54.64615082828286,-17.227520844787918 ) ;
  }

  @Test
  public void test3840() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-54.74304002586999,1.5707963267948912 ) ;
  }

  @Test
  public void test3841() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-5.475650469597468E-16,-5.544638698709775 ) ;
  }

  @Test
  public void test3842() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-54.92775769751985,-89.7453429380425 ) ;
  }

  @Test
  public void test3843() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-59.74368416155975,-1.5707963267948968 ) ;
  }

  @Test
  public void test3844() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-60.81221377990593,90.10376170940184 ) ;
  }

  @Test
  public void test3845() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-61.09308390607489,1.5707963267948963 ) ;
  }

  @Test
  public void test3846() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,6.4292096573591175,-1.5707963267948966 ) ;
  }

  @Test
  public void test3847() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-66.32392214628076,-0.08518223233317315 ) ;
  }

  @Test
  public void test3848() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-66.39320217119973,2442.735801045127 ) ;
  }

  @Test
  public void test3849() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-66.39709590824019,100.0 ) ;
  }

  @Test
  public void test3850() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-66.41766796993204,3.143545780386799 ) ;
  }

  @Test
  public void test3851() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-66.65066831431986,43.98254591528547 ) ;
  }

  @Test
  public void test3852() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-66.72386799930237,129.04573535499281 ) ;
  }

  @Test
  public void test3853() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-66.80168600664385,95.44388838945036 ) ;
  }

  @Test
  public void test3854() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-7.105427357601002E-15,-44.58924519645828 ) ;
  }

  @Test
  public void test3855() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-72.4177653494087,-1.5707963267949054 ) ;
  }

  @Test
  public void test3856() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-72.41782978523517,1.5707963267948983 ) ;
  }

  @Test
  public void test3857() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-72.85490067848733,10.21915085444195 ) ;
  }

  @Test
  public void test3858() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-76.02032869644371,77.03904490549075 ) ;
  }

  @Test
  public void test3859() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-78.78380844498338,-134.19988274008614 ) ;
  }

  @Test
  public void test3860() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-78.86253352792787,66.3591887640514 ) ;
  }

  @Test
  public void test3861() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-84.90625600484407,-32.7652807655916 ) ;
  }

  @Test
  public void test3862() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-8.881784197001252E-16,76.96902001294994 ) ;
  }

  @Test
  public void test3863() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-9.529246624089097,-61.92010571870843 ) ;
  }

  @Test
  public void test3864() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-9.552307655266166,-100.0 ) ;
  }

  @Test
  public void test3865() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-9.622236904971281,1.5707963267948966 ) ;
  }

  @Test
  public void test3866() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-97.7914839642623,-32.08833063284251 ) ;
  }

  @Test
  public void test3867() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-97.88923293133195,-28.771741123773317 ) ;
  }

  @Test
  public void test3868() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-97.94156373377453,-89.53539062730911 ) ;
  }

  @Test
  public void test3869() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-98.07181340951188,-32.25664026871202 ) ;
  }

  @Test
  public void test3870() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-98.4683987412889,55.41800865254365 ) ;
  }

  @Test
  public void test3871() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-9.983971212350665,-14.614233814068527 ) ;
  }

  @Test
  public void test3872() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948917,-1.5707963267948966,1.5707963267948948 ) ;
  }

  @Test
  public void test3873() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948917,-1.5707963267948966,-36.011395312973924 ) ;
  }

  @Test
  public void test3874() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948917,-1.5707963267948966,-42.75235591611991 ) ;
  }

  @Test
  public void test3875() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794892,-0.29345898346036,39.58561099649898 ) ;
  }

  @Test
  public void test3876() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948921,-1.5707963267948912,-21.983719501858857 ) ;
  }

  @Test
  public void test3877() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948921,-3.266592654254427,0.0 ) ;
  }

  @Test
  public void test3878() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948921,-3.552713678800501E-15,34.55751918948773 ) ;
  }

  @Test
  public void test3879() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948928,-0.10744002603539637,0.0 ) ;
  }

  @Test
  public void test3880() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794893,-1.5440636081836914,49.73281754949693 ) ;
  }

  @Test
  public void test3881() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794893,-1.5705582024487865,-1.5793650827938261E-176 ) ;
  }

  @Test
  public void test3882() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794893,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3883() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794893,-1.5707963267948966,43.49117738194985 ) ;
  }

  @Test
  public void test3884() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794893,-161.59218856517012,-39.85076651664558 ) ;
  }

  @Test
  public void test3885() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794893,-35.463611545661614,14.258300672878612 ) ;
  }

  @Test
  public void test3886() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794893,-35.7427129714367,4.700326741341943 ) ;
  }

  @Test
  public void test3887() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794893,-45.88308252845361,0 ) ;
  }

  @Test
  public void test3888() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794893,-66.31714293860486,8.881784197001252E-16 ) ;
  }

  @Test
  public void test3889() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794893,-66.68811452546103,-63.629332868854945 ) ;
  }

  @Test
  public void test3890() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948937,-1.5707963267948966,26.719739486129086 ) ;
  }

  @Test
  public void test3891() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794893,-72.99500576550128,-47.406386650608276 ) ;
  }

  @Test
  public void test3892() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794893,-78.55768935104504,26.900873111699873 ) ;
  }

  @Test
  public void test3893() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794894,-0.8285500270419428,40.19397629772962 ) ;
  }

  @Test
  public void test3894() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794894,-0.980193039785012,-50.60161512202568 ) ;
  }

  @Test
  public void test3895() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948941,-0.09310297730522502,-1.5707963267949054 ) ;
  }

  @Test
  public void test3896() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948941,-10.424777960645866,9.43234197362027 ) ;
  }

  @Test
  public void test3897() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948941,-1.5707963267948963,1.5707963267948952 ) ;
  }

  @Test
  public void test3898() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948943,-1.5707963267948926,78.53981633948474 ) ;
  }

  @Test
  public void test3899() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948943,-1.5707963267948966,-27.32386266434399 ) ;
  }

  @Test
  public void test3900() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948946,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3901() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,0.0,0 ) ;
  }

  @Test
  public void test3902() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-0.006208382215811865,-1.5423487136658458E-179 ) ;
  }

  @Test
  public void test3903() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-0.016442096987400845,-1.5707963267948966 ) ;
  }

  @Test
  public void test3904() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-0.04769126424051251,0.0 ) ;
  }

  @Test
  public void test3905() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-0.06648393228226836,31.415926535897945 ) ;
  }

  @Test
  public void test3906() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-0.07536994100972831,-42.87260177711452 ) ;
  }

  @Test
  public void test3907() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-0.09150132961361626,-1.5707963267948983 ) ;
  }

  @Test
  public void test3908() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-0.15416300499802088,55.010351159822555 ) ;
  }

  @Test
  public void test3909() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-0.23158830885553527,-15.780054954633256 ) ;
  }

  @Test
  public void test3910() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-0.3917574896941687,14.137289011466644 ) ;
  }

  @Test
  public void test3911() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-0.4244227109097808,-117.87092987577006 ) ;
  }

  @Test
  public void test3912() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-0.5016701551908085,553.3757941305995 ) ;
  }

  @Test
  public void test3913() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-0.5957436193298865,-35.11010839053883 ) ;
  }

  @Test
  public void test3914() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-0.6427367920768068,-60.723032758008806 ) ;
  }

  @Test
  public void test3915() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-0.6666588743935193,-63.643170654047346 ) ;
  }

  @Test
  public void test3916() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-0.7155784937430967,7.853982048391284 ) ;
  }

  @Test
  public void test3917() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-0.9961362714336166,-77.16515474897757 ) ;
  }

  @Test
  public void test3918() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-10.169826345133803,-39.12334100828196 ) ;
  }

  @Test
  public void test3919() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.078107406066217,1.5707962974772718 ) ;
  }

  @Test
  public void test3920() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.184977319428041,3.1415926561253276 ) ;
  }

  @Test
  public void test3921() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.2170783905581968,-56.35090174240074 ) ;
  }

  @Test
  public void test3922() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.2432677923130673,-1.5707963267948963 ) ;
  }

  @Test
  public void test3923() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.2484422676897646,20.56434352351792 ) ;
  }

  @Test
  public void test3924() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.3325653959694321,55.51403033753762 ) ;
  }

  @Test
  public void test3925() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.3640470998380383,86.32950579900577 ) ;
  }

  @Test
  public void test3926() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.516704028149591,384.76788796425586 ) ;
  }

  @Test
  public void test3927() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948735,0.0 ) ;
  }

  @Test
  public void test3928() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948912,52.7387696269638 ) ;
  }

  @Test
  public void test3929() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948912,-55.46167625177338 ) ;
  }

  @Test
  public void test3930() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948912,-8.227402818403146 ) ;
  }

  @Test
  public void test3931() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948937,33.25308317088974 ) ;
  }

  @Test
  public void test3932() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948946,-5.014396691057485 ) ;
  }

  @Test
  public void test3933() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948948,2.0279036963002994 ) ;
  }

  @Test
  public void test3934() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948948,26.843151732916937 ) ;
  }

  @Test
  public void test3935() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948961,1.5707963267948966 ) ;
  }

  @Test
  public void test3936() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948963,34.37036744848348 ) ;
  }

  @Test
  public void test3937() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3938() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,-10.069586595128825 ) ;
  }

  @Test
  public void test3939() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,1.570796326794893 ) ;
  }

  @Test
  public void test3940() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3941() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3942() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,1.6330581809250333 ) ;
  }

  @Test
  public void test3943() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,-17.355162369062086 ) ;
  }

  @Test
  public void test3944() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,-21.11342334657695 ) ;
  }

  @Test
  public void test3945() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,2283.360091670973 ) ;
  }

  @Test
  public void test3946() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,-28.468732450695256 ) ;
  }

  @Test
  public void test3947() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,-37.598654822982226 ) ;
  }

  @Test
  public void test3948() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,-41.01320922078615 ) ;
  }

  @Test
  public void test3949() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,-54.075381889095375 ) ;
  }

  @Test
  public void test3950() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,-56.86115226271741 ) ;
  }

  @Test
  public void test3951() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,-57.922197093778706 ) ;
  }

  @Test
  public void test3952() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,-63.245044434425026 ) ;
  }

  @Test
  public void test3953() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,-66.47636494363158 ) ;
  }

  @Test
  public void test3954() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,87.98106607557565 ) ;
  }

  @Test
  public void test3955() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,-91.12542661437406 ) ;
  }

  @Test
  public void test3956() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,9.587522870912053 ) ;
  }

  @Test
  public void test3957() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,97.75568442712063 ) ;
  }

  @Test
  public void test3958() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948983,1.5707963267948961 ) ;
  }

  @Test
  public void test3959() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948983,-42.04668474240001 ) ;
  }

  @Test
  public void test3960() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-16.170556150314304,77.07468222254985 ) ;
  }

  @Test
  public void test3961() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-174.01896875851114,-87.4692043596484 ) ;
  }

  @Test
  public void test3962() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-17.846949631649693,-4.947415932479473 ) ;
  }

  @Test
  public void test3963() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-19.473126395524492,0 ) ;
  }

  @Test
  public void test3964() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-2.220446049250313E-16,0.0 ) ;
  }

  @Test
  public void test3965() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-22.248507951680878,1.1704190886730496E-97 ) ;
  }

  @Test
  public void test3966() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-22.922992511875897,0 ) ;
  }

  @Test
  public void test3967() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,2.3766137780566314E-16,-1.5707963267948966 ) ;
  }

  @Test
  public void test3968() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-28.38666509668284,2.666266664739169 ) ;
  }

  @Test
  public void test3969() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-35.13222521291232,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test3970() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-35.164997198831756,-48.344251267985356 ) ;
  }

  @Test
  public void test3971() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-3.5284059965806165,4.141594635458466 ) ;
  }

  @Test
  public void test3972() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-35.45478479482802,-31.826780849938196 ) ;
  }

  @Test
  public void test3973() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-3.552713678800501E-15,0.0 ) ;
  }

  @Test
  public void test3974() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-35.564146115836195,-12.950610707196294 ) ;
  }

  @Test
  public void test3975() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-35.85701745913951,-1.5707963267949054 ) ;
  }

  @Test
  public void test3976() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-35.974104277697805,-34.56756474350695 ) ;
  }

  @Test
  public void test3977() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-36.01138861976365,1.5707963267948912 ) ;
  }

  @Test
  public void test3978() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-36.0672629486539,0.0 ) ;
  }

  @Test
  public void test3979() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-3.7577680588047286,-90.65299245768881 ) ;
  }

  @Test
  public void test3980() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-3.975282607641855,-100.0 ) ;
  }

  @Test
  public void test3981() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-41.33283539519114,0 ) ;
  }

  @Test
  public void test3982() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,4.141592653597309,-21.953941608381484 ) ;
  }

  @Test
  public void test3983() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-41.44028499132659,-89.91322022539747 ) ;
  }

  @Test
  public void test3984() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-47.12388980385418,-1.5707963267948966 ) ;
  }

  @Test
  public void test3985() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-47.28631623090479,36.109128636259726 ) ;
  }

  @Test
  public void test3986() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-47.38375405535777,12.576073716519852 ) ;
  }

  @Test
  public void test3987() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-47.45567241239175,90.5803034899918 ) ;
  }

  @Test
  public void test3988() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-48.259836106169665,-33.32526226177928 ) ;
  }

  @Test
  public void test3989() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-48.572072410414776,76.90557727693829 ) ;
  }

  @Test
  public void test3990() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-538.3778459154183,0.0 ) ;
  }

  @Test
  public void test3991() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-54.33589290414558,0 ) ;
  }

  @Test
  public void test3992() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-54.62666393860512,-16.64464561569162 ) ;
  }

  @Test
  public void test3993() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-54.91166862606769,-57.82386761510096 ) ;
  }

  @Test
  public void test3994() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-60.72387207975585,-6.28709316321496 ) ;
  }

  @Test
  public void test3995() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-60.85495796635796,71.04646396157332 ) ;
  }

  @Test
  public void test3996() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-61.01503065660875,123.59339676604267 ) ;
  }

  @Test
  public void test3997() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-66.81142844277042,1.5707963267948963 ) ;
  }

  @Test
  public void test3998() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-72.44392987882861,2.465190328815662E-32 ) ;
  }

  @Test
  public void test3999() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-78.57716356548178,1.5707963267948966 ) ;
  }

  @Test
  public void test4000() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-78.7727871824137,-38.451738412398015 ) ;
  }

  @Test
  public void test4001() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-78.92582873408568,1.5707963267948966 ) ;
  }

  @Test
  public void test4002() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-84.89776595911667,-1.5707963267948948 ) ;
  }

  @Test
  public void test4003() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-8.881784197001252E-16,-83.46405130868752 ) ;
  }

  @Test
  public void test4004() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-98.13948044306946,-77.22532625553782 ) ;
  }

  @Test
  public void test4005() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-9.940808411943005,-16.73349720735588 ) ;
  }

  @Test
  public void test4006() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-9.965624640664055,-4.712388993806944 ) ;
  }

  @Test
  public void test4007() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-9.99082655096801,56.18700270066841 ) ;
  }

  @Test
  public void test4008() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794895,-1.2964642210884294,100.0 ) ;
  }

  @Test
  public void test4009() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948952,-0.3022076306108732,79.30763185310528 ) ;
  }

  @Test
  public void test4010() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948952,-10.001314776173317,-39.06764318260994 ) ;
  }

  @Test
  public void test4011() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948952,-1.4382959175468235,13.17670797361973 ) ;
  }

  @Test
  public void test4012() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948952,-41.417255152294445,739.0576941644885 ) ;
  }

  @Test
  public void test4013() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948952,-42.38209854537065,-1.5707963267948966 ) ;
  }

  @Test
  public void test4014() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948954,-1.5707963267948957,48.46273166563707 ) ;
  }

  @Test
  public void test4015() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948954,-1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test4016() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948954,-1.5707963267948966,88.05670087897344 ) ;
  }

  @Test
  public void test4017() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948954,-66.61275061088233,26.542184948422552 ) ;
  }

  @Test
  public void test4018() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,0,0 ) ;
  }

  @Test
  public void test4019() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-0.07158695754992823,1.5707963267948966 ) ;
  }

  @Test
  public void test4020() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-0.09274967054960134,85.01275830149822 ) ;
  }

  @Test
  public void test4021() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,0.10640198497732513,51.97567370483605 ) ;
  }

  @Test
  public void test4022() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-0.11675252680828399,-40.163502039735306 ) ;
  }

  @Test
  public void test4023() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-0.3383436180469861,-57.28334145123671 ) ;
  }

  @Test
  public void test4024() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-0.4103891429107165,-6.2833074679482115 ) ;
  }

  @Test
  public void test4025() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-0.43180012400467005,27.189981501303013 ) ;
  }

  @Test
  public void test4026() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-0.4325881274878469,86.36594804750216 ) ;
  }

  @Test
  public void test4027() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-0.5126837868627786,-1.5521709576104694 ) ;
  }

  @Test
  public void test4028() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-0.59824830501723,-94.24777960769386 ) ;
  }

  @Test
  public void test4029() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-0.6930951741277482,0.0 ) ;
  }

  @Test
  public void test4030() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-0.7375800343449468,-11.784766037962498 ) ;
  }

  @Test
  public void test4031() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-0.7890368263349039,-36.21312490625685 ) ;
  }

  @Test
  public void test4032() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-0.8702694222078001,28.12332826030098 ) ;
  }

  @Test
  public void test4033() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-10.008817399960606,0.34743604443423515 ) ;
  }

  @Test
  public void test4034() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.071627407129005,-15.77724878255202 ) ;
  }

  @Test
  public void test4035() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.2816572625693614,2.2762042923324875E-114 ) ;
  }

  @Test
  public void test4036() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.302356894189714,34.758665963432705 ) ;
  }

  @Test
  public void test4037() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.5707963267948912,-34.50243624482954 ) ;
  }

  @Test
  public void test4038() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.5707963267948912,4.836889482983217 ) ;
  }

  @Test
  public void test4039() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.5707963267948912,-64.93449143103285 ) ;
  }

  @Test
  public void test4040() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.5707963267948948,-20.310151684865744 ) ;
  }

  @Test
  public void test4041() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.5707963267948948,55.149664388493356 ) ;
  }

  @Test
  public void test4042() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test4043() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.5707963267948966,-0.19002757224078143 ) ;
  }

  @Test
  public void test4044() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.5707963267948966,-1.5707963267948912 ) ;
  }

  @Test
  public void test4045() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test4046() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.5707963267948966,-22.428353055100303 ) ;
  }

  @Test
  public void test4047() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.5707963267948966,-2.4677579418653533E-178 ) ;
  }

  @Test
  public void test4048() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.5707963267948966,3.164652555508167 ) ;
  }

  @Test
  public void test4049() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.5707963267948966,4.712390105239297 ) ;
  }

  @Test
  public void test4050() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.5707963267948966,5.14159265359107 ) ;
  }

  @Test
  public void test4051() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.5707963267948966,-6.041389012600919 ) ;
  }

  @Test
  public void test4052() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.5707963267948966,-66.69426678537378 ) ;
  }

  @Test
  public void test4053() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.5707963267948966,79.68114994414405 ) ;
  }

  @Test
  public void test4054() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-217.25892098707814,-84.89330688287409 ) ;
  }

  @Test
  public void test4055() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-22.360055713504508,49.75231854484957 ) ;
  }

  @Test
  public void test4056() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-22.391909083416092,96.16739948332969 ) ;
  }

  @Test
  public void test4057() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-34.59590811427024,-2.4514360454994402E-15 ) ;
  }

  @Test
  public void test4058() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-4.010998046604591,-141.43598829088916 ) ;
  }

  @Test
  public void test4059() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-41.60122290693889,0.0 ) ;
  }

  @Test
  public void test4060() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-41.910693964256524,-1.5707963267948966 ) ;
  }

  @Test
  public void test4061() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-42.16074598700463,0.0 ) ;
  }

  @Test
  public void test4062() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-486.95614167080623,-7.65116390719615 ) ;
  }

  @Test
  public void test4063() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-60.92495652189966,88.09335848666176 ) ;
  }

  @Test
  public void test4064() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-72.93856437083184,44.43754552758931 ) ;
  }

  @Test
  public void test4065() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-78.87963830550947,44.936690370805046 ) ;
  }

  @Test
  public void test4066() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-98.21632148889714,0.0027088501488262196 ) ;
  }

  @Test
  public void test4067() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-98.26615260257681,73.46650442863313 ) ;
  }

  @Test
  public void test4068() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794896,-0.6962737394286572,56.57991776467122 ) ;
  }

  @Test
  public void test4069() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-0.03274812338170019,3.4617901138453817 ) ;
  }

  @Test
  public void test4070() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-0.04058051080257968,-69.82954491310306 ) ;
  }

  @Test
  public void test4071() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-0.06447108304123293,19.84855887006631 ) ;
  }

  @Test
  public void test4072() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-0.07040056350379369,-0.017877932136209918 ) ;
  }

  @Test
  public void test4073() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794896,-1.0267020282309143,12.56637065534693 ) ;
  }

  @Test
  public void test4074() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,0.378576159521954,-12.808776027137409 ) ;
  }

  @Test
  public void test4075() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-0.4357981882569246,22.823426049507937 ) ;
  }

  @Test
  public void test4076() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-0.6227491152215263,-87.47729093988814 ) ;
  }

  @Test
  public void test4077() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-0.7893470327693811,9.424778107104324 ) ;
  }

  @Test
  public void test4078() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-0.8931720595075063,112.81938330209343 ) ;
  }

  @Test
  public void test4079() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.008348515740699,2.4614101520756915 ) ;
  }

  @Test
  public void test4080() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.3174721136637786,-39.376538909026436 ) ;
  }

  @Test
  public void test4081() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.4034365277157974,1.5707963267948948 ) ;
  }

  @Test
  public void test4082() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.4710959993144839,39.68361890930543 ) ;
  }

  @Test
  public void test4083() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.4947318368618614,-69.7627375002591 ) ;
  }

  @Test
  public void test4084() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.5631189016613165,-44.556428299463036 ) ;
  }

  @Test
  public void test4085() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.5707963267948912,-51.394509587677554 ) ;
  }

  @Test
  public void test4086() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test4087() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.5707963267948966,-1.513326078477201 ) ;
  }

  @Test
  public void test4088() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.5707963267948966,-1.557374211108995E-207 ) ;
  }

  @Test
  public void test4089() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.5707963267948966,15.58839129611254 ) ;
  }

  @Test
  public void test4090() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.5707963267948966,18.88196499873522 ) ;
  }

  @Test
  public void test4091() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.5707963267948966,-20.727517803448144 ) ;
  }

  @Test
  public void test4092() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.5707963267948966,-29.884019476398088 ) ;
  }

  @Test
  public void test4093() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.5707963267948966,37.714736843077524 ) ;
  }

  @Test
  public void test4094() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.5707963267948966,-4.712389010530933 ) ;
  }

  @Test
  public void test4095() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.5707963267948966,75.02314461103656 ) ;
  }

  @Test
  public void test4096() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.5707963267948968,-44.38399585985745 ) ;
  }

  @Test
  public void test4097() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.5707963267948983,0.2888368922170822 ) ;
  }

  @Test
  public void test4098() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.5707963268055678,5.512906042744091E-16 ) ;
  }

  @Test
  public void test4099() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.7763568394002505E-15,1.5707963267948966 ) ;
  }

  @Test
  public void test4100() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-4.71238898038469,0 ) ;
  }

  @Test
  public void test4101() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794896,-1.5707963267948966,-1.5707963267948912 ) ;
  }

  @Test
  public void test4102() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794896,-1.5707963267948966,79.8481293716907 ) ;
  }

  @Test
  public void test4103() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794896,-1.5707963267948966,8.853820537263598 ) ;
  }

  @Test
  public void test4104() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-66.2613775827125,-12.616237905019824 ) ;
  }

  @Test
  public void test4105() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-66.29936576407087,2.91761848138521E-4 ) ;
  }

  @Test
  public void test4106() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-84.85111435910623,-75.5132664686592 ) ;
  }

  @Test
  public void test4107() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-97.71001859002462,77.11029517660998 ) ;
  }

  @Test
  public void test4108() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-98.7616180360888,95.59918870682523 ) ;
  }

  @Test
  public void test4109() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.005630401179061396,-54.98342781064036 ) ;
  }

  @Test
  public void test4110() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.07825585016793224,3.373015891268975E-15 ) ;
  }

  @Test
  public void test4111() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.10355386225586849,1.5707963266853069 ) ;
  }

  @Test
  public void test4112() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.17169498852528045,0.0 ) ;
  }

  @Test
  public void test4113() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.17393816086707412,43.01440858578292 ) ;
  }

  @Test
  public void test4114() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.1760140495200868,-13.577775113450464 ) ;
  }

  @Test
  public void test4115() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.23460567801039273,-0.3864828476035108 ) ;
  }

  @Test
  public void test4116() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.2829255576618737,20.420352248333657 ) ;
  }

  @Test
  public void test4117() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.30995344266838626,26.90755976183459 ) ;
  }

  @Test
  public void test4118() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.3298023078253974,-48.279232162716625 ) ;
  }

  @Test
  public void test4119() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.3529261795519876,-1.5707963267948963 ) ;
  }

  @Test
  public void test4120() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.3812404260017376,-29.83393468963385 ) ;
  }

  @Test
  public void test4121() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.40645589685620737,9.174949606305633 ) ;
  }

  @Test
  public void test4122() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.43802928496194504,1.5707963267948948 ) ;
  }

  @Test
  public void test4123() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.4486874450934568,-89.6374876595376 ) ;
  }

  @Test
  public void test4124() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.5621729034529864,-0.04683733146401359 ) ;
  }

  @Test
  public void test4125() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.6392746462227767,-25.163613175116705 ) ;
  }

  @Test
  public void test4126() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.6658351207284987,10.080397588646889 ) ;
  }

  @Test
  public void test4127() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.7664587901124619,-54.48757610844639 ) ;
  }

  @Test
  public void test4128() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.9444852209920185,4.712407800530491 ) ;
  }

  @Test
  public void test4129() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.9919205275897677,-1.5707963268733385 ) ;
  }

  @Test
  public void test4130() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-10.10275581050579,-100.0 ) ;
  }

  @Test
  public void test4131() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.0139303162731161,-8.103981753364028 ) ;
  }

  @Test
  public void test4132() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.0221767186287918,0.0 ) ;
  }

  @Test
  public void test4133() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.0491717191223482,2.710505431213761E-20 ) ;
  }

  @Test
  public void test4134() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.0587911840678754E-22,39.531949866290944 ) ;
  }

  @Test
  public void test4135() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.1390078450352796,-71.37117365463371 ) ;
  }

  @Test
  public void test4136() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.139441678631656,0.0 ) ;
  }

  @Test
  public void test4137() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.1403928092898485,37.73495248877902 ) ;
  }

  @Test
  public void test4138() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.2098169861527357,-28.659278669149572 ) ;
  }

  @Test
  public void test4139() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.2172350417331472,29.567846266623064 ) ;
  }

  @Test
  public void test4140() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.2210951388359086,-26.56088828298425 ) ;
  }

  @Test
  public void test4141() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-122.66289005513858,97.89565554159957 ) ;
  }

  @Test
  public void test4142() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,1.246048590948386,-61.00679079825761 ) ;
  }

  @Test
  public void test4143() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.2881604093787857,56.288923128975426 ) ;
  }

  @Test
  public void test4144() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.3583516482521731,-12.566378254498597 ) ;
  }

  @Test
  public void test4145() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.3587675025927097,0.0 ) ;
  }

  @Test
  public void test4146() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.4058416906953937,11.607214666322273 ) ;
  }

  @Test
  public void test4147() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.4715110278302705,-24.765846703391148 ) ;
  }

  @Test
  public void test4148() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.480664474748269,-59.49535482349406 ) ;
  }

  @Test
  public void test4149() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.4943126544120027,-41.57616370980245 ) ;
  }

  @Test
  public void test4150() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5444728620609516,-89.8084647671291 ) ;
  }

  @Test
  public void test4151() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5528145862079383,-19.421425078894067 ) ;
  }

  @Test
  public void test4152() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5546832352403435,43.016025051629114 ) ;
  }

  @Test
  public void test4153() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5656615831306901,-0.2737955687852011 ) ;
  }

  @Test
  public void test4154() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963262512996,70.4417113911395 ) ;
  }

  @Test
  public void test4155() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948912,-11.025442531678607 ) ;
  }

  @Test
  public void test4156() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948948,-62.27514918174272 ) ;
  }

  @Test
  public void test4157() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948948,-77.3306649045818 ) ;
  }

  @Test
  public void test4158() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948948,88.93595889187898 ) ;
  }

  @Test
  public void test4159() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948954,79.63642708675835 ) ;
  }

  @Test
  public void test4160() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948957,1.5707963267948966 ) ;
  }

  @Test
  public void test4161() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948963,83.82766353720487 ) ;
  }

  @Test
  public void test4162() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test4163() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,-0.42407706788159416 ) ;
  }

  @Test
  public void test4164() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,-0.8455597247624987 ) ;
  }

  @Test
  public void test4165() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test4166() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,-12.018968565179884 ) ;
  }

  @Test
  public void test4167() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,-12.566492844808318 ) ;
  }

  @Test
  public void test4168() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,-15.12147450001871 ) ;
  }

  @Test
  public void test4169() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,1.5707963267948926 ) ;
  }

  @Test
  public void test4170() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,1.5707963267948948 ) ;
  }

  @Test
  public void test4171() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,-1.5707963267948957 ) ;
  }

  @Test
  public void test4172() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test4173() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,2.220446049250313E-16 ) ;
  }

  @Test
  public void test4174() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,26.803726108597786 ) ;
  }

  @Test
  public void test4175() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,28.279244259498206 ) ;
  }

  @Test
  public void test4176() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,-29.027104934869616 ) ;
  }

  @Test
  public void test4177() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,-3.1583907061420544 ) ;
  }

  @Test
  public void test4178() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,34.557520516632586 ) ;
  }

  @Test
  public void test4179() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,38.12011960416365 ) ;
  }

  @Test
  public void test4180() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,4.038342281856002 ) ;
  }

  @Test
  public void test4181() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,-48.204870267217366 ) ;
  }

  @Test
  public void test4182() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,52.99807378307749 ) ;
  }

  @Test
  public void test4183() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,-55.35768652351885 ) ;
  }

  @Test
  public void test4184() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,60.97572365495028 ) ;
  }

  @Test
  public void test4185() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,-61.19838228388382 ) ;
  }

  @Test
  public void test4186() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,-77.60166311927338 ) ;
  }

  @Test
  public void test4187() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,-80.32325758925771 ) ;
  }

  @Test
  public void test4188() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,-8.103983772747243 ) ;
  }

  @Test
  public void test4189() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,84.12630988435043 ) ;
  }

  @Test
  public void test4190() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,90.0018834249276 ) ;
  }

  @Test
  public void test4191() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,-92.2279348102987 ) ;
  }

  @Test
  public void test4192() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,9.295424329183133 ) ;
  }

  @Test
  public void test4193() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,-93.84351910460093 ) ;
  }

  @Test
  public void test4194() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948972,8.1039818442201 ) ;
  }

  @Test
  public void test4195() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,28.703537555541264,0.0 ) ;
  }

  @Test
  public void test4196() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-3.141592654607075,89.83247632114148 ) ;
  }

  @Test
  public void test4197() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-3.1415926684917324,100.0 ) ;
  }

  @Test
  public void test4198() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-3.273451010087026,-2248.104988579574 ) ;
  }

  @Test
  public void test4199() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-3.3176637247339897,91.4901582899861 ) ;
  }

  @Test
  public void test4200() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794896,-3.3371611212502614,89.57705518947132 ) ;
  }

  @Test
  public void test4201() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-3.3920745164867974,31.421018190442634 ) ;
  }

  @Test
  public void test4202() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-34.64627645499764,-82.45124220418056 ) ;
  }

  @Test
  public void test4203() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-34.64656330835784,-6.284469535803936 ) ;
  }

  @Test
  public void test4204() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-35.4339616897207,-80.92299568677255 ) ;
  }

  @Test
  public void test4205() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-35.693462311219506,-1.2064913217589475 ) ;
  }

  @Test
  public void test4206() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-35.76111708937059,3.283629441038701E-288 ) ;
  }

  @Test
  public void test4207() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-35.850343488279655,-31.57703713922419 ) ;
  }

  @Test
  public void test4208() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-35.93990506686115,-77.061282940621 ) ;
  }

  @Test
  public void test4209() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-36.04957032574951,0.0 ) ;
  }

  @Test
  public void test4210() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-3.7730648218010043,-39.09763193831244 ) ;
  }

  @Test
  public void test4211() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-40.892317345377776,97.18095950913634 ) ;
  }

  @Test
  public void test4212() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-525.6901413001781,-1.5707963267949054 ) ;
  }

  @Test
  public void test4213() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-53.52026934467021,-27.75943654626178 ) ;
  }

  @Test
  public void test4214() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-54.43286634570018,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test4215() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-54.707371002335215,1.5707963267948983 ) ;
  }

  @Test
  public void test4216() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-54.7371875612357,3.1415926536008048 ) ;
  }

  @Test
  public void test4217() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-59.72220124140755,1.5707963267948966 ) ;
  }

  @Test
  public void test4218() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-60.805434139157036,77.16297502501175 ) ;
  }

  @Test
  public void test4219() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-60.957411159767375,-90.58801076791654 ) ;
  }

  @Test
  public void test4220() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-72.86596008742393,23.53719255361068 ) ;
  }

  @Test
  public void test4221() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-73.22387767458179,48.26882986475468 ) ;
  }

  @Test
  public void test4222() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-78.6008560473438,1.5707963267948966 ) ;
  }

  @Test
  public void test4223() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-9.625457578083232,29.89758907942192 ) ;
  }

  @Test
  public void test4224() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-97.90023503911303,47.74238627478718 ) ;
  }

  @Test
  public void test4225() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-97.90626948785649,-90.8831171923762 ) ;
  }

  @Test
  public void test4226() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-98.07402934272623,45.74231372340526 ) ;
  }

  @Test
  public void test4227() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-98.530203165322,44.24056362737312 ) ;
  }

  @Test
  public void test4228() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-98.68281539664302,0.4704561832711569 ) ;
  }

  @Test
  public void test4229() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,99.48372345214696,0 ) ;
  }

  @Test
  public void test4230() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test4231() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948968,-0.28848716675138075,-1.5707963267948966 ) ;
  }

  @Test
  public void test4232() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794896,-98.57998973893723,88.8503098218998 ) ;
  }

  @Test
  public void test4233() {
    coral.tests.JPFBenchmark.benchmark05(-1.571300011046485E-15,5.551115123125783E-17,40.98827144889333 ) ;
  }

  @Test
  public void test4234() {
    coral.tests.JPFBenchmark.benchmark05(-1.5777218104420236E-30,-1.5707963267948966,112.91256709830034 ) ;
  }

  @Test
  public void test4235() {
    coral.tests.JPFBenchmark.benchmark05(15.882973817068958,7.469959751377829,39.50479204712431 ) ;
  }

  @Test
  public void test4236() {
    coral.tests.JPFBenchmark.benchmark05(-1.5883476172088962,-59.24505994596543,-29.055069751422494 ) ;
  }

  @Test
  public void test4237() {
    coral.tests.JPFBenchmark.benchmark05(-1.5947907276077816E-15,-1.5707963267948966,-0.9790021341723047 ) ;
  }

  @Test
  public void test4238() {
    coral.tests.JPFBenchmark.benchmark05(-1.5994702856421299E-15,-1.4687629351572817,-18.634563843144463 ) ;
  }

  @Test
  public void test4239() {
    coral.tests.JPFBenchmark.benchmark05(16.001088700440505,-91.73218113437991,23.91836178972406 ) ;
  }

  @Test
  public void test4240() {
    coral.tests.JPFBenchmark.benchmark05(16.035065653964992,-71.62795741417804,31.999132465034563 ) ;
  }

  @Test
  public void test4241() {
    coral.tests.JPFBenchmark.benchmark05(-1.607546075116224E-14,-1.5707963267948966,10.932183178323383 ) ;
  }

  @Test
  public void test4242() {
    coral.tests.JPFBenchmark.benchmark05(-1.6242827758820155E-114,-66.39157320377132,-77.21649013375928 ) ;
  }

  @Test
  public void test4243() {
    coral.tests.JPFBenchmark.benchmark05(16.258372374188596,-89.28630480083137,39.12459866797866 ) ;
  }

  @Test
  public void test4244() {
    coral.tests.JPFBenchmark.benchmark05(1.6284550262326147,-3.582510730783255E-5,-67.30735599820478 ) ;
  }

  @Test
  public void test4245() {
    coral.tests.JPFBenchmark.benchmark05(-1.6316774136713537E-18,-1.5707963267948963,0.5686017082115798 ) ;
  }

  @Test
  public void test4246() {
    coral.tests.JPFBenchmark.benchmark05(-1.632089824507786E-11,-1.5707963267948966,-1.167004225332393 ) ;
  }

  @Test
  public void test4247() {
    coral.tests.JPFBenchmark.benchmark05(16.357502444725498,61.814683188803315,-58.52813444649778 ) ;
  }

  @Test
  public void test4248() {
    coral.tests.JPFBenchmark.benchmark05(16.465754923513828,-21.078462120390483,50.620801104549116 ) ;
  }

  @Test
  public void test4249() {
    coral.tests.JPFBenchmark.benchmark05(-1.6472184286297693E-83,-16.102773154627464,-8.920670221914316 ) ;
  }

  @Test
  public void test4250() {
    coral.tests.JPFBenchmark.benchmark05(1.6542335692801309,1.3234889800848443E-23,-59.6716220477528 ) ;
  }

  @Test
  public void test4251() {
    coral.tests.JPFBenchmark.benchmark05(-1.6543612251060553E-24,-1.5707963267948966,14.139589564793189 ) ;
  }

  @Test
  public void test4252() {
    coral.tests.JPFBenchmark.benchmark05(-16.627358315417922,71.93644728600174,85.40467607275261 ) ;
  }

  @Test
  public void test4253() {
    coral.tests.JPFBenchmark.benchmark05(16.671460289778352,-60.76703220362669,-10.070896681045085 ) ;
  }

  @Test
  public void test4254() {
    coral.tests.JPFBenchmark.benchmark05(-1.6736689352203192E-15,-1.5707963267948966,-53.890234949963656 ) ;
  }

  @Test
  public void test4255() {
    coral.tests.JPFBenchmark.benchmark05(-1.6789713086523465E-14,-1.5707963267948966,65.28676282970964 ) ;
  }

  @Test
  public void test4256() {
    coral.tests.JPFBenchmark.benchmark05(16.806727412800868,-88.51143426988426,-36.624544698496145 ) ;
  }

  @Test
  public void test4257() {
    coral.tests.JPFBenchmark.benchmark05(-1.6940658945086007E-21,-1.0657600996623338,56.22135701178689 ) ;
  }

  @Test
  public void test4258() {
    coral.tests.JPFBenchmark.benchmark05(-1.6940658945086007E-21,-1.5707963267948966,-32.86016954946411 ) ;
  }

  @Test
  public void test4259() {
    coral.tests.JPFBenchmark.benchmark05(-1.7158418571577475E-18,-1.5707963267948963,0.0 ) ;
  }

  @Test
  public void test4260() {
    coral.tests.JPFBenchmark.benchmark05(-1.7268633711820498E-13,-1.5707963267948966,59.09081872428249 ) ;
  }

  @Test
  public void test4261() {
    coral.tests.JPFBenchmark.benchmark05(-1.7345084869981059E-18,-0.0015563441309573225,42.442935444966615 ) ;
  }

  @Test
  public void test4262() {
    coral.tests.JPFBenchmark.benchmark05(1.734723475976807E-18,-1.4655332699220163,-8.150046442395208 ) ;
  }

  @Test
  public void test4263() {
    coral.tests.JPFBenchmark.benchmark05(-1.734723475976807E-18,-1.5707963267948966,-23.56197541960442 ) ;
  }

  @Test
  public void test4264() {
    coral.tests.JPFBenchmark.benchmark05(-1.734723475976807E-18,-1.5707963267948966,47.12395213308527 ) ;
  }

  @Test
  public void test4265() {
    coral.tests.JPFBenchmark.benchmark05(-1.734723475976807E-18,-1.5707963267948966,66.05804111231535 ) ;
  }

  @Test
  public void test4266() {
    coral.tests.JPFBenchmark.benchmark05(-1.734723475976807E-18,-40.99445079673598,13.620576490368563 ) ;
  }

  @Test
  public void test4267() {
    coral.tests.JPFBenchmark.benchmark05(-1.734723475976807E-18,-53.62747387357976,-55.98312023144059 ) ;
  }

  @Test
  public void test4268() {
    coral.tests.JPFBenchmark.benchmark05(17.383604740413546,-19.312842560176847,-10.075095151134477 ) ;
  }

  @Test
  public void test4269() {
    coral.tests.JPFBenchmark.benchmark05(-1.7393494052460785E-15,-1.5707963267948966,-8.28174039405512 ) ;
  }

  @Test
  public void test4270() {
    coral.tests.JPFBenchmark.benchmark05(-17.430975061983105,-1.2407158482003524,-97.31267707997642 ) ;
  }

  @Test
  public void test4271() {
    coral.tests.JPFBenchmark.benchmark05(-1.7435346166664794E-15,-1.2675906321926433,12.618901414084263 ) ;
  }

  @Test
  public void test4272() {
    coral.tests.JPFBenchmark.benchmark05(17.452049758933086,86.93098774505518,46.749000714909016 ) ;
  }

  @Test
  public void test4273() {
    coral.tests.JPFBenchmark.benchmark05(-1.767672889665139E-15,-1.5707963267948966,-19.769017204968282 ) ;
  }

  @Test
  public void test4274() {
    coral.tests.JPFBenchmark.benchmark05(1.7752702114530763,35.955806623644946,-14.117863115291016 ) ;
  }

  @Test
  public void test4275() {
    coral.tests.JPFBenchmark.benchmark05(-1.7758131713797976E-14,-1.5707963267948943,56.16430196459821 ) ;
  }

  @Test
  public void test4276() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-0.06636901459502909,62.81585401816871 ) ;
  }

  @Test
  public void test4277() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-0.38639990959253684,-69.47295959257463 ) ;
  }

  @Test
  public void test4278() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-0.6272465824818605,-0.7686971738701467 ) ;
  }

  @Test
  public void test4279() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-0.9805587880960189,-1.116320809905048 ) ;
  }

  @Test
  public void test4280() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-1.1309010547838172,0.0 ) ;
  }

  @Test
  public void test4281() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-1.169619319127329,92.17245240079563 ) ;
  }

  @Test
  public void test4282() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-1.570796326794797,-48.52577740350743 ) ;
  }

  @Test
  public void test4283() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-1.5707963267948912,12.56565015305273 ) ;
  }

  @Test
  public void test4284() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test4285() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-1.5707963267948963,-44.11061916850443 ) ;
  }

  @Test
  public void test4286() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-1.5707963267948966,58.456546880766325 ) ;
  }

  @Test
  public void test4287() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-1.5707963267948983,27.2786659893341 ) ;
  }

  @Test
  public void test4288() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-35.612806264223764,-1.5707963267948912 ) ;
  }

  @Test
  public void test4289() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-3.5685644123192537,-1.570796326794895 ) ;
  }

  @Test
  public void test4290() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-42.27094746188449,12.87359967567925 ) ;
  }

  @Test
  public void test4291() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-48.12664453259277,45.86383756439643 ) ;
  }

  @Test
  public void test4292() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-78.56173611204119,40.84582930645239 ) ;
  }

  @Test
  public void test4293() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-78.73738246315726,29.042630806259666 ) ;
  }

  @Test
  public void test4294() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-97.99745108338229,66.4375389177651 ) ;
  }

  @Test
  public void test4295() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-98.68822388546518,-1.5707963267948966 ) ;
  }

  @Test
  public void test4296() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-98.93603729155836,27.72362272490289 ) ;
  }

  @Test
  public void test4297() {
    coral.tests.JPFBenchmark.benchmark05(-1.7768033037442224E-15,-1.2784054277698103,0.0 ) ;
  }

  @Test
  public void test4298() {
    coral.tests.JPFBenchmark.benchmark05(-1.7816992425190377E-30,-0.01807261473514804,20.057906936487793 ) ;
  }

  @Test
  public void test4299() {
    coral.tests.JPFBenchmark.benchmark05(-17.856911743953233,56.200647142925334,98.40169094154217 ) ;
  }

  @Test
  public void test4300() {
    coral.tests.JPFBenchmark.benchmark05(17.908997573891966,-92.79109315969482,44.62112083618089 ) ;
  }

  @Test
  public void test4301() {
    coral.tests.JPFBenchmark.benchmark05(-1.7915216454929136E-7,-2.7755575615628914E-17,5.212388980387442 ) ;
  }

  @Test
  public void test4302() {
    coral.tests.JPFBenchmark.benchmark05(-1.7933296426442826E-15,-1.5707963267948966,80.97842288472538 ) ;
  }

  @Test
  public void test4303() {
    coral.tests.JPFBenchmark.benchmark05(17.95584749086558,98.08545815749366,11.766156484379849 ) ;
  }

  @Test
  public void test4304() {
    coral.tests.JPFBenchmark.benchmark05(-1.7969052256446363E-4,-73.08795161974207,-63.48197233408414 ) ;
  }

  @Test
  public void test4305() {
    coral.tests.JPFBenchmark.benchmark05(18.1297802807252,-63.76848410229616,8.440232003052927 ) ;
  }

  @Test
  public void test4306() {
    coral.tests.JPFBenchmark.benchmark05(-18.40952546591896,-28.700348080549574,-18.596767436635957 ) ;
  }

  @Test
  public void test4307() {
    coral.tests.JPFBenchmark.benchmark05(1.8527905305999306,-3.141621613580146,-63.133303392636115 ) ;
  }

  @Test
  public void test4308() {
    coral.tests.JPFBenchmark.benchmark05(18.772636927392,-14.37715655501745,26.48303838195612 ) ;
  }

  @Test
  public void test4309() {
    coral.tests.JPFBenchmark.benchmark05(-1.892985118344409E-14,-1.5707963267948966,-72.55958908073877 ) ;
  }

  @Test
  public void test4310() {
    coral.tests.JPFBenchmark.benchmark05(18.94286531849714,-3.306016706120033,-21.13401530387398 ) ;
  }

  @Test
  public void test4311() {
    coral.tests.JPFBenchmark.benchmark05(-1.9279358920823073E-180,-1.5707963267948966,21.660945890082285 ) ;
  }

  @Test
  public void test4312() {
    coral.tests.JPFBenchmark.benchmark05(1.9290601572634558E-31,-1.5707963267948966,-37.99531413732442 ) ;
  }

  @Test
  public void test4313() {
    coral.tests.JPFBenchmark.benchmark05(19.33393617602563,-33.58600472319071,-84.25866774779837 ) ;
  }

  @Test
  public void test4314() {
    coral.tests.JPFBenchmark.benchmark05(19.4242061351906,20.589782795193585,-87.64822577726912 ) ;
  }

  @Test
  public void test4315() {
    coral.tests.JPFBenchmark.benchmark05(-1.9467177638862437E-208,-98.70172497576458,1.5707963267948948 ) ;
  }

  @Test
  public void test4316() {
    coral.tests.JPFBenchmark.benchmark05(-1.9704964197625997E-6,-1.5707963267948966,7.853981596004626 ) ;
  }

  @Test
  public void test4317() {
    coral.tests.JPFBenchmark.benchmark05(1.9721522630525295E-31,-34.619406399823106,-56.99219807719149 ) ;
  }

  @Test
  public void test4318() {
    coral.tests.JPFBenchmark.benchmark05(-1.9742063534922827E-177,-0.6794745632319764,16.67288963784937 ) ;
  }

  @Test
  public void test4319() {
    coral.tests.JPFBenchmark.benchmark05(-1.9742063534922827E-177,-1.5707963267948966,-27.005817351242996 ) ;
  }

  @Test
  public void test4320() {
    coral.tests.JPFBenchmark.benchmark05(-1.9742063534922827E-177,-35.59230123120428,85.20218292052148 ) ;
  }

  @Test
  public void test4321() {
    coral.tests.JPFBenchmark.benchmark05(-1.999261497086876E-5,-8.883439847145753E-4,-1.5707963267948966 ) ;
  }

  @Test
  public void test4322() {
    coral.tests.JPFBenchmark.benchmark05(-2.002821791541564,-21.44254314584498,-78.80849123969148 ) ;
  }

  @Test
  public void test4323() {
    coral.tests.JPFBenchmark.benchmark05(20.184529811953283,54.24980925284768,-57.68354497847126 ) ;
  }

  @Test
  public void test4324() {
    coral.tests.JPFBenchmark.benchmark05(-2.0235048277937286E-15,-9.991356766058018,2.220446049250313E-16 ) ;
  }

  @Test
  public void test4325() {
    coral.tests.JPFBenchmark.benchmark05(-2.0461364811743334E-15,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test4326() {
    coral.tests.JPFBenchmark.benchmark05(-2.0598076950102164E-7,-66.93066294657257,0.0 ) ;
  }

  @Test
  public void test4327() {
    coral.tests.JPFBenchmark.benchmark05(-20.613624558680385,0,0 ) ;
  }

  @Test
  public void test4328() {
    coral.tests.JPFBenchmark.benchmark05(-2.0679515313825692E-25,-1.359582054756262,-75.7228285639248 ) ;
  }

  @Test
  public void test4329() {
    coral.tests.JPFBenchmark.benchmark05(20.88854029194887,-92.94339413880903,-60.05682151301883 ) ;
  }

  @Test
  public void test4330() {
    coral.tests.JPFBenchmark.benchmark05(-20.94874053774535,-76.2080515761,30.02248910098416 ) ;
  }

  @Test
  public void test4331() {
    coral.tests.JPFBenchmark.benchmark05(-2.1175823681357508E-22,-1.5707963267948966,-10.995696361109779 ) ;
  }

  @Test
  public void test4332() {
    coral.tests.JPFBenchmark.benchmark05(2.1175823681357508E-22,-42.20306950663583,1.570796322256309 ) ;
  }

  @Test
  public void test4333() {
    coral.tests.JPFBenchmark.benchmark05(21.265660304915215,73.12413364228789,96.86460424088122 ) ;
  }

  @Test
  public void test4334() {
    coral.tests.JPFBenchmark.benchmark05(-2.1568774135078647E-14,-1.5707963267948966,-35.999566942688716 ) ;
  }

  @Test
  public void test4335() {
    coral.tests.JPFBenchmark.benchmark05(2.1678157932489626,6.889596404138686,99.15157467512094 ) ;
  }

  @Test
  public void test4336() {
    coral.tests.JPFBenchmark.benchmark05(-2.1684043449710089E-19,-1.5707963267948966,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test4337() {
    coral.tests.JPFBenchmark.benchmark05(-2.1684043449710089E-19,-1.5707963267948966,-20.78260131236101 ) ;
  }

  @Test
  public void test4338() {
    coral.tests.JPFBenchmark.benchmark05(2.1684043449710089E-19,-1.5707963267948966,26.935803536433685 ) ;
  }

  @Test
  public void test4339() {
    coral.tests.JPFBenchmark.benchmark05(-2.1684043449710089E-19,-1.5707963267948966,34.55849583876641 ) ;
  }

  @Test
  public void test4340() {
    coral.tests.JPFBenchmark.benchmark05(-2.173531348072187E-19,-1.5707963267948966,-98.96016858801339 ) ;
  }

  @Test
  public void test4341() {
    coral.tests.JPFBenchmark.benchmark05(21.836424163678103,14.337553554110201,61.33110523536163 ) ;
  }

  @Test
  public void test4342() {
    coral.tests.JPFBenchmark.benchmark05(21.85527144744526,38.02306222073915,-4.974686281141615 ) ;
  }

  @Test
  public void test4343() {
    coral.tests.JPFBenchmark.benchmark05(-21.994804484391864,0,0 ) ;
  }

  @Test
  public void test4344() {
    coral.tests.JPFBenchmark.benchmark05(-2.2028202193538107,-85.85509382777283,65.85266201195151 ) ;
  }

  @Test
  public void test4345() {
    coral.tests.JPFBenchmark.benchmark05(-2.2044761636971228E-8,-1.4601350698990927,120.93767696564461 ) ;
  }

  @Test
  public void test4346() {
    coral.tests.JPFBenchmark.benchmark05(-22.16371714690591,0,0 ) ;
  }

  @Test
  public void test4347() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-0.24268556335319333,-52.95488178266669 ) ;
  }

  @Test
  public void test4348() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-0.44077239236713217,-1.5761011080628282 ) ;
  }

  @Test
  public void test4349() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-0.6292196856929243,-41.44881901143209 ) ;
  }

  @Test
  public void test4350() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-0.7454446569566686,52.366968698756075 ) ;
  }

  @Test
  public void test4351() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-0.8822675921863445,-50.35606551362579 ) ;
  }

  @Test
  public void test4352() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-1.0247144900141478,-38.058854901657185 ) ;
  }

  @Test
  public void test4353() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-10.267846431178443,72.19919627720247 ) ;
  }

  @Test
  public void test4354() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-1.4394193308061567,61.027118180039366 ) ;
  }

  @Test
  public void test4355() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-1.4481081387843564,-93.7169631001162 ) ;
  }

  @Test
  public void test4356() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-1.5564922986713923,-32.491310113914864 ) ;
  }

  @Test
  public void test4357() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-1.5707963232425544,-3.1421650702401105 ) ;
  }

  @Test
  public void test4358() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-1.5707963265870986,-41.0197564657859 ) ;
  }

  @Test
  public void test4359() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-1.5707963267947036,-1.5707963267948966 ) ;
  }

  @Test
  public void test4360() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-1.5707963267948593,100.0 ) ;
  }

  @Test
  public void test4361() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-1.5707963267948963,-0.823420816375176 ) ;
  }

  @Test
  public void test4362() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-1.5707963267948963,-100.0 ) ;
  }

  @Test
  public void test4363() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-1.5707963267948966,12.566378461773986 ) ;
  }

  @Test
  public void test4364() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-1.5707963267948966,20.71910340937599 ) ;
  }

  @Test
  public void test4365() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-1.5707963267948966,35.28535672911363 ) ;
  }

  @Test
  public void test4366() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-1.5707963267948966,-3.878597411941823 ) ;
  }

  @Test
  public void test4367() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-1.5707963267948966,77.73332048824858 ) ;
  }

  @Test
  public void test4368() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-15.729896404107578,-1.5707963267948966 ) ;
  }

  @Test
  public void test4369() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-15.750211618334802,-73.12105548073072 ) ;
  }

  @Test
  public void test4370() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-1.82653686403308E-15,-28.155476944822638 ) ;
  }

  @Test
  public void test4371() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-22.4043506927654,-100.0 ) ;
  }

  @Test
  public void test4372() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-2.3225137676359102E-5,-1.570790894699575 ) ;
  }

  @Test
  public void test4373() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-3.9354413468678304,-4.712388982472543 ) ;
  }

  @Test
  public void test4374() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-42.24992084189691,-7.8539817935728164 ) ;
  }

  @Test
  public void test4375() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-66.48268479679427,-19.4677904455218 ) ;
  }

  @Test
  public void test4376() {
    coral.tests.JPFBenchmark.benchmark05(-22.325580299521363,85.13533818259808,-75.6133191609058 ) ;
  }

  @Test
  public void test4377() {
    coral.tests.JPFBenchmark.benchmark05(22.444851562145445,-23.64715510813413,48.47961298963213 ) ;
  }

  @Test
  public void test4378() {
    coral.tests.JPFBenchmark.benchmark05(-2.2616142776878835E-15,-1.5707963267948966,-42.94034186078482 ) ;
  }

  @Test
  public void test4379() {
    coral.tests.JPFBenchmark.benchmark05(-2.268296048517362E-12,-1.5707963267948966,26.260182890934978 ) ;
  }

  @Test
  public void test4380() {
    coral.tests.JPFBenchmark.benchmark05(-2.292142057925504E-16,-1.5707963267948966,69.13847729781858 ) ;
  }

  @Test
  public void test4381() {
    coral.tests.JPFBenchmark.benchmark05(-2.2971399072357656E-17,-1.5063603699930104,48.20302085462097 ) ;
  }

  @Test
  public void test4382() {
    coral.tests.JPFBenchmark.benchmark05(-2.308244654446434E-128,-35.0220310456195,27.896141624610667 ) ;
  }

  @Test
  public void test4383() {
    coral.tests.JPFBenchmark.benchmark05(-23.13273950241657,29.19268757366919,21.458104706276444 ) ;
  }

  @Test
  public void test4384() {
    coral.tests.JPFBenchmark.benchmark05(-2.3181410395788844E-15,-1.5707963267948966,-77.50404532824452 ) ;
  }

  @Test
  public void test4385() {
    coral.tests.JPFBenchmark.benchmark05(-2.3277952334657456E-4,-35.94230842791743,2.7595851943918257 ) ;
  }

  @Test
  public void test4386() {
    coral.tests.JPFBenchmark.benchmark05(-23.289446943585787,63.52600767795252,-60.285828471754364 ) ;
  }

  @Test
  public void test4387() {
    coral.tests.JPFBenchmark.benchmark05(2.333449656203584,98.2266715031744,75.53763282052722 ) ;
  }

  @Test
  public void test4388() {
    coral.tests.JPFBenchmark.benchmark05(23.38701271875155,7.346136185937311,-39.63224477152134 ) ;
  }

  @Test
  public void test4389() {
    coral.tests.JPFBenchmark.benchmark05(-23.749333139924957,-63.289729271615336,94.32810391644355 ) ;
  }

  @Test
  public void test4390() {
    coral.tests.JPFBenchmark.benchmark05(-2.376703401492754E-15,-1.7763568394002505E-15,-78.14876746237888 ) ;
  }

  @Test
  public void test4391() {
    coral.tests.JPFBenchmark.benchmark05(-23.79079851610608,0,0 ) ;
  }

  @Test
  public void test4392() {
    coral.tests.JPFBenchmark.benchmark05(-23.793382629562302,-53.52018055655172,-42.188963365565655 ) ;
  }

  @Test
  public void test4393() {
    coral.tests.JPFBenchmark.benchmark05(-23.94631500820121,91.69414718426503,17.812864462168505 ) ;
  }

  @Test
  public void test4394() {
    coral.tests.JPFBenchmark.benchmark05(-2.3995149022330095E-240,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test4395() {
    coral.tests.JPFBenchmark.benchmark05(-24.073073057228697,0,0 ) ;
  }

  @Test
  public void test4396() {
    coral.tests.JPFBenchmark.benchmark05(-24.288625707997056,-47.92104376044877,11.512376678229998 ) ;
  }

  @Test
  public void test4397() {
    coral.tests.JPFBenchmark.benchmark05(2.429208245868748,-1.5128748567395247,53.729642065237016 ) ;
  }

  @Test
  public void test4398() {
    coral.tests.JPFBenchmark.benchmark05(-2.4393174982496567E-19,-36.12831551627999,-1.5707963267948966 ) ;
  }

  @Test
  public void test4399() {
    coral.tests.JPFBenchmark.benchmark05(2.445168669869609,-66.6503991909689,-95.77522159563449 ) ;
  }

  @Test
  public void test4400() {
    coral.tests.JPFBenchmark.benchmark05(2.4467372484189975,-1.5511195694821516,-100.0 ) ;
  }

  @Test
  public void test4401() {
    coral.tests.JPFBenchmark.benchmark05(-2.4628014630994054E-14,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test4402() {
    coral.tests.JPFBenchmark.benchmark05(24.637994808892216,-42.11409301149691,62.22109661803637 ) ;
  }

  @Test
  public void test4403() {
    coral.tests.JPFBenchmark.benchmark05(-2.465190328815662E-32,0,0 ) ;
  }

  @Test
  public void test4404() {
    coral.tests.JPFBenchmark.benchmark05(2.465190328815662E-32,-0.5085882894558043,-9.214176356700891 ) ;
  }

  @Test
  public void test4405() {
    coral.tests.JPFBenchmark.benchmark05(2.465190328815662E-32,-1.5707963267948948,1.5707963267948966 ) ;
  }

  @Test
  public void test4406() {
    coral.tests.JPFBenchmark.benchmark05(2.465190328815662E-32,-1.5707963267948948,25.250340742687335 ) ;
  }

  @Test
  public void test4407() {
    coral.tests.JPFBenchmark.benchmark05(2.465190328815662E-32,-54.87072963353474,78.79643087585647 ) ;
  }

  @Test
  public void test4408() {
    coral.tests.JPFBenchmark.benchmark05(-2.465190328815662E-32,-6.85683235027789E-17,36.12831551628262 ) ;
  }

  @Test
  public void test4409() {
    coral.tests.JPFBenchmark.benchmark05(24.823363362904402,79.9993843622662,-44.34411213999516 ) ;
  }

  @Test
  public void test4410() {
    coral.tests.JPFBenchmark.benchmark05(-24.998934207574422,-91.52753037970301,47.38679062788361 ) ;
  }

  @Test
  public void test4411() {
    coral.tests.JPFBenchmark.benchmark05(25.123475871393097,28.08801133214004,38.87233705113945 ) ;
  }

  @Test
  public void test4412() {
    coral.tests.JPFBenchmark.benchmark05(-2.515324000819906E-15,-1.1021240501404814,69.52629447167443 ) ;
  }

  @Test
  public void test4413() {
    coral.tests.JPFBenchmark.benchmark05(25.170558363420753,-21.926747327126492,-25.339081157898335 ) ;
  }

  @Test
  public void test4414() {
    coral.tests.JPFBenchmark.benchmark05(-25.365003477025255,75.97432923314386,0 ) ;
  }

  @Test
  public void test4415() {
    coral.tests.JPFBenchmark.benchmark05(-2.5443750851685838E-14,-1.5707963267948966,-34.180506982854624 ) ;
  }

  @Test
  public void test4416() {
    coral.tests.JPFBenchmark.benchmark05(25.512896169063808,85.52001303921804,65.84667067248583 ) ;
  }

  @Test
  public void test4417() {
    coral.tests.JPFBenchmark.benchmark05(-2.583198315179612E-15,-48.344445278266555,-4.71238914932717 ) ;
  }

  @Test
  public void test4418() {
    coral.tests.JPFBenchmark.benchmark05(-25.85890315151282,5.094513011073332,98.09227257487026 ) ;
  }

  @Test
  public void test4419() {
    coral.tests.JPFBenchmark.benchmark05(2.588960685042243,-1.5707963267948966,72.39732261448884 ) ;
  }

  @Test
  public void test4420() {
    coral.tests.JPFBenchmark.benchmark05(-2.5899611868601704E-14,-1.5707963267948966,-58.7605702553486 ) ;
  }

  @Test
  public void test4421() {
    coral.tests.JPFBenchmark.benchmark05(-2.5904109562828606E-18,-16.05732385811822,56.98769116976393 ) ;
  }

  @Test
  public void test4422() {
    coral.tests.JPFBenchmark.benchmark05(-2.5930959894509674E-20,-1.5707963267948966,56.658986382288475 ) ;
  }

  @Test
  public void test4423() {
    coral.tests.JPFBenchmark.benchmark05(-2.5965576585989007E-13,-1.5707963267948966,69.11503834777396 ) ;
  }

  @Test
  public void test4424() {
    coral.tests.JPFBenchmark.benchmark05(26.122611044115573,-59.352856271063146,-89.35872460772588 ) ;
  }

  @Test
  public void test4425() {
    coral.tests.JPFBenchmark.benchmark05(-2642.5246148856663,0,0 ) ;
  }

  @Test
  public void test4426() {
    coral.tests.JPFBenchmark.benchmark05(-26.702204557052795,82.7369658640639,-98.92989851925671 ) ;
  }

  @Test
  public void test4427() {
    coral.tests.JPFBenchmark.benchmark05(-2.6825718116395708E-12,-155.38214323858426,-118.65882443940197 ) ;
  }

  @Test
  public void test4428() {
    coral.tests.JPFBenchmark.benchmark05(-2.6834263664523614E-12,-48.303877957181605,1.5707963267948966 ) ;
  }

  @Test
  public void test4429() {
    coral.tests.JPFBenchmark.benchmark05(-27.038929488721593,21.27732848563923,61.93676089222865 ) ;
  }

  @Test
  public void test4430() {
    coral.tests.JPFBenchmark.benchmark05(-2708.2387141129016,0,0 ) ;
  }

  @Test
  public void test4431() {
    coral.tests.JPFBenchmark.benchmark05(2.710505431213761E-20,-0.7181098085669728,-70.12448442768012 ) ;
  }

  @Test
  public void test4432() {
    coral.tests.JPFBenchmark.benchmark05(-2.710505431213761E-20,-1.5707963267948966,1.5707963267949512 ) ;
  }

  @Test
  public void test4433() {
    coral.tests.JPFBenchmark.benchmark05(-2.710505431213761E-20,-1.5707963267948966,3.1416665693855066 ) ;
  }

  @Test
  public void test4434() {
    coral.tests.JPFBenchmark.benchmark05(2.710505431213761E-20,-1.5707963267948966,56.46878530722467 ) ;
  }

  @Test
  public void test4435() {
    coral.tests.JPFBenchmark.benchmark05(-27.390969015147704,76.19999849286785,-84.01191288936491 ) ;
  }

  @Test
  public void test4436() {
    coral.tests.JPFBenchmark.benchmark05(-27.40593066203347,0,0 ) ;
  }

  @Test
  public void test4437() {
    coral.tests.JPFBenchmark.benchmark05(27.46348411650861,22.979128800581265,30.47355027162854 ) ;
  }

  @Test
  public void test4438() {
    coral.tests.JPFBenchmark.benchmark05(-2.764938249644398E-6,-1.5707963267948966,-20.991148415150107 ) ;
  }

  @Test
  public void test4439() {
    coral.tests.JPFBenchmark.benchmark05(-2.7755575615628914E-17,-0.41524097900519286,4.712389010678972 ) ;
  }

  @Test
  public void test4440() {
    coral.tests.JPFBenchmark.benchmark05(-2.7755575615628914E-17,-1.5707963210246458,-65.7968672046123 ) ;
  }

  @Test
  public void test4441() {
    coral.tests.JPFBenchmark.benchmark05(-2.7755575615628914E-17,-1.5707963267941665,0.277900004550206 ) ;
  }

  @Test
  public void test4442() {
    coral.tests.JPFBenchmark.benchmark05(-2.7755575615628914E-17,-1.5707963267948966,-24.146976060279133 ) ;
  }

  @Test
  public void test4443() {
    coral.tests.JPFBenchmark.benchmark05(28.000141644984723,73.57722064029369,-25.853908192931385 ) ;
  }

  @Test
  public void test4444() {
    coral.tests.JPFBenchmark.benchmark05(28.074386260393936,-57.287938497440784,7.940419725545283 ) ;
  }

  @Test
  public void test4445() {
    coral.tests.JPFBenchmark.benchmark05(2.808276594496115,3.3881317890172014E-21,-100.0 ) ;
  }

  @Test
  public void test4446() {
    coral.tests.JPFBenchmark.benchmark05(-2.817681462947307E-132,-54.787332146570435,100.0 ) ;
  }

  @Test
  public void test4447() {
    coral.tests.JPFBenchmark.benchmark05(-2.8425367142984084E-13,-0.3427181367299017,2.6587108189577176E-13 ) ;
  }

  @Test
  public void test4448() {
    coral.tests.JPFBenchmark.benchmark05(-2.9046332071611874E-22,-1.5707963267948966,-54.97787143782137 ) ;
  }

  @Test
  public void test4449() {
    coral.tests.JPFBenchmark.benchmark05(-29.102517417504785,42.074696509684145,59.72649790483487 ) ;
  }

  @Test
  public void test4450() {
    coral.tests.JPFBenchmark.benchmark05(-29.136503790208494,-54.662083501376024,-74.45378724175754 ) ;
  }

  @Test
  public void test4451() {
    coral.tests.JPFBenchmark.benchmark05(-2.914907558513647E-14,-41.58091531636365,-0.4746240381370759 ) ;
  }

  @Test
  public void test4452() {
    coral.tests.JPFBenchmark.benchmark05(29.257937836771447,-53.714540824523404,-24.915304406260688 ) ;
  }

  @Test
  public void test4453() {
    coral.tests.JPFBenchmark.benchmark05(-29.262128657309816,-70.62137120228806,-79.2865515013527 ) ;
  }

  @Test
  public void test4454() {
    coral.tests.JPFBenchmark.benchmark05(-2.9331270728214365E-7,-1.5707962977256296,-37.78263650142769 ) ;
  }

  @Test
  public void test4455() {
    coral.tests.JPFBenchmark.benchmark05(-2.9517640390712127E-15,-42.32913132144827,1.5707963267948966 ) ;
  }

  @Test
  public void test4456() {
    coral.tests.JPFBenchmark.benchmark05(-2.9566009757145715E-17,-1.5707963267948966,45.256781130276835 ) ;
  }

  @Test
  public void test4457() {
    coral.tests.JPFBenchmark.benchmark05(2.9634406023289563,-8.673617379884035E-19,88.93574273159166 ) ;
  }

  @Test
  public void test4458() {
    coral.tests.JPFBenchmark.benchmark05(30.047797878035624,15.000323533453127,-1.2298514795800628 ) ;
  }

  @Test
  public void test4459() {
    coral.tests.JPFBenchmark.benchmark05(30.159004200103084,67.32141091083167,-79.46278847318536 ) ;
  }

  @Test
  public void test4460() {
    coral.tests.JPFBenchmark.benchmark05(-30.18419266403005,70.91963663049373,-38.307181296765606 ) ;
  }

  @Test
  public void test4461() {
    coral.tests.JPFBenchmark.benchmark05(30.38724598231525,-78.38540960231883,-14.378725210942036 ) ;
  }

  @Test
  public void test4462() {
    coral.tests.JPFBenchmark.benchmark05(-30.436556592579507,75.20122942219993,-0.09188496705037608 ) ;
  }

  @Test
  public void test4463() {
    coral.tests.JPFBenchmark.benchmark05(-3.0549363634996047E-151,-0.2735197682041593,-1.5707963267948966 ) ;
  }

  @Test
  public void test4464() {
    coral.tests.JPFBenchmark.benchmark05(30.645648737165573,55.92417384965799,49.59166392316064 ) ;
  }

  @Test
  public void test4465() {
    coral.tests.JPFBenchmark.benchmark05(30.685340778131888,41.791416662806625,-34.06538636811169 ) ;
  }

  @Test
  public void test4466() {
    coral.tests.JPFBenchmark.benchmark05(3.0736340303888454,-41.80898561635045,12.68339706854158 ) ;
  }

  @Test
  public void test4467() {
    coral.tests.JPFBenchmark.benchmark05(-30.74323229425144,31.007159037008392,80.67213475084824 ) ;
  }

  @Test
  public void test4468() {
    coral.tests.JPFBenchmark.benchmark05(-30.762233702382886,-96.36538661277515,89.3799389161679 ) ;
  }

  @Test
  public void test4469() {
    coral.tests.JPFBenchmark.benchmark05(-30.945886254107904,86.19075871150372,48.38909760293487 ) ;
  }

  @Test
  public void test4470() {
    coral.tests.JPFBenchmark.benchmark05(-3.1065504416978456E-11,-1.040086685902852E-8,-31.797982795495393 ) ;
  }

  @Test
  public void test4471() {
    coral.tests.JPFBenchmark.benchmark05(-31.11144496420293,90.1281580085707,54.60821262797876 ) ;
  }

  @Test
  public void test4472() {
    coral.tests.JPFBenchmark.benchmark05(-3.1181065136743665E-17,-1.5707963267948966,78.10690889817982 ) ;
  }

  @Test
  public void test4473() {
    coral.tests.JPFBenchmark.benchmark05(-3.1282548362235952E-148,-1.5707963267948966,46.13707931580993 ) ;
  }

  @Test
  public void test4474() {
    coral.tests.JPFBenchmark.benchmark05(-31.328093984893485,76.72837167861849,8.542124129387858 ) ;
  }

  @Test
  public void test4475() {
    coral.tests.JPFBenchmark.benchmark05(-3.1724272966445615E-117,-15.783665843956062,-1.1165962658320552 ) ;
  }

  @Test
  public void test4476() {
    coral.tests.JPFBenchmark.benchmark05(31.74351667599896,64.72254109482603,63.09389886111225 ) ;
  }

  @Test
  public void test4477() {
    coral.tests.JPFBenchmark.benchmark05(-3.188236864276005E-13,-1.5707963267948966,7.764977402525432 ) ;
  }

  @Test
  public void test4478() {
    coral.tests.JPFBenchmark.benchmark05(31.89732834879669,74.30869596053924,65.63423404806866 ) ;
  }

  @Test
  public void test4479() {
    coral.tests.JPFBenchmark.benchmark05(32.04269449187339,-99.92962299956407,36.895336082676664 ) ;
  }

  @Test
  public void test4480() {
    coral.tests.JPFBenchmark.benchmark05(-3.217223493417518E-86,-1.5707963267948966,1.4371902854114242 ) ;
  }

  @Test
  public void test4481() {
    coral.tests.JPFBenchmark.benchmark05(32.23473565520777,45.1524782083568,-43.111265465085054 ) ;
  }

  @Test
  public void test4482() {
    coral.tests.JPFBenchmark.benchmark05(-3.228336562059246E-15,-0.05394350295853312,-45.24650413138959 ) ;
  }

  @Test
  public void test4483() {
    coral.tests.JPFBenchmark.benchmark05(3.2311742677852644E-27,-1.4231394223484104,65.46464694082627 ) ;
  }

  @Test
  public void test4484() {
    coral.tests.JPFBenchmark.benchmark05(-32.34661618548826,-81.36241420175506,54.17598939831234 ) ;
  }

  @Test
  public void test4485() {
    coral.tests.JPFBenchmark.benchmark05(-32.44340669527111,59.17716154922982,83.61631726145541 ) ;
  }

  @Test
  public void test4486() {
    coral.tests.JPFBenchmark.benchmark05(3.2580275775237213E-6,-1.1260992281266884,-169.3881210549511 ) ;
  }

  @Test
  public void test4487() {
    coral.tests.JPFBenchmark.benchmark05(-32.68704139460512,95.22871392034395,96.37865217369239 ) ;
  }

  @Test
  public void test4488() {
    coral.tests.JPFBenchmark.benchmark05(-3.2815082211773345E-7,-1.5707963267948966,101.09874825898589 ) ;
  }

  @Test
  public void test4489() {
    coral.tests.JPFBenchmark.benchmark05(33.168903501479804,5.268631932463336,64.28680195282467 ) ;
  }

  @Test
  public void test4490() {
    coral.tests.JPFBenchmark.benchmark05(33.374679894288874,-12.734641154818178,-46.517908720205384 ) ;
  }

  @Test
  public void test4491() {
    coral.tests.JPFBenchmark.benchmark05(-33.74532953676592,-14.095964954847574,18.909912885787335 ) ;
  }

  @Test
  public void test4492() {
    coral.tests.JPFBenchmark.benchmark05(-3.377017006114542E-226,-1.3789009883056962,-78.1666001104098 ) ;
  }

  @Test
  public void test4493() {
    coral.tests.JPFBenchmark.benchmark05(34.074075927664296,-71.31035190201243,-43.88350047157039 ) ;
  }

  @Test
  public void test4494() {
    coral.tests.JPFBenchmark.benchmark05(-3.4365249146316614,3.3530616842723617,-98.6769841218663 ) ;
  }

  @Test
  public void test4495() {
    coral.tests.JPFBenchmark.benchmark05(-3.4377997962859965E-20,-5.431043015623153E-5,-1.5707621718854021 ) ;
  }

  @Test
  public void test4496() {
    coral.tests.JPFBenchmark.benchmark05(-3.4412783891026905E-15,-1.5707963267948966,2.1175823681357508E-22 ) ;
  }

  @Test
  public void test4497() {
    coral.tests.JPFBenchmark.benchmark05(-34.45178862679232,-12.354373774071476,74.66252619018428 ) ;
  }

  @Test
  public void test4498() {
    coral.tests.JPFBenchmark.benchmark05(-34.53598848365209,87.80182653152829,-88.135193546466 ) ;
  }

  @Test
  public void test4499() {
    coral.tests.JPFBenchmark.benchmark05(-3.467017794556895,-44.86267687705077,-82.77182417841587 ) ;
  }

  @Test
  public void test4500() {
    coral.tests.JPFBenchmark.benchmark05(34.69195143727799,-74.6006186585745,-29.019959973746595 ) ;
  }

  @Test
  public void test4501() {
    coral.tests.JPFBenchmark.benchmark05(-3.469446951953614E-18,-0.009658927998258978,22.02092095876233 ) ;
  }

  @Test
  public void test4502() {
    coral.tests.JPFBenchmark.benchmark05(-3.469446951953614E-18,-1.5707963266797906,50.21592181668068 ) ;
  }

  @Test
  public void test4503() {
    coral.tests.JPFBenchmark.benchmark05(-3.469446951953614E-18,-1.5707963267948966,43.44120500297177 ) ;
  }

  @Test
  public void test4504() {
    coral.tests.JPFBenchmark.benchmark05(-3.469446951953614E-18,-1.5707963267948966,-88.08959430622913 ) ;
  }

  @Test
  public void test4505() {
    coral.tests.JPFBenchmark.benchmark05(-3.469446951953614E-18,-98.09144621538731,78.1092285837052 ) ;
  }

  @Test
  public void test4506() {
    coral.tests.JPFBenchmark.benchmark05(-34.70205319822013,12.770026112852946,-65.93933974669056 ) ;
  }

  @Test
  public void test4507() {
    coral.tests.JPFBenchmark.benchmark05(-3.4874911912234268,-10.183320447277012,39.888305401880956 ) ;
  }

  @Test
  public void test4508() {
    coral.tests.JPFBenchmark.benchmark05(-35.02569489829996,33.580253490768484,-85.85715009134998 ) ;
  }

  @Test
  public void test4509() {
    coral.tests.JPFBenchmark.benchmark05(-35.10990846795738,-65.17908762380067,-51.44255905638631 ) ;
  }

  @Test
  public void test4510() {
    coral.tests.JPFBenchmark.benchmark05(35.155951847870284,-52.30867165801354,-23.279288237686572 ) ;
  }

  @Test
  public void test4511() {
    coral.tests.JPFBenchmark.benchmark05(-35.174286625636825,-62.55368976100926,14.824754329966368 ) ;
  }

  @Test
  public void test4512() {
    coral.tests.JPFBenchmark.benchmark05(35.39152329959373,-65.96184795709814,-63.428429379386195 ) ;
  }

  @Test
  public void test4513() {
    coral.tests.JPFBenchmark.benchmark05(-35.43009361105658,-71.33567220357267,-16.49008061435228 ) ;
  }

  @Test
  public void test4514() {
    coral.tests.JPFBenchmark.benchmark05(-35.45430972207831,87.57006811258952,80.40980691323722 ) ;
  }

  @Test
  public void test4515() {
    coral.tests.JPFBenchmark.benchmark05(-35.52506641082074,93.19112157722188,-97.39762642857686 ) ;
  }

  @Test
  public void test4516() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-0.6057421171069945,-1.5707963267948966 ) ;
  }

  @Test
  public void test4517() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-1.5707963267948966,0.20748923627053845 ) ;
  }

  @Test
  public void test4518() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-1.5707963267948966,0.6400424547622521 ) ;
  }

  @Test
  public void test4519() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-1.5707963267948966,-11.087968529425623 ) ;
  }

  @Test
  public void test4520() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test4521() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-1.5707963267948966,1.570796326794897 ) ;
  }

  @Test
  public void test4522() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-16.021053452464038,-66.54056432012426 ) ;
  }

  @Test
  public void test4523() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-36.0968748121463,-45.998522069704094 ) ;
  }

  @Test
  public void test4524() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-48.256294897385054,-75.89606385436326 ) ;
  }

  @Test
  public void test4525() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-66.53016370387073,-1.4853697815353542 ) ;
  }

  @Test
  public void test4526() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-66.64251398052431,0.0 ) ;
  }

  @Test
  public void test4527() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-66.82712382561202,78.33519229250365 ) ;
  }

  @Test
  public void test4528() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-84.91050786454369,-69.90304863491619 ) ;
  }

  @Test
  public void test4529() {
    coral.tests.JPFBenchmark.benchmark05(-35.59092751647238,31.716082037296076,-66.50619797939109 ) ;
  }

  @Test
  public void test4530() {
    coral.tests.JPFBenchmark.benchmark05(-35.68408890023518,39.85284236326325,59.43616452955115 ) ;
  }

  @Test
  public void test4531() {
    coral.tests.JPFBenchmark.benchmark05(-35.832068142547,44.72386016485265,-27.98188732469565 ) ;
  }

  @Test
  public void test4532() {
    coral.tests.JPFBenchmark.benchmark05(3.5855814422995596,-1.5141271626373554,339.5361849042033 ) ;
  }

  @Test
  public void test4533() {
    coral.tests.JPFBenchmark.benchmark05(-36.0264815087302,0,0 ) ;
  }

  @Test
  public void test4534() {
    coral.tests.JPFBenchmark.benchmark05(-36.04283733650784,99.93026376682982,-37.13141074913246 ) ;
  }

  @Test
  public void test4535() {
    coral.tests.JPFBenchmark.benchmark05(-3.6133807662991415E-16,4.930380657631324E-32,-98.39040965237216 ) ;
  }

  @Test
  public void test4536() {
    coral.tests.JPFBenchmark.benchmark05(-36.17917835671876,7.78286404100794,60.08313546455517 ) ;
  }

  @Test
  public void test4537() {
    coral.tests.JPFBenchmark.benchmark05(-36.253774072512044,54.557927258587966,91.26956770642124 ) ;
  }

  @Test
  public void test4538() {
    coral.tests.JPFBenchmark.benchmark05(36.273258756086875,-30.290181991356377,65.54748869325883 ) ;
  }

  @Test
  public void test4539() {
    coral.tests.JPFBenchmark.benchmark05(36.31803341488717,53.3986139305911,-48.7817569410915 ) ;
  }

  @Test
  public void test4540() {
    coral.tests.JPFBenchmark.benchmark05(-36.433264533469334,-86.84964794839306,-77.4928543622483 ) ;
  }

  @Test
  public void test4541() {
    coral.tests.JPFBenchmark.benchmark05(-36.50722493812475,79.19119236020322,55.25422298316914 ) ;
  }

  @Test
  public void test4542() {
    coral.tests.JPFBenchmark.benchmark05(36.67961182917395,-8.550856152297385,-30.09379565754486 ) ;
  }

  @Test
  public void test4543() {
    coral.tests.JPFBenchmark.benchmark05(36.705801018223326,40.345835063522685,83.03006585423299 ) ;
  }

  @Test
  public void test4544() {
    coral.tests.JPFBenchmark.benchmark05(-3.676915298252295E-15,-1.5707963267948966,-97.73027328124031 ) ;
  }

  @Test
  public void test4545() {
    coral.tests.JPFBenchmark.benchmark05(-3.6790332663083136E-17,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test4546() {
    coral.tests.JPFBenchmark.benchmark05(-3.6799219600577756E-14,-1.5707963267948966,36.25480823062905 ) ;
  }

  @Test
  public void test4547() {
    coral.tests.JPFBenchmark.benchmark05(-3.689106645224526E-7,-1.5707963267948966,-23.56976426441544 ) ;
  }

  @Test
  public void test4548() {
    coral.tests.JPFBenchmark.benchmark05(-36.9410517558894,-49.851388939244124,71.37639881417834 ) ;
  }

  @Test
  public void test4549() {
    coral.tests.JPFBenchmark.benchmark05(-3.7010326536393722E-6,-1.5707963267948966,-9.66951978063328 ) ;
  }

  @Test
  public void test4550() {
    coral.tests.JPFBenchmark.benchmark05(-3.7092061506874214E-68,-0.9736871795486783,55.250043520590886 ) ;
  }

  @Test
  public void test4551() {
    coral.tests.JPFBenchmark.benchmark05(37.27964101512944,-34.81123374871366,-0.2307883640146855 ) ;
  }

  @Test
  public void test4552() {
    coral.tests.JPFBenchmark.benchmark05(-3.728556105229539E-14,-167.7996504450221,119.33609281378247 ) ;
  }

  @Test
  public void test4553() {
    coral.tests.JPFBenchmark.benchmark05(-37.35052935693333,50.912906448479845,-68.09402978640571 ) ;
  }

  @Test
  public void test4554() {
    coral.tests.JPFBenchmark.benchmark05(37.63074222342078,27.584741956811172,-26.78939621823679 ) ;
  }

  @Test
  public void test4555() {
    coral.tests.JPFBenchmark.benchmark05(37.63475628065024,-12.882262409676315,-20.612029112439004 ) ;
  }

  @Test
  public void test4556() {
    coral.tests.JPFBenchmark.benchmark05(37.666886173986086,0.20050321916681924,52.93018206308088 ) ;
  }

  @Test
  public void test4557() {
    coral.tests.JPFBenchmark.benchmark05(37.68217068204379,16.08488142110305,-2.955103493306993 ) ;
  }

  @Test
  public void test4558() {
    coral.tests.JPFBenchmark.benchmark05(37.73609489885774,37.472908187260145,84.43822736395035 ) ;
  }

  @Test
  public void test4559() {
    coral.tests.JPFBenchmark.benchmark05(-37.76937021002593,-0.8466580881203498,-63.68126695314715 ) ;
  }

  @Test
  public void test4560() {
    coral.tests.JPFBenchmark.benchmark05(37.8438975672546,-67.68330320840914,82.48863392694764 ) ;
  }

  @Test
  public void test4561() {
    coral.tests.JPFBenchmark.benchmark05(-3.790058886692927E-17,-1.5707963267948966,-8.28645225171801 ) ;
  }

  @Test
  public void test4562() {
    coral.tests.JPFBenchmark.benchmark05(-37.982394474185725,64.63852150490544,-35.31538813435502 ) ;
  }

  @Test
  public void test4563() {
    coral.tests.JPFBenchmark.benchmark05(38.09115533021583,-55.787893199585795,-56.27028515999613 ) ;
  }

  @Test
  public void test4564() {
    coral.tests.JPFBenchmark.benchmark05(-38.10599658087179,-99.76184680838966,-17.160319527714734 ) ;
  }

  @Test
  public void test4565() {
    coral.tests.JPFBenchmark.benchmark05(-3.8288682720073936E-15,-15.906921131980312,0.0 ) ;
  }

  @Test
  public void test4566() {
    coral.tests.JPFBenchmark.benchmark05(-38.42789918182217,-66.97419761970045,-69.56520352953643 ) ;
  }

  @Test
  public void test4567() {
    coral.tests.JPFBenchmark.benchmark05(-38.55257831633088,5.122405087823552,64.60146083584647 ) ;
  }

  @Test
  public void test4568() {
    coral.tests.JPFBenchmark.benchmark05(-3.8839533639456173E-17,-1.5707963267948966,83.17596691928748 ) ;
  }

  @Test
  public void test4569() {
    coral.tests.JPFBenchmark.benchmark05(38.88312268521673,81.2421591031156,69.29580293884379 ) ;
  }

  @Test
  public void test4570() {
    coral.tests.JPFBenchmark.benchmark05(39.063255962209894,-63.62549134358486,-21.479127124720577 ) ;
  }

  @Test
  public void test4571() {
    coral.tests.JPFBenchmark.benchmark05(39.1872465886552,-54.992990666097064,-0.47109373909373176 ) ;
  }

  @Test
  public void test4572() {
    coral.tests.JPFBenchmark.benchmark05(-39.378189805204514,-75.36742699101886,-42.68398827913145 ) ;
  }

  @Test
  public void test4573() {
    coral.tests.JPFBenchmark.benchmark05(-3.944304526105059E-31,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test4574() {
    coral.tests.JPFBenchmark.benchmark05(39.54810928444209,-1.772248460712845,-27.96811026610129 ) ;
  }

  @Test
  public void test4575() {
    coral.tests.JPFBenchmark.benchmark05(-3.981106958487829E-9,-1.5707963267948966,26.828663730668232 ) ;
  }

  @Test
  public void test4576() {
    coral.tests.JPFBenchmark.benchmark05(4.003506710631624E-4,-1.5707963267948966,-71.35140861443712 ) ;
  }

  @Test
  public void test4577() {
    coral.tests.JPFBenchmark.benchmark05(-40.22088572351004,45.299814686834964,40.568409327527576 ) ;
  }

  @Test
  public void test4578() {
    coral.tests.JPFBenchmark.benchmark05(-4.038877701887844E-15,-1.5707963267948966,-1.5707963267948963 ) ;
  }

  @Test
  public void test4579() {
    coral.tests.JPFBenchmark.benchmark05(-4.0521425750383774E-4,-1.5707963267810794,32.86182385915903 ) ;
  }

  @Test
  public void test4580() {
    coral.tests.JPFBenchmark.benchmark05(-4.0578803133213417E-16,-97.96560448690659,-1.5707963267948966 ) ;
  }

  @Test
  public void test4581() {
    coral.tests.JPFBenchmark.benchmark05(40.65241246907391,9.96053701176092,-97.23063978499651 ) ;
  }

  @Test
  public void test4582() {
    coral.tests.JPFBenchmark.benchmark05(-40.743846988626764,-20.797851923705196,85.32095528372153 ) ;
  }

  @Test
  public void test4583() {
    coral.tests.JPFBenchmark.benchmark05(40.8327318563079,18.982829211451445,73.00485099184226 ) ;
  }

  @Test
  public void test4584() {
    coral.tests.JPFBenchmark.benchmark05(-41.03415986370169,-23.190923176430232,-95.96808777931139 ) ;
  }

  @Test
  public void test4585() {
    coral.tests.JPFBenchmark.benchmark05(-41.11813018395352,93.71389330551742,88.03322188742405 ) ;
  }

  @Test
  public void test4586() {
    coral.tests.JPFBenchmark.benchmark05(-4.115761515721698E-4,-1.5707963267948966,-32.70575932815842 ) ;
  }

  @Test
  public void test4587() {
    coral.tests.JPFBenchmark.benchmark05(-41.266301536845496,60.10476334234431,-19.157701828881542 ) ;
  }

  @Test
  public void test4588() {
    coral.tests.JPFBenchmark.benchmark05(-41.348166294843615,-92.45537191035456,3.4736924468937787 ) ;
  }

  @Test
  public void test4589() {
    coral.tests.JPFBenchmark.benchmark05(-4.137760293312309E-5,-550.2755419238508,-99.67929971811319 ) ;
  }

  @Test
  public void test4590() {
    coral.tests.JPFBenchmark.benchmark05(-4.157079910413025E-19,-1.5707963267948966,-53.40702685698689 ) ;
  }

  @Test
  public void test4591() {
    coral.tests.JPFBenchmark.benchmark05(41.924439220662606,40.86063110652006,-91.73623259705596 ) ;
  }

  @Test
  public void test4592() {
    coral.tests.JPFBenchmark.benchmark05(-42.10557753619817,99.58793817040589,-68.80855508173147 ) ;
  }

  @Test
  public void test4593() {
    coral.tests.JPFBenchmark.benchmark05(42.161998923713725,-91.72594544506947,47.70904205479758 ) ;
  }

  @Test
  public void test4594() {
    coral.tests.JPFBenchmark.benchmark05(-4.2323338722375325,28.625144028939218,-73.30684232271784 ) ;
  }

  @Test
  public void test4595() {
    coral.tests.JPFBenchmark.benchmark05(-42.332100100066626,8.454804659375114,32.645036269122556 ) ;
  }

  @Test
  public void test4596() {
    coral.tests.JPFBenchmark.benchmark05(-4.2351647362715017E-22,-0.13574582048559827,-22.174826934028857 ) ;
  }

  @Test
  public void test4597() {
    coral.tests.JPFBenchmark.benchmark05(4.2351647362715017E-22,-1.4736937598379725,94.94171614543771 ) ;
  }

  @Test
  public void test4598() {
    coral.tests.JPFBenchmark.benchmark05(4.237700216866685,40.81898253900627,17.111269383615507 ) ;
  }

  @Test
  public void test4599() {
    coral.tests.JPFBenchmark.benchmark05(-42.48418850178872,80.6447782922321,-79.8768857445401 ) ;
  }

  @Test
  public void test4600() {
    coral.tests.JPFBenchmark.benchmark05(-4.2800595859258084E-7,-180.58265682527087,111.54335692217572 ) ;
  }

  @Test
  public void test4601() {
    coral.tests.JPFBenchmark.benchmark05(-4.2893682274508765E-18,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test4602() {
    coral.tests.JPFBenchmark.benchmark05(43.17408946402065,-6.327759942095312,67.95939419450849 ) ;
  }

  @Test
  public void test4603() {
    coral.tests.JPFBenchmark.benchmark05(-4.317791244956993,-39.42529878232725,-9.809989363733763 ) ;
  }

  @Test
  public void test4604() {
    coral.tests.JPFBenchmark.benchmark05(-4.3368086899420177E-19,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test4605() {
    coral.tests.JPFBenchmark.benchmark05(-4.3407943809099195E-10,-1.3173345642479035,-120.34007942268374 ) ;
  }

  @Test
  public void test4606() {
    coral.tests.JPFBenchmark.benchmark05(-4.341325682588042E-165,-1.5707963267948966,-48.08456774060738 ) ;
  }

  @Test
  public void test4607() {
    coral.tests.JPFBenchmark.benchmark05(43.42640318798675,78.32601623221927,2.3686693783614174 ) ;
  }

  @Test
  public void test4608() {
    coral.tests.JPFBenchmark.benchmark05(43.653123096999025,-7.157278055816008,-57.73884756021674 ) ;
  }

  @Test
  public void test4609() {
    coral.tests.JPFBenchmark.benchmark05(-4.3801064620848935E-4,-84.95933041635327,-23.561945565904196 ) ;
  }

  @Test
  public void test4610() {
    coral.tests.JPFBenchmark.benchmark05(-4.383618698016806E-193,-60.837400194066774,-4.461576426444708 ) ;
  }

  @Test
  public void test4611() {
    coral.tests.JPFBenchmark.benchmark05(-43.95159867762437,52.88044062358534,-29.73248699303464 ) ;
  }

  @Test
  public void test4612() {
    coral.tests.JPFBenchmark.benchmark05(43.9884924574873,-55.16047536737956,-74.67101077022193 ) ;
  }

  @Test
  public void test4613() {
    coral.tests.JPFBenchmark.benchmark05(-4.4026272858551673E-134,-1.4505921521876952,45.302392176069695 ) ;
  }

  @Test
  public void test4614() {
    coral.tests.JPFBenchmark.benchmark05(-44.034402177283496,90.78261697553336,80.38875862745849 ) ;
  }

  @Test
  public void test4615() {
    coral.tests.JPFBenchmark.benchmark05(4.420325353659749,57.08735615901702,74.3670277183239 ) ;
  }

  @Test
  public void test4616() {
    coral.tests.JPFBenchmark.benchmark05(-4.431336167996266E-15,-1.5707963267948966,65.3967131271256 ) ;
  }

  @Test
  public void test4617() {
    coral.tests.JPFBenchmark.benchmark05(-4.44029356023421E-5,-1.5707963267948966,-1.5707963267948948 ) ;
  }

  @Test
  public void test4618() {
    coral.tests.JPFBenchmark.benchmark05(-4.440892098500626E-16,-0.22527617876938724,-23.24446953628106 ) ;
  }

  @Test
  public void test4619() {
    coral.tests.JPFBenchmark.benchmark05(-4.440892098500626E-16,-0.552200871442536,-1.5707963267948968 ) ;
  }

  @Test
  public void test4620() {
    coral.tests.JPFBenchmark.benchmark05(-4.440892098500626E-16,-10.223387753521692,-77.10597104126705 ) ;
  }

  @Test
  public void test4621() {
    coral.tests.JPFBenchmark.benchmark05(-4.440892098500626E-16,-1.5510610881204872,-41.69148018191012 ) ;
  }

  @Test
  public void test4622() {
    coral.tests.JPFBenchmark.benchmark05(-4.440892098500626E-16,-1.5707963267948966,-0.028845750197139114 ) ;
  }

  @Test
  public void test4623() {
    coral.tests.JPFBenchmark.benchmark05(-4.440892098500626E-16,-1.5707963267948966,-1.5707963267948948 ) ;
  }

  @Test
  public void test4624() {
    coral.tests.JPFBenchmark.benchmark05(-4.440892098500626E-16,-1.5707963267948966,50.51055767956237 ) ;
  }

  @Test
  public void test4625() {
    coral.tests.JPFBenchmark.benchmark05(-4.440892098500626E-16,-1.5707963267948966,79.60964748953356 ) ;
  }

  @Test
  public void test4626() {
    coral.tests.JPFBenchmark.benchmark05(-4.440892098500626E-16,-3.2665926535897953,-53.925513209147994 ) ;
  }

  @Test
  public void test4627() {
    coral.tests.JPFBenchmark.benchmark05(-4.440892098500626E-16,-34.831586217353326,0.0 ) ;
  }

  @Test
  public void test4628() {
    coral.tests.JPFBenchmark.benchmark05(-4.440892098500626E-16,-35.820755220107934,48.969650930278846 ) ;
  }

  @Test
  public void test4629() {
    coral.tests.JPFBenchmark.benchmark05(-4.440892098500626E-16,-400.54621479148017,1.3125318032380742 ) ;
  }

  @Test
  public void test4630() {
    coral.tests.JPFBenchmark.benchmark05(-4.440892098500626E-16,-41.988687372374514,78.6212494949324 ) ;
  }

  @Test
  public void test4631() {
    coral.tests.JPFBenchmark.benchmark05(-4.440892098500626E-16,-73.24677654271537,-5.677185346896764 ) ;
  }

  @Test
  public void test4632() {
    coral.tests.JPFBenchmark.benchmark05(-4.440892098500626E-16,-84.8249547719246,1.3555033885767362 ) ;
  }

  @Test
  public void test4633() {
    coral.tests.JPFBenchmark.benchmark05(-4.440892098500626E-16,-9.619384544152847,-1.5707963267947047 ) ;
  }

  @Test
  public void test4634() {
    coral.tests.JPFBenchmark.benchmark05(44.4468697379759,15.88204612400807,-93.04768535104233 ) ;
  }

  @Test
  public void test4635() {
    coral.tests.JPFBenchmark.benchmark05(44.50382848219141,-57.71918208185303,-26.775144057260178 ) ;
  }

  @Test
  public void test4636() {
    coral.tests.JPFBenchmark.benchmark05(-4.459227954121413E-19,-1.5707963267948966,-81.6970377867231 ) ;
  }

  @Test
  public void test4637() {
    coral.tests.JPFBenchmark.benchmark05(44.828863305268044,68.00883182162619,64.498530905573 ) ;
  }

  @Test
  public void test4638() {
    coral.tests.JPFBenchmark.benchmark05(-44.84258736781732,26.625842737000056,-79.91050605543197 ) ;
  }

  @Test
  public void test4639() {
    coral.tests.JPFBenchmark.benchmark05(-4.490346902323091E-15,-3.3881317890172014E-21,-32.983815928834886 ) ;
  }

  @Test
  public void test4640() {
    coral.tests.JPFBenchmark.benchmark05(45.36176342795429,-91.87161730731185,56.50214778443859 ) ;
  }

  @Test
  public void test4641() {
    coral.tests.JPFBenchmark.benchmark05(-4.537506558163755E-18,-1.5707963267948966,38.822622172239825 ) ;
  }

  @Test
  public void test4642() {
    coral.tests.JPFBenchmark.benchmark05(45.45840434618441,4.228302703035311,-91.420356473282 ) ;
  }

  @Test
  public void test4643() {
    coral.tests.JPFBenchmark.benchmark05(-4.550153052715273E-16,-1.5707963267948966,76.96902001263952 ) ;
  }

  @Test
  public void test4644() {
    coral.tests.JPFBenchmark.benchmark05(-4.5522099189454387E-159,-16.01188691365139,34.11803925245775 ) ;
  }

  @Test
  public void test4645() {
    coral.tests.JPFBenchmark.benchmark05(-45.54907033900084,-4.797776066250691,30.582194798663096 ) ;
  }

  @Test
  public void test4646() {
    coral.tests.JPFBenchmark.benchmark05(-4.5719495651291E-100,-1.2642560374602183,34.84067982342995 ) ;
  }

  @Test
  public void test4647() {
    coral.tests.JPFBenchmark.benchmark05(-4.5839833369241313E-7,-1.5707963267948966,95.81840769480723 ) ;
  }

  @Test
  public void test4648() {
    coral.tests.JPFBenchmark.benchmark05(-4.603172532808123E-9,-1.5707963267948966,-86.39379023523112 ) ;
  }

  @Test
  public void test4649() {
    coral.tests.JPFBenchmark.benchmark05(46.04513132185093,57.234150104334134,-58.59789743468955 ) ;
  }

  @Test
  public void test4650() {
    coral.tests.JPFBenchmark.benchmark05(-46.25043032289273,65.98171742898487,-32.647921311528606 ) ;
  }

  @Test
  public void test4651() {
    coral.tests.JPFBenchmark.benchmark05(-4.635054506015774E-16,-0.3798385704606826,21.732787577084935 ) ;
  }

  @Test
  public void test4652() {
    coral.tests.JPFBenchmark.benchmark05(46.48323479198524,65.64195236072482,36.572457015221204 ) ;
  }

  @Test
  public void test4653() {
    coral.tests.JPFBenchmark.benchmark05(-4.6727315223235813E-14,-1.5707963267948966,94.24777960752402 ) ;
  }

  @Test
  public void test4654() {
    coral.tests.JPFBenchmark.benchmark05(-46.73273331975209,-76.14422206806711,-96.48911878014037 ) ;
  }

  @Test
  public void test4655() {
    coral.tests.JPFBenchmark.benchmark05(46.99862377648077,95.66135009635974,29.409879033564096 ) ;
  }

  @Test
  public void test4656() {
    coral.tests.JPFBenchmark.benchmark05(-47.172277573495805,-22.66147210255052,85.82405140246007 ) ;
  }

  @Test
  public void test4657() {
    coral.tests.JPFBenchmark.benchmark05(-47.222451768333485,15.709630398050535,-73.97463705758972 ) ;
  }

  @Test
  public void test4658() {
    coral.tests.JPFBenchmark.benchmark05(47.44234961686183,-22.040251195833733,45.765936675927406 ) ;
  }

  @Test
  public void test4659() {
    coral.tests.JPFBenchmark.benchmark05(4.757609115321833E-23,-3.788810005140842,0.0 ) ;
  }

  @Test
  public void test4660() {
    coral.tests.JPFBenchmark.benchmark05(-48.08313318770387,84.30962505844971,0 ) ;
  }

  @Test
  public void test4661() {
    coral.tests.JPFBenchmark.benchmark05(48.17004999895775,41.138674179097194,-33.3597034296768 ) ;
  }

  @Test
  public void test4662() {
    coral.tests.JPFBenchmark.benchmark05(48.23077826631646,8.940157746627662,98.02588593046028 ) ;
  }

  @Test
  public void test4663() {
    coral.tests.JPFBenchmark.benchmark05(4.850187106685851,56.41031715147503,-6.645551578231036 ) ;
  }

  @Test
  public void test4664() {
    coral.tests.JPFBenchmark.benchmark05(-48.504389647701274,-62.81384341341314,54.90421482812843 ) ;
  }

  @Test
  public void test4665() {
    coral.tests.JPFBenchmark.benchmark05(-48.632864364335134,2.7190435701382825,-36.11288794561052 ) ;
  }

  @Test
  public void test4666() {
    coral.tests.JPFBenchmark.benchmark05(4.8703702423029424E-17,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test4667() {
    coral.tests.JPFBenchmark.benchmark05(-4.884170375486157E-9,-1.4307956653611331,1.5535305216300517 ) ;
  }

  @Test
  public void test4668() {
    coral.tests.JPFBenchmark.benchmark05(-4.890262547510275,-74.84470919441372,8.655267571397857 ) ;
  }

  @Test
  public void test4669() {
    coral.tests.JPFBenchmark.benchmark05(-49.1435121657785,80.32817756557228,-41.69170160805085 ) ;
  }

  @Test
  public void test4670() {
    coral.tests.JPFBenchmark.benchmark05(-4.919344913540954,3.1272982601289243,12.779010728187657 ) ;
  }

  @Test
  public void test4671() {
    coral.tests.JPFBenchmark.benchmark05(-49.268011959001726,-27.80401095669238,-4.10052817059092 ) ;
  }

  @Test
  public void test4672() {
    coral.tests.JPFBenchmark.benchmark05(4.930380657631324E-32,0,0 ) ;
  }

  @Test
  public void test4673() {
    coral.tests.JPFBenchmark.benchmark05(4.930380657631324E-32,-1.5707963267948966,-83.53740838839919 ) ;
  }

  @Test
  public void test4674() {
    coral.tests.JPFBenchmark.benchmark05(4.930380657631324E-32,-1.5707963267948966,91.98894735172561 ) ;
  }

  @Test
  public void test4675() {
    coral.tests.JPFBenchmark.benchmark05(-4.930380657631324E-32,-15.998032197919997,-1.5707963267948957 ) ;
  }

  @Test
  public void test4676() {
    coral.tests.JPFBenchmark.benchmark05(4.955730270695824,0,0 ) ;
  }

  @Test
  public void test4677() {
    coral.tests.JPFBenchmark.benchmark05(49.59863884351594,-21.08865816578252,31.617192238377413 ) ;
  }

  @Test
  public void test4678() {
    coral.tests.JPFBenchmark.benchmark05(-4.9813973007980375E-15,-35.11518530617846,1.5707963267949125 ) ;
  }

  @Test
  public void test4679() {
    coral.tests.JPFBenchmark.benchmark05(4.9857538113148365,53.05996429242461,-53.99224995551235 ) ;
  }

  @Test
  public void test4680() {
    coral.tests.JPFBenchmark.benchmark05(-4.98923354023794E-12,-1.5707963267948966,7.220912279846317 ) ;
  }

  @Test
  public void test4681() {
    coral.tests.JPFBenchmark.benchmark05(-4.9979940579286586E-14,-1.5707963267948966,27.917727135841574 ) ;
  }

  @Test
  public void test4682() {
    coral.tests.JPFBenchmark.benchmark05(-5.009828067247767,-25.468030344318592,-39.473532877914465 ) ;
  }

  @Test
  public void test4683() {
    coral.tests.JPFBenchmark.benchmark05(-50.16708632363145,-61.44932610230755,26.292549514310835 ) ;
  }

  @Test
  public void test4684() {
    coral.tests.JPFBenchmark.benchmark05(-50.23126655604047,19.507911586182814,-3.5323433702393743 ) ;
  }

  @Test
  public void test4685() {
    coral.tests.JPFBenchmark.benchmark05(-5.0519051484141666E-5,-98.95352995106533,4.71238898038469 ) ;
  }

  @Test
  public void test4686() {
    coral.tests.JPFBenchmark.benchmark05(-5.0539682649402436E-175,-1.5707963267948966,60.89998795971179 ) ;
  }

  @Test
  public void test4687() {
    coral.tests.JPFBenchmark.benchmark05(-50.6013835615734,16.076721937854416,-1.320265205227372 ) ;
  }

  @Test
  public void test4688() {
    coral.tests.JPFBenchmark.benchmark05(-50.764758134718456,-88.88218196342758,56.84302570591541 ) ;
  }

  @Test
  public void test4689() {
    coral.tests.JPFBenchmark.benchmark05(-5.078133246334346,-79.87472822902606,70.6658894938605 ) ;
  }

  @Test
  public void test4690() {
    coral.tests.JPFBenchmark.benchmark05(-5.107195771437929E-16,-1.5707963267948966,-8.981631811716824 ) ;
  }

  @Test
  public void test4691() {
    coral.tests.JPFBenchmark.benchmark05(-51.174840702287106,43.218536302910394,17.464343656397062 ) ;
  }

  @Test
  public void test4692() {
    coral.tests.JPFBenchmark.benchmark05(-51.2564325839151,-98.80953337383676,-3.994245994189029 ) ;
  }

  @Test
  public void test4693() {
    coral.tests.JPFBenchmark.benchmark05(-51.30143017607549,-82.4740682030881,-77.85438595633613 ) ;
  }

  @Test
  public void test4694() {
    coral.tests.JPFBenchmark.benchmark05(-5.133481163772657,8.575651766539806,54.63103290773168 ) ;
  }

  @Test
  public void test4695() {
    coral.tests.JPFBenchmark.benchmark05(-51.46516945501143,48.9763958046471,-4.724935649644138 ) ;
  }

  @Test
  public void test4696() {
    coral.tests.JPFBenchmark.benchmark05(-51.595037772267304,6.589954357673349,87.24865763362098 ) ;
  }

  @Test
  public void test4697() {
    coral.tests.JPFBenchmark.benchmark05(-51.755862635531955,93.8121771961971,-76.50063873326238 ) ;
  }

  @Test
  public void test4698() {
    coral.tests.JPFBenchmark.benchmark05(-51.81306690669744,77.87511047943187,14.931546469812034 ) ;
  }

  @Test
  public void test4699() {
    coral.tests.JPFBenchmark.benchmark05(51.865541470637766,11.966231522279074,-1.1837223678907094 ) ;
  }

  @Test
  public void test4700() {
    coral.tests.JPFBenchmark.benchmark05(-51.89744797287719,41.81820284084759,48.12131380670286 ) ;
  }

  @Test
  public void test4701() {
    coral.tests.JPFBenchmark.benchmark05(5.2180418415188115,-43.67875208139394,-42.789094698856076 ) ;
  }

  @Test
  public void test4702() {
    coral.tests.JPFBenchmark.benchmark05(5.225705689482531,-3.170848037474326,-5.442054464821398 ) ;
  }

  @Test
  public void test4703() {
    coral.tests.JPFBenchmark.benchmark05(-52.3990326648748,-92.3497166668508,-23.131402223618764 ) ;
  }

  @Test
  public void test4704() {
    coral.tests.JPFBenchmark.benchmark05(52.4441463958365,18.820981398794515,63.91982477623054 ) ;
  }

  @Test
  public void test4705() {
    coral.tests.JPFBenchmark.benchmark05(-52.48002523556114,-69.7329119563557,-92.67038021224761 ) ;
  }

  @Test
  public void test4706() {
    coral.tests.JPFBenchmark.benchmark05(-5.253072676646923,90.91815002708225,33.857526900997925 ) ;
  }

  @Test
  public void test4707() {
    coral.tests.JPFBenchmark.benchmark05(-52.53087609703728,66.19646414203254,-48.5987946260235 ) ;
  }

  @Test
  public void test4708() {
    coral.tests.JPFBenchmark.benchmark05(-5.2538141501131826E-12,-1.5707963267948966,-28.168117907033817 ) ;
  }

  @Test
  public void test4709() {
    coral.tests.JPFBenchmark.benchmark05(-52.83686353085555,-99.8406665886298,-68.69088844721082 ) ;
  }

  @Test
  public void test4710() {
    coral.tests.JPFBenchmark.benchmark05(-52.90592404245904,-63.60567660575609,-85.76194467725217 ) ;
  }

  @Test
  public void test4711() {
    coral.tests.JPFBenchmark.benchmark05(-5.293955920339377E-23,-1.5707963267948966,-47.12388282418665 ) ;
  }

  @Test
  public void test4712() {
    coral.tests.JPFBenchmark.benchmark05(52.94829578419595,-60.49583038364838,-35.75877718360003 ) ;
  }

  @Test
  public void test4713() {
    coral.tests.JPFBenchmark.benchmark05(53.020275658333816,-69.6105764096917,36.79326074062257 ) ;
  }

  @Test
  public void test4714() {
    coral.tests.JPFBenchmark.benchmark05(-5.336537637884092,-87.0442035441509,84.98401935478066 ) ;
  }

  @Test
  public void test4715() {
    coral.tests.JPFBenchmark.benchmark05(-5.376003385131773E-16,-1.5707963267948966,-66.54424205215304 ) ;
  }

  @Test
  public void test4716() {
    coral.tests.JPFBenchmark.benchmark05(53.76749842492242,21.334739782438632,-56.29520715084697 ) ;
  }

  @Test
  public void test4717() {
    coral.tests.JPFBenchmark.benchmark05(-53.90784968516434,-89.78579404911144,32.89280075882098 ) ;
  }

  @Test
  public void test4718() {
    coral.tests.JPFBenchmark.benchmark05(-53.93699481352774,-15.569597065201137,90.44670466254473 ) ;
  }

  @Test
  public void test4719() {
    coral.tests.JPFBenchmark.benchmark05(-53.953549958561474,-47.182906679464274,-70.1863740735245 ) ;
  }

  @Test
  public void test4720() {
    coral.tests.JPFBenchmark.benchmark05(-5.402365304094769E-17,-1.5707963267948966,-21.839631649060635 ) ;
  }

  @Test
  public void test4721() {
    coral.tests.JPFBenchmark.benchmark05(54.13597126129497,-84.25631443914337,50.41526542769125 ) ;
  }

  @Test
  public void test4722() {
    coral.tests.JPFBenchmark.benchmark05(-54.17467871267676,89.55135910239201,-84.53107481118131 ) ;
  }

  @Test
  public void test4723() {
    coral.tests.JPFBenchmark.benchmark05(5.421010862427522E-20,-0.5567287526833532,89.66592218535628 ) ;
  }

  @Test
  public void test4724() {
    coral.tests.JPFBenchmark.benchmark05(-5.421010862427522E-20,-1.5707963267948963,0.0 ) ;
  }

  @Test
  public void test4725() {
    coral.tests.JPFBenchmark.benchmark05(54.36935475044106,-62.57345248507955,-36.1024651677043 ) ;
  }

  @Test
  public void test4726() {
    coral.tests.JPFBenchmark.benchmark05(-54.72848166052546,40.37827455776758,-34.16016560380295 ) ;
  }

  @Test
  public void test4727() {
    coral.tests.JPFBenchmark.benchmark05(-5.485643593227791E-4,-9.575186309877424,49.99061153248728 ) ;
  }

  @Test
  public void test4728() {
    coral.tests.JPFBenchmark.benchmark05(55.31124693110888,-34.99384459878132,41.5899448102256 ) ;
  }

  @Test
  public void test4729() {
    coral.tests.JPFBenchmark.benchmark05(-5.533807147630596E-4,-0.8574967651434973,45.714437421401556 ) ;
  }

  @Test
  public void test4730() {
    coral.tests.JPFBenchmark.benchmark05(-5.551115123125783E-17,-1.4678523379989765,-34.72788899517692 ) ;
  }

  @Test
  public void test4731() {
    coral.tests.JPFBenchmark.benchmark05(-5.551115123125783E-17,-1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test4732() {
    coral.tests.JPFBenchmark.benchmark05(-5.551115123125783E-17,-1.5707963267948966,3.1415926684935918 ) ;
  }

  @Test
  public void test4733() {
    coral.tests.JPFBenchmark.benchmark05(-5.551115123125783E-17,-1.5707963267948966,3.173965519425406 ) ;
  }

  @Test
  public void test4734() {
    coral.tests.JPFBenchmark.benchmark05(5.551115123125783E-17,-1.5707963267948966,-98.22637278944477 ) ;
  }

  @Test
  public void test4735() {
    coral.tests.JPFBenchmark.benchmark05(-5.551115123125783E-17,-1.9721522630525295E-31,-1.5707963267948966 ) ;
  }

  @Test
  public void test4736() {
    coral.tests.JPFBenchmark.benchmark05(-5.551115123125783E-17,-36.1096177746476,4.71238898166999 ) ;
  }

  @Test
  public void test4737() {
    coral.tests.JPFBenchmark.benchmark05(-5.551115123126215E-17,-1.5707963267948966,0.4293181422228477 ) ;
  }

  @Test
  public void test4738() {
    coral.tests.JPFBenchmark.benchmark05(-5.554024007589512E-4,1.1102230246251565E-16,1.4307154976697495E-17 ) ;
  }

  @Test
  public void test4739() {
    coral.tests.JPFBenchmark.benchmark05(-5.556896873712694E-163,-1.5707963267948966,-41.05137450316832 ) ;
  }

  @Test
  public void test4740() {
    coral.tests.JPFBenchmark.benchmark05(-5.556896873712694E-163,-60.80475680804506,66.96286834625857 ) ;
  }

  @Test
  public void test4741() {
    coral.tests.JPFBenchmark.benchmark05(-55.953611518035814,81.1923765020089,78.99019147125404 ) ;
  }

  @Test
  public void test4742() {
    coral.tests.JPFBenchmark.benchmark05(-56.09268312228224,-60.96380136834378,-55.26407658226739 ) ;
  }

  @Test
  public void test4743() {
    coral.tests.JPFBenchmark.benchmark05(-56.20298267303527,66.53382680845746,-51.07476999365643 ) ;
  }

  @Test
  public void test4744() {
    coral.tests.JPFBenchmark.benchmark05(-5.641698629825018E-17,-98.4310923821431,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test4745() {
    coral.tests.JPFBenchmark.benchmark05(-56.43388890962506,22.823670785300763,84.84770409885888 ) ;
  }

  @Test
  public void test4746() {
    coral.tests.JPFBenchmark.benchmark05(56.517779341559674,7.569699994123667,-3.6242848279904365 ) ;
  }

  @Test
  public void test4747() {
    coral.tests.JPFBenchmark.benchmark05(-5.664854473601202E-17,-1.0669255176984815,-3.675192360037876E-15 ) ;
  }

  @Test
  public void test4748() {
    coral.tests.JPFBenchmark.benchmark05(-56.71177831724557,-5.49106001312019,73.674208230018 ) ;
  }

  @Test
  public void test4749() {
    coral.tests.JPFBenchmark.benchmark05(-56.801361567768026,-58.77795831850623,61.68131004834089 ) ;
  }

  @Test
  public void test4750() {
    coral.tests.JPFBenchmark.benchmark05(-5.6902623986817984E-160,-1.5707963267948966,1.1319004483262992E-231 ) ;
  }

  @Test
  public void test4751() {
    coral.tests.JPFBenchmark.benchmark05(-5.71655708322029E-16,-1.5707963267948966,-64.9682688274532 ) ;
  }

  @Test
  public void test4752() {
    coral.tests.JPFBenchmark.benchmark05(-57.193243619669,40.41860070022847,37.40835460671644 ) ;
  }

  @Test
  public void test4753() {
    coral.tests.JPFBenchmark.benchmark05(57.26001071121175,-96.4720043789084,70.31214448303615 ) ;
  }

  @Test
  public void test4754() {
    coral.tests.JPFBenchmark.benchmark05(-5.728082997062615E-16,-1.5707963267947902,38.75190595213601 ) ;
  }

  @Test
  public void test4755() {
    coral.tests.JPFBenchmark.benchmark05(-57.49028343118032,-72.82913118971996,37.392513382684086 ) ;
  }

  @Test
  public void test4756() {
    coral.tests.JPFBenchmark.benchmark05(57.538377971261525,4.97547649562442,-15.035793796861128 ) ;
  }

  @Test
  public void test4757() {
    coral.tests.JPFBenchmark.benchmark05(-5.770611636116085E-129,-48.62807330062053,-1.5707963267948966 ) ;
  }

  @Test
  public void test4758() {
    coral.tests.JPFBenchmark.benchmark05(-57.77777391186465,54.769739870835764,-86.75092104528927 ) ;
  }

  @Test
  public void test4759() {
    coral.tests.JPFBenchmark.benchmark05(-58.2005647181546,-6.784890419160618,-3.2254394769833112 ) ;
  }

  @Test
  public void test4760() {
    coral.tests.JPFBenchmark.benchmark05(58.23866213737324,-15.764033291856606,-5.039208250023506 ) ;
  }

  @Test
  public void test4761() {
    coral.tests.JPFBenchmark.benchmark05(-5.8268286962501615E-157,-1.5707963267948966,44.85913678641206 ) ;
  }

  @Test
  public void test4762() {
    coral.tests.JPFBenchmark.benchmark05(-5.852095443365248E-98,-41.553861698848415,76.60397685859908 ) ;
  }

  @Test
  public void test4763() {
    coral.tests.JPFBenchmark.benchmark05(58.9051122952458,60.19831979033151,77.23372908381546 ) ;
  }

  @Test
  public void test4764() {
    coral.tests.JPFBenchmark.benchmark05(-58.99008770449989,-22.429628523341364,-2.9503600556841434 ) ;
  }

  @Test
  public void test4765() {
    coral.tests.JPFBenchmark.benchmark05(59.09967799111752,9.188101907220926,19.809311994008198 ) ;
  }

  @Test
  public void test4766() {
    coral.tests.JPFBenchmark.benchmark05(59.22559112974071,-9.439975216038363,11.673818027900012 ) ;
  }

  @Test
  public void test4767() {
    coral.tests.JPFBenchmark.benchmark05(-59.470176141889276,-24.234976310779246,-48.226692800829674 ) ;
  }

  @Test
  public void test4768() {
    coral.tests.JPFBenchmark.benchmark05(-59.62776713535032,15.973776274319277,81.34575317152141 ) ;
  }

  @Test
  public void test4769() {
    coral.tests.JPFBenchmark.benchmark05(-59.637829772462524,22.637722159924593,64.52499904462897 ) ;
  }

  @Test
  public void test4770() {
    coral.tests.JPFBenchmark.benchmark05(59.83967796552568,-69.12746410346291,66.82795404153669 ) ;
  }

  @Test
  public void test4771() {
    coral.tests.JPFBenchmark.benchmark05(-5.992279266476571E-16,-0.8470222963443129,-38.275718764701196 ) ;
  }

  @Test
  public void test4772() {
    coral.tests.JPFBenchmark.benchmark05(-5.998787255582524E-241,-0.11560030946067021,1.472163725455106 ) ;
  }

  @Test
  public void test4773() {
    coral.tests.JPFBenchmark.benchmark05(-60.23550767513586,14.25428296435976,6.491515523732289 ) ;
  }

  @Test
  public void test4774() {
    coral.tests.JPFBenchmark.benchmark05(60.281355331067886,-20.948634530544055,52.514124711543076 ) ;
  }

  @Test
  public void test4775() {
    coral.tests.JPFBenchmark.benchmark05(-60.54567676838214,20.04787522512403,42.69539541029323 ) ;
  }

  @Test
  public void test4776() {
    coral.tests.JPFBenchmark.benchmark05(-6.083936696161252E-15,-1.5707963267948966,-38.770647594450885 ) ;
  }

  @Test
  public void test4777() {
    coral.tests.JPFBenchmark.benchmark05(-6.162975822039155E-33,-1.5707963267948966,-10.995574286109516 ) ;
  }

  @Test
  public void test4778() {
    coral.tests.JPFBenchmark.benchmark05(61.743928669763335,59.90193534744631,78.15810312043888 ) ;
  }

  @Test
  public void test4779() {
    coral.tests.JPFBenchmark.benchmark05(-61.79204021539493,10.351668682869814,-10.151908842232274 ) ;
  }

  @Test
  public void test4780() {
    coral.tests.JPFBenchmark.benchmark05(-61.88286727100019,26.28696907548347,-63.090115001168876 ) ;
  }

  @Test
  public void test4781() {
    coral.tests.JPFBenchmark.benchmark05(62.190172069282625,30.23834348557409,71.94817855318746 ) ;
  }

  @Test
  public void test4782() {
    coral.tests.JPFBenchmark.benchmark05(-6.227438044292599E-9,-1.5707963267948966,12.554794834465957 ) ;
  }

  @Test
  public void test4783() {
    coral.tests.JPFBenchmark.benchmark05(-6.249834945991599E-19,-1.5707963267948966,-15.707962710949923 ) ;
  }

  @Test
  public void test4784() {
    coral.tests.JPFBenchmark.benchmark05(-6.250247422613587E-14,-35.876129339647726,1.5707963267948966 ) ;
  }

  @Test
  public void test4785() {
    coral.tests.JPFBenchmark.benchmark05(-6.273355559940356,95.00192795875006,-92.60356590393116 ) ;
  }

  @Test
  public void test4786() {
    coral.tests.JPFBenchmark.benchmark05(-6.283712631475069E-9,-1.5707963267948966,-161.80774102992623 ) ;
  }

  @Test
  public void test4787() {
    coral.tests.JPFBenchmark.benchmark05(-6.3174603311753045E-176,-1.4947582100242587,-23.951483345723496 ) ;
  }

  @Test
  public void test4788() {
    coral.tests.JPFBenchmark.benchmark05(-6.324762997601443E-18,-4.3368086899420177E-19,-58.11946408984709 ) ;
  }

  @Test
  public void test4789() {
    coral.tests.JPFBenchmark.benchmark05(63.414346371148895,-62.844854121204044,35.82372798904663 ) ;
  }

  @Test
  public void test4790() {
    coral.tests.JPFBenchmark.benchmark05(-6.345135540573421E-14,-1.5707963267948966,50.29095669666347 ) ;
  }

  @Test
  public void test4791() {
    coral.tests.JPFBenchmark.benchmark05(-6.371998550592831E-4,-61.16993682392799,-70.08582726040295 ) ;
  }

  @Test
  public void test4792() {
    coral.tests.JPFBenchmark.benchmark05(63.74863447091411,-70.42338971416673,39.62235952638133 ) ;
  }

  @Test
  public void test4793() {
    coral.tests.JPFBenchmark.benchmark05(-63.7674342600667,11.403774696923577,22.470395001061803 ) ;
  }

  @Test
  public void test4794() {
    coral.tests.JPFBenchmark.benchmark05(-63.91229811054628,-54.7618022783209,-7.895027758513777 ) ;
  }

  @Test
  public void test4795() {
    coral.tests.JPFBenchmark.benchmark05(-6.406665904585923E-145,-10.39502107950679,-78.70197084121193 ) ;
  }

  @Test
  public void test4796() {
    coral.tests.JPFBenchmark.benchmark05(64.18017040825333,48.17887355515279,74.05511265660621 ) ;
  }

  @Test
  public void test4797() {
    coral.tests.JPFBenchmark.benchmark05(-6.420303511398343E-5,-48.66149136737236,-184.05167474343844 ) ;
  }

  @Test
  public void test4798() {
    coral.tests.JPFBenchmark.benchmark05(64.20664650780478,4.10223425050458,-70.52831977325742 ) ;
  }

  @Test
  public void test4799() {
    coral.tests.JPFBenchmark.benchmark05(-64.23712219585221,-64.0893996686844,77.52121146092301 ) ;
  }

  @Test
  public void test4800() {
    coral.tests.JPFBenchmark.benchmark05(6.4292038561126335,-1.5707963267948983,-8.27496902152727 ) ;
  }

  @Test
  public void test4801() {
    coral.tests.JPFBenchmark.benchmark05(6.4293158163894555,-0.5707388429240884,1.5707963267949125 ) ;
  }

  @Test
  public void test4802() {
    coral.tests.JPFBenchmark.benchmark05(6.429343958440829,-1.166015510548057,38.27130203159622 ) ;
  }

  @Test
  public void test4803() {
    coral.tests.JPFBenchmark.benchmark05(6.429677666427982,-1.5707963267948966,2.363118049425659 ) ;
  }

  @Test
  public void test4804() {
    coral.tests.JPFBenchmark.benchmark05(6.429735371215849,-0.4754645075722198,117.45609390879514 ) ;
  }

  @Test
  public void test4805() {
    coral.tests.JPFBenchmark.benchmark05(6.429938494569645,-1.5707963267948966,1.5707963268023661 ) ;
  }

  @Test
  public void test4806() {
    coral.tests.JPFBenchmark.benchmark05(6.430508160592482,-1.5597131762997258,-3.9776221577896917 ) ;
  }

  @Test
  public void test4807() {
    coral.tests.JPFBenchmark.benchmark05(6.432524618659763,-1.567303285374392,1.5707963267948983 ) ;
  }

  @Test
  public void test4808() {
    coral.tests.JPFBenchmark.benchmark05(-64.34064826540884,-50.22797731179867,85.81751424601 ) ;
  }

  @Test
  public void test4809() {
    coral.tests.JPFBenchmark.benchmark05(6.438514203818973,-1.5707963267948948,8.166940799872163 ) ;
  }

  @Test
  public void test4810() {
    coral.tests.JPFBenchmark.benchmark05(6.438662134020267,-16.028106980718732,41.28887471370238 ) ;
  }

  @Test
  public void test4811() {
    coral.tests.JPFBenchmark.benchmark05(6.446253001888601,-1.5707963267948966,84.38070410152135 ) ;
  }

  @Test
  public void test4812() {
    coral.tests.JPFBenchmark.benchmark05(64.48787613760794,-96.17395521750171,22.95840580457707 ) ;
  }

  @Test
  public void test4813() {
    coral.tests.JPFBenchmark.benchmark05(64.535232858509,-87.57681625083256,65.93364457764847 ) ;
  }

  @Test
  public void test4814() {
    coral.tests.JPFBenchmark.benchmark05(-6.457104406237014E-7,-1.5707963267948966,6.283185307199608 ) ;
  }

  @Test
  public void test4815() {
    coral.tests.JPFBenchmark.benchmark05(6.465895818050112,-1.5707868438034998,38.643766135868916 ) ;
  }

  @Test
  public void test4816() {
    coral.tests.JPFBenchmark.benchmark05(64.97790344985711,-96.69451783215032,29.238931937740574 ) ;
  }

  @Test
  public void test4817() {
    coral.tests.JPFBenchmark.benchmark05(-64.97991267548662,-84.26721995323908,82.8156722156242 ) ;
  }

  @Test
  public void test4818() {
    coral.tests.JPFBenchmark.benchmark05(6.499509886735024,-0.18494860037951166,264.6261101624714 ) ;
  }

  @Test
  public void test4819() {
    coral.tests.JPFBenchmark.benchmark05(-6.582053338898275E-16,-8.673617379884035E-19,-31.27510150613695 ) ;
  }

  @Test
  public void test4820() {
    coral.tests.JPFBenchmark.benchmark05(-66.02547336067515,94.61974649837813,8.381160502732016 ) ;
  }

  @Test
  public void test4821() {
    coral.tests.JPFBenchmark.benchmark05(-6.6174449004242214E-24,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test4822() {
    coral.tests.JPFBenchmark.benchmark05(-6.6174449004242214E-24,-1.5707963267948966,51.32080944571745 ) ;
  }

  @Test
  public void test4823() {
    coral.tests.JPFBenchmark.benchmark05(-6.6174449004242214E-24,-35.18414486425499,1.5707963267948966 ) ;
  }

  @Test
  public void test4824() {
    coral.tests.JPFBenchmark.benchmark05(-66.18858203529126,10.663810893317802,-5.780122905837871 ) ;
  }

  @Test
  public void test4825() {
    coral.tests.JPFBenchmark.benchmark05(-6.627130697472793E-16,-1.3449960081355323,65.69504943725754 ) ;
  }

  @Test
  public void test4826() {
    coral.tests.JPFBenchmark.benchmark05(-66.46561047320623,-39.35698402066132,80.59561944845922 ) ;
  }

  @Test
  public void test4827() {
    coral.tests.JPFBenchmark.benchmark05(66.47032813956633,-5.718553335010526,42.91179694483762 ) ;
  }

  @Test
  public void test4828() {
    coral.tests.JPFBenchmark.benchmark05(-66.4747423974889,93.30624076496267,23.27852625180566 ) ;
  }

  @Test
  public void test4829() {
    coral.tests.JPFBenchmark.benchmark05(66.59297067812247,-8.880844213627853,40.33744350867451 ) ;
  }

  @Test
  public void test4830() {
    coral.tests.JPFBenchmark.benchmark05(-66.84738653552442,-57.17278358848923,80.00304231311603 ) ;
  }

  @Test
  public void test4831() {
    coral.tests.JPFBenchmark.benchmark05(-6.753117117815217E-16,-1.5707963267948966,-17.05995910909889 ) ;
  }

  @Test
  public void test4832() {
    coral.tests.JPFBenchmark.benchmark05(-6.776263578034403E-21,-0.8715657045188593,-61.192403677146054 ) ;
  }

  @Test
  public void test4833() {
    coral.tests.JPFBenchmark.benchmark05(6.776263578034403E-21,-1.5707963267948966,0.8048759053354928 ) ;
  }

  @Test
  public void test4834() {
    coral.tests.JPFBenchmark.benchmark05(-6.776263578034403E-21,-6.167903775352916E-7,-1.5707963267948966 ) ;
  }

  @Test
  public void test4835() {
    coral.tests.JPFBenchmark.benchmark05(6.776263578034403E-21,-66.29142035553988,-48.89035489332906 ) ;
  }

  @Test
  public void test4836() {
    coral.tests.JPFBenchmark.benchmark05(67.78481258963336,-20.309689743294882,-54.46516028027673 ) ;
  }

  @Test
  public void test4837() {
    coral.tests.JPFBenchmark.benchmark05(6.781384577331875,-0.47745614417798976,29.445454287921223 ) ;
  }

  @Test
  public void test4838() {
    coral.tests.JPFBenchmark.benchmark05(-67.93144091760493,-54.98049846795878,-3.8959351772523547 ) ;
  }

  @Test
  public void test4839() {
    coral.tests.JPFBenchmark.benchmark05(-67.97866892077973,-16.731150925002453,-92.28118331380901 ) ;
  }

  @Test
  public void test4840() {
    coral.tests.JPFBenchmark.benchmark05(68.0199443493355,-84.92963849900815,-14.537345578964505 ) ;
  }

  @Test
  public void test4841() {
    coral.tests.JPFBenchmark.benchmark05(68.04149274069823,-25.28527454164515,-99.73868686197314 ) ;
  }

  @Test
  public void test4842() {
    coral.tests.JPFBenchmark.benchmark05(6.808342449032442,-1.018076304395957,4.141599339124675 ) ;
  }

  @Test
  public void test4843() {
    coral.tests.JPFBenchmark.benchmark05(-68.14157166869911,-70.5958453717801,-87.73878394440986 ) ;
  }

  @Test
  public void test4844() {
    coral.tests.JPFBenchmark.benchmark05(68.18466271430486,-74.09289759456648,27.329102529305842 ) ;
  }

  @Test
  public void test4845() {
    coral.tests.JPFBenchmark.benchmark05(6.827514199099263,-0.12184600326064954,66.28139641192179 ) ;
  }

  @Test
  public void test4846() {
    coral.tests.JPFBenchmark.benchmark05(-68.3268191679266,-81.88031200468338,-55.425814028470995 ) ;
  }

  @Test
  public void test4847() {
    coral.tests.JPFBenchmark.benchmark05(68.38113344471017,-74.14156444793964,84.9792349791768 ) ;
  }

  @Test
  public void test4848() {
    coral.tests.JPFBenchmark.benchmark05(-6.842277657836021E-49,-47.32784624715478,39.11481731895584 ) ;
  }

  @Test
  public void test4849() {
    coral.tests.JPFBenchmark.benchmark05(68.6207721357361,-6.317136078067051,47.29748000379311 ) ;
  }

  @Test
  public void test4850() {
    coral.tests.JPFBenchmark.benchmark05(-6.868175316250694E-16,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test4851() {
    coral.tests.JPFBenchmark.benchmark05(69.14144938043432,-51.46941416504358,-90.80902021811099 ) ;
  }

  @Test
  public void test4852() {
    coral.tests.JPFBenchmark.benchmark05(-6.915492575289782E-15,-1.5707963267948966,-72.46981882973347 ) ;
  }

  @Test
  public void test4853() {
    coral.tests.JPFBenchmark.benchmark05(69.27364155507752,96.05830105285807,97.60139402510052 ) ;
  }

  @Test
  public void test4854() {
    coral.tests.JPFBenchmark.benchmark05(-6.93024890990831E-4,-9.672817534167395,-1.585224004462418 ) ;
  }

  @Test
  public void test4855() {
    coral.tests.JPFBenchmark.benchmark05(-69.31646903801176,-89.5884117577823,88.63543362145708 ) ;
  }

  @Test
  public void test4856() {
    coral.tests.JPFBenchmark.benchmark05(-6.938809037118465E-18,-1.5707963267948966,-84.82300164126674 ) ;
  }

  @Test
  public void test4857() {
    coral.tests.JPFBenchmark.benchmark05(6.938893903907228E-18,-0.7976553623281415,0.0 ) ;
  }

  @Test
  public void test4858() {
    coral.tests.JPFBenchmark.benchmark05(-6.938893903907228E-18,-1.5220393891197737,51.8323322848382 ) ;
  }

  @Test
  public void test4859() {
    coral.tests.JPFBenchmark.benchmark05(-6.938893903907228E-18,-1.5707963267948966,-0.6499709821261687 ) ;
  }

  @Test
  public void test4860() {
    coral.tests.JPFBenchmark.benchmark05(-6.938893903907228E-18,-54.977760491879,-89.64866165190935 ) ;
  }

  @Test
  public void test4861() {
    coral.tests.JPFBenchmark.benchmark05(69.4616148930923,93.80380864721488,46.17799474631008 ) ;
  }

  @Test
  public void test4862() {
    coral.tests.JPFBenchmark.benchmark05(69.50476044857152,49.927845510115816,83.79927598835789 ) ;
  }

  @Test
  public void test4863() {
    coral.tests.JPFBenchmark.benchmark05(69.90405160038077,-39.92104581022089,72.44869029706962 ) ;
  }

  @Test
  public void test4864() {
    coral.tests.JPFBenchmark.benchmark05(-69.99669768944399,-61.478473711471196,-65.19256911086708 ) ;
  }

  @Test
  public void test4865() {
    coral.tests.JPFBenchmark.benchmark05(-7.001767062955989E-16,28.70353755551325,76.34934061297542 ) ;
  }

  @Test
  public void test4866() {
    coral.tests.JPFBenchmark.benchmark05(-7.01378991682689E-192,-0.9324338164702343,50.666636027028915 ) ;
  }

  @Test
  public void test4867() {
    coral.tests.JPFBenchmark.benchmark05(-7.061789203599464E-15,-1.5707963267948966,67.3368319213583 ) ;
  }

  @Test
  public void test4868() {
    coral.tests.JPFBenchmark.benchmark05(-70.65498800927463,-99.96996954979036,9.856326702784983 ) ;
  }

  @Test
  public void test4869() {
    coral.tests.JPFBenchmark.benchmark05(70.66238193145821,-5.6525718333374755,17.305046872688308 ) ;
  }

  @Test
  public void test4870() {
    coral.tests.JPFBenchmark.benchmark05(70.83909127688057,50.96276907395787,-18.654804648095123 ) ;
  }

  @Test
  public void test4871() {
    coral.tests.JPFBenchmark.benchmark05(7.085118474773201,-0.3879446431501687,-6.318600749518006 ) ;
  }

  @Test
  public void test4872() {
    coral.tests.JPFBenchmark.benchmark05(-7.090911822732835E-17,-0.015990752771811303,-7.621348433015556E-17 ) ;
  }

  @Test
  public void test4873() {
    coral.tests.JPFBenchmark.benchmark05(70.97190716583614,-39.271815593806835,84.1785918648973 ) ;
  }

  @Test
  public void test4874() {
    coral.tests.JPFBenchmark.benchmark05(-7.105427357601002E-15,-0.10755597703395536,69.33318161614359 ) ;
  }

  @Test
  public void test4875() {
    coral.tests.JPFBenchmark.benchmark05(-7.105427357601002E-15,-0.62104985899889,9.678658326557567 ) ;
  }

  @Test
  public void test4876() {
    coral.tests.JPFBenchmark.benchmark05(-7.105427357601002E-15,-1.0617067911178837,62.210504579082084 ) ;
  }

  @Test
  public void test4877() {
    coral.tests.JPFBenchmark.benchmark05(-7.105427357601002E-15,-1.1562443621785308,-56.518194282254 ) ;
  }

  @Test
  public void test4878() {
    coral.tests.JPFBenchmark.benchmark05(-7.105427357601002E-15,-1.169141020852554,-78.9910365716893 ) ;
  }

  @Test
  public void test4879() {
    coral.tests.JPFBenchmark.benchmark05(-7.105427357601002E-15,-1.2771307909084622,61.48778012393602 ) ;
  }

  @Test
  public void test4880() {
    coral.tests.JPFBenchmark.benchmark05(-7.105427357601002E-15,-1.5707963267948912,-8.507116252909142 ) ;
  }

  @Test
  public void test4881() {
    coral.tests.JPFBenchmark.benchmark05(-7.105427357601002E-15,-1.5707963267948948,69.64655844887983 ) ;
  }

  @Test
  public void test4882() {
    coral.tests.JPFBenchmark.benchmark05(-7.105427357601002E-15,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test4883() {
    coral.tests.JPFBenchmark.benchmark05(-7.105427357601002E-15,-1.5707963267948966,17.278759594743864 ) ;
  }

  @Test
  public void test4884() {
    coral.tests.JPFBenchmark.benchmark05(-7.105427357601002E-15,-1.5707963267948966,33.019708777115824 ) ;
  }

  @Test
  public void test4885() {
    coral.tests.JPFBenchmark.benchmark05(-7.105427357601002E-15,-1.5707963267948966,-62.017110433495205 ) ;
  }

  @Test
  public void test4886() {
    coral.tests.JPFBenchmark.benchmark05(-7.105427357601002E-15,-1.5707963267948966,72.76693055062958 ) ;
  }

  @Test
  public void test4887() {
    coral.tests.JPFBenchmark.benchmark05(-7.105427357601002E-15,-15.855128466396891,4.788606341220041E-16 ) ;
  }

  @Test
  public void test4888() {
    coral.tests.JPFBenchmark.benchmark05(-7.105427357601002E-15,-173.96893874335885,78.28637297787836 ) ;
  }

  @Test
  public void test4889() {
    coral.tests.JPFBenchmark.benchmark05(-7.105427357601002E-15,-1.7763568394002505E-15,-90.95456706379301 ) ;
  }

  @Test
  public void test4890() {
    coral.tests.JPFBenchmark.benchmark05(-7.105427357601002E-15,-54.82995227888094,-68.19296148792863 ) ;
  }

  @Test
  public void test4891() {
    coral.tests.JPFBenchmark.benchmark05(-7.105427357601002E-15,-61.254733595622476,10.932912847933277 ) ;
  }

  @Test
  public void test4892() {
    coral.tests.JPFBenchmark.benchmark05(-7.105427357601002E-15,-72.97893575889304,26.10309769989945 ) ;
  }

  @Test
  public void test4893() {
    coral.tests.JPFBenchmark.benchmark05(-7.131954737631122E-15,-1.5707963267948966,20.435991975848182 ) ;
  }

  @Test
  public void test4894() {
    coral.tests.JPFBenchmark.benchmark05(71.34692577086952,-62.051562175347954,-8.244706277333535 ) ;
  }

  @Test
  public void test4895() {
    coral.tests.JPFBenchmark.benchmark05(-71.35968936708935,67.07526931892701,71.84901246251454 ) ;
  }

  @Test
  public void test4896() {
    coral.tests.JPFBenchmark.benchmark05(-71.39238656557892,-31.690922628672723,86.08272289626572 ) ;
  }

  @Test
  public void test4897() {
    coral.tests.JPFBenchmark.benchmark05(71.43366255932568,-40.946192994173614,57.36835160782485 ) ;
  }

  @Test
  public void test4898() {
    coral.tests.JPFBenchmark.benchmark05(-7.144086119679781E-16,5.551115123125783E-17,-87.18765615471355 ) ;
  }

  @Test
  public void test4899() {
    coral.tests.JPFBenchmark.benchmark05(-71.81753257415636,-40.95973642266743,-24.872894714534638 ) ;
  }

  @Test
  public void test4900() {
    coral.tests.JPFBenchmark.benchmark05(-7.213264545145106E-130,-3.5256894475582505E-4,49.612974484561754 ) ;
  }

  @Test
  public void test4901() {
    coral.tests.JPFBenchmark.benchmark05(-72.2602823176634,-70.43095831821971,45.75946332557646 ) ;
  }

  @Test
  public void test4902() {
    coral.tests.JPFBenchmark.benchmark05(7.235277166408278,-78.97252440399183,-8.61909006218496 ) ;
  }

  @Test
  public void test4903() {
    coral.tests.JPFBenchmark.benchmark05(72.41328302326147,63.866478138887004,-61.00375716711173 ) ;
  }

  @Test
  public void test4904() {
    coral.tests.JPFBenchmark.benchmark05(-72.45954109957944,51.26568743354812,32.340594365001266 ) ;
  }

  @Test
  public void test4905() {
    coral.tests.JPFBenchmark.benchmark05(-7.28656982984233E-4,14.43498611590202,100.0 ) ;
  }

  @Test
  public void test4906() {
    coral.tests.JPFBenchmark.benchmark05(-7.288112333274668,-71.31628084643631,-29.573043613026883 ) ;
  }

  @Test
  public void test4907() {
    coral.tests.JPFBenchmark.benchmark05(72.89704792758562,55.377262858535175,49.77239965757528 ) ;
  }

  @Test
  public void test4908() {
    coral.tests.JPFBenchmark.benchmark05(-72.94613392221507,-85.80998753678783,62.07814067588998 ) ;
  }

  @Test
  public void test4909() {
    coral.tests.JPFBenchmark.benchmark05(72.99161728149477,-48.55025363553851,-98.24374118022654 ) ;
  }

  @Test
  public void test4910() {
    coral.tests.JPFBenchmark.benchmark05(-73.02964398081858,16.64230763000279,-0.6723137196601243 ) ;
  }

  @Test
  public void test4911() {
    coral.tests.JPFBenchmark.benchmark05(73.4131931206172,-73.4566148816419,-18.134220868064816 ) ;
  }

  @Test
  public void test4912() {
    coral.tests.JPFBenchmark.benchmark05(-7.347769421857546E-16,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test4913() {
    coral.tests.JPFBenchmark.benchmark05(-7.411774373178304E-5,-1.4651659037569096,22.588642464596415 ) ;
  }

  @Test
  public void test4914() {
    coral.tests.JPFBenchmark.benchmark05(-7.41737614549256E-15,-1.5707963267948948,-48.77906973104291 ) ;
  }

  @Test
  public void test4915() {
    coral.tests.JPFBenchmark.benchmark05(74.24506351288659,-96.82744385771582,42.652052003552484 ) ;
  }

  @Test
  public void test4916() {
    coral.tests.JPFBenchmark.benchmark05(75.21776827294929,-4.964806417467059,6.278587497188681 ) ;
  }

  @Test
  public void test4917() {
    coral.tests.JPFBenchmark.benchmark05(-75.53295667714524,-87.90156457000231,-56.201705119756284 ) ;
  }

  @Test
  public void test4918() {
    coral.tests.JPFBenchmark.benchmark05(-75.79886726195969,-46.08561139247138,38.96964434272559 ) ;
  }

  @Test
  public void test4919() {
    coral.tests.JPFBenchmark.benchmark05(75.86161493145326,58.82790886400994,37.15636300106729 ) ;
  }

  @Test
  public void test4920() {
    coral.tests.JPFBenchmark.benchmark05(7.5925910867736315,-1.0179251430530527,73.3868668785312 ) ;
  }

  @Test
  public void test4921() {
    coral.tests.JPFBenchmark.benchmark05(-75.98300806846578,-55.54554273317018,10.403504290559809 ) ;
  }

  @Test
  public void test4922() {
    coral.tests.JPFBenchmark.benchmark05(76.2794208159051,8.094883877434071,78.94494584772102 ) ;
  }

  @Test
  public void test4923() {
    coral.tests.JPFBenchmark.benchmark05(-76.42219779011569,57.73272902200691,16.1448787102358 ) ;
  }

  @Test
  public void test4924() {
    coral.tests.JPFBenchmark.benchmark05(-7.674499240725163E-4,8.673617379884035E-19,-73.76401123050607 ) ;
  }

  @Test
  public void test4925() {
    coral.tests.JPFBenchmark.benchmark05(7.698918672825013,-3.469446951953614E-18,-21.56700650680601 ) ;
  }

  @Test
  public void test4926() {
    coral.tests.JPFBenchmark.benchmark05(-7.703719777548943E-34,-0.8701422007360151,-55.01084746237486 ) ;
  }

  @Test
  public void test4927() {
    coral.tests.JPFBenchmark.benchmark05(-7.703719777548943E-34,-1.5707963267948966,1.571040473088762 ) ;
  }

  @Test
  public void test4928() {
    coral.tests.JPFBenchmark.benchmark05(7.761822372158761,-85.51525497677054,28.745464663248953 ) ;
  }

  @Test
  public void test4929() {
    coral.tests.JPFBenchmark.benchmark05(-7.764265093829522,-90.7860586645056,-85.72648661099973 ) ;
  }

  @Test
  public void test4930() {
    coral.tests.JPFBenchmark.benchmark05(-77.70269917244639,85.27363407733702,-23.490461288361985 ) ;
  }

  @Test
  public void test4931() {
    coral.tests.JPFBenchmark.benchmark05(-77.82607070720131,-66.93390945535502,-94.8034018684282 ) ;
  }

  @Test
  public void test4932() {
    coral.tests.JPFBenchmark.benchmark05(-7.795805705677396E-9,-1.5707963267948966,201.04289274054602 ) ;
  }

  @Test
  public void test4933() {
    coral.tests.JPFBenchmark.benchmark05(78.10661384155543,38.68383338465026,65.84263510424918 ) ;
  }

  @Test
  public void test4934() {
    coral.tests.JPFBenchmark.benchmark05(-78.21541804518344,91.13132621622586,-62.835891646941946 ) ;
  }

  @Test
  public void test4935() {
    coral.tests.JPFBenchmark.benchmark05(78.31878876612748,0,0 ) ;
  }

  @Test
  public void test4936() {
    coral.tests.JPFBenchmark.benchmark05(-78.3452397011981,-87.40853242615958,84.80217868610441 ) ;
  }

  @Test
  public void test4937() {
    coral.tests.JPFBenchmark.benchmark05(-7.853622648638776E-11,-1.5073872197245826,-23.569757658017448 ) ;
  }

  @Test
  public void test4938() {
    coral.tests.JPFBenchmark.benchmark05(7.866532453554112,0.0,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test4939() {
    coral.tests.JPFBenchmark.benchmark05(-78.71611208668256,41.41960032920221,60.08479473970843 ) ;
  }

  @Test
  public void test4940() {
    coral.tests.JPFBenchmark.benchmark05(-78.78504925387173,-42.37710024341557,-50.336758403580674 ) ;
  }

  @Test
  public void test4941() {
    coral.tests.JPFBenchmark.benchmark05(79.07473072203334,80.3880843443927,8.66465793343312 ) ;
  }

  @Test
  public void test4942() {
    coral.tests.JPFBenchmark.benchmark05(79.08153341902181,-46.05824394884148,84.83344366966892 ) ;
  }

  @Test
  public void test4943() {
    coral.tests.JPFBenchmark.benchmark05(-79.19316925852296,-70.84227321659623,-14.645201486827972 ) ;
  }

  @Test
  public void test4944() {
    coral.tests.JPFBenchmark.benchmark05(79.26035099583683,88.91668653660955,-22.083839970863053 ) ;
  }

  @Test
  public void test4945() {
    coral.tests.JPFBenchmark.benchmark05(-79.26999265748299,-48.742498741041416,64.70070652642121 ) ;
  }

  @Test
  public void test4946() {
    coral.tests.JPFBenchmark.benchmark05(-7.940111592877257E-15,-1.5707963267948966,98.53162073390877 ) ;
  }

  @Test
  public void test4947() {
    coral.tests.JPFBenchmark.benchmark05(79.57131515877523,-77.6102411490458,76.0018000564516 ) ;
  }

  @Test
  public void test4948() {
    coral.tests.JPFBenchmark.benchmark05(-7.959328122325774E-6,-2.2565913524593006E-5,-20.384003848495123 ) ;
  }

  @Test
  public void test4949() {
    coral.tests.JPFBenchmark.benchmark05(-79.63585904899986,0.7384209091632243,-78.565021634594 ) ;
  }

  @Test
  public void test4950() {
    coral.tests.JPFBenchmark.benchmark05(80.01427093316084,26.707561916122273,33.326271691773655 ) ;
  }

  @Test
  public void test4951() {
    coral.tests.JPFBenchmark.benchmark05(-80.07296968081768,-50.78625522281539,-53.528355537713914 ) ;
  }

  @Test
  public void test4952() {
    coral.tests.JPFBenchmark.benchmark05(-8.008332380732404E-146,-1.5707963267948966,-1.5707963267948983 ) ;
  }

  @Test
  public void test4953() {
    coral.tests.JPFBenchmark.benchmark05(-80.16915026433462,-66.57554876018905,-96.66558791942816 ) ;
  }

  @Test
  public void test4954() {
    coral.tests.JPFBenchmark.benchmark05(-8.046740806452708E-14,-1.5707963267948966,-92.53720492725104 ) ;
  }

  @Test
  public void test4955() {
    coral.tests.JPFBenchmark.benchmark05(80.6178354934548,-56.26770855805787,-76.49914879169258 ) ;
  }

  @Test
  public void test4956() {
    coral.tests.JPFBenchmark.benchmark05(-8.068361309535035,-96.34171896907249,-69.16995418198493 ) ;
  }

  @Test
  public void test4957() {
    coral.tests.JPFBenchmark.benchmark05(-8.073488361672986,-88.40991711272885,30.069849297278694 ) ;
  }

  @Test
  public void test4958() {
    coral.tests.JPFBenchmark.benchmark05(-8.074467662173574E-5,-1.5707963267948966,122.52821879831652 ) ;
  }

  @Test
  public void test4959() {
    coral.tests.JPFBenchmark.benchmark05(-80.76741818609193,-47.14237340206044,-66.44669004851553 ) ;
  }

  @Test
  public void test4960() {
    coral.tests.JPFBenchmark.benchmark05(-80.86634658352085,-7.096997952093616,93.54710273083441 ) ;
  }

  @Test
  public void test4961() {
    coral.tests.JPFBenchmark.benchmark05(80.87100254392658,78.43375323836418,-79.41389559819403 ) ;
  }

  @Test
  public void test4962() {
    coral.tests.JPFBenchmark.benchmark05(81.20989894232056,48.91500059679629,-9.591141787748143 ) ;
  }

  @Test
  public void test4963() {
    coral.tests.JPFBenchmark.benchmark05(-8.1214138794100775E-115,-3.8977672947777156,1.5707963267948966 ) ;
  }

  @Test
  public void test4964() {
    coral.tests.JPFBenchmark.benchmark05(-81.21441103836544,81.37755591303244,-85.943752371547 ) ;
  }

  @Test
  public void test4965() {
    coral.tests.JPFBenchmark.benchmark05(-81.32450213326632,-50.539033463664595,-44.66620381641617 ) ;
  }

  @Test
  public void test4966() {
    coral.tests.JPFBenchmark.benchmark05(-81.35943341791327,78.40832618030188,-5.0414483829491274 ) ;
  }

  @Test
  public void test4967() {
    coral.tests.JPFBenchmark.benchmark05(81.62612756533446,-23.891217168134474,46.54376694630798 ) ;
  }

  @Test
  public void test4968() {
    coral.tests.JPFBenchmark.benchmark05(-81.70382097484752,-75.6141865765558,37.869967734361694 ) ;
  }

  @Test
  public void test4969() {
    coral.tests.JPFBenchmark.benchmark05(81.70541502907852,9.860681687089937,77.93299301279134 ) ;
  }

  @Test
  public void test4970() {
    coral.tests.JPFBenchmark.benchmark05(-81.98246356014786,-40.03064471048445,37.5993583195085 ) ;
  }

  @Test
  public void test4971() {
    coral.tests.JPFBenchmark.benchmark05(82.14401782693875,27.734750415928858,-87.85404677654722 ) ;
  }

  @Test
  public void test4972() {
    coral.tests.JPFBenchmark.benchmark05(82.19902563868843,-64.06783124967632,99.2539898805747 ) ;
  }

  @Test
  public void test4973() {
    coral.tests.JPFBenchmark.benchmark05(-82.32096905247911,-97.33510797716858,63.76939475361726 ) ;
  }

  @Test
  public void test4974() {
    coral.tests.JPFBenchmark.benchmark05(82.66010501588846,-28.36598310177108,-62.106712549768204 ) ;
  }

  @Test
  public void test4975() {
    coral.tests.JPFBenchmark.benchmark05(-82.73464887167934,-19.93904996624063,-46.100411924742126 ) ;
  }

  @Test
  public void test4976() {
    coral.tests.JPFBenchmark.benchmark05(82.84905360286899,19.202733934395383,-99.17287990296104 ) ;
  }

  @Test
  public void test4977() {
    coral.tests.JPFBenchmark.benchmark05(-83.12572423987162,-57.75215947375387,-64.64934057090764 ) ;
  }

  @Test
  public void test4978() {
    coral.tests.JPFBenchmark.benchmark05(-83.1341158485584,80.45586942929265,-36.341157938795334 ) ;
  }

  @Test
  public void test4979() {
    coral.tests.JPFBenchmark.benchmark05(-83.3252186974751,-85.13778619960593,-24.047961082858535 ) ;
  }

  @Test
  public void test4980() {
    coral.tests.JPFBenchmark.benchmark05(83.67307660446258,-93.51402774420382,72.7352298497774 ) ;
  }

  @Test
  public void test4981() {
    coral.tests.JPFBenchmark.benchmark05(-8.376499592791906E-4,-6.912902266075546,0 ) ;
  }

  @Test
  public void test4982() {
    coral.tests.JPFBenchmark.benchmark05(83.787465490942,19.204241891437036,99.68579425101981 ) ;
  }

  @Test
  public void test4983() {
    coral.tests.JPFBenchmark.benchmark05(8.416886705207745,53.3632944148448,50.946164082360156 ) ;
  }

  @Test
  public void test4984() {
    coral.tests.JPFBenchmark.benchmark05(-8.418364871780258E-5,-10.025314209609753,-9.428684459708869 ) ;
  }

  @Test
  public void test4985() {
    coral.tests.JPFBenchmark.benchmark05(-84.24331354187949,44.22432319902782,-71.46704616523269 ) ;
  }

  @Test
  public void test4986() {
    coral.tests.JPFBenchmark.benchmark05(-8.462008789404123,23.29179354017006,-12.543377928835355 ) ;
  }

  @Test
  public void test4987() {
    coral.tests.JPFBenchmark.benchmark05(-8.470329472543003E-22,-10.392981932953289,-16.376074157345887 ) ;
  }

  @Test
  public void test4988() {
    coral.tests.JPFBenchmark.benchmark05(-8.470329472543003E-22,-1.5625237732146788,92.59785116233695 ) ;
  }

  @Test
  public void test4989() {
    coral.tests.JPFBenchmark.benchmark05(-84.75016284719716,-82.82863694250497,82.59701126883542 ) ;
  }

  @Test
  public void test4990() {
    coral.tests.JPFBenchmark.benchmark05(-84.76650865605765,-48.804789023736326,-79.73181608870217 ) ;
  }

  @Test
  public void test4991() {
    coral.tests.JPFBenchmark.benchmark05(-8.486330378512503E-14,-1.5707963267948966,-1.5707963267948968 ) ;
  }

  @Test
  public void test4992() {
    coral.tests.JPFBenchmark.benchmark05(84.88068802384447,-53.605746909089014,-27.98523758116525 ) ;
  }

  @Test
  public void test4993() {
    coral.tests.JPFBenchmark.benchmark05(-8.503998283908528E-16,-1.5707963267948966,8.655828552955095 ) ;
  }

  @Test
  public void test4994() {
    coral.tests.JPFBenchmark.benchmark05(-85.23499831947707,-81.06619540456286,-30.447299737846762 ) ;
  }

  @Test
  public void test4995() {
    coral.tests.JPFBenchmark.benchmark05(85.3210541179011,-50.6872551401534,-54.16966147235218 ) ;
  }

  @Test
  public void test4996() {
    coral.tests.JPFBenchmark.benchmark05(-85.9348222702464,94.23499683805122,20.092135862075438 ) ;
  }

  @Test
  public void test4997() {
    coral.tests.JPFBenchmark.benchmark05(85.94967645429736,-77.32959168692315,3.2644715208288204 ) ;
  }

  @Test
  public void test4998() {
    coral.tests.JPFBenchmark.benchmark05(-8.645163535653227E-224,-0.022117318843612004,-72.94196775798073 ) ;
  }

  @Test
  public void test4999() {
    coral.tests.JPFBenchmark.benchmark05(86.72188107031428,66.91118239981034,-59.896931128519924 ) ;
  }

  @Test
  public void test5000() {
    coral.tests.JPFBenchmark.benchmark05(-8.673617379884035E-19,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test5001() {
    coral.tests.JPFBenchmark.benchmark05(-8.673617379884035E-19,-3.440294521017128,46.69970593935602 ) ;
  }

  @Test
  public void test5002() {
    coral.tests.JPFBenchmark.benchmark05(8.673617379884035E-19,-72.7714152799315,-1.5707963267948966 ) ;
  }

  @Test
  public void test5003() {
    coral.tests.JPFBenchmark.benchmark05(86.77541755043478,17.093732418377996,-59.723737124191125 ) ;
  }

  @Test
  public void test5004() {
    coral.tests.JPFBenchmark.benchmark05(-8.682651365176084E-165,-0.6734078708714835,-4.5782965352899985E-149 ) ;
  }

  @Test
  public void test5005() {
    coral.tests.JPFBenchmark.benchmark05(-86.86795418690369,16.06729512443559,27.109961567624367 ) ;
  }

  @Test
  public void test5006() {
    coral.tests.JPFBenchmark.benchmark05(86.93572387406346,46.01936074712302,0.8750242914836548 ) ;
  }

  @Test
  public void test5007() {
    coral.tests.JPFBenchmark.benchmark05(-8.747191151449566E-20,-35.83558483267507,7.853981633974706 ) ;
  }

  @Test
  public void test5008() {
    coral.tests.JPFBenchmark.benchmark05(-87.63479425592786,38.47870587094056,28.38385190030155 ) ;
  }
}
