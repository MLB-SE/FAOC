import org.junit.Test;

public class Sample29Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark29(-0.5207102756979509 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark29(-1.4941406249999991 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark29(-1.494140625 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark29(-28.47914412054004 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark29(-29.764551415847748 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark29(34.00787743821698 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark29(-35.49222713815878 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark29(3.732074048217072 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark29(-40.09910883268136 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark29(-40.190640204653576 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark29(-40.19140625 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark29(40.777771531590446 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark29(57.845489215858834 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark29(-709.0779881257833 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark29(-709.1416668217021 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark29(-709.2034372393125 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark29(-709.2533084750396 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark29(-709.2933360107651 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark29(-709.6158091577613 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark29(-709.6610818502276 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark29(-709.7448386753434 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark29(-709.9093584851651 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark29(-709.9288646268349 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark29(-709.9903955868466 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark29(-709.9993096506208 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark29(-709.9998709788578 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark29(716.5730191469303 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark29(-719.2295080935584 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark29(-726.3356318531304 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark29(-729.4955084245796 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark29(-732.2127404032277 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark29(-735.6731606817698 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark29(-742.6251071302682 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark29(-743.4111172705719 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark29(-745.4092660585061 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark29(-745.5313576716788 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark29(-745.9224965012788 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark29(-745.9999999824878 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark29(-745.9999999999999 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark29(-746.0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark29(-746.0000000000005 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark29(-746.0000000000307 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark29(-748.1914062501214 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark29(-748.191406355944 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark29(-76.70202990234264 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark29(-768.9889147207375 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark29(86.33147128472089 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark29(-88.20062445600814 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark29(-9.144917371624686 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark29(93.99829130008862 ) ;
  }
}
