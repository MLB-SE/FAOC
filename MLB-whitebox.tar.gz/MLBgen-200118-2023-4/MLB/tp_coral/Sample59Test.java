import org.junit.Test;

public class Sample59Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-0.011040310483494409,-28.540804884879947,-29.30047692812983 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-0.01159977310492811,1095.8151643120684,-1233.5458253470883 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-0.01177690052402769,0.0,15.879634245101883 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-0.011834262068812074,-3.56844198580755E-4,2.220446049250313E-16 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-0.014649043887863977,-38.28153145052946,48.22362045456676 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-0.02094903807321119,0.9599345355610652,-100.0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-0.031247970442013884,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-0.03711165542794104,-5.009499799699334,49.28966859722868 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-0.038681536012646234,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-0.054289074709433095,-26.15711445738047,47.43052999591051 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-0.05710481710339089,4.0607069397050388E-115,-1.8465957235571472E-127 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark59(0,0,0.14127903722445012,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-0.33132983027867624,1230.3873715737145,-1357.206893861383 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-0.33501566389047355,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-1.0,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark59(0.0,100.0,-3.8820852255015256E-5,0.05550679597672545,-9.790153573559627 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-1062.0041461716623,0,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark59(-0.01224183883932406,61.09437846698256,-0.018870541929672725,-28.95868271909356,6.938893903907228E-18 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-12.546504158129878,0,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-1.3877787807814457E-17,-56.941846785243946,96.11716005777612 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-1.7763568394002505E-15,0,0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-2.6115820495217434,0,0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-2711.0446447637887,0,0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-2.7755575615628914E-17,-13.648341219700086,0.02139197215063504 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-41.58975537357603,0,0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-4.440892098500626E-16,0,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark59(0,0,49.41549609116015,61.54897263658998,60.49116916720678 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-53.06752106151238,0,0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-54.6407868855352,0,0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-5.551115123125783E-17,0,0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-5.551115123125783E-17,47.09313659039228,-78.74315152604731 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-5.551115123125783E-17,-96.138589414299,88.60176802161587 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark59(-0.07049688855281995,13.227183754743871,-2.8507985187599017E-37,-19.676996852424562,0.07982906835708548 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-72.13347543687303,76.73700253435598,-76.02177003144249 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-8.881784197001252E-16,100.0,-100.0 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark59(0,0,90.97513838577305,0,0 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-9.70187194028829E-15,4.201845421655799,-0.3738348675796601 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark59(0,-100.0,-0.0020840667264821282,0.06285673248394105,-23.121263768558734 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark59(0,100.0,-0.00423304415060706,5.319113215809317,-6.819113215809317 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark59(0,100.0,-0.014060027325455582,-16.153637469618175,0.09724102882393026 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark59(0,100.0,-0.017210688062582274,0.24409476168336264,-1.8148910884782596 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark59(0,100.0,-0.020291250030760533,4.381857208208382,-5.938498693763762 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark59(0,100.0,-0.05544228061817581,-100.0,0.015707963267948877 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark59(0,100.0,-0.05966787901052018,0.12134214192824544,-12.945183774024272 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark59(0,-100.0,-0.8657464782153964,-2.4042895196218783,2.3418476178494285 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark59(0,-100.0,-1.1102230246251565E-16,0.013643346474769905,-35.626437992543345 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark59(0,100.0,-5.551115123125783E-17,-41.90075056217232,0.03748850093900213 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark59(0,10.28565704533522,-1.7763568394002505E-15,0.030237703557525863,-14.354456753961419 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark59(0,12.296049382771661,-0.056304306641352886,12.464421910920342,-15.606022175388269 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark59(0,1.5914502274490019,-0.027826483151006998,-37.734856610808045,0.041627197447597464 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark59(0,-19.161925600794405,-0.04337790723737872,-13.8389745846018,0.11350525410622758 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark59(0,21.66723974446735,-0.47631988926891017,5.14534948125449,-6.640050063775479 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark59(0,237.36022783032755,-8.881784197001252E-16,-2293.6748933925846,1.6479873021779667E-15 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark59(0,27.88587763467567,-0.03064889224719769,0.8360456657661555,-2.406841992561052 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark59(0,28.693515059697035,-6.819861608322171,96.44434575178633,87.79473676742359 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark59(0,-3.1579834686490855,-0.05286800317259482,0.14749757608772657,-3.672220831127963 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark59(0,-33.98282370399109,97.46805935458838,23.09385620646151,-71.09144777244481 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark59(0,36.40984640978682,-0.14066751778195313,1.3877787807814457E-17,-1423.1943339605073 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark59(0,37.553428214778684,-0.010501419133335188,0.058287078274212485,-26.474116262531037 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark59(0,-40.20636145533111,-1.1102230246251565E-16,-12.679487273596846,0.008770476632790361 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark59(0,42.27456871683277,-1.1102230246251565E-16,0.10655057184768346,-1.6065505718476834 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark59(0,47.95357492749413,-2.7755575615628914E-17,-1.7612882313361644,7.105427357601002E-15 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark59(0,48.556928231333316,-0.059951581335380644,0.13947230035338798,-11.262425032174036 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark59(-0.49510415371049227,7.005172365788951,-0.031931579792567236,0.17513225537524688,-7.895944134141334 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark59(0,-53.1827518195539,-3.552713678800501E-15,-28.10213330556215,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark59(0,53.843311441389645,-0.032980425584590585,-2.7809415643243365,-0.4658978480358628 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark59(0,-54.69822117290898,-0.029856073754921806,4.922452182670866E-4,-28.285315002652965 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark59(0,5.883050679228732,-5.372812031444657E-6,0.4453010509426715,-2.016097377737568 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark59(0,62.73330176110947,-0.1735480249228423,-11.922396881404444,10.655114369085709 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark59(0,63.62764334567015,-0.001455488226965608,0.035557056832118406,-0.035557056832118406 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark59(0,-63.96954917386255,-0.0273665644729372,-78.1275912919054,0.008746445268496491 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark59(0,-64.23932041460284,-0.060591313400566484,-25.65393726795564,-5.691192941147396 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark59(0,-64.95388602585145,-0.020650504333279064,3.913387124614768E-5,-1.5599790626762824 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark59(0,-66.41950786467567,-0.035845192969030465,0.2607741557756498,-1.8315704825705463 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark59(0,66.55124021176023,-2.7755575615628914E-17,-34.66416250140499,34.66416255946542 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark59(0,74.52490975630305,-0.011070285776611111,0.47120507477411727,-2.0420014015690136 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark59(0,81.2693785846862,-0.005383509817670114,-60.52074683765258,0.025949648752956023 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark59(0,-92.19277471931257,-0.002334141458103624,-1.5254156908843102,0.23995628958420487 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark59(0,-9.414857226522118,-0.04135677980423397,-4.540597628288856,4.54059762826839 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark59(0,-95.85186206083137,-0.053062141758861286,0.04191679576211629,-14.919396684571836 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark59(0,95.9969785878526,-1.1102230246251565E-16,-1.6000389431051971,0.029242616310300562 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark59(0,96.17536454037696,-0.051705901542656196,-1.316785604491672,1.160378831130812 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark59(0,-98.06418135337464,-0.18384732991654734,-6.51737176470639,0.24101683677172178 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark59(0,-98.75648910710613,-2.7755575615628914E-17,-0.7755246372071558,0.7755246372071557 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark59(0,99.95497812346095,-0.047851446873074285,37.124438258118985,-4.133856045620832E-4 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark59(0,-99.99972406891949,-0.024564802328883875,-11.43998938483491,9.869193058040013 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark59(0,99.99992436161367,-1.598567029803223E-7,-2.131813099816419,0.5610167730215223 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark59(-100.0,0.044064641590466636,-0.030631614399740936,-51.55343735483016,0.028763986427870557 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark59(-100.0,-22.133780243446633,-0.002942566312737427,-4.530585514582944,4.440892098500626E-16 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark59(-100.0,3.552713678800501E-15,-0.04514153105406516,0.06888110078586188,-22.804460278272856 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark59(-100.0,37.39212305197591,-5.551115123125783E-17,-3.336146275677663,2.220446049250313E-16 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark59(-100.0,-4.667342192831103,-2.7755575615628914E-17,0.11414307805211621,-13.761643312799446 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark59(-100.0,-64.71319346624719,-0.04116877129446969,-97.52229150134788,2.6776448862104567E-15 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark59(-100.0,-69.2740850310265,-0.050970144751903125,2.0129920037939785E-5,-22.88852670454301 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark59(-100.0,-73.68317198111689,-5.551115123125783E-17,0.11040368180387283,-14.227753106869612 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark59(-1.2994262207056124E-113,-40.558809806898985,-0.0330676378742781,-26.65615252325921,3.5193675604691527E-14 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark59(-13.175374676165243,21.6413795950115,-0.0025310275542289595,-26.684854740826353,9.617887963047633E-4 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark59(-13.384339775322921,95.82564462142295,-0.007978929017319919,-15.783472172622552,4.440892098500626E-16 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark59(-13.8351673537435,-77.929121281858,-0.05970336473645532,0.02864868492061136,-10.493427361426518 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark59(149.8824200376488,-66.45935601841322,-0.050742736359232016,-23.39256154459186,0.059507290292299606 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark59(-15.719335357893602,0.03098252292249981,-0.024124646447526016,0.03493345383355171,-22.209958387335174 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark59(-159.75681932671594,-39.181404196252565,-1.3877787807814457E-17,0.04226363102044402,-10.03635159054038 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark59(-1.809415787108355,2.964584496975825,-1.1102230246251565E-16,0.11586389259399044,-13.557177079120128 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark59(-21.616906425116028,-63.366187415918425,-0.010459603126701935,-13.845972706025602,3.552713678800501E-15 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark59(-2.1684043449710089E-19,99.646868137374,-0.01693152916221157,0.03117655268169628,-35.208206291969425 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark59(22.03580233507433,100.0,-0.051514236645769956,0.01891143909697801,-83.06064486895036 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark59(-2.220446049250313E-16,19.510164459357973,-0.06195564387572164,1.3877787807814457E-17,-14.041486742318433 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark59(-238.43539852563458,6.841561214161179,-0.040735503713051874,-47.38274164168459,0.02043026004639037 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark59(-24.427829640478386,81.42180532609214,-0.012804069544804429,-50.48296711799984,9.308622337066538E-17 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark59(-27.132585421573758,-50.016995651771246,-0.020086982157179023,0.11114907823284524,-14.13233786342559 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark59(-28.812148414283055,-73.89108487648082,-0.06201774952892669,1.0450680679104564E-15,-29.82608200283024 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark59(-30.178033134671402,-100.0,-0.05154927208638554,-2.391265945268312,-0.7538245913337583 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark59(-3.2858311540025937,-19.611553360259997,-0.021574792063761936,0.3419161804746712,-3.7284988150224465 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark59(-32.97621218888377,99.96564621506926,-0.014026086375802504,0.013471691579971797,-66.68437198915439 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark59(-3.40838109878444,-13.317161173493865,-2.7755575615628914E-17,0.06608780219736632,-9.751630457317756 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark59(-34.15541455074427,109.15053968186945,-0.030066832374283647,0.01267345289756247,-47.39508820871482 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark59(-3.5847182621649836,-14.332806788687357,-3.552713678800501E-15,-63.426678319045074,0.010394079689354817 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark59(-39.79518476876889,-15.599468772583021,-2.7755575615628914E-17,0.0015741988262610099,-3.466026596427538 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark59(-4.254047487592917,58.8092255196502,-0.0255150246838175,-6.812273227782002,0.20038717059324698 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark59(50.96891129606354,4.503494180658237,-44.7687110726422,90.07956011674477,73.80464187710294 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark59(-52.13938660669763,-70.8559888250554,-0.010862393464673298,0.21167462070940957,-6.537778088448547 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark59(-5.3605746023474525,8.150998237050151,-0.061082986285453264,-7.206032370120733,0.08866382256152838 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark59(-54.044333851388075,-47.21025737473874,-1.3877787807814457E-17,0.05824533248308563,-26.1008616833621 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark59(-55.31578604076182,-45.48348690726858,-0.041081660421490196,-38.010866795039355,1.9414428825299486E-14 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark59(-55.842236219571525,47.49802245020911,-0.06166519193143419,6.384888397912604E-5,-23.311432771402934 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark59(-59.78116648554452,78.62815637054541,-0.04783890642952038,-22.08929295623176,8.758090287088696E-14 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark59(-6.50724047219218,-87.73093044484438,-0.04943212501423547,1.633336004457659E-34,-29.66532881638544 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark59(-6.699592668305501,-3.231653831439182,-0.057571334572080246,-4.352543100037689,0.02129944225142122 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark59(-7.094352316568276,-78.32591042817458,-3.3802336246525974E-29,0.06124582629325115,-25.64740198415747 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark59(-71.881333231509,-67.41546868821192,-0.055516706463770965,0.0020325712667563778,-70.51171906824219 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark59(-74.28851601167841,-88.19077251864645,-0.009309943920607508,6.938893903907228E-18,-26.047536729142045 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark59(-77.9491519467705,-100.0,-0.0027071215637649174,1.4210854715202004E-14,-19.745477766555524 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark59(-81.92995868829509,92.7125600088536,-3.9959807535263454E-4,-47.730760778712785,1.8047890304004333E-5 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark59(-82.87769788635336,-99.25557494990159,-0.00924535745981342,0.3630828345452408,-4.326275376698291 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark59(-8.724494807277559,51.75698016220679,-0.03445740504782452,-60.25105047159147,2.652986788178073E-28 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark59(-88.22022837756333,-92.67317334469645,-1.3877787807814457E-17,-15.735918851598825,0.012077994696528377 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark59(-9.17557383820477,38.27114054154015,-4.7464848779700475,-29.561325458566586,95.6768914847423 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark59(-93.89536627831143,-72.94683291652566,-1.1102230246251565E-16,-44.537994828780235,5.551115123125783E-17 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark59(-96.19513322382426,-32.19142439445196,-0.02917925445161529,0.20261412943619173,-7.752649487801781 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark59(-96.88675356649529,48.79213508497719,-4.583177535993112E-44,0.044871623631816876,-35.00645173180452 ) ;
  }
}
