import org.junit.Test;

public class Sample10Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark10(0,0.0,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark10(-0.0024696446847246394,2.451228450332108E-12,-0.2181591704779929 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-0.75376433606273 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark10(-0.009482813912519168,1.6026681424999395E-15,-0.19054081820796176 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark10(0,0,10.139282062602192 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark10(0,0,12.990089995737549 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-14.279508058847256 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark10(0,0,15.108597377247364 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-1.5707963267948961 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-1.5707963267948966 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-21.502756854338756 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-2646.9171324258637 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-2719.2141568940065 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark10(0,0,2.8420812964419184 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark10(0.0,2.8421709430404007E-14,-0.010260678574593923 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-29.409336789016265 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-32.568514522637386 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-5.770397330940554 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-57.83796861140722 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark10(0.0,6.123238853047946E-17,-1.570748760723048 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-7.451852974916534 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-80.0069794235871 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-93.51049701350118 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark10(0,100.0,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark10(-0.12101835979314046,0.10878841812409498,-0.8925870660560564 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark10(0,-12.738730466184649,63.87483023077493 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark10(0,23.662860494193325,-1.557605664831458 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark10(0,2434.8968584999225,-1.5041124043268326 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark10(0,2577.9722851557785,-1.5707963267948963 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark10(0,28.582814224056023,-0.9495733552971757 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark10(0,-39.137883175629874,-2.915969419773211E-12 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark10(0,4.001386458258365,-0.40341665798412674 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark10(0,40.218985370027156,-1.385871426880737 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark10(0,-40.45175785805484,-8.86544233177213 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark10(0,63.51612591450382,-2.6689945102142554E-5 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark10(0,66.05201413878211,-1.5707963267948886 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark10(0,69.36430279556512,-0.055872871239702526 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark10(-0.7068649390977738,1.7763568394002505E-15,-0.5643847065856803 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark10(0,85.12493796653648,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark10(0,-86.74581442926674,-1.1923677715727132 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark10(0,89.2972612309184,-1.413754274461681 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark10(0,99.66086191210796,-0.9476155328367799 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark10(100.0,0.026080216674977896,-1.5707963267948963 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark10(-100.0,100.0,-5.371424350238619E-12 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark10(100.0,1.1754597322406815,-0.5055333664576509 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark10(-100.0,1.6090671664116638,-0.21854088652784737 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark10(-100.0,2.220446049250313E-16,-0.38468974945759243 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark10(-100.0,6.960317446581939,-3.6962152134177583E-13 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark10(-1.0730982260479323,1.382952743928678,-5.585839051983199E-17 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark10(-1.0912119298949072,1.4210854715202004E-14,-1.4247391806251373 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark10(-1.146857214193921,99.99999999999662,-1.0600731363477743E-12 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark10(-12.822472750649103,0.5735632149136249,-1.3519932106888966 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark10(-1.3377742608693866E-197,0.1476951243883327,-1.5707963267948963 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark10(-1.4210854715202004E-14,2.5846410258456177E-11,-1.5707963267948963 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark10(-1.4210854715202004E-14,28.123226973014567,-0.0016892022952017314 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark10(-1.5001638150144387,0.39489180191090506,-0.48667153058686985 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark10(-1.547288704320946,-7.271767597171991E-15,1.1862737347089956 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark10(-1.5644395784302167,100.0,-0.002393401088207048 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark10(-1.5707907940935186,13.864347653466002,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark10(-1.5707907940935257,0.4945269767487446,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark10(-1.5707907940935257,1.7763568394002505E-15,-0.06051460157213717 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark10(-1.5707907940935346,1.5707907940942611,-2.2666185633716337E-8 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark10(-1.5707907940935348,14.291229624448743,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark10(-1.5707907940935348,1.5710112978454438,-0.016731458767812235 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark10(-1.5707907940935826,64.18948679611057,-2.26973995154367E-11 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark10(-1.5707907957540215,85.62942722436487,-3.2160285079463335E-7 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark10(-1.570794843838737,0.0022464312062487656,-1.5707963267948901 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark10(-1.5748051938831225,0.18129648336358606,-0.404781485485455 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark10(-1.5777218104420236E-30,2.1316282072803006E-14,-0.7489350988659567 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark10(-1.5809352682748359,1.0915578193944526,-0.10401013618960597 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark10(-1.5829028164366343,0.23209208018963784,-0.6609398972013879 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark10(-1.6505284201286798,0.4478253126270193,-0.7710800324859832 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark10(1.9721522630525295E-31,1.7053025658242404E-13,-1.0479234217050704 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark10(-2117.4434732162417,0.11931985378915666,-1.4304880493451406 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark10(-2221.497006961826,5.8486272352150195,-1.915547739034118E-12 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark10(-2.8421709430404007E-14,0.30086635963509545,-0.039593193053648015 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark10(-30.32730066376763,0.655983213006843,-0.37907950776765353 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark10(-31.78689511644255,9.798426242816262,-3.541528103224877 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark10(-33.68928097499409,0.31038017567531817,-0.004917080902033272 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark10(39.16861775495576,-30.86014534528536,33.95048134198649 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark10(-39.81405619036558,-9.073744917457615E-15,-0.11347566313577262 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark10(-4.0825630519695637E-202,39.21843139627021,-9.884247093004407E-12 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark10(41.430031317667485,2.979028462574391,-2.443888970221239E-17 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark10(-4.263256414560601E-14,0.2327686500135695,-0.12279744223871883 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark10(-4.263256414560601E-14,16.484836260288194,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark10(-4.540909676055306,-1.3051028254038226,-1.5687404587319895 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark10(45.41912291901775,0.1781105759045844,-1.5707963267948952 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark10(55.601090497889885,32.660917834976516,-7.898773362745828 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark10(-5.960115419818381,0.14775058904820781,-0.23386602039502963 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark10(-62.786484530284326,2.8113374597586206E-12,-1.1045048269321953 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark10(-63.736284570191756,-31.266870552363216,54.80805503712699 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark10(64.32587704495245,0.12141317662683922,3.2710710482829355 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark10(7.105427357601001E-15,-14.028475734682194,0.011414341728698287 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark10(-7.105427357601002E-15,9.905709901126899E-15,-0.6301822646384014 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark10(-73.86804328316347,0.13414007009958873,-1.5707963267948961 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark10(-78.21170286297199,1.7053025658242404E-13,-0.6044853935511798 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark10(78.62470436952978,83.63699464338555,-55.39937256221157 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark10(79.10917200567721,9.475930681670349,-4.966818067941858E-10 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark10(-79.68859703874868,0.1142852161275322,-1.3141039078404528 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark10(81.34065452456909,1293.456385841807,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark10(82.02482325707307,0.10072823752272071,-0.2858098427253952 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark10(83.13033662791919,35.47076033379639,-3.0872699011906463E-11 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark10(-83.93336206731217,10.740019946085951,-76.94753519548635 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark10(-8.739127064893353,-2.1474666093565852E-9,-0.37569761941172963 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark10(-87.85417071490502,2.8421709430404007E-14,-0.011433804025204442 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark10(88.07495408113105,3.817762899285043E-9,-1.005537045741363 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark10(90.74651560445784,-49.171969894532516,33.36039385016551 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark10(-95.97882915596551,-1.9595266440193748,-6.279743763131536E-4 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark10(-96.51458587176973,15.830868698986782,-0.03521616627409449 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark10(-97.9871527403543,55.013343226896865,59.206364086298294 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark10(-99.39778603313873,2.844585075622909E-16,-1.5707382585390768 ) ;
  }
}
