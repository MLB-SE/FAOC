import org.junit.Test;

public class Sample12Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark12(-0.36993945928207506,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark12(-1.0,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark12(-1.0000000000000004,-68.0326254334401,-0.29760649880822265,0.2816657890618476 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark12(-1.0000000000000018,-6.444188100715451,0.0,0.7635828595935692 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark12(-1.0000000000000018,-73.90222425391957,0.9999999999999991,1.0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark12(-1.0000000000000036,-25.725128128417012,-0.059629785834160995,0.9999999999999999 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark12(-1.0000000000000056,-81.93381578841468,0.0,2.8853058180580424E-129 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark12(-1.000000000000007,-100.0,-0.8126578052642435,-1.0363988622197204 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark12(-1.000000000000007,-15.23289194350843,1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark12(-1.000000000000007,-78.92981483652873,2.584001967843605,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark12(-1.000000000000007,-84.85530075171155,0.0,6.019989155869892 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark12(-1.0000000000000104,-69.77719576624352,1.0,-22.17266481581118 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark12(-100.00000003838643,-1.60892988488499,0.0,1.001589908267453 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark12(-1.0000175608029556,-7.475070069542212,0.05250324518214711,3.3881317890172014E-21 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.000000000000007,-0.048498515978360246,4.0607069397050388E-115 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.0000000000000142,1.0,1.608611746708759E-86 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.0000000000000142,2.7755575615628914E-17,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.0,0.00335587947168392 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.0,-0.0890409205659175 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.009556942878162361,-68.68267296923827 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.0,1.0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.0,1.0000000834557672 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-0.020325185111693622,-0.4649858482594035 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.020987227383186258,3.3087224502121107E-24 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.025464344712263845,100.0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-0.028329093921882653,-36.16948888214188 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-0.029039435123931284,-1.0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.03144120806101547,0.06255252896038087 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.032222336796904796,1.0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.03443775850809372,-1.0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-0.0617804382390707,-1.4866572343491533E-31 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-0.15957839639439297,1.0 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-0.5568908693464952,0 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-0.5707936149774929,-5.421010862427522E-20 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-0.6553647624472847,-0.010775775042153077 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-0.7099445608505215,0.9999999999999982 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-0.810058569093409,-98.79554779187168 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-0.8491593799789566,-1.0 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.9478585397917629,1.000009865558759 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.9562505191221993,0.006362916386455475 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-0.9974040661024428,0.05816202173455785 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-1.0,0 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,1.0,0.0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-1.0000000000000036,-1.0 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,100.0,-0.8499783758404321 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,100.0,-0.8579919048478759 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-100.0,0.9999999999999964 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-1.0,0.8845045153397912 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-1.0,0.9999999999999959 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,1.0,-0.9999999999999982 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,1.0,-1.0 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,1.0,1.0 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-1.0,100.0 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-1.0,-25.176903591588687 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-1.0429905082740343,-0.06255543216301125 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-1.0,-85.52989853653332 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,2517.0123843604874,0 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.05483477323149,1.0,0.7283852323518456 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,5.522956729442086E-4,-3.3881317890172014E-21 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,78.53207902040204,-0.825785369064136 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-84.37169469693679,-0.7683510774866935 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-101.02912023149976,1.0,-2296.95252839385 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-11.45938527619195,0.8783036067043072,-54.17790620762172 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-127.59183132033317,0.026973426859147727,2242.3385536189544 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark12(-1.0001284523294374,-47.34945690920249,-1.0,-0.03922416350417966 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-14.301525206719424,-0.010006073715650706,-0.2707650968942081 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-15.028843480996363,0.03770740815113749,-0.9999999999999836 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-15.149000867240618,-0.4897159967530834,1.0636003590856142 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-17.278592191143943,-0.19827036626538785,0.03600583471939442 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-17.372517653807027,-0.9931029788817416,1.0000071323722726 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-17.963074643918816,0.0025121997982583133,1.0 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-18.759080781347976,1.0,0.7145881021435646 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-2.054817331239792,-58.357641692424,1.0 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-21.41922866957283,1.0,2008.4818727006034 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-21.530286390440875,0.0,0.0 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-21.72388192643366,1.0,-1.0 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-22.014629308330157,0.04305652119879486,2261.09754505714 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-23.678627255116428,0.8957195348068724,73.76473488807231 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-2.450455421187513,1.0,0.958778545279543 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-24.60070186518541,0.03337835457100335,1.0000038819396393 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-2.4703368477503433,-2.220446049250313E-16,-1.9302888505749807E-9 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-25.4527945807062,-19.840363926739535,0.03113431850873377 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-25.75929625477188,0.8868399999005163,1.0 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-30.436838853798633,0.0,0.39217183866919036 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-32.5779575780542,0.053081195472796217,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-33.324749765259156,-1.0,100.0 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-35.02906805162195,0.6039366029397615,1.526290248218504E-5 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-36.209547626865316,-97.0283231755639,0.0 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-36.560110785792716,0.02347798519060257,0.0 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-36.759917598804876,-2.7755575615628914E-17,42.338473185585684 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-37.6083369897377,-2.7755575615628914E-17,0 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-40.35508147661429,1.0,14.14935626702573 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-41.16484575819314,-1.0,-1.0 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-41.427497673325284,-0.03315798049230462,1.0 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-43.3902975530348,1.0,-8.526226370947754 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-45.26318850494529,10.741450828813111,-0.06251599429618375 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-45.83225168350161,0.024725915012404072,0.9999999999999998 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-46.00214080372233,0.0,-1.0000000000000004 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-46.21099204168541,-0.01945145161046677,0.9958982468329093 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-4.638357033860384,-100.0,1.0 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-46.45735955939998,-82.9668649974705,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-4.752678239828322,1.0,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-48.437305912093464,0.039875422441654686,0.05807115614053737 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-50.565368835987194,-0.745947114343783,-80.4615329515299 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-52.21896161844442,1.0,82.36063555130178 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-52.69160508821224,0.0,1.0 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-53.56005880781726,0.0,0.9999999999999982 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-53.8542349512402,1.0,0.8614345030524524 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-54.057617485787915,5.551115123125783E-17,1.0000000000000004 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-5.665130998226115,1.0,0.9999999999999973 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-57.957507047051784,1.0,0 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-58.75774429554931,100.0,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-5.915657520307317,0.8056377151345236,1.0 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-59.712990398544676,0.0,-1.0 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-6.150542767044058,1.0,0 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-61.687429508219765,-0.02310826795582404,41.68629009022176 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-62.0265630314797,-1.0,1.0 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-6.251222871429959,-0.04255423855757085,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-63.264498662124254,1.0,-1.0 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-63.46282383442605,0.9702032389586088,-79.96967542466162 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-63.61247494360642,-1.0,-1.0 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-6.7246763046013704,-1.1102230246251565E-16,-1.0 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-68.39481588226352,0.0,1.0 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-68.43542668043348,1.1102230246251565E-16,-1.0 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-69.36670032275664,0.3689911307580197,0.4365806087619948 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-73.58827127388547,0.6714298449950198,-1.2767972911244588E-14 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-76.36756872172195,1.0,0 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-7.709347556322022,-0.6804635462670564,1.0 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-77.53544531366009,0.007845242014021592,3.8518598887744717E-34 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-77.92014477706124,-0.03999892899988629,-0.06255671454561605 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-78.06999275025763,-1.0,-1.0 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-78.97355490339906,-0.054822254365947565,1.0000000000663583 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-79.08196539527368,2.7755575615628914E-17,0.05358658149200709 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-79.27417101473074,0.014236376491041917,14.70065389486696 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-80.08666918662564,0.0,-1.0 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-81.95914704956624,-1.0,-1.0000000000000164 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-84.04953983175434,-0.013685091611105649,17.504776755061133 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-88.89036844720914,0.013678123275818958,-1.3552527156068805E-20 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-90.92798905643217,0.0,0.012948696496876367 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-9.360130089562729,1.0,-5.293955920339377E-23 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-93.67696982347373,0.05695130210816397,0.9999999999999991 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-94.1152864184005,0.0028002882788840597,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-94.4325884206329,0.0,1.0 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-94.90314350391733,-1.0,0 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-96.41544407155314,-1.0,0.9221505409895387 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-9.867482659744368,1.0,6.938893903907228E-18 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-99.89252368567462,-1.1102230246251565E-16,0.040591819224268244 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-99.97007690351946,-0.9718321232153739,1.0 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-99.99068301453886,0.010223829051180626,-1.0 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark12(-1.0010761737064466,-28.044242890289283,0.9009102840428881,0.9999999999999889 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark12(-10.012269222052254,-2.648465030863961,0.8845122484811183,10.270970675180521 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark12(-10.01827003242714,-83.51746431681302,0.4555434980750078,1.0 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark12(-10.031334716502126,-43.64931554832855,0.5774942253078708,0 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark12(-1.0059907304183786,-40.67251712319909,0.051043580760117564,-1.0 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark12(-10.071260848940096,-26.790405683153057,0.9523560580574418,0.8636502263529227 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark12(-101.00908152686256,-39.597961970404235,0.013473921561702795,0.040786722541094694 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark12(-10.104371710904203,-6.948355984621971,-1.0,-3.944304526105059E-31 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark12(-10.104502501748179,-81.16145418568269,0.0,-0.04915466634806284 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark12(-101.3344007180939,-5.686586271029952,0.01365925265564952,-1.0 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark12(-1.0161981205083912,-5.150093748042794,-1.0,0 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark12(-1.0235992468461634,-51.06755096387458,0.9878271715084537,-1.0 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark12(-10.323884364211168,-84.66770126674214,37.12649033847376,0 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark12(-10.450198122044554,-100.0,-1.0,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark12(-106.49319008258313,-24.01255945468979,-1.0,-1.0000001784145005 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark12(-1.0720819580515906,-54.380258467083905,-0.9942493201797783,1.0 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark12(-10.720989792025103,-36.33288484422425,0.4725028214497977,-0.9999999999999982 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark12(-10.73340881644907,-17.266209927455908,0.0,-3.944304526105059E-31 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark12(-10.782832015957382,0,0,0 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark12(-10.845627566363467,-29.481811156961367,0.9985852468146567,0.9843346160086215 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark12(-10.86237963803358,-100.0,0.6188514747026588,-1.0 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark12(-10.876757048214316,-14.14688548884908,1.0,-1.0 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark12(-10.967331810185213,-14.472868597435003,1.0,-8.1214138794100775E-115 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark12(-11.030982998409016,-28.27713437516381,1.0,-0.9999999999999991 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark12(-11.033003921522015,-81.6353675974533,0.0,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark12(-11.10608652537455,-58.789655973232115,-9.484978968066798,89.49681499285006 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark12(-113.32290136946732,-46.05809149094555,-0.3524133598233794,-63.36134574386079 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark12(-11.358852250952117,-96.74755836584909,-1.0,-0.4090185496823233 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark12(-11.402350854234337,-12.137847577806312,0.013216863819134034,-0.999916719942935 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark12(-1.1444192569294036,-68.57521825133499,1.0,0.044654075887768 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark12(-11.506558478634279,-63.2819587113007,0.42880244869824047,66.04718982871863 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark12(-1.1507142259765757,-72.75025993792725,1.0,68.99644080421047 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark12(-11.603801182320382,-5.5287498264141055,-7.85289788412738,1.0010415475915505E-146 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark12(-11.6115601868336,-100.0,0.9860019456092763,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark12(-11.695480208359797,-68.7341109873894,-72.38442659856754,-0.2272996638537279 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark12(-11.70775320216722,-33.13892946192199,0.0,-0.935166614360444 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark12(-11.850924795593684,-100.0,0.1979017864494118,-1.0 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark12(-121.02623181521895,-1.0000000000000009,-81.76743735011297,-0.6645380758463535 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark12(-12.139140266696252,-42.57615638166081,0.058299215377543234,1.0000000000000018 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark12(-12.162191775558398,-79.22910239734816,0.4592787825371971,0 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark12(-121.64952729857006,-100.0,0.020665152644291085,-0.36241393602071775 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark12(-12.278447120332936,-57.70588104246912,-0.014137296168661884,1.0 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark12(-12.314244398571361,-27.160698901698723,0.6755194740112851,0 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark12(-12.31801922861503,-28.931679210854146,-0.6055612775777666,-5.770611636116085E-129 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark12(-12.351859680288985,-82.07003521493058,0.0,1.0 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark12(-12.370105325238502,-67.62648096143852,1.0,-1.0 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark12(-12.378788301514797,-16.493453896117067,0.9147785513422463,5.929302541837367 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark12(-1.2402840452810568,-66.80551894691732,-1.0,-0.9859081774561193 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark12(-12.406225460652884,-20.31140745147542,-1.0,0.027818673539249217 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark12(-1.2462515157989347,-26.29715606759298,-1.0,-1.0 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark12(-125.18260651737458,-99.99927949953134,-0.061045557185277585,1.000121160647584 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark12(-12.590678617781785,-100.0,-0.04785241448522867,0.8565312228661537 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark12(-12.61678725929174,-67.50929685261599,0.0,-0.6109595023045244 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark12(-12.682700283928725,-26.592054463708706,-0.006144255957100331,79.41447501824878 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark12(-1.2701830535058034,-22.577240938990514,-1.0,-0.039745897449919076 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark12(-127.37031757634395,-91.29615231840003,-0.011037328032165616,1.0 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark12(-12.805134377327283,-61.68429359525501,0.0,1.0 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark12(-12.817155449996537,-5.637471323557744,42.86606921543288,-73.96354403978948 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark12(-1.2916263923648792,-64.5087973354086,-16.38122396682149,-0.5594908391668696 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark12(-1.2919281657768678,-66.09530631828517,0.026288997458937396,0.0 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark12(-12.949004124377145,-8.37956375812692,0.1859088865552264,-1.0000000051737443 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark12(-12.986710065580798,-86.77301249399245,0.0,1.0 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark12(-1.302601189825964,-7.310923023206792,1.0,0.9999999999999964 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark12(-13.093686851718456,-99.1549660774244,0.0,0.05363642201459469 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark12(-1.3255916980357938,-39.547186364793674,1.0,-55.965493425869816 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark12(-133.14772991457434,-13.793249247472312,0.05484437367614736,-0.9999999999999929 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark12(-13.331258079476981,-36.91368890502824,3.552713678800501E-15,-61.40139119513115 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark12(-1.3343411215843788,-53.11841774933347,-11.288719486508251,-1.0 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark12(-13.435981311864651,-79.76009954360237,-1.0,0 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark12(-13.603304879659056,-64.15027836099252,1.0,-1.0 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark12(-13.632622660239473,-58.041107783695026,0.015284324435185312,0.7423829768387045 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark12(-13.650407737250596,-100.0,0.0,-2.465190328815662E-32 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark12(-13.670287500676343,-59.072900181767736,0.04288720434479142,0.933077923320847 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark12(-13.882880739733464,-100.0,0.01,0.0338615223153825 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark12(-13.918830099354693,-100.0,0.042800991572627574,1.0000034287487842 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark12(-14.01284930911865,-84.99413856678207,-0.9942039629231574,0.14593051615275954 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark12(-1.4165484437315166,-99.91602376073683,2.7240526238796337,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark12(-14.170716159355791,-86.2601214470137,0.0,-0.06256473707289534 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark12(-14.237911844856526,-88.76623603940898,1.7763568394002505E-15,97.7996005423594 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark12(-14.310763913205651,-7.388636662259421,-0.021936274346173262,11.330765987940847 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark12(-14.389604846823698,-1.0000000000000036,1.0000000000000004,1.0 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark12(-14.4346078404838,-14.964213314653339,-1.0000222494469508,0.5118591030230769 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark12(-1.4440455547375912,-50.359628362587834,-0.038867227691854495,1.0 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark12(-144.59729935086128,-27.0691076878257,-1.0,-2314.1846094264115 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark12(-14.494299022039044,-54.89292700371884,1.065016867697282,0 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark12(-14.497920648335509,-17.381949064842424,-0.8247247121959572,0 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark12(-1.4545864543484157,-56.927910295640956,0.0,-0.7487465002420306 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark12(-14.559098467108768,-59.5587984868168,62.93249147111004,0 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark12(-14.559279376676525,-89.74095427967683,0.035898641669665915,-99.91938031612938 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark12(-14.629163296420339,-8.699723472198308,1.0,64.01644526721412 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark12(-14.64158269131049,-15.88761930256166,-41.958747831139156,-99.49118130817489 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark12(-14.716274771866058,-77.99105087701547,-0.023422977847935206,5.551115123125783E-17 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark12(-14.765482504842009,-99.99999043607158,-0.38655519720194675,0.004045492873263834 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark12(-14.809474203378189,-39.852435312241774,-1.0,63.93736993289827 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark12(-14.861442847657418,-59.992559940907086,-0.9614182392441948,-0.34260797609284666 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark12(-14.888085471872845,-18.468964599785505,1.0,-0.8686654334807802 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark12(-14.981288211918931,-64.09964401358242,-1.0,-0.6480117035011789 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark12(-15.016593118112002,-35.07892416307282,-0.05095690550926171,0.8265117033862427 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark12(-1.5046731514321614,-33.30003652497812,-1.3877787807814457E-17,-21.89020791969901 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark12(-15.094346729728358,-37.043175235222975,-0.04762909074031185,-1.0 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark12(-15.130909667110771,-15.231638389153067,100.0,-0.03737123077041135 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark12(-1.5154240762332132,-23.526277069077857,0.03811385299943523,-0.9981399415364082 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark12(-15.176791550549094,-91.47731892451883,-3.4743947494501697,1.1571392542757025E-16 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark12(-151.97651748004384,-23.97647731487633,0.041311410047494945,0.9794066752228694 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark12(-15.352854581813233,-82.68455183760955,-0.8608315769476746,-1.0 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark12(-15.443655927382895,-65.27915103312614,0.0,37.31931901565398 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark12(-15.466449168615316,-45.823238532151095,0.1691265013843669,-2.4395941306224884 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark12(-155.94318879135486,-44.81504116133269,-100.0,0.9999999999999991 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark12(-1.565130658656091,-138.21996520786692,1.0,57.761259130927726 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark12(-15.815861597507677,-56.77428529512889,1.0,-1.0 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark12(-15.823380571747766,-81.27556025352177,0.0,-13.791411943926597 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark12(-15.872194166456532,-100.0,-1.0,0 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark12(-15.907600334374834,-4.668658955567095,-0.8942111198350934,-79.86248109078093 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark12(-15.947728643137546,-67.92360269467127,0.0,0.8744070332453897 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark12(-15.96396610407627,-71.63598409076688,-0.041763294492726435,-1.0 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark12(-15.988295309467105,-3.981760167952558,-39.049591210808245,31.774967776326008 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark12(-16.000274462076618,-83.71242486898242,1.0,-45.82496482523302 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark12(-16.01030229741731,-100.0,0.9822335897881133,0.0 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark12(-16.045054201082632,-29.092446072058777,-1.0,1.734723475976807E-18 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark12(-16.06627814303056,-73.41464846426042,-0.030278885132847985,20.370676708945496 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark12(-161.80194636464574,-68.61771960633082,-0.056436408654950344,98.06769075922422 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark12(-162.31571693675434,-78.97760015117802,-1.0,70.04367071490809 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark12(-16.29879598077852,-66.85783479784413,-36.665795884108206,-32.90902377431502 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark12(-16.359255110938985,-71.90859333342829,-1.0,1.0 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark12(-16.756019147115282,-94.32226754713784,1.0,0.0 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark12(-16.8505182702729,-84.27005339200971,-1.0,29.298604203473094 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark12(-1.6890928673368264,-109.23066638271368,-0.13594918969659753,-2242.6707049048205 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark12(-16.914236683838553,-13.46257035862569,0.0,48.21614019622454 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark12(-1.6932846166061968,-25.79320559731466,0.0026902363580025845,0.0032533768323466106 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark12(-1.7042386884122616,-62.92958065726826,-0.5287297892014315,-52.605927781225 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark12(-171.00702237556365,-15.150926087851616,-0.9238404462840606,49.819382939134655 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark12(-17.13016140959367,-34.29352137261298,0.0,-0.7783303393487826 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark12(-1.7178359223500783,-57.89076695364443,-1.0,1.0000015298923424 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark12(-17.311365464919596,-79.43945435949895,0.0445482296653119,-1.3448593046583617 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark12(-17.324098830450097,-70.71960574195543,0.016080648540620034,1.0 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark12(-17.3684041868008,-66.1604710050019,0.039384093585052043,0.9999999999999996 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark12(-1.7452059595030072,-18.604817469099466,0.8097346296172938,2017.0072239830904 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark12(-17.553871281313995,-99.99999999999895,1.0,-1.0 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark12(-17.60612786181439,-60.65730422599453,-1.0,0.0 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark12(-17.651091347978102,-14.30466601367777,0.9999999999999981,0.024393920481488952 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark12(-17.701101215030377,-48.080308529230535,0.058554450416366595,-2061.542766762156 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark12(-17.786362330687858,-88.0714367594216,0.40748276478104906,0 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark12(-17.81683210123363,-64.35274047032178,0.0,72.33079983410029 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark12(-17.817620154284256,-47.7136876367948,-78.77697213891379,-0.9999999999999982 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark12(-17.818964130849682,-38.88701303959015,-21.581160702869305,0.19271338643801528 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark12(-17.84969383936965,-100.0,-2.7755575615628914E-17,-1.0 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark12(-1.7873737864029824,-40.43362501166575,63.57685988564144,-1.0 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark12(-17.92731663398463,-8.1235255118244,-1.0,2.5737787947340145E-85 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark12(-17.96925630034177,-25.456737390897924,73.98932952376381,-2354.4316299820243 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark12(-1.807655566203782,-20.341324582608852,-1.0,-1.0 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark12(-18.131741832167123,-100.0,0.3758793271657941,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark12(-18.225286248355125,-7.692119716567735,1.1102230246251565E-16,-0.9999999999999998 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark12(-18.273553093318014,-28.18572954533034,0.8138609889593379,-0.9130533195383275 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark12(-18.337229358508953,-9.78212943238813,-2.220446049250313E-16,-51.31116829857638 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark12(-18.391770002640534,-22.290419282923256,-0.05291793276372529,-0.572375466500436 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark12(-18.45493780161287,-61.97699129675793,-41.363024326215104,-1720.7128988124605 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark12(-1.8532945847707998,-31.783425518922392,-0.024926791278491095,1.0 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark12(-18.55175383477321,-66.39141362705976,-26.66115770722186,42.71482339731247 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark12(-18.63085581686143,-73.33550876707814,-0.02295448637855635,-1.0 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark12(-187.1859813415175,-100.0,0.9999918203961548,-0.06255302197575682 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark12(-18.73606140537846,-45.99225230325666,0.0,0.0251424801351469 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark12(-1.882549053985528,-42.34467425468689,-0.01764798778889754,-1.0 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark12(-18.924450378690047,-100.0,0.8727116068561013,1.0 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark12(-18.936412886756298,-42.594097114659064,-0.016746432340893902,37.93876356076359 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark12(-19.0046567334653,-80.41998199484085,0.9387457662417058,-1.0 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark12(-19.0521408037963,-75.04731676964262,0.9999999999999963,8.673617379884035E-19 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark12(-19.169592660346037,-51.20410965810041,0.0,-29.00222763052413 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark12(-1.9328532996815124,-21.146878748297997,-0.0732189862485626,0.0 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark12(-19.339853024233406,-72.08639229449301,-39.385657508456774,5.2304198767930075 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark12(-1.954445186309954,-44.869580907961605,-2510.3235319768837,0 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark12(-19.6866314466453,-53.6174929754254,-4.440892098500626E-16,1.0 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark12(-19.705423712189443,-55.20150390318781,97.69641689182808,-1.00663492637029 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark12(-19.78321729869917,-3.9094982660040936,0.06182232462172366,-1.0 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark12(-19.806718212252296,-96.40251936362769,-85.13773126270607,-1.0 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark12(-19.8104369480385,-40.44162465998377,62.29439857639275,0 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark12(-198.20118817496956,-13.392436073752334,0.9426527647299746,0.0 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark12(-19.853618506732126,-50.495278854711096,-0.7062312957481329,0.0 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark12(-19.89522625109129,-34.231046225218016,-1.0,0.9999999999999998 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark12(-199.32950872556376,-6.428078361451899,-0.00520203802579744,2157.7557510125503 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark12(-1.9936082044361998,-51.25677748389475,0.007039519820222757,-0.06255339285538285 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark12(-1.9962580850502292,-33.50912357770684,1.0,0.07117686718602556 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark12(-19.97457011211541,-48.94595714741285,-1.0,0.5785069486207632 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark12(-19.979013915352347,-2.129395020117329,-0.3805744912501332,-2219.9680548498986 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark12(-199.8235163643036,-100.0,46.9023635222837,-0.020923545193233126 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark12(-19.99611426888736,-59.96989715713341,1.0,1.0268054533360702 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark12(-20.011900390382248,-37.401019838376754,-2.7755575615628914E-17,0.0 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark12(-20.015725383929787,-39.447847736056026,-0.16653023016604923,-1.0 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark12(-20.065936037691596,-25.67164968263301,-1.0,-48.258824130931295 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark12(-20.108596687654572,-9.255210106598504,0.0,-1.0 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark12(-20.33469277348816,-96.34202743510873,-67.3896755225893,1.0 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark12(-20.368552985026042,-63.729963910903955,82.23742486174731,-79.71408988998658 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark12(-2.037847366018438,-50.08063970197806,-0.9784119158757665,-12.833528791229703 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark12(-2.040537079684835,-24.002902090970824,0.028571852590139772,1.0 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark12(-20.409506337724462,-46.55853932050893,1.0,-0.9999999999999991 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark12(-20.659717566406936,-22.92375680297578,-1.1102230246251565E-16,0.8151773693663665 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark12(-20.688205233545133,-2.3286202664356774,1.0,1.0 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark12(-20.95700234548889,-30.29643377379132,-1.0000000000000004,0 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark12(-2.103568766409574,-40.164481730075465,0.0,1.0 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark12(-21.111525808356554,-37.456650069692984,0.8125225926824913,-0.007749172733075516 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark12(-21.1369671173518,-100.0,-0.054207745569280055,0.05617702091815688 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark12(-21.14280469413616,-97.58422308743621,0.0,-92.22598927466927 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark12(-21.377950390281228,-45.667965936194136,8.881784197001252E-16,-74.14787636109142 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark12(-21.386729530850886,-20.37195034513273,-82.13408749854605,-63.11768392806414 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark12(-21.554306854330036,-23.027382560814246,-0.979011024333213,0.02761101046631978 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark12(-21.560567706567753,-39.77330895853055,51.787560607017234,-0.04683595166188186 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark12(-21.855463670297826,-100.0,-0.04849682655178436,0.0 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark12(-2.1860330346840957,-100.0,-0.887004550824599,0.9999999999999991 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark12(-21.8853993510927,-71.97207458792485,0.025319037615613764,1.0157378003345072 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark12(-21.956579856079433,-56.046301547601296,0.0,-70.11101076530836 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark12(-21.99357018633536,-8.157839569100773,-1.0,0 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark12(-2.2033153579774307,-61.57008573650263,-1.0,-45.59062282935462 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark12(-2.212005100294384,-86.7627411277331,-0.010289891306558665,0.06255290815378514 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark12(-22.141911862685117,-89.51293630166984,1.0,-1.0000000216487983 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark12(-22.147772686171862,-99.22193371073,-0.024259590624070862,0 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark12(-2.217249923197297,-6.463767782923328,0.05004707516872797,-0.9999999999999996 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark12(-2.220468344032514,-90.40567989404522,-1.0,98.42797186881069 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark12(-22.34127723186907,-5.033910398438948,-1.0,64.70362352571277 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark12(-22.352046786955434,-100.0,1.3877787807814457E-17,0 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark12(-22.363188808503015,-46.138798217106554,-1.0,-47.533095658201205 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark12(-22.37513001321198,-20.24596801002998,-100.0,8.17009835109988E-9 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark12(-22.37976156925393,-67.38646729884972,-1.0,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark12(-22.482567002954056,-62.21528765300608,-70.35998579064085,1.0 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark12(-2.2634848188648955,-94.7496637875564,0.0,1.0 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark12(-22.688712463685768,-17.95582667128715,53.43587544034273,-0.2507261878643299 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark12(-22.871483228693165,-52.06258430463771,-1.0,-1.0 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark12(-2.288409556429287,-56.65194443300953,1.3877787807814457E-17,-1.5996037787000006 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark12(-22.916808377235537,-38.292938906103636,1.7763568394002505E-15,-0.9999999999999964 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark12(-23.054788543672643,-19.59762558969797,-29.957010875248756,-52.23263435531209 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark12(-23.17577725333589,-10.013020316942,0.7489298286660534,1.0 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark12(-23.27403760952196,-100.0,0.7174642691994675,-0.01974530913664546 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark12(-23.330557391326906,-45.22346809279605,0.0,1.0000000000000018 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark12(-23.33498502663987,0,0,0 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark12(-23.511524566838577,-32.22334102897032,0.0,-1.0 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark12(-23.518578057648682,-42.758380238292744,-1.0,-53.439677976517515 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark12(-2.355629153783937,-11.134973713848197,-21.47607466930421,-1.0 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark12(-23.629700485739377,-67.92376000473192,-1.0,-89.51279701318138 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark12(-23.676618250232714,-10.116601145740537,1.0,-1.0 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark12(-23.86358441539704,-35.305654768307626,-1.0,-0.9541080582322857 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark12(-24.05167660144338,-100.0,-1.0,0.07027071270208013 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark12(-2.4068472948613397,-34.264747984888395,1.0,-8.043705462681919 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark12(-24.16191538153007,-78.68012303042664,-0.7548241518563744,4.1359030627651384E-25 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark12(-2.4299870693027525,-28.667257476177934,1.0,-100.0 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark12(-24.49975868032797,-34.34168568647543,-0.9999999999999997,9.412413888521751E-4 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark12(-24.513002518041127,-54.724987426709056,-25.46976156254866,1.0 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark12(-24.516369048325924,-64.23599972888086,-2.7755575615628914E-17,-0.06920332589259104 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark12(-24.544643741259975,85.1768931819939,0,0 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark12(-24.717936869199022,-8.323960270706916,-0.038231029656059234,35.46089561737363 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark12(-24.76281704984693,-22.6594243020825,-55.91959003767508,-0.032013999305183914 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark12(-24.773429426518916,-56.12459845732938,0.0,-28.445642767897453 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark12(-24.827762493313426,-5.2716760317493385,-0.558154613745085,-1.0 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark12(-25.039846295266905,-53.19341815714946,1.0,1.0 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark12(-25.063109633565244,-61.65658295933233,-0.012786071586136006,16.584547563744678 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark12(-25.121726676920346,-53.5115262210226,0.0,-1.0 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark12(-25.162383026538677,-38.06156615903099,1.0,1.0 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark12(-25.21890207531814,-36.91268244391285,1.0,1.78038432044786E-16 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark12(-25.27233534968139,-48.09599920543434,-5.429955134809928,0.22147560157477064 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark12(-25.272399785514793,-87.16061144943657,-0.9999999999999982,-59.794769084704825 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark12(-25.372903537617205,-3.5896764610331147,0.14839091532632565,-1.0 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark12(-25.378368312953583,-3.2891448370470613,0.9064646428832077,1.0 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark12(-25.37948050960776,-3.4308847891568064,-36.7007487125955,0 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark12(-25.469058122938947,-101.41951762316789,0.0,-0.9614459616055742 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark12(-25.587758028828734,-55.39922285780344,-0.03142339670983618,0.6612074680143003 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark12(-25.691573739715427,-14.854198336154356,-2.7755575615628914E-17,57.702618539918745 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark12(-25.706579205250577,-94.30512608759108,0.9613416971404679,-2105.8031314252303 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark12(-25.727784419228904,-100.0,-0.15358103922804744,-1.0 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark12(-25.757654201152775,-84.9893383965945,1.0,0 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark12(-25.789960735229425,-22.144054271672346,0.03405956444782077,-1.1684210042346876 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark12(-25.871384023210922,-100.0,-1.0,1.0 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark12(-2.6100506471900977,-79.5467583956141,-2.7755575615628914E-17,1.0 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark12(-2.624586294457785,-46.17836070048807,1.0,76.20770591873743 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark12(-26.44861923268914,-70.17986130986635,-0.9717491354533089,1.0 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark12(-26.475104465371842,-91.57359847106119,0.0,-78.66955945677729 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark12(-2.6547310570966403,-7.542998330765556,0.20477578506872152,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark12(-26.55277893446432,-100.0,1.0,-1.0 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark12(-26.718231006633623,-100.0,-0.7293678634968277,0 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark12(-26.837507959498907,-17.43864495156872,1.0,-0.2976863148961916 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark12(-26.902103648402875,-89.75178618873878,0.9999999999999996,0 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark12(-26.97526970757876,-63.34048213286209,0.878563683280665,-0.21383949510780886 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark12(-27.016228133135925,-30.20168254250794,0.9998700952059395,0.5167899023781359 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark12(-27.041468597655296,-57.857654201242916,-0.558127945519846,1.0000000000000009 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark12(-27.060765552624826,-60.521493781989676,0.014723985284646801,0.925070511675401 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark12(-2.7224652230493303,-25.542615921874802,-1.0,-0.9957668375253738 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark12(-27.398387635869266,-23.52320720404811,-72.76340452418447,3.469446951953614E-18 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark12(-27.46868810773455,-67.55725785032368,0.0,-1.0 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark12(-27.52142552726237,-79.0714541971301,-0.9725743001921408,1.0 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark12(-27.526773186534328,-19.676122217261554,0.041034150405138387,0.8408698155988361 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark12(-27.55349474084455,-81.02401936773765,1.0,-3.6191076044093955 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark12(-27.560174122462143,-1.2053555189025928,0.0010027987170495578,-0.9999999999999982 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark12(-27.576075971238524,-48.79988984728223,1.0,0 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark12(-27.767055072287448,-76.52170259206098,0.0,-61.637643347203365 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark12(-27.844413393561766,-100.0,-0.9999999999999969,-0.9777449243623494 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark12(-28.190230858499774,-100.0,0.02142429584340194,69.03944328212458 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark12(-28.20061705174543,-4.626765370545362,-36.20760507813343,-74.9901418486129 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark12(-28.24806880481239,-3.2037698201022335,-7.206915622939064,1.0 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark12(-28.338284825442088,-41.130500833348925,44.1446496682276,0 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark12(-28.412716816021792,-100.0,1.0,-0.06255252533898835 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark12(-28.457923128371778,-87.57895845537952,-0.3482971794978774,44.68881681830702 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark12(-28.55866498407177,-71.21941113116065,-1.0,-1.0 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark12(-28.578470007618815,-43.23857608856437,-0.017114729738608052,-0.9672556625142085 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark12(-28.707632400533377,-1.0,0,0 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark12(-28.7088457791282,-33.17145181230254,0.028773427267482284,90.5494893590069 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark12(-28.757674501467353,-82.24721455805175,-0.019772392176154938,-1.0 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark12(-28.77944331925149,-53.365500605633144,-0.871607691167199,0.0 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark12(-28.79706705922982,-23.719882294466924,1.0,0.037275285158947624 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark12(-28.79912143775826,-62.45721020577835,-1.0,92.27073507792429 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark12(-2.8863351426440857,-19.99197315358883,52.37646948938476,0 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark12(-29.014615422700714,-70.4889800219985,61.28967146954582,0 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark12(-29.119985257113115,-164.6539962263614,0.04345049552031799,-2051.9778713829237 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark12(-29.155170967815053,-18.163263463075438,0.24146533122874314,0 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark12(-29.16093629223381,-56.85609765863644,59.165780266084155,-0.06259343745833726 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark12(-29.30860522515492,-99.99999999999999,6.406665904585923E-145,0 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark12(-29.316214353273423,-90.31850469634466,-95.38639420174393,-62.65635612410225 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark12(-29.36472800691483,-62.2900122014613,0.0,-0.6801457432817852 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark12(-29.370494133775566,-85.84387729587581,-0.5341307144583549,1.0073322968779335 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark12(-29.44647803650411,-1.1657863774182178,-0.060849289164221554,3.0428761699151887 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark12(-29.475154327899105,-11.851987319864046,0.8004149603948054,0.32998887467987026 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark12(-29.58437758315256,-79.44905213583766,-12.771604509475651,0 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark12(-29.61442751879006,-27.489986486730977,-1.0,1.734723475976807E-18 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark12(-29.643322312188776,-18.95537242467411,-56.76604291526801,-1.0 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark12(-29.705623408012386,-10.33694310164448,0.0,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark12(-29.757849217967454,-9.327082509502223,0.0,0.39068156898731843 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark12(-2.980897943006234,-61.07395843490059,-1.0,1.0000016901840063 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark12(-29.81247514271054,-19.838863408173545,-0.03437032310829857,0.9999970102564687 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark12(-2.985594320453716,-6.159940483554007,1.0,-42.811871888196464 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark12(-29.925291599295242,-49.44969393784366,0.0,2198.7099794525298 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark12(-29.932997871829407,-9.09255791272507,0.4766878405168638,10.906039524036174 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark12(-29.981202775926235,-100.0,1.5626868532303144E-8,0 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark12(-29.98823784463872,-61.431587571515344,1.000000000000007,-1.0 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark12(-30.219823817767335,-53.07027308422849,0.03494659885998777,0.017729738495088743 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark12(-30.255471722751228,-9.016586758808671,-5.420325617887009,27.844592955938154 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark12(-30.261073225562598,-62.82755511305525,-0.012074868146405751,1.0 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark12(-30.373486350180798,-78.75665319498289,1.7763568394002505E-15,55.06864024387599 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark12(-30.505967206456376,-23.186519805078284,1.0,-55.094458817916056 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark12(-30.50998409622685,-82.57326402175644,0.0,-0.041801216417327924 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark12(-30.530501385114444,-53.12442594075182,-1.0,5.322830981610608 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark12(-30.542440909531113,-41.18544571213186,-0.9332113294356379,-99.47988763141096 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark12(-30.561758539766117,-62.05968135972457,0.021573275632118083,53.52109970365902 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark12(-30.60191928885144,-15.95055589219622,-0.8390574562999717,5.988608273452518 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark12(-30.77794257804516,-12.945937434210938,-73.25196905341423,0.23888966169576792 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark12(-30.850711812220187,-12.146560839344854,-1.0,-0.4153279672204717 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark12(-30.88132380280757,-9.736213043428734,-42.85224442861204,0.9999999999999964 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark12(-30.899954858642168,-68.0896884403042,0.04098705174108283,-0.9999999999999997 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark12(-30.933223638951826,-78.8446473240228,-0.6832683888809592,0.999762752207143 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark12(-31.025790065796414,-52.14934688958539,1.0,-12.980709994302197 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark12(-31.0447321649288,-12.089296522707714,0.0,4.6245014080570357E-4 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark12(-31.051385129703615,-1.0000000000000018,-45.655980096009785,-0.34055171018742814 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark12(-31.13390404687792,-76.09216256161345,0.9999999999999996,-4.433168380208718 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark12(-31.21638533479782,-15.126589879855558,-98.88077673226492,0.0 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark12(-31.218921336324943,-40.79878677953541,-0.6745132125942814,70.73929386120722 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark12(-31.248212115761447,-61.88470541569271,-1.0,-8.597975117944653 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark12(-31.357462526365623,-97.1693879368254,-1.0,0.05650651006517177 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark12(-31.422151344635317,-35.008862875254934,-1.0,-4.797815424533684 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark12(-31.428707673730898,-61.00534001238859,1.0,0.9237637046960823 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark12(-31.47769353112946,-89.81171462490538,-0.033708664069279644,0 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark12(-31.496899106290332,-9.554535775788255,-0.03514581920402139,-0.03121419933273628 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark12(-31.500363707386,-45.718879630031985,-55.462056197308705,49.1887052219505 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark12(-31.657213409161805,-53.7469591000603,0.0,-1.0 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark12(-31.677003086137166,-100.0,0.868562558984425,-41.5884048247189 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark12(-31.67849405297997,-1.0000000000000004,-0.05832974895405031,0.047380173836145456 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark12(-31.786989819447896,-60.71481833138033,0.0,65.94196943143112 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark12(-31.82458474453128,-15.858694547007282,1.0,0.053540101251331296 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark12(-31.89008073520936,-3.9424450271225755,0.2574571909203254,0 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark12(-31.940852848992485,-34.103035709872124,7.008104842526931E-18,1.0 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark12(-31.97246316446549,-62.99686926068226,35.95235703979816,-1.0 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark12(-32.218238789091316,-14.240623550412991,-30.09031307082286,-99.09444447197775 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark12(-32.299243299221644,-41.52987418828473,-27.57438043756804,35.07229318792599 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark12(-32.40903815968501,-37.95550375357463,0.05352146326474304,9.055632383191039 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark12(-32.54157049792332,-21.475706233384532,-0.053809818861593875,25.382998644860947 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark12(-32.56773113653494,-64.73742448788586,-4.440892098500626E-16,57.83786127604238 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark12(-32.609018424538796,-19.806262699837745,0.0,-0.6253052602445768 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark12(-32.689399357721854,-7.538092392240856,-1.0,0 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark12(-32.7856300484268,-100.0,-5.551115123125783E-17,-0.8061872880419723 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark12(-32.93243098788874,-65.96209124946425,0.3730911768307902,0.0036871867604286275 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark12(-32.93654245251132,-52.661846269065094,-62.73391888960618,0 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark12(-3.2953272669064404,-74.5923051327515,-68.0985942757196,0 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark12(-32.96589613310917,-24.35976671396527,1.0,1.0 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark12(-3.3238140170261516,-20.405378658147384,0.0,-1.0 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark12(-33.30427870474854,-91.82676324793536,1.0,-0.05076602974463465 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark12(-33.32159252722111,-28.913696778978714,12.779033194961684,-0.9797129834300732 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark12(-33.42317842061193,-93.91842070404115,62.77839856205597,-1.0 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark12(-33.45569959652539,-3.440326924299701,-0.9722117744372205,-70.00704914482698 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark12(-33.45907207220464,-52.3188290758418,-0.9055626798089882,-0.45881371874509913 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark12(-33.581695101677205,-34.96651536214367,0.0,55.13783468789414 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark12(-33.693077327900056,-94.52371619247434,-0.9795378695281328,0.2990576783714445 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark12(-33.70709732301616,-2.449069006713919,-1.0,-0.06255940970477318 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark12(-33.71331324600966,-23.01957079813036,-0.04513155284558157,-0.051994935359010314 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark12(-33.74870508055416,-100.0,71.99412703896084,-0.8007264928270104 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark12(-33.814570400560754,-58.82350180656397,1.1102230246251565E-16,0.6652382980966368 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark12(-3.386206019430798,-67.10710719395098,-87.86032870965383,2.710505431213761E-20 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark12(-33.980679400228624,14.610634323182083,0,0 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark12(-34.04495316897031,-109.2287171974793,-0.9662807805960055,-2207.606259820311 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark12(-34.090034038786854,-60.198787849950456,0.0,35.06661230551169 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark12(-34.20453133107758,-11.020616311919278,-1.3877787807814457E-17,0.5333323921718208 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark12(-3.4454156269456906,-63.60681987688964,-2.7755575615628914E-17,-1.0 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark12(-34.58189102240206,-51.65356079012887,1.0,-0.9999999999999964 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark12(-34.61168437306505,-72.88226233409502,-1.0,1.0 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark12(-34.62679779887742,-174.22158862142584,0.0,-2331.3305337786956 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark12(-34.698764171761326,-15.549472998005253,-1.0,1.0 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark12(-34.700779914320584,-28.70179104921945,0.03515812233067617,-62.1346235650373 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark12(-34.76660041549373,-56.71361423053449,-2106.3480616657907,0 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark12(-34.785336800466766,-32.04423605640729,-0.05195562064685055,-47.99360520401726 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark12(-34.90664361260775,-86.595904990582,-39.472129899944235,0.8683502481292508 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark12(-34.97426210956571,-7.346716879998711,-46.52950101038944,-1.0 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark12(-35.005097853356624,-57.63479513450996,-1.1173531783087518,-9.580536569911375 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark12(-35.025468361476754,-81.3890253831778,-1.0000000000000142,0 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark12(-35.11684508592281,-27.05298596564137,-0.9999999999999996,0.36954774279170594 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark12(-35.1460133995239,-60.85716324608607,0.008061218838237183,39.65845205741287 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark12(-35.224483646517704,-100.0,1.3877787807814457E-17,1.0 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark12(-35.25732100446216,-1.9853847046489648,-1.0,-31.08470278681638 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark12(-35.38855568402867,-98.40553120564576,-0.98735641234734,-1.0 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark12(-35.48584297932674,-100.0,1.0,0.3620993383874425 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark12(-35.52995911433429,-34.485726225873556,-1.0,-0.9925063457337175 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark12(-35.568368751963085,-3.4571610576594236,0.02975633073237821,15.213503123665939 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark12(-35.58895903202976,-78.28949420505916,0.04462024293891531,57.233468627147744 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark12(-35.628876764955166,-4.673238487740306,1.0,-1.0 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark12(-35.73099078030306,-14.469912445184749,-1.0,-0.7051240736326994 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark12(-35.85850554268066,-28.11398776315248,-17.684901477221572,1.0 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark12(-35.86834300499808,-22.789622061682934,-84.75243488017988,0 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark12(-36.07280921998008,-43.50896328067733,-0.2589660291711765,1.0 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark12(-36.31512862101904,-1.2321098788784468,86.43287157846308,-47.5869997798456 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark12(-36.355919767422336,-98.50422186499573,-0.009306639479765733,1.0 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark12(-36.40277359536294,-64.83423935317937,-1.0,0.22301720497755406 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark12(-36.55921717113803,-42.61771894562827,-1.0,0.6097794616639998 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark12(-36.60341739297893,-54.826496666006264,1.0,-52.23637004574968 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark12(-36.6106936757822,-81.14605490054407,0.9999999999999991,-1.0 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark12(-36.62695983963469,-90.49039987191287,-0.28728288755674447,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark12(-36.75301418885197,-45.66416532790731,33.473446156913155,-49.00634511482767 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark12(-36.799161602814955,-50.29263041336118,0.8380114056455475,0.46734219850051906 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark12(-36.85864920437856,-45.00955506590926,0.030985428049537328,-0.9310658010505791 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark12(-36.94439495836128,-41.4595765859702,-1.0,1.0 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark12(-36.97094483357515,-24.8723966962974,-0.644556629704046,1.0 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark12(-37.171796267018486,-95.32374721732066,-86.31470952464207,0.028832829307094462 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark12(-37.23588277018829,-100.0,0.11575031696786021,1.0000216804348212 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark12(-37.26506024917783,-100.0,1.0,1.0 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark12(-37.40073275827052,-68.7268875435576,-0.5204512536632263,0 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark12(-37.44863402824087,-46.2569720021893,0.03027734563963047,-1.0 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark12(-37.460143283800896,-100.0,0.9230053036883663,-0.3902402409844473 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark12(-37.651482489927716,-88.83949043079946,-0.7902057054819318,-1.0 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark12(-37.80172869005892,-89.25816242374826,0.047379207614446806,19.328174758318887 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark12(-38.05673836381409,-100.0,1.0,-0.5389895811155244 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark12(-38.077854207991116,-18.66164921047017,-0.057105327019424085,91.12395119922982 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark12(-38.20166572826695,-46.948087193258026,0.9999999999999964,-82.32803236719212 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark12(-38.20249460261,-37.45631923911241,-10.553246835549473,0.9999999999999982 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark12(-38.31660030456682,-70.47310884507696,0.9430077621370542,0.030840148956842423 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark12(-38.49064937729348,-55.22724242167566,0.9354855664009796,0.827527923454197 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark12(-38.653187693903604,-74.60221463669924,44.42283422479157,-1.0 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark12(-38.675604851338605,-63.28427083620283,-0.20675552070970893,-64.99628614917879 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark12(-38.677294550283165,-100.0,0.8626475814757981,-100.0 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark12(-38.89359541432188,-100.0,-1.7763568394002505E-15,-100.0 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark12(-38.899002627353326,-39.429848558444874,0.4389409490197621,-1.0 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark12(-38.929041462826255,-10.54886978852376,-28.642477543997686,0 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark12(-39.03734442091781,-27.846597570151438,-1.0,-1.6543612251060553E-24 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark12(-39.05036588875664,-75.7281760921842,0.0,-0.015280725181175292 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark12(-39.13227609932864,-100.0,-0.23093242466276553,3.8718985516580626 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark12(-39.13619391399528,-99.23497367804958,-85.18656182411732,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark12(-39.140265413643235,-93.37334550191316,1718.0999312965855,0 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark12(-39.1635759349881,-7.002483586738483,5.551115123125783E-17,-1.0 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark12(-39.24838670958346,-100.0,-0.0418459405696687,1.0 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark12(-39.30734144951982,-78.60187255832084,0.8068721029107903,-1.0 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark12(-39.310853014814846,-58.926725665006,-29.02231434593028,-0.022448081991377475 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark12(-3.9368344732970733,-30.456274220243433,-0.05369766200482342,0.024123244479812758 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark12(-39.420368051620734,-37.18146281898255,0.0,59.155733523821624 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark12(-39.511899747155574,-100.0,0.0342018203532873,-100.0 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark12(-39.75873746404799,-1.9386515061287781,1.0,0 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark12(-39.784888941932735,-72.15679456365592,1.0,2.220446049250313E-16 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark12(-40.03892077138979,-17.527672564154983,-0.8974743595383097,-1.0000040387035092 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark12(-40.175805325233576,-47.26514398281347,-0.9390777539189424,1.0 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark12(-40.22386436933794,-77.77926854467904,1.0,0.7762899806638167 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark12(-40.31167810950393,-23.53255207811401,1.0,-1.0 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark12(-40.34617199687477,-11.710030071330744,0.047123845490081084,-0.9990845896908541 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark12(-40.353731673328454,-74.57414008564065,0.0,-0.9832194830314848 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark12(-40.499293544801105,-61.92491594695015,-86.53401138160741,1.0 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark12(-40.50669516458653,-82.09965633724931,1.0,0.0 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark12(-40.56492164985907,-26.785220564212125,0.0,-1.0 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark12(40.6457255172802,0,0,0 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark12(-40.65564668662973,-32.00872025239979,-0.6420509444910926,0.318069659823199 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark12(-40.677135315807625,-100.0,0.8454778604332792,0.9999969416686685 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark12(-40.79660677772259,-3.2449919642101044,0.7768747342304829,-1.0 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark12(-41.03601293510146,-7.846315377492587,-66.73377596135305,0 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark12(-4.109282938307695,-97.09454691220104,-67.53560495861974,-1.0 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark12(-41.227401469276614,-83.58661466880486,-39.9207443209145,0.0 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark12(-4.128327892265761,-1.1092403378037072,0.026708106141315108,0.0014755132215569233 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark12(-41.58588595278292,-12.551904831914676,-0.01052003305472417,-0.02648548438034415 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark12(-41.595132550183344,-29.78286012542561,-26.457980334759363,-1.0 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark12(-41.59614515906285,-45.48319162020973,-68.12852847180552,-1.0 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark12(-41.79328094793127,-55.71777219061952,0.018656700054686004,1.0 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark12(-41.801582808504484,-88.4577199904071,-1.0,0.9948574781815764 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark12(-41.874097130144,-43.88151863040256,0.0,-55.54730584109275 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark12(-41.899375956880604,-1.9376156198027843,-74.34301396609717,-34.023438933874644 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark12(-41.92381143972743,-4.290977862964397,-6.99403756605615,1.010647568535265 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark12(-41.97211519389008,-16.18714663445435,-69.21561083092223,-1.0 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark12(41.99075085565954,0,0,0 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark12(-42.10559851664117,-7.273166650602491,-3.8392238435728152E-239,0 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark12(-42.21494761467744,-8.833699526223672,-0.05112513506704022,0.9999999999999964 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark12(-42.2415077045069,-57.261982556878394,-1.0,1.0 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark12(-42.267035570963834,-24.484611328741504,0.00736400018571836,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark12(-42.29256070495522,-87.14842872796305,0.9259456614488719,-97.02078824967121 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark12(-42.558879231531854,-37.90210349540812,1.0,-7.888609052210118E-31 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark12(-4.259258252886105,-16.17610881314163,0.7300016643573559,4.2168791772922093E-81 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark12(-42.6904126039403,-65.38700343094214,1.0,0.46709487234544733 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark12(-42.75913179789309,-100.0,-1.1299783688487461,1.000000239335141 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark12(-4.2812286898666905,-42.174895835915514,-0.900413358212671,1.0 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark12(-42.915548575506925,-49.08888358806496,0.02059779873654909,-53.852210808838066 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark12(-42.9295102843193,-100.0,-1.000000000001211,0 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark12(-42.977632467132594,-75.35349043860697,-8.73623861162059,1.0 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark12(-43.02982471072143,-15.989362229960324,-0.04774727464063522,40.61228631514766 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark12(-43.105856941684955,-39.814901154696884,0.0,0.0 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark12(-43.214317529631394,-2.798557609393356,-0.9137132541488338,-0.6618625434338838 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark12(-43.266385464806234,-34.2317811818391,-100.0,-1.0000000000000004 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark12(-43.34056275207402,-88.76562872693553,0.0,61.994550057716154 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark12(-43.35734406850489,-57.2146455772131,0.35303344783245505,0.9999999999999992 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark12(-4.338073752337564,-77.07504076313342,55.71633422917272,-0.7966980488672027 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark12(-43.395087527075724,-54.601042002015646,-1.0,-0.5637611653536845 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark12(-43.46825504024688,-53.134308434161646,0.03876820045564892,0.9405063450381592 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark12(-43.476616946436344,-90.47872419124927,25.607730777209355,-1.0 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark12(-43.48601258293259,-40.79202389162835,0.9986864541734543,-0.7020892906930227 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark12(-43.55518868634376,-40.73862521577165,0.01336483825824391,-12.54281759631057 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark12(-43.57461905325671,-100.0,-0.9402931349532642,-0.7482364524115733 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark12(-43.57526414275013,-55.19943525333993,0.2894367364316036,0.22137811229984594 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark12(-43.593983809180955,-8.319687121964536,-71.40532845197811,-2427.4445860602104 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark12(-43.59540912510351,-59.809581416679876,-24.32560320280851,0.9999999999999991 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark12(-43.751140667067496,-10.283766194487539,-1.0,-0.6219542132970908 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark12(-43.941333352831926,-24.166532636914052,0.02424936573239473,0 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark12(-44.01895587071466,-86.26719010663072,-1.0,-30.318656439459687 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark12(-44.1252277196802,-47.819645274239605,0.958925557453553,0 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark12(-44.18200438072453,-34.67041889177955,-0.9759886045945088,0.30538853456886317 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark12(-44.24674085389712,-100.0,0.04888515057869419,-0.9436215418357672 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark12(-44.25241045893223,-56.317479707397574,1.0,0.1032666664695312 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark12(-4.430176016484424,-37.13101931398474,-0.643884368360919,-0.9762391607275799 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark12(-44.31417088311672,-38.42115450504067,0.044544468754169786,-22.709719909181583 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark12(-44.467846740847015,-91.9912654572986,0.0,0.9956485312070709 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark12(-44.474447725141054,-47.263828738071794,71.87279602920931,-1.0 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark12(-44.52555303579542,-79.48675761572481,0.22680822340206808,87.0538507838638 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark12(-44.55508395914485,-76.50622389383554,-1.0,-65.52982580998732 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark12(-4.46980003824873,-12.476991774242023,-94.11252885222956,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark12(-44.70579407793444,-6.746865054909646,-0.9999999999999991,1.0 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark12(-4.472732353700285,-52.44834538751212,0.017708144703607154,-0.04750774221336884 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark12(-44.90565713432304,1.0,0,0 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark12(-44.930974329746434,-19.72817277512016,-1.0,63.12760635152951 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark12(-44.95438194899796,-36.909711813628206,-1.0,1.0 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark12(-44.992680140509385,-76.57792378323781,-0.010088567315329748,0.992067171126774 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark12(-45.041879880689,-53.11134138211061,-1.0,3.3881317890172014E-21 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark12(-45.415116751514745,-61.69018669170606,0.9717079871817941,-2184.914769113217 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark12(-45.47271898463342,-99.01941977127038,0.022819156670315907,-0.5619632214557342 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark12(-45.47600827313565,-60.50808710213198,0.8307914440613624,52.218295073825345 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark12(-45.5421159013722,-87.35424134299065,0.0,69.42678165936402 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark12(-45.625100864369,-72.16541732993274,0.027409104820637572,-72.42365869467676 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark12(-45.719433772129705,-17.620758161579552,0.30247149028361486,-52.6640291471685 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark12(-45.87379280993748,-48.75255646371902,-28.933501861680583,-1.0 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark12(-4.590702753462241,-78.90052642068025,1.0,-53.45389327522141 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark12(-45.91594251298268,-100.0,0.0,4.440892098500626E-16 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark12(-45.932250136450406,-30.721019271135106,-1.0,0 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark12(-45.94963384266728,-41.04390741996092,0.021201148889328315,0.97147448363977 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark12(-45.99279851190121,-64.23877698327107,-52.28189742044871,-0.041799784036135545 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark12(-46.069690058832464,-46.17481430351627,0.3779885120132388,1.0 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark12(-4.609289827496311,-60.495427021206446,0.32048768685916196,-37.69974086239314 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark12(-46.127368758498164,-24.853563192657802,0.004856877550739852,-1.0 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark12(-46.13398785107385,-7.584897714426318,1.0,0.7756772667185352 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark12(-46.21571900096397,-46.52614104667688,0.05830286548686145,1.0 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark12(-46.36258711728352,-85.38005083836073,0.9999999999999998,41.0405738685852 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark12(-46.43491940572597,-72.59312297423864,0.0,-1.0 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark12(-46.44217835887519,-58.531391289999036,1.0,-1.0 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark12(-46.45524076295325,-153.84419532729558,0.0,73.98849776543958 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark12(-46.48277983793092,-12.562552059575289,1.0,0.6674966228863238 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark12(-46.487976697517134,-60.75107740940797,0.9721424697497876,-0.9826061055294011 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark12(-46.51575050976194,-28.32962030643717,-1.0,0.0672273460047883 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark12(-46.5540500876302,-49.6015749969967,-65.20903888186008,-1.0 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark12(-46.71435933519476,-33.491824052462206,-0.005465839258886451,-1.0000015819933417 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark12(-46.71997629446656,-59.020152032468424,6.878886681303891,-1.0 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark12(-46.86476650389665,-4.620051771889646,1.0,59.21888822392668 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark12(-46.88601773806753,-90.84370632697215,0.9471734794475424,0.017952415309062164 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark12(-46.891333836868895,-99.1456605682155,0.0,0.9540018755356743 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark12(-47.016585920585875,-100.0,0.0017908876903200421,1.0 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark12(-47.04659974697796,-85.47755454205924,0.0,-2341.296022467207 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark12(-47.08036305169754,-50.418363093348745,1.1102230246251565E-16,-1.0 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark12(-4.7192736416392735,-39.59895663556274,0.0,-0.055280763797275756 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark12(-47.28157897993486,-88.26589847883369,1.0,6.425328990792789 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark12(-47.32577743298737,-59.648594071520016,-24.06624793013914,21.874765873440268 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark12(-47.391484377111496,-18.518245634604657,0.7390636678415103,-0.14535558253457975 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark12(-47.42983390137007,-100.0,-100.0,2286.078953221463 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark12(-47.487211683838346,-7.31883809842958,0.0,-1.0 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark12(-47.512165980479026,-48.08530187771857,-6.86313014044859,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark12(-47.58494416963718,-58.6935616369035,0.9010652220476061,14.043001418712702 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark12(-47.6547358449678,-100.0,0.0,-0.8476957907874106 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark12(-47.85447562061511,-30.56462945549011,100.0,-0.07547146323972231 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark12(-47.90776261585419,-81.04740134327471,-0.6239750819139829,0 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark12(-47.91755625932089,-35.15771420423491,0.6027439100549671,-0.9294193066261869 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark12(-47.99531227552958,-64.76172597432814,-1.0,0 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark12(-48.01370137524755,-31.66883055046511,0.9976170268550278,0.8584338944587608 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark12(-48.03561320039564,-60.216454376809914,-0.032647881904159515,0.0 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark12(-48.06708073387201,-87.3790634761715,0.0,-1.6940658945086007E-21 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark12(-48.08393152935775,-40.14689188915141,-88.86680174825518,57.588367798218 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark12(-48.15817484315336,-13.117970869343123,-54.022286242172754,-1.0138326702912264 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark12(-48.18025983969897,-100.0,0.7561342644204725,-1.0 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark12(-48.26426078915699,-2.539374094679177,-1.0,16.638833652625966 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark12(-4.844916727657675,-49.776857111016156,2.7755575615628914E-17,-100.0 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark12(-48.49176327479717,-74.6628775984635,-0.9437690262376307,-0.24821864263660953 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark12(-48.50362785595096,-18.35335885731307,-0.6340730933293905,-0.7659126216498433 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark12(-48.75176387616294,-39.75199610235802,0.36773667277009203,0.9999999999999964 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark12(-48.82050274954061,-5.350450678398689,-0.9147207949672185,-0.7413647155311089 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark12(-48.85300514757365,-4.335604987105021,0.0,-80.59632197342671 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark12(-48.92780772086363,-15.866119850268007,0.4146068216659007,-1.0 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark12(-48.93313768874881,-89.00660251158344,0.0,-1.0 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark12(-48.95118633099027,-88.26627299683817,-0.9870280459819702,-1.0 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark12(-48.97247322255094,-48.91206526674592,-48.91355433860332,8.954249990441411 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark12(-49.02932868215153,-15.745895020371137,1.0,0 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark12(-49.065964568309205,-40.541167630418215,1.0,-79.88327818319618 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark12(-49.06989041248693,-47.12116985333943,9.345349264752969,-35.21275359302946 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark12(-49.098150436664916,-76.39579179373796,-0.01487444160761224,-1942.2465343393185 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark12(-49.10900856770318,-15.407290951500313,1.7763568394002505E-15,1.0 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark12(-4.931176642331465,-40.64161644797521,-1.0,-1.0 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark12(-49.31452415625807,-34.37277722435904,1.0,0.0 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark12(-49.33277614475966,-39.704497745340404,0.0,2414.747033216922 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark12(-49.34897963401005,-100.0,1.0,1.0 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark12(-49.353249306470516,-79.55417766830065,0.4217636560420781,-61.30418924976016 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark12(-49.38142529917791,-27.14755237570015,-1.0,1.0689057858265905 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark12(-49.382307862793965,-72.76419207906093,-65.52690661018785,0 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark12(-49.46938809781432,-71.53032594483058,-1.0,0.8859771689201903 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark12(-49.48343484115119,-100.0,0.9999999999999585,-1.0 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark12(-49.56284601449346,-40.05886012215565,-0.4102018145447063,-3.364429480291733E-16 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark12(-49.702702637981155,-26.84980831249314,0.0,-0.9360126279573918 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark12(-49.76216882620123,-23.903832964685364,-1.0,-1.8033161362862765E-130 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark12(-49.804628829386914,-43.51511581217449,-73.37730058553093,1.0 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark12(-49.86822057224484,-83.58003489523126,-0.015870943807068605,0.47953817091866924 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark12(-49.87451171034303,-12.707542752245232,54.89154283038013,-26.56186337135118 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark12(-49.945323009346524,-35.64174410726198,-0.9696906251892249,-84.61491832512127 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark12(-49.979156164961054,-48.4374556809855,0.9954376755421344,0 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark12(-50.148327184659806,-26.927429876309873,-18.0549249961568,3.598029514319961 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark12(-50.16052908788593,-55.123306114766166,-0.15369465802984006,-74.69632621371322 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark12(-50.22019643424571,-68.73247453013882,-7.795559540326736,0.6019646780471484 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark12(-50.35832668958339,-5.5565230354650526,1.0,1.0000094605620145 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark12(-50.430852149566675,-30.227714545417612,-1.094537900786795E-15,0.9862249662613529 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark12(-50.43986157258456,-13.711205108772765,0.19784899651060442,1.0 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark12(-50.59260955141139,-63.645257497388364,-7.604982274609424,-1.0 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark12(-50.634949283326115,-98.75141242466404,-1.0,0.38569584489111786 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark12(-50.6526217197832,-13.309830549700381,-2.7755575615628914E-17,0.08180380320662593 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark12(-50.68095702147366,-14.614210738857391,1.0,1.0 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark12(-50.70016200213616,-68.77223009071822,-5.118603206076546,-0.3621072509903227 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark12(-50.7594493245247,-100.0,59.28013280153928,-1.0 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark12(-50.762241637981795,-17.590300238838623,1.0,0.8284270234803868 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark12(-50.88455397132138,-86.96129466168672,-0.107659532551872,43.04980952425277 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark12(-51.03223468001258,-39.34031616301467,-0.8989609389533362,0 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark12(-51.08321177988277,-11.774440427453747,-5.551115123125783E-17,-1.0 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark12(-51.192290081543014,-100.0,-0.9629075649757648,0.43008390985275313 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark12(-51.19769459401424,-94.58664379940909,-1.3877787807814457E-17,0 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark12(-51.22309632600812,-87.75944549379953,-0.06163069031752999,-1.0 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark12(-51.32127642176597,-4.463479483477508,-1.7763568394002505E-15,-34.671948518393656 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark12(-51.33565617519909,-61.61960522444122,0.972198791087321,83.05767911949069 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark12(-51.354157504341046,-61.83843014818821,0.0,-79.48077919337709 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark12(-51.375466091189075,-65.76211521129775,-1.0,1.0 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark12(-51.413969218332646,-22.29510534637854,0.44190833768058047,0 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark12(-51.41697214627742,-100.0,0.04320573056259281,1.0 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark12(-51.439831513785414,-25.15871508098039,-1.0,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark12(-51.5336327149331,-70.89065954555241,37.38135596952094,0 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark12(-51.54453183921043,-78.77179963696027,-1.0000000000000018,2311.8523503288243 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark12(-51.718839047430464,-16.427011792525708,-0.9343235148120769,-1.0 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark12(-51.774442820422294,-34.62841958391503,-69.16655846762288,34.723688147385275 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark12(-51.88904843288127,-22.745495642615765,25.128440032121404,-66.48693307623483 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark12(-51.928096468441694,-27.03897971262124,0.0,-1.0 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark12(-51.97868385475974,-95.59500539304567,0.010535973426204118,-1.0 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark12(-52.18103105694561,-73.61934005457309,0.9788986704603704,65.40168643576001 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark12(-52.255331646029646,-20.810502136841066,1.0,1.0 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark12(-52.32222300003632,-100.0,-0.7272696827031799,1.0 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark12(-52.40717468524892,-79.27411449864081,0.03777285619361648,1.0 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark12(-52.42551543671938,-96.88590296582201,-0.06256486408218932,0 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark12(-52.455004874601066,-15.790179201656795,-0.014123068578825837,1.0 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark12(-52.822978282197035,-61.11024598909344,-1.0,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark12(-52.849516930727646,-39.612709554244155,0.9340776832017671,-0.9556381678761505 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark12(-52.9275212491977,-100.0,-0.7134697728210223,1.8111358157653425E-71 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark12(-52.939536097077244,-42.97475349270632,93.14508802419454,0 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark12(-53.0198968090705,-68.42336561406495,-1.0,-100.0 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark12(-53.14609962399197,-94.38221316702594,-1.0,-0.887287519252649 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark12(-53.172518835488766,-61.10332655474221,0.0,-0.8609261360141748 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark12(-53.22109864571483,-4.945692212575251,-0.7692582214971632,-0.16429514254999145 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark12(-53.348795693161236,-33.26767054849156,1.1102230246251565E-16,0.7010815338929126 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark12(-53.413839175151374,-11.939871949131442,0.042315938916909324,-4.089235292554116E-6 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark12(-53.50548526673501,-56.905779231554206,-5.588081715400247,1.0 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark12(-53.544272107988796,-100.0,1.0,1.0 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark12(-53.59998289838822,-36.820556055589165,-1.0,0.019013231022168897 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark12(-53.62718147586356,-97.33946632881899,-0.8048028436432167,0 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark12(-53.69059757965596,-1.9182379613094156,-0.9401078724376213,79.238866595903 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark12(-5.383444086271453,-13.32230046074244,1.0,1.0 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark12(-53.862340452292926,-100.0,0.9615144945529234,6.027834726244683 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark12(-5.397740846967242,-10.280865986949921,-9.570326040962012,0.100092545375011 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark12(-54.096279480368224,-23.271931343039213,0.9999999999999929,-0.2640190311931798 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark12(-54.10177947927818,-43.21439468211742,2.7755575615628914E-17,-1.0 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark12(-54.21745239879816,-35.674434821251694,1.7763568394002505E-15,1.0 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark12(-54.2186439253266,-79.82680836269597,-1.0000000000000018,85.1830634088106 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark12(-5.441227435838824,-3.406549737641626,0.0,1.0 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark12(-54.45767280928777,-14.957654966955536,-48.00022232372541,-0.15758610887883728 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark12(-54.48945893935108,-13.796969815548053,-1.0,-0.4806552448318786 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark12(-54.54700908480361,-29.85254402083733,0.9430587438239736,1.0 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark12(-54.60097814399219,-37.374484635701386,-1.0,1.0 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark12(-5.467625809558815,-70.56781382079812,0.0,0.010256345690450702 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark12(-54.68146014352419,-91.39699696269422,0.0,39.05123320250518 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark12(-54.832651882513574,-1.3121124600887322,-1.0,-1.0000000000000018 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark12(-55.023074274974554,-100.0,-0.05511447326935377,-0.974927936767226 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark12(-5.504803741001397,-13.071923264670394,5.551115123125783E-17,-4.998926487921406 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark12(-55.23908510101019,-62.858116778783696,1.0,0 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark12(5.534316221334606,0,0,0 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark12(-55.44305118003456,-20.957550041081515,51.758712605050825,-1.0 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark12(-55.53402551280491,-97.1022993116294,93.27625721502068,0 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark12(-55.667051468645184,-64.254391750495,-0.010479902784813854,-1.0 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark12(-55.748408877760156,-19.49585507688849,-0.9965538193569703,33.68408198962635 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark12(-55.9630406258256,-72.85042394501042,1.0,1.0 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark12(-5.597809650281257,-20.211046717172056,-0.05569381711432896,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark12(-56.055144207873816,-28.742112401143526,1.0,25.444244116822837 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark12(-56.07733118053908,-100.0,-1.000000000000007,-2.8578057451394563E-6 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark12(-56.083448195047445,-86.28086820534347,0.9521002844472454,47.054113771285245 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark12(-56.11910734438355,-8.73394991421653,-46.96379630881422,1.0 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark12(-56.13731330327769,-64.27638271542378,-31.15739249660068,57.31901211275792 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark12(-56.29902000103043,-65.57890628996665,0.5642189200809102,-6.776263578034403E-21 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark12(-56.43215213040749,-100.0,1.0,-0.7855790597334095 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark12(-56.47787789321244,-94.6588170760785,-0.8657440760873459,-0.03534786094474568 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark12(-5.66174904513861,-7.432207079362314,-0.02121943575092053,-57.78531121921275 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark12(-56.67413321508026,-35.777787717347564,0.0,1.0 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark12(-56.70391649434425,-18.681005605068083,1.0,-1.0 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark12(-56.713652632074705,-23.786833059354464,-0.9375982006349836,-43.718242445921945 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark12(-56.81361310677583,-33.48545306618113,-1.0,1.0 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark12(-56.82302450442225,-100.0,-9.028269717770154E-5,0.7255441813211474 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark12(-56.915353668655165,-63.695997908903436,-0.5151237531042199,0 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark12(-56.91583174562243,-6.966798835059095,-8.881784197001252E-16,-39.74467598739385 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark12(-56.957925143237,-2.3916985144701615,1.0,1.0 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark12(-5.697471452409322,-100.0,5.585620266208725E-4,-1.0000000018454247 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark12(-56.977974537152235,-78.01070475502269,3.552713678800501E-15,-15.814427904566895 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark12(-57.143539963596346,-70.95784700099436,-0.042223868800989064,1.0 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark12(-57.17617812425982,-51.72855113575357,8.57929135542603,-1.0 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark12(-57.176729095979695,-34.14925305994612,0.5886416306128601,-0.037137717425621275 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark12(-5.725556366520178,-13.736797755045988,-0.9999999999999988,-10.064989108316595 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark12(-57.350614708872826,-86.30406435457283,-50.01483554504658,0.039395645849541 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark12(-57.40727612484196,-62.30065574067547,-0.7344121911011148,-1.0 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark12(-57.40815208961336,-61.77808581532687,-0.9999999999999982,26.785943133166782 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark12(-57.54210688020982,-43.47275566062632,-0.9999999999999991,14.431046820489499 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark12(-57.56888339027799,-71.03859699395956,-1.0,74.55164744557507 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark12(-5.758786558148234,-15.035746006470648,0.9999999999999996,0 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark12(-57.59947606186989,-54.269269191802046,-1.0,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark12(-57.62560569977167,-75.67610094185157,-13.265385111265957,-35.04742455019938 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark12(-57.64441029380733,-100.0,0.0,9.959882753365434 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark12(-57.90043537057603,-32.095273887835134,0.02605507878616886,1.0 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark12(-58.00647249551889,-46.902328160516475,-0.8431420396678247,1.0842021724855044E-19 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark12(-58.06804123760614,-11.29799715705552,27.408986387493943,-1.0 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark12(-58.07450074071081,-7.656430573548413,-1.0,1.0 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark12(-58.215598995548234,-28.393432445046116,-1.0,-1.0 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark12(-58.259725241362844,-9.06160058321015,1.0,-0.01185219785827371 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark12(-58.32279055405629,-51.33066428086115,0.0,15.610868324498654 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark12(-58.411824799010994,-70.1649519469711,-0.007653853058023685,-60.49184472781557 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark12(-58.44187820429882,-83.65176390051207,0.17516105368171875,-1.0 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark12(-58.50811271939233,-61.41525027660104,-4.944447703599665E-5,-0.4862810664074878 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark12(-5.8629451545726905,-74.7118086911479,0.002324331727684259,1.0 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark12(-58.911301133797856,-27.31727989986335,-0.6168922535149051,0 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark12(-58.93549447073225,-18.73382998068312,-4.440892098500626E-16,0.773928919358168 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark12(-58.97198535520407,-5.24103365711737,-58.60989059404324,0.00811987729395669 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark12(-59.007293243185025,-41.6770189237816,0.3192645158016896,36.99554409700848 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark12(-59.039854647969726,-75.36112261322575,-24.57848945890835,-35.20247682953992 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark12(-59.04457528870888,-39.535567154841985,-66.2868811892379,0.18124994211947154 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark12(-59.0604470825143,-100.0,-1.0,1.0 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark12(-59.104170917712146,-71.7562432707366,0.8485168555152143,1.0 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark12(-5.91218128837961,-5.206922612931854,-3.8329572593811743,0.06255279063155135 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark12(-59.36268354207082,-100.0,1.0,0 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark12(-59.470743746039304,-53.71633737656135,0.012233349003212803,-20.592194709249945 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark12(-59.54234102431218,-21.60955378127222,-0.23407682959808263,-0.00687410603169622 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark12(-59.578543841600805,-46.12193689606352,1.0,1.0 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark12(-59.626152585919925,-25.87160268153649,-1.0,-0.8163745086981623 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark12(-59.78548907087239,-11.001646687924957,-1.0,0.8128584518886829 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark12(-59.78640981135646,-59.66113579560641,-1.0,-9.733307494185965 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark12(-59.874123765518085,-100.0,1.0,-0.9570112693626552 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark12(-60.03144953661283,-62.06490372033387,-1.0,0 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark12(-60.10787321158533,-35.76029170043263,0.4658274764140913,-0.6840940052780438 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark12(-60.24599720287262,-46.79563308002479,-0.026528537774287875,-1.0 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark12(-60.37629047362685,-75.71319343003623,0.7399310080707309,-3.3064708653659336 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark12(-60.43040116632658,-61.49426206078092,1.0,-1584.5981668885352 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark12(-60.47216292049173,-100.0,100.0,-0.054731128714386346 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark12(-60.49717045683416,-58.09238616530134,-14.844345585326437,-0.0067286085535169515 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark12(-60.58292278184992,-15.140884271016006,-23.31365381158425,-0.7214313028888562 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark12(-6.067828089817658,-100.0,-1.0,-1.0 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark12(-60.67953621651476,-87.71036706864213,-0.2274564896002058,-1.0 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark12(-6.070662820844191,-10.63097970531129,85.95750326511413,-31.40448566631362 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark12(-60.770914952783066,-15.166944162003611,1.0,-0.0529453665261064 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark12(-60.84512656390546,-1.813005668713501,-1.0,-2361.654807161799 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark12(-60.88872500667899,0,0,0 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark12(-6.096419427245792,-52.10241958063676,-0.026464636949028758,0.031054142005371613 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark12(-61.02111073242818,-78.08770020718424,0.0,-88.32812725308291 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark12(-61.04059604027709,-16.166846003493824,-1.0,50.34262928202716 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark12(-61.0756083876846,-20.95111279136139,-0.8653141481635445,0.9106646383801712 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark12(-61.15032057733549,-72.26131155706082,-15.576413451376993,0 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark12(-61.18074054445452,-25.48287027460796,-1.0,-0.9375188319152103 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark12(-61.408842682207556,-45.55120342666543,-0.8275939407168784,-1.0 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark12(-61.488757890785635,-66.75810258509043,-1.0,0.0 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark12(-61.566507290115055,-61.46888955055652,5.551115123125783E-17,-56.95205963427177 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark12(-6.162591209965299,-94.51208241643157,0.9981905928894816,99.64070082389495 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark12(-61.7011024460323,-84.06154105159455,1.0,-1.0 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark12(-61.70149709808497,-30.055981205259542,-8.881784197001252E-16,-0.14927458395847726 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark12(-61.74415547404047,-73.65135467590241,-1.0000000000000018,2333.434547245896 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark12(-61.902897016345975,-41.387674320418434,0.0,-1.0 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark12(-61.97011615978911,-40.64925475824675,-1.0,-1.0 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark12(-62.03397570106133,-96.2276704295298,-64.72174043505312,-30.827513741145452 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark12(-62.27744396601983,-94.63482553278787,0.0,8.673617379884035E-19 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark12(-6.237543188629331,-65.19623385550689,0.02576544863473845,-1.463023860841312E-98 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark12(-62.405032459192626,-100.0,0.012767031144403418,-0.18440369431742362 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark12(-62.437906946764,-77.74027134507854,-5.857865251692878,-1.0 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark12(-62.51425764186003,-11.680146190947859,-0.9999999999999996,49.23015187313583 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark12(-62.5317024385002,-1.5055417896119003,-0.9999999999999991,54.66416357402131 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark12(-62.53455139166859,-15.600103599534544,-1.0,-0.13614191660933092 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark12(-62.64973354695535,-75.38820826426785,14.81053831158414,0 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark12(-62.70149295819972,-100.0,-0.8184589420813183,0.03445409950281403 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark12(-62.7995885968172,-23.39326178309216,0.0,0.3786731451866707 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark12(-62.86039416116074,-67.54831996167952,0.0,-4.480190155660495 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark12(-62.922536775113414,-27.440389590954823,81.01801255909243,70.43225277608639 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark12(-62.94656890657384,-20.184902841283815,0.5886653346423345,-0.9999999999999982 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark12(-62.99263577937357,-92.69576386226909,2.220446049250313E-16,-0.33065526383964683 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark12(-62.99306541120052,-83.43950258763797,-27.8763211575142,-0.5288839168666704 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark12(-63.314326687484645,-60.496242871088256,-0.4750135434848436,-1.0 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark12(-63.70243891402744,-48.24518792147894,-1.0,0.0 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark12(-63.89624259129268,-48.08705542901236,-10.93787995848372,1.0 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark12(-63.98695841414365,-29.317588581454345,5.551115123125783E-17,-0.025139245994936776 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark12(-64.05971408148777,-76.19854993790602,1.1102230246251565E-16,65.10886670860754 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark12(-64.09795897290404,-11.217974356127558,-1.0,-0.025307303228320976 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark12(-64.27187065236367,-44.92310002233472,0.0,-63.52811344572314 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark12(-64.42771851930856,-78.37290635555698,-17.604634718911385,11.002908480490873 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark12(-64.50418406113994,-31.740642398625024,-1.0,0.0 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark12(-64.56881627097513,-51.10620732900314,1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark12(-6.458126812966147,-59.67822384732963,1.0,-0.012324326777185876 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark12(-64.67575496902646,-30.311676096028314,-1.0,22.357677023803966 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark12(-64.7993649915334,-10.384489436480694,27.41005483581383,-0.09495725402574018 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark12(-64.80783046944585,-6.739009581523355,0.0,0.0 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark12(-64.87111937699245,-98.39001458076046,-0.6018718085154615,1.0 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark12(-64.88951737485704,-44.00120377298312,0.11483403758977984,-1.0 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark12(-64.91904362149772,-40.41152913390736,0.0,0.9999999999999998 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark12(-64.96669100287983,-83.1270201602721,-42.540588163319114,0 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark12(-65.07224666808676,24.961268784156516,0,0 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark12(-65.26257339116177,-22.58204517146953,-0.03795103332565356,-1.0 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark12(-65.33082991130566,-65.64961311444976,-99.8768230037746,0 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark12(-65.3400330484924,-39.588768325497014,-1.7763568394002505E-15,-80.68251256795365 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark12(-65.402167730314,-43.54318718026252,0.0,0.419991119541015 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark12(-65.40941520210792,-95.6664196587679,0.9896618828995516,-97.73430538618729 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark12(-65.42811773850117,-23.704344438466613,-0.7806890693238433,91.80690565365018 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark12(-65.52726473596162,-82.84949405698111,1.0,23.191921902874007 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark12(-65.55000801876662,-100.0,-100.0,-4.3368086899420177E-19 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark12(-6.560836468708331,-36.24239010898984,0.032749057205960524,50.158974115494516 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark12(-65.6368753734541,-81.87684405020289,-1.0,-16.63656498909007 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark12(-65.78614049374728,-36.1803566971192,0.9424244821396235,1.0 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark12(-66.06741329674743,-47.78061540344345,0.0,0.5471565586508218 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark12(-6.607434754407013,-11.901521337389655,0.5976774263449756,1.0 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark12(-66.18558873033396,-47.289345475988064,-0.06987261472029616,0 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark12(-66.19283407725979,-91.79818216001885,20.793843978389386,0.0 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark12(-6.626009264509836,-27.640516764926822,-0.015489495686680954,-46.358640788814476 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark12(-6.627982370470404,-73.08545496108883,-1.0,1.0 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark12(-66.37885025618174,-83.22794258376776,-0.030380603496057312,-1.0 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark12(-66.45541119279105,-97.1959885684485,-1.0,-1.0 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark12(-66.72312919464352,-41.56853856378113,-0.9055355722672866,-0.9872454079696693 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark12(-66.79696505777704,-44.599230729374625,2.281915580762104E-15,53.89563280476534 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark12(-66.88242610033639,-22.554512705168918,1.0,-100.0 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark12(-67.02939496368211,-49.13475921995882,1.0,-0.9999999999999991 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark12(-67.11228696921911,-34.544774449187244,-0.05592936861031439,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark12(-6.713889086410403,-88.30461845721547,0.026258527692678335,0.9819025490016925 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark12(-67.27250959444854,-35.43332115238702,1.0,69.64029536944945 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark12(-67.3661090167225,-37.034340213175724,0.9999999999999964,0.04760815118588746 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark12(-67.54703317897841,-65.29204679363664,0.0,0.5318755400183262 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark12(-67.65355888322225,-43.52347021782859,-1.0,0 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark12(-67.78801874129718,-87.40962260806208,0.050597650667102874,55.147478920857345 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark12(-67.8082792954601,0,0,0 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark12(-67.82332522276006,-57.46293134832339,47.17650705608244,-2419.918117851256 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark12(-67.8378200508053,-41.4584442821351,-1.0,-1.0 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark12(-6.802402507907339,-100.0,-0.9999999999999982,-1.0000007871283008 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark12(-68.17461188983724,-25.914676439103022,-0.8153525366986889,0.9999298176174427 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark12(-68.1846702793484,-12.554266085165825,-0.21979384957373194,-0.9582584405355163 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark12(-68.2020035629229,-54.96872526226549,-1.0,-0.9999999999999991 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark12(-68.21394759269307,-51.48901658357159,-1.0,27.12058663197272 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark12(-6.821835303908159,-3.1660000811932605,0.0,21.968422840692796 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark12(-68.25620908650112,-65.52475694318848,1.0,0 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark12(-68.30094297605687,-47.37930401764909,-1.0,1.0 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark12(-68.31127370908715,-55.791200340839445,0.5403639260932471,-1.0 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark12(-68.47535203659426,-17.09437235195813,-0.06211865229486968,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark12(-6.8498966904348375,-14.696524726735712,0.0,-1.8546030753437107E-68 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark12(-68.55386900270493,-32.53362745340944,0.0,-1.0368766088002102 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark12(-68.58971351860205,72.0906655182799,0,0 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark12(-68.60658261352025,-73.77963296032601,1.0,0.6647670836251438 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark12(-68.70038577798894,-46.9826403379677,-0.789412469711036,-1.0 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark12(-68.7079568876606,-38.31478939777939,0.0,0.6666889438788829 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark12(-68.72430670921676,-20.32799807348216,0.9589515743253205,68.89956315686528 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark12(-68.74872064748212,-22.399441676687438,-1.0,0.6771633727572558 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark12(-68.91671279408885,-100.0,-0.03367829190173399,-100.0 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark12(-69.008997126493,-75.38531932416915,-0.006339080320892587,1.0 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark12(-69.03324448944072,-8.062819332976495,-67.2162156868987,-1.0000000347369646 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark12(-69.04339130739385,-100.0,3.706528905289552E-5,100.0 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark12(-69.04969392699556,-84.88997381985317,-0.5197607389567949,65.00818575749445 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark12(-69.30753023453686,-100.0,0.9351795285171502,1.0 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark12(-69.31047072832118,-27.817157862127086,-0.022357487246202457,-0.9807415061846088 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark12(-69.58009236402225,-30.738820805528295,0.0,-1.0000031363190096 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark12(-69.63931538800432,-83.37709084682704,0.0,-0.9046721120219597 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark12(-69.69354023124697,-100.0,0.8714032648121552,1.0 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark12(-69.75443250491676,-33.79022720080677,42.389800849972296,-0.5471240604392298 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark12(-69.76222374408874,-4.267157675649878,-1.0000000000000018,-1.0 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark12(-69.93645365369912,-26.321759181508575,0.0,0.8923163851279925 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark12(-69.99121394055167,-72.44381302596742,-1.0,-1.0 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark12(-70.10541388903529,-58.42229806684803,24.793876377925983,-1.0 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark12(-70.16558337545862,-83.94783533330177,0.0,0.9999999999999996 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark12(-70.18243300175085,-91.8276386424139,0.9052554454082851,0.7401933196503154 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark12(-70.26801383893665,-4.209175352376029,1.0,-0.9950666069857813 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark12(-70.33423474056823,-93.8088220693761,-1.0,-0.008463187028819041 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark12(-70.35133756895789,-27.28089760849436,-0.010535734913286902,0.8920332559748313 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark12(-70.45149342326606,-23.96029977349278,0.9947815735591832,-0.4516199339156254 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark12(-70.5940024982321,-86.08265573974703,-0.8203085739815437,6.938893903907228E-18 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark12(-70.77396880467741,-50.60526458928816,1.1102230246251565E-16,-0.784655106164252 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark12(-7.089508769092845,-51.87199510511646,-82.13667833241034,-12.988327870406934 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark12(-71.35312065108812,-40.812885373691934,-0.024725728317555457,-95.79171439705696 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark12(-71.47177999988142,-58.11378685040421,-0.009208040181090449,-1.0 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark12(-71.47191616300222,-81.07117768790128,-0.5085031395058992,0.7387033247434298 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark12(-71.48743210213584,-100.0,-43.65500894340081,-1.0 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark12(-71.5002992182344,-47.41570884511764,0.0,6.776263578034403E-21 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark12(-71.64314846588135,-90.57307322860433,-0.05380700596827037,-38.41566649127351 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark12(-71.65567213251644,-36.838502073817786,0.024285492521935306,-1.0 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark12(-71.67376188449593,-100.0,-56.93280416154314,-0.6997823797914083 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark12(-71.72837721949526,-17.226894630872465,78.66498462047488,-0.9448981249807089 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark12(-71.91084270303148,-37.149092889327356,48.30614934680075,-0.9422042172292219 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark12(-71.92882962422802,-9.467042906353623,0.0,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark12(-72.04613933840302,-69.41904671621353,0.7123435743689847,0.9075564489380992 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark12(-72.07863486565964,-98.06934020446982,-1.0,-1.0 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark12(-72.1062178808657,-3.364079898904753,-0.03332092864095476,-49.73044607978856 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark12(-72.17850036740806,-86.3486551258079,0.0,43.69999846625616 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark12(-7.221020154623252,-36.320863090904474,-0.03237977170101869,-0.9784391278927842 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark12(-72.21095672844456,-67.25415037707522,-1.0,7.231304423362397 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark12(-72.33398614826207,-98.30512712180916,-1.0,-1.063835311163583 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark12(-72.35509778269211,-26.468448271651113,-11.541337303697755,-42.46405150364363 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark12(-72.47651995957317,-21.5388680110629,1.3877787807814457E-17,40.786290739714076 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark12(-72.66311151676355,-7.4574281509405544,0.039805718165071426,50.306653185245516 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark12(-72.68254840401673,-42.21838762470033,-0.06130651987610938,-1.000000012579681 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark12(-72.8392293211161,-1.5482214436725517,0.0,-1.0 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark12(-72.97065439289787,-18.733316326423974,1.0,-36.428738570031285 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark12(-7.297204466731095,-38.8681914737874,-0.27770908962133034,54.47031973673201 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark12(-73.01559763402457,-17.926491196958622,1.0,1.0 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark12(-7.312938975112246,-2.9282742718269787,-37.482788356002295,8.649264108231463 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark12(-73.25622169919242,-63.640713886944496,-0.04470195765803543,32.07176977283157 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark12(-73.28551961932364,-9.151536710845843,0.9999999999999991,30.71762296135328 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark12(-73.45943439466578,-26.615761635314342,28.276815741486587,0 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark12(-73.51153788687192,-67.04253055218875,0.9297425640078505,0.04811851393115707 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark12(-7.3533970556437325,-2.003608166852658,1.0,0.8946044251724565 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark12(-73.62010485808929,-62.58814263478509,-74.51913589129526,-75.51351102401023 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark12(-73.66315337423144,-61.65859904088764,0,0 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark12(-73.70787900855262,-2.8373751840723855,-9.82002499329506,-0.9008566373860256 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark12(-73.713705060914,-6.4889225368409456,0.0,0 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark12(-73.77574888824962,-56.692378338758886,-8.881784197001252E-16,3.608864422829649 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark12(-74.13722300545211,-6.486670528750295,-12.272387030628451,1.0 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark12(-74.2005687747982,-72.47271851684236,1.0,30.107895399610705 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark12(-74.22571888111062,-6.07802252528387,0.22790383849119422,-0.37115711485198954 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark12(-74.26343012994595,-100.0,-100.0,-0.9748522625499126 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark12(-7.427770853310921,-5.405191482399583,0.9748258463867597,-1.0 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark12(-7.447194039418058,-8.261172849672656,-0.07473549300494184,0.0625575808702491 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark12(-74.52485094016092,-59.719627116106814,1.0,18.00628845075237 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark12(-74.52875979463406,-49.15158332788287,-100.0,0.9409178687551867 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark12(-74.58284758849929,-53.91212894382541,0.0,1.0 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark12(-7.460648629784991,-33.39244848924854,0.4913322971110574,0.6481924171631237 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark12(-74.64648759944475,-100.0,-0.4910867520778562,1.0842021724855044E-19 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark12(-74.71803865772057,-45.0314383752297,0.0,-1.0 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark12(-74.88331466316865,-11.458193193676825,-5.551115123125783E-17,-1.0 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark12(-75.44919114558945,-74.57970629896082,0.020271920126713104,1.0 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark12(-7.550940865519632,-44.17381158905262,0.0,-50.12126119431862 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark12(-75.6138881165284,-62.01593204851765,0.04789538986863562,-1.0 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark12(-75.62125494625947,-39.31524693839179,0.7988108634525819,-0.9860683491586576 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark12(-75.72269784634062,-93.0196864787307,-11.200642423793113,0 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark12(-7.576754800459824,-39.72831223675898,-1.0,-73.94027202515883 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark12(-75.77636757294341,-61.48340069361134,-1.0,0 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark12(-75.85658733287578,-40.93378683723067,-0.9754672918682148,-100.0 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark12(-75.87785062430265,-100.0,0.03641981657409456,-2.1933776809335086 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark12(-7.589074539123454,-65.97931271655187,1.0,1.0000360617970938 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark12(-75.90515115804449,-6.762793249072843,0.0,-0.7087863509531862 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark12(-75.91745354648137,-47.804380688731605,1.0,100.0 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark12(-75.9717209519585,-31.816505192977996,0.9612626701327802,-70.76135670264824 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark12(-76.02663620561825,-76.49804514356751,-1.0,54.55257934399977 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark12(-76.23202326559272,-85.36293880247246,1.0,0.036993370718197416 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark12(-76.27747551392756,-36.11874957804265,-0.9999999999999989,38.10370183127476 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark12(-76.35756643481984,-70.14963599306166,-0.9729629298743272,69.35834314247393 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark12(-76.37607116492772,-3.158880045535908,-0.5588982977348,1.0 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark12(-76.43487553948468,-26.95505264773959,-0.025896760139020453,0.0 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark12(-76.58445129197,-41.68548576286828,0.0,-19.571253468668626 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark12(-76.60578576857677,-60.69386702394634,0.007602655948847015,-1.0 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark12(-76.79229037252838,-93.1709070053239,0.006659837218948916,-94.82889811864669 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark12(-76.85418708110483,-98.67423830950197,0.015818000862376502,1.0 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark12(-76.90228945907269,-74.56759095933371,-78.79440216373858,-56.71306780257153 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark12(-76.95759745763036,-50.15886146200423,0.20273662818604254,-66.9367504854186 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark12(-77.1852221381217,-8.015426657885593,-1.0,97.98377048762455 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark12(-77.19601090148922,-22.67780728265035,-1.0,-2.056137490613551 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark12(-77.42319971542446,-29.57941070210006,-1.1102230246251565E-16,-0.9428265761033463 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark12(-7.743305500096527,-77.24463112111225,-0.07765419349644945,-0.0011778621786626634 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark12(-77.51641472726638,-91.3896646526217,0.0,-1.0 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark12(-77.52747483867394,-23.92036777367558,0.0,-0.004614772804586664 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark12(-77.58454273621362,-30.251783317577335,81.1419366620342,-1.0 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark12(-78.01450424913561,-6.117924331626739,21.367047351827836,0 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark12(-78.06391873962673,-66.67751345603307,0.0,-56.58429415008951 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark12(-78.07001033683403,-82.16025364508195,-24.43718045531533,56.95069166884795 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark12(-78.1546443807968,-79.97295939200816,1.0,95.13203243350367 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark12(-78.1897875355051,-5.928487022240134,-1.0,0 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark12(-78.22738500372276,-96.25526412596352,-1.0,0 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark12(-78.22890414428385,-67.65719920008583,-65.92219084923134,-1.0 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark12(-78.27581604763574,-1.2154915356677125,-1.1102230246251565E-16,2.1175823681357508E-22 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark12(-78.2789767769085,-60.290560306058104,-7.778452302656419,-0.5769618620546737 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark12(-78.44745555304605,-100.0,0.0,0.0 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark12(-78.49675391812598,-17.50510886066879,0.8485522329885402,-95.91081109706002 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark12(-78.52301064521778,-18.244908106610147,0.9357694741099916,1.0 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark12(-78.58398138415811,-56.758702254452274,-4.4347916744822786E-16,-1.0 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark12(-7.864939816863513,-67.08959464319574,-0.6957715247487821,-1.0842021724855044E-19 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark12(-78.66151368375533,-40.10458705180233,-0.05357168996220033,-0.9999999999999991 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark12(-78.6730415459469,-34.67811603774527,-0.04677703873896899,-1.0 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark12(-78.71898218804112,-100.0,0.018808898946032826,-1.0 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark12(-78.75840935955537,-77.32512275220095,-98.72822491036592,-64.07335825979155 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark12(-7.879256571206767,-65.85927236606398,0.12221218111115562,0 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark12(-78.91848075569432,-76.77391665429182,-67.79020373492338,1.9721522630525295E-31 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark12(-78.97787107733403,-3.959681887026889,-1.0,0 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark12(-79.18629684794497,-4.891218023091752,28.737780216009575,-1.0 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark12(-79.192905435757,-100.0,0.9503190959531417,0 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark12(-7.919939412477341,-78.5577513248814,0.02510492814314169,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark12(-79.21552534767157,-80.27944315367996,-0.055972646573041775,-0.9999999999999998 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark12(-79.28042687223649,-43.22407938128934,40.16357984655516,-0.9679228633909531 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark12(-79.32000743321319,-16.04854447687984,-0.6671111101045434,0.059074977441545606 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark12(-79.45146672622442,-83.38982016036994,41.89098068266571,-91.81719078361677 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark12(-79.57700927924714,-58.500557613244155,39.68663636289485,-0.6039889546652601 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark12(-7.966374245987122,-19.55880597279812,0.8596293974604238,-1.000079241548962 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark12(-79.66420590012663,-26.097061170728104,0.9623146935023686,-0.061266369744902724 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark12(-79.83376366700207,-11.926007035066386,-0.00712156224085797,25.45263987289225 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark12(-79.90560777640113,-36.64553688822586,0.0,0.23473435946189447 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark12(-79.98765929144419,-4.940510834527657,0.01871747118669885,42.743372656991355 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark12(-80.05371751085755,-100.0,1.0,-42.21612552406785 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark12(-80.07660210929714,-79.54662646382273,-0.0028527797463409055,-10.319683321759193 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark12(-80.09528438858922,-100.0,100.0,-0.11221082170559882 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark12(-80.11421292143824,-31.381925488037197,1.0,2219.6280439551338 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark12(-80.27197292019821,-100.0,-1.0,1.0 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark12(-80.3335555319798,-70.76567142431885,1.0,1.0 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark12(-80.40823296014091,-11.10412624344707,-3.0924778094782823,0 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark12(-80.50954606786385,-20.105960175396987,-76.53265044302957,0 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark12(-80.55502834287167,-61.96966596115867,0.0,-96.12165672230319 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark12(-80.56350282417299,-100.0,0.0,0.06264032709587107 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark12(-80.83220894782781,-79.7945038240599,0.15251927998708403,1.0 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark12(-80.98159197256267,-93.12085512919802,0.127199355288272,-1.8726705418768793E-96 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark12(-81.13862996188064,-82.49375323999297,-1.0,0 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark12(-81.18373141216848,-77.74208906452796,1.0,0 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark12(-81.31199576052312,-2.739360523835557,35.30116391692006,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark12(-81.33189265651008,-15.05599679635459,-0.03540223177828905,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark12(-81.53056561436716,-43.737348672812985,-19.501108828550855,86.06489733265221 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark12(-81.57592698545666,-5.1457268727037615,-0.9043763618819156,0.44585014529087275 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark12(-81.64072222530764,-29.050217050527436,-0.020523103555867037,-22.76663056907166 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark12(-81.67939494124043,-63.51901156111789,0.0,-1.0 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark12(-81.68225324367,-99.59170554529064,-2.7755575615628914E-17,0 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark12(-81.80409859748532,-16.988578499258136,-0.03997952158629281,1.0 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark12(-81.80444113093307,-24.798585811182335,-0.03592760657984656,1.0 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark12(-81.82790608962742,-1.8639620821427911,-0.9999999999999982,0 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark12(-81.88359868856894,-37.96715843759698,0.0,1.0 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark12(-81.96077731404966,-93.37683226574153,0.9887322279562483,2419.6454742330366 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark12(-82.12764798850382,-93.49777135838175,0.9665148447015703,-0.6769168023574821 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark12(-8.217085313000462,-100.0,0.0,-0.3630154566331904 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark12(-82.52173329240074,-5.210430319094105,1.0,0.051670843539860456 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark12(-82.5303272848484,-3.361146888348692,36.612133916542376,-1.0 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark12(-8.254956782638459,-7.0061072258131905,0.37819923832752955,-1.0 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark12(-82.6466524227479,-67.87395050330522,91.7990716478338,-0.9999999999999991 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark12(-82.72065245516873,-45.43616841471536,-0.12397919063228136,-14.193181305971777 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark12(-82.78101186636178,-28.62942341205327,-0.832455745519594,-1.0 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark12(-8.317892356448676,-37.21230300486248,7.343576752705659E-16,-0.3982451073732549 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark12(-83.4323408318588,-22.90335151699339,0.0,-1.0 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark12(-83.45931646617791,-57.02616740024784,-40.37980884961625,0 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark12(-83.50822691513224,-19.7115809672173,-0.6114127997780329,0.22587824957698777 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark12(-83.53568465490855,-100.0,-0.7683208103970055,-73.90534313779288 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark12(-83.63795778350381,-33.0769279198138,-59.995175157791074,0.0 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark12(-83.70900201227298,-13.877525827796386,-1.0,-81.5854126256568 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark12(-83.73925648234095,-22.74371511231819,0.05507776868978348,-1.0 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark12(-83.79013657051415,-1.4224895244331166,0.9145559559271356,1.734723475976807E-18 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark12(-83.88366420370204,-2.1837660010704987,-0.9760173517276354,-1.0 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark12(-83.90242033679114,-100.0,-1.1102230246251565E-16,1.0 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark12(-84.0714767079073,-43.53184362978174,-0.05995450181020423,17.348884401662833 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark12(-8.409458900171199,-66.07262585203121,0.9404629560786499,-50.39406667091318 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark12(-8.410005433754321,-89.11397954017856,0.8393225377780292,0.06256102782884125 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark12(-84.13873131322933,-7.828096112146476,-0.11180254558137862,1.0000209884836124 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark12(-84.24159369232534,-53.26147176496181,0.0,83.28835352058184 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark12(-8.43143428806394,-47.071277187035484,-1.0,1.0 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark12(-84.65705529211652,-100.0,1.0,-0.9999999999999964 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark12(-84.97296891138424,-69.16564046672802,-0.051317069344221505,0.6859419837028647 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark12(-85.04811358842453,-1.6282909546778301,0.15848754500892626,0 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark12(-85.34942469922902,-74.77356316762192,-57.34216654657701,1.0 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark12(-85.42692818702103,-91.44462958262105,0.29308482871821284,1.0 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark12(-8.545456191033285,-36.64376671799129,-1.0,-0.052173800778353596 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark12(-85.68134350032099,-71.18291184061184,-49.635286790442755,0.9999999999999964 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark12(-85.78800791689804,-31.942835892562925,1.0,-0.12203829520895404 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark12(-85.87097512769645,-93.34950978709168,-1.0,0 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark12(-85.87229214753596,-100.0,-0.04898029168208384,-0.04658290691630358 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark12(-86.1452846784804,-30.75853407139384,-12.70221134346928,0.882142658766746 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark12(-86.22778708871725,-48.013161086597876,-0.3465907336489898,1.0 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark12(-86.24459867571008,-90.63413750024311,0.020935453159433254,0.5295492550076335 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark12(-86.38000135145496,-13.783073697177747,-0.9991875273472943,-0.988814198995811 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark12(-86.40708334702228,-57.889989734123425,0.9850976377071401,-1.0 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark12(-86.4677136700499,-25.732227445417678,-64.91707446369895,0.9999999999999964 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark12(-86.63453470386673,-79.96463932866281,0.0,-23.9684031144837 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark12(-8.663871384618963,-47.76793779978551,5.551115123125783E-17,1.0 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark12(-86.71233284199394,-3.1613452627757397,-43.09581530181863,83.92400905586373 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark12(-86.75111777839935,-46.71866212886379,1.0,0 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark12(-86.78204961198705,-81.44559189875791,1.0,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark12(-86.98673151155639,-22.08758983638768,-8.221457463733103,40.618197093083126 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark12(-87.17319365126471,-61.92256924025362,0.9999999999999999,1.0456550012514956 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark12(-87.29404859797305,-40.12852864821457,-0.20404314822504777,2186.444221291748 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark12(-87.56389500690274,-21.394742790154062,-0.8666132455775258,-1.0 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark12(-87.57722402524517,-100.0,-0.2639421408957947,0.3839657920577193 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark12(-87.83053571767512,-32.24736532022501,-100.0,-0.017230548740244434 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark12(-87.89567237479667,-13.898642447842477,0.951940584087664,1.0 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark12(-87.90822860179586,-9.108319293544694,-0.2973707561048069,65.52467127306889 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark12(-88.00083527652394,-100.0,0.939850104228138,-94.28676657920698 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark12(-88.06588970399525,-30.033279237549188,-42.7576864128055,-0.014135310439869014 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark12(-88.16466103501482,-67.60803458817352,-0.010077385677029212,-72.10509862915144 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark12(-88.23340228893886,-21.075381800512602,-27.332743621578885,-66.43295665126303 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark12(-88.354984027304,-97.63932275322746,0.0279800206385368,-0.010773716432027403 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark12(-88.46673664118055,-8.349254097428435,-0.03915264438204963,-8.58298382438733 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark12(-88.5123499938042,-22.223665234996844,-92.20589943909398,-0.34770323311205686 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark12(-88.74583979772845,-101.32421331037655,-0.015052709187923874,2188.294457362792 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark12(-88.82901832885408,-35.46130115345137,1.0,66.61113601557574 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark12(-88.83474179428,-33.224355869223174,100.0,-5.776721576299174E-9 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark12(-88.98401565150769,-68.38347435757872,-0.8764841733531753,9.703866074888424 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark12(-89.01603438458712,-75.85721463657606,-31.184622932407137,0 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark12(-89.04117632723512,-34.65888993738935,78.84028710307706,-3.220189685041717 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark12(-89.17798960840801,-3.4536655306007162,-4.1096439393864586,-0.9999999999999964 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark12(-8.953534981169994,-90.9694478781496,0.0,0.10766179099341429 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark12(-89.7614936803573,-66.92711078463198,-1.0,-45.55951598917441 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark12(-89.80843025293196,-55.732560628079405,0.9325917945605575,28.94157943174021 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark12(-89.89968765073398,-57.643423833656925,-0.9999999999999996,1.0 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark12(-89.91697476269994,-2.051831036875409,8.469866195295849E-5,0.27231177484784885 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark12(-8.994528198241873,-48.72320398894472,1.0,0.8989472492394128 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark12(-90.29028167172979,-100.0,-0.008350356848375482,-0.7374559956920217 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark12(-90.30055218765212,-0.7193587935226373,0,0 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark12(-90.3235475380161,-43.77099570212484,0.8205728334067328,-1.0 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark12(-90.47251615614488,-18.238995761704327,-2.7755575615628914E-17,-1.0 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark12(-90.62318871982207,-100.0,-0.25100834457605004,-0.006822755001779146 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark12(-90.74777398301532,-10.980217933211755,0.010923064398287989,-1.0000000000979954 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark12(-90.78061354193451,-70.92381335394082,-1.0,0.06725103325534362 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark12(-90.89346313915709,-25.15267811762748,1.0,-21.496371570100735 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark12(-91.0698859410231,-79.95957035019299,-0.051837243120419485,-14.763969104945685 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark12(-91.12242583458945,-21.434785593135402,-0.7756122380999788,-93.66695483538292 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark12(-91.2279015781747,-100.0,0.05211868943395491,2.710505431213761E-20 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark12(-91.4929228738091,-71.28105627480006,1.0,-0.028922278571731574 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark12(-91.50609051916089,-50.578567578357294,0.01699552892108802,-27.53445675482058 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark12(-91.56131328658837,-47.373123865738755,-1.0,-7.806042478577596 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark12(-91.65077214691945,-7.39621672909421,65.56383544150495,-0.09233826501390202 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark12(-91.91570258336466,-59.376524538372024,-0.7937362317666086,-11.952981968565451 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark12(-92.01884443071273,-20.78892157460851,0.7187074025922726,0.0 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark12(-92.19412334324775,-12.246206594343505,0.9999999999999991,-1.0 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark12(-92.32493493100908,-7.15433106788457,0.8696560717523216,13.593779676341228 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark12(-92.4242371513794,-99.12754771176957,10.866428416481071,-24.67270394417831 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark12(-92.65083767756049,-59.326679936817705,-44.73608091003023,0 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark12(-9.303148933103245,-8.991281663371794,0,0 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark12(-9.320190393918818,-84.24799387920511,0.8866255180275716,-0.568906455058891 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark12(-9.321171745169533,-22.408619946373413,0.027337677869511436,-0.04850963826330207 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark12(-93.27008513686057,-99.29127960241019,-0.002471298933227492,-1.0000608858326543 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark12(-93.29448393914925,-100.0,-0.3130565296968628,0.0 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark12(-9.33124624098636,-81.94888115743592,-41.90173386035827,-8.373816381724694 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark12(-93.72454913116009,-43.579125870548154,-0.7113589058112924,-0.5596696345970069 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark12(-93.7881051419749,-100.0,-1.0,0.06256055404587703 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark12(-93.83254941324427,-100.0,0.005561986401180802,0.0 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark12(-93.86426723114727,-21.07044935757689,0.0,-53.4908605337445 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark12(-93.93574468075907,-100.0,0.0,5.534694772998774 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark12(-94.00124573222173,-77.87914842451444,-48.856498268654235,2181.1617794866834 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark12(-94.05961057867071,-65.32762017725987,1.0,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark12(-94.19015659378249,-38.85462106294243,-0.48967727670541894,0 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark12(-94.32585631103991,-28.28500690514454,-1.0,-0.03295814894181598 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark12(-94.36406818918603,-100.0,3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark12(-94.41690727460706,-59.59504330007477,1.0,-1.0 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark12(-94.54270283509484,-2.7424428771956286,-99.76893092693211,81.80413403428125 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark12(-9.462516522347258,-51.54263911559824,-0.32494091710901374,1.0 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark12(-94.65472365828626,-100.0,6.964632367643993E-5,0.3620973931432135 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark12(-94.84704223319127,-44.4984957364802,0.9999999999999996,0.0 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark12(-95.06614154231106,-50.69822676602813,0.6278239833779771,87.92990931996766 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark12(-95.09418421146233,-45.65870092479035,0.9753116996466737,-67.95019183257968 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark12(-95.38261708777137,-12.174032132781747,0.6558046790936691,-48.58351661673381 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark12(-95.3939346597136,-64.52812746851527,-0.011140070682463902,25.439127775202806 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark12(-9.540864173215798,-48.01223654729473,1.0,-1.0 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark12(-95.44492050430866,-21.350347994173895,-0.05716609946395034,1.0 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark12(-95.44610319039833,-60.148377324568,1.0,-1.000001350524683 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark12(-95.60617464091727,-106.28930757741543,-0.014481514990633992,-0.2705963192321459 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark12(-9.561939917225247,-5.478411357873611,-0.3815596065316769,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark12(-95.68166506646287,-68.221654837743,-0.9005472088482052,0 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark12(-96.20370809238948,-75.41800024736996,1.0,-0.9999999999999999 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark12(-96.22479126870589,-40.14328746696065,1.0,22.22978655870174 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark12(-96.4287596962095,-43.279653618601934,23.38681122353134,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark12(-9.643802500428507,-13.60848550389197,-0.8268662648938858,2151.039665847351 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark12(-96.64072225681315,-44.995064961058276,75.67118957053252,-1.0 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark12(-9.66969379702904,-19.758777618619888,0.02104381160783489,-0.09653979504020438 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark12(-9.674887302509916,-67.42806112078449,3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark12(-96.76619211744412,-29.072982372166422,1.0,-19.88798845875435 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark12(-96.95125598372509,-31.40324382827673,1.0,1.0 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark12(-9.69558342530761,-55.375595755364245,-9.443889958283512,-0.9999999999999964 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark12(-96.9726795491689,-94.31277054112812,-44.24032963116022,-35.21074520033616 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark12(-97.07807708946271,-3.247353514698651,-13.6821607523921,-1.0 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark12(-97.15517653532511,-17.04078348831166,0.0,-71.91700352766122 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark12(-97.2890838249464,-16.800266773472302,-0.017001519343911257,1.0 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark12(-97.34081433631206,-76.72829204754385,1.0,14.666382520295903 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark12(-9.734360952384712,-87.39885719469564,-1.0,0.4060110887418017 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark12(-97.35457528329192,-46.25372061646254,1.0,0 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark12(-97.54117438180633,-47.97137276482282,0.9999999999999964,49.81303823290456 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark12(-97.75920064792236,-45.114592298884034,1.0,-0.5801993416867666 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark12(-97.78202432511449,-14.832690039780289,0.47329619211835894,0 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark12(-97.8075023329887,-57.584276335641285,-0.7940598095694713,45.54998901981806 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark12(-97.93202397024828,-100.0,-1.2458890699053202,1.0000000273997967 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark12(-98.03861419671108,-100.0,1.0,0 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark12(-98.03975261823273,-68.56135829970111,0.979524457485931,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark12(-98.23738990082157,-69.50079719361575,-0.9178364278656032,-0.8563435811130853 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark12(-98.27541406522045,-33.86522552281072,-1.0,-1.0 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark12(-98.28057766714556,-31.781390576953655,5.887984481786311,-1.0 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark12(-98.32330892667949,-80.4452575854627,1.0,0.0625527455985696 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark12(-98.36680155315696,-37.63008675764414,1.0,-17.879131678344805 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark12(-98.38872633051375,-18.742006779497558,69.6279648711407,-59.13603242303094 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark12(-98.4356465376352,-45.65210693139772,-46.19964994903609,-1.0 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark12(-98.45514529855667,-73.4761452541299,-51.306393261931404,-1.0 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark12(-98.47611791167942,-100.0,-0.02579035066115415,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark12(-98.519603814188,-13.317428950937767,-0.9800285013650242,-5.521365960848399 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark12(-98.5501155478979,-9.587083266672225,-0.007590387846855562,1.000000000000008 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark12(-98.62755110925154,-27.14922403767473,0.009493134087716832,1.0 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark12(-98.9492879086858,-7.6798258378704265,0.041544981525042074,-0.055020583899719436 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark12(-99.1285620826035,-84.13211252376925,-0.024952500875655093,-0.018215468313541077 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark12(-99.1691039532423,-49.64460307094323,1.0,0.6625686281081338 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark12(-99.17033071996448,-62.07267144934209,-68.03062029263162,1.0 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark12(-99.22346141396628,-47.295043223062486,-1.0,-0.010205270238371186 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark12(-99.36424425649253,-25.720545405188773,-17.808543567211203,-0.7775600568018755 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark12(-99.47562981027215,-14.37200541356188,-1.0,1.0 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark12(-99.52850770706006,-2.2167239894806277,-0.9652848695524717,0.9999999999999999 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark12(-99.52933846138303,-100.0,-0.6588266674772817,-0.06255563514696355 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark12(-99.53247370571997,-7.304502405892931,0.8395047979224195,-1.0398301896337523 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark12(-99.56686797267272,-15.455807981164327,-8.318348714936704,0.9910069700655177 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark12(-9.957741540490625,-6.281285849539188,1.0,-0.8995428507189072 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark12(-99.57996289659599,-69.68509527135046,-0.9888708454834754,-1.0 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark12(-99.8011144279877,-83.9143361844644,-0.13240861920440172,-1.0 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark12(-99.85312444932391,-49.88118501569343,0.9974782753938265,-0.03160362208795589 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark12(-99.88826033019761,-100.0,1.0,-85.20498467374858 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark12(-99.91951362482611,-1.0000000000000018,0.06255252745561549,0 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark12(-99.9391399331509,-50.83816833802756,-0.029753853091642052,1.0000000000817648 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark12(-99.99952894901848,-99.99948678591275,-0.9329438524981676,0.9997857395013526 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark12(-99.99955256006008,-34.00645924888612,1.0,1.0842021724855044E-19 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark12(-99.99961771889964,-66.62678964260132,-0.02217961634309974,2.1684043449710089E-19 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark12(-99.99988804691539,-100.0,0.02333904215390772,0.0 ) ;
  }
}
