import org.junit.Test;

public class Sample09Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark09(0.0015742352996039877,-95.47679272581021 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark09(-0.002589489241166712,169.65866189828287 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark09(0.005487201278237676,-104.023099563901 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark09(0.005622427525368422,-101.51078711054888 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark09(-0.006422852873484984,88.86959294644683 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark09(-0.00696318334405988,81.97315048157093 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark09(-0.006984112292413255,12.48775700345881 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark09(-0.007167640123729734,62.00290298124736 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark09(0.008482007575930395,-71.61927270790085 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark09(0.008917348209140682,1.507419548583789E-14 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark09(0.013171490585335732,-3.268496584496461E-13 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark09(-0.016473468552103937,34.5809435389078 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark09(0.016694051564554762,-34.1886859505795 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark09(0.01738591459409733,-2.050511057501339 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark09(0.02074031356634698,-75.7363827586315 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark09(0.02288713657057631,-68.63227830843246 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark09(0.030400792990720075,-14.932096622514578 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark09(-0.040693280499548824,38.60087728273252 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark09(0.052888267552339906,-1.1723955140041653E-13 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark09(0.06147336965615292,60.911097729861716 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark09(0.0930374065349992,-6.135127054038546 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark09(0.10924025500989225,-14.379281032002837 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark09(0.1555168122997208,-1.78424992618325 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark09(0.15722063998555313,-9.99103124716472 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark09(-0.1663806376420931,9.440980327133303 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark09(0.1722259851486373,-3.5553485093740025E-16 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark09(-0.17414521611610567,9.020037195552973 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark09(0.18764092661766485,-8.371288476929847 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark09(0.19635513127678836,3.5282047002019308 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark09(-0.2167936683807068,7.245582117446574 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark09(-0.2207633763929664,7.115293996924919 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark09(-0.22692856137380518,6.92198600866033 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark09(0.26109370896531514,-6.01621667951953 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark09(-0.2761339569469925,5.688530103874278 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark09(-0.30235640015577314,5.195181335621229 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark09(0.35118780127988103,-4.472810049409787 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark09(0.3631874060688167,3.7267307997405637E-16 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark09(-0.3890007630702571,1.4673180453298944 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark09(0.5318583939693824,-2.9534108037135214 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark09(-0.558681005088173,0.06210841612452711 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark09(0.7256648271086235,-2.164630650563055 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark09(0.8341127610284638,-0.6843154648813485 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark09(-0.9158836971379252,34.41251103764736 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark09(100.0,-0.006927286426059674 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark09(100.0,-2.6511131526991784E-6 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark09(-100.0,60.6993464077106 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark09(-100.0,9.994434130841615 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark09(-10.034871551072271,0.1565337751248137 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark09(-10.050647237927492,0.005391347492880206 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark09(-102.30299216579073,0.005579460477477184 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark09(-10.486083135354235,0.1497981950475733 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark09(1.0856096054987319,-1.4210854715202004E-14 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark09(-11.042772691133056,0.1422465508192692 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark09(1.1102230246251565E-15,-7.636176677781108 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark09(-1.1102230246251565E-16,22.610068591525106 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark09(-1.1102230246251565E-16,53.483495939427 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark09(-1.112584252491362,0.5130364848202124 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark09(-1.1368683772161603E-13,20.088865012574516 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark09(11.429096572414377,-14.402069595515123 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark09(11.691942395787711,-0.45230331220410286 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark09(-12.262949491700143,3.758073466005904E-4 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark09(-1.2333470541030351,1.2736044745623332 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark09(-12.401226467067602,27.374533824812346 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark09(12.567112172435131,7.293958663031887 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark09(-12.598947710697828,-38.35701635492168 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark09(-1317.8118727257747,1408.9608059640623 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark09(13.22014830052754,-0.11881835899921134 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark09(1.3296160023139192,-0.02178911934036698 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark09(-13.334556427739159,-92.23781413689626 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark09(13.663940989179707,-0.11495924404523872 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark09(1371.829158427962,-1309.0861501351308 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark09(-13.86455965433618,0.0014113873945259103 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark09(139.45014206629952,-0.00409288178836861 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark09(1.4210854715202004E-14,-0.8952139709231091 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark09(1.4210854715202004E-14,-37.584284866047824 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark09(144.37009369771252,-1.0111352667184772E-6 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark09(-14.590551663472624,-45.184311203481144 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark09(14.647255557305776,-6.541742619264683 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark09(-15.330672835412212,-8.489640107099433E-18 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark09(1.534460850935389,-1.02367963694698 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark09(-1.551976356580937,3.552713678800501E-14 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark09(-15.548392107719593,0.10102628721429108 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark09(15.847951794438117,-9.931719395878446 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark09(-16.57304204038313,42.482134411094506 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark09(1.7763568394002505E-15,-29.056639508886022 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark09(17.789985820725928,-0.03208511606253239 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark09(18.110629741907758,-5.284789960187993 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark09(1.8857419731995313,13.327903226119147 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark09(-19.346597287466253,8.881784197001252E-16 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark09(-19.769601789798656,0.07945513235402868 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark09(2.001706209411803,-0.28515486033084375 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark09(-20.180014271115127,1.6101279565977218 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark09(-2.0322730662660786E-14,0.0030129976612774108 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark09(-2.1316282072803006E-14,3.4314036575267437 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark09(21.450292380454865,-15.817593558624633 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark09(22.395554833187873,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark09(22.818133900374306,-79.27397705225563 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark09(2.3331590462580472E-302,-0.639654375146506 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark09(23.982386722090133,-19.411183484473156 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark09(2.4492960964052477E-17,-2.4999974501750275 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark09(24.865660441370636,-0.06317130930419435 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark09(2.5165474989453175E-16,-0.3471039409898964 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark09(-26.96110184059195,3.552713678800501E-15 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark09(27.53014334321948,-83.18633812076656 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark09(-2.7755575615628914E-17,43.091246100758184 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark09(27.80749950646468,11.887987917724871 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark09(-29.109103347741595,0.053962374176556804 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark09(-29.275918228046322,1.9721522630525295E-31 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark09(-30.183473239130066,84.11471717396154 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark09(3.063499467326409,34.63691822416783 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark09(-30.68614684488946,1.0388476174942554 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark09(-30.991016536474632,17.644698278859906 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark09(3.159319479648289,-0.49719451828585903 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark09(-32.41095919999246,25.441727088376112 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark09(32.61475623789005,-6.6376454349671405 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark09(-33.03985262867066,4.440892098500626E-16 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark09(-33.38597714115087,0.017095608863266186 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark09(-3.3978566203522794E-16,0.1802087221414872 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark09(34.33397255050076,-4.930380657631324E-32 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark09(3.478883072681697,-61.474307529420315 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark09(-3.582873102751023,61.71786015866283 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark09(35.93881545190425,17.057773223647715 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark09(35.94596240734268,-47.05517278653628 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark09(3.68480088279199,4.086929610382086E-17 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark09(37.20438904361859,0.0 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark09(37.48998218764311,-87.31993882527591 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark09(-3.831768954223006,57.80157538830309 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark09(38.42592897874022,-60.37480685893095 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark09(38.50873610523877,-92.85429866298543 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark09(38.79885632326153,30.386632344911334 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark09(-3.9812968031573455,-1.4011690942146815 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark09(4.022413270395484,-0.1419038678503149 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark09(40.30935469399034,33.99771745256637 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark09(-408.8562112058319,433.40307639448304 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark09(-42.85272679689349,8.881784197001252E-16 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark09(42.92834618799509,-80.06834631866269 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark09(-4.311581188598538,44.694757712467265 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark09(-44.29359299406583,2.220446049250313E-16 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark09(-4.440892098500626E-16,0.4612768640506424 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark09(-4.440892098500626E-16,16.342428986687338 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark09(45.6484791838304,-24.775965728858296 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark09(-4.614560664727895,3.8215294798312844E-15 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark09(-4.668723575428714,4.618527782440651E-12 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark09(473.78224763157755,-467.57054905265215 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark09(4.754144408433717,-0.3304056822523835 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark09(47.739644757201376,-0.032903393705248085 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark09(47.77256335227968,-32.782078831861114 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark09(48.6290575886071,-6.982321558127808 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark09(-4.930380657631324E-32,7.0735813641079375 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark09(49.53373676151668,-58.07425694336155 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark09(49.702664255918535,-55.88711812512503 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark09(-49.91220300161887,92.43066839922847 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark09(50.59319133496592,78.00663037013715 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark09(50.98202917804713,-86.64743420674567 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark09(5.1192157843965385,-1.4433273793623438E-15 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark09(-5.148857707185071,-4.946765188097989 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark09(-51.816234067543654,61.27530704533936 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark09(-5.186961971048731E-13,0.4521836324976647 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark09(-52.09076123113119,4.440892098500626E-16 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark09(-52.41674541759998,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark09(-5.393640990666038,0.02682493013003002 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark09(5.5292421341418105,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark09(55.309562756925146,-93.6544331668803 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark09(-5.551115123125783E-17,77.23424407362947 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark09(55.63149717993497,-0.02823573706302196 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark09(-56.045052112447216,95.51561845312051 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark09(-56.47722578405536,40.26237938933576 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark09(5.693855189857473,-0.2758757071294955 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark09(-5.8268286962501615E-157,1.1380524797363597E-159 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark09(5.9152609308338736E-272,-7.011900706907453E-53 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark09(5.977189608766286,-0.02834049408369088 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark09(-6.090706968007052E-10,-1.9676821819067652E-7 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark09(-61.092234335321265,2.580531393844953 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark09(-61.16489167912072,83.41298977194073 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark09(-61.98778496855846,-99.60626344108192 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark09(6.204685663068601,-5.091163119211245 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark09(-62.698806277580466,24.853081716267454 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark09(63.12838444842774,-0.009041817594218278 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark09(-63.22174827002236,93.14009286895148 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark09(64.30906463879626,-0.024425737423138694 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark09(-6.7372347808321384,0.23315148987592238 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark09(68.93131562731367,-26.071165808530196 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark09(-72.0339850017886,8.552643388484398 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark09(74.18303971289058,-25.69324964318382 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark09(-74.23481311982034,0.007689063257172268 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark09(-74.82713939643146,38.901929853132884 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark09(-75.03629001780878,24.13669658194282 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark09(75.56014831495892,-92.38994400981207 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark09(76.68369015289935,-79.25119048058986 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark09(-78.15310200719824,84.04219346887939 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark09(-78.60190614501329,95.05017613820863 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark09(78.61525815833326,-30.30128524708485 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark09(79.30733195369024,43.886203612637615 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark09(-81.66318774629353,11.176860894897871 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark09(8.555672512839791,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark09(85.94767972574172,85.50525739736946 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark09(87.91317648163763,-2.4868995751603507E-14 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark09(-88.63577846893429,47.15513659595163 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark09(88.78140856022925,-100.0 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark09(-8.881784197001252E-16,6.358103482441834 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark09(91.22325694026162,1.7400285322848958 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark09(9.175890794206026,-16.98640104445272 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark09(92.01337712610706,-48.76765175316884 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark09(-94.12990419397343,46.607278808500325 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark09(-95.11827592207726,24.047237533699857 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark09(95.21089690274846,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark09(98.02597986742386,-9.802656769898855E-17 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark09(98.38593154712915,-98.2904042479251 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark09(9.841151152060855,-72.194678266765 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark09(-99.35887867060798,47.04966630303889 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark09(-99.7188122839666,26.028452091837295 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark09(9.994305941853487,-0.15716912569354324 ) ;
  }
}
