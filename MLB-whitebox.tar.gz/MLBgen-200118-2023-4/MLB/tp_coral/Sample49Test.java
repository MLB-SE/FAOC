import org.junit.Test;

public class Sample49Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark49(0.001628039248242993,1.635250712302253E-6 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark49(-0.01019405868132866,0.014168378062795445 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark49(10.57208896369257,39.42791103630743 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark49(-1.2116654960809893E-38,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark49(-1.3694038695196645E-5,1.7139379360732177E-6 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark49(-1.5038227643595673E-37,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark49(1.6473192594632438E-5,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark49(1.8099502732970572,5.802666109607489 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark49(23.962631401010853,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark49(2.5243383489411397,5.246454438724236 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark49(26.62290034344612,36.38088491704343 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark49(2.956752803931297,5.290505429816474 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark49(33.0981147424107,65.68340118495487 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark49(35.91912764270009,57.170993540097754 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark49(4.2550710358379436E-4,1.0061736545986666E-5 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark49(44.812112837794416,52.68602006053965 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark49(4.705675543527048E-9,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark49(-4.948421078111622E-9,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark49(49.53960711538622,89.01629359418877 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark49(60.698294611464746,91.65748355306934 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark49(6.211665296712576E-15,2.7409200293148913E-8 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark49(64.16807904913992,0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark49(-7.922251760049438E-4,7.82952458808937E-5 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark49(8.328540829407868E-37,0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark49(8.423564410525074,39.692264926647 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark49(8.967441087198651,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark49(-9.998444303267036,35.42905936667299 ) ;
  }
}
