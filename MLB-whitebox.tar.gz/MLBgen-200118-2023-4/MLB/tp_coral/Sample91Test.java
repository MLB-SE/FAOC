import org.junit.Test;

public class Sample91Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark91(-0.003313240772669926,-56.545354523843606 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark91(-0.006142860281566943,-42.784820716653286 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark91(-0.006984426816241479,0.006984426816241479 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark91(-0.02027876764194647,-89.60692273145538 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark91(-0.030040292892536513,-25.69821055226231 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark91(-0.030445490119678932,-9.48727796076941 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark91(-0.03846538966084878,157.11810214502844 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark91(-0.03877211773200345,-47.1626619215789 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark91(-0.04289805524450266,1.1716381358559617E-243 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark91(-0.04515642265476254,-9.487277960769381 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark91(-0.051410021339807876,0.051410021339807876 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark91(-0.07346371339683883,44.055760863653944 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark91(-0.07672553453471664,-29.010101846745243 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark91(-0.08344684738213012,-12.159038940083045 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark91(-0.08855693970834667,-20.856322044143013 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark91(-0.08908751409911544,-69.02595086487634 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark91(-0.10623695847037547,78.43357938127446 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark91(-0.11401203985535567,-56.43465572476092 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark91(-0.11428851734200193,-9.539066478111382 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark91(-0.1637969972319962,44.1460941474891 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark91(-0.18742159971881067,88.95785418794777 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark91(-0.1926951173495356,59.497565300856536 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark91(-0.20959306659663238,97.17977919468696 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark91(-0.2128655616883801,-56.08253975632953 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark91(-0.21796287248589175,-85.04096451941031 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark91(-0.24651754253509772,0.8262568214877023 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark91(-0.2646346645806261,2.876900605661433 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark91(-0.27394630360551275,-96.94949971846785 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark91(-0.27409078407702747,8.673617379884035E-19 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark91(-0.2853293040597315,1.5707963267948966 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark91(-0.2861633016635099,72.25938813467147 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark91(-0.2933595210796218,-1.5707963267948966 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark91(-0.2944432274046846,90.81174372669932 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark91(-0.30093905084738504,-56.24772871376889 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark91(-0.3270187716957093,82.00842776503033 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark91(-0.3285932428383376,-0.0881720503593536 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark91(0.3362790585565705,0 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark91(-0.33813273233124835,-56.21053503228503 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark91(-0.34083064366275695,-53.74790575468924 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark91(-0.3412009581040129,-49.92428149933268 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark91(-0.36347100048291736,-59.10904265052312 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark91(-0.39889873187082425,-3.16E-322 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark91(-0.39986640549501046,-9.824644366386588 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark91(-0.41434883968308267,88.3789431401973 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark91(-0.44166541765571454,-53.8487405286822 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark91(-0.4523555860357605,-16.160318853984727 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark91(-0.4537719611363694,0.4537719611363694 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark91(-0.4580930539578393,-3.5996857075476325 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark91(-0.47731479246190806,75.87553847861695 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark91(-0.479353018677237,-97.86872527996083 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark91(-0.4796211709698923,-87.91920975948938 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark91(-0.48157887648857645,84.34142277043584 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark91(-0.4962347047272112,88.46082900524142 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark91(-0.4980579753510472,-43.48423917490606 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark91(-0.5311980980603217,-100.0 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark91(-0.5450034147653806,-63.65665833273682 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark91(-0.5491957400917608,77.99062059965307 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark91(-0.5544244129797871,-62.27742865881608 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark91(-0.5602549868549498,0.5602546107252049 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark91(-0.5607472504689958,-49.7044517291339 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark91(-0.5693754262281709,0.0 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark91(-0.6262656946822298,160.22966832557773 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark91(-0.6341946782497695,0.6341808572963689 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark91(-0.6395219497705062,25.772061950812315 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark91(-0.6445566843102227,-1.43E-322 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark91(-0.6459102493076584,76.0441339354627 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark91(-0.6862219562860626,0.0 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark91(-0.6905991125274287,33.763522349725974 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark91(-0.6961142057775471,0 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark91(-0.7057077635896143,-10.130507602816682 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark91(-0.7330599042498808,-48.230103724382815 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark91(-0.7442571659196874,65.48984102602506 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark91(-0.7486580914274676,-55.80000967318881 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark91(-0.7686583621991632,4.3368086899420177E-19 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark91(-0.7763694400440623,7.059678862860483 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark91(-0.7769154270284719,62.116686462164814 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark91(-0.7799333811642766,84.04306826576014 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark91(-0.7853669635566799,-11.781003650802493 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark91(-0.7898134202576639,13.38417620699828 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark91(-0.7977692483122665,48.354037884267115 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark91(-0.8006955939853592,25.933366774543124 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark91(-0.8090182389475724,77.73079810079726 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark91(-0.8260864404349038,13.462507127672609 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark91(-0.8281221668815704,-17.868090170924518 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark91(-0.8338531655200421,-1.5707963267948968 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark91(-0.8388838554179432,-29.113234506017026 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark91(-0.8517847268901876,2.2898079266996056 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark91(-0.8577988937586968,32.27372542965663 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark91(-0.8711183244657562,-36.82799351861176 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark91(-0.8754968445124965,2.2660958090772967 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark91(-0.8764404888670498,-74.52178319728799 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark91(-0.9016213443055463,-29.17487923729057 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark91(-0.9112252470482218,-6.8862300039878495 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark91(-0.9324483874604139,-5.499960733049423E-19 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark91(-0.9458898787738867,-1.570796326794899 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark91(-0.9479123597532632,1.5707963267231795 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark91(-0.9520562275672722,44.93406946678448 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark91(-0.9527152574799891,0.0 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark91(-0.9638677384643078,26.096608967182654 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark91(-0.966864373662645,0.9668643736626451 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark91(-0.9670361882871547,-54.37411129931364 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark91(-0.9722210008801773,-41.81292549754749 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark91(-0.9747358789118135,-138.24678707342076 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark91(-0.9840701885345544,-56.41299875868118 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark91(-0.9910322944468438,67.51053469972187 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark91(-0.9996446742701863,5.739899362538779 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,0.0 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark91(-100.00000000000001,100.00000000000001 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,100.0 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,-1.1888408896576113 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,1.570796326794868 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,1.5707963267948966 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,-2608.0404327291153 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,-32.79879614699664 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,4.141592653589794 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,-47.12389062897379 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,-49.80150128457938 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,-4.9E-323 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,-50.79644737231008 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,5.9E-323 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,62.50022463080097 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,66.98010780820073 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,-7.8539816339744855 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,9.242595204427927E-274 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,-9.860761315262648E-32 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark91(-1.0046048218958991E-15,-91.10667562435357 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark91(-100.52826180345711,2.220446049250313E-16 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark91(-100.54658991487842,-2.1169202924320872E-4 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark91(-10.108596607557411,7.105427357601002E-15 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark91(-1.0135267990090286,8.411251161760351 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark91(-1016.4504679426256,-0.9979020536771187 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark91(-1.02032553234158,-42.96150743145194 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark91(-1.022982561287271,4.9E-324 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark91(-10.359013128974482,4.8148248609680896E-35 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark91(-10.439873138812032,-1.5707963267948966 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark91(-10.446913399574598,23.316686302411725 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark91(-10.478555171468495,-96.28725163247611 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark91(-10.488006592831766,-76.24124008026847 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark91(-1.057277066699989,-54.87363442937252 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark91(-10.608623287616183,-16.967142357569912 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark91(-1.065035362937285,-98.45441969026683 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark91(-106.81290914234917,69.11509947965304 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark91(-106.81415119009823,-1.5707963267948966 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark91(-106.81416108700415,15.723588268710252 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark91(-1.0703064318026783E-19,18.849555921522665 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark91(-10.771269035517534,2.3432762717119234E-243 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark91(-10.839470134545465,63.64673065697818 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark91(-1.0842021724855044E-19,-87.96459620945457 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark91(-10.883422274058958,7.044960608145658 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark91(-1.0914643469938072,70.20650272596926 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark91(-1.0947644252537633E-47,-21.991392715753555 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark91(-10.995574287564276,-1.5707963267948237 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark91(-10.995574287564276,42.4115008234639 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark91(-11.014138649692425,-1.5707963267948966 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark91(-110.2040190724005,19.04360040362691 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark91(-11.037371956839065,-40.16280922625172 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark91(-11.05168391925504,36.184425147973386 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark91(-1.1102230246251565E-16,-94.24777904549352 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark91(-111.29145791367935,175.86682924084124 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark91(-111.54909175786204,-1.5707963267948797 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark91(-111.58208345749017,-20.475896503386167 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark91(-1.1159860131970364E-16,-9.424777960739226 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark91(-111.75093462454073,55.47213070914589 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark91(-11.180161312216768,32.0552806020784 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark91(-1.1183185621593736,-130.0634069847359 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark91(-111.86410308492707,-1.2332324443054903 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark91(-111.87791973806091,164.7686021099177 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark91(-111.93693195289235,-90.04987856306283 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark91(-11.198960527119247,-1.5707963267948966 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark91(-112.09720032312345,-19.849555921533387 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark91(-1.1210387714598537E-44,53.40707487297032 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark91(-1.1215923842234525,89.98459127890601 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark91(-112.55565385709167,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark91(-112.61216199023531,84.41259660798221 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark91(-112.62230426675359,142.9105454517514 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark91(-1.1287718113749354,177.94200944324328 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark91(-113.09733482156896,0.0 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark91(-1.1381419723790258,89.96785876920336 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark91(-11.458523947523986,14.189024293161552 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark91(-11.466730260702333,36.59947148942068 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark91(-116.29122373560804,1.6014639919713735E-15 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark91(-116.30151194891967,-47.126124225389724 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark91(-116.98965927022364,-56.22016935416929 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark91(-11.70863775013404,0.0 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark91(-11.740863658590243,52.78346796315283 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark91(-11.770246020066088,68.31891378468237 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark91(-117.8097245096174,-1.5707963267948966 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark91(-1.1781742006169165,27.049854016939882 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark91(-117.96560646512128,92.8328652375313 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark91(-118.09004102224361,-13.856850428527705 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark91(-118.22748960298294,-7.436216540608788 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark91(11.894654870228266,-0.012646623541783697 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark91(-119.38010765122507,-72.25667466968555 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark91(-11.990592325834498,68.43284277446062 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark91(-1.2034405544344668,-26.86545115674575 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark91(-120.58263089383937,-29.47644393973536 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark91(1.2059504278438612E-25,-9.424796395595575 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark91(-1.2103391409888933,-1.5707963267948966 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark91(-12.147138475618618,-1.5707963267948966 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark91(-1.224376576315474E-16,-34.55752229091 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark91(-12.26559459705068,-99.08349969840471 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark91(-1.2274899375762953,27.046843944731844 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark91(-122.87926672384965,-67.66098647237406 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark91(-1.232595164407831E-32,69.11503837897548 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark91(-12.377004836011878,-53.79600964892006 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark91(-1.25507565124785,-85.26597080386873 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark91(-1.2582468838516692,-79.7980632235965 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark91(12.597620614359174,25.103085617778778 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark91(12.616964398100638,-6.3337790571305135 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark91(-1.2658664535216426,-38.770883605719405 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark91(-126.72995510429698,1.0662489607052472 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark91(-12.684388396409355,5.551115123125783E-17 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark91(-1.2716269384782515,-55.27704082613803 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark91(-1.2776647315372094,-53.60248879920516 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark91(-12.776835028441695,-23.36381468681283 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark91(-1.2793084995093231E-15,91.10618663627473 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark91(-12.867059665139834,-85.10773883345708 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark91(-12.895026828219148,-85.44979982378196 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark91(-1.2897849955582281,-16.997748263507194 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark91(-12.915262187838753,-9.77366953424896 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark91(-129.53511077088046,-112.95629255291125 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark91(-130.00703397589058,24.193649286910684 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark91(-130.3763511918486,-1.5707963267948966 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark91(-1305.8192671916124,-0.2707275719332684 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark91(-131.8271409710232,3.2665926535897936 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark91(-1.3188221116534322,78.33968505788351 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark91(-13.20255385964299,-48.25664434592346 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark91(1.3234889800848443E-23,1.5707963267948966 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark91(-1324.862497713196,-1.5707963267948966 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark91(-132.84908483951017,100.0 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark91(-13.287383739782118,0.7210131254229455 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark91(-1.3320377776840877,-42.65025937257302 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark91(-1.3334105020112943,30.39646882078123 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark91(-1.334110178996823,77.20570616074801 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark91(1.3552527156068805E-20,-28.27433474351205 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark91(-13.576825485011781,-25.00058846238204 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark91(-13.607986500102584,-50.73129100883186 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark91(-136.463951344497,50.137098995041626 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark91(-1.3750998683179176,-39.89133200874531 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark91(-13.794755695367037,-45.84411014163159 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark91(-1.3801299124352557,-174.16772585987388 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark91(-1.3883600182106965,45.7355297856362 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark91(-13.913548813269273,-78.53981713466464 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark91(-13.928563844448936,65.1224321081846 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark91(-1.3956086151858793,68.25273340375466 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark91(-139.70580434148576,-17.02250762094782 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark91(-139.8008730524167,1.5707963267948966 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark91(-13.992706658544904,42.57335394717505 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark91(-13.995590324567985,0 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark91(-14.06596811807077,-86.61976427783078 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark91(-1.408470081470794,64.56533156764925 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark91(-14.13002383246726,-50.20885304505181 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark91(-1.4137031085780625,1.5707963267948966 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark91(-14.187665375688695,-75.8181257340973 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark91(-1.4267775662279216,-42.26748206289523 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark91(-1.4272275922579982,20.276783513796758 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark91(-142.8084112351646,-1.4367418236239173 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark91(-1.4345365214696144,-17.14343704114648 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark91(-1.434738501557874E-105,-2.0303534698525194E-115 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark91(-1.4349296274686127E-42,1.5707963267948966 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark91(-1.447880028622779,125.70265220903138 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark91(-1.469565507355566,-66.7814128559323 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark91(-1.4815859114807065E-16,69.11504133463643 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark91(14.825979814163434,-32.29820835401085 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark91(-1.4836478196521936,50.26871054778296 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark91(-149.20254362014722,-1.5707963267948948 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark91(-1.4925627878564143,1.4925627878564143 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark91(-14.939688201515906,0 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark91(-1.5078125644768077,-80.04762890422164 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark91(-1.5220043888839914,-62.016474464727374 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark91(-1.5235476794721714,64.35540075126804 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark91(-1.5354323840593926,139.8362370274813 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark91(-15.433686484491147,-64.02355381501957 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark91(-154.34636370323094,34.557522685672716 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark91(-155.0035439010564,16.77346714310549 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark91(-1.5510604495152787,4.4755106060441046 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark91(15.556413256311586,-57.9944533189966 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark91(-1.5563973914574927,-54.99227037315879 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark91(-1.5588322237121983,89.52342652422641 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark91(-156.0231695575557,-147.2740677921798 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark91(-1.5625498300835357,-18.855675091990946 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark91(-1.5672350404171842,-48.69824741701956 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark91(-1.567357329757528,1.5707963267948966 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark91(-1.5680670555452325,1.5680670555452407 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark91(-1.568467247213273,-20.492696503665602 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark91(-1.5685076428080165,49.94802419990763 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707939719279955,39.26990581501357 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707955766148123,45.55309272687454 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707957902553638,-92.67698274436272 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707962423041275,-117.81989738598965 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963243801344,1.5707963243813323 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963265029699,89.52782525333762 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963265059286,1.5707963267948966 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963265321618,158.65292861417873 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963265348572,1.5707963267948937 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963266169476,-168.06523830196414 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963266320797,-23.549250832999437 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267006582,1.5707963267948963 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267151273,1.5707963267948963 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267262908,32.97915407219431 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267442455,7.853981633928884 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267855387,-42.430653474708095 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267917715,-61.26105674499924 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267924365,-80.11061266653653 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267932934,1.5707963267948966 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267933085,89.53539062731146 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267933365,1.5707963267948966 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267935376,45.55309347704872 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326794187,1.5707963267948966 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267944618,-54.98051233889188 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267944733,1.4972274637028724 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326794544,1.5707963267948966 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948486,73.83968978427131 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948544,-48.745996027641596 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326794877,100.0 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948806,63.23585969866814 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948841,-18.064827115536147 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326794889,1.5707963267948966 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326794891,1.5707963267948966 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948912,83.25628841892622 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948923,1.5707963267948968 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948928,-10.995928770378157 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948928,-98.94994349402572 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326794893,1.5707963267948966 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948937,1.5707963267948966 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948941,-54.976445356323744 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,-100.0 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,100.0 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,12.876233647015095 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,-168.07520696432277 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,-17.27637742027213 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,-17.27875959474573 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,-180.64857209475522 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,-26.722414149354005 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,-34.55752606913394 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,54.25956938577713 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,55.00098794974367 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,56.72790124357403 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,-80.12353854823544 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,82.78590707570343 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,90.71028240190535 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326794895,1.5707963267948966 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326794895,1.5707963268135636 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948954,202.6327261327427 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948957,-149.22199481816006 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948957,1.5707963267948926 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948957,1.570796326794896 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948957,1.5707963267948966 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948957,17.847750260699435 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948957,-60.39028480983795 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948957,64.39163219873008 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948957,-73.82742735936016 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326794895,-92.6796946447894 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948961,-100.0 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326794896,-113.09733552929389 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948961,1.5707963267948966 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948961,26.703711301052557 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948961,38.80050450129037 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948961,46.55984770961023 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948961,-48.69287758051774 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948961,70.68582143410428 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948961,7.267105161165446 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948961,-73.82635851770578 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,0.0 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,100.0 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,-10.995574287563313 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,114.66808150014957 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,14.135929702165694 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,1.5707963267875997 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,1.570796326794253 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,1.5707963267948957 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,1.5707963267948966 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,1.5707963267948983 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,1.5707963267949197 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,1.5707978745726734 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,1.584578619253753 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,20.961417389534006 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,2.220446049250313E-16 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,2459.8844789856744 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,-2571.49006261073 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,2577.9132312148568 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,-36.125466263399716 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,51.8358826374894 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,-54.406973652642435 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,-54.96924411271453 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,58.10969966759768 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,-67.54424205218594 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,76.96902001294859 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,76.97020572328461 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,-80.11052122666284 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,83.25220532013095 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,83.26289989760178 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,-86.39202057236135 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,-86.39550856639872 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,0 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,100.53075757816936 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-1.0917401020747333 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-10.995574287561936 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.0E-323 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-117.80972451026116 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-124.09290980058408 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-1.2600001031341825 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,13.427368495891297 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,14.137166941152563 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-14.238180959773132 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,15.048568589363551 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,15.364766964123746 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5490292275930975 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5515393036175704 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark91(-15.707963267948966,-1.5552918502493938 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-15.649464311074816 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.570796326789899 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.570796326790071 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267910066 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267923284 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-1.5707963267947171 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267948508 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-15.707963267948788 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267948948 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267948954 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267948957 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267948961 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267948963 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-1.5707963267948968 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267948968 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267949 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267949019 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267949054 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267949197 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.57079632679504 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.570796326801857 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-15.723017508109475 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-17.264630305289007 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-17.278759594743864 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-1.73E-322 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,20.420352248332115 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,22.149433481680674 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-22.252121583136894 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,23.47736569044793 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-23.561944901926534 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-2494.942397585504 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,2570.9560933531484 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-2574.3563672996547 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-25.93508007071817 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,2619.504263792725 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-26.277641789894105 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-2.6382945360269858E-228 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,26.70358391120091 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,27.18576501514826 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,27.803445228634402 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-28.088587463013166 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-28.27433388230713 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-28.36218837550262 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-29.037025162333894 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,29.305608486037894 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-29.84513020910174 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-29.84513020910175 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-31.415926535897935 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,3.1415926535924776 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,31.93060343328616 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,32.986722861975814 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-36.12831551627596 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-36.128315516278136 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,3.751864874013094 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,3.945474531452229 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-4.141592653589784 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-42.14614802148502 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-42.41150082346005 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-42.536500823462234 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-42.626917638175655 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,42.74799794920244 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,4.3368086899420177E-19 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-43.5542778203675 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,43.630634108333254 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,44.99000390301142 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-45.76517668894908 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-4.712388980377721 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-47.123889803846055 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,47.91141087564475 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-48.69468613063913 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-48.6946861306415 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,48.783874644729906 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,4.9E-323 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,50.26548245743668 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-50.265482457436725 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-51.4142866464712 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,55.44346258158572 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-56.180841638404864 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,56.548667764615324 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-59.30071982996445 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-60.48866698540486 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,6.06956612808874 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-61.8010840000103 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-61.9894703784027 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,6.283185307179584 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-6.283200565968676 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,62.83350856529276 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,62.85315095874726 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-63.23742186965258 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,64.40264939858535 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,64.40264939858776 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,64.40264939858953 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-67.54101360641943 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,70.6858347057672 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,70.68583470576766 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-70.68583470577035 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,7.143671195514219E-102 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-7.208250323782727 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,72.25663103426417 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,72.38163103256525 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-73.80506044876748 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-75.78230916244917 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,76.95408219323402 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,76.96902001294868 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,77.38257324166968 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-78.53981633974482 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-80.11061266653424 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-80.89924542446852 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-81.68140899333463 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,82.07717080884814 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,82.15554874436575 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,83.25220532012558 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,83.28405546912413 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-83.51317929433716 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-85.38031329161598 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,86.83910049620306 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,88.65484504932753 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,89.53539062730702 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,89.53539062730985 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,89.5353906273106 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-89.7304155645661 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-89.95602487339127 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-90.04274256350604 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,90.39097369142445 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,91.10618719254211 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-9.113902524445497E-305 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-92.67698328089703 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-93.25960600509534 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,95.8185759344882 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,97.38940654731658 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-9.860761315262648E-32 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-98.95495336455289 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,9.949363951236498 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark91(-15.707963267948967,-1.1640334410465112E-15 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948968,0 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948968,14.137166941148184 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948968,1.5707963267948963 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948968,1.5707963267948966 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948968,1.5707963267949054 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948968,-281.1725425886393 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948968,-73.80501091909574 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948968,-80.11061266653836 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326794897,1.553225908228935 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948974,70.70505628425772 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948977,1.5707963267949054 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948983,-100.0 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948983,-105.23194036090152 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948983,1.5707963267948966 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948983,-168.07267905144067 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948983,26.687645634990673 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948983,70.6791841944158 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948983,89.52571427161159 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267949019,-98.95802512126484 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267950291,1.5707963267949008 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark91(-15.713069943544507,-0.005106747444128188 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark91(-15.723588267948967,1.5707963267948966 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark91(-15.723588267948967,-50.265469564238664 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark91(-15.752248179995243,1.6622808077166837 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark91(-15.879532817362673,-20.456764675202493 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark91(-15.9222396792488,-26.776474237090362 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark91(-15.930428630221009,2.2877230240183835 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark91(-1.5930919111324523E-58,-21.991149185813285 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark91(-15.94033072270575,-20.037917379322394 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark91(-15.97476315082185,-17.722900395175074 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark91(-16.01075249271918,-21.688359350358336 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark91(-160.24067190137532,62.734316178727866 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark91(-16.025370149869346,-9.107371078849 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark91(-16.030186714691517,-2612.3514653597217 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark91(-16.034757535101182,4.1045368012983762E-289 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark91(-16.087961093236743,-0.04324001455848381 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark91(-1.6155871338926322E-27,21.991148575128438 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark91(-16.161052992663016,-15.340577224662468 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark91(-1.6197930747631732E-48,91.10618695410342 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark91(-16.223885215831707,-19.034339692265245 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark91(-16.230075236840815,-0.10202431411735471 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark91(-1.6543612251060553E-24,-94.247779051278 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark91(-16.630732638927114,4.064362024567941 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark91(-16.631074698603904,-0.9230314919562947 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark91(-16.63721603116099,23.92046914357799 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark91(-16.646814628068046,-73.19087548838809 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark91(-16.65528115871784,-33.06042725753291 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark91(-16.75424680365387,12.860917463273065 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark91(16.77002969691692,-31.24357985161916 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark91(-168.2007133467659,19.01058202700385 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark91(-169.10933442465858,-91.41940883342612 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark91(-16.927874423794975,78.21809173808026 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark91(-169.4161252485267,0.0 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark91(-169.41832725712527,0.5002814201040131 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark91(-170.28636212963232,-2532.7746750136175 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark91(-17.08519970898074,-1.5707963267948963 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark91(-17.19628060724338,-22.589681064265193 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark91(-17.27875959474352,-1.5707963267948966 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark91(-17.278759594743864,54.977871437822685 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark91(-17.28440804597284,55.082171239647565 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark91(-1.7290985989219702E-18,-18.849555921540826 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark91(-17.314743646040192,-0.03571757269613471 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark91(-17.336446914454157,-6.709605702489085 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark91(-1.734723475976807E-18,72.25760759506525 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark91(-17.35107154601005,72.25663103981043 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark91(-174.25328130829192,-7.677815923467797 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark91(-175.92918860102566,28.27433071299692 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark91(-1.7605311439619172E-16,72.25663033719461 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark91(-17.705980548866638,-1.9980172809176717 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark91(-1.7763568394002505E-15,-1.5707963267948966 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark91(-17.78920821874061,11.226153558054762 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark91(17.876916570770888,9.11833903319112 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark91(-1.7921509857775822E-13,-113.0973355292323 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark91(-17.980100934268364,39.2476768581794 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark91(-180.700180882298,216.78335356278342 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark91(-180.82029112506615,0.2052687280951594 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark91(-181.0599926390162,54.58265910896427 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark91(-18.10730205721725,51.152929393437205 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark91(-18.122646628723317,-1.6033346880071782E-291 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark91(-18.17868062718439,-18.113159809446685 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark91(-181.88652512101902,91.96989207987829 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark91(-18.217852601508284,-0.6317033200304757 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark91(-182.20467802786146,-1.5707963267948966 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark91(-18.417698058618114,-0.43185786292064493 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark91(18.641767093963793,-51.56582077197305 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark91(-18.824612889205248,-91.0812439217705 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark91(-18.84955591188838,-56.54866776398585 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark91(-18.84955591232858,28.274333882307886 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark91(-18.84955592153871,31.447237802838263 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark91(-18.84955592153876,0 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark91(-18.849555921538762,2.8183550360737793E-15 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark91(-19.14370414734594,-60.396481359828186 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark91(-19.14549300787781,1.5707963267948966 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark91(-1.9259299443872359E-34,47.123889803846936 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark91(19.35312641666744,34.56923341439603 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark91(-19.511158391399945,-28.00839013969822 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark91(-19.759860670850387,-82.84934444394052 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark91(-19.883307767134056,-74.35230505409845 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark91(-20.055604565967712,29.449496034788467 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark91(-20.066807687888442,10.92925015576023 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark91(-20.0955373652113,17.69311443431218 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark91(-20.186838421239475,1.077171167375463 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark91(2.0194839173657902E-28,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark91(-2.0215873059760975E-174,1.8208839675781755E-158 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark91(-2.0239900838389496E-75,1.1487970337155825E-56 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark91(-20.27322585885743,71.33336458830135 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark91(-20.31147299258005,0 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark91(-20.32797577540621,70.65061129909493 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark91(-20.34402236154979,-2614.4481652103204 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark91(-20.418573595067016,1.5707963267944542 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark91(-2.0487047045251205E-17,1.5707963267948966 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark91(-2.0679515313825692E-25,-50.261949033822006 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark91(-20.818691082134606,-69.6372355404109 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark91(-2.0913938024773407E-18,2.091393801766E-18 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark91(-2.108127111958676E-6,-54.118277693413084 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark91(-2.111775712052551E-5,238.76103716908224 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark91(-2.1120267390779946E-5,25.13276986574639 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark91(-2.1305141830801383E-6,-31.41592440538375 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark91(21.41126220209273,-54.75178824266902 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark91(-216.78973689369192,-0.03198286231556291 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark91(21.75928958827548,18.614612675526008 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark91(-219.9082325318511,15.707963267945454 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark91(21.991148575127845,-0.006931453828321646 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark91(-21.991148644973123,15.707963267846486 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark91(-22.022398575128555,-1.5707963267948966 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark91(-22.032248954729482,53.30455597817695 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark91(-22.176349103724917,2521.2782412984006 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark91(-22.1792885742605,-6.026951113950062 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark91(-2.2204460492503136E-16,2.999393627791262E-241 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark91(-2.220446049250313E-16,-37.699109673424545 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark91(-2.220446049250313E-16,39.862379900449895 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark91(-22.25164504012995,1.5707963267948966 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark91(-22.35882790089351,-1.5707963267948963 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark91(-22.38253809647084,0 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark91(-22.451512855996604,3.601956934457845 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark91(-22.476243450839892,-2610.4517375165933 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark91(-22.505792159837128,-75.66244411902372 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark91(-22.517094252062634,-0.5259456769340813 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark91(-22.638228153101213,-0.6474460765672787 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark91(-22.718923356817452,0.8951290968445988 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark91(-22.756088389360713,-11.823367906170603 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark91(-22.775303885312965,-10.70935421129704 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark91(-2.27843174369217E-7,97.10002443984351 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark91(-22.84704061933145,26.638023340565645 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark91(-22.864390198590172,90.90691692621996 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark91(-22.891008000274795,0 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark91(22.951411499549607,-99.23736102560949 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark91(22.960926273026487,-31.82432582339014 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark91(-23.007252944358903,55.53256339538593 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark91(-23.069069600385816,0.0 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark91(-23.152985741457584,-57.344441237843945 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark91(-23.23047558896215,8.274328422032212 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark91(-23.56194470805728,-1.5707961329293523 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark91(-23.561944901920203,-1.5707963267948966 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark91(-23.561944901926562,-1.5707963267948966 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark91(-2.361887486224366E-5,-97.3911174622926 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark91(-23.711690075627672,147.62359162879773 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark91(-23.712537974107505,-1.4202032546108407 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark91(-2.4074124304840448E-35,-100.52866344696987 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark91(-24.309716787927243,-0.8230244407911025 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark91(-2.465190328815662E-32,-1.5707963267948966 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark91(-2.465190328815662E-32,-15.708024303106274 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark91(-2.465190328815662E-32,2.220935265658096E-16 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark91(-2.465190328815662E-32,56.54866776461627 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark91(-24.771907046033828,-68.58318456429629 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark91(-24.7932673605549,-0.339473868163446 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark91(-24.879111651325992,0.0 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark91(-25.065138099059652,-35.381428065610336 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark91(-25.132741228718263,-5.74384386995104E-5 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark91(-25.132741347927638,0.0 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark91(-25.136647478720644,-1.5707963267948966 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark91(-25.146100809962963,-1.570796326794843 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark91(-25.180811962537867,-42.85976821943004 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark91(-25.187638298534964,2593.2218244119763 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark91(-25.495786503812234,-2506.546795621001 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark91(25.517183335913643,33.127801022899575 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark91(-2.5653355008114852E-290,0.0 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark91(25.700114064589627,0 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark91(-25.710031945540806,2.1827656571563665 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark91(-25.816314107412058,61.4279546721458 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark91(-2.5849394142282115E-26,-59.69025909363277 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark91(-25.95691026443255,-67.15701121606679 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark91(-26.217987745192225,-136.173730620835 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark91(-26.363598076486184,-1.5707963267948983 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark91(2.6450650183290634,-33.66328579884512 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark91(-2.6469779601696886E-23,1.5707963267948966 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark91(2.6469779601696886E-23,-50.265480163341216 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark91(-2.6469779601696886E-23,-62.83209721381079 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark91(-26.486302712351133,121.81714673135878 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark91(-2649.1943163339847,0 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark91(-26.656668812107647,-9.42477796076938 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark91(2.6692703940863463,27.175936065303404 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark91(-2734.0987322978476,0 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark91(-2.7755575615628914E-17,9.424776872463926 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark91(27.902525319473767,-60.02631280795785 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark91(-2.8148933918813004E-13,109.95574286698556 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark91(-28.274333882325063,1.5707963267948966 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark91(-28.274334123368007,131.9625226411566 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark91(-28.274335784458515,28.274318924064406 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark91(-28.274341991266855,-1.2207031391561678E-4 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark91(-28.378037859187785,97.81173540893332 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark91(-28.567644763556075,61.60875435002506 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark91(-28.677194231667627,-147.67930349163348 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark91(-28.824638162460857,0 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark91(-28.8937116861576,73.72365902466287 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark91(-28.99755323893646,-2581.815262214693 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark91(-29.097988307280502,5.6372150772078164 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark91(-29.315738874135725,8.312773289781347 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark91(-29.41562018519475,-1.1411995256030374 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark91(-29.471863317774904,-1.1975294354667647 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark91(-29.733691516034582,-35.70263024856118 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark91(-29.813760674214734,-6.985480930105425 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark91(-29.827233169582982,-1.5528992872748515 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark91(-29.845130209103036,-1.570796326792411 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark91(-29.845130209103036,17.278759594743864 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark91(-29.845130209110796,-1.5707963267948966 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark91(-29.848353880008514,-1.5707963267948983 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark91(-29.859794835279743,-35.966324645882004 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark91(-30.01440657890255,23.006802946195734 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark91(-30.15331302502679,-83.4460700119864 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark91(-301.58708091889537,-0.0018745268818356406 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark91(-301.5926786848764,-0.047839838657509605 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark91(-30.574689739699522,0 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark91(-3.0814879110195774E-33,65.97344568785297 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark91(-30.907911463813974,-17.310966658256532 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark91(-31.136650758595636,-1.5707963267948968 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark91(-31.3301989049238,-0.08572763097413139 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark91(3.1415926535897953,-1.5707963267948966 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark91(-3.1415926535898033,1.5707963267948966 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark91(-3.1415926535917675,-0.9941203927039531 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark91(-3.1415926535927348,-1.15689630652976E-11 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark91(3.141592653648113,-0.0021712892560852896 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark91(3.14159266849234,-1.5707963267948966 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark91(3.141592713195027,0.0 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark91(3.1415928920083727,0.0 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark91(3.141592892008384,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark91(-3.1415928920113134,-2.3530011673822404E-7 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark91(-3.1415929022099203,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark91(3.1415929101178803,-1.5707963267948963 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark91(-3.1415940300772394,-5.5362136331342296E-6 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark91(-3.1415945609384863,-1.9025067955189857E-6 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark91(-3.141594560942243,-0.3018606753764258 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark91(-3.141625243865904,-4.077729307562473E-5 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark91(-3.1420809348397936,-1.5707963267948966 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark91(3.1420809348398153,-7.555624604344618E-12 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark91(-3.142080934853602,-1.5707963267948968 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark91(-3.1420809903045432,-1.5707963267948966 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark91(-3.1420811803764606,53.40707511102184 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark91(-3.1420819644934475,-0.9663501776975358 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark91(-3.1435457823950017,-1.182220986233403 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark91(-31.44717653589852,-2.0863024524101465E-17 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark91(3.144943955875151,-113.0939842269472 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark91(-3.149405153589794,-1.5707963267948966 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark91(-3.1494051535898016,-0.007812504817910232 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark91(-3.14940515429525,-1.5707963267948968 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark91(-31.594020436285685,-0.8087512163920452 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark91(-31.64755589417505,84.50645527008129 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark91(3.1728426535922107,-37.667861864927914 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark91(-3.1728504366794663,-0.99999984982555 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark91(-31.84985948538196,0.4339329494840266 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark91(3.187341911920764,78.49406708141386 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark91(-3.190169163303688,3.2945339283856248 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark91(3.2072268937911304,125.72934038379299 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark91(-3.2097114064578934E-27,72.25662945056891 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark91(-32.123760114846014,-82.74352801494474 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark91(-32.19011681065773,57.094866368526766 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark91(3.219567355068354,28.196369757379838 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark91(3.2311742677852644E-27,28.274332702418544 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark91(-3.2422050573144214,-0.20553374899587062 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark91(-32.56267559291646,-10.505172847844037 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark91(-32.57985970790021,-10.588711132771659 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark91(3.2665926555333638,-100.53003202774423 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark91(3.266592812674079,-40.87195449684325 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark91(-3.284759864428942,-0.1431672108391487 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark91(-3.298184567346326E-15,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark91(-3.3087224502121107E-24,6.283185307180042 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark91(-3.317756779100456,15.884127393459629 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark91(-3.334520807652467,2630.1173758280192 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark91(33.46854725452127,85.30582715241971 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark91(-3.373365242232926,72.48840362120838 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark91(-3.39800274244989,-12.478843836466027 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark91(-3.4351510973885393,-1.5707963267948966 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark91(-34.557519427906314,2.465190328815662E-32 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark91(-34.64606547152121,83.91020276462987 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark91(-34.651189616054424,2706.6205235650823 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark91(-34.686415257144105,-0.12889606765637973 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark91(-34.71020422781131,-6.533185307179587 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark91(-3.480665430523411,1.5707963267948968 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark91(-34.83591431383907,-28.20155217792839 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark91(-34.891046479114635,27.262771718735745 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark91(-34.89323906279496,-1.5707963267948948 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark91(-3.5062591842605713,51.77342179447516 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark91(-35.066635847937235,23.649609933356857 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark91(-35.138694467727866,-1.5707963267949054 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark91(-35.206138922348785,-87.22611218853741 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark91(-35.23885952024297,6.952358042814959 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark91(-35.43419956689155,-1.5707963267948966 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark91(-3.5463871766057555,-0.40479452301596225 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark91(-35.47544509610892,-2.817681462947307E-132 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark91(-3.5506426723351304E-16,78.53981551428869 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark91(-3.552713678800501E-15,43.98229715027714 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark91(-3.552713678800501E-15,60.02959843601255 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark91(-35.71272952773066,-78.32930172523099 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark91(-3.575466221745126,-97.83870709355206 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark91(-35.78561832044376,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark91(-35.7909084461645,-89.4855444125349 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark91(-3.5823532495198744,47.56465039977698 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark91(-35.896595629094584,-1.3390764396068582 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark91(-35.91031051182948,-38.35890651463467 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark91(35.97355673967374,65.09155327066077 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark91(-35.99892371808086,-1.441404528593135 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark91(-36.12831551570043,-1.5707963262124693 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark91(-36.13954574899284,-1.5707963267948948 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark91(-3.6505519456640627,-15.899282462804123 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark91(-36.52379315291836,92.80004173384171 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark91(-3.6529807580631406,-0.5113881044733474 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark91(-36.65650840109656,-1.0430146792895605 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark91(-3.7051747998605435,-21.349806524916787 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark91(-37.058149791707386,-50.302155891984455 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark91(-37.07741198875585,2722.8529871575756 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark91(-37.16658898430107,40.75575402591045 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark91(-3.719973424208362,66.51080220502497 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark91(-37.26830111578921,-67.72544537447499 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark91(-37.35520433344808,-172.8361290740861 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark91(-37.63802583941897,0.04323786230049009 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark91(-37.69911013448621,12.56637162765999 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark91(-37.699111743276426,-144.5129005207637 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark91(-37.69911185437057,-81.68140994821186 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark91(-37.699172878233774,-1.5707963267948966 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark91(-3.780674060910993E-16,1.5707963267948966 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark91(-38.13450333714202,-6.4E-323 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark91(-3.817716835107659,41.51682867818518 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark91(-38.17771881898664,-83.35628958229726 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark91(-38.213438813688036,-16.81402828463844 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark91(-38.26926944474951,1.0E-323 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark91(-38.330725578277864,0.0 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark91(-38.39669193056046,-47.416882983705456 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark91(-38.45587406366082,-73.01339325314855 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark91(-3.8518598887744717E-34,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark91(-3.8518598887744717E-34,56.55257401461628 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark91(-3.8518598887744717E-34,94.24777960769377 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark91(-38.61902421528522,58.77034804599837 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark91(-38.69288074768726,0.9937689046097432 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark91(3.8937928265241784,2.3893924806554083 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark91(-39.25609448402061,-1.5707963267948966 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark91(-4.079465095234225,91.32555339758616 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark91(-40.840704496667314,-1.960672839908942E-15 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark91(-40.84071881417019,0 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark91(-40.840719755474275,-84.82300927638182 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark91(-40.84461181712284,0.0 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark91(-40.867139003130625,-94.55171349698605 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark91(-40.86775924132418,55.31523431814134 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark91(-4.1144288349184635,-11.386886003077947 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark91(-41.17984653619445,-72.04980220644617 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark91(41.1952821453832,-15.535967642747735 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark91(-41.19957189588263,0.0 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark91(-4.122548308973432E-15,-131.9468893213367 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark91(-41.24466937930743,93.84381472505368 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark91(-41.33535489944793,7.604366265180639E-211 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark91(-4.1359030627651384E-25,9.424774404696747 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark91(-4.141592653589794,-1.5707963267948966 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark91(4.141592653589794,-60.56968727315653 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark91(4.141592653589796,-73.21791119083778 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark91(4.14159265398229,8.85398838392471 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark91(4.14161266077576,40.838110399359934 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark91(-4.146508097653226,-27.708452999576675 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark91(-41.506372737549505,0.0 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark91(-41.6078288574379,-1.5707963267948966 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark91(-41.610641522823975,-48.3897130120674 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark91(-41.629248923782114,26.86351987947105 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark91(4.163956151143632,32.209886063455045 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark91(-41.669809635021814,-32.24503167425243 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark91(-41.768023486543086,-3.141592653590518 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark91(-42.19170593008117,37.64701365672636 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark91(-4.2351647362715017E-22,1.5707963267948966 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark91(-42.3670296830941,-1.5266057623472027 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark91(-42.411500823159955,-1.5707963267948966 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark91(-42.4115008234636,-1.5707963267929759 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark91(-42.53650082346221,-1.5707963267948966 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark91(-42.55592479372722,-1.715220297059909 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark91(-42.58332445633616,1.5707963267948966 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark91(-42.58370251960208,-1.435255694303073 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark91(-42.60958349362873,42.98133963306864 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark91(-42.61108924657821,12.154388920199892 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark91(42.666602182807,-41.0427211026148 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark91(-4.266696189968883,0.0 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark91(-42.667541168307835,-2535.292031302897 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark91(-42.670548521285696,-78.20867599526692 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark91(-42.67800821073659,-39.393831631351944 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark91(-42.69381723665881,1.5707963267948968 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark91(-42.71357443808669,-190.36842915680697 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark91(-42.74250569435151,-62.31200565594422 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark91(-42.75396890123804,-79.98440711674967 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark91(-42.75635678004666,-1.5707963267948966 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark91(-42.78036191463146,49.60937510710094 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark91(-42.79420014154977,18.910877942611705 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark91(-42.85497073430131,-5.421010862427522E-20 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark91(-42.89333597042885,-89.51734217176852 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark91(-42.91558137745895,77.63079142678032 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark91(-42.92044335003088,-22.29761567184803 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark91(-42.93601933388497,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark91(-42.93955777345962,35.16360793135218 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark91(-42.96379992530176,-100.0 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark91(-42.96786603295369,7.853981633974484 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark91(-42.97761583440311,30.61403178884406 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark91(4.326565377468161,-73.44160375644361 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark91(43.31819303498088,-85.67693440708275 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark91(4.3368086899420177E-19,-1.5601670629141633 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark91(-43.42188384412016,-62.51034737244805 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark91(-43.465728807960204,9.31640959737156 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark91(-43.52576909193129,85.5008651907549 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark91(-43.98229714668551,160.22122506115664 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark91(-43.98229716579655,6.314458517946722 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark91(-43.999477159075084,-1.507075677939972 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark91(-44.007625571831205,55.069293320897785 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark91(-4.415478212956941,41.22532466766941 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark91(-44.191682877522354,74.19288345602854 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark91(-4.440892098500626E-16,0.0 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark91(-4.440892098500626E-16,-2514.2718252615614 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark91(-4.448822469301832,-60.9586935634945 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark91(-44.51326206513049,-100.0 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark91(-44.55703633094445,0.574554124572422 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark91(-44.73305521658687,58.09940537952637 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark91(-4.478222903030524E-9,103.67257138547416 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark91(-44.8088565606092,15.822266200099225 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark91(-44.879405252627706,38.10327073342771 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark91(-44.884202543244236,-49.27058666681958 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark91(-44.956346771222535,1.5707963267948966 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark91(-450.4592777974354,-1.5707963267948966 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark91(45.39266435555086,49.67444233222548 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark91(-45.85876854862152,78.3135187628414 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark91(-4.5917748078995606E-41,-21.99114857512855 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark91(4.609796440506421E-17,-113.07479843397755 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark91(-46.4130769356907,-18.248854879082458 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark91(-4.6780197286674055,61.226687493283684 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark91(-4.70197740328915E-38,-69.11509941532888 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark91(-4.712388980378947,-1.5707963267948966 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark91(-4.71238898038469,-1.5707963267948966 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark91(-4.7123889803846986,-1.5707963267948966 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark91(-4.712388980384708,-1.5623643006111207 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark91(-4.712388980385003,-1.5683085314157814 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark91(-4.712388980385156,-1.549892282202708 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark91(-4.712388980385377,-1.5634746524193899 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark91(-4.712388980389033,-1.5707963267987135 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark91(-4.712388980396617,-1.482523088046264 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark91(-4.712389006721209,-1.5661712775708532 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark91(-4.715590654615504,-1.5756887560914494 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark91(-47.17283811353167,-1.8034802855195977 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark91(-4.722501386918916,-1.5707963267948948 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark91(-47.262403908850374,0 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark91(-4.740785456651467,17.307156071010642 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark91(-47.62497903019278,53.41980994277881 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark91(4.766443973633599,64.66948886464999 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark91(-4.779776889054553E-51,1.0691058840368783E-50 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark91(-47.82207968716716,37.295297472186064 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark91(-4.785983688971264,23.635539610510023 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark91(-47.86158902292519,-1.5707963267948966 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark91(47.94723910249584,-34.370181690212775 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark91(-47.97181759179261,35.84756830552544 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark91(-47.97184285215167,-1.5707963267948966 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark91(-48.00220883357838,-1.6940658945086007E-21 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark91(-4.8148248609680896E-35,56.54866824145399 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark91(-48.16609893838715,0.0 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark91(-48.195702810935316,-2.0522684006491881E-289 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark91(48.439288533171805,79.68222271936463 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark91(-4.8500858976170065,-1.4331457528562423 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark91(-48.5063916063071,16.424106054632944 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark91(-48.554629092527435,-194.9774053993665 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark91(-48.694686130642495,-1.5707963267948966 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark91(-48.69468627497986,-1.5707963267948966 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark91(-48.70688016220157,-1.5707963267948968 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark91(-48.784336401098884,1.5707963267948966 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark91(-48.78654591959444,14.276105197615372 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark91(-48.78947559971249,-48.92882156798315 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark91(-48.7922038870372,-1.4712581083837482 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark91(-48.79764464551801,-7.498484069478155E-242 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark91(-48.799766810854855,61.364636655437536 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark91(-48.80764958141074,0.0 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark91(-4.89182829990264E-20,28.274332946044957 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark91(-48.96429842539478,-76.8053844271186 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark91(-49.16756970038668,-1.5707963267948966 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark91(-4.920261271756977E-18,37.949112971195404 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark91(-49.28107550406332,0.5863351624613425 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark91(-4.930380657631324E-32,0 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark91(4.930380657631324E-32,1.5707963267948966 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark91(-4.930380657631324E-32,18.849800062163773 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark91(-4.948210660903868,0.0 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark91(-49.72005278256962,-0.8861557125013908 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark91(-49.744630343160104,0.0 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark91(-49.74523209941168,91.62643731212901 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark91(-49.773954375912,-38.77928320804471 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark91(-49.79376979846644,4.141592653690509 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark91(-49.80512978271675,43.36739877324683 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark91(49.810190090670346,-20.316718052818445 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark91(-49.84546901826201,-79.71518667703793 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark91(-49.87346298283445,-100.0 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark91(-49.91019274978911,57.19655126885863 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark91(-4.991222771828494,74.10626115080395 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark91(-49.92489144234044,-87.42543133437088 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark91(-49.954487336209894,-58.70651296411824 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark91(-49.954582699571716,-44.838417432209 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark91(-49.974972808450644,31.416020603544546 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark91(-49.9759718272785,56.259157134458086 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark91(-49.98162353446062,64.97563792009925 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark91(-49.99050958527356,31.036745286662267 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark91(-49.99270603364493,26.906047682776467 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark91(-50.009894237116015,82.56645583142344 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark91(-50.011013588073425,-1.0507614211323843E-286 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark91(-50.03905139291242,-29.103185653868525 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark91(-50.06673495572228,-28.07558638059373 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark91(-50.09859088074046,1.1881822289344749E-212 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark91(-50.11676138312186,50.11676138312186 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark91(-50.12149758130715,-75.4157656856645 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark91(-50.143738736706545,0.8060754319146213 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark91(-50.160138689638394,-1.5707963267948983 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark91(-50.190241027329606,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark91(-50.194139451232715,56.042895474683625 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark91(-50.20544387336971,-0.060038584066982106 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark91(-50.22191623279991,-6.490696756005629 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark91(-50.223808221002656,-14.06703977518092 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark91(-50.23687089503166,2608.0333401637467 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark91(-50.26512461443545,15.707963267665649 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark91(-50.26548245743195,6.963838654187599E-18 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark91(-50.265482457436356,188.49639923087784 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark91(-50.265482606561946,68.79933984480118 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark91(-50.28406545974361,-13.940202271532513 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark91(-50.30791886233803,-4.141592653589794 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark91(50.31483773067416,-23.3385610913583 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark91(-50.32116457401837,56.548659152373176 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark91(-5.039376713582371,36.16494612973181 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark91(-50.43936390163507,-18.500564537261177 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark91(-50.46165071658539,-12.699645805472286 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark91(-5.0487097934144756E-29,-9.487279980108573 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark91(-50.55826212103462,-25.581465691293165 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark91(50.65685777151137,-71.96863538827179 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark91(-50.998006817196284,-4.2212712576431773E-227 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark91(-51.074717511934935,-48.362135762963185 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark91(-51.18790597694453,-35.03967530195435 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark91(-51.27954706865254,-1.5707963267948968 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark91(-51.3796488774954,4.3368086899420177E-19 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark91(-5.16879212921865,42.86790397229617 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark91(5.169878828456423E-26,62.8943537990015 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark91(5.169878828456423E-26,-87.96459267054018 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark91(-52.16924209645064,-27.482929616551786 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark91(52.35901581775255,-40.23059947837289 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark91(52.43615454563607,55.42444403876502 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark91(-5.248089578101883,-0.6080221367417873 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark91(-5.293955920339377E-23,3.469446951953614E-18 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark91(-53.407075111098166,69.11704606051752 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark91(-53.458436996498236,-16.363232095345417 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark91(-53.467908908830104,53.467908908830104 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark91(-53.55911375348619,21.78832263249886 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark91(-53.584505591264076,-0.1774305905797094 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark91(-53.58840777193056,-90.89463148841277 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark91(-53.68149551626329,-0.2744204052368048 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark91(-53.84062554852632,-54.50529584841652 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark91(-53.97774973765048,26.284327904126012 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark91(-53.98413964775146,-115.66186364609737 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark91(-54.01063758249058,-38.93207987600184 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark91(-5.421010862427522E-20,-1.5707963267948966 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark91(-5.421010862427522E-20,28.27433161850241 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark91(-54.439783351853976,-48.76436193632325 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark91(54.44909653348637,-95.01840860539433 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark91(-54.54502020634567,1.588983226352891 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark91(-54.550168905723964,54.550168905723964 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark91(-54.564118772608914,6.270638695477032 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark91(-54.58169130991906,-1.1746161988925736 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark91(-5.4738221262688167E-48,-50.26548245743668 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark91(-5.4738221262688167E-48,-91.10618695402415 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark91(-54.75102446509973,60.29320989012149 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark91(-54.844976169579056,22.2836252755112 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark91(-54.876476548939635,74.56165714245137 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark91(-54.89724581441516,-34.300776519188474 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark91(-54.966546360220676,-1.5707963267948983 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark91(-54.97787143782253,-1.5707963267948966 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark91(-54.977871437824184,-1.5707963267948966 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark91(-54.97787143782485,-1.5707963267948966 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark91(-54.97787143782516,-1.5707963267949054 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark91(-54.97787143782711,-1.5707963267941714 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark91(-54.994475909524155,-2620.2902653476444 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark91(-54.99650223931949,10.77325723201114 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark91(-55.0199072580569,-1.5707963267948966 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark91(-55.09568822790819,-0.9874352819958139 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark91(-55.09715927787762,0.0 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark91(-55.164833135355934,21.011363013772225 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark91(-55.230444505720904,-52.08885185213111 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark91(-55.29712990748279,7.046271451140544 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark91(-55.31473645069327,-29.112912285498325 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark91(-55.342385439631144,-4.989548792055487 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark91(-55.35138064371115,-44.125294700661584 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark91(-55.39146761133978,28.37152671102096 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark91(-55.40838361598796,-61.65436627205864 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark91(-55.42837567913058,9.680689029543585 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark91(-55.43569150457627,-98.22587948866133 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark91(-55.453582009864846,-1.5707963267948966 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark91(-55.47892273159167,32.85339841573108 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark91(5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark91(-55.53264369707031,28.934825161828627 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark91(-55.56924532814579,-0.9792944555678157 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark91(-55.58667530382137,55.58667530382137 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark91(-55.71792723028286,-37.84214600944375 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark91(-55.7679059764023,-57.93962186938073 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark91(55.81851307466661,0 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark91(-55.90300237757151,-107.67301230180779 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark91(-55.947081396438456,90.91640067478984 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark91(-55.98762436870435,55.98762436870435 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark91(-56.02442004679482,-91.08412021066796 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark91(-56.03722445625227,0.0 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark91(-56.06691543632951,89.7106842292653 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark91(-56.08890074535799,-82.6025365665862 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark91(-5.609356637629415E-11,-43.299124050088295 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark91(-56.10418146864722,0 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark91(-56.13445210867657,-27.119772821924816 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark91(-56.142519775524796,-38.105259832169004 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark91(-56.175701688580766,2532.6966338386333 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark91(-56.272569060557814,-100.53096895085426 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark91(-56.31978910417843,48.620624253902896 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark91(-56.333153906042,-6.5380872420212395 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark91(-56.351168987489274,56.351168987489274 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark91(-56.360841572512314,-62.405267029482815 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark91(-56.413543268530894,34.111654347006464 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark91(-56.46337099686704,3.266592653589825 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark91(-56.46420329096237,-59.850107902362204 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark91(-56.492304871843224,-100.0 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark91(-56.4956445734379,8.729085849400334 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark91(-56.500279986642035,0.0 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark91(-56.50728886151356,-0.041378903102720056 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark91(-56.51403899758005,-18.467606272403508 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark91(-56.51895569375955,-1.5707963267948968 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark91(-56.537135962815384,78.44497959814126 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark91(-56.5386797701273,80.74162025226055 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark91(-56.54524856942135,-0.0034191951949318184 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark91(-56.54618624133082,-34.55751943158191 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark91(-56.54866751055814,15.707963267946518 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark91(-56.548667764190846,2.060646544507244E-18 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark91(-56.54866776453416,21.991095742622548 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark91(-56.54866776461559,1.5707963267948966 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark91(-56.548667764615665,-18.84955592150924 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark91(-56.54866776461627,1.5707963267948966 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark91(-56.55257401461628,-1.5707963267948966 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark91(-5.6859175518900145,-136.5273246290264 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark91(-5.720585252760436,118.8179207819946 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark91(-5.739718509874451E-42,-31.415926535897928 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark91(-57.606416494171505,-1.5707963259609279 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark91(-57.835750868829486,-1.2871100873634793 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark91(-57.963355727267235,-53.535489796243326 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark91(-57.988852183145426,-47.31499056977946 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark91(5.799517912023789E-20,-153.93901907382744 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark91(-5.809850873813163E-8,6.2870915571804575 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark91(-59.81841116911203,-91.00747199022395 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark91(-59.86155292512536,-2667.7815139891172 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark91(-59.96493699673186,1.5707963267948966 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark91(-60.08188361172835,-0.3915027776144452 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark91(-60.11930081657981,-77.22579811804997 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark91(-60.158810440480146,31.939454870813535 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark91(-60.16791662522995,28.44553029870366 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark91(-60.188922707960344,16.12478686275098 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark91(-60.19860411718598,3.3087224502121107E-24 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark91(-60.2822312674268,-29.546903463344123 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark91(-60.524185428193306,-0.8339250099872343 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark91(-60.61356309442163,-72.3384004021437 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark91(-60.65334580158512,-1.5707963267948968 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark91(-60.730410123084425,-69.11503837897546 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark91(-61.01961142898472,-48.208405449878924 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark91(-61.04810503386808,50.1714357683189 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark91(-61.182021415414475,-1.49504335909665 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark91(-61.261056745000964,-1.570796326794495 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark91(-612.733547737306,-1.5707963267949054 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark91(-61.333904067094934,69.41372617155326 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark91(-61.51696794567252,0 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark91(-61.538148717604415,25.345837208535627 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark91(-61.56747468590895,-55.943736755535966 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark91(-61.84608651331558,-0.5850400209211544 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark91(-62.07155770383983,71.25654833313811 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark91(-62.075080472854594,-21.234375976187284 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark91(-6.225457851162721,-6.533185307179587 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark91(-62.34351108435872,17.761654508609027 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark91(-62.45049577451134,-0.38135729728452605 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark91(-6.269136653996354,34.57156784267096 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark91(-62.78926417867532,-1.5707963267948948 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark91(-6.283185307179233,-1.4854839033826985 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark91(-6.283185307179573,109.95572468492023 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark91(-62.83185307179576,28.27433288714555 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark91(-62.831853071795855,0.0 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark91(-62.831853071795855,1.5707963267948966 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark91(-6.283185307183279,1.5707963267948966 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark91(-6.28318530741892,0.01076593865720099 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark91(-6.283185308374108,1.5707963267948972 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark91(-6.283185336986425,1.0699586965254886 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark91(-6.283185339470137,78.53982687677319 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark91(6.283185426464554,0.0 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark91(6.283185427982992,1.0304491295599551E-4 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark91(-6.283185784076338,0.33341014558325205 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark91(-6.28320056596891,1.5258799287068117E-5 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark91(-6.283200565969085,1.5222033047321455E-5 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark91(-6.283200565972532,1.5707963267948966 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark91(-6.283200566276512,1.579852963668065E-5 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark91(6.28416186967989,50.26457262785549 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark91(-6.28709155717995,1.5707963267948966 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark91(-62.973557623515994,63.800965445603595 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark91(-63.01534799960045,-50.265482457454254 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark91(6.304714630659468,-78.51828701626495 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark91(6.3108872417680944E-30,12.566404758610233 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark91(-632.9789573070962,-0.9835171873288289 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark91(-63.34079105449564,-1.5707963267948966 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark91(-63.37383219563962,2598.4054394920627 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark91(-63.40761320152068,95.19820886869744 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark91(-63.550870055033904,-16.329988138523404 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark91(-63.58917039179124,76.94658983848663 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark91(-63.59693491085965,95.43362708328895 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark91(-63.61311708698139,89.83131598732255 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark91(-63.6644623695563,-15.767302443607448 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark91(-63.753918492307,-26.898597335641725 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark91(-63.82347625099382,-38.81174218964037 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark91(-63.823632911447746,0.0 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark91(-63.96453796733252,-48.59874729979106 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark91(-64.15581531442977,1.3177747429038154E-82 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark91(-64.35960600506012,66.20999026812052 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark91(-64.368967801858,1.5371147300621415 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark91(-64.3866708533208,1.5707963267948966 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark91(-64.39548731778524,1.563634245989366 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark91(-64.40264939858974,1.5707963267948966 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark91(-64.40264939859037,1.5707963267948966 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark91(-6.462348535570529E-27,-3.142080934900258 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark91(6.462348535570529E-27,88.08959964814125 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark91(-657.5928620685169,-1.5256692738883662 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark91(-66.42448936192707,-55.645886795842195 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark91(-66.46038782281065,8.451509629494495 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark91(-66.54448634152092,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark91(-66.58226024921423,-22.68510630691118 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark91(-66.62642928773525,22.913416698781177 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark91(-66.73565878750642,68.39741441804418 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark91(-66.83246555926563,-0.8590198338799705 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark91(-66.87420858840649,-1.5707963267948948 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark91(-6.6939187218009426E-15,72.25663103256484 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark91(-66.96393528756558,-114.08782509141247 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark91(-66.97344572538564,55.548667764616276 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark91(-6.699249837882817,-1.5707963267948968 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark91(-67.17271312894395,-96.77503353160783 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark91(-6.724059062721488,0.44087375554190156 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark91(-67.3078307088313,-20.95021693598554 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark91(-67.36269068309618,70.9542927432819 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark91(-67.4412761025223,0.0 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark91(-67.49048776379003,0.2655336026465509 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark91(-67.52223434381399,42.38949311509565 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark91(-67.54424205217468,-1.5707963267948966 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark91(-67.54424205217904,-1.5707963267948966 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark91(-67.54424205218187,-1.5707963267948966 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark91(-67.56315400186723,-1.5707952930904652 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark91(-6.776263578034403E-21,15.723588267948967 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark91(-6.776263578034403E-21,6.286986671692346 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark91(-67.84378701775373,-42.33434435793129 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark91(-67.87104800653319,40.409541877696455 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark91(-6.790632964299881,78.03236868262454 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark91(-67.93511369773309,0 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark91(-6.831339988150972,0.548154680971386 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark91(-68.58148851689137,-20.951226533574314 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark91(-68.58521471509988,66.55404228323843 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark91(-686.4371408651577,1.2087423577399192 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark91(-6.865613916777136,91.6046592484796 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark91(-68.69404089880729,-1.5707963267948983 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark91(-68.8187039006723,1.5707963267948968 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark91(-68.94027383566674,-2668.3749346472523 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark91(-68.96935661165148,-94.39346137501776 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark91(-69.10251103409529,-0.012527344880164855 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark91(-69.11503837897543,-6.283185304949598 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark91(-69.11503838082294,-1.9259298497035434E-34 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark91(-69.11699150397547,-91.10618649130492 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark91(-69.12480786650491,0.009769518200628985 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark91(-69.16029333308065,-26.837931992888812 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark91(-69.26960848571461,76.50755768733188 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark91(-69.30258998572756,100.0 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark91(-69.32433952034691,1.5707963267948957 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark91(-6.938893903907228E-18,37.69911568661229 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark91(69.54293307783334,-63.54122409021377 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark91(-69.59789744890531,0 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark91(-6.971724047752715,1.265E-321 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark91(-69.79761843206428,-56.45695478922195 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark91(69.8524547622157,-5.860101366045043 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark91(-69.87930531086303,-38.01266022007993 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark91(-69.89013554452394,-28.087080694786266 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark91(-69.93117922970382,0 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark91(-69.94142716318174,0.0 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark91(-70.00853518764727,107.38656472441225 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark91(70.18228334385782,-43.26246217871952 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark91(-70.2327161586139,-55.430989984977835 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark91(-70.25479331076241,1.5707963267948968 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark91(-70.37993735865565,-61.96633854877958 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark91(-70.42829173765277,8.11152460209206 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark91(-70.61134500800642,32.75888188109053 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark91(-70.664097538248,1.5707963267948963 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark91(-70.68583470576542,1.5707963267948966 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark91(7.084140404534665,-30.38249387335108 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark91(-7.117553250329678,9.860761315262648E-32 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark91(-71.56947042810751,-40.0356509826735 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark91(-7.1746481373430634E-43,6.283201079486727 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark91(-71.81108128986504,-79.99970951446983 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark91(-7.201811294836706E-4,-70.46796522341062 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark91(-72.25663152786622,1.5707963267948966 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark91(-72.25663339232511,69.11699265512617 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark91(-72.26444354034199,2.2685873197807855E-9 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark91(-72.27854511613327,-4.9E-324 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark91(-72.51078867156397,3.395750292589907 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark91(-72.5640723637763,-7.853981636588613 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark91(-72.60491310703553,29.72984077190764 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark91(-72.61234325036449,98.5146865150785 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark91(-72.84928593054832,1.1832526518710258 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark91(-72.97752450539386,-36.882056120022874 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark91(-73.14228909772898,-0.8856580651637322 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark91(-73.15329621881725,7.9E-323 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark91(-73.18555731901206,-0.9288839668208243 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark91(-73.19609928179838,5.343717057946448 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark91(-73.28679647685125,-58.531153680237644 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark91(-73.30256191548125,0.0 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark91(-73.37440286265684,-169.14630519728118 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark91(-73.56526619658163,-2.263803687225405 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark91(-73.58000104852178,-0.8787708537355021 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark91(-73.7503841432469,1.5707963267948966 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark91(-7.376086385921312,-51.21672954636895 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark91(-73.82742735936006,-1.570796326793748 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark91(-73.82742735936255,-1.5707963267948966 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark91(-73.92354624950539,0 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark91(-74.04241729826433,2.1619003089938786 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark91(-74.06250233857938,-1.3357213475756593 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark91(-74.13691787417349,-24.5100502939555 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark91(-74.14700458953625,98.38428344646115 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark91(-7.421917005657484,89.9674552556261 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark91(7.429019842189007,-76.65729876794023 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark91(-74.45005899925542,1.5707963267948966 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark91(-745.5574587646281,-0.936746350022545 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark91(-74.87796025346123,3.9374540692382425 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark91(-74.92013540645274,42.246528827910055 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark91(-75.01905111678818,-0.3792671674866563 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark91(-7.512209293908844,-1.5707963267948966 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark91(-75.15404553870798,-0.24417814744706173 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark91(-75.32813947942365,25.709566368604087 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark91(-75.39710785435567,32.34152529162577 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark91(-75.39822368606849,-78.55544133974485 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark91(-75.39822368615502,0.0 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark91(-75.3983021483246,0.007497641349443446 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark91(-75.42456857460498,52.10752383500605 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark91(-7.566605901849894,26.99091328763783 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark91(-75.66976385945895,-0.47146913612333274 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark91(-75.67579519052111,-66.1568627194761 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark91(-75.69389436961784,-78.72629144529314 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark91(75.91871403839914,13.610981687546214 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark91(-75.95567558463821,-1.5707963267948966 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark91(-76.07341150308478,-0.6753164196738106 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark91(-7.607786474394954E-24,2.6469779601696886E-23 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark91(-76.24911093774571,-9.117774022711785 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark91(-76.39094218870841,0.0 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark91(-76.43789256462969,60.80986346305724 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark91(-76.46283616483487,-45.82526321091389 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark91(-76.49937915467065,1.1011561500629534 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark91(-7.650253905286846,0 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark91(-76.59256769818339,-6.89634990100329 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark91(-7.67900192395139,85.85412048339452 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark91(-76.7930141143723,-4.154609622382367 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark91(-76.8709044103376,-52.41180364445696 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark91(-76.87674540624448,47.05028508333402 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark91(-76.9690200129479,1.5707963267948966 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark91(-76.99051613364341,86.59348114349453 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark91(-7.703719777548943E-34,21.99114857512855 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark91(-7.761189469321976,1.4752479737373074 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark91(-78.01424691996584,-87.25740373902897 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark91(-7.8357029755138194,1.5707963267948963 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark91(7.853981633974483,-1.5707963172263597 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark91(7.853981633974483,-1.5707963267948966 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark91(7.853981633974755,-1.5707963267948966 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark91(7.853981633975872,-1.5706308519346484 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark91(7.853981633977421,-1.5515388879230652 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark91(7.853981633980525,-0.5013102716956919 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark91(7.853981634031194,-1.4957733761620478 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark91(7.853981639643622,-6.818835582025723 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark91(7.853981903027144,-1.5707963267948966 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark91(-78.53988023929364,31.416233679588128 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark91(7.85398808970247,-7.852780893842185 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark91(7.854454707500474,-72.04962034528651 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark91(-78.59183909287343,38.710503048427356 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark91(7.864943712586367,-21.65589316303742 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark91(-78.700708395411,6.104306395013509 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark91(-78.70895405929546,6.269100694360347 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark91(-78.7619519124572,10.571538523511212 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark91(-78.77833162339958,74.10694617589982 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark91(-78.82835363717662,0.0 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark91(-78.83391619048426,-0.29409985073942885 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark91(-78.84242574449245,1.5707963267948966 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark91(-78.84763239078157,0 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark91(-78.87043372124884,1.5707963267948966 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark91(-7.888609052210118E-31,56.548669642305526 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark91(7.901033624456836,-20.467354312120126 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark91(79.08597914469053,86.70441753036852 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark91(-79.13308876662491,-2.996460937105553 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark91(-7.913357392009681E-17,84.82300164692433 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark91(-79.1634296191846,1.5707963267948966 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark91(-79.36650594980571,-69.94172798903634 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark91(-79.39808603314968,42.134711292942626 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark91(-79.51155286745274,80.11061266653972 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark91(-79.52796697975941,41.35094838777755 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark91(7.969491271671701,48.57922988582847 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark91(-79.87829000023996,24.83873932709014 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark91(-80.0074328319093,-1.4654839579761407 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark91(-80.0873143241985,65.976949249878 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark91(-80.09060385559266,51.184088252055744 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark91(-80.09480213660774,-1.5707963267948966 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark91(-80.09514415317327,-1.5707963267948983 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark91(-80.13863637403391,2652.986349007198 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark91(-80.2331485065868,-169.16659229855367 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark91(80.85078762242986,-69.6637753321965 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark91(-80.99600939865392,-21.97930188781727 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark91(-81.01351665686494,0 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark91(-8.10230630439068,17.800210504204458 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark91(-81.02777097776723,0.5000813527579879 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark91(8.10398163397453,-1.2955734898197981 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark91(8.103981633975472,-1.3191308469973135 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark91(-81.10978652220018,-59.282144083124955 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark91(-81.49134300340826,-96.31585868409012 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark91(-81.55360822898214,-64.95794302177217 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark91(-81.68140899330793,1.2037062152420224E-35 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark91(-81.68140899333461,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark91(-81.68922149333463,25.132741188899047 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark91(-81.68922149496474,-135.07675044969025 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark91(-81.99043203355463,89.70541460774677 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark91(-81.99916941589964,0.31776042256501963 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark91(-82.01314628363885,61.577199809990304 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark91(-82.17484713749779,-12.516376841065295 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark91(8.244591440765964,99.35067305549401 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark91(-82.47287740023278,0.0 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark91(-82.53750169557411,-98.24546496352308 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark91(-82.79975702803483,51.3838304921369 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark91(-82.80947612721721,77.80568074407691 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark91(-82.8338450830566,1.501296877660855 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark91(-83.07327467060463,89.79203270739124 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark91(-83.0816105329959,59.69026109416219 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark91(-83.08554634584404,89.89703288723827 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark91(-83.1150156823453,-3.7492420347390774E-242 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark91(-83.15040674778214,1.4689977544475181 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark91(-83.25220532012877,1.5707963267948966 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark91(84.78543027965424,75.0638680719735 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark91(-84.82300927631896,-87.9645943004975 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark91(-84.90467768834262,91.31850395661121 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark91(-84.90932373604399,-68.31855194586657 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark91(-84.95154536058726,25.17411635224964 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark91(8.503057022980977,143.59128275194564 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark91(-85.05527758798003,77.06508388006591 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark91(-85.07784756486221,-54.93239221252506 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark91(-85.13044181737793,-0.3072907051281955 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark91(-85.18883119128142,91.47201649846102 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark91(-85.45591945680165,1.5707963267949054 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark91(-85.47526075941347,-0.6522591124890555 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark91(-85.8140037073238,62.85465266329019 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark91(-8.592275700703545E-19,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark91(-86.3207782016063,-21.992330277876903 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark91(-86.39379773968592,-1.5707960927600786 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark91(-86.39379797371285,-1.5707963267948966 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark91(-86.3937979737152,-1.5707963267948966 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark91(-86.39379797371782,-1.5707963267948966 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark91(-86.39379797372197,-1.5707963267948966 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark91(-86.44518711864626,-91.09391027524617 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark91(-86.62559677458508,78.07291151357869 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark91(-8.673617379884035E-19,0.0 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark91(-86.9012922184947,35.62082127150723 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark91(-86.91128713995164,-0.5175276855400317 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark91(-87.12144005570806,136.4716029964634 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark91(-87.83954758874445,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark91(-87.90244027999032,-21.85329000740967 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark91(-87.90899688917166,72.97547798672443 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark91(-87.93837132843181,56.52244479253388 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark91(-87.96455748971712,-9.424780234855891 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark91(-87.96459430052559,2.199989311084242E-5 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark91(-87.9974616446235,0 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark91(-88.03474127814881,25.287729642498505 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark91(-88.04734524550352,0.0 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark91(-88.06534859733864,-53.507828477536 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark91(88.09351352205391,-64.1218524209785 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark91(-88.28140943652201,0 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark91(-88.41590334136211,-25.788048764661966 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark91(-88.41812743726376,-1.5707963267948966 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark91(8.853981633949266,-0.5717460521747894 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark91(-88.8045297802931,-1.5707963267948966 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark91(-8.881784197001252E-16,-38.86782400567782 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark91(-8.881784197001252E-16,-66.67191713344121 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark91(-8.881784197001252E-16,74.53648345818071 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark91(-8.881784197001252E-16,90.83006214918186 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark91(-8.8817842040397E-16,8.8817842040397E-16 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark91(8.89746861748409,49.73709289702812 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark91(-88.98217969514592,12.566374817046993 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark91(-88.99309081612762,-3.138121671942514 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark91(-89.03083560977726,1.0658305803607373 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark91(-89.05980087821298,-41.15085195838824 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark91(-89.08796817387602,61.64120027014067 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark91(8.91672071007217,49.756267650780494 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark91(-89.1703671506416,1.205772850127385 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark91(-89.2756002552999,-42.66112925147534 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark91(-89.28801837216446,31.677078636294965 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark91(-89.32632443552029,35.176197593721895 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark91(89.36562086194863,76.48822167770433 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark91(9.005685068339403,-34.379462509638586 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark91(-9.009911227201751E-9,97.38937224858923 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark91(-90.16550934765723,76.42431420710855 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark91(-90.175926043407,57.933280040544645 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark91(-90.27185163259148,37.815100307967526 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark91(9.05217497307677,56.174187676467696 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark91(-91.10618719252324,-1.5707963267948966 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark91(-91.10618816480486,-18.849458368813227 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark91(-91.1071633954559,-1.5707963267948966 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark91(-91.16748073148787,-68.64919923361688 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark91(-91.1955048363477,-90.63422559905702 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark91(-91.21071395841737,-12.691370614359174 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark91(-91.30559287907163,99.57474131216946 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark91(-91.35383419595742,78.70288950469254 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark91(-91.35985736034525,61.5212792549697 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark91(-91.37936342599762,-181.11873338649434 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark91(-915.7414073577204,-0.3483650972787494 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark91(-91.7348102021959,-39.78574211643114 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark91(-918.9152665873032,0.3212172745358659 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark91(-91.93780174752558,-2.0522684006491881E-289 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark91(-92.30212139884098,-1.1959344447369773 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark91(-92.41223391390125,-62.35239206890124 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark91(-92.53365095197485,-45.40976114812795 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark91(-92.56694217994398,-83.36224642108444 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark91(-92.66460491203122,-1.5707963267948983 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark91(-92.67698328089509,-1.5707963267948966 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark91(-92.6769832808962,-1.5707963267948966 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark91(-92.67698328089664,-1.5707963267948966 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark91(-92.71549520659873,-1.5322844010950645 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark91(-93.0115639113178,-83.03309391062933 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark91(-93.32658907950884,52.19271778260958 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark91(-93.34181949154221,82.66187168312264 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark91(-93.63887504282876,-1.9536118447392568 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark91(-93.81669917892732,77.96728412455889 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark91(-93.9844445933182,0 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark91(94.16102464336032,82.44758618408798 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark91(9.424776782034913,-175.92918858276897 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark91(-94.24777960769377,1.5707963267948966 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark91(9.424777960769378,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark91(-94.24794727437299,-72.25644221362808 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark91(-94.27902969855758,-43.98229716553367 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark91(-94.499158626958,-2628.3181150715986 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark91(-94.50761125267536,1.5707963267948966 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark91(-94.61596622032395,82.04959560596478 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark91(-94.66756796323222,-169.44975261493246 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark91(-94.8444426164359,-41.07593237212734 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark91(-9.492895212276888,78.70573291897668 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark91(-94.98889414938705,-61.561047167371996 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark91(94.99266262454162,-86.42759774106386 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark91(-95.11950079206844,-37.841680563177455 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark91(-95.19005548597595,71.51327416736686 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark91(-9.520220614811645,-25.649829252215813 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark91(-95.4699401903809,-4.363753236276892 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark91(-95.5473890485502,-1.5707963267948966 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark91(-9.622784962646875,69.11665654745944 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark91(-9.629649721936179E-35,-65.97344572653228 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark91(-9.674777960769381,0.0 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark91(-96.86882422759604,-80.6880991921189 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark91(-97.38940277959568,-50.26548245739182 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark91(-97.38940282610166,1.1351375910571767E-6 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark91(-97.3972377357733,-15.723588268048895 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark91(-97.40055818225797,-67.28632057432299 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark91(-97.64666083745472,-1.8746210173695387E-242 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark91(-97.7577233237063,26.828238109593272 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark91(-97.76733248932469,-1.5707963267949054 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark91(-9.786409985490842,3.503224678311255 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark91(-97.90566548593297,1.570796326460318 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark91(-97.96918427022032,-80.8538121616249 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark91(-97.96923665912144,-0.5798643978378448 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark91(-98.03164081251188,-70.03291442861592 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark91(-98.08193340136127,-32.486703086298576 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark91(-98.26985717978374,45.152710283338166 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark91(-9.837360438388785,0.0 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark91(-98.63318277379771,-6.589229335434936 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark91(-986.4600689130096,-1.5707963267948966 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark91(-98.79377116575391,0.0 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark91(-98.96016858807842,-1.570796326793279 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark91(-9.913731177959843,2601.608588684853 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark91(99.17768031173696,-95.50500646610327 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark91(-99.20900906253192,4.6050624568010505 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark91(-99.46158797913328,1.5707963267948966 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark91(-99.46626525346863,13.837989892072429 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark91(-9.964193289019749E-13,-81.68140899333363 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark91(-99.76167339005696,-119.09029899797333 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark91(99.93925811206029,-72.21347864120595 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark91(-99.99352243797026,-0.9481277351298582 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark91(-99.99999999999999,-4.004166190366202E-146 ) ;
  }
}
