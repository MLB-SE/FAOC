import org.junit.Test;

public class Sample51Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark51(0.0,0.0011872171515001568 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark51(0.0,0.006619202220033935 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark51(0.0,0.007119716589559175 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark51(0.0,0.024240102317079022 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark51(0.0039109657477674085,2.482541736240043E-5 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark51(-0.04321540370722598,0.0061841386497305355 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark51(0.0,8.360908541079384E-4 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark51(0.34239896904247297,77.45082225796276 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark51(0.44490734725250264,49.28470400407008 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark51(0.44526973732531494,49.55473026267468 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark51(0.44805542480639043,49.536213339487794 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark51(0.4482903673630858,46.00805151427318 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark51(0.4640303763661099,48.13875833426354 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark51(0.470555167539754,43.01343627040707 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark51(0.47201349525993547,49.527986504740056 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark51(0.4804202001260205,40.00347234729649 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark51(0.4873045495083654,45.61363906444587 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark51(0.48957766928060664,46.81272407990099 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark51(0.495622738428084,41.15129901770195 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark51(0.5083103679147172,48.68469707448543 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark51(0.5124076814313296,48.38337461531793 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark51(0.5132545761646736,49.486745423835316 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark51(0.518383923120959,49.48161607687901 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark51(0.5300125322678042,37.354693507637386 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark51(0.5305329318275867,48.50212328061711 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark51(0.5345302473852604,37.54302341009934 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark51(0.5366249419253621,35.66933049164839 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark51(0.5412897678534101,44.27489832999471 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark51(0.5471344886676035,47.635681684401376 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark51(0.5574052147477695,34.082461749163144 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark51(0.5622474745470925,31.489076646976116 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark51(0.5703326532594559,48.700854766300296 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark51(0.5848442645359171,29.583608995592556 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark51(0.5852650158565211,27.565360457214112 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark51(0.5923965688169517,28.116345877752792 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark51(0.5940686444213128,29.751300785682503 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark51(0.5971057925409724,30.653535346696287 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark51(0.5971648224484909,37.12037116128391 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark51(0.5987339823545728,49.40126601764538 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark51(0.6113345730521604,43.52670327134169 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark51(0.6123075073121527,45.66817169732343 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark51(0.6124835434928144,49.1815390342949 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark51(0.6205653687833506,47.34317659275257 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark51(0.6285977895909792,49.37140221040901 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark51(0.6355296579466696,24.456939387429504 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark51(0.6433635546884346,27.154122941287454 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark51(0.6482541088044977,40.85034048050994 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark51(0.6557126083257536,23.549762266742885 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark51(0.6559750919616505,47.665244917154325 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark51(0.6609730417566277,28.67945765575979 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark51(0.6617026077153403,45.33747176913681 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark51(0.6632973443062156,47.733941983588835 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark51(0.6670715209605333,23.76361915955927 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark51(0.6683506471151983,41.68114544178485 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark51(0.6697760353581673,49.33022396464182 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark51(0.6744274944523916,49.3255725055476 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark51(0.6796021909767287,41.599536873972056 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark51(0.689321419500482,37.04432574229372 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark51(0.7047204822879962,28.714326225752473 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark51(0.7114476910109591,47.4947123216348 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark51(0.7136077724085368,25.123602689556076 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark51(0.7258676792715333,49.2741323207284 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark51(0.7269460308811757,34.15509848489325 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark51(0.728435186201631,48.91958125925464 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark51(0.7311072741830329,25.01979174909106 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark51(0.7360934477639809,26.53664851071285 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark51(0.7393418587205574,46.518080029636025 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark51(0.7467630385739312,21.371549843543633 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark51(0.7578101965005573,49.24218980349904 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark51(0.7582020691665745,26.703127224604565 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark51(0.7590171606643139,34.980502460595375 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark51(0.7603008116745684,30.443491672170637 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark51(0.7623024188764593,49.237697581123534 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark51(0.7626733027471237,33.85506455254368 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark51(0.763930603590066,38.23403760281498 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark51(0.7663414786803338,16.838666443334958 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark51(0.7678153966480821,49.232184603351904 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark51(0.7682268880374001,34.62834141104779 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark51(0.7694027662940155,18.521533148447148 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark51(0.7745275162967884,36.45077744366818 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark51(0.7768466947004935,22.517665258385534 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark51(0.7782713862741915,18.2135243245037 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark51(0.7851595886576357,21.055042604501125 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark51(0.787916039940594,21.156038237745538 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark51(0.7904508336393179,36.82622554908463 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark51(0.7931349124233732,18.296142301195026 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark51(0.7973035009932641,21.354946923131493 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark51(0.8039299783138603,31.228415408091394 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark51(0.8141471919115304,17.590568882854726 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark51(0.8154492486255238,48.47471502000619 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark51(0.8163299575099714,46.099976650486866 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark51(0.8169976010900228,36.031853796447564 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark51(0.8179806327342156,35.565985644217136 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark51(0.8243382724086388,22.690107141556368 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark51(0.8349180789577701,19.86336438692284 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark51(0.8353572421943909,35.42059283876759 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark51(0.840406906107181,43.96530985405218 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark51(0.8423144864171235,21.399659983986425 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark51(0.8434428070773574,49.156557192922634 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark51(0.84616495145508,24.836522452820304 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark51(0.8467661131171127,36.61895373704837 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark51(0.859353031327954,19.968079131800827 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark51(0.8594017095881554,16.172467548296666 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark51(0.8616685064030065,38.741392063099795 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark51(0.8639299050396545,17.809709299009754 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark51(0.8686966413059842,47.21010092052228 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark51(0.8717491858445694,46.43589425909745 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark51(0.8744244383627802,20.93309297565149 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark51(0.8786135636889725,20.60444469305 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark51(0.8809994420418263,17.424950269776822 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark51(0.8824801360928944,31.317377739371693 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark51(0.893181251993397,32.297580067173044 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark51(0.9190264204349636,39.55879440750734 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark51(0.9208551585800677,27.74746374554735 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark51(0.9214763318468044,34.455601276714646 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark51(0.9256100222162402,44.63702106016319 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark51(0.927272911964689,49.07272708803529 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark51(0.9404812485625698,32.73328310490343 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark51(0.9486875532322818,25.384668725017306 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark51(0.9698853199206465,12.235184125796295 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark51(0.9704727857176342,12.21002813157695 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark51(0.9709487054180101,32.78789953205131 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark51(0.9727163719688008,40.784456213775684 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark51(0.976725287645289,11.819406483621123 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark51(0.977585511279448,13.057407382359019 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark51(0.9786388910959545,46.82880591398961 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark51(0.9795075924382814,16.575150742183126 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark51(0.9818218876505291,35.84914524216262 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark51(0.9835321851977596,12.296945432611167 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark51(0.9877102324256999,49.012289767574295 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark51(0.9897949118056675,31.31349234231844 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark51(0.9949598695148296,27.003052637050516 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark51(0.9966198142485894,18.2778958183915 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark51(0.9973012672550308,38.728684186830435 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark51(0.9980484280242925,49.0019515719757 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark51(10.001968589804022,26.536496706193205 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark51(1.000317917093696,27.881873519513988 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark51(10.005560478738733,13.863254264296089 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark51(10.00559172128878,29.834613695154417 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark51(10.010860731789915,18.615373428158534 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark51(10.020606614542132,12.283961568057848 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark51(10.021224207587068,36.7539006767862 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark51(10.024404941438043,21.848697340383907 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark51(1.002917313220662,25.31363394711437 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark51(10.033399644905833,25.35878509056785 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark51(10.034956603843451,26.2968740064681 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark51(1.0047525910424913,47.576330816015776 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark51(10.047954728443434,39.55062517940351 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark51(1.0048988532585348,42.57455389222184 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark51(10.05015292463429,18.992936981650814 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark51(10.05026449655619,39.949735503443804 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark51(1.005985213007719,32.47175238048078 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark51(10.061526920572277,18.872918356088064 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark51(10.061633898020972,35.40202232451247 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark51(10.063590347440154,22.284006038575882 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark51(10.067213610319557,34.98568351129617 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark51(10.06731013879849,31.831496177916847 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark51(10.071414999056842,35.26364907122178 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark51(10.07198169797563,19.193856060410525 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark51(1.0075520389526815,21.078699667894824 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark51(10.080100396666538,13.981473289974673 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark51(10.080425783894713,39.91957421610528 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark51(10.0843724078548,30.822908228507885 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark51(1.010195296030659,28.800198429766652 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark51(10.11886449972188,24.099423127634083 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark51(10.129441293933795,21.830809607938594 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark51(10.13276460979074,21.475784694554207 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark51(10.133648501798149,28.156053377064495 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark51(10.13551147531589,20.746553171667426 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark51(10.149456601601557,28.642367235573943 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark51(10.162350595801598,20.932510014772944 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark51(1.0163626023611698,44.74840507560879 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark51(10.172298473154257,28.485904017518067 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark51(10.17392678976843,11.159738432041777 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark51(10.175158254710468,37.974553479604054 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark51(10.180466465345162,22.884178246273194 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark51(1.0188873231221365,17.081062715755607 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark51(10.189359612437983,13.213397211334152 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark51(10.192650973034105,23.578762369382815 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark51(10.19334036767215,30.42055243711124 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark51(1.0195962520029616,32.059833491867835 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark51(10.198758337990487,14.812045497629597 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark51(10.199570816303577,25.281865468085158 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark51(10.200244757200764,28.219652483785076 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark51(1.0201958277744607,21.387408138226327 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark51(10.20497820173685,38.40851397439255 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark51(10.206916348787473,30.307464161500832 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark51(1.0215511808893352,36.33416679408941 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark51(10.225113014252244,35.85238226625626 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark51(1.0229754133347768,32.51616696155574 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark51(10.230328776091824,38.35547558298791 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark51(10.230831643713472,11.615579254572197 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark51(10.232164341677416,13.940220921982815 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark51(10.233599142743827,32.823330412699164 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark51(10.240434005432217,13.116802219432415 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark51(10.250981619400036,31.08333178367432 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark51(10.252118675195419,12.92269336388732 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark51(1.0254827409991805,23.723718781058494 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark51(10.28475225382882,39.715247746170576 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark51(10.293221123981368,33.59198725573137 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark51(10.293356530117606,30.691762737904696 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark51(10.296824612531054,29.038142952212894 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark51(1.0299727059978858,46.98945031330504 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark51(10.308214893946499,13.009233031190178 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark51(10.343306388755934,31.530732466657327 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark51(10.34725101444947,21.041697544698778 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark51(10.354320134320757,34.22906476839108 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark51(10.35571926961292,27.347303881634062 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark51(1.0361449691362106,15.894696567329353 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark51(10.36693179839763,39.63306820160236 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark51(10.367343665425732,24.870534149285234 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark51(1.0367538741750923,48.96324612582485 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark51(10.36967303660515,18.258842533013706 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark51(10.370818197106411,35.38455708519439 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark51(10.375443846191772,23.142510579331343 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark51(10.376954887483365,29.263238937190636 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark51(1.0398048664922706,27.792612503189673 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark51(10.402644192198139,23.500567783811462 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark51(10.40729787800909,27.002014980903866 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark51(10.415479009069267,37.48773277522347 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark51(10.417144990430643,11.409195940177103 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark51(10.42131671419406,39.57868328580585 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark51(10.422419480438421,32.71113094730046 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark51(10.44128680259628,39.55871319740366 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark51(10.452568947258268,27.36878476796522 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark51(10.455552921838859,37.899222095167886 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark51(1.0457187510254187,32.254301197578826 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark51(10.4690961513503,33.12691516506155 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark51(10.471331092898069,20.813238743025494 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark51(10.472265128143562,25.637628372516843 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark51(10.47994562325323,24.734313138239884 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark51(1.0491191154950952,36.785755537068326 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark51(10.494941679053554,33.38514222931451 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark51(10.501762562557516,39.49823743744248 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark51(10.50378072197627,34.04259969577767 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark51(10.509036893263698,15.560316156942788 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark51(10.514531490147853,20.359100784307515 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark51(10.516346883470433,17.190754819438098 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark51(10.519321051236133,27.55616115974169 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark51(10.525818075349918,29.11761706823509 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark51(10.526143914168301,34.63631621641005 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark51(1.0538914652143063,47.063710394168936 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark51(10.53939081330428,29.914741101470753 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark51(10.540733812539127,32.53840943044381 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark51(10.54303381109879,15.01113369986129 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark51(10.543851778235165,38.43291065813992 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark51(10.547615211158103,38.29112363763784 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark51(1.05488327698815,10.841706716176366 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark51(1.054924359449028,10.656288507288735 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark51(10.551194214073249,15.915885286879671 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark51(10.560675197226473,24.694309720359755 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark51(10.567363654744,32.67640449402228 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark51(10.570076633614661,24.77136412191318 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark51(10.577391321029008,39.4226086789709 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark51(10.587235351959126,25.139984952653336 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark51(10.58978347031345,19.202210226293033 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark51(1.0595436211823165E-14,0 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark51(10.596051451534507,18.385099809259373 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark51(10.602434882964683,35.078427242243194 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark51(10.605471550904781,39.394528449095105 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark51(1.0609909172090002,43.412239992738975 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark51(10.623069008660309,11.611967396652147 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark51(10.625816681328288,16.646318744438474 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark51(10.636093219277878,11.784691624940422 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark51(10.639143108221312,39.36085689177868 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark51(10.64535196950915,13.548387925947964 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark51(10.654522161561843,34.182364509598784 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark51(10.655920861664796,27.18120624753979 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark51(10.663104810214946,22.83942299322223 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark51(10.670809822260878,38.81486801117613 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark51(10.674729301246003,18.370827925524026 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark51(10.67540216302973,13.672065611264614 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark51(10.676771057099387,17.670016636222698 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark51(10.680817676242398,37.84628592720307 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark51(10.681840642305929,32.42636981758261 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark51(10.68402561093093,28.205023246430784 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark51(10.68868714121639,28.962958527341925 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark51(1.0689870245828956,29.5332231826213 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark51(1.0699281296686076,48.29848556625061 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark51(10.70112257275234,38.99421993166516 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark51(10.707324554791242,32.43967069967394 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark51(10.708074126988933,28.68878000929078 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark51(10.70963511516958,12.952614518302505 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark51(10.722771170429164,39.277228829570795 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark51(10.723495104759351,20.894748079551654 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark51(1.0764653396446988,30.69820814163168 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark51(10.768618466540005,25.590942012884653 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark51(10.769019464652082,39.23098053534791 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark51(10.773764196988438,34.625859275820574 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark51(10.777994344381266,26.275312382575592 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark51(10.789947259112111,36.472674790333954 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark51(10.791183099574852,37.709216675654375 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark51(10.791870649267963,13.363512941777728 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark51(1.0801604388934578,28.346166005644363 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark51(10.804568153446127,21.21593226186927 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark51(1.0811865960832279,29.826049749781845 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark51(10.812018307846904,14.558066899798547 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark51(10.817467356864114,14.133235470290998 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark51(10.84586327434603,24.154658891824113 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark51(10.850123726321613,14.496310826831916 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark51(10.850662842883139,39.006494842269966 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark51(1.086121148913731,48.2292640964506 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark51(10.864282955547594,39.1357170444524 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark51(10.870313053276352,19.78549221086404 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark51(10.87161729999842,20.447130546788372 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark51(10.881453402041451,31.3077104048308 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark51(10.885268229285856,12.107215162415123 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark51(10.885703144794249,16.93036534036871 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark51(10.889367829315141,23.537329702395567 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark51(10.890921950323687,30.16625154400785 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark51(1.0897344096839536E-22,0 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark51(1.0897978525336924,29.019606655368705 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark51(10.898483564187458,38.26056891204428 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark51(10.902911358573888,34.2902306666071 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark51(10.90393170525607,11.87701486588162 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark51(10.905941790526313,31.845990414255425 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark51(10.907530823812777,38.16664900923536 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark51(10.909700602839152,28.095318661437943 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark51(10.912827129967923,25.584584394136712 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark51(10.920817332153106,21.69659893808374 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark51(10.921837126457874,34.459201750657456 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark51(10.926074877977968,30.455075532667365 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark51(10.926337376003389,20.614726655665706 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark51(10.934884052561998,24.86957027511724 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark51(10.966359458257415,17.579580577394907 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark51(10.968180570545883,37.10316757329278 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark51(10.971249597910134,12.010141692169034 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark51(10.979112345569018,31.684092175462634 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark51(10.993131290464802,13.464290914370068 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark51(11.000070680926228,34.30495493480251 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark51(11.00294114144998,25.734506366732262 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark51(11.004611108637263,29.25705674883352 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark51(11.004612227241608,13.830300478211628 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark51(1.1007509550030647,9.728847436955125 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark51(11.022070113050226,12.035811952575422 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark51(11.022093710886693,32.894608553800936 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark51(11.03142289095959,37.50171537937376 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark51(11.035120935344494,25.452715591587193 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark51(1.1035641933347762,45.47903937260955 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark51(11.053823118557048,37.66212194767803 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark51(11.057019165856884,21.74510772523972 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark51(1.1058882731600335,47.8941833925675 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark51(11.05954662295889,25.074077685303337 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark51(1.1066725077943893,45.73632102529089 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark51(1.106847105915807,11.736513923940862 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark51(11.074456384957367,14.162194281787823 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark51(11.091778052559945,16.748876936501887 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark51(11.108338970371918,12.07769532576728 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark51(1.11126515293742,11.963712074406601 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark51(11.129831289792719,18.874934302124856 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark51(11.140017857286637,13.407179066611391 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark51(11.142309028713186,28.417629112798807 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark51(11.144117035102333,38.85588296489766 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark51(11.14439309234794,36.44451544127128 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark51(11.147141777547986,12.821049071825882 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark51(1.115655967076055,18.40583827918492 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark51(11.157562519602891,17.094412122714758 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark51(11.161018977617005,18.22109273995993 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark51(11.16237829661506,28.51396536415554 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark51(11.205027350546743,17.862109492436986 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark51(11.20830393124217,32.51983448843475 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark51(11.215016819330572,33.19108098817597 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark51(11.229408309141297,31.93854776559435 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark51(11.22996170218752,16.32986884992573 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark51(1.1232542667691803,24.571818696050514 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark51(11.23947177019246,38.760528229807534 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark51(11.249529378278496,33.09107748103824 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark51(1.1252234297556827,48.44591356878857 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark51(11.26285999563703,15.221105387057918 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark51(11.271996807336256,18.6484054464664 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark51(11.272354249257361,30.7092709903975 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark51(11.293389072379295,25.999460319840257 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark51(11.309029847348265,38.69097015265173 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark51(11.311336437454283,22.565928269079038 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark51(11.31856697818921,20.34954134561155 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark51(11.319059409185101,19.234332223800934 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark51(11.31982234378225,38.68017765621772 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark51(1.1326827765443426,10.623626911060711 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark51(11.33349480567729,24.824206416149337 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark51(11.33726831770123,28.667806332348306 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark51(11.338644970397056,37.98018101746578 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark51(1.1338691250926323,41.02444758495997 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark51(11.361389961007902,15.440134225318445 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark51(11.3735450866306,17.658654928417008 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark51(11.391241094078183,22.537341034813068 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark51(1.13916193557435,37.63640877592988 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark51(11.392624581001854,33.444620027621966 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark51(11.39382799798787,12.63407409768746 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark51(11.396347744464634,33.60691691336376 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark51(11.398212987723731,14.733306570522023 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark51(11.409747702344376,38.03171669553407 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark51(11.413489316844448,23.30485713846724 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark51(11.416891242771698,14.82250829199802 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark51(11.424102362207549,37.7619278639427 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark51(11.451742650626144,27.61965031457862 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark51(11.455975190252037,38.54402480974795 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark51(11.4719247341245,37.436149702188885 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark51(11.478187089365466,27.146002277918186 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark51(11.479463104625111,38.356147226818074 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark51(1.1481594759531504,33.202788002664505 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark51(11.49182892564194,38.1957066726533 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark51(11.493354181272792,27.279111385892833 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark51(11.496493553218869,25.315492559269074 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark51(11.502650030633973,38.49734996936601 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark51(1.1534630275419602,41.03497394748507 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark51(11.54587327232133,36.754919035872774 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark51(11.546476263124859,13.866297872974215 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark51(11.552055899178695,23.073546090308742 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark51(1.158114304092022,15.634188112484765 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark51(11.583335151779252,28.41141041697057 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark51(11.61485719838113,25.770734855130442 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark51(11.617119081974607,28.042172626874645 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark51(1.163515954034799,47.085728532684335 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark51(11.635401664927961,38.36459833507203 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark51(1.1636099140511504,11.498500924808866 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark51(11.642708825864645,23.476011168731148 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark51(11.643323657781025,34.05154826132099 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark51(11.648942693363011,33.3592525376159 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark51(1.1651664445589347,46.80061013953045 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark51(11.652792009549302,37.13882810947388 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark51(11.656062925267603,37.274203425444256 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark51(11.662178095770173,20.181056020410253 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark51(11.663329818539552,35.39472874789038 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark51(11.66700382043753,13.645937431465667 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark51(1.166734359267763,14.822568085447287 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark51(1.1676433131330128,18.36786485779271 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark51(11.717908051483562,28.706716278082865 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark51(11.71931658342163,25.734465797790534 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark51(11.727160033296155,16.519699015566758 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark51(11.730816750460122,28.07785992405684 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark51(11.741705393885098,24.818613537579793 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark51(11.752018208220221,12.661496187595422 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark51(1.175631042026533,48.82436895797346 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark51(11.756670538837746,15.657178540702054 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark51(11.76216662332202,38.23783337667797 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark51(11.77381754228864,14.477867797458927 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark51(11.783054540756083,25.181519108537614 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark51(1.1785525449833225,47.55785737298178 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark51(11.787159987994983,26.984855364987354 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark51(11.792884831487376,30.6972355030438 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark51(11.801551764839676,19.038525902697117 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark51(11.806935659258258,37.36278436238709 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark51(11.808609913603336,32.17669543570668 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark51(11.81091105957893,16.888987118420502 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark51(11.819827869692974,38.18017213030695 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark51(11.82033792222235,29.97087773375077 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark51(1.1824050483314963,47.67585998202064 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark51(1.182737748149411,12.74762351912764 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark51(11.83189988302476,35.984428927575834 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark51(11.839568366156868,21.573212689625535 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark51(11.845026826455623,36.32080671185881 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark51(1.1849410568994614,35.823038874124336 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark51(11.850222852266242,22.636560687869988 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark51(11.860702782719244,24.68092917278237 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark51(11.872383511240557,30.202062065156156 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark51(11.877125658867982,34.94625608075873 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark51(11.877642578329857,21.98567199477699 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark51(1.1878314151657463,28.966182247962138 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark51(1.1882773816419956,47.178553433382945 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark51(11.884160766897821,15.96319456908843 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark51(11.890693565135606,22.971104304744046 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark51(11.89339159731185,31.237388942039697 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark51(11.923706669612105,15.51858964614588 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark51(11.923779871993704,21.215994664680622 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark51(11.935626859256658,15.54255687392299 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark51(11.939203759704654,15.789550952672272 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark51(11.944655126796846,38.05534487320315 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark51(11.947134476698125,33.164324474888986 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark51(11.982519089662702,15.984994267213693 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark51(1.1984384555617205,48.80156154443827 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark51(11.996929436594598,26.805190558288317 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark51(11.998362425845215,14.43417928401152 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark51(11.998598033268394,27.552379043840318 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark51(1.200232684432791,27.55156909667953 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark51(12.013713188913272,24.5108394112913 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark51(12.016484352922973,36.59416847527002 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark51(1.2024127503495219,46.646118803477606 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark51(12.03597037752158,37.0966455907363 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark51(12.036024482388697,34.93849846875503 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark51(1.2051296881858633,31.593389361325933 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark51(12.063512529296233,16.826828603399946 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark51(1.2071506591691161,17.02362078543665 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark51(12.081322781221132,13.36569520274935 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark51(12.108269697345435,21.16472217802901 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark51(12.108854289589615,26.244850059389556 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark51(1.2117426364493582,22.731062814087124 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark51(12.12248708705765,25.861954457664595 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark51(12.124167405827777,15.53402448244428 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark51(12.124633492438164,14.776157378466262 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark51(1.2130931316337978,19.69246687333512 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark51(12.135147754568225,19.195432794883985 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark51(12.147056278586533,16.827333012361095 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark51(12.151174703212149,23.164735051893715 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark51(12.151314007623952,13.287778163015432 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark51(1.2157888992183619,27.294038559136197 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark51(12.166787258403257,20.380646882981154 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark51(12.170020919276837,13.648532947296204 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark51(12.172537494210616,13.069935758942592 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark51(12.175058127869757,15.483360953864931 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark51(12.175841378606247,37.824158621393735 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark51(12.177932603112623,19.037103631301733 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark51(12.178747820126464,16.039450387736892 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark51(12.180821480629817,13.558290940856338 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark51(12.210211986461019,35.5788421893233 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark51(12.224910293393187,37.775089706606806 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark51(1.2230624408370687,44.73805620960968 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark51(12.23680791176163,36.32197952666817 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark51(12.241161777029347,32.714224844492946 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark51(12.266579235886638,17.422695627791995 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark51(12.268165421758397,30.904277875998304 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark51(12.27633282720224,34.595409196344406 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark51(12.279503531405737,31.240278690613934 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark51(12.282627134024338,13.285809408339716 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark51(12.290590947119753,30.63380344404124 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark51(12.291895505245748,21.197164925085005 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark51(12.29522836184032,26.686385811594317 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark51(12.29791587051239,29.962144956115495 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark51(1.2299201164174867,8.454571342713251 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark51(12.31546051384797,23.84501655296882 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark51(12.322743016306518,20.314649293082226 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark51(12.329313950838937,34.93280228646199 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark51(1.2330561563558473,8.394461610499178 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark51(1.2334666254889157,22.00733261193895 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark51(12.341720041506846,28.672782581530015 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark51(12.343542568933557,36.015706829667664 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark51(12.352124549969105,37.64787545003088 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark51(12.378276311104745,24.444621569932306 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark51(12.379468979630204,25.108851602968596 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark51(12.382192868865701,32.58002635657368 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark51(1.2387818773785142,35.043982939429014 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark51(12.394984171183694,20.06175741484249 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark51(12.398384899636312,13.37495710676744 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark51(1.2405867943624571,29.4884891995585 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark51(12.408509071660049,17.8288616459743 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark51(1.2410063263160596,24.481919823403018 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark51(12.410536782542351,36.79748881894844 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark51(12.41095335425301,24.271141660325128 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark51(12.41586037240721,19.02615229579348 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark51(12.42433908733949,17.19536509913395 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark51(1.2428599308280894,31.39814898094167 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark51(12.428637344575613,28.008988990716443 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark51(12.456596190214242,13.345358444862041 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark51(12.464700594074856,32.501318705667046 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark51(12.48626300512521,22.687831351258808 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark51(12.488349753665545,35.727209046713426 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark51(12.499042739498181,25.76759334105555 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark51(1.2500700028411087,40.16483141832063 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark51(1.2504567872022108,15.046842083722503 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark51(12.507106627044436,37.49289337295539 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark51(12.545534018807885,33.91284118682344 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark51(12.556960497282631,36.63563006218692 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark51(12.566906506273853,21.83061070224784 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark51(12.572862784554445,31.083235995878198 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark51(1.2573108689591588,27.991207226286704 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark51(12.581796601662248,24.075549070757532 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark51(12.596829260888725,33.29018075028878 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark51(1.2603510582793689,45.20692001720951 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark51(1.2607230307642965,23.714568227578894 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark51(12.609564741191235,20.172200426725496 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark51(12.615644290710463,15.682068869123071 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark51(1.263091447063374,42.849356303843024 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark51(1.2633163296227536,9.061420676620173 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark51(12.635840891319532,14.004480868895783 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark51(1.2639170082223918,48.45070850411602 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark51(12.646558713735391,15.405866947400757 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark51(12.649456306335804,15.025000162751638 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark51(12.651759969636828,20.020372354284916 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark51(12.654745585902077,13.57565261370771 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark51(1.2659759850320929,48.7340240149679 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark51(12.661319625373253,13.536533063342077 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark51(12.662393447340918,13.633098504384847 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark51(12.66620596403942,35.57583300507524 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark51(12.673384116036246,25.833273552442733 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark51(12.674304166869149,14.261428809858984 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark51(12.686427614389824,27.071560210000307 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark51(12.689449578513361,30.314999322595327 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark51(1.2711015477071559,8.934140234628675 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark51(12.715321790028995,31.934232828319722 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark51(12.716160971491846,14.213142648424991 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark51(12.718845497063285,20.1038255811427 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark51(12.72985978835139,13.838880939058143 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark51(12.730977427603605,21.35954031895983 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark51(12.755642463159148,23.228442132512512 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark51(12.76515228035369,32.793351644734116 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark51(12.79999374496856,17.416269891694142 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark51(1.2801718159788393,43.348709360884015 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark51(1.2810586091891336,13.545042433337997 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark51(12.811668556661123,19.46193706278956 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark51(12.8144681241031,29.08383522647145 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark51(12.81560244377593,33.07165200676772 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark51(1.2822737856979387,31.429630270611312 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark51(1.2831969574503574,24.919910903806297 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark51(12.83695623792471,22.989367350014845 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark51(1.2845555373999673,33.20080054311131 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark51(1.284679604361429,9.066302332829295 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark51(12.856116604326175,19.74367389805083 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark51(12.857766281302858,30.316292688356384 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark51(12.8588218787731,33.147205001854275 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark51(1.2865623573158729,41.989578090796925 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark51(12.867322204451863,21.817312855171124 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark51(12.87085024769921,29.0034189927662 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark51(12.87533814804587,34.66231109040348 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark51(12.880732451903356,32.16992817161389 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark51(12.886543692148237,26.64538932538865 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark51(12.889249468744708,23.87468437869019 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark51(12.890033197680063,30.979685531993958 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark51(1.2890033608531581,42.80417623239168 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark51(12.908603815749231,34.08122217591199 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark51(12.910032624913269,21.68424401280076 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark51(12.910265771487175,13.917311290502642 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark51(1.2913553206073813,48.70864467939261 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark51(1.2933503723310196,24.434636896017764 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark51(12.936360033959929,13.821472607194083 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark51(12.93869621697496,20.5203684226866 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark51(1.293940698311026,48.706059301688924 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark51(12.946376661039594,22.036741085143532 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark51(1.2952829994068331,26.224716832050802 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark51(12.97101693419944,18.49751765198411 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark51(12.971898243075707,37.028101756924286 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark51(12.976176747519645,24.523444903590246 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark51(13.002303072276035,24.311876798571873 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark51(13.004361249101521,32.72395902461375 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark51(13.008952794679475,29.234339914781803 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark51(13.018610396486451,17.293737051324968 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark51(13.022441228455122,21.54615521249808 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark51(13.027195292558872,31.78180820736293 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark51(1.3033002242879719,38.137752365086186 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark51(13.047313173255434,36.79094071154148 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark51(13.050807620745061,21.503264016557864 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark51(13.057380640619058,15.152779274376655 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark51(13.080235472566319,14.739693178438962 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark51(13.080953468485077,29.657746469328544 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark51(13.081230768076967,23.488160862712284 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark51(13.081846244968844,27.77375739695829 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark51(1.308431054974136,48.55524216792085 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark51(13.085249382140582,25.949104737350094 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark51(1.3088317549557047,7.939498405622274 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark51(13.08858697420132,33.12453538718364 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark51(1.3090295043686488,30.837348883824053 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark51(13.1116051349684,30.506692546907914 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark51(13.11835606143017,32.39124386498857 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark51(1.3120774334418126,42.00112086826853 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark51(1.312113255938204,46.108783662383345 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark51(13.122485827490578,27.66496735921401 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark51(13.127313101947237,34.741666754920345 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark51(13.132545320576199,27.606848172615116 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark51(13.134240659471121,36.86575934052887 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark51(13.134821639482169,35.356017234613404 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark51(13.146265559791885,28.40079385793848 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark51(13.149255123278422,22.93311191929581 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark51(13.149743201044913,22.233949461107613 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark51(1.3150900183605323,10.477059313068544 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark51(13.151972240530284,32.69683295212715 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark51(13.168759543757602,14.427611302055828 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark51(13.171633849895969,24.030992864620984 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark51(13.176443070368265,21.1098090847684 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark51(13.177062772201385,24.442150866476002 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark51(13.187762975211186,14.89225103854443 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark51(13.195390027647232,19.62057472514018 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark51(13.200878113792431,25.921859534263263 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark51(1.320216795358533,11.80484347404725 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark51(13.21422622786119,36.44697827744207 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark51(1.3216415525593845,31.04965659673755 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark51(1.3226149874260358,43.36500183330591 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark51(1.3229427739761312,12.928778364163833 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark51(13.229792230285128,26.558888621859396 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark51(13.236046746078365,36.76395325392162 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark51(13.255953249654507,31.88040351153711 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark51(13.259627864724228,35.613707865942054 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark51(13.262574247536648,36.72956115898779 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark51(13.269463995436112,24.814328318742145 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark51(13.270591057571423,19.534721372227423 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark51(13.275461750210482,19.47532625765072 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark51(13.28424526724772,18.522930650579013 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark51(13.296265983201614,27.62451818253074 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark51(13.300906374351996,18.142955716515857 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark51(13.31103762886103,27.480389627082175 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark51(13.319356874417608,34.79938618195027 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark51(13.328504665239848,28.895430207221295 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark51(1.333133126600842,9.309432505306361 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark51(13.334784070110842,14.182053232491263 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark51(13.365596904225283,14.422838539313908 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark51(13.375742943456228,15.42179300617127 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark51(13.381906695757095,34.0586760196621 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark51(13.383832298302977,23.760882991401047 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark51(1.3388613289631763,33.03065823022334 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark51(1.3391296043928698,10.07172691613856 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark51(13.391659258773679,16.75527540939914 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark51(13.394674366828411,33.11357085532222 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark51(13.409371144316012,23.40585136439404 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark51(13.422660495851517,14.60873073400522 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark51(13.425150931645721,20.571841331535182 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark51(13.429035593556591,31.540393357451677 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark51(13.430263862958782,21.363341413772048 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark51(1.344015021943676,43.752307683610894 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark51(1.344095048053191,45.48667928318292 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark51(13.445625163153217,15.888294013995274 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark51(13.455816108239986,35.50508390516745 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark51(13.472559467080586,16.07187421449008 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark51(13.47638802989431,15.20990659415968 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark51(13.495572388559946,20.37080647130543 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark51(1.3498348230468302,13.486521894609169 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark51(1.3503370518358588,44.256452315882576 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark51(13.50355116761554,15.424028780484235 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark51(13.505583044677394,15.791253092536465 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark51(13.505692523573302,26.335848342789788 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark51(13.511717355412154,31.061614773009694 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark51(13.528193923153253,20.661218845534723 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark51(1.3531922728265044,48.37503701927787 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark51(13.546956638126726,36.45304336187314 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark51(-1.3552527156068805E-20,8.597973193935831E-5 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark51(13.554422560251083,32.9224745360994 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark51(1.355611367050173,7.75114770860418 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark51(13.559524887050188,23.41508405059973 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark51(1.3561271976309779,29.846549782740283 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark51(13.580421394913202,33.101822870933546 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark51(13.58147233673493,16.12350760329427 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark51(1.3598452990513579,28.517545147352592 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark51(13.609325933862323,17.812869559008988 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark51(13.611430761869883,33.501479680243364 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark51(13.614295036997738,18.71309680192688 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark51(1.3617691236914578,14.197601782627075 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark51(13.643673957334173,35.18463105909609 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark51(13.645147274807325,21.179004986729396 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark51(13.654578798095415,14.720177016544483 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark51(1.3654793472409636,23.33070598866385 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark51(13.655059402462612,35.87295376726712 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark51(13.655373173204893,17.57865273286754 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark51(13.656208957064138,28.33856723844707 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark51(13.680463814144545,34.67999153228616 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark51(1.3720829360645865,15.41018853394985 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark51(1.3730466201705696,28.796361416773664 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark51(1.3744933243654476,28.1559245477263 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark51(1.3745532309476909,22.833799917285575 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark51(13.753780180324668,33.78798071869119 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark51(13.76568152452495,15.740927030088756 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark51(13.767659136076603,23.691824467405297 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark51(13.767925325807568,27.20200693921231 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark51(13.772524349109716,16.772627108426192 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark51(13.778557019073896,21.336937302334988 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark51(13.78258405841892,29.793917979696715 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark51(13.818286438236214,35.85599424867203 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark51(13.822405721989348,26.780974532268104 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark51(1.382267372579335,33.509452282088205 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark51(13.837341353701333,35.039802427926446 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark51(13.849415991851032,14.815166758341725 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark51(13.859807317759845,28.183328090915495 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark51(1.3870767919334628,48.612923208066526 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark51(13.8879757522269,33.77103145959553 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark51(13.899404620858988,27.100701417316643 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark51(13.903737772154102,21.87984725092072 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark51(13.90396888973089,18.561182541530513 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark51(13.913476887609534,30.437874596624113 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark51(13.915282137936643,33.428281386046166 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark51(13.923111773497567,35.812019656658464 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark51(13.930489496051138,23.92584310178046 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark51(13.933561650774642,30.831884578677915 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark51(13.935225517073519,21.89660186041218 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark51(13.9419708837293,19.779017958990593 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark51(13.943238850102048,19.98385317737194 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark51(1.3962804434008262,31.831695574624234 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark51(1.3978484864285383,8.472840429459922 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark51(13.98286633048674,30.829921457032807 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark51(13.983763581153069,18.32564264478323 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark51(13.988189410395833,27.41337688088241 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark51(1.4027243756797816,10.358591652660692 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark51(14.038911653170388,19.826471140667067 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark51(14.057002845253336,24.716459271543044 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark51(14.060768902891013,31.339938380284366 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark51(1.4063901863465844,34.47729249240754 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark51(14.073041224147516,29.92744190184419 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark51(1.4094171295309232,7.24594177199268 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark51(14.11330968156517,16.002734090546028 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark51(14.11583806963391,22.36641684753363 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark51(14.13094496234138,17.11978022092437 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark51(14.145567753001927,29.74235504265937 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark51(14.148346655204708,19.513800978427916 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark51(14.156987065698104,20.292768680029212 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark51(14.160424253040416,21.80887551661756 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark51(1.416449253087431,8.094907650121087 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark51(1.4175250134484214,43.88460088103632 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark51(14.182706860025164,16.89201140904659 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark51(14.183485541953573,29.375964067760805 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark51(14.191486481936465,29.004491465911656 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark51(1.4191701024117975,7.129208671324568 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark51(1.4192328719505438,16.977015546763383 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark51(14.195413488808569,15.100768276761855 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark51(14.197953402555413,34.040351140348236 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark51(14.215246530047091,35.7847534699529 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark51(14.218680414678957,19.034988245321344 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark51(14.220200086976263,19.7277285273844 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark51(14.230591963558467,18.504506310620684 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark51(14.23243390473542,34.010297503251536 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark51(14.237051637583036,32.99212048378891 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark51(14.257262602837697,25.771318284850686 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark51(14.258452144505464,31.79537047135588 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark51(14.260371802730374,35.73962819726962 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark51(14.261239368248201,15.793774416550207 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark51(1.4274598368859301,45.65668881695834 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark51(14.276634997524297,17.345362038080438 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark51(1.4289822317144667,8.169318235799855 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark51(14.29138771778405,35.17286859831637 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark51(14.2992250020813,18.58975211655772 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark51(14.3184968450811,17.593282876474902 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark51(14.323896653740803,23.089026081392078 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark51(14.340459280397365,35.659540719602624 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark51(1.4342285393701815,14.771821251090131 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark51(14.345987011460757,16.114040438808104 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark51(14.349205843684754,30.976526614732293 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark51(14.34948215100809,19.96798253511882 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark51(14.356849035888274,15.244600573545725 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark51(1.4358640399991174,45.70005525198326 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark51(1.4370773687036404,47.05582515282754 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark51(14.372441018105235,22.972059122751176 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark51(14.380530630164799,20.38824251173739 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark51(14.40679713482811,26.736395685753394 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark51(1.4429626493932162,47.521467297078914 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark51(14.435948521658858,20.593159723894644 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark51(14.44204567618685,15.268704195006968 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark51(1.446078535227286,25.466582069528656 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark51(1.44753642738047,20.140641575217003 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark51(14.498895835506204,23.831366672326517 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark51(1.4508911632473769,35.22831906803131 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark51(1.4513582766149966,13.806149856704451 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark51(14.516771062542034,23.142161781219144 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark51(14.523435270777483,15.94231916377538 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark51(14.542118396301712,18.428046442368117 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark51(14.56485520154331,20.22512280403339 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark51(1.4592811532854073,48.54071884671458 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark51(1.4597951199085486,36.50675698358904 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark51(1.4606462885880802,44.913055746325256 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark51(14.626805055188825,25.832925642505145 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark51(14.642546911788372,28.79562288187668 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark51(14.65458631313517,27.705534973738693 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark51(1.466119383543571,28.96973658087748 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark51(1.4669204159880027,28.440979244172212 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark51(1.4685214790339023,26.040853736747053 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark51(1.4686152116196567,47.38836666916663 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark51(14.692303078153117,29.486353885554735 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark51(1.4693017270890865,38.50092494525759 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark51(1.4705846492481776,31.046075455303452 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark51(14.709754044195819,29.860610355599874 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark51(14.710979066883908,35.289020933116085 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark51(14.712182046119906,17.162270418410813 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark51(14.724966399898022,19.881365661041997 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark51(14.727110657158903,28.65342151836049 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark51(1.473318359438494,18.695068281597358 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark51(14.739115904104981,23.716257798547975 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark51(14.745262526874797,26.178017790652362 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark51(14.754833841639936,32.00542937613079 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark51(14.763067196191486,27.065847236741348 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark51(1.476494573409358,38.308439997181466 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark51(1.4776652312472152,20.193588473601537 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark51(14.790268819537005,21.702636744438777 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark51(1.4793889614453377,40.626440519262864 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark51(1.4807937153170627,13.79129474168002 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark51(1.4809330180625153,20.318805426685543 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark51(14.810133723310969,20.817422406239515 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark51(1.4820709281638642,7.0594842834984775 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark51(1.4824618441350026,19.847064790495097 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark51(14.828719976896679,23.663358893012756 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark51(14.835548014758942,33.24709157792026 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark51(14.83930109802101,20.051550653403254 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark51(14.843177561522651,26.976428678617893 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark51(14.84603833932793,17.540898343697208 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark51(1.4876249344272452,14.423905686381858 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark51(14.880704311246596,30.581265893730638 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark51(14.89102604352129,16.476887436727765 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark51(14.893371640011438,33.17892643195657 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark51(1.4910665790133528,6.924944902685809 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark51(1.491975578575568,11.870579102548895 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark51(14.944982145984014,32.25424323129627 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark51(1.4947397878744368,38.939615468450256 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark51(1.495016277109344,27.442621047285932 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark51(14.953456789164761,34.0281563511374 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark51(14.960462041241367,30.064193056232796 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark51(14.96603250338886,32.79030856290242 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark51(15.00054568889453,33.142456046597545 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark51(15.012797590624615,27.857916578512402 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark51(15.032930010625506,20.087034709228774 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark51(15.038865300608368,34.96113469939158 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark51(15.041088049459177,21.30827694647415 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark51(15.045781341195585,31.88329464001103 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark51(15.050177080319727,26.054713417778032 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark51(15.053963345191313,34.94603665480648 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark51(15.054675766594855,23.59707973893434 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark51(1.5075685695380752,16.760918403412177 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark51(15.075858313853402,21.639416281638276 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark51(15.085179784753635,17.77676771989985 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark51(15.091642563953897,23.5812666969006 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark51(15.094642930190119,34.05968392132178 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark51(1.509464463638821,25.928632777773046 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark51(15.116715295203093,21.673823244500426 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark51(1.5120138322087795,18.306663052907776 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark51(15.126274543271464,24.76295695052295 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark51(1.513005817521293,45.47857405806573 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark51(1.5131162118635189,38.04426831598258 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark51(15.157827429510263,31.923501696482646 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark51(15.170267338570056,22.69870384735735 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark51(15.174369566360753,34.49323250402446 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark51(15.185953476008375,18.064523760854122 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark51(1.51995922211598,9.993509079859166 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark51(15.199915131995919,26.78720634730358 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark51(1.5209157182555373,47.58283755764654 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark51(15.222840691470083,33.41822146625083 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark51(15.229229933642216,23.498807815693283 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark51(15.235422633700693,30.670880559295966 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark51(15.255618676071236,28.973560641368806 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark51(1.5266430996867086,29.963712771531675 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark51(15.285427143549635,34.71457285645036 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark51(15.317831745220602,34.68216825477939 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark51(15.321852029774655,26.03352790554152 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark51(15.338828207677864,16.310937133313047 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark51(15.340047871463385,29.98040217134087 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark51(15.344784849770406,24.28973797164018 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark51(15.35357252581295,18.21198183867226 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark51(15.356480934024056,17.59839859980646 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark51(15.364205332102266,17.534114865855187 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark51(1.537974286432151,28.779344057120483 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark51(15.383575363518815,28.4737656988583 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark51(15.392879080102105,27.00962603491297 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark51(15.395178173773118,16.66795680239624 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark51(15.398908956814196,31.869893515219218 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark51(15.399061039386638,33.173949985884605 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark51(15.401649410075207,22.7652551929377 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark51(1.5403173363966367,34.94561548933976 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark51(1.5407522390114679,8.331561665790915 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark51(1.5419986526033966,23.719953172682036 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark51(1.543404046898523,11.298875278139548 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark51(15.435397039646503,34.41287882331497 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark51(15.43821077889578,29.119605893426012 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark51(15.439434984412827,27.125051707853615 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark51(15.441639277969472,18.587988198316715 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark51(15.442174899947835,29.79432858285577 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark51(15.451934289976819,21.31515586950661 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark51(15.454778219663126,19.650289827636243 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark51(15.46616332232228,23.050972211505737 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark51(15.4780234358841,20.895853971839244 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark51(15.483156070770576,27.38922001895854 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark51(15.504330635900104,24.436435693861696 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark51(15.540316995133676,34.45968300486629 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark51(15.544164135168103,28.00918560768426 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark51(15.546725519886422,34.453274480113556 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark51(15.546836198707545,25.497412404728674 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark51(15.552540414855187,28.351912614660336 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark51(15.552569839316234,32.65994260349163 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark51(15.574323001963952,29.12171416890004 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark51(15.576663855589018,23.161301432224306 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark51(15.583370410113844,33.67396584081932 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark51(1.5588786741063245,23.332713162893498 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark51(15.589453643597892,24.64450907868914 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark51(1.559805994700528,7.816622338588758 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark51(15.61752885357184,28.234320821675936 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark51(15.626998754262694,34.37300124573724 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark51(15.630458204424109,16.703439444770552 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark51(15.631194476187112,33.453209747669376 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark51(15.637450411217785,19.936000896614274 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark51(15.647454053332075,19.48150178553114 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark51(1.5672611708789077,29.749907189661315 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark51(1.5675571005368498,22.74223403432724 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark51(15.678551068558187,19.101906086078245 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark51(15.703090816240652,16.60539989639974 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark51(15.705548612973615,17.255441234265504 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark51(1.5710555979395044,13.3413503611969 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark51(15.711007370956168,20.006659521264524 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark51(1.571200694760961,18.235605323071866 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark51(15.713319068536052,30.82770012520166 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark51(15.715972276372938,16.608417202308576 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark51(15.717155696727215,23.857359408168783 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark51(15.723901362567421,21.51186799835368 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark51(15.739726581024655,32.75927866540377 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark51(15.740073307902676,21.80026495598848 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark51(15.750245842084297,33.319042524361606 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark51(1.5750308306474494,33.00793635726086 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark51(1.575867089016029,46.97301707105834 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark51(15.762043015448384,34.2379569845516 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark51(15.76886217798743,27.638743572025845 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark51(1.577290992794417,39.02054100177634 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark51(15.778274837134873,17.27997780102799 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark51(15.796442620707884,25.6056912449737 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark51(15.797113285776575,29.630712856834663 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark51(15.822948465989233,17.206625709655572 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark51(15.825289000457559,23.132611230193362 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark51(15.840166314092485,20.654434961064027 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark51(15.865591003005711,34.13440899699428 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark51(1.5869334859841526,24.566093549858305 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark51(15.877386885309079,17.46933832417521 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark51(15.877397306397036,34.12260269360296 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark51(1.5885549358183235,41.44513363058197 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark51(15.886985529101167,24.2541919906525 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark51(15.905181727841367,24.026925750331856 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark51(15.905578137899596,28.199143191246037 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark51(1.5908309783504677,16.18847654195889 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark51(1.5911492003901628,8.564514341457553 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark51(15.912153166499536,30.00676142330073 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark51(15.922821924190515,19.977353678037616 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark51(15.931553459425785,20.64708019673634 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark51(1.594065862907712,15.14644207403694 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark51(1.5941616374734728,18.21104348818038 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark51(1.5960009720185298,44.927779057147234 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark51(15.969210853807098,17.21180004659395 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark51(15.974438531707193,27.841369477412186 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark51(1.5976902397424837,15.371336735372026 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark51(15.983203720277345,23.74491923127775 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark51(15.99032756752699,24.37793288547701 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark51(15.998290446074046,18.25672612321432 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark51(1.6007737638713309,20.33958072812571 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark51(1.6026493496887482,40.528595669056095 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark51(16.03408102170532,32.28719436970792 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark51(16.03460405639115,33.96539594360884 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark51(16.038016542644286,26.619330706401602 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark51(16.066684041837043,16.975921376715334 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark51(16.074507581722827,32.09184728872688 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark51(16.085632034891162,20.794634340349436 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark51(16.097959412639554,18.03297143585351 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark51(16.099179829739924,18.617992474404346 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark51(16.103527267844015,32.822353423518145 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark51(1.6103904003772413,35.340347831465124 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark51(16.113496488597107,16.894735658115863 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark51(16.131396388311632,23.642973144448554 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark51(1.6135586499940189,41.715215598312426 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark51(16.148340609916417,31.41556441119741 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark51(1.6158517144771167,26.645609169327457 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark51(16.17019242639668,31.35221079628633 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark51(16.18437877192666,21.834865232699016 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark51(1.6194179396890434,19.3160139457992 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark51(16.19742538805123,17.806988238937578 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark51(16.201375462109198,20.94849309497681 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark51(1.62092331970827,11.921913501302855 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark51(16.216881480624906,18.16612627483863 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark51(1.6227822282508697,24.521722449187862 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark51(16.235808649326273,17.812701403232566 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark51(16.247667448649466,17.647769702320133 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark51(1.6270389193854982,15.983211414400785 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark51(16.288139907106824,24.63632109606377 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark51(16.302886638019842,30.961046093790657 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark51(1.631949006381256,30.965133732937694 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark51(16.33265266333632,32.29600444759666 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark51(16.35393439960623,30.067124896027686 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark51(16.356718552891806,29.065705923215205 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark51(16.368276515921565,33.016180454028614 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark51(16.385581076936703,18.660431936415506 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark51(16.397588805230015,23.824111114087515 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark51(1.6397890595614086,10.312039703379085 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark51(1.6398393402143228,45.479216219320364 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark51(16.40905027094017,33.41188523671073 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark51(16.418678561566026,30.042591320100655 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark51(1.6421806791943112,27.252768641183692 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark51(16.423519059894033,17.844133431805133 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark51(16.439541182329705,30.10744788259251 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark51(16.443078136241365,30.284672820740838 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark51(16.44605700205404,30.42024444886254 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark51(1.6477647156755166,45.78550939068106 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark51(16.4799128362813,31.529941873261265 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark51(16.502427387459505,21.36865550270582 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark51(16.5042019846193,30.112168362941503 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark51(16.51256159998141,20.922492794453817 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark51(16.51280128293267,27.953495053419132 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark51(1.652604486482912,46.442119385279625 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark51(1.6543488604455092,26.36767786910727 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark51(16.556212791827903,22.992889228080088 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark51(16.562670216196324,17.365732077473304 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark51(16.568079124931103,21.95589732901962 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark51(16.572292030834305,19.155515630620584 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark51(16.606368825522466,21.211612823805837 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark51(1.6621931269988437,9.801509719746917 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark51(1.6623385059916274,28.057842259207433 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark51(16.624166119576643,20.096556014721187 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark51(16.62909224276808,29.203101166399534 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark51(1.662938096079909,20.714496613503115 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark51(1.6630503588575465,8.052329810565837 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark51(16.644714245869068,20.320376694878917 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark51(16.65782111819607,25.497662938976575 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark51(16.69888320538429,27.03960505292858 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark51(1.6706047226518592,9.236410212603445 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark51(16.733497846393334,23.47207438852716 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark51(16.739019576475727,33.260980423524245 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark51(16.740217570033295,17.495693601169094 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark51(16.741575359484457,31.785007132654016 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark51(16.747873904136913,17.866973049765924 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark51(16.754978664393633,30.145781581327725 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark51(16.7608540889781,33.23914591102189 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark51(1.6763577723697043,14.511101842763628 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark51(16.777155813730673,17.596612958165466 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark51(16.777801106972163,18.24817126880687 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark51(16.786559859507094,24.82362058566048 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark51(16.788299277801315,21.74184627853954 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark51(16.816844036397477,33.1831559636025 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark51(16.817041722327627,24.77903253627672 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark51(16.822559796815355,26.015735308707292 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark51(16.832379845706697,18.524211166761262 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark51(1.684976278086709,34.05044021075699 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark51(16.85607466176715,23.358434856176885 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark51(16.871386690405842,32.52964201632676 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark51(16.88435189823545,32.45935490280027 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark51(16.895803258115542,33.10419674188435 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark51(1.6936729942293312,47.261236583966934 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark51(16.93697568179782,30.690165090156512 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark51(16.947308933562752,21.622849636546704 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark51(1.6950189150931987,40.75808403897244 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark51(16.952137320785297,30.722998078985178 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark51(16.96000952830181,20.987630875540006 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark51(16.965143424025044,31.208504637161127 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark51(1.6971036630358185,40.861893285828984 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark51(1.6971936442999227,38.45375994540541 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark51(1.6983796810527485,47.92421829813577 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark51(1.6989107660387552,16.429095984437012 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark51(16.989551126648337,20.33377794570688 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark51(1.6997579379466572,31.068106788460256 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark51(1.7012418683744812,44.768480758519814 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark51(17.019399321826967,29.911799696031288 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark51(17.0345340689221,26.91809545845632 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark51(17.04155712648692,32.95844287351302 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark51(17.053736430870046,18.129598285754795 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark51(17.054130432066707,32.945869567933286 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark51(17.06274238063898,32.48454374441414 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark51(17.064416729461843,22.276887924130932 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark51(1.707297257785683,11.11790737675436 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark51(17.09186825489762,29.482206170659055 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark51(17.1269858271734,31.38032462178046 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark51(17.137597379037643,25.33146777233685 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark51(17.143207017758684,32.31875913913535 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark51(1.7145419645419082,29.355457726098166 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark51(17.14778233049617,29.2081308336046 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark51(17.154216776320297,19.771158846660896 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark51(1.7177722610318438,17.547876472193693 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark51(1.7214197193786873,26.81192058421273 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark51(1.7244638269451884,48.13445326918597 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark51(17.250197631266204,28.8218208847168 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark51(1.725319259757069,9.01403780028356 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark51(1.7268593548200197,26.79480574563664 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark51(17.272346943174682,23.490327698046315 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark51(17.290591297066477,32.709408702933516 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark51(1.729616704374152,36.93531343887207 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark51(17.308416964164792,27.0639285206221 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark51(17.317106977416767,32.682893022583215 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark51(17.328188455043513,18.65596005513916 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark51(17.333585308269633,18.10943487480017 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark51(17.3357563316507,29.09744496663012 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark51(17.345065688054547,19.626006144636477 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark51(-1.734723475976807E-18,7.716881697795278E-6 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark51(17.35238380828845,22.413021760023753 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark51(17.36325003488257,32.193106814591545 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark51(1.7398613422387665,33.419855864407566 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark51(17.402225993959384,28.739101192677243 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark51(17.41618602501707,19.016665172578474 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark51(1.7421927024009705,16.043924875611395 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark51(17.446238406352848,24.577950068883652 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark51(17.447478496802304,20.429073081929584 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark51(17.465003665344796,30.376937676485248 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark51(1.7486682718284574,13.26589676029522 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark51(17.4953638397471,26.84445633011252 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark51(1.7497893101764053,48.25021068982359 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark51(1.7517119305197895,15.148330564866399 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark51(17.52672411742411,20.52908303280003 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark51(17.529079396907818,32.064213585343296 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark51(17.538130661401752,30.243138529258488 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark51(17.53988029944003,21.631544274654985 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark51(17.571967428274775,24.370223220466897 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark51(17.578967820186783,32.42103217981031 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark51(17.605363616712523,24.591878024233793 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark51(1.7635491225097724,36.74904922429977 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark51(17.637270785250948,22.29278742406416 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark51(17.643595362546776,20.60484818704677 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark51(17.651458295242577,19.970489348201355 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark51(17.658497014022018,32.00716093101323 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark51(1.7690055790232435,18.645244730099122 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark51(17.701812326212135,23.744013610630276 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark51(17.72253709355718,28.599638250766475 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark51(17.73360101148314,26.677643538437394 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark51(17.758557694963294,21.65898695582517 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark51(17.76076177527481,32.239238224725185 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark51(17.760838422745515,31.01595142949553 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark51(17.774792365198564,23.12178620068748 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark51(1.780502803947745,35.795671108666056 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark51(17.807602521059884,32.19239747894011 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark51(17.822684722761224,24.4081805312413 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark51(17.823657152610522,24.709176210875256 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark51(1.785236458435124,10.609723099770974 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark51(1.787975380518552,7.042184816526053 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark51(17.8816036923756,32.11839630762435 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark51(1.7884185846538996,35.23745571561369 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark51(17.895395064136437,26.218487857577614 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark51(17.908648715727523,18.63502889747012 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark51(17.909867286779985,19.925528111878304 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark51(1.7918980571701235,48.20810194282987 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark51(17.919889881573226,21.341865145617845 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark51(1.7923715751718934,48.2076284248281 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark51(1.792954687576227,42.246543130709284 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark51(17.93281541390637,19.232846948912496 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark51(17.939030106077354,23.06961588659759 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark51(17.9605009915618,27.979733264907466 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark51(1.7970394741266773,36.59803715401884 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark51(17.971378143709615,21.20665235210612 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark51(17.971553439575146,19.560235266049972 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark51(17.975126649940492,21.859909449503405 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark51(17.992999221835348,26.80364203689969 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark51(1.7993875003815987,29.357656904450522 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark51(18.012071260142775,18.775804032285112 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark51(18.02165392973604,31.470793512710383 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark51(1.8034182353797945,35.73611484772346 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark51(1.8042915201796834,32.912405202615844 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark51(18.05146056283877,26.768907596072538 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark51(1.8060796358724218,18.241833975479622 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark51(18.063334567562194,19.779138770828595 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark51(18.075801637611846,19.272249795703715 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark51(18.11110817310113,21.817366741844808 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark51(18.130906229265193,18.853695410849827 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark51(1.8138943597541282,23.658521347147257 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark51(1.8145782783780078,33.26381643138336 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark51(18.153953234038937,28.788031016846567 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark51(18.155406206567832,27.264992060093917 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark51(18.169521753669343,25.03150644077077 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark51(18.174629826230866,24.408027905554775 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark51(1.8174945514352228,48.18250544856477 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark51(18.17586146901644,21.212487974404496 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark51(1.8178315789644257,31.979126719272756 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark51(18.224541329333313,21.36306389870136 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark51(18.240580504805948,20.025084078343042 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark51(18.24835952795287,22.52452243904044 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark51(18.248612090542466,31.75138790945717 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark51(18.26831587147646,19.01850091557577 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark51(1.8296925542560714,41.03040340506047 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark51(18.304548630724753,27.43596669174017 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark51(18.31926555808161,25.504013817458258 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark51(18.326996740789923,24.378472722072985 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark51(18.330061853631932,28.684197166034664 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark51(1.8357952132566737,38.38557031761886 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark51(18.374149453849768,27.409094037271345 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark51(1.837426424648143,37.29534620399801 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark51(18.38467400851212,25.160987335875113 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark51(18.396380635420332,29.869658447921246 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark51(1.8415190437041247,12.88576696182875 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark51(1.8419338455968841,11.610222366695226 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark51(18.419692602737086,29.083361215651394 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark51(18.428042525494018,19.283232189368718 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark51(18.42904215408545,22.98837762836115 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark51(18.43636686889499,24.68771331781855 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark51(18.44181674631882,19.246912204427403 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark51(18.442092163065254,26.38630893442759 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark51(18.461807630068634,25.591361715840705 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark51(18.490948488727867,20.03579790505212 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark51(18.495067901226633,21.648221086953612 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark51(18.554672898316873,31.44532710168312 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark51(18.563738264653722,29.650341346138077 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark51(18.565713018795222,20.7413181263683 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark51(18.57704245022221,26.79738110786451 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark51(1.8590898271679634,8.55940426873461 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark51(18.600317889068734,24.585440802449156 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark51(18.601685884241988,26.862672681746446 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark51(18.636326960410926,30.240498833640316 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark51(1.864245374841886,47.7216692503855 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark51(1.8652030279918392,28.61236997515698 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark51(1.8652434230204307,24.632207271503944 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark51(18.668417736400528,20.53236660572591 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark51(18.675189966021307,24.58586327715912 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark51(18.67653781270775,30.748372358401014 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark51(18.67998211429708,30.32686861979431 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark51(18.700665779390782,28.44048445045262 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark51(18.72303675555156,28.870522498352614 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark51(18.73448870448125,23.52576110629181 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark51(18.74455597202342,27.90920413743163 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark51(18.749859469037688,28.88281964691427 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark51(18.75361093686439,21.189883674135785 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark51(1.876337223055529,28.317242504008618 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark51(1.8764133680782606,20.16058827135288 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark51(18.78793650073763,23.244173048791666 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark51(1.8795242645044397,47.35714408028048 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark51(18.80244512012041,30.40952105547035 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark51(18.810360428552343,29.451618459991884 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark51(18.81474303364893,26.52780040660189 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark51(18.8358494397809,29.74632739988772 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark51(1.8844945896432357,11.759367078310603 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark51(1.8860809946630042,22.352205659735617 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark51(18.872932782296488,25.422905240741756 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark51(1.8873636039511439,37.51230480878323 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark51(18.88079332884979,30.952823421983 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark51(18.906465447335734,25.682481090544073 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark51(18.91765550651047,25.16399768893433 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark51(18.929625628294474,28.081667151530127 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark51(18.94967990578644,19.699297225770145 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark51(1.8959732729295382,11.981853318482365 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark51(18.973181684854552,25.984099799936985 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark51(18.979610739416117,26.58676070736192 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark51(18.981406827997375,24.619373552939777 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark51(19.052761188119632,22.536855531926832 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark51(19.07518065954052,30.83492358147666 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark51(19.085314045676924,26.592127141502317 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark51(19.091123113422043,27.86083120932952 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark51(19.12161792418729,21.798004520652754 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark51(19.12567379836699,28.591663404408962 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark51(19.13224218829332,23.76148155731856 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark51(1.9140599535949718,15.324113481758289 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark51(1.9145750853754677,32.97380237260162 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark51(19.14663753820456,28.900685967280396 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark51(19.147442632899086,21.355080472990238 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark51(19.15204807117341,19.867930036075094 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark51(1.9153396687978077,31.711227223015868 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark51(19.16362719982685,20.112717958453157 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark51(19.167539247749872,27.70959965330985 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark51(1.9169898935498537,30.18827631343723 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark51(1.920287068037112,8.35269098323765 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark51(19.215468914840187,21.463279153203402 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark51(19.23661402237501,20.250632064780014 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark51(19.237380479791,24.088026854744427 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark51(19.24135591724084,23.77367212082207 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark51(19.275621651754477,29.255701817700757 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark51(19.283235403152375,19.984799651380747 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark51(1.9293925901371551,12.887104391386035 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark51(19.32179867517341,30.476493923653038 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark51(19.322955845702644,26.185430928446095 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark51(1.933785711120854,45.1677577602066 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark51(19.346200885629486,30.059526572266748 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark51(19.378488861028927,29.416499311438116 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark51(1.9392559395727424,32.34793525173063 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark51(19.397290755902304,29.642760924108956 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark51(19.4194377508812,21.347438184162783 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark51(19.420524110593803,25.21856712819679 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark51(1.9433324744863256,47.62589286050178 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark51(19.465058389673864,25.108546497014604 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark51(19.472572165567342,20.166189211718414 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark51(19.474243728989833,30.525756271010152 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark51(1.9475727119604045,41.483102663171394 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark51(19.47946763737221,27.595161907233976 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark51(1.948281906441963,20.461007831848292 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark51(1.9488748323239093,40.65590299213727 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark51(19.499282941124818,27.537359685136906 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark51(19.500664965070897,20.209705743808147 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark51(19.501404027225846,22.335100071715175 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark51(1.9516580687256777,31.03498940438675 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark51(1.951713871767577,31.33087910406806 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark51(1.9522816645130234,32.528270865443545 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark51(19.55016984974091,20.24109736822523 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark51(19.56691825676529,23.213040258525325 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark51(1.9587688478481846,47.39948208313659 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark51(19.590718342749362,30.40928165725049 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark51(1.9598549040148239,6.294959467335982 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark51(19.614084948801384,24.58712084954155 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark51(19.62143100993137,21.140558608497287 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark51(19.63701219674367,29.34089452916558 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark51(19.65630611037558,29.709915803686812 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark51(19.656565989298414,22.719533224031778 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark51(19.66615992248728,20.361124242008497 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark51(1.969296051880346,27.44144130420179 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark51(19.694190802328592,29.444615040811385 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark51(19.700857526338652,21.15276466422603 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark51(1.971851776179804,18.051452049674268 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark51(19.74404923551056,23.952759197543898 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark51(19.754036750447085,30.245963249552887 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark51(19.758734372265828,21.38794631779007 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark51(1.9772716889994968,44.71484773514595 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark51(19.784474533740152,20.570189178510176 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark51(1.9786761884110717,38.877993036432684 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark51(1.9791901878264468,21.836885448834707 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark51(19.794600163701787,24.17401075395314 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark51(1.9855846385699731,22.156846004150196 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark51(19.858684088735526,24.885332867392158 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark51(19.882981464187814,30.11701853581218 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark51(1.9883008115199772,42.0521764065783 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark51(19.898160523822582,27.531767127768834 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark51(19.91079169643761,29.044829476262375 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark51(1.991280910946493,48.0087190890535 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark51(19.91294427980654,20.693407041267925 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark51(19.93646806439935,23.409434088725817 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark51(19.9589876663171,21.666330331173782 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark51(19.970260177781867,27.001631876014727 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark51(20.024698860063978,23.38940136133509 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark51(2.002561637932885,8.231848312344312 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark51(20.033289480823285,26.492380900182177 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark51(20.037786333036323,21.48401586386528 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark51(20.043073447827624,26.10983818931254 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark51(2.0084515333979027,33.4208196288875 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark51(20.087792767469324,24.003154594510207 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark51(2.0097532699042198,7.709275095568456 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark51(2.0126022772972902,29.83771894528769 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark51(20.154246444268836,21.58464149312303 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark51(2.015457477524193,6.965074729759493 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark51(20.157085390550165,20.85817814007011 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark51(20.171188700515458,26.707089833588398 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark51(20.17357878413391,28.89099091682985 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark51(2.018029228609848,14.023807817493037 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark51(2.0183356860652597,12.447089424890478 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark51(20.187112016622294,29.04824895945802 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark51(20.20192604089243,22.222289725886128 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark51(20.20880411619919,21.774032527297948 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark51(20.235233585985803,21.590688895133 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark51(2.0240963798809446,37.056897998024766 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark51(2.024836787227043,9.957857273597767 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark51(2.0286815934334808,14.658598376263264 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark51(20.304788567954315,24.67196281065021 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark51(20.312245168425875,28.85699794564124 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark51(20.32041012051873,27.331740721936825 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark51(2.032248350707359,23.123368724137165 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark51(2.0326916552748457,11.153191514682376 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark51(2.0345215617017116,23.14105837719093 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark51(20.363246951081127,27.8469957482055 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark51(20.37765141260352,22.44439827166231 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark51(20.382009186800488,29.6179908131995 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark51(20.384884152389077,21.40813170049526 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark51(20.385776217645258,22.64122369301937 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark51(20.38727940099017,21.685551069511305 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark51(20.420433039186904,25.43622329078012 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark51(20.430476262541347,23.623309386633593 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark51(20.442553713030208,22.4185824188111 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark51(2.0456885077013,22.955349840598032 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark51(20.496852021492728,27.103066870128156 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark51(2.050118610475554,34.977404878415 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark51(20.526848841279808,21.57747858333932 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark51(20.531400003114314,23.966835417786726 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark51(2.0532128902415394,44.561405061229266 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark51(20.549499061455805,26.003790802631244 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark51(20.553992687799006,28.329408540203985 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark51(20.561141809521487,25.260795404839456 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark51(2.0571595682711017,21.601904986539637 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark51(20.579409517451925,29.420590482547027 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark51(20.58558015650935,24.741037630661513 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark51(20.599042492371893,22.822153373452863 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark51(20.606086075763315,29.393913924236557 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark51(2.0627720593010217,18.72487248322779 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark51(2.0638360401940474,44.57380441835576 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark51(2.064620826433515,41.62505981818751 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark51(20.648330515514004,24.771348988893436 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark51(2.065384754446285,23.35510983508682 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark51(2.0658177722555378,20.86081918441927 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark51(20.685300174366475,27.912035810602447 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark51(2.0705195759614696,31.389362994778935 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark51(2.0711190655009943,28.44763172794248 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark51(2.072841543596752,8.524539803498229 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark51(2.0776216477592158,33.272343124903216 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark51(20.784007574028834,28.69173573064191 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark51(2.0798715347350214,32.328402235485015 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark51(2.0805753006521535,17.91332891308855 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark51(2.0814934319243132,10.900400527449648 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark51(20.8771878862905,27.969060580702603 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark51(20.91539029294242,28.25360189453997 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark51(20.920666442097385,29.07933355790239 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark51(20.92973640271451,25.356009198816068 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark51(20.942538104577217,29.057461895422776 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark51(2.094807576817275,47.00627815918277 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark51(20.960904350904002,21.62751465100141 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark51(2.096439451987166,24.580828104471834 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark51(20.98520913496661,25.45620685201329 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark51(20.990290000917213,26.36153324143082 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark51(2.0993646759876157,13.994643812607748 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark51(2.100280125030622,35.19229274714323 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark51(21.010377825867902,28.989622174132023 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark51(21.036371219715612,28.963628780283074 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark51(2.1043147710567824,16.388699044074315 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark51(21.04825193399111,24.513095875217545 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark51(21.071047514056644,25.16975727776716 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark51(2.1073621616398155,18.435705456365742 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark51(2.1090205246186144,20.790787729360318 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark51(21.095339078962514,23.274731236569618 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark51(2.1113426282689716,13.084089031202666 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark51(2.1125496891742017,25.130452254131058 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark51(21.13529634692877,28.237237511199595 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark51(2.116042015199369,41.22957666804004 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark51(21.20307002311681,27.00993082193972 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark51(21.221173709896306,23.112068946378514 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark51(2.122835476639878,23.627252368199606 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark51(2.1229308586397053,36.158000164548895 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark51(21.252261729702965,25.002626649585878 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark51(21.25514777098529,28.744852229014693 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark51(21.2740946281517,28.430911673125195 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark51(21.28760361255268,28.712396387447257 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark51(21.29728890427907,21.972002754011726 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark51(21.33386887042961,21.99408827662083 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark51(21.334134948786797,28.665865051213068 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark51(2.133724344933227,32.30410226186987 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark51(2.1355012616470717,41.134375375586984 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark51(2.1360947389762917,41.15820474590902 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark51(2.1366457324718056,7.301026355317219 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark51(21.373918845376025,22.04041847669542 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark51(21.37967017738376,22.08137822188057 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark51(21.399912100255307,25.44406388644917 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark51(21.410744322598465,28.589255677401525 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark51(21.434515316109696,23.188714473920854 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark51(21.438986716663806,25.547763580570603 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark51(2.1451855577830017,39.94475637535791 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark51(21.477941888997115,27.11193254752898 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark51(2.148463161978529,6.878994993037324 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark51(21.48525430458912,28.514745695410866 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark51(21.528039520824244,26.557608898895808 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark51(2.1549278607289466,13.506126994033949 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark51(21.55265550942574,28.447344490574253 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark51(21.55510160341882,24.323435238037888 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark51(2.1587266577371906,13.057092506751331 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark51(21.59056141303691,27.757864774621893 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark51(2.159138916073154,28.736104753317164 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark51(21.614119346041804,27.240489723026684 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark51(2.165834609327618,5.851058119663406 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark51(21.713200201147657,28.286799798852257 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark51(2.17502737407375,13.667275203590805 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark51(2.1758621195238987,9.185564627600115 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark51(21.75932091960685,28.240679080393136 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark51(21.770322155017148,22.50420282250873 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark51(21.787989986938463,28.212010013061047 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark51(2.1826782682474004,47.32987424267108 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark51(2.1827708245429207,38.28632494850996 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark51(21.83754630171171,23.35373825400498 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark51(2.183857890063808,18.095377581635894 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark51(21.84746714293368,26.49191657842482 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark51(21.863029908395532,22.83271089080877 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark51(21.867602016446554,28.13239798355307 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark51(21.87714844937416,22.537448074405155 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark51(2.1890786108063054,23.43086115692286 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark51(21.918709760861816,24.361311560234427 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark51(21.93738955991566,23.541688537266523 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark51(-2.194735547011815E-34,0 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark51(21.947485767741846,28.052514232258147 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark51(21.965577173895582,23.710264001669472 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark51(21.96920419108133,27.190536647620902 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark51(21.97578486137246,24.0489178806381 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark51(21.983196691991466,24.012334342339315 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark51(21.997131252375084,24.11125930197204 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark51(2.2002349831430195,10.447361464136563 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark51(2.201337520600461,24.808546924759597 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark51(22.063495215499245,22.749185020024562 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark51(22.09542687210984,24.667024764013874 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark51(2.2097653244274227,25.45057166979805 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark51(22.098709738517613,26.079758106218833 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark51(2.2152363726256112,45.61979594407845 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark51(22.176917499803196,27.82308250019669 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark51(2.2182820623207067,47.78171793767929 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark51(2.2187167620667907,47.279475823190865 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark51(22.196993238277926,25.08323553981743 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark51(22.228964006482695,27.771035993517298 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark51(22.23774667565644,24.143358308414832 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark51(22.245698300311176,26.59513114852193 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark51(2.226466117127714,11.030748369001046 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark51(22.26956470358705,24.465442345640895 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark51(2.230714652695667,38.38716180414136 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark51(2.231171312246147,33.62767505607255 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark51(22.318108564921808,26.27889862342252 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark51(2.2318558019827837,9.92101042766879 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark51(22.329356444284958,26.530741028298024 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark51(2.2333132946168606,16.087053160982446 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark51(2.2336317823050393,18.98988213621118 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark51(22.34632696799774,23.009948121708852 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark51(22.346382689075313,26.78693909617462 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark51(22.40245540613484,26.249369119384443 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark51(22.403936607952886,27.596063392047103 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark51(22.44050031598006,24.129659068994087 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark51(2.2450146269282385,38.318997588016344 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark51(22.46411855364713,24.464002398006578 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark51(2.247099578993911,35.18115367421515 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark51(22.555315578338064,24.957781667378896 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark51(2.2562568607935134,39.578029940410744 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark51(22.574479448256213,24.809162811934343 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark51(22.677321010877876,23.533779033888052 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark51(2.271570270333994,47.664907318444065 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark51(2.273509131528783,6.897028248982934 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark51(2.2742009359319297,9.059676984678887 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark51(2.2754289958706693,18.243992957914102 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark51(22.761767278936773,23.401234552520968 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark51(22.771867249157495,23.4610621038714 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark51(2.2787916937189587,47.721208306281035 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark51(22.800799079863694,27.07153964818085 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark51(2.2829599547780504,23.75694341871423 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark51(22.87339518488519,27.126604815114618 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark51(22.90609882070295,24.68064921544797 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark51(2.291407966600019,26.801437806750144 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark51(22.944191857069313,25.409188330042113 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark51(2.298498120053736,11.872621616507757 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark51(22.99484862081063,23.784980561811864 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark51(2.3002831658545944,34.78770386396292 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark51(23.02095968798641,26.080567662501636 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark51(23.04249355068852,24.209634219796 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark51(23.064716503630976,26.889360793338845 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark51(2.306628467502364,22.444098626442724 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark51(23.109199566726957,25.67417179137325 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark51(2.311762349372941,31.089886105776827 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark51(23.1189972439698,24.20989372953703 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark51(23.125872004419023,23.791020370840748 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark51(23.13738189350856,26.363977381425244 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark51(23.157095277159087,26.842904722840863 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark51(2.3165815837863875,13.638264078609126 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark51(23.210914281507655,25.493717588122706 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark51(23.25017976493325,23.892471762305327 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark51(23.2998523119752,25.96719429969332 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark51(2.3333664028398573,15.44529927174672 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark51(2.334925894830647,42.81366670891828 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark51(2.3470002274684703,16.792360472655886 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark51(23.473320393892543,25.245416566324945 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark51(2.3475161624149337,6.242261186367955 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark51(23.494750554504378,24.97464559399316 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark51(23.49773730613404,24.44668274830741 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark51(2.3512257090040407,45.046686395331164 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark51(2.3553242348438683,10.089743852484872 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark51(2.356899806679383,33.97669062337033 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark51(23.604681116431777,26.04232485442186 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark51(23.60577561311817,24.288402010395608 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark51(23.613702767840252,24.31311461877607 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark51(23.62196066344393,24.931293705459723 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark51(23.63547987280363,24.283408606162766 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark51(2.363967428027383,29.39848408867337 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark51(2.3657944047891597,18.83135140531898 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark51(23.70845008897442,24.342426501192595 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark51(2.3715703739459144,44.63441850592213 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark51(23.728225916462286,25.338482906570192 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark51(23.746167213517523,26.151596178595682 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark51(2.376771428991759,8.711318746230784 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark51(2.377624278188459,43.54177531551338 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark51(2.3785849309486906,5.312776326083693 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark51(23.822580188234838,24.538507098237176 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark51(2.3860003839775175,44.40640304129772 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark51(2.3894276021547345,41.675687501936494 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark51(23.93409974609186,24.555557085504635 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark51(24.003582108939735,25.921681391492186 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark51(2.402860513796014,10.496860163099058 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark51(2.403880559009978,21.290688201696057 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark51(2.4045574022854375,35.66530181109903 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark51(2.4056412058621106,17.53013335852323 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark51(2.4066702135253166,33.123919821221676 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark51(24.0754562032224,25.880192941477446 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark51(2.4088590461446984,46.5235565032564 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark51(2.409791036965559,11.03379219784728 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark51(2.410463957562527,33.36030361676555 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark51(24.172744086900224,25.5136028125509 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark51(2.4174628934228366,35.07463321814117 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark51(2.421250711041651,22.973875020620113 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark51(24.2302274821429,24.85809267299174 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark51(2.4238426886931137,30.347611215795695 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark51(24.24746841621631,25.587943606540506 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark51(24.25054229065175,25.297714201247132 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark51(2.4251303844887113,38.7160972588264 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark51(2.428802986762264,21.518595554307552 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark51(24.29700068832217,25.63238832993156 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark51(2.43242715623569,7.3924668399130695 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark51(24.35829392663271,24.973887733329203 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark51(2.4374741513133564,34.76839211919882 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark51(24.4263048615903,25.184819142865653 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark51(24.43659412334705,25.080569579919878 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark51(24.448531992508997,25.551468007490996 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark51(24.5705705652487,25.183573901822136 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark51(2.4572258264943514,34.730495220679785 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark51(24.577854411045976,25.42214558895401 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark51(2.463188677101379,12.62437912476588 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark51(24.65508816495778,25.344911835042197 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark51(2.4668996907754277,35.98460583281674 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark51(2.469860490882226,19.410060629877606 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark51(2.471518024411882,30.427295142952186 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark51(2.4760802776479665,13.453574531444772 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark51(2.4811926877230235,24.23214573483898 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark51(2.492605178360435,44.354722649637466 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark51(2.4934012206407488,31.29289096076323 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark51(2.4949674598542515,11.171781973925448 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark51(2.496024589319859,26.65603799459781 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark51(2.5051166983899265,22.94834630114066 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark51(2.5150921772538055,46.3063720314677 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark51(2.5188865601480046,32.841232742665966 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark51(2.5192658912079002,47.48073410879209 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark51(2.525525448454772,32.29103276397046 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark51(2.5256303254223544,35.606408025109694 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark51(2.5273011482787524,17.016446119881266 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark51(2.5286975915036294,31.51319899354067 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark51(2.52953124154367,13.161959715875241 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark51(2.5297119195089266,40.318699277816506 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark51(2.5302712269121628,29.709036309838865 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark51(2.53153069254914,22.450122923743237 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark51(2.5330886926935676,26.848782351406562 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark51(2.535836800114973,41.668362559370365 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark51(2.5456083702650574,5.910303228982656 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark51(2.5464202585001203,17.233510613192763 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark51(2.54751489042974,37.822762039199745 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark51(2.553300530972203,15.571014096115714 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark51(25.549027075076765,72.84946455596332 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark51(2.5607442621317418,11.952008323212524 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark51(2.5619733903391344,7.708812131750079 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark51(2.562128475445075,7.55680512689554 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark51(2.568493486738367,5.714064460911276 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark51(2.573689866708534,25.560292896479538 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark51(2.5767590793961404,5.6973994834058175 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark51(2.586992810565363,9.67587051399488 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark51(2.5940983447341353,21.419239231687826 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark51(2.594113053766221,23.041416400193064 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark51(2.6062938416878865,37.85584066433418 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark51(2.608608531099094,11.593539016531352 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark51(2.6100714552582076,16.0113684660513 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark51(2.6103200199920544,46.702949776737235 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark51(2.6134848777084017,34.17854938425663 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark51(2.615171421921332,37.59186009303784 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark51(2.615402893839848,24.089880465951424 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark51(2.6171172624940233,22.88023431093142 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark51(2.62158677595923,6.665636967095253 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark51(2.622950835983872,16.705160880319553 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark51(26.253514763078087,63.67266724880511 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark51(2.625654002043607,43.876807624153514 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark51(2.6300336595654414,6.980235573896351 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark51(2.63076876872519,24.840010298302545 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark51(2.6338360858561622,45.93364571627566 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark51(2.6343181481718716,19.542038908020643 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark51(2.635771737522134,6.417160751797567 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark51(2.6384331837848474,5.8278619087970664 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark51(2.646681072744599,36.39978169612175 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark51(2.650965809504285,38.04971193585462 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark51(2.6595518552563533,18.490504826505628 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark51(2.6642575434556903,43.141448296906646 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark51(2.6689830782898696,12.473611873103806 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark51(2.671244293340308,8.536758347147384 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark51(2.6812723618925194,36.17810593384854 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark51(2.6858857963261755,31.55745227481765 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark51(2.6905539525236186,41.18775669174008 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark51(2.693564465936319,19.068627502290127 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark51(2.700628094792833,10.919233859426498 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark51(2.7077423706631274,33.32486833385943 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark51(2.7113261743935517,31.2372401726374 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark51(2.7145295450889257,42.651348725610546 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark51(2.7168508144762002,44.88233375072665 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark51(2.7191675279893985,6.6605407822166 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark51(2.7193990318752412,41.3378816401098 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark51(2.7211957646014753,15.964072304836634 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark51(2.7217449006845698,45.008064685717045 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark51(2.7330036327931992,47.266996367206794 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark51(2.7542160371464632,37.94693548777431 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark51(2.75430014982787,36.4477894727801 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark51(2.7620265149484595,47.23797348505153 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark51(2.762441777915214,12.927894904460643 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark51(2.771595173446755,18.635870434259687 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark51(2.7726972216035666,5.2523856139905085 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark51(2.7766575036971144,34.49375368673026 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark51(2.777768028271435,36.73220810242027 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark51(2.791610538503697,45.60858315856711 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark51(2.796674182432099,20.588726922616445 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark51(2.798007406075775,28.92001144895417 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark51(2.8057866612085913,47.1942133387914 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark51(2.806648693982993,43.8282433602632 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark51(2.807285815598931,26.3559059483121 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark51(2.8129434454662814,6.163861454493613 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark51(2.82454768689652,15.075390686391108 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark51(2.8250795837337677,35.993860405236035 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark51(2.826962852895477,18.625978039572615 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark51(2.8345168804994216,29.35317586147181 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark51(2.837640881927811,13.582179990818105 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark51(2.83938122550056,35.25115447018129 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark51(2.8432316113515554,17.704079018016515 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark51(2.844737744585558,5.931268264850871 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark51(2.8457980377762513,44.48689801982158 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark51(2.8474385741818082,47.152561425817844 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark51(2.8500793205604564,14.995592303164614 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark51(2.8552033508001706,13.099911831813756 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark51(2.8572735391011275,9.247185552021662 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark51(2.861117985580462,6.493351788526098 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark51(2.8627775265538986,22.576974786445156 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark51(2.8659670149777856,12.757262592172552 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark51(2.868412534361582,29.32720939233883 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark51(2.8691419037798056,40.89404213081366 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark51(2.8713721774656173,39.83801112857238 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark51(2.8766735058221684,11.145413232475647 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark51(2.88299055475854,12.308057351342008 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark51(2.884496512556666,42.05871097259404 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark51(2.884704295742459,30.892692445563114 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark51(2.8914718070497187,36.797298696326266 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark51(2.911042035092464,13.999302132966022 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark51(2.914196147320374,45.557890166331106 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark51(2.916473184530711E-4,1.6561688457832898E-4 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark51(2.927121105055079,32.16923408527876 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark51(2.9287701112412265,14.310685112063197 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark51(2.928809247457238,8.34731603120622 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark51(2.928985616858398,10.815429551931217 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark51(2.929480667402574,29.913317076322308 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark51(2.936637364848721,40.24227704636843 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark51(2.938762322696867,43.635224672648974 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark51(2.9475857184870335,24.63263352689333 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark51(2.9479446276213537,38.74526836264309 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark51(2.948381538184222,19.515054457637987 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark51(2.9486231649674295,29.75248914592828 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark51(2.954683953755577,19.596105771921884 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark51(2.955137286430695,9.929131520782562 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark51(2.956947012169266,35.443849344661004 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark51(2.962196316054123,36.911062644172176 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark51(2.9631050011095397,46.327674102835374 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark51(2.9672248221990416,14.628163935846388 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark51(2.9698243596962755,30.194699283250884 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark51(2.971261659974786,42.47691390666321 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark51(2.974374973058179,18.206319833979535 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark51(2.974841212332919,27.177430100978768 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark51(2.976529093837698,10.459267321725036 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark51(2.9791897816308364,18.79175100315919 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark51(2.983662190996043,20.919405278039264 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark51(2.986641865253315,35.514532256737766 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark51(2.988459053804206,16.378447508529305 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark51(2.994804338397941,27.64523946813557 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark51(3.000170451450882,31.950859421637773 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark51(3.0027642772322327,46.739908385141746 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark51(3.0220328334442694,35.26979236303574 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark51(3.026923806205417,17.13038357400191 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark51(3.030719510431407,37.54744113740347 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark51(3.031162994829245,19.994825403848623 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark51(3.0314698552137855,35.46044624734236 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark51(3.0366781756380306,7.086599462636917 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark51(3.0476822798070105,26.677641723186497 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark51(3.050165931832839,8.024804625773763 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark51(3.0587196802650567,44.500988505733886 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark51(3.0617443012696217,15.620022151248634 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark51(3.0725927242259816,35.12222792098072 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark51(3.079239594712634,18.308320132935023 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark51(3.079546275277691,13.026300905616168 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark51(3.0800261868048313,6.141948405438199 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark51(3.0814516641460443,15.413957768372399 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark51(3.0838492640933026,14.078512745383449 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark51(3.096713646987496,17.354352990373798 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark51(3.106116545890368,37.01755041474604 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark51(3.1170822887039265,36.681916319857976 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark51(3.121445066814225,46.87855493318574 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark51(3.1237724786765,18.696607358408414 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark51(3.1377379199206246,6.477169821415927 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark51(3.1411035914304932,41.40709773616382 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark51(3.141513719871881,6.3299715566984105 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark51(3.1456945254494,13.26957194200098 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark51(3.16425643147511,20.610536255147593 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark51(3.17774680549399,45.88020059305998 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark51(3.184122381971548,12.237492912426305 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark51(3.1873338008028753,34.437955874442764 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark51(3.199897706972493,19.974843036338257 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark51(3.202457117096742,28.77694255624084 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark51(3.2031859751921985,30.549218959032828 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark51(3.223312437710357,46.776687562289624 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark51(3.233803591776791,38.557912209144234 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark51(3.236114213128406,25.12831995614934 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark51(3.2370417359088197,45.0496439525798 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark51(3.239392596477046,7.305979683649497 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark51(3.245451954075456,7.590560428530438 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark51(3.247610544931703,39.913665919426535 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark51(3.248240577204669,34.92929347486296 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark51(3.2492027312596576,32.40976773436415 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark51(3.265848044082901,35.37683760499536 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark51(3.2669227529806206,40.28361865014435 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark51(3.271298457170639,16.925713582130605 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark51(3.27451397997109,44.78607218425026 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark51(3.2822535039439806,46.71774649605601 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark51(3.2853386547282284,6.608980704859274 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark51(3.2878797145367953,7.840184607867997 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark51(3.2904593345094,5.892306722009934 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark51(3.296076191747545,20.766890110959267 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark51(3.301200055939745,17.586915672520846 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark51(3.302729594852174,17.682553717540667 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark51(3.310128281626163,27.964599055253345 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark51(3.3101426945558075,18.469209998740695 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark51(3.311251601358279,28.33470473562403 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark51(3.311553256082476,7.187449153160301 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark51(3.315378384802287,37.6112097744936 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark51(3.319335914369674,6.281012028568696 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark51(3.3210596926578635,6.0488307679507045 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark51(3.3246314364503506,26.19057298255909 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark51(3.326928947387284,10.252383205126621 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark51(3.3288181376035597,46.313185197602536 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark51(3.3292208835425328,8.301224002138923 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark51(3.3306986976170663,19.324208740593733 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark51(3.337528984832801,26.149504297918952 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark51(3.3379618206273136,11.434063146003934 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark51(3.3439433153957765,21.583657715483653 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark51(3.3440415241251316,9.521655655604548 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark51(3.3498807718775634,7.724135920418828 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark51(3.3560950730739023,15.683967137743139 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark51(3.3610439082364563,43.36722116449306 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark51(3.3661104742828307,41.07217818118091 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark51(3.367828047346194,9.559610029349571 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark51(3.3781099640039614,46.62189003599603 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark51(3.3825187225487525,33.00256485350329 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark51(3.3835878248778304,46.61641217512215 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark51(3.3874795172024648,21.48320814859727 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark51(33.89073538130296,92.58272373366412 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark51(3.391494312062875,31.690587676105366 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark51(3.3936423569640226,29.92440999016611 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark51(3.394378751594017,14.90526439865717 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark51(3.394834410078701,45.9806940622108 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark51(3.4000734177054284,37.23954518641645 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark51(3.401336264802501,5.6547420584945485 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark51(3.4016361291945145,23.1486225814555 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark51(3.4023107610162437,24.124340718534878 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark51(3.406469564034566,42.38180878108912 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark51(3.4077146149288406,46.592285385071136 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark51(3.4131973816282226,15.714201310200309 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark51(3.416227536071826,32.96357352688878 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark51(3.4210620130014746,37.984925486113184 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark51(3.4233810637515916,9.176932935516561 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark51(3.4244392173916793,25.459899728627633 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark51(3.4305689813893556,23.25949976996995 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark51(3.4326502376834185,17.203324733802347 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark51(3.4332863447651363,37.75865697610854 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark51(3.439413131527317,21.860543651706465 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark51(3.4410632639105216,34.73155636433407 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark51(3.445001505288303,18.34853740556821 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark51(3.449763647720527,22.41875191937977 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark51(3.4603700951370513,23.475051939488154 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark51(3.4617932483465506,23.852283644526025 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark51(3.4620206583948203,42.104111349741856 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark51(3.480642461147461,36.31630383174309 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark51(3.4857478969095865,14.630424301672988 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark51(3.4867109734841364,8.613790849526808 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark51(3.4893124630600596,32.123241672972625 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark51(3.489507804044834,10.79058876712169 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark51(3.491386926008005,15.971642965046826 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark51(3.4976037683778003,17.602234525481435 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark51(3.505885267087322,45.112642118149324 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark51(3.5112639098524774,26.3809599197766 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark51(3.518203480964684,29.605766200287814 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark51(3.520239853768942,20.923071257374247 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark51(3.524853315259733,39.033625904404744 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark51(3.5262702879566916,29.104276227377056 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark51(3.530816860651001,40.691301198622796 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark51(3.531645994106853,43.200133913032175 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark51(3.532937112560411,46.46706288743951 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark51(3.533745743728531,11.454824754384646 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark51(3.5378776465317783,32.54320823311744 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark51(3.5402457444001527,31.849759734532057 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark51(3.548128186863954,17.129006491184875 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark51(3.5554357157157916,46.44456428428418 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark51(3.5594958783880823,6.50187494453961 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark51(3.565940526402045,13.569438928094186 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark51(3.5732645790497344,24.416274062979085 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark51(3.5830586531753,6.468083441016148 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark51(3.5863425318249966,25.32108385668947 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark51(3.5914576889348666,21.542554206360748 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark51(3.5938266396793246,40.633691473218164 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark51(3.595774221876462,46.40422577812353 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark51(3.5981776465118336,24.540894091485697 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark51(3.602448523108137,30.70495837404158 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark51(3.605181764698372,5.739786642785518 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark51(3.607395725839801,7.438660511320833 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark51(3.6135924438451426,29.758999801530393 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark51(3.614654914678411,36.285572178255535 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark51(3.6165146799601082,32.10484767903526 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark51(3.6169907815573055,20.071996567065085 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark51(3.6175311076350996,36.27300868905037 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark51(3.6261348822336146,29.475239033622813 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark51(3.627111066051617,28.316018846797405 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark51(3.632106678377454,24.752746569286302 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark51(3.6402796270245394,6.885142971552609 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark51(3.641724224902539,18.019972128960646 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark51(3.6526556542483473,21.826752095010235 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark51(3.6529479023552227,44.345691057964416 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark51(3.659946546038313,24.84205882400417 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark51(3.679586900462332,11.326085948951889 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark51(3.6807775410255203,40.212615057854464 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark51(3.6850732948733764,9.011328131083943 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark51(3.685962004378027,27.68142315302744 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark51(3.6925127243110154,32.46228118769784 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark51(36.96118995600355,91.87018783985292 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark51(3.696702247454919,46.30329775254506 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark51(3.6986277907041307,8.531351627402046 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark51(3.699197611156791,35.24908489368758 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark51(3.707090588076923,39.47375073871348 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark51(3.714389776574226,26.064031200822235 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark51(3.7154008150757285,26.487789028764766 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark51(3.730896656942747,10.068814830218884 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark51(3.7351643823660936,23.021704832025364 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark51(3.736463293050022,37.452438572211776 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark51(3.7376898654208537,32.58981029653856 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark51(3.7447940194504525,43.321235097266424 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark51(3.7526406793598994,17.94903672893784 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark51(3.7527279693236846,43.51340886238239 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark51(3.7636048047407797,45.886052041277594 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark51(3.7643704069489523,24.54836236501447 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark51(3.764521197256414,28.344866532540237 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark51(3.77313723540734,30.19187774340685 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark51(3.7764826365287014,46.22351736347129 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark51(3.7841063396121086,34.520674076516514 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark51(3.7848081876811186,20.876850220158595 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark51(3.7884460514032696,17.120247313479183 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark51(3.7945597771040127,17.86686772127564 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark51(3.794569830453895,9.926131345276872 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark51(3.799264188440503,33.07224371590095 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark51(3.800111585280348,39.13467222102463 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark51(3.800251700191623,44.194675589037786 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark51(3.8063599482666035,7.862954611964582 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark51(3.8085275965820955,39.1182074778483 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark51(3.8175694892042458,34.84705536994116 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark51(3.8239153056754134,33.22300659110624 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark51(3.827082054823137,33.65246688452021 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark51(3.8330316649319265,15.980237738307451 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark51(3.835351823170072,16.21594752363984 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark51(3.8357870493658766,28.133723904916874 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark51(3.8395040780449294,22.374714331926256 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark51(3.841755652528926,46.158244347471054 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark51(3.8524053198214006,42.647151069893425 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark51(3.8542614099985997,11.571164246385734 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark51(3.854882024921455,18.233715097841845 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark51(3.859634365379378,35.59285371177583 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark51(3.8632426717577744,13.057301459427677 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark51(3.863598926819108,35.5521356284991 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark51(3.869238664087706,8.99269115372418 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark51(3.8738642277615725,8.465163806489429 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark51(3.8755917509270876,32.65210131711183 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark51(3.876138418779604,9.774223672086464 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark51(3.884639613026607,25.45833677204996 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark51(3.8967766379117457,16.02819563602428 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark51(3.897964610146662,28.180613412789214 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark51(3.9049546512917885,39.171059985010714 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark51(3.9102700447449763,31.26843921209874 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark51(3.9104446642599697,43.72459731282936 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark51(3.9155994270506653,22.422206398415696 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark51(3.9168319487929466,36.64036665363005 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark51(3.919607361366033,38.909064760825885 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark51(3.920273651639434,17.45472254867788 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark51(3.921282007193369,42.82560801863485 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark51(3.923383144001207,39.52595513286198 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark51(3.9263740902166973,13.25817877003405 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark51(3.934814109344245,45.39382223466407 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark51(3.951259506400831,42.92662405056279 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark51(39.52484210936649,7.144836835459117 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark51(3.9561043565652767,36.89176978791056 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark51(3.9595569809713,18.928059882624765 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark51(3.961354344445759,7.863473678752555 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark51(3.9626071985275084,46.03739280147247 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark51(3.9648423827913177,20.45958316889616 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark51(3.9686219861464718,24.659261965881058 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark51(3.9728836241343686,30.769175828322915 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark51(3.976743788071472,14.849589416009533 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark51(3.980114807851649,12.52858818341926 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark51(3.9830908300805348,24.272049367944533 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark51(3.9854521683221416,33.3039328316716 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark51(3.9905393532621183,23.688436980691147 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark51(3.992010715039509E-14,1.998001680439611E-7 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark51(4.004502124459464,30.24976687464084 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark51(4.0072762283141685,7.4246494740757925 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark51(4.020073146510182,12.029249591206938 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark51(4.031154917448404,36.07181854705976 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark51(4.031974368643631,40.492054201668964 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark51(4.038197092196749,7.880933375133651 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark51(4.039731194508931,26.73177526853479 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark51(4.041218850834639,26.657987823745913 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark51(4.041867893787723,42.79678414408673 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark51(4.045433036994623,15.280614733969486 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark51(4.046379017320996,15.893856771403726 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark51(4.0518502312392926,39.156334053546175 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark51(4.056310502427969,10.185360016093032 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark51(4.063994824043961,14.813568375351421 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark51(4.068324766437769,38.19043820495591 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark51(4.073477791019968,28.343542395349203 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark51(4.081516911884648,32.46870334564181 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark51(4.081893556577569,19.72997779333689 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark51(4.092461685532541,34.243091347561034 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark51(4.100308631499772,15.657326840315932 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark51(4.11315012111055,18.369910864895544 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark51(4.123985772148263,45.876014227851726 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark51(4.133690681551727,43.6642405961113 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark51(4.137952356219188,18.5903058494348 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark51(4.1390640467031155,45.03174931921038 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark51(4.139601115364268,45.86039888463566 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark51(4.143287583919374,16.690192485374823 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark51(4.144116635460065,43.968967127704985 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark51(4.14523267066069,28.4582418804153 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark51(4.15223109648413,27.064346791381723 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark51(4.16488964164445,44.26294778739975 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark51(4.165622204597369,16.658262722036625 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark51(4.1698564963595,43.33439096989147 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark51(4.170249470747535,36.53023213512765 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark51(4.174110302309003,13.83038449571967 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark51(4.1743117157496386,12.130286525798116 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark51(4.17742713930005,39.030258560667534 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark51(4.179227288570189,22.495504291828922 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark51(4.179237984532875,23.404418463150733 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark51(4.1798443468496345,12.27390407215718 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark51(4.182328002223114,10.830779808717212 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark51(4.1893772633723785,38.62166209937675 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark51(4.191667108342292,6.154373827389193 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark51(4.192534416217725,9.699852975208628 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark51(4.196786320046968,45.8032136799529 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark51(4.211085851600373,28.797575515493747 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark51(4.2152626463482035,45.78473735365179 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark51(4.229998839591701,29.95818662638149 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark51(4.2316997021623735,25.52582045921841 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark51(4.237212718420976,8.611598375759215 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark51(4.2385452285238046,23.011607603256067 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark51(4.243005560463459,17.919858916874773 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark51(4.2437341814172385,25.87111941348455 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark51(4.244319196406039,23.763533445074202 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark51(4.244548360271594,8.392240832470364 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark51(4.2460120165224,6.32186991376696 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark51(4.252874162955152,33.49634557859875 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark51(4.261755556189575,38.17657451783782 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark51(4.265197651107243,29.54079590700661 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark51(4.277113325473131,8.2517867755882 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark51(4.283948551229258,19.525519593318293 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark51(4.284393086960449,44.09322179509502 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark51(4.284436087962023,19.20856884058739 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark51(4.290808323104827,40.298982491137735 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark51(4.298454868108763,42.84231512244557 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark51(4.302434391898743,43.62708718391005 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark51(4.309618321204795,8.650953628151044 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark51(4.310456792112403,33.82971782638853 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark51(4.313494087475462,13.827326117235202 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark51(4.3163801247333,7.051681418878964 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark51(4.317010849932345,24.24405735432738 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark51(4.319271462062787,44.02122615471538 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark51(4.3254745517291155,10.177369777358209 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark51(4.343897117535486,8.011927705792841 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark51(4.346263410611305,8.989017566773043 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark51(4.349123175234688,18.490426069758307 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark51(4.350625668831512,40.10585617295513 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark51(4.3527446654557345,12.645565732160277 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark51(4.359855210340726,29.798067753098024 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark51(4.363785719455933,26.384317237293757 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark51(4.3711764205018095,27.931493974231785 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark51(4.373446882559761,19.315994931988158 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark51(4.376345002886907,17.038915118900434 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark51(4.385439838451234,10.65496243454183 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark51(4.397818820808013,29.01702806281608 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark51(4.401639951961831,16.838738707473063 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark51(4.4029028099373875,29.45089298004632 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark51(4.403791185575487,45.5962088144245 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark51(4.409252983150296,8.750779894740845 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark51(4.410535916766804,29.103762851856914 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark51(4.411393423885656,31.78839346906429 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark51(4.415806440320642,16.95490443665703 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark51(44.171481639232496,55.4272830182577 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark51(4.423416426367353,18.692031923858416 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark51(4.428061968141254,45.57193803185871 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark51(44.369226788417734,0 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark51(4.439374821202534,37.27383568501381 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark51(4.4397380520778285,43.152426098928345 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark51(4.441007477576633,37.668236484102636 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark51(4.44274709177715,12.01062874855154 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark51(4.443793002199364,11.787310988288496 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark51(4.444018752622654,23.420431246742226 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark51(4.446490225942497,24.704320106793574 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark51(4.446549719090271,43.230906019169936 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark51(4.447780791853262,7.461326451375896 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark51(4.449347960225694,35.50781817230802 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark51(4.455207292063008,38.679224705005595 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark51(4.459157181824001,13.453644277108992 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark51(4.4676246841553,43.34692588585254 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark51(4.474058258193117,6.1507563228650035 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark51(4.474350941895678,9.92896610831969 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark51(4.4767572399175215,19.1088598382566 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark51(4.477398800861556,10.715884140972683 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark51(4.483994204764599,9.951850294260083 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark51(4.488368148862037,16.58500738131184 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark51(4.490424322474155,20.7455428106164 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark51(4.492877879109415,30.789272789557515 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark51(4.494038057402136,6.291649189021003 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark51(4.501507690834698,45.49849230916524 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark51(4.505113049258583,33.16746820872228 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark51(4.50910460654687,13.35923823077816 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark51(4.5105991696112255,6.2232540011270885 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark51(4.512459263532037,20.632024380837464 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark51(4.517641799360177,27.723738723103295 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark51(4.528791307947529,37.193370394996606 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark51(4.529876244442271,25.481797090242523 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark51(4.539720465744949,33.75786647200246 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark51(4.541739402115354,26.143963874633982 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark51(4.555383346020032,45.44461665397996 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark51(4.5563887739493225,18.41968549548409 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark51(4.556562353233358,41.85067501968953 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark51(4.55679405609375,6.215791337312234 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark51(4.557935014767978,9.934737138488757 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark51(4.561871659341591,36.965760833733555 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark51(4.566554914873549,28.785884429174416 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark51(4.568985164348646,16.119832185180513 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark51(4.578491079583795,28.54937966844051 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark51(4.584317343494362,41.728868901593756 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark51(4.596712732059572,20.794081361561183 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark51(4.6009597173415955,8.14620690861328 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark51(4.6024066720737515,7.084053444948807 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark51(4.604099617564586,23.86747463176424 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark51(4.608031210957336,33.183531305692725 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark51(4.608882421237581,8.934341020303748 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark51(4.6139319515409625,26.01543435421621 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark51(4.617874219696901,15.601976293186809 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark51(4.624247943564878,6.891873036291804 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark51(4.627458830318602,8.078729713967576 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark51(4.639472833485898,23.89190244064423 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark51(4.647000698383804,44.37366512775184 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark51(4.647348363829934,43.837854391840295 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark51(4.653683544982739,36.391990725769745 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark51(4.656138557548626,18.005419250600163 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark51(4.656836249892265,8.446559223081735 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark51(4.660150569046195,34.427213569584325 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark51(4.6615199000239045,27.351827419891663 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark51(4.66495896916399,37.01358161006975 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark51(4.665660421097925,6.862618325290185 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark51(4.666008070965532,25.63757520481407 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark51(4.66772282207701,16.598711628013987 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark51(4.668780324692918,14.08473036116844 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark51(4.6717338159528765,14.30036712658864 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark51(4.685319005881983,18.094781701746257 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark51(4.688878224585654,32.60132462225485 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark51(4.690490827344238,40.74703474024082 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark51(4.698825757900508,42.84449490221891 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark51(4.7065362896931475,8.123752743592888 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark51(4.711004947046121,31.039987037627014 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark51(4.718847892738836,40.50254673649255 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark51(4.720769450998404,35.34235741206305 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark51(4.723073422317005,9.74468035741289 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark51(4.724243872367268,35.22788196040884 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark51(4.7257699709798615,32.15642719206148 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark51(4.728661239213011,30.852782362929503 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark51(4.730779109778821,6.468837614920936 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark51(4.732963659719232,7.376347260373391 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark51(4.74553920391965,14.001062811184653 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark51(4.755556646889573,9.527534434177042 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark51(4.76217624579607,15.448198630040139 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark51(4.764028191570048,27.01920899492572 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark51(4.76930637382074,25.529341936120915 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark51(4.769876443052269,23.20673774522284 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark51(4.772013713732784,29.420110089000104 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark51(4.7751344699666305,32.260360428103354 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark51(4.776463886096293,16.004284600802848 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark51(4.77763240839235,33.92204437497085 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark51(4.7782271021189295,40.0950130524767 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark51(4.779957848793217,27.965368433203523 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark51(4.786029888130901,6.7785515272629056 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark51(4.786595276376871,27.828323400233042 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark51(4.791382404335636,40.71508130741594 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark51(4.797135449247492,40.43767580327068 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark51(4.798944361141844,15.837361993735783 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark51(4.808557369759001,19.285285714099487 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark51(4.810613091646914,15.978776167549839 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark51(4.810630133854062,8.065113563269762 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark51(4.814050133784846,19.786184798892094 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark51(4.825514124483709,9.76130988554398 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark51(4.826589685773257,24.690306570855896 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark51(4.844889306049112,7.336711256883575 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark51(4.855362753571839,42.6590705519414 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark51(4.858066589107503,7.242064932703704 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark51(4.86273641187951,41.43297806756928 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark51(4.8639895705393,13.850197974076108 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark51(4.868195493125185,8.651033224241573 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark51(4.8735961462167126,41.02627620794931 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark51(4.874946474966762,38.01886843275858 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark51(4.8760950513120775,10.503480826140944 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark51(4.876506691216463,25.32379989280447 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark51(4.879840633800964,33.68819138876893 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark51(4.8803088562935955,34.21524221810648 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark51(4.88075096013732,10.31234804226753 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark51(4.88698597421029,22.545089492106072 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark51(4.892069177360918,45.10793082263908 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark51(4.894060752642,26.35574532752467 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark51(4.902832085060432,37.05621874839255 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark51(4.902842390069793,40.339231234183956 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark51(4.905601955435273,7.650950151518419 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark51(4.907677495159074,28.912397148219483 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark51(4.908714321689729,44.24175910955094 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark51(4.908824612141971,41.5542527816594 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark51(4.92244848242251,34.3373140892987 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark51(4.927727515070156,10.417130071722339 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark51(4.928504998501197,12.963176476381946 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark51(4.931304967113405,17.336198940303873 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark51(4.939207684045922,45.06079231595406 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark51(4.939363141118136,45.06063685888181 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark51(4.941388921553781,41.603118460070874 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark51(4.945268092493931,18.967614202567276 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark51(4.949529279507075,9.041729511134907 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark51(4.951226451990749,15.872297164784314 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark51(4.956162706003184,16.251671488458783 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark51(4.956811723399596,23.55888365249956 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark51(4.961003485046751,20.314860289058885 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark51(4.966155122652012,45.033844877347946 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark51(4.968156805643666,37.99563266115592 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark51(4.970963280303394,27.11424747764613 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark51(4.970970560333569,29.217149559573784 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark51(4.972276023281054,34.59644156383246 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark51(4.973636029863615,41.57650662041574 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark51(4.977786777785294,45.02221322221462 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark51(4.978661013900734,34.88380580864454 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark51(4.9885913914438476,40.17387735050636 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark51(4.991287046850815,24.49413164801433 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark51(4.997129806181633,25.94728101761143 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark51(4.997467948228945,19.945812077843613 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark51(5.016592790162932,19.700548546972186 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark51(5.018991251669121,21.107437340611426 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark51(5.020236580354933,25.05258749616557 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark51(5.024570263281801,43.05640144339034 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark51(5.025007100993417,12.252479953993344 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark51(5.031046606398277,7.533905339308376 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark51(5.033777752957278,40.4842110402939 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark51(5.035805039250391,17.892967398758984 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark51(5.040391551525786,38.81117811899813 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark51(5.043508119479355,25.499960281209468 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark51(5.05157595161353,30.326270290882807 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark51(5.061551095255645,11.28609541272445 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark51(5.068870438566435,42.86410297133588 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark51(5.081601777487151,41.71261115907626 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark51(5.083709863734143,18.202167094987658 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark51(5.084727214608463,29.989769563232926 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark51(5.093136732227743,32.13334657233534 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark51(5.098542338689896,29.865591511110267 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark51(5.103921990064842,41.01651889197427 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark51(5.116502781022604,17.327886229707573 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark51(5.1213158932438745,12.628443547030741 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark51(5.1254954526900605,29.6207315165818 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark51(5.13841525846208,32.396850731739306 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark51(5.139626723766085,37.42302076560327 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark51(5.1402276708003996,29.859238426359525 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark51(5.140859621692172,34.893066235127975 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark51(5.141290683004961,10.39441149950919 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark51(5.1453053408148754,17.80168995153643 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark51(5.147136954525413,16.85396026215985 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark51(5.147746878797523,18.077852283312552 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark51(5.155903813107884,21.214177934814643 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark51(5.162447432947623,10.797127984278916 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark51(5.164290439352001,30.733196500493676 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark51(5.173517568918399,17.362269924360646 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark51(5.176817472629168,20.739942363306113 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark51(5.176888099130949,14.530892927057266 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark51(5.179897124180144,44.4239166830163 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark51(5.1814001747271305,24.947495079410672 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark51(5.184602334690297,11.828493164505119 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark51(5.185310499075213,38.87741205539007 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark51(5.186881489132176,21.271998828368297 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark51(5.1880364501916745,34.91895490923682 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark51(5.1961685154672494,10.044538045300683 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark51(5.196329384922658,6.860023882396234 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark51(5.203886091016514,17.292703445544916 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark51(5.205581833877446,25.707995384089273 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark51(5.2059819903099225,10.943778713677759 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark51(5.210403481906539,39.06969941633426 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark51(-5.220958679459905E-4,0.001648793088309715 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark51(5.222291601469095,17.953224624350497 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark51(5.228417019182885,14.366395134188735 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark51(5.23919640433472,24.019026183739257 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark51(5.239899829234844,7.216896449323893 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark51(5.245507412776675,28.685562899212897 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark51(5.246013278803389,29.987646819087303 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark51(5.246298092403882,17.531409174465296 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark51(5.24800534200341,8.691254491428694 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark51(5.249524944548634,7.753996395546693 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark51(5.2583305886845295,10.214534151747245 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark51(5.263400735497854,16.302293757130684 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark51(5.273860268504109,43.49273557432733 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark51(5.2818759853583686,27.915660582665097 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark51(5.2819504946265425,7.104397718380156 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark51(5.292367987807722,40.79054757904339 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark51(5.2953233178243835,30.523954035477857 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark51(5.298903535356246,37.13765241902232 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark51(5.30222320531864,26.906882811944442 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark51(5.30468707595174,10.716455453550477 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark51(5.3049784484342695,40.503054672995006 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark51(5.311581287180022,7.207539741530164 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark51(5.314595430517372,19.89620426149159 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark51(5.314869883172776,35.666896875549355 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark51(5.326084714612492,13.353477534445247 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark51(5.336308022196604,35.909173557466715 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark51(5.3467323385311385,7.003057572997577 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark51(5.347611484925792E-5,2.661469136373163E-6 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark51(5.3487852779511265,39.04309314168633 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark51(5.350615879425813,27.9823305894594 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark51(5.351276436514183,32.451910019212136 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark51(5.357318983018317,40.90631624741849 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark51(5.359494958077875,18.49198234631683 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark51(5.360411457508185,33.773684567804395 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark51(5.362917917404882,44.414419739804934 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark51(5.372506873541809,27.930884898203672 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark51(5.375342867957983,16.230840775869538 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark51(5.380646450471339,21.928007641978496 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark51(5.381188381858694,16.97483586990146 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark51(5.381882271635584,31.340729541255456 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark51(5.385480814374603,10.719808967670758 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark51(5.38817252295086,30.169747528710275 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark51(5.394126450081686,37.1667325283959 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark51(5.403067926758319,44.59693207324167 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark51(5.407014255691763,20.13546894147737 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark51(5.408371290618646,34.90809748318239 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark51(5.40864433440791,37.086281764323815 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark51(5.416589080350293E-7,2.621914523966535E-6 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark51(-5.421010862427522E-20,3.778566285252903E-4 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark51(5.42421163884724,20.34512165374032 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark51(5.424286012200875,44.57571398779912 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark51(5.428254564821415,17.801995591591606 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark51(5.429953361300704,21.71248371863888 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark51(5.43511235704667,38.24720745970859 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark51(5.436241783591939,35.504025083880606 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark51(5.450882490129544,19.45851576182124 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark51(5.454628292981088,41.067076721486444 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark51(5.457812627792819,8.71528540057541 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark51(5.460935418342757,11.741518933125889 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark51(5.461776900358359,25.200244523228662 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark51(5.46410442485967,26.210112749562214 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark51(5.465366102262379,34.11042660771352 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark51(5.46674254390318,23.137165051919723 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark51(5.4670469943754565,13.036592853206969 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark51(5.468359039893841,13.716721696033744 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark51(5.478295798611578,23.780396383680696 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark51(5.481143101449916,42.09049095661001 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark51(5.4832956574861615,39.981197631329024 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark51(5.487798464389229,33.68752928062966 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark51(5.500855979689831,15.78947684370873 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark51(5.501688590627497,8.672953443656723 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark51(5.504948501272608,16.848005386167486 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark51(5.538838389145951,15.782726270943144 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark51(5.539444576711091,7.884690683009339 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark51(5.539492252256764,27.2638837156114 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark51(5.5447324277354255,21.608444592993408 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark51(5.554869119072457,36.911983749143076 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark51(5.567948204182988,13.481494402841363 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark51(5.574605960757225,40.18145016633511 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark51(5.58222828408104,13.493313470698325 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark51(5.5836734921459055,7.359603846769886 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark51(5.596057615997502,7.895308419015265 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark51(5.607295871306221,40.994748550421065 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark51(5.615213504336706,11.56144294553468 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark51(5.618071016334497,23.88628923233518 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark51(5.625070666571787,42.97304912027906 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark51(5.626781565913049,42.08393072215196 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark51(5.628215844137145,38.435038581180976 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark51(5.632274404712451,26.422822215155733 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark51(5.632782091760021,32.01029045534773 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark51(5.6348655983391005,39.94537795531636 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark51(5.641791368128152,11.794631785104627 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark51(5.642503080813993,27.628402803634387 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark51(5.6429821332107934,42.811773705839215 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark51(5.651865678957748,30.905145678589662 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark51(5.654730067194677,34.66501030829829 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark51(5.654809461543493,17.07589067582431 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark51(5.661018071208829,26.14844809727201 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark51(5.669560609470436,41.61264971348402 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark51(5.670657585604431,26.90169984967885 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark51(5.676461157861674,15.812939264426902 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark51(5.682696186441367,9.912541958018759 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark51(5.687118890654958,14.499631450995182 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark51(5.696826964749379,44.30317303525062 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark51(5.704512245543723,44.29548775445627 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark51(5.709118801148392,11.298975488585981 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark51(5.713764490466406,15.20418369994765 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark51(5.718118316716501,11.128878096852901 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark51(5.720532220248657,41.83998983442163 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark51(5.72957666163984,39.25993404077778 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark51(5.731570070772435,13.284137038138226 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark51(5.733697162075828,42.00378575082536 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark51(5.744719811399975,7.2221182259939765 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark51(5.744738239085208,22.12849903057581 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark51(5.746840014294465,7.170891824086539 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark51(5.751734682556432,42.15916012730651 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark51(5.7550380016604805,15.493527675808622 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark51(5.758844937157221,29.608028298868618 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark51(5.771687644296179,24.282263102221208 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark51(5.777175308160537,38.551716454527764 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark51(5.777836309252365,32.26281357285558 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark51(5.780066520808987,36.69230013826987 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark51(5.794842839256177,41.78287377406619 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark51(5.795673850786869,15.0019458461704 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark51(5.796689236434582,35.714466019803695 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark51(5.800204200954724,29.218226925780613 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark51(5.8008887618268545,24.464640603451244 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark51(5.80242106496988,39.48233427852327 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark51(5.8036131629480145,39.17484625346236 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark51(5.810352350432396,42.58607695679541 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark51(5.817760581428952,30.103117258848055 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark51(5.818110514818336,17.140322472714313 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark51(5.82257238013743,26.738233327523915 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark51(5.824250558836255,21.73260939353115 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark51(5.828611259825265,40.81896534152173 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark51(5.832408203312383,16.540875926206056 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark51(5.841585027756651,36.48986331779645 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark51(5.848162000954311,44.15183799904568 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark51(5.8588134072964095,12.500131852285065 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark51(5.8610900496789355,15.814513205700493 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark51(5.87496369380645,41.32745059469278 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark51(5.876009600299572,14.222925866933918 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark51(5.88256037978752,42.59328298311556 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark51(5.887614598137333,26.616394939268403 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark51(5.889936205381092,10.45686038269632 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark51(5.893838989908289,34.51766027182819 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark51(5.901499223526633,9.352295230623724 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark51(5.925944630345679,43.35674654022026 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark51(5.930237318687194,37.53828545859554 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark51(5.934470280711253,22.71218238802342 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark51(5.9378213712468835,37.44248445963544 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark51(5.943359689643103,42.24862745480803 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark51(5.943493925518254,38.045087118487714 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark51(5.950919451336972,15.157018184190491 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark51(5.9586469168348515,26.079579393052143 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark51(5.959670470096583,28.46121509695996 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark51(5.968433332804324,42.42650023750048 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark51(5.9769165301772205,12.246880507423924 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark51(5.978156210479952,17.620404480937452 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark51(5.991691795466124,28.903435518613236 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark51(5.992982427005167,8.000299966549022 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark51(5.994624355035484,18.794404257761926 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark51(5.9963521067239185,42.264060817141086 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark51(5.99639259592459,12.237185690879485 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark51(5.997469345124443,8.589715023531056 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark51(6.0023750133804725,27.576821204247267 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark51(6.007478096495541,43.99252190350444 ) ;
  }

  @Test
  public void test2476() {
    coral.tests.JPFBenchmark.benchmark51(6.009193789126961,40.6667405128091 ) ;
  }

  @Test
  public void test2477() {
    coral.tests.JPFBenchmark.benchmark51(6.0166603919681165,27.354586240265828 ) ;
  }

  @Test
  public void test2478() {
    coral.tests.JPFBenchmark.benchmark51(6.018943098040026,12.104680115011064 ) ;
  }

  @Test
  public void test2479() {
    coral.tests.JPFBenchmark.benchmark51(6.026594010204931,38.45421555791705 ) ;
  }

  @Test
  public void test2480() {
    coral.tests.JPFBenchmark.benchmark51(6.035877126576139,29.69022404488635 ) ;
  }

  @Test
  public void test2481() {
    coral.tests.JPFBenchmark.benchmark51(6.0365261509088555,38.76234685697898 ) ;
  }

  @Test
  public void test2482() {
    coral.tests.JPFBenchmark.benchmark51(6.04737902420036,43.95262097579963 ) ;
  }

  @Test
  public void test2483() {
    coral.tests.JPFBenchmark.benchmark51(6.056689857625656,11.083396045253409 ) ;
  }

  @Test
  public void test2484() {
    coral.tests.JPFBenchmark.benchmark51(6.059765481659018E-5,6.598709868493876E-8 ) ;
  }

  @Test
  public void test2485() {
    coral.tests.JPFBenchmark.benchmark51(6.0633066578462405,16.67568356617278 ) ;
  }

  @Test
  public void test2486() {
    coral.tests.JPFBenchmark.benchmark51(6.076722689426234,38.22321236132754 ) ;
  }

  @Test
  public void test2487() {
    coral.tests.JPFBenchmark.benchmark51(6.090960272056506,17.36153522256781 ) ;
  }

  @Test
  public void test2488() {
    coral.tests.JPFBenchmark.benchmark51(6.097895902750537,8.851229899015152 ) ;
  }

  @Test
  public void test2489() {
    coral.tests.JPFBenchmark.benchmark51(6.099189970089753,9.386365315582367 ) ;
  }

  @Test
  public void test2490() {
    coral.tests.JPFBenchmark.benchmark51(6.1008690268521,43.89913097314789 ) ;
  }

  @Test
  public void test2491() {
    coral.tests.JPFBenchmark.benchmark51(6.101842874792069,8.863700775061247 ) ;
  }

  @Test
  public void test2492() {
    coral.tests.JPFBenchmark.benchmark51(6.102212820966599,20.650790060737904 ) ;
  }

  @Test
  public void test2493() {
    coral.tests.JPFBenchmark.benchmark51(6.110355877984091,39.499619186831495 ) ;
  }

  @Test
  public void test2494() {
    coral.tests.JPFBenchmark.benchmark51(6.123181610268389,30.30542784060583 ) ;
  }

  @Test
  public void test2495() {
    coral.tests.JPFBenchmark.benchmark51(6.127854096733003,35.650534619313845 ) ;
  }

  @Test
  public void test2496() {
    coral.tests.JPFBenchmark.benchmark51(6.131779542744681,7.744140077392597 ) ;
  }

  @Test
  public void test2497() {
    coral.tests.JPFBenchmark.benchmark51(6.138698178004205,29.10542380344944 ) ;
  }

  @Test
  public void test2498() {
    coral.tests.JPFBenchmark.benchmark51(6.139347553692522,9.620470130443113 ) ;
  }

  @Test
  public void test2499() {
    coral.tests.JPFBenchmark.benchmark51(6.1425945110005244,9.590832862735013 ) ;
  }

  @Test
  public void test2500() {
    coral.tests.JPFBenchmark.benchmark51(6.150974485761978,30.10651059956095 ) ;
  }

  @Test
  public void test2501() {
    coral.tests.JPFBenchmark.benchmark51(6.153162135754432,13.715088521854327 ) ;
  }

  @Test
  public void test2502() {
    coral.tests.JPFBenchmark.benchmark51(6.162569499604189,42.93977069661264 ) ;
  }

  @Test
  public void test2503() {
    coral.tests.JPFBenchmark.benchmark51(6.169319409694651,29.510021326516153 ) ;
  }

  @Test
  public void test2504() {
    coral.tests.JPFBenchmark.benchmark51(6.185190594997067,8.51741208988679 ) ;
  }

  @Test
  public void test2505() {
    coral.tests.JPFBenchmark.benchmark51(6.186227482355512,8.755609525210772 ) ;
  }

  @Test
  public void test2506() {
    coral.tests.JPFBenchmark.benchmark51(6.1896186880187045,43.81038131198129 ) ;
  }

  @Test
  public void test2507() {
    coral.tests.JPFBenchmark.benchmark51(61.947688611869324,23.27470279622581 ) ;
  }

  @Test
  public void test2508() {
    coral.tests.JPFBenchmark.benchmark51(6.197656864083513,28.797677659570752 ) ;
  }

  @Test
  public void test2509() {
    coral.tests.JPFBenchmark.benchmark51(6.199941387520369,28.77689118654957 ) ;
  }

  @Test
  public void test2510() {
    coral.tests.JPFBenchmark.benchmark51(6.209939623234575,33.1246603054839 ) ;
  }

  @Test
  public void test2511() {
    coral.tests.JPFBenchmark.benchmark51(6.210103571394733,7.998883126104429 ) ;
  }

  @Test
  public void test2512() {
    coral.tests.JPFBenchmark.benchmark51(-6.2139302298297785E-9,0 ) ;
  }

  @Test
  public void test2513() {
    coral.tests.JPFBenchmark.benchmark51(6.216110682737787,43.7838893172622 ) ;
  }

  @Test
  public void test2514() {
    coral.tests.JPFBenchmark.benchmark51(6.218328479949605,12.849490980234094 ) ;
  }

  @Test
  public void test2515() {
    coral.tests.JPFBenchmark.benchmark51(6.223351836083353,26.98837150014883 ) ;
  }

  @Test
  public void test2516() {
    coral.tests.JPFBenchmark.benchmark51(6.230598878606955,29.886951522600015 ) ;
  }

  @Test
  public void test2517() {
    coral.tests.JPFBenchmark.benchmark51(6.2448851359052995,10.391768905092107 ) ;
  }

  @Test
  public void test2518() {
    coral.tests.JPFBenchmark.benchmark51(6.245208296749709,41.55501799247102 ) ;
  }

  @Test
  public void test2519() {
    coral.tests.JPFBenchmark.benchmark51(6.24870148992467,41.43341734725939 ) ;
  }

  @Test
  public void test2520() {
    coral.tests.JPFBenchmark.benchmark51(6.249557005079126,33.813344730478605 ) ;
  }

  @Test
  public void test2521() {
    coral.tests.JPFBenchmark.benchmark51(6.268762205577488,20.438111739691607 ) ;
  }

  @Test
  public void test2522() {
    coral.tests.JPFBenchmark.benchmark51(6.273497131339155,8.359639156434312 ) ;
  }

  @Test
  public void test2523() {
    coral.tests.JPFBenchmark.benchmark51(6.274540355410522,21.328101976067444 ) ;
  }

  @Test
  public void test2524() {
    coral.tests.JPFBenchmark.benchmark51(6.285281782894032,19.75395673894144 ) ;
  }

  @Test
  public void test2525() {
    coral.tests.JPFBenchmark.benchmark51(6.287419854032009,8.594271643191405 ) ;
  }

  @Test
  public void test2526() {
    coral.tests.JPFBenchmark.benchmark51(6.290932174276946,26.537110311428933 ) ;
  }

  @Test
  public void test2527() {
    coral.tests.JPFBenchmark.benchmark51(6.291631672277703,8.857092452606224 ) ;
  }

  @Test
  public void test2528() {
    coral.tests.JPFBenchmark.benchmark51(6.296437836478747,17.430826951510987 ) ;
  }

  @Test
  public void test2529() {
    coral.tests.JPFBenchmark.benchmark51(6.308812766860823,43.69118723313917 ) ;
  }

  @Test
  public void test2530() {
    coral.tests.JPFBenchmark.benchmark51(6.3102312377152625,8.816166167838452 ) ;
  }

  @Test
  public void test2531() {
    coral.tests.JPFBenchmark.benchmark51(6.310702789955997,8.206663702539501 ) ;
  }

  @Test
  public void test2532() {
    coral.tests.JPFBenchmark.benchmark51(6.317083858157716,10.397685796471764 ) ;
  }

  @Test
  public void test2533() {
    coral.tests.JPFBenchmark.benchmark51(6.323766568463867,32.43221603948189 ) ;
  }

  @Test
  public void test2534() {
    coral.tests.JPFBenchmark.benchmark51(6.325908141803865,10.406829261153973 ) ;
  }

  @Test
  public void test2535() {
    coral.tests.JPFBenchmark.benchmark51(6.327705373692098,22.30150315766717 ) ;
  }

  @Test
  public void test2536() {
    coral.tests.JPFBenchmark.benchmark51(6.3294899236344335,41.515603898203295 ) ;
  }

  @Test
  public void test2537() {
    coral.tests.JPFBenchmark.benchmark51(6.335406047975823,27.772848891125548 ) ;
  }

  @Test
  public void test2538() {
    coral.tests.JPFBenchmark.benchmark51(6.3367155639111665,8.189921733851378 ) ;
  }

  @Test
  public void test2539() {
    coral.tests.JPFBenchmark.benchmark51(6.34588471742039,9.615771361844313 ) ;
  }

  @Test
  public void test2540() {
    coral.tests.JPFBenchmark.benchmark51(6.3493750258577535,29.9007372778359 ) ;
  }

  @Test
  public void test2541() {
    coral.tests.JPFBenchmark.benchmark51(6.356202052609049,19.053733297390735 ) ;
  }

  @Test
  public void test2542() {
    coral.tests.JPFBenchmark.benchmark51(63.582295786519495,82.14759742856003 ) ;
  }

  @Test
  public void test2543() {
    coral.tests.JPFBenchmark.benchmark51(6.363358816917582,28.131332030066318 ) ;
  }

  @Test
  public void test2544() {
    coral.tests.JPFBenchmark.benchmark51(6.371813253832693,7.774372941190904 ) ;
  }

  @Test
  public void test2545() {
    coral.tests.JPFBenchmark.benchmark51(6.3774632516227,33.0846279228094 ) ;
  }

  @Test
  public void test2546() {
    coral.tests.JPFBenchmark.benchmark51(6.381597777145018,19.378886678392064 ) ;
  }

  @Test
  public void test2547() {
    coral.tests.JPFBenchmark.benchmark51(6.390041406757163,24.987809586250265 ) ;
  }

  @Test
  public void test2548() {
    coral.tests.JPFBenchmark.benchmark51(6.395180211367915,14.73028634601907 ) ;
  }

  @Test
  public void test2549() {
    coral.tests.JPFBenchmark.benchmark51(6.398497552769314,27.633113118988618 ) ;
  }

  @Test
  public void test2550() {
    coral.tests.JPFBenchmark.benchmark51(6.407976780063834,29.17581698045811 ) ;
  }

  @Test
  public void test2551() {
    coral.tests.JPFBenchmark.benchmark51(6.418035531091618,26.492335541151206 ) ;
  }

  @Test
  public void test2552() {
    coral.tests.JPFBenchmark.benchmark51(6.430766569844721,26.141252665265167 ) ;
  }

  @Test
  public void test2553() {
    coral.tests.JPFBenchmark.benchmark51(6.444578366726759,43.555421633273234 ) ;
  }

  @Test
  public void test2554() {
    coral.tests.JPFBenchmark.benchmark51(6.457235645236551,29.559330214876724 ) ;
  }

  @Test
  public void test2555() {
    coral.tests.JPFBenchmark.benchmark51(6.457412372357837,24.59790859399058 ) ;
  }

  @Test
  public void test2556() {
    coral.tests.JPFBenchmark.benchmark51(6.467693122144514,22.09343965491395 ) ;
  }

  @Test
  public void test2557() {
    coral.tests.JPFBenchmark.benchmark51(6.475338781478623,25.93415044780661 ) ;
  }

  @Test
  public void test2558() {
    coral.tests.JPFBenchmark.benchmark51(6.478049213445264,19.76783015743679 ) ;
  }

  @Test
  public void test2559() {
    coral.tests.JPFBenchmark.benchmark51(6.4809491072928775,43.5190508927071 ) ;
  }

  @Test
  public void test2560() {
    coral.tests.JPFBenchmark.benchmark51(6.492044303565166,20.85975901741668 ) ;
  }

  @Test
  public void test2561() {
    coral.tests.JPFBenchmark.benchmark51(6.495039508663254,9.673838519124203 ) ;
  }

  @Test
  public void test2562() {
    coral.tests.JPFBenchmark.benchmark51(6.496566210208197,11.58495610888724 ) ;
  }

  @Test
  public void test2563() {
    coral.tests.JPFBenchmark.benchmark51(6.4966676615518395,28.92389758460564 ) ;
  }

  @Test
  public void test2564() {
    coral.tests.JPFBenchmark.benchmark51(6.50579844300853,40.27133718640846 ) ;
  }

  @Test
  public void test2565() {
    coral.tests.JPFBenchmark.benchmark51(6.512345669808212,40.74280355250423 ) ;
  }

  @Test
  public void test2566() {
    coral.tests.JPFBenchmark.benchmark51(6.514904496919627,8.976080687667036 ) ;
  }

  @Test
  public void test2567() {
    coral.tests.JPFBenchmark.benchmark51(6.516747216759974,43.483252783240005 ) ;
  }

  @Test
  public void test2568() {
    coral.tests.JPFBenchmark.benchmark51(6.520451049460348,37.44479906080733 ) ;
  }

  @Test
  public void test2569() {
    coral.tests.JPFBenchmark.benchmark51(6.530761819292465,35.28045057833822 ) ;
  }

  @Test
  public void test2570() {
    coral.tests.JPFBenchmark.benchmark51(6.536195842357028,14.166904387405811 ) ;
  }

  @Test
  public void test2571() {
    coral.tests.JPFBenchmark.benchmark51(6.538996830936284,16.159309778695658 ) ;
  }

  @Test
  public void test2572() {
    coral.tests.JPFBenchmark.benchmark51(6.541413964939437,14.32787964102286 ) ;
  }

  @Test
  public void test2573() {
    coral.tests.JPFBenchmark.benchmark51(6.551464556659511,15.222699576964914 ) ;
  }

  @Test
  public void test2574() {
    coral.tests.JPFBenchmark.benchmark51(6.552986867264423,23.842071477450048 ) ;
  }

  @Test
  public void test2575() {
    coral.tests.JPFBenchmark.benchmark51(6.556026428004785,11.845147120325763 ) ;
  }

  @Test
  public void test2576() {
    coral.tests.JPFBenchmark.benchmark51(6.562458826353415,43.43754117364658 ) ;
  }

  @Test
  public void test2577() {
    coral.tests.JPFBenchmark.benchmark51(6.567662382216,30.078919350251084 ) ;
  }

  @Test
  public void test2578() {
    coral.tests.JPFBenchmark.benchmark51(6.571210371572803,37.42353133525219 ) ;
  }

  @Test
  public void test2579() {
    coral.tests.JPFBenchmark.benchmark51(6.573124204113398,12.419850534904569 ) ;
  }

  @Test
  public void test2580() {
    coral.tests.JPFBenchmark.benchmark51(6.600399868036661,14.880412573677575 ) ;
  }

  @Test
  public void test2581() {
    coral.tests.JPFBenchmark.benchmark51(6.631612442544508,10.845133935553392 ) ;
  }

  @Test
  public void test2582() {
    coral.tests.JPFBenchmark.benchmark51(6.642804836090235,41.308821915361534 ) ;
  }

  @Test
  public void test2583() {
    coral.tests.JPFBenchmark.benchmark51(6.646127579521206,10.155425199351683 ) ;
  }

  @Test
  public void test2584() {
    coral.tests.JPFBenchmark.benchmark51(6.649867949526353,32.29843480042723 ) ;
  }

  @Test
  public void test2585() {
    coral.tests.JPFBenchmark.benchmark51(6.6538282281626095,22.2209624399716 ) ;
  }

  @Test
  public void test2586() {
    coral.tests.JPFBenchmark.benchmark51(6.662646986026985,39.57388432076468 ) ;
  }

  @Test
  public void test2587() {
    coral.tests.JPFBenchmark.benchmark51(6.665452181870467,8.470915917693162 ) ;
  }

  @Test
  public void test2588() {
    coral.tests.JPFBenchmark.benchmark51(6.6660405419364475,31.18553938141892 ) ;
  }

  @Test
  public void test2589() {
    coral.tests.JPFBenchmark.benchmark51(6.666099459502803,21.89696301883022 ) ;
  }

  @Test
  public void test2590() {
    coral.tests.JPFBenchmark.benchmark51(6.677769320192045,11.677776606047221 ) ;
  }

  @Test
  public void test2591() {
    coral.tests.JPFBenchmark.benchmark51(6.678385798212048,19.173080274349587 ) ;
  }

  @Test
  public void test2592() {
    coral.tests.JPFBenchmark.benchmark51(6.684961570692337,13.819662925691972 ) ;
  }

  @Test
  public void test2593() {
    coral.tests.JPFBenchmark.benchmark51(6.69426294148623,35.69468493708962 ) ;
  }

  @Test
  public void test2594() {
    coral.tests.JPFBenchmark.benchmark51(6.7000282152935,16.538240485131055 ) ;
  }

  @Test
  public void test2595() {
    coral.tests.JPFBenchmark.benchmark51(6.703110252345894,15.94666534786424 ) ;
  }

  @Test
  public void test2596() {
    coral.tests.JPFBenchmark.benchmark51(6.713018278881336,8.264978244058657 ) ;
  }

  @Test
  public void test2597() {
    coral.tests.JPFBenchmark.benchmark51(6.716472696005454,17.941092073960732 ) ;
  }

  @Test
  public void test2598() {
    coral.tests.JPFBenchmark.benchmark51(6.719762278081092,36.24102956580822 ) ;
  }

  @Test
  public void test2599() {
    coral.tests.JPFBenchmark.benchmark51(6.7293310501750625,42.216223250029685 ) ;
  }

  @Test
  public void test2600() {
    coral.tests.JPFBenchmark.benchmark51(6.730174971278132,33.8164315822948 ) ;
  }

  @Test
  public void test2601() {
    coral.tests.JPFBenchmark.benchmark51(6.735274748005967,8.216282193373473 ) ;
  }

  @Test
  public void test2602() {
    coral.tests.JPFBenchmark.benchmark51(6.749010295929196,13.414988005152324 ) ;
  }

  @Test
  public void test2603() {
    coral.tests.JPFBenchmark.benchmark51(6.756474102679363,17.76931636872652 ) ;
  }

  @Test
  public void test2604() {
    coral.tests.JPFBenchmark.benchmark51(6.75753997170807,12.129662926762236 ) ;
  }

  @Test
  public void test2605() {
    coral.tests.JPFBenchmark.benchmark51(6.758923587921738,37.52041319061604 ) ;
  }

  @Test
  public void test2606() {
    coral.tests.JPFBenchmark.benchmark51(6.7724686593053605,36.10125694733068 ) ;
  }

  @Test
  public void test2607() {
    coral.tests.JPFBenchmark.benchmark51(6.7734990301628955,15.686157816981478 ) ;
  }

  @Test
  public void test2608() {
    coral.tests.JPFBenchmark.benchmark51(6.7808272223022925,36.41459468129318 ) ;
  }

  @Test
  public void test2609() {
    coral.tests.JPFBenchmark.benchmark51(6.789190392311099,13.693571745954245 ) ;
  }

  @Test
  public void test2610() {
    coral.tests.JPFBenchmark.benchmark51(6.79697430802425,31.62130779873479 ) ;
  }

  @Test
  public void test2611() {
    coral.tests.JPFBenchmark.benchmark51(6.817359866175337,20.15450973421042 ) ;
  }

  @Test
  public void test2612() {
    coral.tests.JPFBenchmark.benchmark51(6.827051055497602,16.28456550743412 ) ;
  }

  @Test
  public void test2613() {
    coral.tests.JPFBenchmark.benchmark51(6.831524033528979,38.400991074112085 ) ;
  }

  @Test
  public void test2614() {
    coral.tests.JPFBenchmark.benchmark51(6.833089184198052,18.548286656349255 ) ;
  }

  @Test
  public void test2615() {
    coral.tests.JPFBenchmark.benchmark51(6.835205681544295,24.60657328785088 ) ;
  }

  @Test
  public void test2616() {
    coral.tests.JPFBenchmark.benchmark51(6.837857226522573,33.008630299407685 ) ;
  }

  @Test
  public void test2617() {
    coral.tests.JPFBenchmark.benchmark51(6.839234258669279,13.890562047793907 ) ;
  }

  @Test
  public void test2618() {
    coral.tests.JPFBenchmark.benchmark51(6.842447120149657,11.67544276901755 ) ;
  }

  @Test
  public void test2619() {
    coral.tests.JPFBenchmark.benchmark51(6.843934666531368,8.27288866153853 ) ;
  }

  @Test
  public void test2620() {
    coral.tests.JPFBenchmark.benchmark51(6.845379465617702E-5,0 ) ;
  }

  @Test
  public void test2621() {
    coral.tests.JPFBenchmark.benchmark51(6.848549920756739,15.471862275649103 ) ;
  }

  @Test
  public void test2622() {
    coral.tests.JPFBenchmark.benchmark51(6.858108237007428,38.21943783044418 ) ;
  }

  @Test
  public void test2623() {
    coral.tests.JPFBenchmark.benchmark51(6.86027231690862,34.134638339794435 ) ;
  }

  @Test
  public void test2624() {
    coral.tests.JPFBenchmark.benchmark51(6.8603521739217435,16.97715076793184 ) ;
  }

  @Test
  public void test2625() {
    coral.tests.JPFBenchmark.benchmark51(6.868579779010759,25.232462517948576 ) ;
  }

  @Test
  public void test2626() {
    coral.tests.JPFBenchmark.benchmark51(6.8919459614289735,29.207949527884495 ) ;
  }

  @Test
  public void test2627() {
    coral.tests.JPFBenchmark.benchmark51(6.893891230170842,39.13557055461669 ) ;
  }

  @Test
  public void test2628() {
    coral.tests.JPFBenchmark.benchmark51(6.894504009178082,9.031734850503017 ) ;
  }

  @Test
  public void test2629() {
    coral.tests.JPFBenchmark.benchmark51(6.896383214476302,29.787132082098992 ) ;
  }

  @Test
  public void test2630() {
    coral.tests.JPFBenchmark.benchmark51(6.897050937945281,24.17083728337805 ) ;
  }

  @Test
  public void test2631() {
    coral.tests.JPFBenchmark.benchmark51(6.8980650411060225,18.240688336788708 ) ;
  }

  @Test
  public void test2632() {
    coral.tests.JPFBenchmark.benchmark51(6.901381045735093,8.147163442444029 ) ;
  }

  @Test
  public void test2633() {
    coral.tests.JPFBenchmark.benchmark51(6.907495306932564,43.092504693067426 ) ;
  }

  @Test
  public void test2634() {
    coral.tests.JPFBenchmark.benchmark51(6.926251437532898,30.092442136715334 ) ;
  }

  @Test
  public void test2635() {
    coral.tests.JPFBenchmark.benchmark51(6.92800259213719,30.79227443360179 ) ;
  }

  @Test
  public void test2636() {
    coral.tests.JPFBenchmark.benchmark51(6.932757495283322,35.32007510199589 ) ;
  }

  @Test
  public void test2637() {
    coral.tests.JPFBenchmark.benchmark51(6.940486773416737,29.95180043473644 ) ;
  }

  @Test
  public void test2638() {
    coral.tests.JPFBenchmark.benchmark51(6.940899825712705,21.552354808570428 ) ;
  }

  @Test
  public void test2639() {
    coral.tests.JPFBenchmark.benchmark51(6.941792556819038,10.340630081713115 ) ;
  }

  @Test
  public void test2640() {
    coral.tests.JPFBenchmark.benchmark51(6.94615257884719,20.385939366568977 ) ;
  }

  @Test
  public void test2641() {
    coral.tests.JPFBenchmark.benchmark51(6.956315012835844,24.701812395595013 ) ;
  }

  @Test
  public void test2642() {
    coral.tests.JPFBenchmark.benchmark51(6.966484363492273,15.26779264526994 ) ;
  }

  @Test
  public void test2643() {
    coral.tests.JPFBenchmark.benchmark51(6.970133385927138,20.578181735459992 ) ;
  }

  @Test
  public void test2644() {
    coral.tests.JPFBenchmark.benchmark51(6.973883347455059,40.536592006503746 ) ;
  }

  @Test
  public void test2645() {
    coral.tests.JPFBenchmark.benchmark51(6.974919898513235,35.54644734738747 ) ;
  }

  @Test
  public void test2646() {
    coral.tests.JPFBenchmark.benchmark51(6.979197548357412,23.289403748906224 ) ;
  }

  @Test
  public void test2647() {
    coral.tests.JPFBenchmark.benchmark51(69.80612446577496,0 ) ;
  }

  @Test
  public void test2648() {
    coral.tests.JPFBenchmark.benchmark51(6.981609653968402,16.457251079336366 ) ;
  }

  @Test
  public void test2649() {
    coral.tests.JPFBenchmark.benchmark51(6.999723729307036,27.333592696250236 ) ;
  }

  @Test
  public void test2650() {
    coral.tests.JPFBenchmark.benchmark51(7.00246567695919,8.237086392919394 ) ;
  }

  @Test
  public void test2651() {
    coral.tests.JPFBenchmark.benchmark51(7.004323165635682,35.8021086709023 ) ;
  }

  @Test
  public void test2652() {
    coral.tests.JPFBenchmark.benchmark51(7.006115400914624,9.319804194607315 ) ;
  }

  @Test
  public void test2653() {
    coral.tests.JPFBenchmark.benchmark51(7.015565292824107,15.11984913981803 ) ;
  }

  @Test
  public void test2654() {
    coral.tests.JPFBenchmark.benchmark51(7.021484239395505,11.185689665186985 ) ;
  }

  @Test
  public void test2655() {
    coral.tests.JPFBenchmark.benchmark51(7.02933757314878,17.673042808804865 ) ;
  }

  @Test
  public void test2656() {
    coral.tests.JPFBenchmark.benchmark51(7.029848501459253,23.263948189639194 ) ;
  }

  @Test
  public void test2657() {
    coral.tests.JPFBenchmark.benchmark51(7.0443050037145625,13.842772619817397 ) ;
  }

  @Test
  public void test2658() {
    coral.tests.JPFBenchmark.benchmark51(7.0548676569325295,30.379737689243722 ) ;
  }

  @Test
  public void test2659() {
    coral.tests.JPFBenchmark.benchmark51(7.07102965798788,9.56437891775677 ) ;
  }

  @Test
  public void test2660() {
    coral.tests.JPFBenchmark.benchmark51(7.073142584101589,28.080226739141068 ) ;
  }

  @Test
  public void test2661() {
    coral.tests.JPFBenchmark.benchmark51(7.07342970354685,19.160580773143863 ) ;
  }

  @Test
  public void test2662() {
    coral.tests.JPFBenchmark.benchmark51(7.078178057780818,33.84685450444351 ) ;
  }

  @Test
  public void test2663() {
    coral.tests.JPFBenchmark.benchmark51(70.80812285321483,80.95741728698022 ) ;
  }

  @Test
  public void test2664() {
    coral.tests.JPFBenchmark.benchmark51(7.083520759134743,25.063836263839832 ) ;
  }

  @Test
  public void test2665() {
    coral.tests.JPFBenchmark.benchmark51(7.094631063093928,12.24266233339791 ) ;
  }

  @Test
  public void test2666() {
    coral.tests.JPFBenchmark.benchmark51(7.098018206932093,11.462373529803926 ) ;
  }

  @Test
  public void test2667() {
    coral.tests.JPFBenchmark.benchmark51(7.105908279416354,23.396366199859713 ) ;
  }

  @Test
  public void test2668() {
    coral.tests.JPFBenchmark.benchmark51(7.1081442242508786,27.063805494111293 ) ;
  }

  @Test
  public void test2669() {
    coral.tests.JPFBenchmark.benchmark51(7.109596535129851,40.60030176251404 ) ;
  }

  @Test
  public void test2670() {
    coral.tests.JPFBenchmark.benchmark51(7.113220873795522,8.9660277891779 ) ;
  }

  @Test
  public void test2671() {
    coral.tests.JPFBenchmark.benchmark51(7.127333548337546,26.475373430354338 ) ;
  }

  @Test
  public void test2672() {
    coral.tests.JPFBenchmark.benchmark51(7.134299799744436,28.201645570909086 ) ;
  }

  @Test
  public void test2673() {
    coral.tests.JPFBenchmark.benchmark51(7.140357938179974,29.982328363687884 ) ;
  }

  @Test
  public void test2674() {
    coral.tests.JPFBenchmark.benchmark51(7.141062674659466,37.61323821240916 ) ;
  }

  @Test
  public void test2675() {
    coral.tests.JPFBenchmark.benchmark51(7.142345854893037,24.377211728149305 ) ;
  }

  @Test
  public void test2676() {
    coral.tests.JPFBenchmark.benchmark51(7.143004205438133,36.26142451852084 ) ;
  }

  @Test
  public void test2677() {
    coral.tests.JPFBenchmark.benchmark51(7.145926789077034,12.366468567521261 ) ;
  }

  @Test
  public void test2678() {
    coral.tests.JPFBenchmark.benchmark51(7.157300541644533,42.8426994583546 ) ;
  }

  @Test
  public void test2679() {
    coral.tests.JPFBenchmark.benchmark51(7.1589495869990145,27.299903134035503 ) ;
  }

  @Test
  public void test2680() {
    coral.tests.JPFBenchmark.benchmark51(7.160400713469244,35.04540453729206 ) ;
  }

  @Test
  public void test2681() {
    coral.tests.JPFBenchmark.benchmark51(7.160439286360344,41.67254609100158 ) ;
  }

  @Test
  public void test2682() {
    coral.tests.JPFBenchmark.benchmark51(7.161158175286239,31.04435417785263 ) ;
  }

  @Test
  public void test2683() {
    coral.tests.JPFBenchmark.benchmark51(7.161619407433562,39.6865980645766 ) ;
  }

  @Test
  public void test2684() {
    coral.tests.JPFBenchmark.benchmark51(7.164849257505637,38.621770255008094 ) ;
  }

  @Test
  public void test2685() {
    coral.tests.JPFBenchmark.benchmark51(7.165279489803368,10.241713115509626 ) ;
  }

  @Test
  public void test2686() {
    coral.tests.JPFBenchmark.benchmark51(7.181830016787401,37.607126414391104 ) ;
  }

  @Test
  public void test2687() {
    coral.tests.JPFBenchmark.benchmark51(7.182512803056511,15.960682245489235 ) ;
  }

  @Test
  public void test2688() {
    coral.tests.JPFBenchmark.benchmark51(7.186055301019522,37.776408112240745 ) ;
  }

  @Test
  public void test2689() {
    coral.tests.JPFBenchmark.benchmark51(7.1907197084272125,23.27318244270748 ) ;
  }

  @Test
  public void test2690() {
    coral.tests.JPFBenchmark.benchmark51(7.192753908318949,34.673761651442874 ) ;
  }

  @Test
  public void test2691() {
    coral.tests.JPFBenchmark.benchmark51(7.192985488332027,14.507794118725357 ) ;
  }

  @Test
  public void test2692() {
    coral.tests.JPFBenchmark.benchmark51(7.193875577374499,8.733217072939848 ) ;
  }

  @Test
  public void test2693() {
    coral.tests.JPFBenchmark.benchmark51(7.197654234025364,36.857298793439355 ) ;
  }

  @Test
  public void test2694() {
    coral.tests.JPFBenchmark.benchmark51(7.201575229009766,26.48555194945098 ) ;
  }

  @Test
  public void test2695() {
    coral.tests.JPFBenchmark.benchmark51(7.202594051406937,32.10654499021801 ) ;
  }

  @Test
  public void test2696() {
    coral.tests.JPFBenchmark.benchmark51(7.210158731526221,29.3135337030607 ) ;
  }

  @Test
  public void test2697() {
    coral.tests.JPFBenchmark.benchmark51(7.21720124364937,8.424889751108019 ) ;
  }

  @Test
  public void test2698() {
    coral.tests.JPFBenchmark.benchmark51(7.225875466998303,18.132910751268525 ) ;
  }

  @Test
  public void test2699() {
    coral.tests.JPFBenchmark.benchmark51(7.2345895835769625,25.485811966264293 ) ;
  }

  @Test
  public void test2700() {
    coral.tests.JPFBenchmark.benchmark51(7.236918639384754,21.270848676006594 ) ;
  }

  @Test
  public void test2701() {
    coral.tests.JPFBenchmark.benchmark51(7.245567519623748,41.598138878233726 ) ;
  }

  @Test
  public void test2702() {
    coral.tests.JPFBenchmark.benchmark51(7.24937198816769,33.19582033593218 ) ;
  }

  @Test
  public void test2703() {
    coral.tests.JPFBenchmark.benchmark51(7.2511301499662375,42.748869850033756 ) ;
  }

  @Test
  public void test2704() {
    coral.tests.JPFBenchmark.benchmark51(7.25437597687597,34.86464405975162 ) ;
  }

  @Test
  public void test2705() {
    coral.tests.JPFBenchmark.benchmark51(7.259404963908111,14.772756273602013 ) ;
  }

  @Test
  public void test2706() {
    coral.tests.JPFBenchmark.benchmark51(7.259422525258955,23.286273942191542 ) ;
  }

  @Test
  public void test2707() {
    coral.tests.JPFBenchmark.benchmark51(7.261006575728786,30.361101734645388 ) ;
  }

  @Test
  public void test2708() {
    coral.tests.JPFBenchmark.benchmark51(7.26616510578944,20.81588748622727 ) ;
  }

  @Test
  public void test2709() {
    coral.tests.JPFBenchmark.benchmark51(7.270312435335342,37.70586867323368 ) ;
  }

  @Test
  public void test2710() {
    coral.tests.JPFBenchmark.benchmark51(7.282919079805549,32.263656450642 ) ;
  }

  @Test
  public void test2711() {
    coral.tests.JPFBenchmark.benchmark51(7.294444824132471,31.433749165596993 ) ;
  }

  @Test
  public void test2712() {
    coral.tests.JPFBenchmark.benchmark51(7.297809903547957,36.7342606027311 ) ;
  }

  @Test
  public void test2713() {
    coral.tests.JPFBenchmark.benchmark51(7.302126941866533,17.70397426866485 ) ;
  }

  @Test
  public void test2714() {
    coral.tests.JPFBenchmark.benchmark51(7.308471931265187,8.54484823777429 ) ;
  }

  @Test
  public void test2715() {
    coral.tests.JPFBenchmark.benchmark51(7.321522958343362,18.448746092413682 ) ;
  }

  @Test
  public void test2716() {
    coral.tests.JPFBenchmark.benchmark51(7.325324499406122,26.240014707084285 ) ;
  }

  @Test
  public void test2717() {
    coral.tests.JPFBenchmark.benchmark51(7.335573603891078,19.29557165763663 ) ;
  }

  @Test
  public void test2718() {
    coral.tests.JPFBenchmark.benchmark51(7.3485705837036335,12.056351327433271 ) ;
  }

  @Test
  public void test2719() {
    coral.tests.JPFBenchmark.benchmark51(7.3516962437927305,17.357147115187587 ) ;
  }

  @Test
  public void test2720() {
    coral.tests.JPFBenchmark.benchmark51(7.355108993761391,30.580317697241156 ) ;
  }

  @Test
  public void test2721() {
    coral.tests.JPFBenchmark.benchmark51(7.3756907927364495,13.56847410497997 ) ;
  }

  @Test
  public void test2722() {
    coral.tests.JPFBenchmark.benchmark51(7.376471844512494,36.87462880477554 ) ;
  }

  @Test
  public void test2723() {
    coral.tests.JPFBenchmark.benchmark51(7.377080536055132,26.252241619187828 ) ;
  }

  @Test
  public void test2724() {
    coral.tests.JPFBenchmark.benchmark51(7.381124505462495,16.84008802894536 ) ;
  }

  @Test
  public void test2725() {
    coral.tests.JPFBenchmark.benchmark51(7.382848994233534,20.13992801954773 ) ;
  }

  @Test
  public void test2726() {
    coral.tests.JPFBenchmark.benchmark51(7.393880588567299,41.339546473242564 ) ;
  }

  @Test
  public void test2727() {
    coral.tests.JPFBenchmark.benchmark51(7.403126998718548,41.22476850251357 ) ;
  }

  @Test
  public void test2728() {
    coral.tests.JPFBenchmark.benchmark51(7.4094559137640665,28.02734490857224 ) ;
  }

  @Test
  public void test2729() {
    coral.tests.JPFBenchmark.benchmark51(7.41456527820317,19.94267012806567 ) ;
  }

  @Test
  public void test2730() {
    coral.tests.JPFBenchmark.benchmark51(7.428152533213179,10.948708909304244 ) ;
  }

  @Test
  public void test2731() {
    coral.tests.JPFBenchmark.benchmark51(7.428962607951476,33.27670092640648 ) ;
  }

  @Test
  public void test2732() {
    coral.tests.JPFBenchmark.benchmark51(7.429700704038819,29.31750381553678 ) ;
  }

  @Test
  public void test2733() {
    coral.tests.JPFBenchmark.benchmark51(7.43336602134319,38.881927254108774 ) ;
  }

  @Test
  public void test2734() {
    coral.tests.JPFBenchmark.benchmark51(7.4404579586644,16.67959206574396 ) ;
  }

  @Test
  public void test2735() {
    coral.tests.JPFBenchmark.benchmark51(7.44765175803632,25.571847395171076 ) ;
  }

  @Test
  public void test2736() {
    coral.tests.JPFBenchmark.benchmark51(7.453410030813416,29.644624259590017 ) ;
  }

  @Test
  public void test2737() {
    coral.tests.JPFBenchmark.benchmark51(7.461252362519062,19.490366283648157 ) ;
  }

  @Test
  public void test2738() {
    coral.tests.JPFBenchmark.benchmark51(7.497485672462403,34.228900296146236 ) ;
  }

  @Test
  public void test2739() {
    coral.tests.JPFBenchmark.benchmark51(7.501511069974384,11.745386097049717 ) ;
  }

  @Test
  public void test2740() {
    coral.tests.JPFBenchmark.benchmark51(7.504317915410162,20.57008670611431 ) ;
  }

  @Test
  public void test2741() {
    coral.tests.JPFBenchmark.benchmark51(7.508114295269806,40.59447093427548 ) ;
  }

  @Test
  public void test2742() {
    coral.tests.JPFBenchmark.benchmark51(7.512392329228732,35.8424397945887 ) ;
  }

  @Test
  public void test2743() {
    coral.tests.JPFBenchmark.benchmark51(7.5240455745543,38.55180182014273 ) ;
  }

  @Test
  public void test2744() {
    coral.tests.JPFBenchmark.benchmark51(7.533668305935663,33.631484372154205 ) ;
  }

  @Test
  public void test2745() {
    coral.tests.JPFBenchmark.benchmark51(7.539591528845918,20.875701578475983 ) ;
  }

  @Test
  public void test2746() {
    coral.tests.JPFBenchmark.benchmark51(7.539766934487901,34.515320470547266 ) ;
  }

  @Test
  public void test2747() {
    coral.tests.JPFBenchmark.benchmark51(7.576667497871355,35.41940832892871 ) ;
  }

  @Test
  public void test2748() {
    coral.tests.JPFBenchmark.benchmark51(7.5818071334993675,40.31030390632884 ) ;
  }

  @Test
  public void test2749() {
    coral.tests.JPFBenchmark.benchmark51(7.591714664277333,41.80479232026471 ) ;
  }

  @Test
  public void test2750() {
    coral.tests.JPFBenchmark.benchmark51(7.592150809832177,41.57733790232854 ) ;
  }

  @Test
  public void test2751() {
    coral.tests.JPFBenchmark.benchmark51(7.603579928954028,21.608897737725908 ) ;
  }

  @Test
  public void test2752() {
    coral.tests.JPFBenchmark.benchmark51(7.6132215475030165,13.599625131186684 ) ;
  }

  @Test
  public void test2753() {
    coral.tests.JPFBenchmark.benchmark51(7.627900199231846,42.37209980076802 ) ;
  }

  @Test
  public void test2754() {
    coral.tests.JPFBenchmark.benchmark51(7.635844099413845,37.11622544454315 ) ;
  }

  @Test
  public void test2755() {
    coral.tests.JPFBenchmark.benchmark51(7.642550416155558,14.821781651911166 ) ;
  }

  @Test
  public void test2756() {
    coral.tests.JPFBenchmark.benchmark51(7.646154529837219,28.595320537775905 ) ;
  }

  @Test
  public void test2757() {
    coral.tests.JPFBenchmark.benchmark51(7.650882024114765,35.87608172588406 ) ;
  }

  @Test
  public void test2758() {
    coral.tests.JPFBenchmark.benchmark51(7.652056729027109,35.85878401018681 ) ;
  }

  @Test
  public void test2759() {
    coral.tests.JPFBenchmark.benchmark51(7.666840415426734,37.117017076833605 ) ;
  }

  @Test
  public void test2760() {
    coral.tests.JPFBenchmark.benchmark51(7.673195288410611,14.693675114138571 ) ;
  }

  @Test
  public void test2761() {
    coral.tests.JPFBenchmark.benchmark51(7.6854474976037395,19.499158791243907 ) ;
  }

  @Test
  public void test2762() {
    coral.tests.JPFBenchmark.benchmark51(7.687382099005021,42.13637751696871 ) ;
  }

  @Test
  public void test2763() {
    coral.tests.JPFBenchmark.benchmark51(7.692413823907174,17.951121413442024 ) ;
  }

  @Test
  public void test2764() {
    coral.tests.JPFBenchmark.benchmark51(7.72116054404378,12.054449885137203 ) ;
  }

  @Test
  public void test2765() {
    coral.tests.JPFBenchmark.benchmark51(7.7522808066515605,41.72700546561379 ) ;
  }

  @Test
  public void test2766() {
    coral.tests.JPFBenchmark.benchmark51(7.756759977961082,30.276395327633878 ) ;
  }

  @Test
  public void test2767() {
    coral.tests.JPFBenchmark.benchmark51(7.761552063977575,18.717109210766665 ) ;
  }

  @Test
  public void test2768() {
    coral.tests.JPFBenchmark.benchmark51(7.766790369471067,16.83351271741836 ) ;
  }

  @Test
  public void test2769() {
    coral.tests.JPFBenchmark.benchmark51(7.77292306675238,31.318680048886222 ) ;
  }

  @Test
  public void test2770() {
    coral.tests.JPFBenchmark.benchmark51(7.775070069326944,21.31566544367078 ) ;
  }

  @Test
  public void test2771() {
    coral.tests.JPFBenchmark.benchmark51(7.784441169649995,25.518450805356466 ) ;
  }

  @Test
  public void test2772() {
    coral.tests.JPFBenchmark.benchmark51(7.786588681159429,34.83022169832978 ) ;
  }

  @Test
  public void test2773() {
    coral.tests.JPFBenchmark.benchmark51(7.798769863484038,23.85535192468673 ) ;
  }

  @Test
  public void test2774() {
    coral.tests.JPFBenchmark.benchmark51(7.80631341607555,39.45978796396352 ) ;
  }

  @Test
  public void test2775() {
    coral.tests.JPFBenchmark.benchmark51(7.8217343550912375,18.927178517278165 ) ;
  }

  @Test
  public void test2776() {
    coral.tests.JPFBenchmark.benchmark51(7.825403352522727,14.719341135416641 ) ;
  }

  @Test
  public void test2777() {
    coral.tests.JPFBenchmark.benchmark51(7.828330205907946,18.711743153618983 ) ;
  }

  @Test
  public void test2778() {
    coral.tests.JPFBenchmark.benchmark51(7.828808405222773,26.91731698087264 ) ;
  }

  @Test
  public void test2779() {
    coral.tests.JPFBenchmark.benchmark51(7.8289127307728865,18.435362650459787 ) ;
  }

  @Test
  public void test2780() {
    coral.tests.JPFBenchmark.benchmark51(7.833687430677784,30.08436792680726 ) ;
  }

  @Test
  public void test2781() {
    coral.tests.JPFBenchmark.benchmark51(7.841389483810772,37.12608670596498 ) ;
  }

  @Test
  public void test2782() {
    coral.tests.JPFBenchmark.benchmark51(7.846964173895552,9.513278901776161 ) ;
  }

  @Test
  public void test2783() {
    coral.tests.JPFBenchmark.benchmark51(7.851289340135125,10.32788352745375 ) ;
  }

  @Test
  public void test2784() {
    coral.tests.JPFBenchmark.benchmark51(7.85176560279308,12.812849666685878 ) ;
  }

  @Test
  public void test2785() {
    coral.tests.JPFBenchmark.benchmark51(7.8616957451378235,14.379361069203167 ) ;
  }

  @Test
  public void test2786() {
    coral.tests.JPFBenchmark.benchmark51(7.870027827558104,17.894648687089855 ) ;
  }

  @Test
  public void test2787() {
    coral.tests.JPFBenchmark.benchmark51(7.871450815263387,36.17050738015385 ) ;
  }

  @Test
  public void test2788() {
    coral.tests.JPFBenchmark.benchmark51(7.872316274848927,20.307450985332544 ) ;
  }

  @Test
  public void test2789() {
    coral.tests.JPFBenchmark.benchmark51(7.875755840431722,15.248046072137143 ) ;
  }

  @Test
  public void test2790() {
    coral.tests.JPFBenchmark.benchmark51(7.893671352689651,40.17663243668051 ) ;
  }

  @Test
  public void test2791() {
    coral.tests.JPFBenchmark.benchmark51(7.912120530264801,39.80386424715235 ) ;
  }

  @Test
  public void test2792() {
    coral.tests.JPFBenchmark.benchmark51(7.923515617968604,36.192894095778655 ) ;
  }

  @Test
  public void test2793() {
    coral.tests.JPFBenchmark.benchmark51(7.928756900365613,42.07124309963427 ) ;
  }

  @Test
  public void test2794() {
    coral.tests.JPFBenchmark.benchmark51(7.9290920637771904,40.86637932851204 ) ;
  }

  @Test
  public void test2795() {
    coral.tests.JPFBenchmark.benchmark51(7.930759393705046,12.039041905935719 ) ;
  }

  @Test
  public void test2796() {
    coral.tests.JPFBenchmark.benchmark51(7.946614520918767,10.843841148633103 ) ;
  }

  @Test
  public void test2797() {
    coral.tests.JPFBenchmark.benchmark51(7.951764699470431,32.62148716595331 ) ;
  }

  @Test
  public void test2798() {
    coral.tests.JPFBenchmark.benchmark51(7.964374229181512,19.408957991585325 ) ;
  }

  @Test
  public void test2799() {
    coral.tests.JPFBenchmark.benchmark51(7.964404368312003,20.030875861554705 ) ;
  }

  @Test
  public void test2800() {
    coral.tests.JPFBenchmark.benchmark51(7.971763905510713,31.37252123524007 ) ;
  }

  @Test
  public void test2801() {
    coral.tests.JPFBenchmark.benchmark51(7.973723436964349,35.583951001603566 ) ;
  }

  @Test
  public void test2802() {
    coral.tests.JPFBenchmark.benchmark51(7.976247296113698,15.594162495771613 ) ;
  }

  @Test
  public void test2803() {
    coral.tests.JPFBenchmark.benchmark51(7.978611673418696,32.306194651104704 ) ;
  }

  @Test
  public void test2804() {
    coral.tests.JPFBenchmark.benchmark51(7.9860469884959215,35.45459320548284 ) ;
  }

  @Test
  public void test2805() {
    coral.tests.JPFBenchmark.benchmark51(7.988236861208975,12.106083097749746 ) ;
  }

  @Test
  public void test2806() {
    coral.tests.JPFBenchmark.benchmark51(7.989453136168365,17.843668898380784 ) ;
  }

  @Test
  public void test2807() {
    coral.tests.JPFBenchmark.benchmark51(8.007269688940255,9.356036531639589 ) ;
  }

  @Test
  public void test2808() {
    coral.tests.JPFBenchmark.benchmark51(8.012669377003096,10.433852897969583 ) ;
  }

  @Test
  public void test2809() {
    coral.tests.JPFBenchmark.benchmark51(8.019217665829316,11.963712159770807 ) ;
  }

  @Test
  public void test2810() {
    coral.tests.JPFBenchmark.benchmark51(8.028529711913919,36.4413290276411 ) ;
  }

  @Test
  public void test2811() {
    coral.tests.JPFBenchmark.benchmark51(8.029099036722798,28.690353314145483 ) ;
  }

  @Test
  public void test2812() {
    coral.tests.JPFBenchmark.benchmark51(8.039894345292623,28.059644930446012 ) ;
  }

  @Test
  public void test2813() {
    coral.tests.JPFBenchmark.benchmark51(8.041695090908348,22.057753755381242 ) ;
  }

  @Test
  public void test2814() {
    coral.tests.JPFBenchmark.benchmark51(8.044097731689021,33.863911735467155 ) ;
  }

  @Test
  public void test2815() {
    coral.tests.JPFBenchmark.benchmark51(8.055318342414836,27.671725582127245 ) ;
  }

  @Test
  public void test2816() {
    coral.tests.JPFBenchmark.benchmark51(8.055368437953843,21.584598819501835 ) ;
  }

  @Test
  public void test2817() {
    coral.tests.JPFBenchmark.benchmark51(8.056310707233003,14.236593520693209 ) ;
  }

  @Test
  public void test2818() {
    coral.tests.JPFBenchmark.benchmark51(8.060254170229953,11.713589059821345 ) ;
  }

  @Test
  public void test2819() {
    coral.tests.JPFBenchmark.benchmark51(8.062238877475352,16.234512725887313 ) ;
  }

  @Test
  public void test2820() {
    coral.tests.JPFBenchmark.benchmark51(8.066005393944181,40.39470750450701 ) ;
  }

  @Test
  public void test2821() {
    coral.tests.JPFBenchmark.benchmark51(8.067977198458848,26.941718829284113 ) ;
  }

  @Test
  public void test2822() {
    coral.tests.JPFBenchmark.benchmark51(8.077965659900116,25.034274366731097 ) ;
  }

  @Test
  public void test2823() {
    coral.tests.JPFBenchmark.benchmark51(8.093069188850285,10.067324936002265 ) ;
  }

  @Test
  public void test2824() {
    coral.tests.JPFBenchmark.benchmark51(8.095924950180574,20.074823322023633 ) ;
  }

  @Test
  public void test2825() {
    coral.tests.JPFBenchmark.benchmark51(8.09791302809748,9.906525835664311 ) ;
  }

  @Test
  public void test2826() {
    coral.tests.JPFBenchmark.benchmark51(8.10429969126875,41.345990433079834 ) ;
  }

  @Test
  public void test2827() {
    coral.tests.JPFBenchmark.benchmark51(8.106338237589569,33.62715414117807 ) ;
  }

  @Test
  public void test2828() {
    coral.tests.JPFBenchmark.benchmark51(8.10793381820223,9.823708052427216 ) ;
  }

  @Test
  public void test2829() {
    coral.tests.JPFBenchmark.benchmark51(8.114637653770188,14.420754952722902 ) ;
  }

  @Test
  public void test2830() {
    coral.tests.JPFBenchmark.benchmark51(8.114884754771545,19.461105824515585 ) ;
  }

  @Test
  public void test2831() {
    coral.tests.JPFBenchmark.benchmark51(8.12868188055414,16.16399687356595 ) ;
  }

  @Test
  public void test2832() {
    coral.tests.JPFBenchmark.benchmark51(8.132759003498478,31.837072670109677 ) ;
  }

  @Test
  public void test2833() {
    coral.tests.JPFBenchmark.benchmark51(8.133424575931116,33.77787509581037 ) ;
  }

  @Test
  public void test2834() {
    coral.tests.JPFBenchmark.benchmark51(8.134923504676479,24.88173159649476 ) ;
  }

  @Test
  public void test2835() {
    coral.tests.JPFBenchmark.benchmark51(8.135783138487326,30.150695378623965 ) ;
  }

  @Test
  public void test2836() {
    coral.tests.JPFBenchmark.benchmark51(8.136113536954397,26.6366467692919 ) ;
  }

  @Test
  public void test2837() {
    coral.tests.JPFBenchmark.benchmark51(8.138184804359042,41.626604315548576 ) ;
  }

  @Test
  public void test2838() {
    coral.tests.JPFBenchmark.benchmark51(8.142028021022174,21.246247329907646 ) ;
  }

  @Test
  public void test2839() {
    coral.tests.JPFBenchmark.benchmark51(8.144421705126192,40.027134549057564 ) ;
  }

  @Test
  public void test2840() {
    coral.tests.JPFBenchmark.benchmark51(8.148476584218457,30.289624098386497 ) ;
  }

  @Test
  public void test2841() {
    coral.tests.JPFBenchmark.benchmark51(8.152197182282366,21.719598323698122 ) ;
  }

  @Test
  public void test2842() {
    coral.tests.JPFBenchmark.benchmark51(8.152345890155189,37.250367097479995 ) ;
  }

  @Test
  public void test2843() {
    coral.tests.JPFBenchmark.benchmark51(8.152725643354616,17.138769702889746 ) ;
  }

  @Test
  public void test2844() {
    coral.tests.JPFBenchmark.benchmark51(8.162547236147464,32.80482591521299 ) ;
  }

  @Test
  public void test2845() {
    coral.tests.JPFBenchmark.benchmark51(8.163374042077592,24.147572922368752 ) ;
  }

  @Test
  public void test2846() {
    coral.tests.JPFBenchmark.benchmark51(8.16842837369543,32.61150753706019 ) ;
  }

  @Test
  public void test2847() {
    coral.tests.JPFBenchmark.benchmark51(8.184455283245603,34.51907112399866 ) ;
  }

  @Test
  public void test2848() {
    coral.tests.JPFBenchmark.benchmark51(8.186169344806558,36.73645720853787 ) ;
  }

  @Test
  public void test2849() {
    coral.tests.JPFBenchmark.benchmark51(8.186663608796465,35.57417195834866 ) ;
  }

  @Test
  public void test2850() {
    coral.tests.JPFBenchmark.benchmark51(8.187875450501195,39.1627132361065 ) ;
  }

  @Test
  public void test2851() {
    coral.tests.JPFBenchmark.benchmark51(8.188781744725418,22.082130476063867 ) ;
  }

  @Test
  public void test2852() {
    coral.tests.JPFBenchmark.benchmark51(8.190571284608101,10.460394058495524 ) ;
  }

  @Test
  public void test2853() {
    coral.tests.JPFBenchmark.benchmark51(8.19155635502544,34.35198518796281 ) ;
  }

  @Test
  public void test2854() {
    coral.tests.JPFBenchmark.benchmark51(8.192946378598387,26.261752867823766 ) ;
  }

  @Test
  public void test2855() {
    coral.tests.JPFBenchmark.benchmark51(8.193820444661611,36.85427328908767 ) ;
  }

  @Test
  public void test2856() {
    coral.tests.JPFBenchmark.benchmark51(8.211366488810679,41.78863351118912 ) ;
  }

  @Test
  public void test2857() {
    coral.tests.JPFBenchmark.benchmark51(8.211925518509602,13.07969954089721 ) ;
  }

  @Test
  public void test2858() {
    coral.tests.JPFBenchmark.benchmark51(8.212107152496586,23.640972970609198 ) ;
  }

  @Test
  public void test2859() {
    coral.tests.JPFBenchmark.benchmark51(8.213123491670242,33.12725477958133 ) ;
  }

  @Test
  public void test2860() {
    coral.tests.JPFBenchmark.benchmark51(8.216712624954852,10.671885773017124 ) ;
  }

  @Test
  public void test2861() {
    coral.tests.JPFBenchmark.benchmark51(8.221492077542479,41.67842254685192 ) ;
  }

  @Test
  public void test2862() {
    coral.tests.JPFBenchmark.benchmark51(8.230796880170317,15.491289944936028 ) ;
  }

  @Test
  public void test2863() {
    coral.tests.JPFBenchmark.benchmark51(8.233098638381932,37.62674357848249 ) ;
  }

  @Test
  public void test2864() {
    coral.tests.JPFBenchmark.benchmark51(8.235136115997499,19.933601677544544 ) ;
  }

  @Test
  public void test2865() {
    coral.tests.JPFBenchmark.benchmark51(8.238933431950727,19.391761684749213 ) ;
  }

  @Test
  public void test2866() {
    coral.tests.JPFBenchmark.benchmark51(8.245658781987217,16.38968835956689 ) ;
  }

  @Test
  public void test2867() {
    coral.tests.JPFBenchmark.benchmark51(8.255273275816847,21.197774583784906 ) ;
  }

  @Test
  public void test2868() {
    coral.tests.JPFBenchmark.benchmark51(8.258769494283833,13.165905568107053 ) ;
  }

  @Test
  public void test2869() {
    coral.tests.JPFBenchmark.benchmark51(8.261308349548514,14.36313685044675 ) ;
  }

  @Test
  public void test2870() {
    coral.tests.JPFBenchmark.benchmark51(8.266783561307136,12.667529162479191 ) ;
  }

  @Test
  public void test2871() {
    coral.tests.JPFBenchmark.benchmark51(8.270098277582605,32.181983540988625 ) ;
  }

  @Test
  public void test2872() {
    coral.tests.JPFBenchmark.benchmark51(8.27169078139785,32.35055413725371 ) ;
  }

  @Test
  public void test2873() {
    coral.tests.JPFBenchmark.benchmark51(8.27759228801564,23.067444353605325 ) ;
  }

  @Test
  public void test2874() {
    coral.tests.JPFBenchmark.benchmark51(8.284845720317492,30.925660079609912 ) ;
  }

  @Test
  public void test2875() {
    coral.tests.JPFBenchmark.benchmark51(8.29588129555836,30.096673152696468 ) ;
  }

  @Test
  public void test2876() {
    coral.tests.JPFBenchmark.benchmark51(8.303266088239653,11.07209773101745 ) ;
  }

  @Test
  public void test2877() {
    coral.tests.JPFBenchmark.benchmark51(8.304449042952589,13.987689071918444 ) ;
  }

  @Test
  public void test2878() {
    coral.tests.JPFBenchmark.benchmark51(8.309641502314065,36.80281078379056 ) ;
  }

  @Test
  public void test2879() {
    coral.tests.JPFBenchmark.benchmark51(8.314853361118047,33.134715690040345 ) ;
  }

  @Test
  public void test2880() {
    coral.tests.JPFBenchmark.benchmark51(8.32264810992504,34.198562806638165 ) ;
  }

  @Test
  public void test2881() {
    coral.tests.JPFBenchmark.benchmark51(8.323122795626688,12.855319316786094 ) ;
  }

  @Test
  public void test2882() {
    coral.tests.JPFBenchmark.benchmark51(8.334210265304947,32.94417784967558 ) ;
  }

  @Test
  public void test2883() {
    coral.tests.JPFBenchmark.benchmark51(8.34713354466183,17.37067554302527 ) ;
  }

  @Test
  public void test2884() {
    coral.tests.JPFBenchmark.benchmark51(8.375270055310745,41.18928353499291 ) ;
  }

  @Test
  public void test2885() {
    coral.tests.JPFBenchmark.benchmark51(8.380646571900902,18.72660016548058 ) ;
  }

  @Test
  public void test2886() {
    coral.tests.JPFBenchmark.benchmark51(8.391703769477772,14.781643695143359 ) ;
  }

  @Test
  public void test2887() {
    coral.tests.JPFBenchmark.benchmark51(8.401944115972128,24.691362757978094 ) ;
  }

  @Test
  public void test2888() {
    coral.tests.JPFBenchmark.benchmark51(8.402934678153272,13.17592673949602 ) ;
  }

  @Test
  public void test2889() {
    coral.tests.JPFBenchmark.benchmark51(8.408580135798587,37.47197313469232 ) ;
  }

  @Test
  public void test2890() {
    coral.tests.JPFBenchmark.benchmark51(8.410033599564358,21.626669712738305 ) ;
  }

  @Test
  public void test2891() {
    coral.tests.JPFBenchmark.benchmark51(8.417157103086609,16.177086177905764 ) ;
  }

  @Test
  public void test2892() {
    coral.tests.JPFBenchmark.benchmark51(8.423651822796273,39.46542799454116 ) ;
  }

  @Test
  public void test2893() {
    coral.tests.JPFBenchmark.benchmark51(8.427950217002405,34.89155940438087 ) ;
  }

  @Test
  public void test2894() {
    coral.tests.JPFBenchmark.benchmark51(8.43893514697524,12.899914761796442 ) ;
  }

  @Test
  public void test2895() {
    coral.tests.JPFBenchmark.benchmark51(8.44944496983861,36.981762601969024 ) ;
  }

  @Test
  public void test2896() {
    coral.tests.JPFBenchmark.benchmark51(8.463949293316801,9.983982497987398 ) ;
  }

  @Test
  public void test2897() {
    coral.tests.JPFBenchmark.benchmark51(8.468764807638536,9.934003590272582 ) ;
  }

  @Test
  public void test2898() {
    coral.tests.JPFBenchmark.benchmark51(8.475965416031427,12.49801173458124 ) ;
  }

  @Test
  public void test2899() {
    coral.tests.JPFBenchmark.benchmark51(8.490597644768187,27.415266405174535 ) ;
  }

  @Test
  public void test2900() {
    coral.tests.JPFBenchmark.benchmark51(8.492883368093104,33.36255863201555 ) ;
  }

  @Test
  public void test2901() {
    coral.tests.JPFBenchmark.benchmark51(8.501173810211355,12.282778822590387 ) ;
  }

  @Test
  public void test2902() {
    coral.tests.JPFBenchmark.benchmark51(8.503416905744501,29.039558584283355 ) ;
  }

  @Test
  public void test2903() {
    coral.tests.JPFBenchmark.benchmark51(8.503993650570113,12.02489574405876 ) ;
  }

  @Test
  public void test2904() {
    coral.tests.JPFBenchmark.benchmark51(8.514360953302784,16.437785655019127 ) ;
  }

  @Test
  public void test2905() {
    coral.tests.JPFBenchmark.benchmark51(8.515774962206356,35.319651058988 ) ;
  }

  @Test
  public void test2906() {
    coral.tests.JPFBenchmark.benchmark51(8.516633946355583,17.948075867696517 ) ;
  }

  @Test
  public void test2907() {
    coral.tests.JPFBenchmark.benchmark51(8.524734869885805,26.077050111186466 ) ;
  }

  @Test
  public void test2908() {
    coral.tests.JPFBenchmark.benchmark51(8.529171303555216,39.16010650641172 ) ;
  }

  @Test
  public void test2909() {
    coral.tests.JPFBenchmark.benchmark51(8.537343170574374,27.304812620145526 ) ;
  }

  @Test
  public void test2910() {
    coral.tests.JPFBenchmark.benchmark51(8.542940748865139,38.98045769462586 ) ;
  }

  @Test
  public void test2911() {
    coral.tests.JPFBenchmark.benchmark51(8.55285687189159,33.77696654719547 ) ;
  }

  @Test
  public void test2912() {
    coral.tests.JPFBenchmark.benchmark51(8.554337060483704,18.18841655756505 ) ;
  }

  @Test
  public void test2913() {
    coral.tests.JPFBenchmark.benchmark51(8.559012254036418,32.74251420122988 ) ;
  }

  @Test
  public void test2914() {
    coral.tests.JPFBenchmark.benchmark51(8.562990513201598,24.6382805022362 ) ;
  }

  @Test
  public void test2915() {
    coral.tests.JPFBenchmark.benchmark51(8.5664821938647,39.890734544026486 ) ;
  }

  @Test
  public void test2916() {
    coral.tests.JPFBenchmark.benchmark51(8.573302844904438,34.11294392084264 ) ;
  }

  @Test
  public void test2917() {
    coral.tests.JPFBenchmark.benchmark51(8.577120985116096,10.365733095018669 ) ;
  }

  @Test
  public void test2918() {
    coral.tests.JPFBenchmark.benchmark51(8.581918661458547,41.41808133854145 ) ;
  }

  @Test
  public void test2919() {
    coral.tests.JPFBenchmark.benchmark51(8.584521321135583,36.72493398535735 ) ;
  }

  @Test
  public void test2920() {
    coral.tests.JPFBenchmark.benchmark51(8.595148786381813,39.39725997113365 ) ;
  }

  @Test
  public void test2921() {
    coral.tests.JPFBenchmark.benchmark51(8.598422948959524,25.161885552276544 ) ;
  }

  @Test
  public void test2922() {
    coral.tests.JPFBenchmark.benchmark51(8.598463164019625,10.855341813927907 ) ;
  }

  @Test
  public void test2923() {
    coral.tests.JPFBenchmark.benchmark51(8.603894883732412,13.779307085571398 ) ;
  }

  @Test
  public void test2924() {
    coral.tests.JPFBenchmark.benchmark51(8.609112165670552,25.042842324045637 ) ;
  }

  @Test
  public void test2925() {
    coral.tests.JPFBenchmark.benchmark51(8.6313312712752,23.38256215582497 ) ;
  }

  @Test
  public void test2926() {
    coral.tests.JPFBenchmark.benchmark51(8.645633686162554,16.970220991535285 ) ;
  }

  @Test
  public void test2927() {
    coral.tests.JPFBenchmark.benchmark51(8.659581106499672,10.450308955449955 ) ;
  }

  @Test
  public void test2928() {
    coral.tests.JPFBenchmark.benchmark51(8.674056492542334,24.086255965796184 ) ;
  }

  @Test
  public void test2929() {
    coral.tests.JPFBenchmark.benchmark51(8.679208090961714,13.076302279619597 ) ;
  }

  @Test
  public void test2930() {
    coral.tests.JPFBenchmark.benchmark51(8.704528752227986,15.857381397062113 ) ;
  }

  @Test
  public void test2931() {
    coral.tests.JPFBenchmark.benchmark51(8.706426487909937,37.31147163200504 ) ;
  }

  @Test
  public void test2932() {
    coral.tests.JPFBenchmark.benchmark51(8.712547296394789,19.05513401736762 ) ;
  }

  @Test
  public void test2933() {
    coral.tests.JPFBenchmark.benchmark51(8.723118740016972,35.17428893348665 ) ;
  }

  @Test
  public void test2934() {
    coral.tests.JPFBenchmark.benchmark51(8.723793316565633,27.751628524533743 ) ;
  }

  @Test
  public void test2935() {
    coral.tests.JPFBenchmark.benchmark51(8.72683376205379,14.780660657186566 ) ;
  }

  @Test
  public void test2936() {
    coral.tests.JPFBenchmark.benchmark51(8.731334519320953,10.067929378843132 ) ;
  }

  @Test
  public void test2937() {
    coral.tests.JPFBenchmark.benchmark51(8.741133202543352,33.7972587968774 ) ;
  }

  @Test
  public void test2938() {
    coral.tests.JPFBenchmark.benchmark51(8.744423283759346,33.51402659752628 ) ;
  }

  @Test
  public void test2939() {
    coral.tests.JPFBenchmark.benchmark51(8.746697749537603,16.05897578706022 ) ;
  }

  @Test
  public void test2940() {
    coral.tests.JPFBenchmark.benchmark51(8.74818547421603,31.302760328165732 ) ;
  }

  @Test
  public void test2941() {
    coral.tests.JPFBenchmark.benchmark51(8.751783921137047,38.77684967296594 ) ;
  }

  @Test
  public void test2942() {
    coral.tests.JPFBenchmark.benchmark51(8.755965944975102,35.51702036825927 ) ;
  }

  @Test
  public void test2943() {
    coral.tests.JPFBenchmark.benchmark51(8.75788193486828,13.438392728518991 ) ;
  }

  @Test
  public void test2944() {
    coral.tests.JPFBenchmark.benchmark51(8.767404812610307,28.324019831114914 ) ;
  }

  @Test
  public void test2945() {
    coral.tests.JPFBenchmark.benchmark51(8.772752802840017,32.91865373982591 ) ;
  }

  @Test
  public void test2946() {
    coral.tests.JPFBenchmark.benchmark51(8.776656734352372,21.41856788651721 ) ;
  }

  @Test
  public void test2947() {
    coral.tests.JPFBenchmark.benchmark51(8.778001946599318,16.721065167857745 ) ;
  }

  @Test
  public void test2948() {
    coral.tests.JPFBenchmark.benchmark51(8.784720380194273,14.933537269689651 ) ;
  }

  @Test
  public void test2949() {
    coral.tests.JPFBenchmark.benchmark51(8.790528186064222,26.30744289887268 ) ;
  }

  @Test
  public void test2950() {
    coral.tests.JPFBenchmark.benchmark51(8.790578563012645,36.94711422239888 ) ;
  }

  @Test
  public void test2951() {
    coral.tests.JPFBenchmark.benchmark51(8.792783255867903,40.21826385800233 ) ;
  }

  @Test
  public void test2952() {
    coral.tests.JPFBenchmark.benchmark51(8.799768855978371,14.226458964042692 ) ;
  }

  @Test
  public void test2953() {
    coral.tests.JPFBenchmark.benchmark51(8.809604993837269,12.087039132042747 ) ;
  }

  @Test
  public void test2954() {
    coral.tests.JPFBenchmark.benchmark51(8.825071543383672,10.384152754990268 ) ;
  }

  @Test
  public void test2955() {
    coral.tests.JPFBenchmark.benchmark51(8.82980447133251,15.194229324741599 ) ;
  }

  @Test
  public void test2956() {
    coral.tests.JPFBenchmark.benchmark51(8.860279312766266,12.77151373473528 ) ;
  }

  @Test
  public void test2957() {
    coral.tests.JPFBenchmark.benchmark51(8.888047308131986,21.722364000147948 ) ;
  }

  @Test
  public void test2958() {
    coral.tests.JPFBenchmark.benchmark51(8.888178205971116,18.852045616137644 ) ;
  }

  @Test
  public void test2959() {
    coral.tests.JPFBenchmark.benchmark51(8.916413132602951,13.385046635568386 ) ;
  }

  @Test
  public void test2960() {
    coral.tests.JPFBenchmark.benchmark51(8.918204293579606,24.903818853272597 ) ;
  }

  @Test
  public void test2961() {
    coral.tests.JPFBenchmark.benchmark51(8.934606746459522,34.27668152018987 ) ;
  }

  @Test
  public void test2962() {
    coral.tests.JPFBenchmark.benchmark51(8.941094804312954,19.3361895269405 ) ;
  }

  @Test
  public void test2963() {
    coral.tests.JPFBenchmark.benchmark51(8.942369422270872,27.022176784136803 ) ;
  }

  @Test
  public void test2964() {
    coral.tests.JPFBenchmark.benchmark51(8.950213924188517,17.02978967967348 ) ;
  }

  @Test
  public void test2965() {
    coral.tests.JPFBenchmark.benchmark51(8.962801979544542,26.779434986448422 ) ;
  }

  @Test
  public void test2966() {
    coral.tests.JPFBenchmark.benchmark51(8.974788097019061,33.510628777971306 ) ;
  }

  @Test
  public void test2967() {
    coral.tests.JPFBenchmark.benchmark51(8.980536706170113,29.914542081901573 ) ;
  }

  @Test
  public void test2968() {
    coral.tests.JPFBenchmark.benchmark51(8.984861010376505,30.506847761654626 ) ;
  }

  @Test
  public void test2969() {
    coral.tests.JPFBenchmark.benchmark51(8.986988157234975,13.68196891948574 ) ;
  }

  @Test
  public void test2970() {
    coral.tests.JPFBenchmark.benchmark51(8.993064124624254,25.29950211521343 ) ;
  }

  @Test
  public void test2971() {
    coral.tests.JPFBenchmark.benchmark51(9.011139128711562,18.230878150367886 ) ;
  }

  @Test
  public void test2972() {
    coral.tests.JPFBenchmark.benchmark51(9.022827424103923,14.98413421633198 ) ;
  }

  @Test
  public void test2973() {
    coral.tests.JPFBenchmark.benchmark51(9.023111358321387,16.502201393210484 ) ;
  }

  @Test
  public void test2974() {
    coral.tests.JPFBenchmark.benchmark51(9.027614818113454,11.57904826348721 ) ;
  }

  @Test
  public void test2975() {
    coral.tests.JPFBenchmark.benchmark51(9.028074912566339,23.064498715281402 ) ;
  }

  @Test
  public void test2976() {
    coral.tests.JPFBenchmark.benchmark51(9.032874622129654,15.16531056674117 ) ;
  }

  @Test
  public void test2977() {
    coral.tests.JPFBenchmark.benchmark51(9.043676957890462,13.866016542141802 ) ;
  }

  @Test
  public void test2978() {
    coral.tests.JPFBenchmark.benchmark51(9.050538833199894,16.548572228606453 ) ;
  }

  @Test
  public void test2979() {
    coral.tests.JPFBenchmark.benchmark51(9.060949066583234,23.053405779947383 ) ;
  }

  @Test
  public void test2980() {
    coral.tests.JPFBenchmark.benchmark51(9.061691958171124,25.225416702413554 ) ;
  }

  @Test
  public void test2981() {
    coral.tests.JPFBenchmark.benchmark51(9.07091267164159,39.93667264914953 ) ;
  }

  @Test
  public void test2982() {
    coral.tests.JPFBenchmark.benchmark51(9.075208175607543,20.412917705539726 ) ;
  }

  @Test
  public void test2983() {
    coral.tests.JPFBenchmark.benchmark51(9.079035923148052,40.92096407685193 ) ;
  }

  @Test
  public void test2984() {
    coral.tests.JPFBenchmark.benchmark51(9.098779803572981,30.234404414765294 ) ;
  }

  @Test
  public void test2985() {
    coral.tests.JPFBenchmark.benchmark51(9.108439014733904,39.681227995652534 ) ;
  }

  @Test
  public void test2986() {
    coral.tests.JPFBenchmark.benchmark51(9.109385918843955,24.081445152893835 ) ;
  }

  @Test
  public void test2987() {
    coral.tests.JPFBenchmark.benchmark51(9.120128139806383,17.406828788941326 ) ;
  }

  @Test
  public void test2988() {
    coral.tests.JPFBenchmark.benchmark51(9.121230464842707,17.604301923827208 ) ;
  }

  @Test
  public void test2989() {
    coral.tests.JPFBenchmark.benchmark51(9.124367545940032,14.644441637458613 ) ;
  }

  @Test
  public void test2990() {
    coral.tests.JPFBenchmark.benchmark51(9.127712426695368,19.18135331281445 ) ;
  }

  @Test
  public void test2991() {
    coral.tests.JPFBenchmark.benchmark51(9.132940816140803,40.86705918385906 ) ;
  }

  @Test
  public void test2992() {
    coral.tests.JPFBenchmark.benchmark51(9.136204939973268,38.70502696096972 ) ;
  }

  @Test
  public void test2993() {
    coral.tests.JPFBenchmark.benchmark51(9.13794346319034,10.208512154540715 ) ;
  }

  @Test
  public void test2994() {
    coral.tests.JPFBenchmark.benchmark51(9.14673360488365,40.25903843627813 ) ;
  }

  @Test
  public void test2995() {
    coral.tests.JPFBenchmark.benchmark51(9.164427340047652,32.09719932142846 ) ;
  }

  @Test
  public void test2996() {
    coral.tests.JPFBenchmark.benchmark51(9.17029130753859,10.217127002037758 ) ;
  }

  @Test
  public void test2997() {
    coral.tests.JPFBenchmark.benchmark51(9.174582135768006,25.538009455792874 ) ;
  }

  @Test
  public void test2998() {
    coral.tests.JPFBenchmark.benchmark51(9.178789060187171,24.03271592131145 ) ;
  }

  @Test
  public void test2999() {
    coral.tests.JPFBenchmark.benchmark51(9.195737384116072,14.120939897302563 ) ;
  }

  @Test
  public void test3000() {
    coral.tests.JPFBenchmark.benchmark51(9.197181127429204,35.01925082317473 ) ;
  }

  @Test
  public void test3001() {
    coral.tests.JPFBenchmark.benchmark51(9.208075655792271,30.979816148671347 ) ;
  }

  @Test
  public void test3002() {
    coral.tests.JPFBenchmark.benchmark51(9.210952149047486,33.23395931038377 ) ;
  }

  @Test
  public void test3003() {
    coral.tests.JPFBenchmark.benchmark51(9.218226855165085,33.986206810960795 ) ;
  }

  @Test
  public void test3004() {
    coral.tests.JPFBenchmark.benchmark51(9.235027619569408,32.03676009304911 ) ;
  }

  @Test
  public void test3005() {
    coral.tests.JPFBenchmark.benchmark51(-92.36763276910128,0 ) ;
  }

  @Test
  public void test3006() {
    coral.tests.JPFBenchmark.benchmark51(9.238770658691962,19.322484584604922 ) ;
  }

  @Test
  public void test3007() {
    coral.tests.JPFBenchmark.benchmark51(9.244828239680714,13.01697593882669 ) ;
  }

  @Test
  public void test3008() {
    coral.tests.JPFBenchmark.benchmark51(9.246179541388116,10.669609077552636 ) ;
  }

  @Test
  public void test3009() {
    coral.tests.JPFBenchmark.benchmark51(9.24983071391767,32.330909854209324 ) ;
  }

  @Test
  public void test3010() {
    coral.tests.JPFBenchmark.benchmark51(9.256546819064695,22.356987674941124 ) ;
  }

  @Test
  public void test3011() {
    coral.tests.JPFBenchmark.benchmark51(9.265819663041157,20.266010174693164 ) ;
  }

  @Test
  public void test3012() {
    coral.tests.JPFBenchmark.benchmark51(9.268370566586754,18.00337183485101 ) ;
  }

  @Test
  public void test3013() {
    coral.tests.JPFBenchmark.benchmark51(9.287620275621705,23.699293126735625 ) ;
  }

  @Test
  public void test3014() {
    coral.tests.JPFBenchmark.benchmark51(9.289184959464245,22.899127741236672 ) ;
  }

  @Test
  public void test3015() {
    coral.tests.JPFBenchmark.benchmark51(9.29263774420987,11.641492176386677 ) ;
  }

  @Test
  public void test3016() {
    coral.tests.JPFBenchmark.benchmark51(9.302151479617166,17.641978768865926 ) ;
  }

  @Test
  public void test3017() {
    coral.tests.JPFBenchmark.benchmark51(9.307693317316932,10.382315387347415 ) ;
  }

  @Test
  public void test3018() {
    coral.tests.JPFBenchmark.benchmark51(9.31267602318021,24.238078888405724 ) ;
  }

  @Test
  public void test3019() {
    coral.tests.JPFBenchmark.benchmark51(9.314180833695573,12.369844335741377 ) ;
  }

  @Test
  public void test3020() {
    coral.tests.JPFBenchmark.benchmark51(9.315705297521546,15.228630859905266 ) ;
  }

  @Test
  public void test3021() {
    coral.tests.JPFBenchmark.benchmark51(9.31926379170352,39.67289128516441 ) ;
  }

  @Test
  public void test3022() {
    coral.tests.JPFBenchmark.benchmark51(9.325371566471995,26.958440453179477 ) ;
  }

  @Test
  public void test3023() {
    coral.tests.JPFBenchmark.benchmark51(9.336609579254443,16.461785152960957 ) ;
  }

  @Test
  public void test3024() {
    coral.tests.JPFBenchmark.benchmark51(9.35003455949564,11.923851858685993 ) ;
  }

  @Test
  public void test3025() {
    coral.tests.JPFBenchmark.benchmark51(9.350946861746419,17.515350305352456 ) ;
  }

  @Test
  public void test3026() {
    coral.tests.JPFBenchmark.benchmark51(9.353582035518485,26.120057928713123 ) ;
  }

  @Test
  public void test3027() {
    coral.tests.JPFBenchmark.benchmark51(9.359331651740476,35.71589043280051 ) ;
  }

  @Test
  public void test3028() {
    coral.tests.JPFBenchmark.benchmark51(9.366684964662198,32.38988700087563 ) ;
  }

  @Test
  public void test3029() {
    coral.tests.JPFBenchmark.benchmark51(9.371337340504965,13.6784079275928 ) ;
  }

  @Test
  public void test3030() {
    coral.tests.JPFBenchmark.benchmark51(9.373278483738574,21.079048852384048 ) ;
  }

  @Test
  public void test3031() {
    coral.tests.JPFBenchmark.benchmark51(9.375120524503702,19.415266219346297 ) ;
  }

  @Test
  public void test3032() {
    coral.tests.JPFBenchmark.benchmark51(9.37920792836691,18.499749898569434 ) ;
  }

  @Test
  public void test3033() {
    coral.tests.JPFBenchmark.benchmark51(9.384398744708605,16.346090166280106 ) ;
  }

  @Test
  public void test3034() {
    coral.tests.JPFBenchmark.benchmark51(9.38671018375388,32.600701586125865 ) ;
  }

  @Test
  public void test3035() {
    coral.tests.JPFBenchmark.benchmark51(9.396657972476149,36.44024791324401 ) ;
  }

  @Test
  public void test3036() {
    coral.tests.JPFBenchmark.benchmark51(9.399810209860576,35.03741385919966 ) ;
  }

  @Test
  public void test3037() {
    coral.tests.JPFBenchmark.benchmark51(9.405682371209252,31.35752288041823 ) ;
  }

  @Test
  public void test3038() {
    coral.tests.JPFBenchmark.benchmark51(9.411548275177779,30.10430217045493 ) ;
  }

  @Test
  public void test3039() {
    coral.tests.JPFBenchmark.benchmark51(9.413121360049232,17.857214658108745 ) ;
  }

  @Test
  public void test3040() {
    coral.tests.JPFBenchmark.benchmark51(9.436348554762162,13.03779978920143 ) ;
  }

  @Test
  public void test3041() {
    coral.tests.JPFBenchmark.benchmark51(9.438099458513502,18.467969784716416 ) ;
  }

  @Test
  public void test3042() {
    coral.tests.JPFBenchmark.benchmark51(9.451698585911998,27.209810297559514 ) ;
  }

  @Test
  public void test3043() {
    coral.tests.JPFBenchmark.benchmark51(9.477012512745105,27.352894015649127 ) ;
  }

  @Test
  public void test3044() {
    coral.tests.JPFBenchmark.benchmark51(9.479740276343023,16.467907709824686 ) ;
  }

  @Test
  public void test3045() {
    coral.tests.JPFBenchmark.benchmark51(9.489128581925627,31.133390802041077 ) ;
  }

  @Test
  public void test3046() {
    coral.tests.JPFBenchmark.benchmark51(9.50793950832174,29.94163386062681 ) ;
  }

  @Test
  public void test3047() {
    coral.tests.JPFBenchmark.benchmark51(9.513366050410058,39.558042779243095 ) ;
  }

  @Test
  public void test3048() {
    coral.tests.JPFBenchmark.benchmark51(9.514067009378806,35.43016008527769 ) ;
  }

  @Test
  public void test3049() {
    coral.tests.JPFBenchmark.benchmark51(9.524307169926445,38.085547270388275 ) ;
  }

  @Test
  public void test3050() {
    coral.tests.JPFBenchmark.benchmark51(9.53471039293478,34.751662875002864 ) ;
  }

  @Test
  public void test3051() {
    coral.tests.JPFBenchmark.benchmark51(9.538274379455473,26.316132745716132 ) ;
  }

  @Test
  public void test3052() {
    coral.tests.JPFBenchmark.benchmark51(9.546675418812345,23.06386876160147 ) ;
  }

  @Test
  public void test3053() {
    coral.tests.JPFBenchmark.benchmark51(9.55137467696747,28.074946419459792 ) ;
  }

  @Test
  public void test3054() {
    coral.tests.JPFBenchmark.benchmark51(9.561870503968496,15.541101092856252 ) ;
  }

  @Test
  public void test3055() {
    coral.tests.JPFBenchmark.benchmark51(9.574240973906882,20.195697906719516 ) ;
  }

  @Test
  public void test3056() {
    coral.tests.JPFBenchmark.benchmark51(9.587280293053382,29.65437478896021 ) ;
  }

  @Test
  public void test3057() {
    coral.tests.JPFBenchmark.benchmark51(9.591855409530254,26.541988462784147 ) ;
  }

  @Test
  public void test3058() {
    coral.tests.JPFBenchmark.benchmark51(9.594857478599621,11.26862613890603 ) ;
  }

  @Test
  public void test3059() {
    coral.tests.JPFBenchmark.benchmark51(9.59748553181312,33.91493537309805 ) ;
  }

  @Test
  public void test3060() {
    coral.tests.JPFBenchmark.benchmark51(9.599618996415018,33.07478080108629 ) ;
  }

  @Test
  public void test3061() {
    coral.tests.JPFBenchmark.benchmark51(9.62144197335273,31.160384338167063 ) ;
  }

  @Test
  public void test3062() {
    coral.tests.JPFBenchmark.benchmark51(9.62287046406983,40.37712953593015 ) ;
  }

  @Test
  public void test3063() {
    coral.tests.JPFBenchmark.benchmark51(9.6344940510905,40.36550594890949 ) ;
  }

  @Test
  public void test3064() {
    coral.tests.JPFBenchmark.benchmark51(9.64826110108322,28.99561814934637 ) ;
  }

  @Test
  public void test3065() {
    coral.tests.JPFBenchmark.benchmark51(9.649260653972021,19.12851523856935 ) ;
  }

  @Test
  public void test3066() {
    coral.tests.JPFBenchmark.benchmark51(9.652739043248587,21.55461537333572 ) ;
  }

  @Test
  public void test3067() {
    coral.tests.JPFBenchmark.benchmark51(9.662422686786602,13.909014509455716 ) ;
  }

  @Test
  public void test3068() {
    coral.tests.JPFBenchmark.benchmark51(9.666837364006568,37.704957787242364 ) ;
  }

  @Test
  public void test3069() {
    coral.tests.JPFBenchmark.benchmark51(9.668202666175759,28.35369476989814 ) ;
  }

  @Test
  public void test3070() {
    coral.tests.JPFBenchmark.benchmark51(9.698675753279232,37.39978632805432 ) ;
  }

  @Test
  public void test3071() {
    coral.tests.JPFBenchmark.benchmark51(9.70092622404171,13.934643159038316 ) ;
  }

  @Test
  public void test3072() {
    coral.tests.JPFBenchmark.benchmark51(9.703639729783077,13.029404425625815 ) ;
  }

  @Test
  public void test3073() {
    coral.tests.JPFBenchmark.benchmark51(9.708583862362559,25.378596824329875 ) ;
  }

  @Test
  public void test3074() {
    coral.tests.JPFBenchmark.benchmark51(9.723418655782893,29.79540662143711 ) ;
  }

  @Test
  public void test3075() {
    coral.tests.JPFBenchmark.benchmark51(9.72378878642651E-9,0 ) ;
  }

  @Test
  public void test3076() {
    coral.tests.JPFBenchmark.benchmark51(9.726183580582259,20.168343992293615 ) ;
  }

  @Test
  public void test3077() {
    coral.tests.JPFBenchmark.benchmark51(9.731628327333198,12.776690682200627 ) ;
  }

  @Test
  public void test3078() {
    coral.tests.JPFBenchmark.benchmark51(9.737669402079248,37.75504778526536 ) ;
  }

  @Test
  public void test3079() {
    coral.tests.JPFBenchmark.benchmark51(9.748130694139803,19.15668879498635 ) ;
  }

  @Test
  public void test3080() {
    coral.tests.JPFBenchmark.benchmark51(9.753623101300704,30.692173397640204 ) ;
  }

  @Test
  public void test3081() {
    coral.tests.JPFBenchmark.benchmark51(9.753849111212283,38.71856403765238 ) ;
  }

  @Test
  public void test3082() {
    coral.tests.JPFBenchmark.benchmark51(9.756926398650407,18.29492630512894 ) ;
  }

  @Test
  public void test3083() {
    coral.tests.JPFBenchmark.benchmark51(9.771067765208016,34.12168926275706 ) ;
  }

  @Test
  public void test3084() {
    coral.tests.JPFBenchmark.benchmark51(9.78675408658279,37.69891100261265 ) ;
  }

  @Test
  public void test3085() {
    coral.tests.JPFBenchmark.benchmark51(9.794565446248768,20.210539835078677 ) ;
  }

  @Test
  public void test3086() {
    coral.tests.JPFBenchmark.benchmark51(9.799919959363224,28.80234938978675 ) ;
  }

  @Test
  public void test3087() {
    coral.tests.JPFBenchmark.benchmark51(9.804839922670624,18.828760476930697 ) ;
  }

  @Test
  public void test3088() {
    coral.tests.JPFBenchmark.benchmark51(9.808962661719264,21.7331105018189 ) ;
  }

  @Test
  public void test3089() {
    coral.tests.JPFBenchmark.benchmark51(9.813480450968044,18.56934950248339 ) ;
  }

  @Test
  public void test3090() {
    coral.tests.JPFBenchmark.benchmark51(9.8189193863738,21.29939960086996 ) ;
  }

  @Test
  public void test3091() {
    coral.tests.JPFBenchmark.benchmark51(9.827999195256723,25.72861758574099 ) ;
  }

  @Test
  public void test3092() {
    coral.tests.JPFBenchmark.benchmark51(9.830229365080797,34.53757076618942 ) ;
  }

  @Test
  public void test3093() {
    coral.tests.JPFBenchmark.benchmark51(9.830765149904153,17.319209723770328 ) ;
  }

  @Test
  public void test3094() {
    coral.tests.JPFBenchmark.benchmark51(9.836410965496514,12.284310337052759 ) ;
  }

  @Test
  public void test3095() {
    coral.tests.JPFBenchmark.benchmark51(9.840010867416959,22.757332603512495 ) ;
  }

  @Test
  public void test3096() {
    coral.tests.JPFBenchmark.benchmark51(9.85735907744264,40.142640922557355 ) ;
  }

  @Test
  public void test3097() {
    coral.tests.JPFBenchmark.benchmark51(9.86779070003347,40.13220929996609 ) ;
  }

  @Test
  public void test3098() {
    coral.tests.JPFBenchmark.benchmark51(9.869611674683938,15.336447806313132 ) ;
  }

  @Test
  public void test3099() {
    coral.tests.JPFBenchmark.benchmark51(9.886416228151234,15.709049348711005 ) ;
  }

  @Test
  public void test3100() {
    coral.tests.JPFBenchmark.benchmark51(9.90888713811038,18.162156516247663 ) ;
  }

  @Test
  public void test3101() {
    coral.tests.JPFBenchmark.benchmark51(9.91804996515502,39.94566133354638 ) ;
  }

  @Test
  public void test3102() {
    coral.tests.JPFBenchmark.benchmark51(9.926176134813574,12.157482222850462 ) ;
  }

  @Test
  public void test3103() {
    coral.tests.JPFBenchmark.benchmark51(9.935508932270153,26.975102384705067 ) ;
  }

  @Test
  public void test3104() {
    coral.tests.JPFBenchmark.benchmark51(9.963323572806743,38.7502102660564 ) ;
  }

  @Test
  public void test3105() {
    coral.tests.JPFBenchmark.benchmark51(9.975112676033149,33.438003538506024 ) ;
  }

  @Test
  public void test3106() {
    coral.tests.JPFBenchmark.benchmark51(9.97660769781588,15.733070642733438 ) ;
  }

  @Test
  public void test3107() {
    coral.tests.JPFBenchmark.benchmark51(9.993572995623893,11.02572795090228 ) ;
  }
}
