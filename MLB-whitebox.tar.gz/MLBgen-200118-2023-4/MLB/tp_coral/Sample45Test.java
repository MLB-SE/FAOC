import org.junit.Test;

public class Sample45Test {

  @Test
  public void test0() {
//    0.6674655214437394;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-647.1176769481931,9.003121294468613 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-648.254012198491,58.923704075069516 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-649.44218725624,59.47676937538802 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-650.938997645846,100.0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-651.6283356544061,100.0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-651.7258660046597,54.54624845143161 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-653.6854257442421,100.0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-654.6892356738126,100.0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-657.0813165277135,100.0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-661.5205315118769,8.100180880168466 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-670.220829157524,100.0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-676.2192060987926,100.0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-680.0676152248717,98.90936128586068 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-680.3491991692514,87.02997025698886 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-701.4023343249457,66.10524056113877 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark45(-102.54971727092003,-649.172635820675,41.138416684365296 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark45(-106.3166530840283,-657.7456685702398,16.550015115299573 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark45(-109.10915553223151,-681.3132749817822,21.44801824251219 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark45(-109.32732608295922,-657.0408962937961,18.328371629459085 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark45(-110.71500003049846,-640.2319254950289,2.0385842373209044 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark45(-111.05627158188395,-646.6186961524448,92.25764405976429 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark45(-111.78915989794687,-653.8895769900521,29.49626688308905 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark45(-112.47487063577869,-635.2450581155887,8.94270046906152 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark45(-113.67951274438693,-652.0546344549717,0.5401762119400644 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark45(-113.76809724366561,-675.146887275571,100.0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark45(-113.83933594392421,-647.8493862442126,31.197371775584372 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark45(-114.06242428305168,-649.6730572959002,3.080224184004692 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark45(-114.35335983060504,-710.7523246563219,29.03812174050202 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark45(-115.3237406315557,-661.5391916493505,100.0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark45(-116.55000988288275,-643.0252047756893,63.647587535442426 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark45(-116.58889714413226,-639.4691671689559,92.52663765612576 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark45(-118.24501846059863,-641.6473437297136,21.717331735438677 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark45(-118.90661155333174,-629.0674872154453,83.33289550605767 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark45(-119.07130462388862,-644.8282314320033,74.5195555954719 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark45(-119.18412755068584,-631.9530340842082,97.62975994100282 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark45(-121.85128918437363,-636.04526834116,46.56944365253588 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark45(-121.85244078137005,-628.079670923752,37.759287702312804 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark45(-121.93041982614437,-664.6382503873458,77.03188438852666 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark45(-122.35219445080034,-633.0630476983381,82.40817896029952 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark45(-124.30025215829929,-621.7628127257888,76.00166063712015 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark45(-124.6926509654998,-627.4995416207864,13.982756524425511 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark45(-125.25902554114299,-632.2944839382759,5.261587500865275 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark45(-127.01064347072048,-638.2971654675488,71.17811252096152 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark45(-127.41968731458685,-683.410081998931,0.9944476934098674 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark45(-128.0896174045011,-635.9538457743341,98.73086030877721 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark45(-128.94554638873115,-624.8420909119477,100.0 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark45(-129.75895225902957,-657.5717632357489,100.0 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark45(-130.24457973155262,-652.1766270793997,80.2615722661526 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark45(-130.2963682012168,-640.1287070642121,23.47906804898527 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark45(-130.63358474005773,-616.2683183749926,59.94131978104778 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark45(-131.03075336491906,-620.7377841491904,100.0 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark45(-131.80281951184708,-624.652112335498,23.136129205815138 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark45(-132.78605811244975,-637.644157269544,72.86342769253218 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark45(-133.00595181345926,-623.018930539749,54.957192467798535 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark45(-133.7121968816768,-640.5610437316782,23.842789886611996 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark45(-134.26470968594168,-625.2047842884167,78.56186340640156 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark45(-135.02847286185755,-632.4628039697072,70.90293149922402 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark45(-137.12726293449074,-613.1331513765542,88.02460019883739 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark45(-137.2798815751351,-624.5426534557763,82.51417451645125 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark45(-137.35110062611682,-648.9345055633992,28.91523537413096 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark45(-137.41024162861294,-618.9984705675282,71.11947783514438 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark45(-137.6185711893807,-645.7308472867793,26.343045421083715 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark45(-138.21513851927858,-663.487673852963,16.083914200922834 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark45(-138.73424805747365,-611.7765567988268,19.7133591633511 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark45(-139.75468725045522,-647.7577521107748,95.31386771937395 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark45(-139.9802915665528,-618.4994142122986,84.76208329277074 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark45(-140.2690015379298,-616.8095559274701,68.10373009886726 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark45(-140.7425017364016,-605.5426438010478,94.01358630956986 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark45(-141.43811038293268,-609.7888006063002,86.44998769958036 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark45(-142.11058630359335,-619.5906272999838,45.732374599969035 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark45(-142.80984518453317,-605.4817447901539,6.855529824456681 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark45(-143.65846643363216,-618.2201147064643,17.343723643459924 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark45(-144.2855778589079,-606.9371426462105,98.75405240918519 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark45(-144.57182325024755,-602.2172605019334,94.0480075811214 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark45(-144.59443397849043,-659.3787396901596,82.16042485703247 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark45(-144.63109380465085,-710.6394395726305,82.55041705994182 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark45(-144.80200520091043,-638.5883693344708,70.92868307326549 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark45(-145.05141787137353,-652.2285641493409,93.84550053098016 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark45(-145.0599380718517,-603.705671853041,50.99376739399872 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark45(-146.64297208181694,-615.4739156908545,71.54857509355134 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark45(-147.05718351752805,-630.4445645617969,39.49644852924004 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark45(-147.11745207872835,-600.7450464056338,86.24401301238385 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark45(-148.61312760094006,-634.6558771103939,16.25409902274481 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark45(-148.7179727450984,-605.6895978931333,12.270584173153452 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark45(-149.43816703176063,-646.1590458789666,20.529130571990166 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark45(-150.8742256422285,-661.9776473836893,45.93251139521635 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark45(-151.28682236259047,-605.8694528964653,77.01047401464086 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark45(-151.32262888273905,-606.6664438221713,100.0 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark45(-152.05692679535065,-626.085165581573,100.0 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark45(-152.46797388864272,-611.2439823619787,44.55038817246603 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark45(-152.53118488810452,-615.183727126212,78.81915985128467 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark45(-152.67705810753097,-635.6524585572396,72.17092904935865 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark45(-152.79960670672745,-643.7877653863663,66.43072035266655 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark45(-152.84195569107092,-621.7201694307576,17.34087778118368 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark45(-153.64349001957234,-612.6014266384524,25.000698405722403 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark45(-153.87882419067427,-618.7707569382989,100.0 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark45(-153.9989179670758,-645.0964159385871,60.63727697876314 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark45(-154.16647066020414,-597.8943724202702,1.3426872157937595 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark45(-154.9874065185964,-656.2782056984656,83.67120753140918 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark45(-155.17088695688562,-648.9309199889426,33.32968116419727 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark45(-155.27148779986805,-606.3552584201616,100.0 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark45(-155.4849381363269,-597.4871604637561,80.0902853990944 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark45(-155.54205779852117,-599.6505929796548,78.61306145638463 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark45(-156.61709308313155,-619.9897142800124,53.84551241546734 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark45(-157.02954975997724,-593.9076866106179,62.28164819934062 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark45(-157.14322840458198,-616.1058173387385,100.0 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark45(-158.49443925917976,-618.4183584846596,2.7169500314581256 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark45(-158.57635247230084,-588.527134291965,43.03484606342772 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark45(-158.77034657940558,-588.4554967408596,53.28324162551175 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark45(-159.01674733840545,-587.8030966974363,87.25094422263821 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark45(-159.46931120514358,-625.1618704770992,37.1256580542547 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark45(-159.5311653281824,-600.0756690648165,70.18452382448396 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark45(-159.69615935503487,-587.8667074359049,99.95680506724437 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark45(-159.8502699902545,-683.2244003852325,97.82216308657237 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark45(-160.27424687619765,-625.310627064096,4.039770809563478 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark45(-160.3691002208631,-616.930492179396,32.17835177431138 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark45(-160.5973745091244,-610.1974737324052,43.870172063001775 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark45(-161.04513249580415,-635.4741286760487,82.63464336047608 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark45(-161.14345341576748,-615.8766879057382,1.5856038797373344 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark45(-161.64750465121747,-590.1034845374071,2.8536168931686348 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark45(-161.7040764481154,-615.5336208830822,70.87451495418941 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark45(-161.77099741076543,-595.2433837262483,20.54007423540085 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark45(-162.08800622714625,-590.6942952118011,66.83063412177526 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark45(-163.10759732166895,-607.6497428681425,29.744339598635435 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark45(-163.75900278475575,-590.2914718337323,83.64519341719244 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark45(-16.436742809739812,16.436742809739812,0 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark45(-164.45972873882636,-639.843236423633,82.68474635038251 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark45(-164.69415190831347,-608.9098070106944,100.0 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark45(-165.38734063586884,-630.7940742937321,99.15674077354925 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark45(-165.5161929194491,-631.961739349404,57.71262312403985 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark45(-165.77397983473134,-618.9282064114888,34.703268657356915 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark45(-166.2474210110929,-614.3336860073208,61.39132168673564 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark45(-166.26623832894023,-602.1102736481199,45.93950102905009 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark45(-166.27759793465702,-593.6263800577069,3.6638598221792478 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark45(-166.5007350895551,-617.8260350867138,47.89973926211083 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark45(-166.63590807256188,-599.7249754072723,56.50807827181674 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark45(-166.9438069319312,-606.5394106287677,44.91398655882233 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark45(-167.23641253253115,-636.3587078638124,100.0 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark45(-167.28992896980407,-601.9767457832722,96.70204044887598 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark45(-167.5224788171889,-622.6108077974385,17.77942473536254 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark45(-167.5850477638252,-580.3810105924958,10.366043759482423 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark45(-168.22113063708485,-578.360273370522,100.0 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark45(-168.29878162091157,-608.77815194254,98.80968152304655 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark45(-168.40319822568767,-610.4252203883061,100.0 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark45(-168.44683421788517,-610.2683246283149,25.128057097901774 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark45(-168.55190568285312,-615.6832140568926,100.0 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark45(-168.55441114743314,-596.0923983559735,100.0 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark45(-168.80789518491412,-614.207421072943,54.14930843823012 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark45(-168.82571887102404,-595.580853057828,78.19699251469106 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark45(-169.16392857448758,-589.6808517882441,11.276091817051253 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark45(-169.36561825274498,-590.0584267713115,90.45061880289077 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark45(-169.45895371035192,-627.4212086800469,45.49592559559542 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark45(-170.159084986324,-622.2171969527697,21.808006143172705 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark45(-170.487796679083,-586.7993563709458,55.26342293864275 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark45(-170.64198907943907,-586.2545328114043,43.093977750250104 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark45(-171.40475386145957,-596.2732788501935,96.49766867292186 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark45(-171.70815182587185,-607.491559607729,82.56692639957566 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark45(-171.81518565610924,-585.9391721792882,100.0 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark45(-171.94642310967708,-605.8495836905553,42.280371139812274 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark45(-172.47396459089887,-609.3332754255848,5.533591330762519 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark45(-172.6543824846378,-593.4713064504058,4.4164357336501325 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark45(-172.861650949465,-629.0962067465069,28.320243804213504 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark45(-173.04709177464864,-604.1508120591916,52.003120576556285 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark45(-173.11020176786644,-584.7395286653722,6.719054703483039 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark45(-173.62600492848935,-584.9260265087896,82.6559821719691 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark45(-173.75663190974527,-572.3908890350219,93.19161749624068 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark45(-174.0309373500737,-611.0610901965599,100.0 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark45(-174.28086069097628,-594.8924646083544,70.7331453126472 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark45(-174.51579341889746,-590.2615795982362,84.25340480445513 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark45(-174.91679254421356,-574.0197500259685,47.0499385948942 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark45(-175.06898486147958,-591.9136760020366,100.0 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark45(-175.31406246055286,-624.982129324266,31.748887136936503 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark45(-175.5067515019791,-585.7160738623501,12.948995977206973 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark45(-175.94772822617628,-601.7271100763438,8.748934810951226 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark45(-176.1201767199799,-585.8277618132043,100.0 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark45(-176.39606904315187,-590.7776757241037,64.09904670016638 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark45(-176.55543351711177,-569.638774977345,100.0 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark45(-176.5997611182935,-581.153768000717,75.08750553318478 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark45(-176.61434532657833,-622.5741649014043,100.0 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark45(-176.6160195489298,-574.30094348632,100.0 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark45(-176.8344872662013,-599.2488119674889,69.76425894917668 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark45(-177.16523345394228,-572.8824554604466,94.31809686267735 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark45(-177.23634573176798,-595.9667939214285,4.792062959493521 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark45(-177.83700447846672,-572.5539348819711,11.612693437939384 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark45(-178.25259817042013,-580.3447120610028,16.262478001494273 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark45(-178.40549958208766,-613.8464108309603,90.83019290360457 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark45(-178.40668235493698,-587.8909064813009,61.56230143737136 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark45(-179.37179986916374,-602.2199517103169,87.54275306151965 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark45(-179.86766621905534,-566.6729298528975,96.719943395694 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark45(-179.88552693084392,-595.0036526427283,5.686284790842805 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark45(-180.08269399149194,-590.992177219315,70.44389834873519 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark45(-180.2809517470237,-596.9135265449518,29.039729395432374 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark45(-180.34066570446063,-571.6180075646706,31.58818655014727 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark45(-180.3618437134131,-598.625935122222,35.25121057887017 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark45(-180.7743642303352,-602.899627025641,64.85949009948081 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark45(-181.14072718913937,-584.2107835244777,4.964302312453253 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark45(-181.88657945845657,-587.6547376901236,59.61518325414997 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark45(-181.98498267500239,-636.6336729276554,70.48629549920767 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark45(-182.50697129655092,-590.6302205597008,100.0 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark45(-182.51395752803796,-587.7240616876803,10.74841436710581 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark45(-182.81114099738198,-647.3615421952624,40.474673759950534 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark45(-182.8941583088037,-627.3003432629886,100.0 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark45(-183.01849101096286,-634.8627681891188,77.01590523574438 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark45(-183.02649862550473,-564.0460124145517,23.577697900999055 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark45(-183.13224584546037,-579.3237998111898,32.827860359706506 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark45(-183.54985335267875,-567.2915497258266,98.34450765559936 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark45(-184.2209339422535,-565.4114271000194,33.926784191918955 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark45(-184.28491469194745,-568.5250003361889,46.729280575156054 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark45(-184.33950936947318,-565.7976621581752,21.97784830660801 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark45(-184.38632770886775,-581.2000108778801,93.19796537500633 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark45(-184.47590463622907,-648.1916548203811,53.03104186478055 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark45(-185.03315401233047,-570.0134198418207,99.55767181088106 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark45(-185.23083238370108,-613.372106142688,23.36987501878631 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark45(-185.35278985641546,-582.8181622786917,100.0 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark45(-185.4189748744049,-588.2342397849163,3.954503055834806 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark45(-185.58114923250608,-585.137315020183,100.0 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark45(-185.7575752867595,-586.3853115212013,60.011622403823424 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark45(-185.80112165833535,-589.3133479019497,73.31137568539145 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark45(-186.01542015617838,-650.4987596507044,71.51529589904484 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark45(-186.33676018337093,-603.5195398925778,94.54470362385078 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark45(-186.35755051020524,-616.6791448267577,84.49889820406705 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark45(-186.61567763293164,-629.6665418503915,85.19578114924377 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark45(-186.6367950693561,-595.1949278765609,8.844802971352948 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark45(-186.67534069449027,-572.1414684399814,70.06873544001365 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark45(-187.9038763383073,-579.9925715766972,58.62542299151866 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark45(-187.9642171400039,-626.0730407957215,3.734055660071718 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark45(-188.04602952683342,-591.0423989151572,94.38262356174795 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark45(-188.38455161880935,-564.6846895382862,14.350768567900388 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark45(-188.47833843592724,-591.1156233967131,5.421793085156153 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark45(-188.595361085873,-579.8597831950672,100.0 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark45(-188.608495622901,-564.1618424995573,69.6870699251285 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark45(-188.96413310374464,-565.9399083086945,37.4064877981516 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark45(-189.0430887309302,-570.2219927642838,73.36890214751227 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark45(-189.36201954222054,-564.236940268983,10.258838175426035 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark45(-189.74961655775817,-565.2669432355913,55.27906888264141 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark45(-189.98772435502977,-556.6497341954196,44.03937354327425 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark45(-190.3214265218896,-579.289635465567,100.0 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark45(-190.35900533133758,-568.9377335935786,100.0 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark45(-190.53338292846612,-561.7965845310488,100.0 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark45(-190.84408618842144,-613.0851068034272,49.48390189993788 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark45(-190.85662857578293,-565.227778413305,20.129657530048362 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark45(-190.85770547490037,-564.8983432852287,66.53601437735034 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark45(-190.99887165317577,-560.2348441363685,19.444315969331228 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark45(-191.11168440673552,-573.4877321013892,100.0 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark45(-191.11810719335975,-576.6105250332607,94.0808037613071 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark45(-191.74851364869284,-595.5310033351011,40.997932984733296 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark45(-191.94409876967896,-572.7286208866097,100.0 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark45(-192.23640403550286,-570.144308894711,67.99812200416159 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark45(-192.23922389645077,-597.2675070048385,41.82772555388999 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark45(-192.57214031437277,-554.672158885209,72.5310922650726 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark45(-192.8949717999621,-567.6512663255,3.8090176322372225 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark45(-192.9208413560787,-579.3583515999912,92.62990397273487 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark45(-193.2099165915001,-572.0894129696109,100.0 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark45(-193.30461128431133,-574.9352995909115,100.0 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark45(-193.3294851819318,-561.135181544203,100.0 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark45(-193.392121402493,-620.8210358615116,26.281515492173753 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark45(-193.4352936808508,-554.4990872401066,80.34995451055528 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark45(-193.76624407397196,-622.0558374899889,100.0 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark45(-193.79998408890776,-617.5131416738055,65.1872711241933 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark45(-193.807563539097,-584.4993144661585,23.249009978578613 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark45(-193.98003467248648,-565.5352863029366,100.0 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark45(-194.0380552742523,-561.7954915073498,93.48806188051816 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark45(-194.12414594768785,-555.9665019050566,74.30884871735793 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark45(-194.14562289988925,-579.050996053139,94.53880312533477 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark45(-194.86082240245705,-607.2152440153202,37.80374427100301 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark45(-195.00655350881402,-575.6205588121876,15.620333569335543 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark45(-195.35438109923962,-582.0452681711704,49.890027384594106 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark45(-195.547520630683,-557.1489987405567,0.794870916014446 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark45(-195.58846796224634,-568.1917038356488,27.319292611276992 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark45(-195.8313257306576,-562.5607502821856,100.0 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark45(-195.94485144821786,-613.5257639284504,99.76669767666507 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark45(-196.6260302738701,-572.7781672352628,28.880506218237315 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark45(-196.7499436112121,-564.3645428380581,80.0049568883145 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark45(-197.03155954388956,-580.4768943672908,13.229407406132395 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark45(-197.0561526092057,-611.0190903067631,83.34718540542642 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark45(-197.2929319515494,-555.1829719972,41.190376239850565 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark45(-197.59320657686413,-573.2714106430726,2.8357396271037887 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark45(-197.92081415504575,-549.0616192549289,76.96035411438186 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark45(-198.3844273056249,-591.30180240589,89.15519658262377 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark45(-198.77091303643564,-548.6151954395851,85.7769402709344 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark45(-198.8547997569349,-563.7027166004511,16.79025146158719 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark45(-198.90211125800812,-558.9766933031156,81.42876112450085 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark45(-199.27126563831922,-557.044648198153,64.12493903894969 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark45(-199.41743591998957,-631.7932477487518,100.0 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark45(-199.43016999777174,-573.4415645265551,27.794633501333195 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark45(-199.80059503066627,-562.7490317629641,60.245946370294575 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark45(-199.8344209835388,-567.5751153874799,100.0 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark45(-199.84134454909145,-555.6793262693992,94.58669452849534 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark45(-199.8807059720061,-562.8695813554405,67.40527930829916 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark45(-199.88110993754827,-598.2805665904507,64.03552779421437 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark45(-199.91992657371253,-553.8193934863275,18.871714622661756 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark45(-200.08770287273578,-586.3258207134402,7.362465502837054 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark45(-200.25760244900107,-625.4187594643936,100.0 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark45(-200.25934283292153,-595.2547443401073,20.811440597363244 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark45(-201.55548363809748,-551.4199759523749,5.902052530489115 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark45(-201.67718953282616,-552.8970234901626,19.924330987486897 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark45(-202.481140493142,-567.6947737212861,98.71923593136665 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark45(-202.49077240677065,-554.1845106770675,83.03359319740372 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark45(-203.3258402356151,-550.0318789906987,44.48110666346699 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark45(-203.3344985863845,-547.6237999676126,40.79041633570603 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark45(-203.34517913001403,-573.5214806097898,99.72438309933185 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark45(-203.47396497184263,-543.783082163583,77.26072731422923 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark45(-203.53518016000834,-547.5550156668165,91.7710303617603 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark45(-203.75041702377771,-568.9684416820322,100.0 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark45(-204.18281720268385,-586.8056066479471,88.82105982239483 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark45(-204.3071466840075,-544.3991574663196,100.0 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark45(-204.3889747513428,-617.1424166737021,71.83884670255685 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark45(-204.65680886638677,-589.3274236664191,54.745418479452724 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark45(-204.8172236970597,-581.1802609718508,65.8865649147227 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark45(-204.92810361398455,-611.4008997677461,63.079243128772106 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark45(-205.02807454879053,-551.586634236996,44.59615475781624 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark45(-205.5428935948155,-544.0424241501634,32.32026957623367 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark45(-205.81630171231598,-546.1419132889595,62.44790022129715 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark45(-205.92546893961008,-562.9454955292925,37.00543866695563 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark45(-206.7337114610463,-547.473607126505,24.739374462191407 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark45(-206.83411606860858,-605.8656352578184,61.078781936802386 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark45(-207.05956056868956,-579.4878758136779,73.54450929139303 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark45(-207.06947436785316,-558.8835505829147,13.269433456881245 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark45(-207.1552956754041,-551.0230692472486,62.78019693480783 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark45(-207.7997146407929,-565.7303610142773,50.24748437298513 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark45(-207.84750577288185,-538.4982120641057,44.11702723439629 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark45(-208.1208695492104,-539.7426505904109,24.074453630028472 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark45(-208.44525087285828,-624.521954064798,59.87907695403112 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark45(-208.5810694338242,-547.2381376046873,0.2107226702493108 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark45(-208.85931764048183,-602.8278979063599,100.0 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark45(-209.0604796456687,-539.2228041680107,46.4483945163914 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark45(-209.0972149564749,-538.8687446569471,16.534439556745255 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark45(-210.07344480874167,-575.2375983431094,30.450077659961636 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark45(-210.23582097019442,-548.3612848537955,100.0 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark45(-210.33723752540328,-536.7271708391786,41.08131065614543 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark45(-210.39312693656203,-539.4953910244587,100.0 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark45(-210.66233979264507,-574.3903529086949,6.098613066210717 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark45(-210.752487286527,-546.4629365364966,100.0 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark45(-210.96314597419774,-556.5908021154506,100.0 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark45(-211.0984722574068,-564.258599238129,100.0 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark45(-211.29466978694066,-611.2496997927149,100.0 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark45(-211.60781433546308,-597.3538928838032,52.240238532915356 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark45(-212.1418006473292,-549.7180486780817,19.962676238399247 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark45(-212.2707578279024,-561.9242528226308,11.38090751258693 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark45(-212.46150519442287,-548.8414420721346,74.92293670759639 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark45(-212.59556661716857,-552.5209027949129,4.2138341946304365 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark45(-212.73131231646013,-537.127477471353,38.463772174848145 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark45(-213.26674698228186,-592.8772458496296,16.616818878527766 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark45(-213.28493712856695,-575.5942747813968,17.41184122103259 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark45(-213.6844777814517,-553.2118866295613,65.49823412685905 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark45(-213.98537679655618,-538.4124207617067,100.0 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark45(-214.90954282130554,-550.3683565526297,8.74741698802464 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark45(-215.64205475514075,-586.3386112636204,55.460442881877924 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark45(-215.95325195015482,-595.2673618131587,11.152297744289712 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark45(-216.20116414644605,-566.630840347923,100.0 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark45(-216.30594771849684,-565.8007396392485,80.10858798778125 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark45(-216.40940762840256,-540.5052556599944,49.171514929715244 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark45(-216.41306065977108,-533.5160345972818,85.20875724315982 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark45(-216.8354524210137,-536.8643715436575,29.402979167301623 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark45(-217.29764273623582,-539.2276095515505,91.47610372023013 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark45(-217.8881441505974,-593.6994459769172,83.6305978597641 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark45(-217.94157413602323,-528.1571695411941,100.0 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark45(-217.94467837279902,-539.6734305856123,100.0 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark45(-217.95240372416785,-545.601651011151,86.82086796138023 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark45(-218.14400729887188,-554.2514431746293,83.3669144808261 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark45(-218.23037016828465,-536.8281640890716,14.38028861619911 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark45(-218.2894785953395,-537.2746996961667,19.657058735226187 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark45(-219.28230605364416,-566.5861324607786,29.894343140539235 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark45(-219.3639443056329,-532.4061671989181,100.0 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark45(-219.7834798494647,-601.8841321848951,14.96070479320079 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark45(-220.17987645439626,-548.3249266123748,18.715622022345087 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark45(-220.18979082747455,-537.0717671306679,91.91373207623425 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark45(-220.52533793694255,-530.6647904559051,0.1626178954719677 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark45(-220.6286023007106,-537.1094126582205,0.8110348513685466 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark45(-220.74742054180058,-549.4433262297314,28.16093284010188 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark45(-220.79570882013536,-533.9932816669493,25.151042474071446 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark45(-220.8143279935445,-534.0536105713468,76.45781778027342 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark45(-221.26723761466772,-534.3066164485701,11.726732332064188 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark45(-221.28177912603581,-548.7996143415038,17.300463521926417 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark45(-221.36342799456628,-544.6622781506466,7.030796530903999 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark45(-222.06409939312715,-535.53964565665,49.05098354905977 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark45(-222.11866879424753,-550.4118779238156,100.0 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark45(-222.21900189647513,-575.7466294494673,9.837151806380632 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark45(-222.22951979883547,-526.6152859615578,98.33198009254639 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark45(-222.75959230845368,-572.8699134735187,11.416050933123074 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark45(-222.9667122280746,-552.7125919585807,38.605899297050286 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark45(-223.1759354597881,-538.1969188276483,100.0 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark45(-223.21479161492698,-526.2349639536781,92.73149454257731 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark45(-223.26302978967652,-543.8536224576756,84.16549279358176 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark45(-223.35377172580593,-579.6991649188246,79.18573750738851 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark45(-223.3917279789651,-546.7194113806779,1.0025299656945634 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark45(-223.7951064569056,-530.3363702223006,97.89414717545927 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark45(-224.18238138434438,-604.3563211809533,41.9108516347585 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark45(-224.3534350667136,-553.5129780642985,81.07108052450104 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark45(-2.2509674186211255E-19,-754.5996061391763,0 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark45(-225.2627454396905,-565.5680848841401,36.170579322570944 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark45(-225.40994999635714,-526.2599221317047,100.0 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark45(-225.46157012842423,-523.0487987486099,60.1510649165783 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark45(-225.65370597344008,-558.6992802740506,100.0 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark45(-225.71652825219104,-554.4349779067439,18.419506325931 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark45(-225.78071520128412,-598.3847205096134,35.693395634204705 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark45(-225.79169261964677,-554.9602919344836,11.528284503460199 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark45(-225.8133953209674,-569.7320025893134,81.35187200768962 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark45(-225.83258170424182,-551.3360211791136,100.0 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark45(-226.21316431098273,-542.1252258498744,90.63993936824139 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark45(-226.48844743379743,-603.90077198572,25.119351931413263 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark45(-226.51151309896548,-555.1765347658828,41.536992827656235 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark45(-226.60059606315977,-584.338150808044,33.86376825659846 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark45(-226.83358720668014,-545.0801109956785,32.75034347029623 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark45(-227.1697263893107,-546.2754421406847,64.56263756967769 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark45(-227.72190369359512,-533.1128490204411,100.0 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark45(-227.9580981142108,-535.3011307476039,4.455312371070024E-19 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark45(-227.97545781080711,-543.5918081274529,23.933133598130254 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark45(-228.24603405426967,-524.2206424796644,83.72150136809825 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark45(-228.36932438881195,-524.1692292503149,7.851197902117207 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark45(-228.4350581293753,-518.1060854161587,38.18211708340863 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark45(-228.45944799990556,-551.6107956801859,23.821191903934476 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark45(-228.49892210389964,-518.8106483292298,73.39514953118712 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark45(-228.63787048602904,-556.4174789938701,56.6868647575688 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark45(-228.71385346834148,-534.4310999107881,20.80863052792779 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark45(-228.7876489928194,-570.9770924084108,72.72502817166213 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark45(-228.93518022058444,-518.2254629828599,100.0 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark45(-229.26518559003236,-535.1662169467223,25.112469803774857 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark45(-229.39199845441158,-547.8840709245923,100.0 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark45(-229.51554733882566,-536.9815744964341,84.02248354602796 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark45(-229.59684452871178,-531.3412385661437,87.855857800709 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark45(-229.75202385680626,-552.9161320709675,34.22127014515078 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark45(-230.5290248117881,-588.7296156958043,18.65629133258257 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark45(-230.59597132358576,-522.3741720246235,55.24653718613652 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark45(-230.73935556227494,-543.303843002947,38.50622549465487 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark45(-230.96580983957708,-535.3009612050042,71.43091765981521 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark45(-231.178075403793,-516.8497968596962,51.792249594753144 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark45(-231.27715491825998,-514.8063909035732,60.94137731080096 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark45(-231.48075750553292,-539.9692695052834,100.0 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark45(-231.65614130043093,-516.1042614473615,2.1741953357814054 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark45(-231.69561399832207,-577.3586840910473,76.53429603606884 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark45(-231.93815405248785,-518.6495191986285,4.043366803480566 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark45(-232.4042186683556,-537.1639932114259,29.611165584751348 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark45(-232.68119009685032,-523.5048673761022,53.309476379520476 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark45(-232.8919176673996,-535.4055048040678,9.009078815368127 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark45(-233.0658273589504,-523.8577995796377,24.84891672871001 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark45(-233.21648309573501,-530.5041776990648,1.581874965212677 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark45(-233.58522364348855,-546.8967602116381,12.466791808272191 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark45(-233.6879461105787,-573.4668238281965,61.12521991461461 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark45(-233.903765852667,-527.0112573683941,51.335736737426515 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark45(-233.98327379472525,-533.6493428181698,80.16564704835102 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark45(-234.34196619960264,-643.7235259084844,63.9004871172867 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark45(-234.38393403134387,-530.1294814913474,92.35903179796654 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark45(-234.40279371172588,-536.6287301618222,34.75900476271099 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark45(-234.66958153196643,-530.1285969794445,11.288890344187251 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark45(-235.0666220228485,-551.5333351710045,83.78764426415901 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark45(-235.1302088835027,-594.1819694175625,27.541003069955778 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark45(-235.89526464611924,-575.9476321800511,44.04848140604861 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark45(-235.95897504303107,-512.425758218385,68.60252854634936 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark45(-236.08790686799802,-522.9561130169915,42.597304207738716 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark45(-236.09680074926246,-513.4689778569685,38.2128879214971 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark45(-236.23932822745786,-524.1052955855924,62.87372854887337 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark45(-236.62476932873503,-517.5003795067165,73.82988922091393 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark45(-236.73885744721525,-514.9485635375878,49.38428525636104 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark45(-236.84379254831583,-522.9962017881945,43.18582733747792 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark45(-237.04463555866553,-544.5718078197079,100.0 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark45(-237.5239263728519,-531.9336684548855,64.34596300006982 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark45(-237.85671225742152,-563.7472537967155,75.30590509519445 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark45(-238.18301093752697,-571.4887328635625,23.26586472435895 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark45(-238.26217857322519,-544.5300787965442,52.70536179643395 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark45(-238.72750259611806,-518.0499347660301,4.6557748598801965 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark45(-239.0009970631463,-537.9110649785752,51.70477713616532 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark45(-239.0755783838551,-535.0551031395066,89.7349986821009 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark45(-239.3706274813288,-533.0024812395311,26.656851197594932 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark45(-239.59034461610804,-510.66148995012963,2.6078296382646347 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark45(-240.1632071797801,-507.1137305100634,80.58069509963224 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark45(-240.29621470661013,-514.5509964849723,60.12221774254448 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark45(-240.39058645229042,-548.7990922456991,45.414077904415 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark45(-240.4620424873727,-510.24715971524506,89.68764288842769 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark45(-240.54672438546365,-513.2454743714611,0.5040067600356579 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark45(-240.61838971520527,-534.8168191700131,66.38822666566665 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark45(-240.64376873138247,-510.0385816659382,83.02266528121004 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark45(-240.70390295400972,-512.1967783279356,85.87762693837254 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark45(24.0729180472661,94.33460458603793,0 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark45(-241.12686162619647,-530.9001899176959,14.896668613219504 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark45(-241.16091790085272,-508.6882605411463,9.070085627185634 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark45(-241.52242965350047,-547.2388402549087,96.86471951542313 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark45(-241.63611131167113,-531.6734105963802,31.59160335893776 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark45(-241.6607768199518,-544.3070581538169,72.97186155681533 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark45(-241.82936788874397,-534.1412243929931,91.7872849486738 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark45(-242.0402071564086,-543.7002626046828,62.952150693600515 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark45(-242.13495998407348,-518.0879102548234,66.13334669378662 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark45(-242.154178235482,-506.65296631052615,47.23606485660741 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark45(-242.92406243771393,-520.8574816368331,18.00238586409226 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark45(-242.92558676317412,-536.1772470109264,88.45555421646503 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark45(-243.03133616497686,-516.1745071026602,24.981711468489465 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark45(-243.17373110715855,-523.5531387333436,10.2619955419065 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark45(-243.292598558766,-514.4375438017867,67.69117470195968 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark45(-243.30335282381537,-511.9631170927846,2.869054409710203 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark45(-243.57393169791814,-520.5353390410424,95.38031818055404 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark45(-243.63688661853104,-554.2635695854567,65.95633593228902 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark45(-243.64668992375243,-524.2900086037056,100.0 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark45(-243.67729036404165,-531.0666489521558,79.57067071674933 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark45(-243.78697078896985,-539.5852576408065,37.70270595204249 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark45(-243.93127627355292,-503.3721349529237,81.94780488907296 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark45(-243.9328187422405,-525.51935610747,15.55813855879562 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark45(-244.05119245074363,-525.2918816204331,57.70020943916177 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark45(-244.2201410941471,-627.8770110239525,86.7136767151824 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark45(-244.28174269043365,-512.158692450896,90.47750312962327 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark45(-244.77652654883013,-528.2987734029223,77.27191935556743 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark45(-244.84966802164632,-513.7605784122484,34.58414049540875 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark45(-244.90609771640104,-506.4071347917362,83.60416061105053 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark45(-245.01821224778521,-507.3529992454478,73.21075933375448 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark45(-245.04633938498316,-509.7473926550641,64.53889273406003 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark45(-245.3721934662913,-535.6767327180773,71.42248332559714 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark45(-245.40477408576953,-567.7040037658323,100.0 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark45(-245.77224659823767,-525.5646830695334,65.65397558431553 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark45(-245.79765896743785,-544.0912556681061,73.24611863958069 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark45(-245.88479364662558,-524.0110990304493,100.0 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark45(-246.3635068855765,-561.2710776602822,37.07286817710772 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark45(-246.68566130096963,-520.1274570890045,41.58416637016268 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark45(-247.17239993326405,-507.03306829112046,100.0 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark45(-247.24569108057085,-535.1438406997886,65.45003847094785 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark45(-247.27110867803827,-546.0938649403731,71.63821746191158 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark45(-247.32747755490584,-544.2240465651668,58.39490805593229 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark45(-247.4960981934883,-510.21233388241035,38.85162323220513 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark45(-248.2655578693702,-526.5382741306885,2.4971114804796457 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark45(-248.302406794925,-530.5013849167041,5.9960057402262805 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark45(-248.3323888161691,-536.7848414773937,100.0 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark45(-248.41137101660564,-497.71560077880247,10.602920844856271 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark45(-248.4794563193586,-514.2826271620581,100.0 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark45(-249.18536710597093,-512.8217605226489,49.68016391717481 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark45(-249.19389051616457,-502.2503751369577,62.10483527955162 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark45(-249.6520468978401,-580.2081979136058,100.0 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark45(-249.9063444008637,-502.499400681283,34.679380330459594 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark45(-249.94694143935848,-536.0254223229658,87.20932133328932 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark45(-249.98023745018364,-500.9126656219091,35.48131674225942 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark45(-250.06167857771476,-557.5668616150683,82.00814680844496 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark45(-250.24032901071288,-499.75008909806786,39.39134773136533 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark45(-250.30850374218628,-554.3316018822403,96.35387625115334 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark45(-250.33851791282999,-512.507918348191,51.75903894059019 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark45(-250.4396100585808,-525.0769243885592,100.0 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark45(-250.70359922825887,-531.1044728033934,59.30465331942651 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark45(-250.79957158102496,-502.6049362980721,12.426178044958519 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark45(-250.90323642407992,-525.1679646186185,100.0 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark45(-250.940313313779,-509.22669799812337,84.9747047994972 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark45(-251.21252206531904,-524.8492259257422,91.42458334067265 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark45(-251.2612209462744,-574.938545755682,23.957306899579535 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark45(-251.38698509140383,-499.4746512314854,22.12563856067847 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark45(-251.50517418313007,-579.8616480494655,0.6511361065421681 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark45(-251.666430100359,-495.03995909299107,32.414594201033594 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark45(-251.69971827113952,-549.3713464690582,87.30132939729515 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark45(-251.73812394904496,-499.4693677853171,96.91218422727181 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark45(-251.88184107643323,-560.5572226523673,100.0 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark45(-252.2861408849294,-528.301151061358,9.975482626187087 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark45(-252.44219543290816,-502.7466470607096,5.401060702969247 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark45(-252.67168240961524,-554.8281493715506,85.59768062532243 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark45(-252.76558404423616,-561.767249012413,40.20900482437696 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark45(-252.87051868852922,-531.2185798158152,96.49965808135767 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark45(-253.3814863850327,-514.3641806174161,100.0 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark45(-253.44047105277411,-523.7971684781934,91.11676754303463 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark45(-253.53122153350753,-497.00197341331784,33.170969930744036 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark45(-253.6359693478155,-500.2258989914347,22.209086278628916 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark45(-253.69408968099845,-627.4664981603954,100.0 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark45(-253.69472267975328,-523.9286889122841,36.48314474995766 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark45(-253.82192944027977,-562.5027765830584,58.31511794623478 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark45(-253.92947720274572,-552.7754198259031,61.5413662202335 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark45(-253.9667805553696,-524.2042194939419,82.21957259778773 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark45(-254.1394989971548,-561.680319886667,40.430914449034105 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark45(-254.21310042822938,-545.0893830855931,97.7826499400575 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark45(-254.667669449145,-500.1070338123966,79.831605153277 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark45(-255.24231423853112,-495.77777307085876,9.076607969796612 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark45(-255.37590377221164,-511.30233583240084,55.93928849558117 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark45(-255.62387107065425,-513.0958390518355,4.283627680617627 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark45(-255.64222732839102,-492.04199633358087,59.77291442679632 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark45(-255.7040333396763,-491.8020611271229,22.70224383509192 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark45(-256.1899343137095,-539.13568228852,49.95852883891777 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark45(-256.2244244928162,-501.3490619674485,0.9795934829091237 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark45(-256.41374326723235,-499.6021332469606,32.455328474873966 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark45(-256.56233394845526,-496.32506817167604,58.2517638411625 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark45(-256.8182662512593,-512.1724721266595,50.63810095303077 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark45(-256.988480872967,-506.01356239563466,59.74923197953703 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark45(-257.0315774929203,-566.1858572637628,27.26972183981573 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark45(-257.22760685013156,-491.50396737304,11.127786601865182 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark45(-257.75309559766566,-499.45466631279504,44.266557031689956 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark45(-257.839820704122,-500.76279893814376,56.95782805315787 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark45(-258.2240378505313,-516.4983722273682,45.03105561547079 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark45(-258.69260580078856,-512.3395137212917,28.24592953032146 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark45(-258.71676485799196,-535.2760933388522,80.65284793894608 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark45(-259.24835802096766,-535.8991538679013,38.60238350380209 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark45(-259.37660352129706,-513.2649655233823,47.345902025227616 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark45(-259.42051410428707,-500.5531567289762,45.543806833479664 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark45(-259.4265193344769,-553.1911889079222,84.32512592758138 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark45(-259.4444820316,-569.6096506826984,68.74765080608118 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark45(-259.52725347626745,-522.9427277073058,100.0 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark45(-259.55116537664145,-512.2017530922105,100.0 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark45(-259.56029885772085,-497.437083702246,47.37186922569322 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark45(-259.7170809747408,-495.6851845174761,7.11274457857651 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark45(-259.7831088676419,-541.9686221630818,96.57743966283178 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark45(-259.80486156796405,-544.3192018525817,77.58384329419238 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark45(-259.83172563575346,-504.5859478777246,100.0 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark45(-260.1828283578798,-535.026872915437,29.618710545683598 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark45(-260.18583617281337,-495.96620100051354,96.87379561379777 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark45(-260.3720756646032,-497.0507095997207,92.838338650894 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark45(-260.4473388194633,-492.0043161612937,6.405066206800498 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark45(-260.56197797484253,-510.75697848363916,100.0 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark45(-260.7155749934846,-486.19186585732183,100.0 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark45(-260.91875030212674,-507.48290242099824,36.74486955601358 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark45(-261.03165291633127,-494.3591466716811,72.38038829233443 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark45(-261.21375336376,-494.5411211018387,46.171424968019124 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark45(-261.4329589665202,-572.2066732683777,52.91941585713843 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark45(-261.52754092836,-505.1267103216535,54.84526429521753 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark45(-261.7005316211231,-486.1761187885605,20.2570051625804 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark45(-261.76072232890425,-510.3066074145268,34.19980202093035 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark45(-261.9837268398087,-498.19788098252604,53.67273790500863 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark45(-262.31159671988894,-502.54465730149406,64.50485940230365 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark45(-262.4217450713459,-503.66732637443585,64.99517094055028 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark45(-262.83177789899673,-485.10568053549304,88.13431871847573 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark45(-263.16136967417043,-491.89140749762555,25.396861828114424 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark45(-263.3106669577635,-550.5786783947423,40.60330033641304 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark45(-263.4772437945372,-486.7906815405177,39.90277947978734 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark45(-263.50159773183407,-486.91581108247453,0.5907226272530579 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark45(-263.6454531281521,-498.0975638535421,28.816849004568724 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark45(-263.6574563872581,-511.005890324934,55.67342200489415 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark45(-263.80236276803777,-483.91326695956633,100.0 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark45(-264.3999602038516,-495.3960261862422,100.0 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark45(-264.4353265273372,-487.6618974919595,14.400027282723926 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark45(-264.457003928618,-496.8692440256013,84.47842448928998 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark45(-264.5142239414015,-492.3214328625142,75.27216499997337 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark45(-264.8488745967672,-549.5507320070285,43.12825084763986 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark45(-264.8562628863206,-516.8453684357859,78.32900613734378 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark45(-265.07519548197234,-496.5764845784411,66.801921544957 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark45(-265.09934939909783,-488.41151083225054,94.39148617003127 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark45(-265.15493576628046,-490.8623587504172,8.864537715260141 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark45(-265.2625733989229,-498.55756519050857,35.11587113436809 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark45(-265.44465553344816,-518.1345598507228,84.08878246895065 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark45(-265.51456664188174,-557.5973204441152,60.275371694006736 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark45(-265.51548988635534,-530.9229503685663,35.06134766428279 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark45(-265.6375699130215,-522.4204376718128,26.051417350037468 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark45(-265.7247353774994,-496.3938229505152,65.59496320694967 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark45(-265.8773382210737,-493.2643544983264,11.447945321122432 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark45(-265.9515326903117,-536.0699451350403,100.0 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark45(-265.98022746082444,-483.72479895365234,53.13814942630947 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark45(-266.00066984821643,-480.0275191494757,53.551821926073316 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark45(-266.00922757928873,-514.4613649361929,5.808335848910957 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark45(-266.6983799189667,-495.0147054896296,52.86195054034812 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark45(-266.7090137527475,-490.9385104968004,53.99699692981358 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark45(-266.72373953053034,-507.96332272069054,36.28822634399677 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark45(-266.84372342675533,-490.49100642648136,41.224255852873284 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark45(-266.8447362281087,-490.92791422492144,40.9264618653977 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark45(-266.8458542441448,-554.155225320925,70.32446931729822 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark45(-266.9326918206508,-491.9040055418184,91.20658282795358 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark45(-266.9910279230246,-493.4360399270124,6.054571980135705 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark45(-267.01546516708834,-494.65345474327864,73.65288367606331 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark45(-267.1653488168696,-502.4186941180561,7.2145097518441474 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark45(-267.2968774784189,-494.7004697039075,18.97917369425241 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark45(-267.5104031042232,-492.43937463658995,100.0 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark45(-267.66119905313815,-551.7391635971244,21.93355329751452 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark45(-267.82521339898585,-478.21601972540066,40.72618563857469 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark45(-268.0392147401756,-493.6733046055023,20.25162141193732 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark45(-268.0583759368896,-495.9051837423631,44.76053539890901 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark45(-268.2478977704189,-484.9186052180449,100.0 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark45(-268.34695204004953,-499.3836951385027,79.44800855272308 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark45(-268.44775149279644,-479.3793993536043,60.02663929643779 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark45(-269.0206804858602,-512.1429522676361,83.47166303384904 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark45(-269.1032189162612,-509.9568671884619,100.0 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark45(-269.3223711958474,-508.86594432166964,55.824446454558256 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark45(-269.81962149749603,-484.031908913236,7.232809620464263 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark45(-269.8235593030398,-532.3259978603102,79.3139787705442 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark45(-269.88282288533946,-502.2468696530485,21.417216703957337 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark45(-269.9299592444341,-517.5507612690981,82.90188978688772 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark45(-270.32501409361475,-484.35043153825325,76.18904898517141 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark45(-270.5463910755414,-521.0531330718476,38.60323897591155 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark45(-270.6882435745148,-527.8855691603267,42.45326305832887 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark45(-271.3337098407331,-477.0611944297794,34.21042094504173 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark45(-271.6336310472138,-480.44369171199554,63.53646488096635 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark45(-271.82239152195734,-477.4373662170351,77.50142714319702 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark45(-272.215701766922,-506.320502687651,93.55615477672544 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark45(-272.4419044665382,-481.858764862438,54.83057174062213 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark45(-272.5681882171741,-480.34167016749063,23.094225525305557 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark45(-272.6956583377358,-506.1651080231777,63.96315030232998 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark45(-272.70601340123824,-518.9050689765133,49.259963333702984 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark45(-273.2563861761189,-505.6675741631632,15.229186772905877 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark45(-273.27164702222393,-508.5494801246592,72.49772341395118 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark45(-273.29197706540907,-554.7774772056787,39.89819012160936 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark45(-273.73547026165295,-509.9223832994659,61.8874568306901 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark45(-273.7520018418355,-528.9024369407725,100.0 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark45(-274.1061556010101,-489.83477784775613,77.22307983584159 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark45(-274.45747610937116,-508.5986055290831,100.0 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark45(-274.65594290830046,-503.3871128562423,51.146154127442315 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark45(-274.6936949526804,-500.0412452683803,64.48183783651248 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark45(-274.89243041810244,-492.44078543764937,100.0 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark45(-274.9066429674185,-481.1727207828916,46.28136420115149 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark45(-275.27376755261264,-473.25084937768315,65.30870406345787 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark45(-275.2978095369687,-474.6203648250758,94.5817984919731 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark45(-275.41963906328334,-502.2276943730627,56.563470560437935 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark45(-275.6486610267532,-487.12759282953243,34.99403319817574 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark45(-275.7489797406338,-471.1853582667669,26.642625588970123 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark45(-275.8475654455202,-564.2460084734375,37.85241282337449 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark45(-276.01174298214437,-527.4279818879847,80.15610025750465 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark45(-276.0267024554529,-516.3372393163693,7.275667276852275 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark45(-276.0626034106486,-497.4961469564983,85.53259307681347 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark45(-276.0947131462723,-480.76215746488026,94.99008061345367 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark45(-276.4626333143222,-485.11910589483836,23.078410011527367 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark45(-276.5149462782435,-543.3980619884885,92.92783490948483 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark45(-276.6319629495461,-471.3986411193679,71.19988374407521 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark45(-276.66731729606374,-476.86258431295556,34.20502842952905 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark45(-277.06890381072304,-499.01670853078974,100.0 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark45(-277.0957316608576,-482.2378549148973,78.14260155465459 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark45(-277.8125110407265,-469.43249235798146,65.92553342212003 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark45(-277.9330275767616,-488.5471731729043,89.3065844394616 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark45(-277.99639405979207,-489.96412735073335,97.74604730956312 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark45(-278.19609084471693,-495.9446462578363,92.75226895048331 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark45(-278.21585829855445,-492.5077941577372,64.87112619285526 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark45(-278.4861826078251,-470.3823915261312,100.0 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark45(-278.5847229755733,-470.5708444590385,90.49861371007671 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark45(-278.870674862178,-508.49725484095705,24.281688156423357 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark45(-278.9654803099513,-479.75982303031316,61.5677647969778 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark45(-279.1363207369049,-467.28015340787715,1.084107722809378 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark45(-279.2590501087172,-471.2911829339666,46.1521774589074 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark45(-279.46911768546966,-497.0399159384353,18.03610317457141 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark45(-279.5869331722587,-466.8139286941621,68.53877622431969 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark45(-279.60876857305345,-473.00171223444664,25.4219449986534 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark45(-279.6212515777769,-491.08246631113786,72.17640650519763 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark45(-279.76795336032484,-474.7874252984187,52.25376245152094 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark45(-279.81716905621744,-506.5758152274743,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark45(-279.8250852719668,-522.7038502057874,40.00119144338501 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark45(-280.2058977190611,-468.9005271595764,42.34851173549484 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark45(-280.2640331754588,-511.4699098239406,52.88279713037403 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark45(-280.2665182251919,-476.92264394193245,70.59531183967263 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark45(-280.699830065653,-511.52903166200633,51.347978779025965 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark45(-280.8674806115965,-473.14158747398324,30.43709610164001 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark45(-280.96506156658614,-475.7174582878324,55.0773319268161 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark45(-281.00316333403873,-523.0788187749956,42.7988524901199 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark45(-281.34915125751644,-488.86345091281385,25.539332247130318 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark45(-281.909384304415,-514.8771110498299,63.96683220047339 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark45(-281.97952047190137,-497.0869503344731,26.7628541686328 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark45(-282.2192924305342,-472.4394578926493,100.0 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark45(-282.2782379118778,-509.359875450909,100.0 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark45(-283.2872198648936,-471.12469098385105,19.988330122422973 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark45(-283.29593974005735,-468.1851142867564,63.8938009076264 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark45(-283.4860889339008,-487.7237939211954,12.807413597276422 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark45(-284.0738817119487,-462.3087988084817,0 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark45(-284.38743408343765,-494.07047930376956,50.84087851856313 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark45(-284.4892655059312,-475.56657817404505,6.69001959866668 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark45(-284.5067371219691,-502.90304360861734,100.0 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark45(-284.6265251287638,-462.8010902296536,68.85461565720061 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark45(-284.86484888727125,-473.2802865813094,45.88675373332586 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark45(-285.1173876984375,-486.4190095769659,11.37177131036728 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark45(-285.27483023998326,-498.01946658614327,10.277866445830952 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark45(-285.41076639897994,-464.99610944108423,67.00180263167758 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark45(-285.4478333919862,-469.3151962667486,20.41148331609412 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark45(-285.52630999826374,-468.66480729861803,76.75561595072026 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark45(-285.73610102191424,-486.22059606338587,52.69966438272769 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark45(-286.0309879038105,-491.1281646153014,99.67044734598588 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark45(-286.11760383880244,-478.3982221798725,74.2762009293466 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark45(-286.2713938183471,-476.04764273308086,64.19602954981602 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark45(-286.50676171284147,-504.5959636394442,80.36278338751896 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark45(-286.5137469756185,-482.84468494442683,100.0 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark45(-286.7488709249356,-470.2638162768235,79.05108646751509 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark45(-286.75880366738903,-465.45660010357625,35.362543291701655 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark45(-286.9988635323805,-481.86041290291246,83.45221742408444 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark45(-287.09354057471256,-472.60983125226284,21.6678349296392 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark45(-287.10970709797135,-525.1004386354144,41.465451351393796 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark45(-287.2654487156392,-470.8969238327262,41.401415229159994 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark45(-287.37277718016736,-475.57397631024645,68.31925793868001 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark45(-287.37620200601856,-474.5887772361271,29.148924553613085 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark45(-287.5259009045588,-478.6942369344102,100.0 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark45(-287.6207319327319,-459.3397432301223,34.84445519909579 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark45(-287.7278290425351,-459.7219420699881,98.94214036903918 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark45(-287.785797943344,-512.7133505003598,100.0 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark45(-287.8320167691696,-475.02151318562534,55.81238388703136 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark45(-287.87027158069685,-487.1249811874518,61.08465243142933 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark45(-288.1819565562992,-472.59587013505205,27.159335382615254 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark45(-288.202875795887,-481.7582879509111,44.88131465258857 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark45(-288.4588013038748,-483.1282660697626,100.0 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark45(-288.51316821227437,-531.0102692707634,100.0 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark45(-288.73542858301397,-457.74874793711297,100.0 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark45(-289.00928445156404,-518.826825886034,56.262229408858445 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark45(-289.0683035524895,-472.6471077130863,63.46503419972868 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark45(-289.09482794786055,-465.41782731183457,88.64991933800005 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark45(-289.1902387180849,-490.4379275487123,0.03540042915103925 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark45(-289.1947893308595,-466.0902899588336,85.8396060475456 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark45(-289.40081483453105,-470.7580890198023,95.575392051423 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark45(-289.56216336483317,-476.40441577590394,100.0 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark45(-289.7880488663924,-474.6860131659262,100.0 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark45(-289.7941955076505,-462.4398334539461,92.78319962615348 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark45(-289.8835779898963,-464.1492775876117,52.04433660511029 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark45(-290.0336267968755,-476.098083482017,100.0 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark45(-290.14078783009734,-465.48856999106306,73.3917286518072 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark45(-290.19152435901736,-461.4619339432181,80.30064546139371 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark45(-290.2778756622444,-476.85027825816985,16.344160659233566 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark45(-290.30641675878354,-479.62120639032514,46.951217423702815 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark45(-290.5881368310906,-499.66344182674976,94.51924175684141 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark45(-290.6228903329397,-538.4213498862409,20.602139663509703 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark45(-290.64738723422306,-493.79385399231484,100.0 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark45(-291.0437354491015,-468.1460701764135,96.53462785790146 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark45(-291.07992754361095,-467.361007200006,14.466854766019523 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark45(-291.0867280921684,-461.62533497287035,27.72611994979411 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark45(-291.09930373814035,-458.6404829179786,84.28944627240818 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark45(-291.14856843004236,-517.1347754841687,55.33628192100721 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark45(-291.16739462711763,-469.14208916710413,2.762051115581656 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark45(-291.4165857477259,-481.17407749291925,74.55885458399615 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark45(-291.4877779192497,-481.2018218193802,100.0 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark45(-291.7175882666737,-466.80486079730395,40.33354758066167 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark45(-291.76191791004123,-470.9088995593579,52.998959019721525 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark45(-291.8950955803539,-485.2987587161331,40.14823807867097 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark45(-291.9048262123184,-484.4567530027424,49.02983233817838 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark45(-292.34491772970426,-465.9793472215636,64.16172993362801 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark45(-292.3631402855431,-494.76846399770074,87.6639419309108 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark45(-292.4432097494561,-456.6913033991715,22.61333611868676 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark45(-292.47144656210867,-471.479020150037,43.03546942950112 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark45(-292.50779509361934,-503.5146502474732,7.2772832868105155 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark45(-292.618925684179,-484.0851071541137,50.36905727201042 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark45(-293.28471060365297,-470.4291550849847,38.79485403987078 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark45(-293.3214910056552,-455.12657916008516,100.0 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark45(-293.3903884332967,-462.97808715828165,94.66854812620167 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark45(-293.41911030898206,-455.95859890886476,30.599559057377604 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark45(-293.4784277526976,-470.41851632765815,17.704665759963675 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark45(-293.67165029580906,-509.39789695951276,18.860928466659473 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark45(-293.78236084301767,-463.00880318352364,21.891581583283283 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark45(-293.8775215090261,-471.9555009551351,98.374246996674 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark45(-294.2663969234236,-500.24306051806894,33.53646363483469 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark45(-294.3864328569564,-483.2481345027206,5.768584706379286 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark45(-294.4855277618996,-488.34848495651323,100.0 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark45(-294.50055036480313,-472.61429368628103,52.46472653552078 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark45(-294.8323638747598,-546.7779075130327,41.420018635136984 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark45(-294.9494233139256,-455.0123476372609,8.444248879488825 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark45(-294.98498598558837,-475.84987524949616,25.015833556539803 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark45(-295.05994033257394,-458.740715027166,5.23762873304176 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark45(-295.0929041281985,-452.1848487247944,81.11862838197021 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark45(-295.1288318223592,-466.7057981136066,16.740920869148894 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark45(-295.1888771212931,-468.2750313920328,70.86852156097194 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark45(-295.31128133433384,-480.4361209549862,68.4434411030243 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark45(-295.33914510371056,-450.8630258876596,55.58043928155206 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark45(-295.6214373352012,-454.3932859343382,74.4731592637238 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark45(-295.66244368463344,-494.18922627160595,26.010030587003996 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark45(-295.6813024035944,-525.0770519719218,23.363186823110155 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark45(-295.6966496908384,-456.38975834085716,57.9050824190617 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark45(-295.73227035884275,-456.8227535032772,3.4586267623650997 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark45(-296.0379829712867,-469.54099829794495,23.50416100747468 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark45(-296.24243450671355,-458.7039020137511,30.196981738667574 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark45(-296.6341088838304,-458.89637970264226,31.885520084459927 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark45(-296.67783947028266,-482.4262217505629,36.5949009173614 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark45(-296.72009126781006,-489.8759398638122,16.36273528059911 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark45(-296.99395601339063,-496.3422373817687,96.497196749902 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark45(-297.00168356808007,-465.7632376375732,0.6689794983369524 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark45(-297.0264555529037,-534.6975560076506,72.35640448707093 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark45(-297.18097919078247,-457.0877831073126,100.0 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark45(-297.3872041285778,-469.0514753878979,73.78610014269137 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark45(-297.56780009386017,-456.4013192972887,59.36593216433971 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark45(-297.77972396881785,-495.79426671727197,32.622644484875934 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark45(-297.87574994809245,-464.26249501856466,61.937278958569806 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark45(-298.01927293244194,-490.2164708310384,25.898579114669758 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark45(-298.06837049232684,-455.2304715305015,69.27609758492278 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark45(-298.180482907429,-447.89509634558584,75.82499826929494 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark45(-298.2250532584262,-461.547623936732,100.0 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark45(-298.26060716755626,-488.39139645185423,57.41741199388103 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark45(-298.44457743779805,-456.17867066907564,48.481565510865735 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark45(-298.67007737182865,-492.14075934788207,100.0 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark45(-298.6933980449877,-474.4701344748966,100.0 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark45(-298.8736473632218,-460.6920619368148,100.0 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark45(-299.0035807895793,-471.0702318528737,13.030312184470176 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark45(-299.01089348155347,-454.67648585679063,57.58153912919809 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark45(-299.2565011793753,-487.48878240411284,50.45401445069882 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark45(-299.31546617093807,-504.7990034954447,56.74355216428327 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark45(-299.50668932028015,-449.8467747338139,42.07452986162531 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark45(-299.51512817496547,-448.71387617823905,100.0 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark45(-299.67554943674116,-451.8715272440645,33.56560226435917 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark45(-299.7562828855113,-453.37657884310346,20.819755237583593 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark45(-300.09951024317763,-503.90657582373024,1.8873532084289906 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark45(-300.46833694259436,-450.7438985855294,13.336667701320096 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark45(-300.6253800434653,-526.7904576341185,100.0 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark45(-300.7517202146166,-456.2056371758932,100.0 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark45(-300.96655887367973,-454.465357789575,86.2387520732928 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark45(-301.167897887772,-447.1621476339618,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark45(-301.37703945393434,-458.00008560982775,35.28467290725888 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark45(-301.63696218072096,-465.8125418361728,4.221467766135632 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark45(-301.8237786327312,-483.7224982080808,45.86789110037884 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark45(-301.9728750045032,-477.6363224640874,2.286619478567829 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark45(-302.24222771549864,-473.3713004558804,69.53373404266489 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark45(-302.2876885492873,-487.39573415363134,47.115264982486224 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark45(-302.3847850595596,-489.9232392389679,69.75247253623715 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark45(-302.49267815281854,-456.634127260477,73.77262382548125 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark45(-302.68363011383025,-459.5388942334847,91.14584571159895 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark45(-302.7546202193743,-448.67605582311035,18.242468228344947 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark45(-302.94735681769873,-456.64582684375546,99.50365525146469 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark45(-303.0279058475688,-443.5025031085358,28.050823810611533 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark45(-303.1370447343829,-506.01747153045847,100.0 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark45(-303.3141723600261,-487.8241122768262,11.30348425709991 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark45(-303.38487371151876,-466.38486182473446,69.20321605662562 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark45(-303.4002457948782,-459.3980621067946,100.0 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark45(-303.42272953976544,-449.7833494667517,88.76620697300072 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark45(-303.8083026776682,-467.40194212394783,74.90734586080572 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark45(-303.9225605131464,-443.18897200554176,100.0 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark45(-304.0808516108216,-448.7300763088117,100.0 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark45(-304.48202670847394,-507.6647379497224,4.2105095485689645 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark45(-304.507453173492,-442.45841687144593,100.0 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark45(-304.5950816808449,-447.7755270157636,72.00142811893308 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark45(-304.62224745610865,-469.0066493007615,29.79694483102662 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark45(-304.6684468198065,-452.5910879459395,32.73427949282052 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark45(-304.9552760993432,-519.4899732103946,60.671680589334954 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark45(-304.9784806939942,-449.7962282494897,100.0 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark45(-305.0426523065241,-494.6995972688691,17.972974931768476 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark45(-305.18594551986547,-444.22625502436784,1.8292946838869995 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark45(-305.54788471938554,-447.5254639870426,100.0 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark45(-305.8856011819681,-446.0266946411771,100.0 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark45(-306.0536308822681,-452.1015865755081,1.151375849068458 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark45(-306.061988983173,-479.6165543484889,67.07396882822857 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark45(-306.2069411714515,-441.5692670653007,32.96852035265988 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark45(-306.2968702525065,-455.96031580969975,11.034312921256756 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark45(-306.5052023216542,-467.64629476895436,46.99046860520451 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark45(-306.6651696583776,-445.05886465933355,40.95292304090182 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark45(-306.95427126999476,-440.3899427559444,100.0 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark45(-307.216417589824,-454.5118205644043,100.0 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark45(-307.3007679629098,-459.3302052294467,9.510805019636651 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark45(-307.5305198075614,-456.0154501633901,42.71304609701977 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark45(-307.5601092388503,-478.156196531849,58.707447840521695 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark45(-307.66223117917434,-449.54321627182173,100.0 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark45(-307.79334169918525,-448.375183967171,94.44315591463607 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark45(-307.88566229257856,-475.4896960830667,87.71087821416569 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark45(-307.9612284012729,-442.16039596139433,42.7066207368984 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark45(-308.5173955676263,-447.66847176158274,96.79790368640118 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark45(-308.62387171173515,-494.08477305096983,97.90595562681816 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark45(-308.64484404958,-459.8938292662516,22.752426267286907 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark45(-308.8687343803995,-438.6688869768704,48.267325982264225 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark45(-308.89871829741605,-499.85874503979323,13.671570823561254 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark45(-308.9406854030829,-483.81773958348407,64.40139106255549 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark45(-308.9755353838087,-475.45995346956613,78.90251913936928 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark45(-309.0533819313667,-456.0898442746067,18.290913288649847 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark45(-309.0741035566118,-498.08777343175774,98.12036544872339 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark45(-309.33366350810974,-452.964859361372,100.0 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark45(-309.35412581620454,-445.8176222013218,4.193824049849213 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark45(-309.4855338205246,-465.50356962540593,97.4259157507527 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark45(-309.8537361579851,-500.16949049924244,21.7438533839007 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark45(-309.92723890977504,-530.4945995300873,100.0 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark45(-310.0269580380569,-441.2847616917686,28.334709824661473 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark45(-310.1470482323532,-444.7000853955609,31.487002447033646 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark45(-310.2669182377266,-511.50764349100604,48.24110157217399 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark45(-310.26939732996533,-463.96333932493314,84.07223737381739 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark45(-310.4181871635991,-437.38040509546045,94.07094667814505 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark45(-310.5872580564495,-460.347948034903,54.46414760680105 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark45(-310.73579902576876,-450.21359257852345,100.0 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark45(-310.8756457099836,-477.2450624481365,39.94873695009413 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark45(-310.9026374420289,-451.3437624640577,68.03618435763838 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark45(-310.9243551233144,-444.2248732445782,10.517841851072802 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark45(-310.95606890514694,-436.5707901722027,94.22092463480308 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark45(-311.1343391469043,-447.2237800789403,33.02250318454415 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark45(-311.4697843897522,-444.32665275245256,58.585994297092554 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark45(-311.532954740401,-441.0808655657838,64.0593981209762 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark45(-311.6368137676353,-442.0838706937923,1.959934887661603 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark45(-311.7238459224508,-441.23005399092943,100.0 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark45(-311.8252984418869,-441.5689540641761,56.53902979719922 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark45(-311.87650840674445,-443.6695655366911,23.76897359634185 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark45(-312.15158410744203,-453.7169807919025,24.453682527326023 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark45(-312.3121488173846,-452.4739950956152,84.92989351675257 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark45(-312.36595507160035,-505.421623862247,67.07688987267156 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark45(-312.9218851793775,-448.1279721681394,100.0 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark45(-312.96867361162424,-456.3549127671252,84.81066299198565 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark45(-313.0363190607464,-507.1011169015328,18.269861449017128 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark45(-313.14014880092435,-464.14299260933376,58.88847713689188 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark45(-313.3654903425768,-463.9411975642578,19.279846341665532 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark45(-313.5917063819904,-493.25477235072253,6.561069055247543 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark45(-313.6221953626484,-479.17539523423795,83.61216706862328 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark45(-313.631446517043,-515.5923529175344,78.71552796847376 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark45(-313.7574407927889,-473.7826171916095,18.507159198285322 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark45(-313.92640960889725,-473.0675910109095,67.24928146051127 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark45(-313.94549903063466,-464.9095357658709,46.62820255651968 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark45(-314.05607493647403,-436.8959785128016,27.86329935646505 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark45(-314.36429095130785,-457.2981316018385,82.03817363581567 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark45(-314.52572573258686,-491.9186863450494,55.21066174186387 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark45(-314.52972068310476,-439.5219097942727,69.42639213918572 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark45(-314.5465253488207,-438.946229699141,97.8813572710626 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark45(-314.66143212422264,-454.16873381197433,15.430366401202235 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark45(-314.67263616778615,-460.1710067463029,5.116742321547463 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark45(-314.7023497548685,-495.44152880024774,62.275400170373985 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark45(-314.7525052762938,-483.53215959785996,64.19530620361053 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark45(-314.7884477046005,-469.866736434665,96.69937351155664 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark45(-314.8160046735377,-472.77851531143483,100.0 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark45(-314.8531461269024,-510.0035431818829,100.0 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark45(-314.87698638270143,-431.4586649974276,39.62803826943244 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark45(-314.8912270474084,-452.9676164503799,100.0 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark45(-315.17521708404695,-432.6588854813342,8.164148585026524 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark45(-315.1793078290508,-445.67232003239275,64.4192519406194 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark45(-315.2995181091773,-432.46396777080366,41.63707819865837 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark45(-315.30611625672964,-480.36125335762773,100.0 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark45(-315.40445004056966,-484.36335737601877,31.407112838669406 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark45(-315.51510420272245,-434.4871599674506,60.66392875842743 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark45(-315.5697538555523,-456.9833289813103,54.14601392763055 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark45(-315.60274739068876,-442.4449449807866,94.90585996209376 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark45(-315.6593473466247,-487.97396401656005,46.95475320923049 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark45(-315.73194998279797,-433.4668568590035,70.57711382537659 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark45(-315.8757250506541,-492.93841455803215,14.783192274203103 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark45(-315.9024417967564,-476.3547121026843,78.45258728356009 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark45(-316.1772641561983,-491.3979384272677,48.9893301572142 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark45(-316.2025854682571,-464.51018314055904,74.40030145579945 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark45(-316.22071204095255,-487.9364133134567,13.486054900383266 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark45(-316.25297516451764,-450.4427339208974,100.0 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark45(-316.2830796099437,-447.01094726478783,100.0 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark45(-316.3235141674909,-506.661893135388,37.64145599470197 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark45(-316.3304906167566,-449.0311783474818,59.561007242168984 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark45(-316.3492327934038,-447.69433491490975,54.21918394907186 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark45(-316.470407470518,-472.4762563392098,53.18585408792859 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark45(-316.54854177068694,-431.7219263208533,52.01841184124194 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark45(-316.8253298819901,-452.15660727156967,14.81845485074571 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark45(-316.9277149979552,-446.40590550421626,34.417427808301426 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark45(-317.1461565834735,-434.4919828266683,99.10801046243517 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark45(-317.2678089432115,-451.7645355774015,12.252078057674211 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark45(-317.3581853156438,-439.5417542992798,46.10334105028443 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark45(-317.41737810181303,-431.93018207030144,47.47006215928755 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark45(-317.5045554861355,-445.3678472889079,13.859308294735072 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark45(-317.5155319824071,-439.1440531744528,16.022750056226883 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark45(-317.51922058307684,-431.8604625028981,97.2350098993883 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark45(-317.6615313855558,-444.79536994860763,76.49768274501781 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark45(-317.6716785679574,-482.0496164496754,49.18053813354854 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark45(-317.86574406118524,-465.5307621338528,5.7781379307418845 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark45(-317.9377528158139,-440.9674751097228,34.558092769807644 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark45(-318.4980673342883,-502.15768408283054,100.0 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark45(-318.9426206840334,-435.3949423098245,100.0 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark45(-319.3754096641637,-437.4086764408342,56.107556890885064 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark45(-319.39061003670514,-427.1975104754793,18.711285004613714 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark45(-319.5378959935523,-433.20908956057156,62.41464148285078 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark45(-319.8267234399278,-449.27419596436704,47.17916271989841 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark45(-320.26570494186524,-427.52367513414487,100.0 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark45(-320.57142948099136,-443.49963713451154,100.0 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark45(-320.63036099959515,-469.9692794939688,67.00074749204242 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark45(-320.8094665490935,-456.8635286279027,20.977169122953754 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark45(-320.81308630593446,-439.2150547194475,97.74606340802131 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark45(-320.89617865546455,-478.0487861226751,69.3326266815485 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark45(-321.03281902248006,-465.65775320173265,37.55609859369869 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark45(-321.1269061919817,-496.9180234676176,99.66244194428127 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark45(-321.1437698792714,-442.63758450876173,79.38687473064331 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark45(-321.2440564307373,-463.86716724822844,57.48451289822998 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark45(-321.28995808028395,-453.05181912242097,4.626934989818835 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark45(-321.3357055968053,-465.55527545146185,100.0 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark45(-321.38188283296086,-462.9774019021514,88.44388421607229 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark45(-321.76308711821514,-471.5195334009455,40.52314247540775 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark45(-321.7746214064494,-460.92447046263,68.03631958793005 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark45(-321.86378754767327,-436.3727938187193,36.00511814133128 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark45(-321.9103806341814,-439.8639213126306,100.0 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark45(-321.99659184109345,-458.16213647798645,100.0 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark45(-322.08408426156535,-429.49135757899376,98.0585326077701 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark45(-322.12418559778604,-480.92650229955365,100.0 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark45(-322.26979206885443,-473.0669451899416,100.0 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark45(-322.3281760156314,-451.23483173413194,100.0 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark45(-322.33463947062006,-445.8848326561715,72.93725307947702 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark45(-322.67648405837235,-430.5671419857022,53.57770495225782 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark45(-322.6829741985729,-433.8464531818043,57.83256132984093 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark45(-322.7189000580558,-454.2272154545618,20.093121530972937 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark45(-322.7953370078631,-435.00770456785415,5.924685745543022E-5 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark45(-322.8527721616559,-440.0355052439516,62.96245104448633 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark45(-322.93582203427036,-432.7661550041908,83.99589331826772 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark45(-323.1755246492003,-478.0180296749411,52.15709366944259 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark45(-323.2010033942649,-473.2118094049508,0.6628989632218207 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark45(-323.2368537791798,-438.9866416077519,55.69496848409773 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark45(-323.24757284380394,-459.9633862777905,67.63894706020187 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark45(-323.34973375333027,-476.81950973235894,48.020438126580586 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark45(-323.605521634571,-470.011583726012,2.989392016510493 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark45(-323.64663386604514,-505.52434579895754,66.76778960581728 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark45(-323.7406211395034,-440.90895202149164,71.18563444008706 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark45(-323.9987393683831,-444.2960340913196,100.0 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark45(-324.34322037172774,-422.27463506372,100.0 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark45(-324.43410530581684,-425.55914895730007,100.0 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark45(-324.53154195129997,-464.25011294472665,11.366696682963308 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark45(-324.58097899987007,-431.57549127842685,57.14976630787547 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark45(-324.728795942947,-445.9032105140416,13.639064880926682 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark45(-324.73902108693306,-428.9995336276319,99.61049463410086 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark45(-324.85618603739147,-436.0075452446761,10.129406872025086 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark45(-325.0181482345028,-433.2594143592471,7.206247859097871 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark45(-325.0329828085211,-430.9161576272836,21.319374821752348 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark45(-325.14514729330244,-441.5007433060133,53.327136188056045 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark45(-325.37399911490417,-433.9689200376222,28.992991764931908 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark45(-325.39013050794654,-431.272369386337,65.4291081963851 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark45(-325.3931888848407,-467.5507056198867,30.64991604091901 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark45(-325.4257816592591,-452.70467563494805,1.4720595235380216 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark45(-325.5355188798277,-454.92993721886114,5.9904166404961074 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark45(-325.63628438968954,-421.6740177833742,10.972315938837653 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark45(-325.6899803669299,-476.31936589111586,21.128843633187827 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark45(-325.7796632675114,-459.9197760094647,100.0 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark45(-325.83666906452186,-452.87935323010595,5.4735111093626045 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark45(-325.9994010229517,-424.9585304844521,100.0 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark45(-326.11931692960934,-439.89888734663367,57.10705683998148 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark45(-326.2499942298206,-472.86904758782003,19.19115171871016 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark45(-326.352774136035,-452.96416683585915,95.88560468493944 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark45(-326.6341880145599,-423.83923728963697,91.71268038351698 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark45(-326.64201672444364,-426.6854433657249,36.977942851048 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark45(-326.7540388372245,-434.1744755163172,14.746747220686004 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark45(-326.8630265018279,-478.1050472140632,70.38102302277551 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark45(-327.00102202057224,-422.6091449821095,1.4587005741039718 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark45(-327.15008514213287,-420.7605460323859,78.34757328450951 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark45(-327.15724505039634,-423.69441732007783,34.379598060640205 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark45(-327.4504253691315,-426.9609166845177,17.559862708971522 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark45(-327.52376861030956,-477.07890634800384,100.0 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark45(-327.52604511795494,-468.7278698194188,100.0 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark45(-327.5319800679396,-460.7008739013515,64.30073825223863 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark45(-327.676791935824,-431.7785197753104,95.47464890159091 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark45(-327.7587796468879,-418.69341269218603,44.61390855294283 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark45(-327.940463105964,-459.4793693373777,15.100350751961372 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark45(-328.0400280985996,-428.3992198895543,8.783264541761284 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark45(-328.05078504706375,-445.29199196325,87.62614937230893 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark45(-328.122942779606,-436.450977433647,29.779456578504124 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark45(-328.1917648633956,-437.2899073857363,14.468655595015576 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark45(-328.27278756870925,-423.96721200344916,38.39775883166834 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark45(-328.3397621978664,-460.98120768701176,27.245166385857587 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark45(-328.4500693779553,-436.58897826523116,100.0 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark45(-328.48673868454233,-470.59580130151767,100.0 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark45(-328.70145043905063,-430.3113777073,100.0 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark45(-328.72880337986606,-424.8648478105755,84.39979706372586 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark45(-328.9723184021064,-444.2199016005791,68.94376625499734 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark45(-329.0354863887778,-428.870685745115,12.390490171414285 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark45(-329.15271241834904,-433.5636894842526,100.0 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark45(-329.5298304477149,-476.04266826395923,78.99033038113188 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark45(-329.6108111886197,-442.28429073995716,99.65013141274162 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark45(-329.73686374771387,-434.9277869982703,10.944710806879016 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark45(-330.0713958719865,-437.32066764944216,89.5424956940756 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark45(-330.19231483677163,-442.5191116130229,100.0 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark45(-330.20988482647135,-456.6267896373688,74.60487928703074 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark45(-330.4301015441293,-453.99023098347186,82.15034707662531 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark45(-330.63773943664876,-429.51435017394897,59.61074701994258 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark45(-330.78623545590324,-418.4860433242909,49.805236982421036 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark45(-331.01227613435617,-415.7272093538086,51.118022386450406 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark45(-331.02320628228966,-535.4499678247512,98.33655058192417 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark45(-331.1225098378122,-423.12903376582375,38.84212823253412 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark45(-331.141095314385,-471.80851994217767,13.667899280592508 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark45(-331.1476617019908,-418.21432707682214,100.0 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark45(-331.150444595671,-450.5986011722455,41.91987851939182 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark45(-331.15330144956374,-423.2917375279995,56.047998145009615 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark45(-331.3513004057762,-444.40262428982805,100.0 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark45(-331.70036068743497,-502.5849235792416,8.616839406092566 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark45(-331.78662703365416,-422.20319405941524,30.604561945495448 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark45(-331.79976729141947,-453.47137253064886,100.0 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark45(-331.80568907399186,-415.4597156116148,35.34343267813233 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark45(-331.8423272890431,-438.1616681673595,89.19114261663913 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark45(-331.98252800130496,-447.7401398466677,74.0910788676207 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark45(-332.2057782079739,-421.8731989666527,28.45920097174519 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark45(-332.21656771891577,-458.15140203213565,60.75010134517621 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark45(-332.27784412390037,-418.3753973938891,6.614484848033683 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark45(-332.4435471023944,-422.871637824131,100.0 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark45(-332.586127842313,-485.10651775650865,53.83931551142419 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark45(-333.28269244336946,-421.6512869759707,87.23194452761629 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark45(-333.35175455052314,-458.0504045929425,100.0 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark45(-333.35565496684063,-435.21864369632925,98.77745148387064 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark45(-333.41039742028613,-428.52953837748487,93.40631419955545 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark45(-333.50331585352126,-473.32422758651126,25.873272466421838 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark45(-333.5950146383084,-415.51360871745044,57.89443221948855 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark45(-333.7482931874193,-511.8451193890774,31.106639492682376 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark45(-333.8571987218956,-415.9634774252042,30.91008425063265 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark45(-333.9022672762545,-435.7971308693447,59.421477117552314 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark45(-333.9178684539513,-417.0756817398024,5.619516829021393 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark45(-334.0761314218445,-424.59204523657553,75.01895434664323 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark45(-334.1587722775117,-445.5445013628114,7.105427357601002E-15 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark45(-334.1877207076231,-457.96356846004187,100.0 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark45(-334.23380633016006,-428.6041747395846,66.1596288998362 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark45(-334.3459046234382,-418.55162469368497,27.503568806113627 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark45(-334.4957969022931,-451.08132151928976,97.45974760503171 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark45(-334.62573575306857,-420.7939091793707,44.02589450119302 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark45(-334.8353950990188,-525.5260225537245,19.737213236559256 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark45(-335.2129994051935,-413.0762356613542,7.3566889396059025 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark45(-335.3342999849444,-424.16552123366597,58.526577272249654 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark45(-335.48875298996353,-413.8088117208264,100.0 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark45(-335.56020494375815,-418.25474024835023,11.234986585871923 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark45(-335.6684905634452,-500.84416261268893,91.626882717538 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark45(-335.7743220187392,-449.9139042108258,100.0 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark45(-336.04466649775105,-492.46739106581964,21.366724163412854 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark45(-336.2667059530027,-443.3540869290074,26.09379514007233 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark45(-336.3040423406221,-430.7816750247058,98.10936363574851 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark45(-336.4227555008525,-453.22267983881915,82.28805181655434 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark45(-336.4752462538716,-415.08673898650187,26.326561409009358 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark45(-336.51925421380747,-437.7501866989803,100.0 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark45(-336.85250304894817,-485.84457521761044,72.47474129008219 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark45(-337.1192073214537,-474.6668511957823,100.0 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark45(-337.22147571083116,-460.47901039731624,9.621200276571656 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark45(-337.3652729321906,-414.2344694814243,24.1234297304527 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark45(-337.5183021023661,-430.948555539672,75.0181338577463 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark45(-337.52254638793306,-431.8761193884966,43.09297781884197 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark45(-337.7355627820087,-449.12050326560336,22.6464338885133 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark45(-338.02939510065255,-412.79815886528706,85.63628600708881 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark45(-338.126304618338,-411.88134490805163,43.262915022987755 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark45(-338.75772009010865,-410.8876382817658,94.51404348449398 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark45(-338.79704101669216,-417.8679092820926,62.190567856444204 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark45(-339.0768733025218,-417.0827753622655,38.31738292731444 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark45(-339.24106827210437,-435.0288244587572,5.524965379398722 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark45(-339.3736137017097,-415.2017453726104,34.07280133275199 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark45(-339.4412883731035,-428.3874896647886,10.257857421659764 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark45(-340.1248618184821,-439.03295862151316,75.78539093458596 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark45(-340.13447843211316,-467.1518250542192,15.861078318813863 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark45(-340.240595105807,-419.80618547184196,1.797061953989413 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark45(-340.3808345753745,-473.6383778686609,78.81363394430336 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark45(-340.50972281387294,-410.49587937848196,49.74493951103699 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark45(-340.55752009502453,-408.65714067843214,70.81169334507584 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark45(-340.7662789827579,-415.86734920107745,19.141632093738707 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark45(-340.76824173425155,-430.8679057409294,1.1637521008365042 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark45(-340.7817731542178,-447.67369089984203,9.66150414818891 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark45(-340.84883828915366,-418.3228272440282,72.52954413559755 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark45(-340.85579411903404,-479.1557291752932,10.005502542392989 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark45(-340.89466679953534,-416.1086676711416,4.935237556260304 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark45(-340.97573515624674,-544.329098000283,28.24545417519576 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark45(-340.98503480802793,-429.84398119218736,24.5432935534714 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark45(-340.99625275616575,-418.00720315485546,97.96351606508159 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark45(-341.00369233024765,-428.33511711914747,14.829884877859925 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark45(-341.03449957765065,-415.3962257662107,22.07387445549449 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark45(-341.07225749610495,-409.2919899609443,43.625984672001266 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark45(-341.11974178788785,-461.9871154638457,37.48049290595338 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark45(-341.1756185489715,-409.7818981302609,24.107098273369076 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark45(-341.183536880137,-480.82458712587425,67.48494305667373 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark45(-341.184771708079,-413.30328901058397,10.918799332982033 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark45(-341.3302614722101,-428.1052245675745,38.010576876666846 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark45(-341.44204027063955,-484.0534377108728,61.144312145410794 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark45(-341.76770553380277,-426.5525142859676,84.66381747207143 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark45(-341.81786109249464,-439.0472921003897,23.775666265201068 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark45(-342.02993180901535,-422.4080245932073,100.0 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark45(-342.1802588692828,-413.3141596429161,25.42502952279723 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark45(-342.3963205899106,-406.95675228204436,67.09477636129282 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark45(-342.5141160346181,-440.7687096812626,34.450341918909004 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark45(-342.5368825624182,-428.4888927376602,100.0 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark45(-342.5773018702742,-460.88138080138185,83.43054054049594 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark45(-342.75261108308473,-418.9602599277857,94.80919486115741 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark45(-342.7645595646064,-433.9303273290948,30.937851166398687 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark45(-342.84685153537623,-432.02092721634915,59.72741066663788 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark45(-342.9212247279966,-405.91532775783134,34.15394586345221 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark45(-342.96576926264686,-479.3759563923569,25.194289965533613 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark45(-343.1448603425521,-427.7272642573681,76.53439778652748 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark45(-343.17203267081624,-426.9826109384651,100.0 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark45(-343.1998721676873,-405.70594732518805,15.776002030300987 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark45(-343.3662053164502,-403.09574757829364,69.96647343425667 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark45(-343.4413631291057,-409.8360875407041,19.579048862213995 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark45(-343.4704822874752,-403.6047088299985,41.60098733280746 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark45(-343.65446357213625,-422.40020289784235,0.3045391912468771 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark45(-343.72400175583635,-466.6012516826807,28.70234425261839 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark45(-343.86200493889044,-407.65114248411,42.58381641314148 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark45(-343.93888193269686,-416.8720513139474,80.1355581419339 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark45(-344.27873090008507,-477.32077912377736,91.67216043784816 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark45(-344.39148605530664,-402.6461931302665,90.75021623724717 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark45(-344.3936537941655,-404.2516105986847,84.52858471084397 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark45(-344.56411801194173,-464.90269203914977,73.48796977206433 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark45(-344.676307264792,-432.6261473061856,88.0478971436068 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark45(-344.8052279900956,-428.0026321109038,39.73974162875044 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark45(-344.96472091925966,-450.8152855451645,34.344261988662566 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark45(-345.0027727100419,-414.0868904309603,26.760058414189245 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark45(-345.15451383206243,-415.0910205261535,20.72140301238735 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark45(-345.30021762470625,-439.16700422003873,52.80157838914559 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark45(-345.3058056727169,-428.67960728601923,100.0 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark45(-345.4227996133875,-419.711050812884,100.0 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark45(-345.51561200006427,-442.51043087726777,76.32335755517806 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark45(-345.5469979019671,-409.0605410637543,20.537141024215245 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark45(-346.07796520546896,-447.60670242424214,100.0 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark45(-346.1034820276791,-446.9360514877624,61.48856670331571 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark45(-346.23009222531306,-440.67785409766697,70.89896906934524 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark45(-346.32282135612604,-452.2216316693001,100.0 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark45(-346.34675172873176,-406.0190776051635,96.02888811660623 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark45(-346.49390915732704,-452.403607879316,2.3674658463107363 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark45(-346.64499274026684,-420.8123224894247,53.92167720150556 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark45(-346.81368990175633,-422.9524181856631,18.59447673868921 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark45(-346.9375970224755,-426.6237301099199,22.12261517378751 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark45(-346.9922446502719,-442.1964102858536,23.398570681236365 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark45(-347.2461598429751,-462.20668459550086,63.80743481222552 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark45(-347.3398352226085,-436.79492154914084,31.601957226164046 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark45(-347.3474264303018,-455.8246294567421,76.28666661690653 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark45(-347.3564569761482,-433.0066413605868,100.0 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark45(-347.3596548510743,-401.49305890436705,86.16832003219295 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark45(-347.45179985173723,-417.29981765638075,75.8614565143406 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark45(-347.7986541185035,-475.31329147107806,68.91367591049598 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark45(-347.83573425606454,-422.8269403496164,79.58376453566603 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark45(-347.95190261482867,-413.2084403214236,47.26461559799057 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark45(-347.9729860672187,-448.4100963296963,63.99790585991289 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark45(-348.49788793530973,-403.4845315059277,88.00159889448068 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark45(-348.51755047660123,-456.709859422015,55.62712626795795 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark45(-348.5304633881771,-469.3471776272202,54.6284695926484 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark45(-348.53332101910905,-400.60823218913924,100.0 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark45(-348.91564796103967,-415.5259173962482,32.80215179183341 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark45(-349.01067601651454,-398.47395132126536,20.823146504756522 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark45(-349.0957830736071,-453.2432366969305,100.0 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark45(-349.11025096086524,-404.16920948080474,63.92850485768378 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark45(-349.1846133144565,-433.7161755946335,2.958742695167956 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark45(-349.20486238859445,-420.0105725355606,100.0 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark45(-349.20864792996434,-463.01565853764123,97.26417015250667 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark45(-349.323406087216,-442.2930876356365,42.09914150549856 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark45(-349.5203927615701,-450.3009155319456,98.92653807003543 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark45(-349.6238639831238,-449.62289098308247,11.44960305974169 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark45(-349.7175485308307,-404.0802230867905,29.03471508104684 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark45(-349.7340920376642,-405.276212517704,39.729214040087555 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark45(-349.94664917657826,-402.44738736065955,99.33690703378977 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark45(-349.9483943303374,-455.3241741807526,43.521881902875634 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark45(-350.06080864109197,-443.36312281033975,83.30833990165982 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark45(-350.4113923009716,-399.470344249018,17.53897446852666 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark45(-350.41705501423115,-427.8843886863807,76.3669850242496 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark45(-350.4923978597793,-489.45216954394897,68.46759325393108 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark45(-350.5269651773483,-406.87596301541765,24.154638789650363 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark45(-350.76760099261315,-438.71798661787886,33.00410855391601 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark45(-350.96235826915193,-395.63881626428656,27.34770673181191 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark45(-351.0139615859034,-435.93529763201565,34.3965708576072 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark45(-351.08490713799034,-430.5851452530363,57.385214735959124 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark45(-351.08615447225264,-421.5643342947501,58.45617217352162 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark45(-351.1923789992035,-421.41116614044677,100.0 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark45(-351.250724530319,-416.0250293088719,48.679437346047706 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark45(-351.3066452941137,-446.1218208264009,100.0 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark45(-351.35462315715137,-420.8393476962297,32.15253840431214 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark45(-351.379927426581,-417.50067207224134,26.42563250212004 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark45(-351.56338897283166,-415.04650334372786,39.43817747445081 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark45(-351.7368139950137,-395.9078686683303,41.244487506640496 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark45(-351.80389078991965,-448.53853873898436,99.27291631063952 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark45(-352.16271404828365,-444.3355704451378,28.130649310131105 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark45(-352.1651845970763,-467.20003473680725,19.203197832539743 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark45(-352.2451937896812,-401.3807190963538,19.03597853431775 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark45(-352.2688230916093,-423.5937352799692,65.24385568050178 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark45(-352.43786095921166,-394.78893259004906,47.49768349315205 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark45(-352.4402525373612,-408.22029116864303,34.99287211436351 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark45(-352.56565384506786,-412.8689814078492,86.40145360196433 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark45(-352.6123132582415,-425.0010843756787,23.945827839119886 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark45(-352.6401852081498,-412.5733558377167,88.15992281468229 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark45(-352.69533487121544,-413.75769538031,75.0087233240871 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark45(-352.77841064966094,-403.9474843476939,90.41704527963998 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark45(-352.8467649701203,-447.2198687718775,18.376332818437618 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark45(-353.343875974313,-464.5005532291434,5.689130282947289 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark45(-353.53604105063033,-398.25813369898003,69.31084274319389 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark45(-353.5377262610038,-426.5720748573583,34.244094100258565 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark45(-353.57801192762656,-393.00067774854205,38.70907863070039 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark45(-353.73675257197004,-440.1768711692755,35.62606714903498 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark45(-353.75951455526615,-423.291586438471,23.063595643629696 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark45(-353.81416405409044,-427.38013333617556,35.10688631381075 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark45(-353.82007530599765,-404.24991880062925,7.556453198299479 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark45(-354.02136478661293,-413.0769258644604,58.81490633086352 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark45(-354.1009392261205,-411.26793602777553,72.04651887574809 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark45(-354.1059814419013,-431.1057409984455,26.03759647626201 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark45(-354.1928706326408,-447.8379546904165,51.87046288913432 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark45(-354.32389022741063,-400.1164581236293,80.20740183903493 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark45(-354.66809456007616,-447.59560960987153,2.2123825406902 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark45(-354.66966992621343,-416.06824340326614,26.9126818451102 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark45(-354.91896504129477,-425.9152935058974,31.444941074155025 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark45(-354.9677822630336,-438.2349269519526,49.26878792303066 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark45(-355.0429080353074,-418.5615095904787,43.89276537475419 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark45(-355.182181712041,-397.03591006286985,100.0 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark45(-355.24407567494166,-422.70579194713724,99.91145998239622 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark45(-355.476164529412,-395.9879276648209,43.41798378032965 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark45(-355.9290133665413,-392.74870777103274,34.13575651438484 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark45(-355.96749969334627,-449.38686449177726,33.833318375278466 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark45(-355.98356148225736,-413.91762439874134,1.9115448934583128 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark45(-356.05453347332707,-398.93756334299087,85.9304559798793 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark45(-356.1049362360567,-466.95825250113137,27.888512804279372 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark45(-356.389690300425,-418.09107934148795,28.98998457685272 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark45(-356.5464875964872,-401.95848041212815,100.0 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark45(-356.7049466791283,-403.43781080593664,76.72941865612012 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark45(-356.89926077379425,-392.8136200934498,38.90633557025748 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark45(-356.95299973115476,-457.12971488006923,51.23975493703094 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark45(-357.27085585371725,-405.31169884753837,7.962457227056021 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark45(-357.3150515960532,-439.11602909223467,73.61208040487662 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark45(-357.4127189420775,-470.7517881269528,1.9096455991608607 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark45(-357.45372112645043,-389.6542942015543,45.34586500859146 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark45(-357.7097166797581,-392.9871391903008,97.10089451405639 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark45(-357.7286317537164,-398.27515559682803,6.014447572107983 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark45(-357.74816915965107,-442.53716315523286,54.05113900836503 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark45(-357.9307826988338,-447.4605275124579,53.432778174876944 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark45(-358.150954222801,-418.6231789898908,72.5642477082464 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark45(-358.19702331344024,-389.63737428898537,49.26992352441857 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark45(-358.2354892542611,-419.57745138690416,54.04008081117626 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark45(-358.24944776961587,-423.9012046884828,38.805890140313494 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark45(-358.3984257796072,-405.2428788760341,74.26784242633661 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark45(-358.7213633936958,-428.2995869477647,61.661962281378464 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark45(-358.83010098407397,-397.7744671550425,60.738314409693345 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark45(-359.01824652886063,-445.090537857899,91.72083740836109 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark45(-359.02983706711325,-393.18517101889233,28.37879278507188 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark45(-359.0338384383589,-415.8083847877664,92.22692429033782 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark45(-359.08870407394966,-461.6086836140902,30.54142200747956 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark45(-359.2653138361652,-413.8584370216228,100.0 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark45(-359.3670089984546,-448.522580880917,100.0 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark45(-359.4763608901302,-387.47914083278744,36.27269778112171 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark45(-359.48565007767036,-480.5482069788923,2.6346977319198004 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark45(-359.49821815227676,-410.5229820477787,65.60076665780309 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark45(-359.5692686240996,-392.78854730174896,84.10636504345635 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark45(-359.6475366847265,-399.34204971806025,57.237274804265525 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark45(-359.9303697497877,-392.8084194097385,50.64307504965936 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark45(-360.03954493008195,-421.5148119261091,13.25554923456798 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark45(-360.1686814096129,-389.358952409077,92.26137134659146 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark45(-360.3581527952923,-429.62485490420886,71.41042838023012 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark45(-360.3654407898678,-387.48929130971663,54.921776922332924 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark45(-360.4098771557146,-433.57914128106677,13.963213943503021 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark45(-360.42334273194405,-433.66113658612153,25.416979847712852 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark45(-360.4317750235913,-469.11443870362837,59.83943498234589 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark45(-360.4803582195109,-394.2643362094992,77.48940771035055 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark45(-360.64186419283016,-389.2555005667346,83.06035154604433 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark45(-360.65480659502776,-457.09482741569497,100.0 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark45(-360.66498270939013,-391.61174657789036,56.867885806352376 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark45(-360.73714327594917,-440.6321899881851,58.691722845057456 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark45(-361.0385124961515,-415.7553759579469,53.67863952258395 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark45(-361.04193844404324,-412.7502778606348,49.45944665776673 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark45(-361.29612118221496,-397.79716879460454,44.3440538272437 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark45(-361.4182368497569,-417.72410760654697,40.01088004218329 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark45(-361.699083693463,-390.6664941396169,19.596621113143172 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark45(-361.78149807357784,-399.84148595548186,8.391978643641792 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark45(-362.0366260851978,-384.11097282552913,3.4347820029443596 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark45(-362.1725956161652,-383.97493194848266,0.9460837939161877 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark45(-362.29490122727003,-445.1237687853827,33.526091785697304 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark45(-362.3367473216471,-397.322017350837,7.149395416169298 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark45(-362.52001000491913,-427.37524952562137,95.63807273556495 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark45(-362.64906923633345,-403.84507808246985,94.65220854606287 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark45(-362.7393444963885,-417.5006961650664,32.44416330753816 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark45(-362.9913078956146,-421.0981047898877,70.51391068314294 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark45(-363.16860129001435,-431.81699849628797,39.65512678027771 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark45(-363.4241585311456,-412.9189597458526,4.290296154843489 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark45(-363.4700483397325,-412.5950827317873,75.45477242767345 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark45(-363.50501410556,-455.2395125445909,10.633240395116502 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark45(-363.5351480764683,-396.0058629092129,72.57596501682585 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark45(-363.89370325665027,-404.8723500409679,66.17763120749555 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark45(-363.9417550427392,-535.7419793296497,53.68293244659543 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark45(-363.9735576567939,-453.6628714105191,13.070396171092042 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark45(-364.2272032501819,-401.7485017397213,50.17784629146139 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark45(-364.7918345778893,-399.20613751351686,3.0061572632773306 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark45(-36.48603918263351,28.451961716713896,-18.975679345218424 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark45(-364.8894297454522,-426.72306881280355,33.77552089496439 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark45(-364.92706963843466,-399.33323186021374,33.63548891118816 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark45(-365.0804900790845,-426.08177772590597,72.97710546639402 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark45(-365.43610094621323,-403.16011771828374,19.319375804581895 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark45(-365.4615473093901,-401.5367330834714,86.97597430862862 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark45(-365.6387081410823,-395.60416451782174,32.03955432173748 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark45(-365.73103337148285,-415.7048364758579,100.0 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark45(-365.87605317361,-413.4608416415069,46.86450110249538 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark45(-365.9901253942522,-393.24977530550507,27.3998220412754 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark45(-366.06262625284353,-385.74522504567653,1.3223478930562464 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark45(-366.1122539359196,-399.926392831241,40.05626001540739 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark45(-366.3322834594099,-398.13722511370077,55.60722185129666 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark45(-366.3535256835123,-384.63900279157065,50.6531616554951 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark45(-366.4051787438335,-385.62554493437653,17.233812244675462 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark45(-366.5038913459385,-406.37775344789117,100.0 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark45(-366.6386329269498,-402.8377352564221,76.33302454625611 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark45(-366.7273363747241,-394.03419223522405,71.21298847876446 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark45(-366.98896651110914,-443.7176773032783,41.276256396777654 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark45(-367.32081403086,-396.30159554321943,36.07297273495428 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark45(-367.34435210567375,-419.2683350334317,100.0 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark45(-367.35854435521173,-384.80684997122347,18.938514245430554 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark45(-367.36171931775186,-379.561303301584,34.36866989094797 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark45(-367.4397787835276,-499.14211125716156,100.0 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark45(-367.498099673377,-389.93828691183313,62.81892435192201 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark45(-367.7838436749201,-393.3374583662494,72.67602755030097 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark45(-367.9869453476759,-394.7750203732961,87.02310193367583 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark45(-367.9983023624691,-387.65307039395634,42.54267659346643 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark45(-368.2229807914881,-460.6285450114439,44.644405172149504 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark45(-368.52142927045486,-393.5925469252413,45.08874141504023 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark45(-368.8188274941217,-417.52741512702045,49.466770135164296 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark45(-368.96346809674725,-415.4269440324732,96.55380237174381 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark45(-369.01369922471184,-392.6973064888147,43.16028141280654 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark45(-369.0613849343827,-398.9685467719146,83.71592397440381 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark45(-369.1568537937433,-377.4977395485996,11.688385595694356 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark45(-369.16341507195045,-382.34739430509984,31.636581508678574 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark45(-369.1716630567745,-387.73118604721014,2.253708427135706 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark45(-369.19957159393334,-456.8658694361442,100.0 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark45(-369.3056187148456,-378.13294244318854,8.975513058404829 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark45(-369.3741427149569,-396.66939126594696,22.286630324708895 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark45(-369.5003904746565,-446.2292162425215,48.677734922657635 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark45(-369.60305380840396,-404.5181944913704,100.0 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark45(-369.6188400231159,-437.3125636280211,100.0 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark45(-369.6496619302479,-379.9504039690749,11.700953262087864 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark45(-369.89224062822933,-415.2907152090512,26.576525780646904 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark45(-369.9157577459152,-398.69263499605216,64.61324446290376 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark45(-369.98120355342803,-384.7649987404655,100.0 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark45(-369.9906304365329,-388.47288106794133,5.956746892827752 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark45(-370.2204458284878,-386.79627004592845,1.5949514507027729 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark45(-370.3601346604934,-396.669414036996,67.56111048535075 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark45(-370.51446257462123,-375.56844921113225,43.81762370678558 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark45(-370.5426965748873,-377.0116514589846,100.0 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark45(-370.5697039790305,-408.69360540108414,90.71815185943862 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark45(-370.6160778950478,-377.0229333198202,63.75380408971992 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark45(-370.62651885814313,-404.3531637089217,18.24314923565818 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark45(-370.62884261816157,-390.89610325691206,46.50348008164801 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark45(-370.6589390256896,-384.5457893254015,54.57895513936643 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark45(-370.7344797176123,-403.6799319300055,83.41313475526962 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark45(-370.73524428824817,-413.5775689279508,32.43076103566861 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark45(-370.8463742642856,-389.0465592132897,5.602371269192432 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark45(-370.8743644313236,-402.6155239006315,9.633601127346637 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark45(-371.0955401995545,-396.95513737030274,7.411386765458701 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark45(-371.5079125425906,-402.9053678618342,100.0 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark45(-371.52189765934656,-387.41457953236403,23.151073361696945 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark45(-371.7854439148977,-445.3133758379003,53.83652155334485 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark45(-371.82880101086624,-388.046087167881,63.01374248596045 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark45(-371.99903034856175,-391.7626573872882,100.0 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark45(-372.0043566368167,-388.12285053541945,72.2020695857318 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark45(-372.1878850418963,-386.2785471852313,18.39670620344633 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark45(-372.4275125079456,-431.7140859035735,100.0 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark45(-372.5496040508947,-398.13909851167256,100.0 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark45(-372.5765560203742,-424.0737497020295,0.979683690136298 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark45(-372.6940499970211,-381.7117501750948,20.95300750585048 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark45(-372.7346650484327,-385.46759386145544,29.36896382414659 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark45(-372.8583490990326,-405.1391094376422,57.364493162321224 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark45(-373.03157344026835,-399.025800506957,64.1926739718258 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark45(-373.033928669382,-380.15997425547505,48.31301888814369 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark45(-373.05656298926135,-438.79452035819173,48.72966096375876 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark45(-373.2684759078185,-381.2895704213507,76.71894735332558 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark45(-373.3469345419321,-401.3084798797689,33.275838768404384 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark45(-373.34708900287995,-373.6431440716191,100.0 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark45(-373.5864289492083,-430.0220472046408,9.1868008913289 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark45(-373.6673193797303,-405.70973766693294,100.0 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark45(-373.8609508288113,-394.0654193107479,22.491268482419486 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark45(-374.0828703974659,-389.87672795132727,53.002591941873504 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark45(-374.1021084084053,-372.5136254653134,100.0 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark45(-374.1257558484848,-429.31881929794633,74.05572589404139 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark45(-374.1444347239025,-386.67415435310875,61.50248393717018 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark45(-374.1621342496506,-374.10111216814795,99.81570551044612 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark45(-374.4894453189319,-407.8765505102908,61.949856839229255 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark45(-374.56789786577843,-436.1970551642062,3.5485371472381195E-4 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark45(-374.6216215817007,-372.5894127823635,8.004986508047281 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark45(-374.7777106486324,-375.05817829893,69.92916064604827 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark45(-374.9221124270252,-423.1890749176691,99.5365710457358 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark45(-374.9453109173793,-392.4173119459516,22.188979218115207 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark45(-375.1453116813146,-372.9252965086252,100.0 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark45(-375.14963877902653,-380.16005820021894,97.72004086297986 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark45(-375.2131113035637,-374.5184501435072,29.770702642045137 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark45(-375.66861037786873,-393.60951614657904,97.8245736116865 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark45(-375.672989834816,-425.90765380370294,63.223478534566425 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark45(-375.7256491231985,-411.47036672862725,20.197046822620138 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark45(-375.889941641183,-410.26867957478623,41.389918273213 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark45(-375.8926766990075,-392.7608269560369,27.10204520443486 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark45(-375.94506703239614,-374.0522676997704,100.0 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark45(-376.02999074383376,-389.68527934541027,75.1075424883858 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark45(-376.1613520296549,-442.24632006287834,100.0 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark45(-376.4635715699204,-385.44027899802677,58.67198977930491 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark45(-376.5028730655936,-427.24758426462483,100.0 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark45(-376.5190744309578,-422.47099890831294,100.0 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark45(-376.55354884070874,-374.25527619763136,69.35061627381401 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark45(-376.95582969380223,-380.43298473431696,69.52451982970237 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark45(-376.95775454210934,-465.40311078657027,84.3906844789463 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark45(-376.98635038790496,-412.984129155235,61.22264561630453 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark45(-377.0034450255054,-385.7601044528662,67.53007143308767 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark45(-377.30223574291426,-371.58288287426683,61.629613827434326 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark45(-377.3233835224022,-391.645559263095,6.447255002690923 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark45(-377.3672842488614,-381.6244661762643,15.066549306842283 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark45(-377.4291710342497,-435.8322161571248,100.0 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark45(-377.78185387150774,-369.1407552818485,36.21402161720718 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark45(-377.87771273249405,-368.87274356148356,8.216491529655727 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark45(-378.03170662012445,-447.83882371133177,100.0 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark45(-378.1782941143411,-377.1760115170194,90.00499226513807 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark45(-378.1869518901294,-395.83668861363003,54.14490398640686 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark45(-378.37538985260306,-393.22043784167613,37.81609237970528 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark45(-378.65807581198516,-388.96749637839497,18.560632233259724 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark45(-378.67993224807043,-399.94218002683016,40.68731495088389 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark45(-378.79526240190285,-370.8423419340198,71.6833868255915 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark45(-378.87967612039165,-369.2861170606128,1.338593454494844 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark45(-378.91275164827437,-396.1355447716622,47.12455163473871 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark45(-379.00504528844476,-368.56846912232186,12.677839614700105 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark45(-379.4120732266682,-393.4424529453849,86.91059786130535 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark45(-379.41984897584535,-395.6587407083722,1.6410867182535327 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark45(-379.42972824839177,-453.56510874667623,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark45(-379.47594846765196,-391.51779195893533,8.810423737161344 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark45(-379.50276631901903,-425.3370994232998,41.74012135889285 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark45(-379.65539173765677,-375.8742319104375,47.42720933238786 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark45(-379.8244770000568,-367.2422102706859,93.24712553208946 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark45(-379.9029663391464,-374.3670519851689,58.92438737850648 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark45(-379.99382431837773,-371.60642257232865,89.47766223222408 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark45(-380.0765756064568,-372.577909346726,11.727137585837681 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark45(-380.1315682036873,-414.6190596481354,17.79997309895402 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark45(-380.1753917287119,-368.05812428462883,24.879119063035816 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark45(-380.18460134631454,-383.0201399041247,58.26730811396317 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark45(-380.3771235857366,-417.6450663133758,46.34145510904665 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark45(-380.40812385554085,-372.2222387388431,63.74705741276054 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark45(-380.5581700469646,-367.58842559711144,33.39928284987502 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark45(-380.9060086267104,-394.63984129316,10.326509707131414 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark45(-381.23299353196956,-367.25120949613154,100.0 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark45(-381.58326615978046,-387.2704330539027,10.25866872013323 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark45(-381.60998136578235,-377.2382014194275,100.0 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark45(-381.62436277528417,-367.07980264344457,24.425527477242333 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark45(-381.7078964942672,-389.9453266564379,100.0 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark45(-381.7163295439323,-376.0474002467821,75.73679809119932 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark45(-381.74305861491285,-426.947403639258,85.03680991656466 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark45(-382.0650317267551,-383.5472317760499,50.246434322245506 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark45(-382.2583288494989,-371.98625902129976,67.98468619545054 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark45(-382.2716468343666,-467.52231585237695,12.639974420744807 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark45(-382.62944075892466,-389.666332568948,91.89304922968208 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark45(-382.8538740194479,-384.0630801133484,28.86261476725832 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark45(-382.8549795701209,-385.32269409672386,100.0 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark45(-382.9755829864071,-368.0148967213149,41.17784365445755 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark45(-383.02267510715336,-368.5268490570867,40.52325560390187 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark45(-383.12546656963104,-365.5812113979074,58.178327709088705 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark45(-383.6171776480845,-367.9155613416772,5.7901777625764055 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark45(-383.77978781218934,-362.42078379490823,100.0 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark45(-383.7958442727224,-444.05408977198823,58.630566448725716 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark45(-383.7963003780811,-377.34550495212505,1.1385070007495832 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark45(-383.8085009320851,-365.39287055589523,14.467718564697108 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark45(-384.19449817954023,-421.49276668871664,95.71271877114833 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark45(-384.2054834165833,-366.6653098026323,61.39020755841278 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark45(-384.23731794542755,-363.1327625018299,78.92158874469916 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark45(-384.5017714011059,-364.8195630531279,35.87865790815076 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark45(-384.55789386838353,-372.0381198969004,47.266635878776015 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark45(-384.6680031098514,-411.09139558192993,69.92805234621753 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark45(-384.7916535043846,-364.49934348137356,12.914242467177829 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark45(-384.9343375041402,-361.9617532572744,95.52835113927603 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark45(-385.0088432978224,-380.5647016111255,32.13032337336054 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark45(-385.04339255781093,-405.608581721123,73.93733220901336 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark45(-385.1182070062501,-372.00065223818433,9.048963630333432 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark45(-385.1868788256059,-402.7269221180081,97.37406776562051 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark45(-385.3128425016941,-389.03881241838684,100.0 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark45(-385.32882979517177,-363.9987111092571,56.61472294979461 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark45(-385.50647088669746,-368.07656311342095,48.759830352334234 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark45(-385.5819358654593,-361.80447433899917,24.531126923242866 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark45(-385.7670818889617,-365.61093940054104,72.46062845164124 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark45(-385.96484254372234,-400.3851560160353,62.32176437489913 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark45(-386.2232387301543,-371.8268512164331,47.05709809251255 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark45(-386.2664367028972,-364.00705394017234,6.854715808052276 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark45(38.62857687933007,-789.228672902,0 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark45(-386.5279679097201,-375.1297507209633,72.03001936923266 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark45(-386.5528995396538,-388.2662335103918,100.0 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark45(-386.6927922781191,-394.29711158202633,45.5935674658497 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark45(-386.7202133618593,-426.0805781051445,62.28818365257888 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark45(-387.20450389947297,-382.16446647961044,16.154987022133227 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark45(-387.25468813201684,-380.70155611539985,87.66546378769928 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark45(-387.3368173238847,-374.6119414078261,62.26751695793041 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark45(-387.34553772699996,-406.5563555301837,100.0 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark45(-387.43311006733717,-418.8040875883848,50.21235151477322 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark45(-387.46821737344663,-364.50601128148037,99.95715748372385 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark45(-387.5677859308898,-403.8614378290728,23.09882031943917 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark45(-387.6518831558816,-387.3866410814714,75.63447938673065 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark45(-387.7171752206386,-384.1261134751307,42.048768774851254 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark45(-387.783547767431,-452.43886115396657,61.48661747698054 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark45(-387.88829819371585,-359.0111167770926,54.67879396814041 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark45(-388.2573726853144,-397.8054070319474,100.0 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark45(-388.4321152035029,-379.3136234069167,0.9023973592280758 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark45(-388.46704916513727,-358.47232784552835,55.851635934826106 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark45(-388.5497680725404,-370.7065535053822,52.998668643045875 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark45(-388.6261678011706,-388.360980869167,24.71278417488969 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark45(-388.65192970817805,-377.6153192002484,66.45697131890017 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark45(-388.8589170708435,-358.3072772917464,38.10456652841424 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark45(-388.863962013684,-366.6426157873098,72.74977295986079 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark45(-388.9006100395153,-396.6342597395063,7.526374028139003 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark45(-388.9740999359949,-382.2938956390765,80.11329818757446 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark45(-388.9765843136096,-360.34364429320107,43.023302282565936 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark45(-389.0913444774422,-370.3142592577919,100.0 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark45(-389.41722223331266,-378.6385265668168,100.0 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark45(-389.4245371480552,-393.7116552451105,87.4009378034437 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark45(-389.43512466175736,-373.54984903764824,42.643378511639185 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark45(-389.4925966256756,-403.7969007462277,74.60457901840019 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark45(-389.6115879801402,-436.6991199725625,72.13017497319075 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark45(-389.657221106806,-356.7223714216463,97.61938659244265 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark45(-389.75839931222123,-373.0252207011591,95.04209354464544 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark45(-390.1026075034772,-358.49428391064333,6.776145274173672 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark45(-390.2495650974586,-366.70977831677214,96.81282688716871 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark45(-390.29307725672606,-388.05871767061274,58.70883859149819 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark45(-390.3766910489635,-414.10802489294775,100.0 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark45(-390.59078019424305,-380.7747643931289,13.51799121329843 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark45(-390.6324410121713,-359.66052013293614,100.0 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark45(-390.6991998258759,-360.34336678235246,81.20375438385545 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark45(-390.90211167744553,-367.50705975281534,92.68206941963723 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark45(-390.91716453631767,-370.912028931759,1.0520509056175342 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark45(-390.93104436366247,-364.59084861701024,45.052970569760845 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark45(-390.9869428992823,-383.7983265158872,35.79047286346096 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark45(-391.01170495525116,-370.54535278853604,26.603548300699714 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark45(-391.05335251446445,-358.6166222821494,35.4294620709008 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark45(-391.06765289929365,-367.5701206670853,93.7894858904483 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark45(-391.1056687678561,-387.00060922203556,5.689942891812109 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark45(-391.2018171079227,-379.40364819467374,29.69392342545453 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark45(-391.2807518942351,-419.2857388923337,50.67351429145717 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark45(-391.2862566318543,-435.1793391535993,100.0 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark45(-391.397582559262,-420.43495257070833,52.892707097779805 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark45(-391.4148938190468,-390.79563411492745,37.02422896218599 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark45(-391.4163503585182,-374.79422291746835,10.762751288708785 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark45(-391.53561585302623,-359.11991965699815,8.881784197001252E-16 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark45(-391.58578759005394,-356.30023064653994,3.7231988117616623 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark45(-391.78161786434094,-398.61933027521025,85.36880253148178 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark45(-392.368500974583,-379.973866758498,56.28070092446177 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark45(-392.5815800223613,-374.07420986101863,92.85104164721636 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark45(-392.68657264383313,-391.3746512072261,19.478678227311136 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark45(-392.6975454459005,-377.4823664074745,56.29505710978657 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark45(-392.7932199785178,-400.0275141854526,70.57373750694433 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark45(-392.79937779037,-372.2427402227591,2.487652373486071 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark45(-393.11074279900834,-377.07196513337,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark45(-393.26798089080336,-366.73762719861276,100.0 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark45(-393.52517254677264,-366.7512699780201,53.59740178676921 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark45(-393.5268631649018,-409.4225913944813,31.802353272924762 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark45(-393.5376695838625,-371.61127305329853,30.020860625978628 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark45(-393.640987787374,-418.9883080518162,46.43137979237076 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark45(-393.70786488953706,-353.67327504099205,100.0 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark45(-393.8792627150073,-374.33784174791566,58.85141459680125 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark45(-394.028097486912,-399.86155922105786,66.09520643893651 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark45(-394.10680177826407,-368.9344115580151,2.269887609664309 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark45(-394.1861450217933,-377.1968470117013,41.85538367321692 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark45(-394.22680845965226,-382.6587235625448,49.28350372210457 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark45(-394.26942582568086,-353.80287134521154,46.35672371305765 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark45(-394.27150129620594,-399.88927586337616,14.190205128189774 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark45(-394.35954467193386,-355.2730194743749,100.0 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark45(-394.4484756096155,-398.24950887113414,1.3470960070704763 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark45(-394.49760792802897,-353.60968019352265,86.00391246467035 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark45(-394.51680819165574,-417.2723835390612,86.47541580157122 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark45(-394.65531068628053,-414.96148815575697,21.481626584199162 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark45(-394.70235438952824,-424.5222748940896,100.0 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark45(-394.74159073718823,-424.2354111236489,16.2882102206883 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark45(-394.74253077603896,-363.8716755637529,90.33058512805312 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark45(-394.9918952424356,-376.32552819943817,42.268413779239324 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark45(-395.0360660743149,-413.70104126661033,60.995530342767125 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark45(-395.4457520669551,-359.78830144150004,76.7834637131096 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark45(-395.4609873270798,-353.9060498515184,50.40111036467687 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark45(-395.585440147825,-361.9777381586174,84.40062168825608 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark45(-395.83574665155106,-353.9820131651841,72.18317262284336 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark45(-395.9516094651746,-427.9092666429678,39.94902281623834 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark45(-395.97589697650466,-355.28177289798737,70.02053496041273 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark45(-395.99017106587337,-353.39615787393046,100.0 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark45(-396.27638320087726,-353.6229029572379,10.053187175718733 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark45(-396.7344409194395,-408.4483308286938,10.601070542813801 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark45(-396.9071959418273,-386.2499834021361,40.77003422852957 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark45(-396.90911661828665,-365.8903034440637,22.945288681897893 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark45(-397.2442426708984,-349.3061293364135,36.28957247817539 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark45(-397.609762080405,-378.9021385475402,76.71002507219501 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark45(-397.705894510673,-351.45084867323294,24.201017317560343 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark45(-397.80657642193637,-394.3336638303464,32.33223770046203 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark45(-398.16268701331103,-347.9181960036948,100.0 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark45(-398.17070734868787,-360.4503252639788,24.04292104846884 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark45(-398.2128515822518,-362.5445964670348,13.357353020633298 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark45(-398.2222612791057,-364.6108042489686,73.8200803234291 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark45(-398.43116308356787,-382.22218101263195,12.767694785646412 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark45(-398.45095021708374,-369.04400379552123,81.00844754627065 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark45(-398.48208002967056,-359.2395815327085,100.0 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark45(-398.51707253005014,-400.8610539675715,62.02806417839014 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark45(-398.52901996789916,-354.03115992461676,20.567488803427153 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark45(-398.6342718066272,-369.1333893490382,76.30849944502287 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark45(-398.6360235958166,-378.0524206209834,17.63471491116482 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark45(-398.9054115087954,-353.72571544893077,100.0 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark45(-399.05147281752363,-356.35549532587953,97.08800337249178 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark45(-399.06310239486606,-356.2202396208151,42.82814921306951 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark45(-399.09780218760505,-368.55113547736875,11.632778931950824 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark45(-399.43440356819366,-347.40652099980525,16.297799388480712 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark45(-399.5734102259305,-366.8207946918399,71.84540966991949 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark45(-399.9087374330904,-371.338301630601,62.24184429369777 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark45(-399.97853740858,-369.620232382118,21.73788207496041 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark45(-400.0141715062283,-431.5751774707745,51.32783675418301 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark45(-400.02978517515317,-368.7563616075783,100.0 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark45(-400.06728239958056,-361.8876310109498,31.368333635643552 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark45(-400.09481770619954,-372.89472240593363,13.390126237868088 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark45(-400.1058170935971,-427.55619494555623,55.234313187157795 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark45(-400.14656489620785,-357.2250938845066,9.929684456172794 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark45(-400.5514102996464,-373.6210429453512,93.33700641657794 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark45(-400.6057020631381,-370.37313752972466,100.0 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark45(-400.66687512640186,-356.24763685967724,88.53754124801546 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark45(-400.86743325978307,-368.9860263581758,94.79141980676872 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark45(-400.95210273835323,-359.6345875981542,10.341663192359192 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark45(-401.1526948284903,-380.0040095919906,3.879161038925446 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark45(-401.18026992567627,-385.9506038228566,4.189034453229439 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark45(-401.419561433308,-375.19663105730183,31.287540251670237 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark45(-401.63753237371697,-416.2733049874574,3.0036043871128726 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark45(-401.78944639683544,-469.4608651398911,25.064255277879383 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark45(-401.79304063643167,-355.9078051375442,8.028395701605717 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark45(-402.08724511692503,-374.01790969110397,70.96657653279414 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark45(-402.11207146171756,-416.1747015998674,33.616484380424424 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark45(-402.1398627629635,-351.8553689044558,88.0124620952615 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark45(-402.4503284390337,-379.78045445393826,57.900445443351344 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark45(-402.59860954543456,-359.67896377857033,1.7558347771963176 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark45(-402.8320471305266,-358.08291460965296,89.89534384452972 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark45(-402.95323017007735,-361.7920986106576,90.42138450596872 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark45(-403.13837194198084,-348.0012979174363,13.535398971937923 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark45(-403.1693251350716,-367.01651674779123,57.4287641122593 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark45(-403.21337948438685,-383.5106589912583,79.41985981698738 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark45(-403.24778242761323,-381.2330419975888,57.677852713550095 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark45(-403.2957184179129,-441.89022605762136,59.44081717087718 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark45(-403.30413720728546,-373.2260193724187,67.65567259623987 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark45(-403.37514776323,-352.5217234279326,100.0 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark45(-403.49028058181705,-356.98303839041625,98.35556228394 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark45(-403.5926826481588,-345.8347764473041,40.66454440881279 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark45(-404.15283704868466,-374.26131127835527,16.12693330723465 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark45(-404.4473895210094,-374.06531631375606,25.326084734346964 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark45(-404.5070536212159,-374.09807015387787,72.3768199785084 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark45(-404.52992181523615,-409.01436941367604,60.36955881794833 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark45(-404.5924279437768,-349.4783994489986,11.3100169509041 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark45(-404.70902939589456,-349.8005058381536,10.813114406358551 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark45(-404.7469786767486,-375.3891251183837,42.34218575443805 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark45(-405.09881621268465,-356.8680737548719,79.06812667617248 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark45(-405.381420466186,-363.55665799255337,100.0 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark45(-405.45546661277865,-345.8828250697389,16.739474470294454 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark45(-405.7056312676356,-357.3581177673991,19.52010865424181 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark45(-406.0605234780097,-363.18061845197263,74.28124325104253 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark45(-406.1619792612084,-357.92467162274266,95.41558098618813 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark45(-406.21918159490326,-379.482252919551,4.09230755169936 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark45(-406.31840921566635,-415.8158422308589,4.124867893007362 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark45(-406.3266441565976,-423.70318391066445,28.25084056501987 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark45(-406.37500689028855,-368.5052796637422,21.361573120912468 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark45(-406.4645961909317,-363.10583633165953,100.0 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark45(-406.5623289899235,-341.5261728505252,78.69232002699974 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark45(-406.5984548035122,-389.07757344324494,50.209589525250976 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark45(-407.26210756468583,-366.69389046843617,21.02052342181298 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark45(-407.38421066092826,-346.90569114025186,100.0 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark45(-407.5367561662691,-356.54476723088214,100.0 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark45(-407.6028315136957,-363.9704818644311,7.105427357601002E-15 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark45(-407.74453820002674,-364.16919296197716,49.57396216480842 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark45(-407.8676365976532,-349.602434607852,83.17205083065659 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark45(-407.9601271682068,-365.0890113460424,15.556984271337157 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark45(-408.1342726880167,-342.04629172083963,97.85456498227475 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark45(-408.37928747531726,-339.78537386493554,94.53398367423935 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark45(-408.637151236404,-364.8150801228401,32.621371744361966 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark45(-408.71373410409774,-351.64159947951765,3.552713678800501E-15 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark45(-409.2328909741285,-366.6334052790993,38.83251931233541 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark45(-409.31614841806646,-345.3425783560698,46.83093287519543 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark45(-409.38336712630297,-402.94745523313327,80.57332048068554 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark45(-409.4736218600503,-362.9018598173267,11.40416706532757 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark45(-409.5710212160856,-345.19363940175856,18.914393049940074 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark45(-409.6442601891309,-422.6457645952742,35.36395025514909 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark45(-409.70287631886185,-360.72096729537697,67.3420405763305 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark45(-409.85189378380466,-345.0576659772549,44.78028023391258 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark45(-410.03169538251876,-386.37049884432804,100.0 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark45(-410.3033799717158,-359.51994762249456,62.84873155674629 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark45(-410.3285799856584,-339.447899908829,40.58555640366882 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark45(-410.3524080578056,-342.13804790063784,70.9432635296653 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark45(-410.38001762724576,-336.7481293767563,36.641518115862084 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark45(-410.39573762148996,-443.1110746592372,71.50871827091748 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark45(-410.4777683711564,-335.97893465821636,39.66316998364681 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark45(-410.6574409680777,-400.40276224660636,19.812779969014883 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark45(-410.86674881222564,-381.6323425802892,11.24588257486647 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark45(-410.8752801207342,-346.0641461794152,100.0 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark45(-410.8892162518192,-425.589643245653,65.8935002518993 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark45(-410.94054026468865,-357.0548148168957,100.0 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark45(-411.029936174913,-374.7046458503097,29.61075464851291 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark45(-411.1874320520248,-341.89527612778215,7.992907618093298 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark45(-411.37817614871835,-347.09707393664604,100.0 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark45(-411.5400602101804,-340.640962874408,9.297550328188237 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark45(-411.8289201537779,-346.61915988037924,37.97293935596517 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark45(-411.9478287569266,-335.4221784234529,2.655615242326874 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark45(-412.05830607780206,-372.6313205050327,100.0 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark45(-412.1669114635226,-343.44181595617647,52.71302387254542 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark45(-412.1711375659931,-337.92910582824163,100.0 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark45(-412.24673784261523,-392.32811219613205,50.882641677238496 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark45(-412.373731492184,-347.8286863555747,58.89674543466049 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark45(-412.5769314338674,-351.22020352540517,71.38610317692041 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark45(-412.7356857615772,-376.12443163405527,30.737949212824873 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark45(-412.7497820882815,-342.2669192422723,7.065327769907782 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark45(-412.9603633367145,-349.23035761830175,3.7730731585772617 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark45(-413.2596023970866,-386.40992633395956,46.02977671424867 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark45(-413.3061464802468,-375.1898782039891,100.0 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark45(-413.31155342745046,-382.87766304258594,100.0 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark45(-413.560556916944,-392.0064394188724,36.629372338714376 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark45(-413.70269018943674,-337.38274994989047,54.35756821878431 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark45(-413.8002524254892,-347.42068516636,20.49670183944849 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark45(-413.85893324448494,-335.3277664598675,51.277030852509796 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark45(-414.03662921371375,-368.50535942714635,100.0 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark45(-414.0988235507742,-337.65105930053,12.716268602836081 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark45(-414.09942572595236,-386.0784720681659,89.9318782402284 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark45(-414.2796545927967,-331.8884962845981,8.016372051277969 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark45(-414.5741378487402,-345.7834636357846,2.220446049250313E-16 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark45(-414.6937133618009,-383.656158757564,12.671449987112894 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark45(-414.7828431304222,-331.50365191395736,15.559588173616604 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark45(-414.8576604091209,-349.7350951917177,85.93848759154642 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark45(-415.0428743811335,-331.26424697736906,100.0 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark45(-415.0720904109084,-341.87630819308794,28.576453518663016 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark45(-415.1409998922232,-358.6892219439087,1.8900719635767773 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark45(-415.2558322946253,-377.05073655723953,17.32144418012875 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark45(-415.29138380477343,-352.17366606250243,1.387851684197571 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark45(-415.3186712305179,-354.4336540355635,0.6451950279968628 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark45(-415.5299103053269,-345.36023126212626,23.084987391361665 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark45(-415.6043324016301,-330.8379296452795,82.99797011166305 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark45(-415.6249399375742,-335.6379887070725,82.75328475537341 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark45(-415.6256802522449,-330.95390586309793,7.339183776196762 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark45(-416.1155334056241,-387.7967251737911,100.0 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark45(-416.4264355980751,-359.0135059185476,90.56311454201685 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark45(-416.50828503098376,-402.8658113963397,28.420154307464202 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark45(-416.5096327391412,-338.740553576387,73.83430266353997 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark45(-416.56132628558487,-335.29252511282175,7.061454784307571 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark45(-416.6275203029209,-332.54514368623126,57.727986641279614 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark45(-416.6564844509321,-359.60116890344824,100.0 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark45(-416.6898048996593,-333.2681847249039,10.755066159205981 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark45(-416.7302776949094,-359.3393835043504,61.89851168568339 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark45(-416.7376128467576,-357.9830633033914,56.78932758957126 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark45(-417.0091141107376,-334.02088542664956,20.47962819493945 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark45(-417.1049676619278,-331.2405304438572,68.73285624540469 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark45(-417.18446330997455,-335.74216640876165,1.270722514631629 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark45(-417.4464565446771,-355.24782734442243,63.050116863567894 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark45(-417.6468476600044,-360.1129499996196,87.6264708933023 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark45(-418.11125413362555,-395.69533833048087,60.86920228887075 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark45(-418.13170343549973,-332.8502178502689,92.20592600765099 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark45(-418.14877987402303,-345.8338409410858,64.35827500689533 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark45(-418.3171136860678,-369.69459350887513,40.43680202178954 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark45(-418.3724453471032,-368.6016477580097,2.201440158344269 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark45(-418.4075716802086,-329.15076935923696,-78.00639533266983 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark45(-418.5679508482724,-327.7490751803256,6.0983529964051115 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark45(-418.84059634722945,-372.73549587798203,27.554811138381467 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark45(-418.9006566419779,-331.38360812898975,25.763723858917018 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark45(-419.0689709745481,-334.2543497660263,18.04231253738979 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark45(-419.23352018169885,-333.64674642105655,48.619988644173304 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark45(-419.3072415812488,-343.6784338391949,18.11458776321512 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark45(-419.72050698268947,-340.5620093398389,10.858530999809872 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark45(-419.7217392286249,-326.6926986810064,71.64932918282 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark45(-419.7615064584852,-333.3278517289248,97.17384288545796 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark45(-419.7886501161896,-342.66201994008844,20.91663014749163 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark45(-419.7918250555075,-417.23344642020203,10.724019544234437 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark45(-419.7953406238576,-346.2671165301248,82.49023734146127 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark45(-420.10493850887894,-361.79562969962217,63.886144603004226 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark45(-420.27585950749005,-359.81152679673517,75.04010075526344 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark45(-420.3295197514105,-343.0045817732529,61.84071417950307 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark45(-420.51036284172113,-340.3646858780664,28.4675637397319 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark45(-421.26379965634186,-332.5586188713708,84.9008681271321 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark45(-421.33150645308194,-356.6093612703393,27.977201908653356 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark45(-421.3734974318802,-334.985017929324,39.86037228485338 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark45(-421.4480089167587,-328.5578774271402,34.93857314066423 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark45(-421.59656025938153,-364.44096273538577,42.61295037434439 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark45(-421.7591760975624,-333.72605357493495,65.91096180138032 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark45(-421.8037756238391,-334.9207294352475,43.421130335748956 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark45(-421.8795768865782,-349.95422503959117,71.85845371327909 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark45(-421.9506586856882,-338.949866165499,73.58680593827333 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark45(-422.088080326317,-326.441019600092,44.54591479103891 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark45(-422.17519633613057,-334.9633967314472,74.43463063207204 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark45(-422.1827958252919,-335.9992960283628,100.0 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark45(-422.4339178091764,-387.05466826090236,100.0 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark45(-422.5048257375359,-356.868337618421,53.9120550217003 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark45(-422.5065880831391,-379.51676865164006,58.2489711818541 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark45(-422.5728405325287,-333.30759391701,76.85122365235773 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark45(-422.6155772381408,-354.0782456100846,76.83981343503456 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark45(-422.68446136355146,-403.7804358223028,100.0 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark45(-422.92091068079066,-366.0842984714285,100.0 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark45(-423.3626302163197,-327.792288052654,57.27560400604017 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark45(-423.5214712577481,-324.5537967777421,44.051129465590236 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark45(-423.66412210802844,-341.52134860287055,79.41390995881858 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark45(-423.6897346063697,-323.54777291361813,74.01720702519785 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark45(-423.7759853315237,-371.2624913638802,68.70672955560656 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark45(-423.82135878803496,-332.1572878594533,6.830418734878135 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark45(-423.9384181360834,-362.83091105326315,59.20441278540642 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark45(-423.980957611776,-395.43374612809873,34.05208191743654 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark45(-424.0606887164262,-323.4906353202101,20.893366463681936 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark45(-424.09295096110895,-392.6714634728395,15.539781977709083 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark45(-424.4708114950334,-334.69257239730314,64.81128159332434 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark45(-424.78711438253873,-334.631088259012,74.96087965871575 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark45(-424.94034701073986,-349.98613899866535,65.11656195158278 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark45(-424.9695663394974,-334.7773159388175,44.458926329290705 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark45(-425.0774130702612,-338.25621830749236,68.49963467956528 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark45(-425.0827294882071,-356.9681542386277,69.16363795952785 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark45(-425.09376839802155,-357.26828570673734,18.55815955992732 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark45(-425.12920407554856,-326.36688921304085,46.90806175713874 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark45(-425.1635761513597,-367.6657037382545,15.994620329717009 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark45(-425.2184444883514,-378.7024862637393,30.04390585793064 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark45(-425.5382206153325,-333.7944068737046,78.96105863667796 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark45(-425.55428354498594,-340.1886180801836,88.15247406102128 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark45(-425.5933003186186,-361.8514755522805,43.66913684847654 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark45(-425.6265419651316,-334.3459658812975,30.037834793648926 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark45(-425.63053231668187,-328.3837855681721,80.56723803783441 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark45(-425.7787907128587,-354.2275337881375,15.266630709152423 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark45(-425.87194625753204,-329.20849342234663,15.124426340952922 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark45(-426.0941683768271,-343.2798239938798,76.17773480273533 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark45(-426.1772785420302,-363.64996825641606,50.52613132466294 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark45(-426.185320398122,-365.9044579987133,100.0 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark45(-426.1954461044508,-336.53204746057725,77.61157430610234 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark45(-426.1962741235373,-377.12456765379073,29.562581136495965 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark45(-426.3961716285445,-331.8721062493602,89.41432385195691 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark45(-426.5184633392455,-378.3397776213782,61.336691102353456 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark45(-426.5864033518814,-374.2605760857781,65.49182294686901 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark45(-426.8865818279162,-389.6449509792023,32.62845492010928 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark45(-426.9439598883728,-348.8506604442284,58.0345985217059 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark45(-426.9501262825799,-383.8725808246986,23.63081057032879 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark45(-427.0714409012468,-355.9759043229461,37.42813894370934 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark45(-427.076396011581,-335.4582278268798,59.55863925004138 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark45(-427.1549838729938,-354.96607332803165,67.65997912000077 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark45(-427.23441999048407,-344.07494666825727,100.0 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark45(-427.2520575132796,-318.8594409777133,66.63619507500343 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark45(-427.5886889205472,-325.526855128588,33.44964360120096 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark45(-427.73809582495267,-327.101585272247,49.965120678346636 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark45(-427.9704718283529,-365.2204543305758,8.946216540177108 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark45(-428.01325598318573,-334.6934594037074,1.4354203229574587 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark45(-428.062061777285,-340.36710800311806,75.52658160200662 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark45(-428.2296516938764,-323.8751284057107,82.87040054515069 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark45(-428.26238648117805,-409.252331948815,9.681564673290865 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark45(-428.3620026286238,-414.2656854989053,100.0 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark45(-428.4988342007329,-322.40646769916145,75.34696681815225 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark45(-428.512229798891,-353.1199938748508,100.0 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark45(-428.5817027079715,-336.7727594426113,96.00023917802858 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark45(-428.6021532691427,-335.0148771871137,72.86167508413419 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark45(-428.60781628200857,-336.6646099336094,24.86671752951885 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark45(-428.79141641519175,-366.70609514795586,52.89760872647295 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark45(-428.9808428322087,-325.9733338228855,66.83397963084914 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark45(-429.02890758499547,-411.0121471697875,59.44386005910903 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark45(-429.32147075587164,-373.8125248029173,50.038874732043126 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark45(-429.34828137442906,-353.16444775877005,29.03236958433098 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark45(-429.46943206872044,-322.00464959348415,21.4437836552452 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark45(-429.6109936709192,-334.03291885869663,39.39641433071304 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark45(-429.7573126804675,-319.2448448928262,28.50428964722751 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark45(-429.7783932588536,-356.0297089070401,78.00182006665983 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark45(-429.79904431132957,-329.1348283463605,91.2973617150702 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark45(-429.84653444800085,-322.2765439735111,95.46124431791475 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark45(-430.0584876307843,-328.9342722919846,42.37767644372721 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark45(-430.3856408413977,-349.5066426470856,25.026260672664932 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark45(-430.6390843530953,-390.96005777220154,60.680361174397206 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark45(-430.65033590132043,-346.7854690642526,15.015167324028084 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark45(-430.6999837470994,-322.7196348865217,55.723928660716325 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark45(-430.71433335775447,-496.45963555099263,60.923457008426965 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark45(-430.7868724802325,-401.887582163296,42.91470324671272 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark45(-430.84761950963343,-333.6632459021887,35.16713285225173 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark45(-430.89882914709915,-326.3276641236674,100.0 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark45(-431.11606004122973,-360.9390915904193,79.49526524518805 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark45(-431.18467196983397,-350.31010097651426,64.57576702067638 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark45(-431.2639632822172,-372.8556265760248,70.53799279861596 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark45(-431.41525808499534,-344.0962134164359,87.94488015861901 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark45(-431.53717571652436,-321.64813628295076,100.0 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark45(-431.7548382598162,-334.3526007710972,85.70520389379948 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark45(-431.7883280776877,-321.4975329229124,59.4751851505367 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark45(-431.84514722189374,-327.5098929466177,100.0 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark45(-431.9430256193908,-336.92842557925246,87.37484535208057 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark45(-432.0129015490757,-332.65361453526384,100.0 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark45(-432.10509541946885,-389.39284311452417,85.36277841015198 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark45(-432.2513637533187,-319.2464373065695,100.0 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark45(-432.4741111529533,-350.7527547727497,34.18001272577416 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark45(-432.5136238688727,-324.5703629543882,82.36338949834214 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark45(-432.6703600656019,-322.69937915931996,38.575239826409614 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark45(-432.80695064708743,-326.96818995174226,57.760863957320396 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark45(-432.89701465382717,-323.5584638146645,22.754603280825464 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark45(-433.03601259622485,-346.60335196433044,100.0 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark45(-433.0522106838816,-338.735173337443,55.00784616866133 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark45(-433.0953700864625,-337.9909099806767,1.1139763952183017 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark45(-433.109291462257,-329.93282419775176,44.92310055658194 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark45(-433.1345821428019,-342.4486234778113,60.41143910784638 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark45(-433.5164322954241,-348.25643342154575,83.43221517308896 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark45(-433.56405555771767,-343.94381243100827,12.669011184243132 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark45(-433.6119361431374,-352.67272834636856,100.0 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark45(-433.96511330190185,-349.638135827259,88.35986549869455 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark45(-434.07406346020184,-335.5056207930127,83.57301896324748 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark45(-434.16911589837827,-351.3149516102004,68.68943413536277 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark45(-434.17646341085344,-313.39443208634555,85.97641007180928 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark45(-434.28535135975545,-321.33572089801925,71.45095826509825 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark45(-434.5166412968494,-341.192311847681,24.37349620547377 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark45(-434.8169085870329,-323.000770960539,3.6129199574905186 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark45(-434.9138989425785,-358.04133040846034,20.59495741456206 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark45(-435.11418931828143,-340.0502838494243,68.3084126951234 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark45(-435.1616789210926,-323.96568548583394,14.372170862584127 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark45(-435.2529608160695,-360.62571216938585,4.239924745625288 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark45(-435.39575772868614,-318.51405425870513,83.30939497310646 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark45(-435.5204710372969,-315.00372962315026,95.54395897499512 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark45(-435.67181497727694,-317.62911236916176,36.37306304969388 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark45(-435.73721888474194,-325.2910804780589,5.1373348008340685 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark45(-435.831292792437,-347.3381157577636,7.69440753708804 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark45(-435.89574040771623,-313.47226754117605,100.0 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark45(-436.24609769259996,-325.3041784391889,100.0 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark45(-436.3856086509154,-314.3377293122301,6.9899435328819095 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark45(-436.5735190493116,-322.4417477962151,80.08531873849375 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark45(-436.587141864362,-348.6620829053248,-100.0 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark45(-436.7551780403977,-310.6301631223685,89.13595465135538 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark45(-436.9326877396811,-339.28363694750874,35.99700305104428 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark45(-436.9619329248275,-369.85132456880734,100.0 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark45(-436.9768198998434,-322.73153320769126,100.0 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark45(-436.9840704374128,-312.6332687414385,87.82562005150157 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark45(-437.0128447681699,-421.1274894925995,5.494547292779188 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark45(-437.08453653931133,-359.16278672683507,1.1332526251155173 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark45(-437.1873845082887,-317.7243974266364,9.210599136847947 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark45(-437.2073465515937,-311.1685471663323,82.77676415510007 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark45(-437.4400594391733,-371.38118223889984,94.38531545430689 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark45(-437.7172416216425,-380.6744892412478,100.0 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark45(-437.7421620209317,-309.51093357076905,100.0 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark45(-437.9496206549718,-372.51421160531146,60.09473689395054 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark45(-437.9517083812652,-320.1231606747858,44.6373973220083 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark45(-438.05789371209727,-314.14422163885007,100.0 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark45(-438.069138161875,-328.5589538835566,50.9884211097401 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark45(-438.1045922196357,-315.95831975043325,58.67096162612259 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark45(-438.1537924459449,-342.01205267878356,11.691623747290961 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark45(-438.25779113848387,-308.40169582597673,96.41696146760506 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark45(-438.397178944959,-359.1908719351424,100.0 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark45(-438.7069482249125,-322.96227620068424,70.21106908783739 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark45(-438.7318413138895,-310.1431056157144,100.0 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark45(-438.80527807406156,-346.1138382896096,100.0 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark45(-438.9058028637635,-312.2479412272104,60.08789388208277 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark45(-439.0250328967957,-329.9530721443855,86.39178187520395 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark45(-439.2334926497039,-349.8161803595359,84.95523817445968 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark45(-439.3354989702701,-325.0713743828998,100.0 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark45(-439.35396892416304,-321.39378153423917,75.59196099944904 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark45(-439.35570320115903,-317.19480537390973,100.0 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark45(-439.3638074531353,-308.4123080363138,6.68849030269287 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark45(-439.3780532677039,-340.01695729525557,39.570168567824965 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark45(-439.4042076090338,-318.28913475263676,72.1130779013775 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark45(-439.4832627784356,-337.70010008572103,36.17096454620028 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark45(-439.5600257059417,-371.7604704685287,74.98582490337776 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark45(-439.59743337141174,-312.78317642970154,26.030797952174538 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark45(-439.62401098230225,-324.8466461373291,27.5163731792816 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark45(-439.6747702243395,-317.5989815310546,68.35328017510764 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark45(-439.69551759911866,-317.449238452924,92.36909581951659 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark45(-439.90035559248236,-331.6542405713732,57.82904089150321 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark45(-439.9695401056338,-332.29529001742185,35.54027699037829 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark45(-440.46127813806146,-398.74497485272343,25.75249246927855 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark45(-440.7647489894099,-342.1340060921834,96.23050980993227 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark45(-440.94354380403195,-349.1336600996961,77.16958758636923 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark45(-441.10037629059406,-310.331534722609,56.03505381993574 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark45(-441.13557935103165,-337.67185443898757,56.25388068875449 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark45(-441.30264219612184,-319.7729186226728,52.83683404007576 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark45(-441.36609340661994,-332.7044992154098,36.37393601943609 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark45(-441.4804259169,-333.49507550847414,100.0 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark45(-441.83344884123653,-338.6251403835688,100.0 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark45(-441.92855721357995,-419.78025389459685,100.0 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark45(-442.0451039506047,-332.6109169623937,100.0 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark45(-442.11753364877933,-312.4389751166905,79.94824453318253 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark45(-442.1403538374391,-361.77635590243295,83.89655280850184 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark45(-442.44025073429356,-312.5693373428622,7.203353613952302 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark45(-442.5834879332936,-352.2331529836969,32.380699849441555 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark45(-442.61488463552797,-349.95727875483607,46.99676594134368 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark45(-442.6989108576514,-311.44443256087413,4.3888375837018145 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark45(-442.7435033237948,-309.02820205886934,62.35831072673298 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark45(-442.79774898408425,-350.0413256031195,68.5430051949422 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark45(-443.0918476210412,-309.41223145737445,23.074992923234603 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark45(-443.1090903083466,-356.1425087095855,100.0 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark45(-443.13855109194645,-327.0426423349715,48.09658139333129 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark45(-443.68793214390695,-318.786732073248,42.111533668069626 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark45(-443.71021911456785,-305.8391260025669,1.4527329493974293 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark45(-443.8498552331112,-343.53033641714046,85.77259966520842 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark45(-443.8854561023257,-322.9571780181454,48.96921518480971 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark45(-443.90519021796626,-303.90485134721376,99.43611421546589 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark45(-443.91016570506355,-309.2596245261908,47.747178142508375 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark45(-444.038719465646,-340.36271887500624,100.0 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark45(-444.18948067742775,-313.32797745473187,37.24865311967892 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark45(-444.29425251180317,-327.93439043464997,59.49305290086892 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark45(-444.36588097604135,-348.73333949190794,29.759574022942644 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark45(-444.37859244493876,-355.1795262240289,2.807668888898675 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark45(-444.58748007318883,-310.0232407061742,91.32999172617122 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark45(-444.793496847635,-313.2392845610343,72.17920094024342 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark45(-444.9350819549519,-405.563401342456,100.0 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark45(-445.15164012974134,-306.5529701479749,59.20878628986128 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark45(-445.1562475562075,-301.70435832093256,61.84838781463961 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark45(-445.16889054367647,-333.9612099951093,64.57945226412932 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark45(-445.17206180145064,-313.65687830461405,96.23137007811698 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark45(-445.20085952420425,-325.31297951286894,68.77401786611219 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark45(-445.4182218363757,-306.0330895035261,48.02031415828753 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark45(-445.4672243582948,-350.73749104801067,42.15001473199911 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark45(-445.47029797053807,-314.1207164337587,88.26190238590891 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark45(-445.5759816271348,-312.4977297833463,34.00068682999421 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark45(-445.64880225434064,-301.7198570135609,66.80000748137869 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark45(-445.66381536550557,-357.47634961494265,100.0 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark45(-445.7319077089983,-386.09157204464685,21.72685236956397 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark45(-445.7800239085563,-349.5322061501802,72.1951410310131 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark45(-445.8641203981836,-340.2114006349036,25.268886018898655 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark45(-445.9739168099957,-311.26792608234155,49.27472079939989 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark45(-446.24057459502546,-332.8017127871793,55.348537094366236 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark45(-446.3385122592888,-339.75440844312,51.584062316647106 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark45(-446.3539172783398,-354.18520736199105,4.6182060464947625 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark45(-446.35868068554055,-342.399602177088,33.86696632061853 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark45(-446.5247367660946,-303.20801181541384,6.403564862138822 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark45(-446.7363980134159,-303.1009970693327,14.106618498811613 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark45(-446.8103172310915,-306.75304175771174,40.83063842172041 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark45(-446.89359871556593,-355.810756757905,14.184705807888577 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark45(-446.9877111850211,-328.5645028033581,35.407725481323524 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark45(-447.0522671425954,-306.97896356882103,6.516968830388549 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark45(-447.1360283923731,-386.69343757212766,25.4203284469352 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark45(-447.43276580561735,-371.60622415368357,78.3921915016065 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark45(-447.55290432776076,-300.55667381346643,18.140148717712208 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark45(-448.1241367948052,-299.2947350808977,82.56436020760304 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark45(-448.1461092082051,-318.8630197522195,68.38021899499185 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark45(-448.1538796637776,-344.8898316374755,85.21166888046892 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark45(-448.2286528685734,-301.45287652994443,40.92979292055867 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark45(-448.2498623936608,-304.88191445160004,66.57013199401308 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark45(-448.28113358871803,-301.1293796601355,62.35072284612971 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark45(-448.3027148323202,-353.13364574482955,47.58938245508011 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark45(-448.4224829592552,-334.8566559916042,80.72741786599201 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark45(-448.4435735853482,-339.7799632391108,100.0 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark45(-448.5126773590159,-314.2663517028533,100.0 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark45(-448.98612557073534,-307.63076559561534,40.51544011333894 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark45(-449.05931852115685,-299.8968409130876,98.25640416685795 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark45(-449.08588795315893,-316.13874216156967,84.54770441378722 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark45(-449.1045491954577,-365.5270390035394,2.953770926433748 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark45(-449.1885941105554,-302.67591728292496,48.550120120996006 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark45(-449.21162123170086,-346.5812769206079,6.1408716136379695 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark45(-449.2368351759482,-301.25653935574945,67.44071906078258 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark45(-449.2545879394254,-373.3402925788445,74.84345390588427 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark45(-449.3058860087476,-342.05074695442846,18.002180346036155 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark45(-449.31093686218367,-305.6114413623757,80.43730848085079 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark45(-449.42446746170083,-300.56755488042717,88.45103249565642 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark45(-449.5547729496194,-324.1076561868226,100.0 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark45(-449.6303307756666,-299.4128649953037,97.89822999350824 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark45(-449.6683871891149,-409.15780403471507,100.0 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark45(-449.77106862194,-340.3084544214123,68.67436009067899 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark45(-449.8184531217683,-302.2946740414392,70.66022456460152 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark45(-449.9632858470331,-334.041617539172,44.40862239639845 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark45(-449.98922572853627,-307.42399914649764,4.127883469906578 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark45(-449.9987389590206,-300.4400201210933,52.748704862756945 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark45(-450.2367863274068,-322.3181945751003,38.878735361219384 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark45(-450.35902187327684,-305.46969217820435,56.96940475046145 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark45(-450.53748794803425,-305.61228459722975,67.9717571186149 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark45(-450.7493315995062,-308.5950159421424,70.60431279728348 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark45(-450.80154936109585,-306.11820927553373,91.78181842814962 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark45(-450.8992444930208,-303.80020115941596,28.556735770072265 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark45(-450.9619488351554,-345.87789713626273,77.95725728431987 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark45(-451.08618200273304,-306.87246376837743,50.67334675024168 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark45(-451.21750163829915,-352.3678709856619,100.0 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark45(-451.35055987181715,-312.9273133270136,42.54929779369437 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark45(-451.4052351974624,-302.64944582972913,4.871387689632584 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark45(-451.52403699671964,-320.2042782490969,100.0 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark45(-451.56815036776067,-376.06187482859036,60.57313883250674 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark45(-451.64164257566193,-317.00715238429257,47.99697039705376 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark45(-451.6690231198447,-307.0246121823299,100.0 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark45(-451.99370287016404,-334.2301037094513,41.57778970880216 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark45(-452.0012292243659,-339.5464333309889,94.86285260105706 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark45(-452.04297398281176,-317.81241565484765,62.34851819945493 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark45(-452.0827291184287,-327.25584121451743,91.97281512215129 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark45(-452.17679872725756,-323.30325335789774,40.837773626911115 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark45(-452.58225443473236,-310.2272013743771,80.88918109379392 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark45(-452.71190765326537,-324.9610995767274,28.75999604425482 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark45(-452.90661127594444,-309.1344506211609,79.98105775915852 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark45(-452.9290102403502,-345.9459723298377,50.60170645598217 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark45(-452.98751538510663,-377.41194657566075,15.374060073989355 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark45(-453.1301943607012,-314.5493478029353,43.925419933083504 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark45(-453.2140593258669,-300.08142983722814,100.0 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark45(-453.2804927527067,-316.7222808619818,29.656564022046922 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark45(-453.3054702793267,-305.2094217172748,29.418266084900182 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark45(-453.3329828348289,-306.2751676842392,96.73451269812671 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark45(-453.34308753957566,-331.2217084244259,61.127373177196375 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark45(-453.40209156811807,-351.42902985,100.0 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark45(-453.4048917575959,-313.63953047751426,100.0 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark45(-453.4387073271208,-337.5952367249686,11.12497627639182 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark45(-453.53932997478466,-351.14527733919266,100.0 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark45(-453.55712382401146,-336.40038854735366,78.679059211415 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark45(-453.6443012045143,-295.8881943276592,10.812388662022158 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark45(-453.85726146593515,-375.70069525329717,36.09113324545726 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark45(-453.9577041426104,-327.4016382566377,53.98320906684151 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark45(-454.0077581588877,-372.23581102478744,70.19053453813916 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark45(-454.0361996328388,-307.33326199302,5.589591533231996 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark45(-454.0853655268984,-355.5719169968467,39.3671348229679 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark45(-454.20032249025513,-341.50556720069085,7.497173789377751 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark45(-454.2520665891727,-306.2201149772499,80.97946341022458 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark45(-454.26584247109895,-300.09199859445033,92.03755702348917 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark45(-454.4485892990698,-357.54726150405634,89.78450799460578 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark45(-454.5381172764965,-315.8728069235098,59.74723165679549 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark45(-454.608525473901,-356.33165601743,99.5807978518026 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark45(-454.9870602172083,-291.16585906527285,78.16143200069882 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark45(-454.99019019579106,-299.69430096115457,90.92190367952085 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark45(-455.2215576392427,-356.5832853461227,34.22404409614026 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark45(-455.27797647342953,-305.1867705827058,33.21813776733754 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark45(-455.42881763566857,-338.62333077250537,0.9161499414995546 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark45(-455.429333392378,-354.19565248540516,36.843790097484714 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark45(-455.51718273490224,-306.6293870191411,30.007261679385067 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark45(-455.7917305764724,-334.79704348247145,38.29789815813916 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark45(-455.83517232854274,-298.3395499219492,100.0 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark45(-455.90154466569663,-332.31427181760967,100.0 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark45(-456.1053440485569,-331.5521734224846,28.79725186526693 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark45(-456.2423701320609,-308.8064024734192,100.0 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark45(-456.378895391914,-292.6764487464808,34.588061301778595 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark45(-456.4466414879929,-337.7550924085401,100.0 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark45(-456.4951527177169,-291.9407226259481,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark45(-456.6426697486204,-296.81931027384996,17.912315849353888 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark45(-456.6602138853679,-331.4309519911974,100.0 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark45(-456.77208280726074,-320.4942307697627,34.869418483611554 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark45(-457.1071031672859,-351.6896538938622,25.20020474287182 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark45(-457.1097424552144,-318.3865626784325,48.625024818095845 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark45(-457.38073765094066,-297.69360652108134,5.137051979372998 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark45(-457.4977311376268,-341.38379541104405,92.02628797554652 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark45(-457.5258883540331,-343.0168912892098,23.818934465525004 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark45(-457.712296682226,-363.06442347195036,11.033223777851589 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark45(-457.8778608901788,-294.30350632388615,53.8779044100734 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark45(-458.0645933184526,-303.3534189628769,82.99640819554975 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark45(-458.0811429625048,-327.3505858288818,97.90898341738233 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark45(-458.2414209727042,-364.44051463658593,31.250366374554932 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark45(-458.2922547492587,-343.51783207604706,46.69717006986275 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark45(-458.4736459705243,-339.4544647978903,77.94844602662954 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark45(-458.891902779895,-319.3624355251439,76.61172015104586 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark45(-458.9000062431791,-317.94930883166586,23.525481941424943 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark45(-458.9023329456581,-303.06405893779345,90.59972113734673 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark45(-458.97242688696065,-371.2696282366756,33.478458644920664 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark45(-458.9969444743655,-308.9502786156412,29.473946842583985 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark45(-459.0883791510317,-304.0018909852569,100.0 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark45(-459.2186616228116,-324.1820106364416,82.5754971205092 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark45(-459.5334527087468,-338.22368557089146,14.521364704484725 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark45(-459.68414770143374,-371.81047369092846,37.57050096513035 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark45(-460.0899747436926,-289.8962592314351,6.912695733127567 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark45(-460.1627475976215,-292.40605439955715,100.0 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark45(-460.1743960869629,-305.0217538946736,44.673409319616596 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark45(-460.22743833478825,-355.4667980983247,13.01493663716738 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark45(-460.25804416241095,-287.02305780357017,26.99854078420327 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark45(-460.4714123191525,-319.3268247606313,68.6418402151086 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark45(-460.47631111139594,-308.3720431356842,89.55807388382456 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark45(-460.6404114423767,-306.90542308555035,91.8236042174787 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark45(-460.7151441297266,-307.42027527335364,28.175460183335446 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark45(-461.07065875501934,-305.6293989202054,65.47128261931857 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark45(-461.80989674884404,-292.54000078093816,64.70743272033909 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark45(-461.8145257615886,-286.1437413111977,12.007650333957002 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark45(-461.86595180463553,-422.23063065557693,37.11056056877297 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark45(-461.9168674016682,-348.193767654941,11.913669997930612 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark45(-462.3504586701731,-298.4362150869035,11.645663560686074 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark45(-462.37204187312244,-284.8647135997631,74.35272606800027 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark45(-462.40692796191803,-312.9844088651896,100.0 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark45(-462.71567786136757,-294.81295960342567,88.05781814197687 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark45(-462.85737493434885,-294.6626887429378,100.0 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark45(-462.9211031434991,-309.3563337664845,30.96433861229289 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark45(-462.96760166509546,-311.00975899431904,60.44797711719187 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark45(-463.2082619641811,-293.9375498678383,78.24540378010451 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark45(-463.72195464145904,-289.93719492222175,78.62391266709108 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark45(-463.7359308568582,-401.1288765114883,91.56312175547038 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark45(-463.7903348976181,-321.9629574252643,90.37599722115769 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark45(-463.86474715174865,-305.8976298027539,43.66865894511841 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark45(-463.87190174411387,-348.3809281340077,75.51899394785383 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark45(-463.9800208360195,-293.07382438710533,62.919904844111386 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark45(-464.0098273709624,-285.7232587197629,59.81681707081975 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark45(-464.13956052838586,-288.3608698458554,100.0 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark45(-464.18675524655265,-344.7652816886144,72.34136603896812 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark45(-464.47923814767336,-296.01130997601837,100.0 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark45(-464.49878739130804,-281.5960218498199,40.67132356596309 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark45(-464.63941715712315,-282.0428421934255,59.25650366170416 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark45(-464.8667468630642,-299.9963203896742,80.07947731832738 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark45(-465.1423291212842,-298.84523832565407,27.29945397475022 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark45(-465.25721782544133,-311.6252823307139,87.21831540936716 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark45(-465.35666536815995,-283.6778579216778,76.1045055199086 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark45(-465.68018996074915,-294.26808299344924,3.7564902282020824 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark45(-465.7427654783506,-285.1757165913603,10.423874930732666 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark45(-465.8198546486646,-298.95925579002665,67.66178356972839 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark45(-465.84633572389805,-294.51544524830683,91.58976464654282 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark45(-466.0214633769476,-285.0389017115855,7.105427357601002E-15 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark45(-466.0846696335345,-293.2621759825006,6.065987300036042 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark45(-466.34239441013443,-281.66803426541094,100.0 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark45(-466.36131649284715,-326.6532365315964,92.67763908376119 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark45(-466.36381812475736,-296.69260913080745,51.31659627111952 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark45(-466.4350896804869,-286.34577246395156,7.105427357601002E-15 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark45(-466.5670824265422,-339.09380774623065,14.101699300497515 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark45(-466.61027167974544,-300.22110133439094,61.93591037024288 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark45(-466.67594945443994,-313.3139408011049,22.800001497101377 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark45(-466.81276278958546,-291.6462910743584,43.79442575672326 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark45(-467.0552782770003,-290.60784834433105,100.0 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark45(-467.1097939515821,-287.69905062749854,100.0 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark45(-467.1519919440281,-280.54401456095985,15.814707287643998 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark45(-467.2477263425847,-311.684384121831,35.91396377519578 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark45(-467.4206595148047,-318.2897645153829,0.49248557896868306 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark45(-467.52239480387715,-284.8032842873394,70.34212712342601 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark45(-467.92268578666324,-281.8152121252549,0.2668561172346955 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark45(-468.0153297369594,-282.30939206781665,55.30980511045453 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark45(-468.05685229913524,-326.95690277193575,97.96610033886301 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark45(-468.09177037552945,-298.1341088043222,14.415774974484094 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark45(-468.1176302408211,-330.22390964430593,48.672501304688154 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark45(-468.12905667622414,-286.72195946007537,9.599657013177804 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark45(-468.1864342821813,-279.9997675254238,15.08304493397155 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark45(-468.32442433059754,-301.36963805363973,100.0 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark45(-468.4197481320284,-299.2697801720211,35.372744024583426 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark45(-468.7467259994445,-283.0384631835694,29.597480123414286 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark45(-468.7966760526182,-299.00105562810785,34.49527572530087 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark45(-468.83535552430413,-292.202844208674,82.15625997154353 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark45(-468.8826795396278,-410.3936477324527,70.75465387761741 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark45(-468.92126147540375,-299.9764508245434,-59.111745507704484 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark45(-469.039773630152,-277.020457978877,51.289718825514825 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark45(-469.0597199043185,-332.3232758521302,59.98765295734455 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark45(-469.06400625713917,-283.6421257899797,9.959875099856077 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark45(-469.5758331504921,-283.4171929603066,68.7353080540077 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark45(-469.6018594655867,-293.81270320472225,40.11911253793704 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark45(-469.62241979630886,-296.900324773064,98.01447793699714 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark45(-469.67292663253704,-286.3071100984712,48.727355494707666 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark45(-469.76226537628,-328.0622551164006,48.81990817268972 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark45(-469.8029164274027,-294.6935761600942,95.2730416893148 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark45(-469.8265857190295,-328.871204932062,34.01787992743749 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark45(-469.84432754224815,-281.07403103323935,80.75216457118839 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark45(-469.8468740272166,-278.1699316605952,100.0 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark45(-469.89042475221595,-279.2436096447663,48.535928718353944 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark45(-469.9285279727189,-308.15493105921405,84.95836056394919 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark45(-469.9608862438202,-278.46783294890895,88.73418299753692 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark45(-469.99517705497334,-317.55880866463974,64.64697697939116 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark45(-470.349431483044,-366.29564300805674,80.98533993446398 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark45(-470.55621588646005,-283.829326322344,12.374855041048178 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark45(-470.5793945851737,-310.1731992458823,65.28709862052588 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark45(-470.9051755543787,-302.09992521430996,95.93458797509805 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark45(-471.4993895602859,-274.7313983047469,100.0 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark45(-471.52792350161087,-317.1116996955808,3.4337274011253527 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark45(-471.5811801787211,-345.32792995516155,40.9391990075969 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark45(-471.94911615651347,-288.2932419015653,52.26845214610668 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark45(-472.0121810719139,-286.61659033108253,99.33115408456135 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark45(-472.28339794743147,-278.91357542104504,100.0 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark45(-472.31385048310284,-347.4588154835433,100.0 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark45(-472.3768619491947,-318.22607553228255,1.122974630171683 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark45(-472.41022218293597,-283.9575336659316,63.82544709557402 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark45(-472.5070223627466,-287.0892208761414,100.0 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark45(-472.5580511877301,-303.2543783232564,25.874970445964692 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark45(-472.5586013173154,-337.3277204613833,7.105427357601002E-15 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark45(-472.5880606611583,-279.716125311547,93.44901982492419 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark45(-472.66883869846333,-315.2059604823652,100.0 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark45(-472.72140461432116,-274.6446845775517,95.32261642720422 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark45(-472.7690878810798,-280.85088917128576,66.05642407260171 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark45(-473.0040538227767,-281.1433192664332,32.72514016150586 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark45(-473.0059695877162,-286.6438309078591,37.2981217276938 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark45(-473.4376133754479,-308.510918637614,56.714111415235436 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark45(-473.45930427728945,-339.15785384253775,71.34525081796033 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark45(-473.5405358163456,-300.4175449082054,64.71710035509517 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark45(-473.5638344068131,-294.2917573423801,100.0 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark45(-473.6496102710428,-298.46379621886575,100.0 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark45(-473.7998096587678,-288.4540682323281,65.83129038698516 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark45(-473.8560120060842,-324.3037718208965,99.5732492692405 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark45(-473.9093472270766,-287.1820491069613,99.12232895230838 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark45(-474.13220620591716,-303.04022423465364,67.98835196188483 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark45(-474.4018439045516,-355.14404176383977,79.54921390799292 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark45(-474.4624407246592,-334.24311404500196,6.889175392220324E-6 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark45(-474.48029554851587,-280.90323583439124,33.9539872351323 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark45(-474.639983559147,-278.3201788850319,29.634521883861055 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark45(-474.6409490424591,-297.16895450034906,6.286060522848274 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark45(-474.6603072188345,-298.48386750440017,92.1436319269713 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark45(-474.66999866632716,-308.8259609399357,39.583564774872315 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark45(-474.7712619740548,-277.11352666872284,34.321779355203006 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark45(-474.9187676918575,-283.036657007758,39.46169091541185 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark45(-474.9345249571759,-335.1197873086489,11.380990502052441 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark45(-475.3132717338519,-376.61949133294087,30.514808542226206 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark45(-475.34509711465284,-294.71293163519357,74.00391995962042 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark45(-475.8093794163737,-282.8399349477478,1.2958875596972348 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark45(-475.8913094398674,-290.17728231888117,100.0 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark45(-475.97579918281696,-349.44167203191387,89.99222858476367 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark45(-476.12474318446453,-280.43291691606225,13.188463792726353 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark45(-476.30717160810747,-269.9507297056645,100.0 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark45(-476.46424644124886,-287.76381891551597,97.07998456598298 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark45(-476.5316497967032,-322.47143270291315,67.79725068084466 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark45(-476.7421311717103,-281.49515304135383,55.008622503541886 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark45(-476.79534385747246,-271.03628098170674,2.8092901959215766 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark45(-477.26387356664776,-316.2930496984739,47.03879484933847 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark45(-477.3061709255099,-358.6281883212875,77.57506732142059 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark45(-477.51065159227767,-277.7090731234368,36.08545585362057 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark45(-477.73466400156985,-277.0422545730739,1.5811364106440067 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark45(-477.75228476114654,-283.3811932424563,100.0 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark45(-477.81889153272067,-317.78656748764797,82.31416701002988 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark45(-478.095560107374,-292.9535623544139,61.54447114817418 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark45(-478.1022796808844,-294.43565954697067,45.59889527664072 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark45(-478.12387393091007,-321.28407384951134,33.770408799677284 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark45(-478.2113504127527,-289.692506623151,19.996242110337633 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark45(-478.3493420129863,-413.93279092087573,39.64215094250767 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark45(-478.4429269761519,-277.71740067061506,8.383128927228327 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark45(-478.5783396828501,-277.14382157643945,100.0 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark45(-478.58946141869353,-355.3208664027563,48.30745487362384 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark45(-478.64729051457687,-270.3113222860771,89.67115130005314 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark45(-478.65249858757704,-274.18663716853405,99.48038172309157 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark45(-478.7058936955869,-278.5543249185895,100.0 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark45(-478.73566652540404,-273.8312030552045,82.01751219735155 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark45(-478.799251768848,-289.58707592923406,62.55526759971988 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark45(-478.8870506211547,-276.29607225570464,100.0 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark45(-479.0099248688807,-312.1916119308958,22.5313250042596 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark45(-479.02708392109423,-316.7628189972418,100.0 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark45(-479.05459687775283,-270.2062415954499,33.479104841846805 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark45(-479.0547047398941,-269.27864022738197,29.449352876762703 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark45(-479.0771134301648,-294.99350635819667,100.0 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark45(-479.5643442716859,-269.71495507574656,0.10030440998778545 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark45(-479.76094652532294,-295.05847291862904,5.644313774131618 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark45(-479.85379891130543,-281.86391382328856,9.275824879015218 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark45(-480.0182722031851,-282.2521507747964,77.07167886391224 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark45(-480.1223342952686,-270.49104765584036,39.18219826401335 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark45(-480.1285234752956,-289.94645080616147,86.59186277869802 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark45(-480.36583175466177,-279.9783396214093,100.0 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark45(-480.39542008636244,-273.3319781895616,56.82285075638407 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark45(-480.40260303432433,-272.6202889497423,81.66862708915758 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark45(-480.4459256805684,-270.40819191009086,67.20139975391393 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark45(-480.4664954642257,-314.32571921251633,97.08515143911393 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark45(-480.94052613607545,-324.56398151157777,17.420183860298195 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark45(-481.0466409899962,-268.55746196376793,96.3469732458669 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark45(-481.2300038250192,-376.4646372218597,100.0 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark45(-481.27360009682195,-279.5070009813874,69.3040911955936 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark45(-481.31713009740963,-277.94719842660925,70.77845581054876 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark45(-481.45414285300495,-283.8590052755747,36.79610040889051 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark45(-481.50635696987007,-291.70390323228503,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark45(-481.632450286526,-279.28722928421416,80.72511709039625 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark45(-481.7656139310874,-280.5377585395547,31.80823075024378 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark45(-481.9834532043702,-293.2510022440952,98.46123791901607 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark45(-482.0305749184319,-330.45821864888507,5.30386405978183 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark45(-482.137849993467,-276.86322648444224,49.22060079754303 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark45(-482.4271518119886,-292.6602593310713,9.645641221929012 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark45(-482.65104319450415,-337.4168373832146,88.31836477032263 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark45(-482.6801953014561,-270.89296828807295,100.0 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark45(-482.684191661874,-265.90043225875195,31.73161694173737 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark45(-482.98073330297495,-307.4977353720621,80.8948465330966 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark45(-483.0515976700203,-318.25024104227623,52.36056250123892 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark45(-483.40088118703966,-266.72709756966213,59.667157351722295 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark45(-483.40798317822794,-296.7195921831615,44.92115941309643 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark45(-483.4331246517045,-291.3069968296263,89.06119017893037 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark45(-483.54545800424523,-299.8414470161014,57.05837075361987 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark45(-483.55707968476713,-270.9466025011022,46.19736467340013 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark45(-483.568319081133,-294.50797764143925,84.3842981692236 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark45(-483.6179441852223,-280.6254476856353,85.37417514354647 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark45(-483.68373596369264,-320.3024540703861,38.66730654732419 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark45(-483.6861262370126,-281.29391157712644,100.0 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark45(-483.728542662435,-268.19649339592974,86.66107922529696 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark45(-483.8862169526676,-271.7729832770762,93.11873058812628 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark45(-483.894522285209,-282.93324411706055,62.58526012872073 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark45(-483.93739437688123,-272.7755283108437,3.7655262686976414 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark45(-484.03585269291796,-336.4890749640067,51.24538658032918 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark45(-484.14775513398024,-289.79989401562284,68.06394274320945 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark45(-484.39101404958376,-293.99651174157435,82.33530465453498 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark45(-484.591803656598,-313.97302782969257,53.63724966071379 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark45(-484.6724308823226,-285.9406964517844,80.06338681698969 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark45(-484.77749949993324,-278.4196413974273,45.9198943513976 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark45(-484.93483523409935,-299.03327782624336,52.39194777384105 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark45(-485.02911066535336,-354.27642634572845,17.744053310958567 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark45(-485.0981688032717,-330.6735703375006,40.71987191069945 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark45(-485.33476228808337,-264.5630899209584,5.7164808841478845 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark45(-485.5148919283408,-275.9700236933431,33.86601539178713 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark45(-485.7503382202101,-346.92979563013364,49.26131334304593 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark45(-485.8516413404585,-262.0718568091317,100.0 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark45(-486.23485047649433,-263.2549642198747,9.785461777769711 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark45(-486.30219028722865,-297.6444005184445,4.0128158126815805 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark45(-486.6463203914131,-291.1593752382591,14.083738243228067 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark45(-486.67347939521756,-300.4244512052863,86.9963484241296 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark45(-486.9612234748031,-286.59235852242205,91.09173814292436 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark45(-487.05602498218946,-351.81527886997003,96.50861907068298 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark45(-487.18702292086357,-265.95639716996413,40.446344854304215 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark45(-487.45093829473126,-259.41835491573164,0.6607264832612714 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark45(-487.6054343003431,-331.03089080060215,8.345147360305475 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark45(-487.7306480591577,-285.5148077400039,61.98205395346994 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark45(-487.8103060094105,-290.1689599318873,27.55460698498706 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark45(-487.8350665634701,-373.5489920703965,88.50050940527379 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark45(-488.16048456265804,-271.5479754098561,65.62631460870486 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark45(-488.66592072500447,-321.4164591832569,64.42165117042728 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark45(-488.8178826404617,-273.37201892440993,48.01876131838745 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark45(-489.0192781921592,-287.90927297232156,21.703255449878924 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark45(-489.09692218269583,-312.1863355589468,18.7280086719218 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark45(-489.24951891606605,-357.19562274508587,100.0 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark45(-489.25789799095196,-272.2318769697453,23.878339581801228 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark45(-489.4257265206837,-324.83440114753915,60.21818542596324 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark45(-489.5219934372421,-305.500735573973,81.83739072366396 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark45(-489.56917907285145,-286.12026370586955,53.191749613890266 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark45(-489.64189526416095,-305.87671349001096,17.2269298169235 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark45(-489.6793224529075,-258.5249839333244,9.060257115447556 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark45(-489.6828304514178,-318.8925033175186,25.92326933409342 ) ;
  }

  @Test
  public void test2476() {
    coral.tests.JPFBenchmark.benchmark45(-489.7061542917227,-303.5719396313324,34.918084958847004 ) ;
  }

  @Test
  public void test2477() {
    coral.tests.JPFBenchmark.benchmark45(-489.7899915872903,-310.6841773810333,69.28219163782009 ) ;
  }

  @Test
  public void test2478() {
    coral.tests.JPFBenchmark.benchmark45(-489.8969624819318,-265.5179371370902,48.69058712238561 ) ;
  }

  @Test
  public void test2479() {
    coral.tests.JPFBenchmark.benchmark45(-489.8984389912056,-261.1480187070433,33.57078737330448 ) ;
  }

  @Test
  public void test2480() {
    coral.tests.JPFBenchmark.benchmark45(-490.0954486397379,-299.08752706922115,84.18573447224159 ) ;
  }

  @Test
  public void test2481() {
    coral.tests.JPFBenchmark.benchmark45(-490.4340318958188,-336.20254503053746,100.0 ) ;
  }

  @Test
  public void test2482() {
    coral.tests.JPFBenchmark.benchmark45(-490.4734601757732,-267.25208929874054,83.46332756614166 ) ;
  }

  @Test
  public void test2483() {
    coral.tests.JPFBenchmark.benchmark45(-490.5194636470768,-273.0475448889583,82.3745218757461 ) ;
  }

  @Test
  public void test2484() {
    coral.tests.JPFBenchmark.benchmark45(-490.5833154699778,-269.3737784229536,88.18786865728129 ) ;
  }

  @Test
  public void test2485() {
    coral.tests.JPFBenchmark.benchmark45(-490.8642055359413,-308.6175615285423,3.933756420689434 ) ;
  }

  @Test
  public void test2486() {
    coral.tests.JPFBenchmark.benchmark45(-491.0251761807463,-307.00090694976655,27.90902417846668 ) ;
  }

  @Test
  public void test2487() {
    coral.tests.JPFBenchmark.benchmark45(-491.0934849905146,-279.1189109903374,15.312049484450995 ) ;
  }

  @Test
  public void test2488() {
    coral.tests.JPFBenchmark.benchmark45(-491.1899018380237,-318.94663889693953,58.80575355190919 ) ;
  }

  @Test
  public void test2489() {
    coral.tests.JPFBenchmark.benchmark45(-491.2617082605208,-267.72922930294044,21.414029949465487 ) ;
  }

  @Test
  public void test2490() {
    coral.tests.JPFBenchmark.benchmark45(-491.290266502469,-275.5591657983268,100.0 ) ;
  }

  @Test
  public void test2491() {
    coral.tests.JPFBenchmark.benchmark45(-491.3339770425009,-276.215104045898,100.0 ) ;
  }

  @Test
  public void test2492() {
    coral.tests.JPFBenchmark.benchmark45(-491.35542719909523,-258.0893197971827,43.62988373876311 ) ;
  }

  @Test
  public void test2493() {
    coral.tests.JPFBenchmark.benchmark45(-491.47909778790034,-256.56911415831166,37.017112292391886 ) ;
  }

  @Test
  public void test2494() {
    coral.tests.JPFBenchmark.benchmark45(-491.7579343694223,-335.4542395366871,5.707203408165057 ) ;
  }

  @Test
  public void test2495() {
    coral.tests.JPFBenchmark.benchmark45(-492.012763838273,-294.8408473618009,27.725017737750164 ) ;
  }

  @Test
  public void test2496() {
    coral.tests.JPFBenchmark.benchmark45(-492.05487081439526,-314.2136292052747,1.5299826727850387 ) ;
  }

  @Test
  public void test2497() {
    coral.tests.JPFBenchmark.benchmark45(-492.55970777468644,-291.1665511738851,51.63757209829109 ) ;
  }

  @Test
  public void test2498() {
    coral.tests.JPFBenchmark.benchmark45(-492.69570615448737,-273.56781756152304,33.1923993675089 ) ;
  }

  @Test
  public void test2499() {
    coral.tests.JPFBenchmark.benchmark45(-492.7335160276046,-277.98176082583814,58.558048938610085 ) ;
  }

  @Test
  public void test2500() {
    coral.tests.JPFBenchmark.benchmark45(-492.9005022832897,-274.45813771471194,79.97720454284453 ) ;
  }

  @Test
  public void test2501() {
    coral.tests.JPFBenchmark.benchmark45(-493.02433168034713,-286.2551940374642,61.07023391488485 ) ;
  }

  @Test
  public void test2502() {
    coral.tests.JPFBenchmark.benchmark45(-493.13864811686335,-256.15812608987227,51.83093505202385 ) ;
  }

  @Test
  public void test2503() {
    coral.tests.JPFBenchmark.benchmark45(-493.37400620228743,-374.5044864167142,16.909120270633267 ) ;
  }

  @Test
  public void test2504() {
    coral.tests.JPFBenchmark.benchmark45(-493.69084712698975,-321.13320070477494,11.061341694815297 ) ;
  }

  @Test
  public void test2505() {
    coral.tests.JPFBenchmark.benchmark45(-493.75979534934294,-290.4481267707053,99.8729452453569 ) ;
  }

  @Test
  public void test2506() {
    coral.tests.JPFBenchmark.benchmark45(-493.7646480303368,-253.68030578154662,88.43644890860492 ) ;
  }

  @Test
  public void test2507() {
    coral.tests.JPFBenchmark.benchmark45(-494.16053867566495,-257.78292806130816,35.69921639073752 ) ;
  }

  @Test
  public void test2508() {
    coral.tests.JPFBenchmark.benchmark45(-494.2007852288952,-326.41480486854454,43.78764929167167 ) ;
  }

  @Test
  public void test2509() {
    coral.tests.JPFBenchmark.benchmark45(-494.22710332970127,-265.9122133806269,56.226774199831226 ) ;
  }

  @Test
  public void test2510() {
    coral.tests.JPFBenchmark.benchmark45(-494.33664352241533,-381.54007338357144,17.72953546567952 ) ;
  }

  @Test
  public void test2511() {
    coral.tests.JPFBenchmark.benchmark45(-494.70416208804005,-328.89994503956916,0.9522631785118705 ) ;
  }

  @Test
  public void test2512() {
    coral.tests.JPFBenchmark.benchmark45(-495.0378476301635,-268.5361072334425,69.86512639363994 ) ;
  }

  @Test
  public void test2513() {
    coral.tests.JPFBenchmark.benchmark45(-495.6445330531349,-261.9547580047967,78.12816357274562 ) ;
  }

  @Test
  public void test2514() {
    coral.tests.JPFBenchmark.benchmark45(-495.69434135261923,-283.47567207939187,53.02242419100537 ) ;
  }

  @Test
  public void test2515() {
    coral.tests.JPFBenchmark.benchmark45(-495.83504614891,-258.8883412218192,79.29339116548007 ) ;
  }

  @Test
  public void test2516() {
    coral.tests.JPFBenchmark.benchmark45(-495.8827156085762,-250.47307518671414,73.44592687949542 ) ;
  }

  @Test
  public void test2517() {
    coral.tests.JPFBenchmark.benchmark45(-496.16729411467816,-259.9016879884633,100.0 ) ;
  }

  @Test
  public void test2518() {
    coral.tests.JPFBenchmark.benchmark45(-496.1994254022135,-259.3497930030836,41.57876812868321 ) ;
  }

  @Test
  public void test2519() {
    coral.tests.JPFBenchmark.benchmark45(-496.29008072999807,-288.2306162211332,85.23386975695558 ) ;
  }

  @Test
  public void test2520() {
    coral.tests.JPFBenchmark.benchmark45(-496.39874271316455,-261.5851327009564,67.2860795539256 ) ;
  }

  @Test
  public void test2521() {
    coral.tests.JPFBenchmark.benchmark45(-496.4594754425435,-250.4514331019687,90.73719401433456 ) ;
  }

  @Test
  public void test2522() {
    coral.tests.JPFBenchmark.benchmark45(-496.57618328190364,-276.3867032412426,71.50516428213592 ) ;
  }

  @Test
  public void test2523() {
    coral.tests.JPFBenchmark.benchmark45(-496.64227414061264,-254.6685198688433,64.37963472582484 ) ;
  }

  @Test
  public void test2524() {
    coral.tests.JPFBenchmark.benchmark45(-496.8899409527852,-256.5374314406313,53.57877183297825 ) ;
  }

  @Test
  public void test2525() {
    coral.tests.JPFBenchmark.benchmark45(-496.9888289353354,-298.46235871939876,61.55119307517626 ) ;
  }

  @Test
  public void test2526() {
    coral.tests.JPFBenchmark.benchmark45(-497.026581084966,-286.484417338536,42.04924449150954 ) ;
  }

  @Test
  public void test2527() {
    coral.tests.JPFBenchmark.benchmark45(-497.04360460454825,-259.5965437716893,58.38865852835556 ) ;
  }

  @Test
  public void test2528() {
    coral.tests.JPFBenchmark.benchmark45(-497.2933924378711,-358.1299736175467,88.89978222098131 ) ;
  }

  @Test
  public void test2529() {
    coral.tests.JPFBenchmark.benchmark45(-497.4927581218462,-310.9259349223652,81.64334758920523 ) ;
  }

  @Test
  public void test2530() {
    coral.tests.JPFBenchmark.benchmark45(-497.862262111872,-293.6102092060758,30.02235833506893 ) ;
  }

  @Test
  public void test2531() {
    coral.tests.JPFBenchmark.benchmark45(-498.23774441567036,-303.8887269372218,51.071116212304105 ) ;
  }

  @Test
  public void test2532() {
    coral.tests.JPFBenchmark.benchmark45(-498.28286105330045,-362.48654269230633,58.20985558870799 ) ;
  }

  @Test
  public void test2533() {
    coral.tests.JPFBenchmark.benchmark45(-498.5906702090557,-260.47056743258423,34.13891371831582 ) ;
  }

  @Test
  public void test2534() {
    coral.tests.JPFBenchmark.benchmark45(-499.0738800349668,-278.3517956884083,92.755766081297 ) ;
  }

  @Test
  public void test2535() {
    coral.tests.JPFBenchmark.benchmark45(-499.0973803567316,-261.5366010186698,88.95573821003006 ) ;
  }

  @Test
  public void test2536() {
    coral.tests.JPFBenchmark.benchmark45(-499.27174951457073,-281.72829893736883,10.632637090147384 ) ;
  }

  @Test
  public void test2537() {
    coral.tests.JPFBenchmark.benchmark45(-499.2974918159937,-303.0777047847161,47.30809497273714 ) ;
  }

  @Test
  public void test2538() {
    coral.tests.JPFBenchmark.benchmark45(-499.4622804692211,-252.00525026570676,39.37176621231649 ) ;
  }

  @Test
  public void test2539() {
    coral.tests.JPFBenchmark.benchmark45(-499.8327942608988,-263.6855355875722,47.42174780317227 ) ;
  }

  @Test
  public void test2540() {
    coral.tests.JPFBenchmark.benchmark45(-500.26122892044026,-322.4172485311326,71.68819265819687 ) ;
  }

  @Test
  public void test2541() {
    coral.tests.JPFBenchmark.benchmark45(-500.4186932309725,-252.9644776636428,100.0 ) ;
  }

  @Test
  public void test2542() {
    coral.tests.JPFBenchmark.benchmark45(-500.4994925326546,-316.42516892279264,40.08445707702552 ) ;
  }

  @Test
  public void test2543() {
    coral.tests.JPFBenchmark.benchmark45(-500.6683136319752,-253.41207579816785,84.87622024963159 ) ;
  }

  @Test
  public void test2544() {
    coral.tests.JPFBenchmark.benchmark45(-500.7752782197299,-257.8776358092552,100.0 ) ;
  }

  @Test
  public void test2545() {
    coral.tests.JPFBenchmark.benchmark45(-500.8138071380717,-265.18290682422946,10.351220974928225 ) ;
  }

  @Test
  public void test2546() {
    coral.tests.JPFBenchmark.benchmark45(-500.91889918927586,-265.8406334867758,82.98807643983056 ) ;
  }

  @Test
  public void test2547() {
    coral.tests.JPFBenchmark.benchmark45(-500.9534487913799,-245.87064803993118,100.0 ) ;
  }

  @Test
  public void test2548() {
    coral.tests.JPFBenchmark.benchmark45(-501.2920387281884,-253.21360264880244,41.48592933522281 ) ;
  }

  @Test
  public void test2549() {
    coral.tests.JPFBenchmark.benchmark45(-501.3015385476269,-264.3458100118315,6.394350031534373 ) ;
  }

  @Test
  public void test2550() {
    coral.tests.JPFBenchmark.benchmark45(-501.5366649777505,-254.9913989312642,49.075244661127414 ) ;
  }

  @Test
  public void test2551() {
    coral.tests.JPFBenchmark.benchmark45(-501.637796231048,-245.42281537008438,24.555544090728688 ) ;
  }

  @Test
  public void test2552() {
    coral.tests.JPFBenchmark.benchmark45(-502.0388753105281,-263.0669014247423,87.32186744192447 ) ;
  }

  @Test
  public void test2553() {
    coral.tests.JPFBenchmark.benchmark45(-502.3176194179185,-255.69714954588818,26.21460658758727 ) ;
  }

  @Test
  public void test2554() {
    coral.tests.JPFBenchmark.benchmark45(-502.3499659338677,-245.8806316005303,72.10970127412597 ) ;
  }

  @Test
  public void test2555() {
    coral.tests.JPFBenchmark.benchmark45(-502.42054698270636,-264.0353334192881,18.880856205371675 ) ;
  }

  @Test
  public void test2556() {
    coral.tests.JPFBenchmark.benchmark45(-502.4450836377247,-291.00367357181887,35.70632307960099 ) ;
  }

  @Test
  public void test2557() {
    coral.tests.JPFBenchmark.benchmark45(-502.87278066406407,-258.8328473223054,53.787953663144094 ) ;
  }

  @Test
  public void test2558() {
    coral.tests.JPFBenchmark.benchmark45(-503.1602730674845,-259.2168934113967,30.6619044667911 ) ;
  }

  @Test
  public void test2559() {
    coral.tests.JPFBenchmark.benchmark45(-503.160523462624,-255.2777951944678,30.884899321799764 ) ;
  }

  @Test
  public void test2560() {
    coral.tests.JPFBenchmark.benchmark45(-503.44886738805786,-293.8565193188418,80.21180749245772 ) ;
  }

  @Test
  public void test2561() {
    coral.tests.JPFBenchmark.benchmark45(-503.4502266981925,-250.98127691158663,38.76154809924529 ) ;
  }

  @Test
  public void test2562() {
    coral.tests.JPFBenchmark.benchmark45(-503.46248391915793,-254.15901706410867,14.579586919286996 ) ;
  }

  @Test
  public void test2563() {
    coral.tests.JPFBenchmark.benchmark45(-503.9365001437518,-260.6984805076488,68.13057045898299 ) ;
  }

  @Test
  public void test2564() {
    coral.tests.JPFBenchmark.benchmark45(-503.943096064042,-324.34393856652105,98.78954096381793 ) ;
  }

  @Test
  public void test2565() {
    coral.tests.JPFBenchmark.benchmark45(-503.94642291341245,-255.45743119956194,53.463266041941296 ) ;
  }

  @Test
  public void test2566() {
    coral.tests.JPFBenchmark.benchmark45(-503.95625889757827,-264.0973968331507,58.7022915368955 ) ;
  }

  @Test
  public void test2567() {
    coral.tests.JPFBenchmark.benchmark45(-504.00958524566494,-251.44691040731323,100.0 ) ;
  }

  @Test
  public void test2568() {
    coral.tests.JPFBenchmark.benchmark45(-504.02683200899435,-255.0745584774449,5.160841855442257 ) ;
  }

  @Test
  public void test2569() {
    coral.tests.JPFBenchmark.benchmark45(-504.03339988795733,-367.10783735218945,44.37590712965505 ) ;
  }

  @Test
  public void test2570() {
    coral.tests.JPFBenchmark.benchmark45(-504.1305879205935,-281.77040510121714,75.33107224802873 ) ;
  }

  @Test
  public void test2571() {
    coral.tests.JPFBenchmark.benchmark45(-504.3971093758365,-340.82324460201795,-6.447518679250626E-7 ) ;
  }

  @Test
  public void test2572() {
    coral.tests.JPFBenchmark.benchmark45(-504.5853444475098,-287.9754721466897,34.64549965155916 ) ;
  }

  @Test
  public void test2573() {
    coral.tests.JPFBenchmark.benchmark45(-504.5986271627771,-249.85775198371235,56.76925067150174 ) ;
  }

  @Test
  public void test2574() {
    coral.tests.JPFBenchmark.benchmark45(-504.6258789808608,-254.98158883286357,100.0 ) ;
  }

  @Test
  public void test2575() {
    coral.tests.JPFBenchmark.benchmark45(-504.71406648543325,-266.25582677094854,98.77320736291765 ) ;
  }

  @Test
  public void test2576() {
    coral.tests.JPFBenchmark.benchmark45(-504.7647367642871,-290.66101369451917,54.207439973900364 ) ;
  }

  @Test
  public void test2577() {
    coral.tests.JPFBenchmark.benchmark45(-504.8083719804699,-273.6531792827885,100.0 ) ;
  }

  @Test
  public void test2578() {
    coral.tests.JPFBenchmark.benchmark45(-505.38753187000833,-243.89846666354947,12.420258908894667 ) ;
  }

  @Test
  public void test2579() {
    coral.tests.JPFBenchmark.benchmark45(-505.6473203049359,-253.32667541992944,100.0 ) ;
  }

  @Test
  public void test2580() {
    coral.tests.JPFBenchmark.benchmark45(-505.8475993924771,-248.34896555812614,82.48525994211883 ) ;
  }

  @Test
  public void test2581() {
    coral.tests.JPFBenchmark.benchmark45(-505.97924759079245,-257.77954760039677,20.583727302109693 ) ;
  }

  @Test
  public void test2582() {
    coral.tests.JPFBenchmark.benchmark45(-506.32595038260575,-251.4881147729467,100.0 ) ;
  }

  @Test
  public void test2583() {
    coral.tests.JPFBenchmark.benchmark45(-506.38148601554394,-294.6561548704274,7.105427357601002E-15 ) ;
  }

  @Test
  public void test2584() {
    coral.tests.JPFBenchmark.benchmark45(-506.60387064695357,-287.76283291384004,56.59783990716875 ) ;
  }

  @Test
  public void test2585() {
    coral.tests.JPFBenchmark.benchmark45(-506.6557673742171,-254.744058865991,75.32548918838239 ) ;
  }

  @Test
  public void test2586() {
    coral.tests.JPFBenchmark.benchmark45(-506.7293048998525,-244.1726779993496,74.76452045238764 ) ;
  }

  @Test
  public void test2587() {
    coral.tests.JPFBenchmark.benchmark45(-507.09533030606974,-246.99366641126574,36.40310954006313 ) ;
  }

  @Test
  public void test2588() {
    coral.tests.JPFBenchmark.benchmark45(-507.1010355297151,-295.72296936367576,32.62172317454983 ) ;
  }

  @Test
  public void test2589() {
    coral.tests.JPFBenchmark.benchmark45(-507.2165447690221,-277.7792403937223,46.92307664393843 ) ;
  }

  @Test
  public void test2590() {
    coral.tests.JPFBenchmark.benchmark45(-507.21673137966616,-240.3683426400592,67.35763877740752 ) ;
  }

  @Test
  public void test2591() {
    coral.tests.JPFBenchmark.benchmark45(-507.25397722997195,-329.770877089569,100.0 ) ;
  }

  @Test
  public void test2592() {
    coral.tests.JPFBenchmark.benchmark45(-507.3207213979932,-261.23162699261957,69.73224480931594 ) ;
  }

  @Test
  public void test2593() {
    coral.tests.JPFBenchmark.benchmark45(-507.5814195522986,-239.36826484926007,54.53702806248424 ) ;
  }

  @Test
  public void test2594() {
    coral.tests.JPFBenchmark.benchmark45(-508.0802443423552,-247.4421002333276,43.887654404689584 ) ;
  }

  @Test
  public void test2595() {
    coral.tests.JPFBenchmark.benchmark45(-508.3741396566927,-251.4467260040123,27.107687799775533 ) ;
  }

  @Test
  public void test2596() {
    coral.tests.JPFBenchmark.benchmark45(-509.1094187275319,-241.53364623063229,43.97173742615499 ) ;
  }

  @Test
  public void test2597() {
    coral.tests.JPFBenchmark.benchmark45(-509.2317166610843,-249.93760426863741,3.7426622396227467 ) ;
  }

  @Test
  public void test2598() {
    coral.tests.JPFBenchmark.benchmark45(-509.37846689970297,-236.6990887349723,68.64232628288033 ) ;
  }

  @Test
  public void test2599() {
    coral.tests.JPFBenchmark.benchmark45(-509.66967906053384,-239.36196720040255,97.18777176899633 ) ;
  }

  @Test
  public void test2600() {
    coral.tests.JPFBenchmark.benchmark45(-510.0883335704943,-260.2461752361337,55.79904391217207 ) ;
  }

  @Test
  public void test2601() {
    coral.tests.JPFBenchmark.benchmark45(-510.1938724392986,-299.362372633508,92.42837747541037 ) ;
  }

  @Test
  public void test2602() {
    coral.tests.JPFBenchmark.benchmark45(-510.2594716117524,-355.8865452110428,54.48845647207392 ) ;
  }

  @Test
  public void test2603() {
    coral.tests.JPFBenchmark.benchmark45(-510.30795104155646,-251.605159572258,80.17171715521638 ) ;
  }

  @Test
  public void test2604() {
    coral.tests.JPFBenchmark.benchmark45(-51.04425763690233,-762.7092068598816,93.50491600131866 ) ;
  }

  @Test
  public void test2605() {
    coral.tests.JPFBenchmark.benchmark45(-510.6796668106762,-251.12537842834303,79.39617510315534 ) ;
  }

  @Test
  public void test2606() {
    coral.tests.JPFBenchmark.benchmark45(-510.814994024038,-281.6477593219881,2.894339085923008 ) ;
  }

  @Test
  public void test2607() {
    coral.tests.JPFBenchmark.benchmark45(-510.84786574669454,-261.55128498430025,26.14362159874007 ) ;
  }

  @Test
  public void test2608() {
    coral.tests.JPFBenchmark.benchmark45(-51.10366046457373,-704.2429122457663,65.04257291553236 ) ;
  }

  @Test
  public void test2609() {
    coral.tests.JPFBenchmark.benchmark45(-511.0978251355715,-272.6938280830904,46.67008259672528 ) ;
  }

  @Test
  public void test2610() {
    coral.tests.JPFBenchmark.benchmark45(-511.18075685870735,-244.41621301286236,59.961202036509604 ) ;
  }

  @Test
  public void test2611() {
    coral.tests.JPFBenchmark.benchmark45(-511.19961199941855,-276.4462148801347,25.24040068855038 ) ;
  }

  @Test
  public void test2612() {
    coral.tests.JPFBenchmark.benchmark45(-511.40360766143226,-243.5914419583104,61.287241689757536 ) ;
  }

  @Test
  public void test2613() {
    coral.tests.JPFBenchmark.benchmark45(-512.1272134280242,-261.72573274428345,0.397251975804096 ) ;
  }

  @Test
  public void test2614() {
    coral.tests.JPFBenchmark.benchmark45(-512.3090173827364,-237.76399919594934,100.0 ) ;
  }

  @Test
  public void test2615() {
    coral.tests.JPFBenchmark.benchmark45(-512.4126362890212,-258.6396549071099,63.30794157797554 ) ;
  }

  @Test
  public void test2616() {
    coral.tests.JPFBenchmark.benchmark45(-512.5030854477153,-299.0145583221574,41.16743958426491 ) ;
  }

  @Test
  public void test2617() {
    coral.tests.JPFBenchmark.benchmark45(-512.7206302064303,-233.3272159739761,80.58976956454913 ) ;
  }

  @Test
  public void test2618() {
    coral.tests.JPFBenchmark.benchmark45(-512.9064018799669,-246.59601231917446,100.0 ) ;
  }

  @Test
  public void test2619() {
    coral.tests.JPFBenchmark.benchmark45(-512.978247416213,-239.03393979820268,2.154385151823959 ) ;
  }

  @Test
  public void test2620() {
    coral.tests.JPFBenchmark.benchmark45(-512.980144199438,-237.93675897282202,33.28503857883098 ) ;
  }

  @Test
  public void test2621() {
    coral.tests.JPFBenchmark.benchmark45(-513.315288291209,-240.12408198149362,53.975643508488474 ) ;
  }

  @Test
  public void test2622() {
    coral.tests.JPFBenchmark.benchmark45(-513.3364059298674,-268.1609474469402,72.55137889101303 ) ;
  }

  @Test
  public void test2623() {
    coral.tests.JPFBenchmark.benchmark45(-513.355342979192,-264.83699270197246,62.221328785808225 ) ;
  }

  @Test
  public void test2624() {
    coral.tests.JPFBenchmark.benchmark45(-513.4907001487636,-275.8279929661244,76.71629131570091 ) ;
  }

  @Test
  public void test2625() {
    coral.tests.JPFBenchmark.benchmark45(-513.5954833324988,-251.84755194983018,46.666462220779955 ) ;
  }

  @Test
  public void test2626() {
    coral.tests.JPFBenchmark.benchmark45(-513.6902112223977,-252.83483451738584,13.88900408868135 ) ;
  }

  @Test
  public void test2627() {
    coral.tests.JPFBenchmark.benchmark45(-513.7569418910217,-234.53419940678785,50.041578475939616 ) ;
  }

  @Test
  public void test2628() {
    coral.tests.JPFBenchmark.benchmark45(-513.7657416630058,-238.31289560020895,59.44643946241209 ) ;
  }

  @Test
  public void test2629() {
    coral.tests.JPFBenchmark.benchmark45(-513.8183494306996,-264.1879388712029,18.796530971006973 ) ;
  }

  @Test
  public void test2630() {
    coral.tests.JPFBenchmark.benchmark45(-513.958025499735,-278.81663372487316,11.304977864848738 ) ;
  }

  @Test
  public void test2631() {
    coral.tests.JPFBenchmark.benchmark45(-514.0233382705811,-273.656403705995,100.0 ) ;
  }

  @Test
  public void test2632() {
    coral.tests.JPFBenchmark.benchmark45(-514.2112848040719,-285.9752077679724,9.88032953952036 ) ;
  }

  @Test
  public void test2633() {
    coral.tests.JPFBenchmark.benchmark45(-514.2888162167822,-253.56563272270483,100.0 ) ;
  }

  @Test
  public void test2634() {
    coral.tests.JPFBenchmark.benchmark45(-514.3359528785079,-243.93061297781026,67.55292276185781 ) ;
  }

  @Test
  public void test2635() {
    coral.tests.JPFBenchmark.benchmark45(-514.953370010292,-238.75944558753207,41.272925383423654 ) ;
  }

  @Test
  public void test2636() {
    coral.tests.JPFBenchmark.benchmark45(-514.9990762593726,-279.73191344097086,12.646342719766253 ) ;
  }

  @Test
  public void test2637() {
    coral.tests.JPFBenchmark.benchmark45(-515.2303095793785,-280.6907306827485,100.0 ) ;
  }

  @Test
  public void test2638() {
    coral.tests.JPFBenchmark.benchmark45(-515.3926847648736,-243.4368273702163,90.39408116162048 ) ;
  }

  @Test
  public void test2639() {
    coral.tests.JPFBenchmark.benchmark45(-515.4898197889329,-235.7206267487986,91.36930712322956 ) ;
  }

  @Test
  public void test2640() {
    coral.tests.JPFBenchmark.benchmark45(-515.8741239737342,-253.9150233874321,89.29727946173162 ) ;
  }

  @Test
  public void test2641() {
    coral.tests.JPFBenchmark.benchmark45(-515.8998111632992,-238.48000933655283,36.578495005139985 ) ;
  }

  @Test
  public void test2642() {
    coral.tests.JPFBenchmark.benchmark45(-515.9692993705942,-254.91211885498558,98.41285877955954 ) ;
  }

  @Test
  public void test2643() {
    coral.tests.JPFBenchmark.benchmark45(-516.1074493124077,-255.1323807503015,2.6822116338716313 ) ;
  }

  @Test
  public void test2644() {
    coral.tests.JPFBenchmark.benchmark45(-516.2083174288678,-298.5777821657595,50.38941773503984 ) ;
  }

  @Test
  public void test2645() {
    coral.tests.JPFBenchmark.benchmark45(-516.2186177813577,-265.05379319426515,42.06403533793818 ) ;
  }

  @Test
  public void test2646() {
    coral.tests.JPFBenchmark.benchmark45(-516.2684368795102,-248.2604573378989,12.116904233269139 ) ;
  }

  @Test
  public void test2647() {
    coral.tests.JPFBenchmark.benchmark45(-516.5478537339342,-263.29726659321744,100.0 ) ;
  }

  @Test
  public void test2648() {
    coral.tests.JPFBenchmark.benchmark45(-516.6085371813201,-235.7524060141583,86.13624101503638 ) ;
  }

  @Test
  public void test2649() {
    coral.tests.JPFBenchmark.benchmark45(-516.6604492623535,-250.45019451527645,40.76566696361047 ) ;
  }

  @Test
  public void test2650() {
    coral.tests.JPFBenchmark.benchmark45(-517.1677478552833,-260.10323412013076,100.0 ) ;
  }

  @Test
  public void test2651() {
    coral.tests.JPFBenchmark.benchmark45(-518.0910520266234,-234.10359990892715,35.628556369766244 ) ;
  }

  @Test
  public void test2652() {
    coral.tests.JPFBenchmark.benchmark45(-518.5984155697523,-241.29945747996925,58.41833699707547 ) ;
  }

  @Test
  public void test2653() {
    coral.tests.JPFBenchmark.benchmark45(-518.96126465528,-266.80893768007604,84.78754569275617 ) ;
  }

  @Test
  public void test2654() {
    coral.tests.JPFBenchmark.benchmark45(-518.9825123827073,-278.8816784037196,22.462225313593095 ) ;
  }

  @Test
  public void test2655() {
    coral.tests.JPFBenchmark.benchmark45(-519.7281108377983,-288.827497488694,14.57343759724678 ) ;
  }

  @Test
  public void test2656() {
    coral.tests.JPFBenchmark.benchmark45(-519.8477671729486,-296.9068013286065,6.404676399348318 ) ;
  }

  @Test
  public void test2657() {
    coral.tests.JPFBenchmark.benchmark45(-520.0191818952638,-237.26988783987903,100.0 ) ;
  }

  @Test
  public void test2658() {
    coral.tests.JPFBenchmark.benchmark45(-520.3804005572711,-226.31637410895928,56.78956165507276 ) ;
  }

  @Test
  public void test2659() {
    coral.tests.JPFBenchmark.benchmark45(-520.5883489303224,-226.43908727391957,78.95636040429108 ) ;
  }

  @Test
  public void test2660() {
    coral.tests.JPFBenchmark.benchmark45(-520.9747718326881,-225.28652558520503,0.6644181889322596 ) ;
  }

  @Test
  public void test2661() {
    coral.tests.JPFBenchmark.benchmark45(-521.2343940007546,-227.70992467140553,74.36355508514976 ) ;
  }

  @Test
  public void test2662() {
    coral.tests.JPFBenchmark.benchmark45(-521.478403554396,-260.6759874971931,89.16889934543926 ) ;
  }

  @Test
  public void test2663() {
    coral.tests.JPFBenchmark.benchmark45(-521.7747643112036,-225.7621914964699,2.9385863179328737 ) ;
  }

  @Test
  public void test2664() {
    coral.tests.JPFBenchmark.benchmark45(-521.979796586245,-266.59957960404597,73.46119570137458 ) ;
  }

  @Test
  public void test2665() {
    coral.tests.JPFBenchmark.benchmark45(-522.0562806495649,-260.4599547071101,20.18193937053124 ) ;
  }

  @Test
  public void test2666() {
    coral.tests.JPFBenchmark.benchmark45(-522.215098900245,-238.17087617381708,9.884508648345843 ) ;
  }

  @Test
  public void test2667() {
    coral.tests.JPFBenchmark.benchmark45(-522.4971000909238,-246.60736046879785,14.20802386612543 ) ;
  }

  @Test
  public void test2668() {
    coral.tests.JPFBenchmark.benchmark45(-522.5319252578463,-258.6818925992382,61.858839320524766 ) ;
  }

  @Test
  public void test2669() {
    coral.tests.JPFBenchmark.benchmark45(-522.8032143332703,-278.7979211335372,100.0 ) ;
  }

  @Test
  public void test2670() {
    coral.tests.JPFBenchmark.benchmark45(-522.8509941152463,-258.6463032794959,3.5063760433478474E-5 ) ;
  }

  @Test
  public void test2671() {
    coral.tests.JPFBenchmark.benchmark45(-522.9978522321197,-261.1935398094209,16.363891550914445 ) ;
  }

  @Test
  public void test2672() {
    coral.tests.JPFBenchmark.benchmark45(-523.160581336849,-233.13113475138732,20.018839579857513 ) ;
  }

  @Test
  public void test2673() {
    coral.tests.JPFBenchmark.benchmark45(-523.5256824670975,-258.1367153136579,80.46373804698152 ) ;
  }

  @Test
  public void test2674() {
    coral.tests.JPFBenchmark.benchmark45(-524.0746698594845,-272.870731605563,100.0 ) ;
  }

  @Test
  public void test2675() {
    coral.tests.JPFBenchmark.benchmark45(-524.1615873286581,-241.53880992071086,42.97871084612271 ) ;
  }

  @Test
  public void test2676() {
    coral.tests.JPFBenchmark.benchmark45(-524.2215797483536,-244.75150547223475,2.1024612673739256 ) ;
  }

  @Test
  public void test2677() {
    coral.tests.JPFBenchmark.benchmark45(-524.3326630899927,-257.8262508983822,61.12085160948169 ) ;
  }

  @Test
  public void test2678() {
    coral.tests.JPFBenchmark.benchmark45(-524.6314537069712,-253.6725233309017,76.61659132379995 ) ;
  }

  @Test
  public void test2679() {
    coral.tests.JPFBenchmark.benchmark45(-524.7522965984251,-231.0945208200043,41.04875828545033 ) ;
  }

  @Test
  public void test2680() {
    coral.tests.JPFBenchmark.benchmark45(-524.8342068310253,-248.57517590387639,87.75178522708501 ) ;
  }

  @Test
  public void test2681() {
    coral.tests.JPFBenchmark.benchmark45(-524.9411874914804,-226.93770824106204,47.09184337832431 ) ;
  }

  @Test
  public void test2682() {
    coral.tests.JPFBenchmark.benchmark45(-524.9987730509621,-227.8279502167052,38.13890683594681 ) ;
  }

  @Test
  public void test2683() {
    coral.tests.JPFBenchmark.benchmark45(-525.1787727163904,-252.17008351877072,96.91284611629297 ) ;
  }

  @Test
  public void test2684() {
    coral.tests.JPFBenchmark.benchmark45(-525.295320950175,-243.3970548108553,37.92683669157191 ) ;
  }

  @Test
  public void test2685() {
    coral.tests.JPFBenchmark.benchmark45(-525.3902740398784,-227.1282951154294,65.64689731052891 ) ;
  }

  @Test
  public void test2686() {
    coral.tests.JPFBenchmark.benchmark45(-525.489800747158,-224.07872608035723,63.34371687948042 ) ;
  }

  @Test
  public void test2687() {
    coral.tests.JPFBenchmark.benchmark45(-525.8257378039494,-244.8912674898451,33.29332539337682 ) ;
  }

  @Test
  public void test2688() {
    coral.tests.JPFBenchmark.benchmark45(-526.1503700054815,-287.5158045891245,100.0 ) ;
  }

  @Test
  public void test2689() {
    coral.tests.JPFBenchmark.benchmark45(-526.1565495952534,-244.24245191851554,91.05835878193238 ) ;
  }

  @Test
  public void test2690() {
    coral.tests.JPFBenchmark.benchmark45(-526.4029049468644,-238.0418350110802,21.39508082653812 ) ;
  }

  @Test
  public void test2691() {
    coral.tests.JPFBenchmark.benchmark45(-526.6337935789632,-309.3877061637592,85.24179534901793 ) ;
  }

  @Test
  public void test2692() {
    coral.tests.JPFBenchmark.benchmark45(-526.7377072955012,-228.95093971530767,27.09357392733031 ) ;
  }

  @Test
  public void test2693() {
    coral.tests.JPFBenchmark.benchmark45(-526.9933201939846,-222.9010472231738,17.64308937686014 ) ;
  }

  @Test
  public void test2694() {
    coral.tests.JPFBenchmark.benchmark45(-527.1477889334515,-224.6170821334023,65.76044304103249 ) ;
  }

  @Test
  public void test2695() {
    coral.tests.JPFBenchmark.benchmark45(-527.2709867375104,-232.21343327665278,20.61826266677282 ) ;
  }

  @Test
  public void test2696() {
    coral.tests.JPFBenchmark.benchmark45(-527.2719422857905,-267.015908391741,94.75687191762623 ) ;
  }

  @Test
  public void test2697() {
    coral.tests.JPFBenchmark.benchmark45(-527.326944228084,-265.26722438544664,17.48439343997579 ) ;
  }

  @Test
  public void test2698() {
    coral.tests.JPFBenchmark.benchmark45(-527.4512652897253,-234.55581912599874,100.0 ) ;
  }

  @Test
  public void test2699() {
    coral.tests.JPFBenchmark.benchmark45(-527.5324888459095,-229.00498993532605,76.24994843777003 ) ;
  }

  @Test
  public void test2700() {
    coral.tests.JPFBenchmark.benchmark45(-527.965561714214,-226.41540498541912,9.524881425459625 ) ;
  }

  @Test
  public void test2701() {
    coral.tests.JPFBenchmark.benchmark45(-528.0101632057273,-256.9415920151045,93.52563837865674 ) ;
  }

  @Test
  public void test2702() {
    coral.tests.JPFBenchmark.benchmark45(-528.073652962801,-260.72704007958293,99.9585671614918 ) ;
  }

  @Test
  public void test2703() {
    coral.tests.JPFBenchmark.benchmark45(-528.6190619610802,-326.57115019298516,16.164566696319355 ) ;
  }

  @Test
  public void test2704() {
    coral.tests.JPFBenchmark.benchmark45(-528.7626224319893,-227.7884063425231,19.743422225986194 ) ;
  }

  @Test
  public void test2705() {
    coral.tests.JPFBenchmark.benchmark45(-529.0198923533101,-269.1159137360947,7.9954744637119575 ) ;
  }

  @Test
  public void test2706() {
    coral.tests.JPFBenchmark.benchmark45(-529.0457564904267,-264.0908374970847,47.795992509029446 ) ;
  }

  @Test
  public void test2707() {
    coral.tests.JPFBenchmark.benchmark45(-529.0633289871663,-226.3491755836983,96.39675337310442 ) ;
  }

  @Test
  public void test2708() {
    coral.tests.JPFBenchmark.benchmark45(-529.2880063417543,-223.66121725909105,55.169051843471806 ) ;
  }

  @Test
  public void test2709() {
    coral.tests.JPFBenchmark.benchmark45(-530.1016033973092,-222.8537444017357,68.79946707725136 ) ;
  }

  @Test
  public void test2710() {
    coral.tests.JPFBenchmark.benchmark45(-530.3315277842564,-216.2117231528222,83.69228119524999 ) ;
  }

  @Test
  public void test2711() {
    coral.tests.JPFBenchmark.benchmark45(-530.4982751902436,-257.6123364057114,100.0 ) ;
  }

  @Test
  public void test2712() {
    coral.tests.JPFBenchmark.benchmark45(-530.7468380478563,-220.2526103301254,10.52399845022282 ) ;
  }

  @Test
  public void test2713() {
    coral.tests.JPFBenchmark.benchmark45(-530.9425659530206,-353.86812129814115,62.7166824778148 ) ;
  }

  @Test
  public void test2714() {
    coral.tests.JPFBenchmark.benchmark45(-531.8320918385317,-218.46380774650018,33.59262641164196 ) ;
  }

  @Test
  public void test2715() {
    coral.tests.JPFBenchmark.benchmark45(-531.8807622983419,-239.72996291353905,1.0444643897660867E-4 ) ;
  }

  @Test
  public void test2716() {
    coral.tests.JPFBenchmark.benchmark45(-532.2792380900346,-260.410556621962,1.5052393436852043 ) ;
  }

  @Test
  public void test2717() {
    coral.tests.JPFBenchmark.benchmark45(-532.4176565994153,-255.22713004490592,42.71060931145482 ) ;
  }

  @Test
  public void test2718() {
    coral.tests.JPFBenchmark.benchmark45(-532.4883288110013,-380.94371600113544,100.0 ) ;
  }

  @Test
  public void test2719() {
    coral.tests.JPFBenchmark.benchmark45(-532.6415569261056,-237.15832471486232,7.899284025315964 ) ;
  }

  @Test
  public void test2720() {
    coral.tests.JPFBenchmark.benchmark45(-532.7048514436789,-241.6244463338176,0 ) ;
  }

  @Test
  public void test2721() {
    coral.tests.JPFBenchmark.benchmark45(-532.9645812867864,-213.80031315757634,74.79778361698031 ) ;
  }

  @Test
  public void test2722() {
    coral.tests.JPFBenchmark.benchmark45(-532.9906981156421,-268.7800204236563,100.0 ) ;
  }

  @Test
  public void test2723() {
    coral.tests.JPFBenchmark.benchmark45(-533.5568194526676,-258.3770381098497,100.0 ) ;
  }

  @Test
  public void test2724() {
    coral.tests.JPFBenchmark.benchmark45(-533.668714519217,-270.79876005392765,8.597677896215373 ) ;
  }

  @Test
  public void test2725() {
    coral.tests.JPFBenchmark.benchmark45(-533.735421054495,-280.28923357750057,100.0 ) ;
  }

  @Test
  public void test2726() {
    coral.tests.JPFBenchmark.benchmark45(-534.5136476024968,-236.16783589387518,94.32262771909748 ) ;
  }

  @Test
  public void test2727() {
    coral.tests.JPFBenchmark.benchmark45(-534.6049051175877,-234.58632303496174,58.69017210955579 ) ;
  }

  @Test
  public void test2728() {
    coral.tests.JPFBenchmark.benchmark45(-534.6741463665287,-253.99243773594833,6.715173098384341 ) ;
  }

  @Test
  public void test2729() {
    coral.tests.JPFBenchmark.benchmark45(-534.9550569085281,-231.56102593498616,21.060702865627363 ) ;
  }

  @Test
  public void test2730() {
    coral.tests.JPFBenchmark.benchmark45(-535.0211633025781,-271.0863083476213,57.43120889981256 ) ;
  }

  @Test
  public void test2731() {
    coral.tests.JPFBenchmark.benchmark45(-535.057363746974,-276.00081404703394,73.99461682876778 ) ;
  }

  @Test
  public void test2732() {
    coral.tests.JPFBenchmark.benchmark45(-535.0680507661579,-242.9771860408125,100.0 ) ;
  }

  @Test
  public void test2733() {
    coral.tests.JPFBenchmark.benchmark45(-535.3076190721359,-254.92966480419955,87.76268382306398 ) ;
  }

  @Test
  public void test2734() {
    coral.tests.JPFBenchmark.benchmark45(-535.3244264009094,-273.8589467580077,44.497027060412734 ) ;
  }

  @Test
  public void test2735() {
    coral.tests.JPFBenchmark.benchmark45(-535.4728938712757,-226.0579964411262,99.41870853896694 ) ;
  }

  @Test
  public void test2736() {
    coral.tests.JPFBenchmark.benchmark45(-535.5414309034122,-258.6551431256105,100.0 ) ;
  }

  @Test
  public void test2737() {
    coral.tests.JPFBenchmark.benchmark45(-535.6189439522497,-246.64535399564377,100.0 ) ;
  }

  @Test
  public void test2738() {
    coral.tests.JPFBenchmark.benchmark45(-535.719445067865,-257.84042815715395,100.0 ) ;
  }

  @Test
  public void test2739() {
    coral.tests.JPFBenchmark.benchmark45(-535.9093595735253,-221.90478830917584,100.0 ) ;
  }

  @Test
  public void test2740() {
    coral.tests.JPFBenchmark.benchmark45(-536.0741154436872,-241.1289409513025,80.99719698301942 ) ;
  }

  @Test
  public void test2741() {
    coral.tests.JPFBenchmark.benchmark45(-536.152003289317,-216.91460855866106,100.0 ) ;
  }

  @Test
  public void test2742() {
    coral.tests.JPFBenchmark.benchmark45(-536.2486748245697,-242.97738146844455,84.2219927812738 ) ;
  }

  @Test
  public void test2743() {
    coral.tests.JPFBenchmark.benchmark45(-536.4695460110815,-267.37998823813865,50.140628616181885 ) ;
  }

  @Test
  public void test2744() {
    coral.tests.JPFBenchmark.benchmark45(-536.4844145511149,-273.268767154271,96.5923084849976 ) ;
  }

  @Test
  public void test2745() {
    coral.tests.JPFBenchmark.benchmark45(-536.6054630182208,-228.32203725047617,8.310681160255996 ) ;
  }

  @Test
  public void test2746() {
    coral.tests.JPFBenchmark.benchmark45(-536.7900316356225,-221.4234071956,43.88144220586295 ) ;
  }

  @Test
  public void test2747() {
    coral.tests.JPFBenchmark.benchmark45(-536.8240905345002,-259.29683975081826,40.895343430141565 ) ;
  }

  @Test
  public void test2748() {
    coral.tests.JPFBenchmark.benchmark45(-537.2038749841524,-265.783164541326,22.60057084363862 ) ;
  }

  @Test
  public void test2749() {
    coral.tests.JPFBenchmark.benchmark45(-537.3248650814362,-234.761366331907,30.436102252900668 ) ;
  }

  @Test
  public void test2750() {
    coral.tests.JPFBenchmark.benchmark45(-537.3345700188152,-260.5405715797734,100.0 ) ;
  }

  @Test
  public void test2751() {
    coral.tests.JPFBenchmark.benchmark45(-537.4969795492822,-246.4169373060517,10.580907852827707 ) ;
  }

  @Test
  public void test2752() {
    coral.tests.JPFBenchmark.benchmark45(-537.7186165330208,-283.99814437450914,80.82158360233296 ) ;
  }

  @Test
  public void test2753() {
    coral.tests.JPFBenchmark.benchmark45(-537.8211263122574,-226.67267349830928,100.0 ) ;
  }

  @Test
  public void test2754() {
    coral.tests.JPFBenchmark.benchmark45(-538.0455016784455,-281.0140579233132,27.996480514629354 ) ;
  }

  @Test
  public void test2755() {
    coral.tests.JPFBenchmark.benchmark45(-538.0556687789261,-208.8078348427099,21.747847894188112 ) ;
  }

  @Test
  public void test2756() {
    coral.tests.JPFBenchmark.benchmark45(-538.3296214383873,-225.10103766714488,17.914122820426883 ) ;
  }

  @Test
  public void test2757() {
    coral.tests.JPFBenchmark.benchmark45(-538.4493789685996,-209.64327329979804,22.57781581006661 ) ;
  }

  @Test
  public void test2758() {
    coral.tests.JPFBenchmark.benchmark45(-538.6915235697874,-233.04758424578958,97.1384909219521 ) ;
  }

  @Test
  public void test2759() {
    coral.tests.JPFBenchmark.benchmark45(-538.8272190683471,-235.87545151971162,12.18008630314165 ) ;
  }

  @Test
  public void test2760() {
    coral.tests.JPFBenchmark.benchmark45(-539.020182536163,-232.71583133693986,4.420413243134689 ) ;
  }

  @Test
  public void test2761() {
    coral.tests.JPFBenchmark.benchmark45(-539.0568941189467,-226.4585269783188,41.98748664169963 ) ;
  }

  @Test
  public void test2762() {
    coral.tests.JPFBenchmark.benchmark45(-539.2286172374305,-236.980835142913,39.70165783335213 ) ;
  }

  @Test
  public void test2763() {
    coral.tests.JPFBenchmark.benchmark45(-539.717150456514,-207.87027419893158,100.0 ) ;
  }

  @Test
  public void test2764() {
    coral.tests.JPFBenchmark.benchmark45(-539.7248485660468,-214.00261332965917,78.52791044108739 ) ;
  }

  @Test
  public void test2765() {
    coral.tests.JPFBenchmark.benchmark45(-539.8305480486897,-251.64470825132994,84.10216891058349 ) ;
  }

  @Test
  public void test2766() {
    coral.tests.JPFBenchmark.benchmark45(-539.8715787524103,-224.20770247434766,100.0 ) ;
  }

  @Test
  public void test2767() {
    coral.tests.JPFBenchmark.benchmark45(-540.0134768453308,-231.49785596023136,24.500485629742144 ) ;
  }

  @Test
  public void test2768() {
    coral.tests.JPFBenchmark.benchmark45(-540.0741715092518,-227.28425901839245,94.78618571322819 ) ;
  }

  @Test
  public void test2769() {
    coral.tests.JPFBenchmark.benchmark45(-540.6106184836494,-235.12279033138896,55.07885380930807 ) ;
  }

  @Test
  public void test2770() {
    coral.tests.JPFBenchmark.benchmark45(-541.3356315616862,-241.2068486817333,68.00593779207114 ) ;
  }

  @Test
  public void test2771() {
    coral.tests.JPFBenchmark.benchmark45(-541.5635597690068,-226.42485701025996,61.52587234872797 ) ;
  }

  @Test
  public void test2772() {
    coral.tests.JPFBenchmark.benchmark45(-541.8846086104301,-232.08446071738877,4.0239623067254655 ) ;
  }

  @Test
  public void test2773() {
    coral.tests.JPFBenchmark.benchmark45(-542.3606659381196,-214.71905747104051,10.53756566813495 ) ;
  }

  @Test
  public void test2774() {
    coral.tests.JPFBenchmark.benchmark45(-542.5303380760548,-225.68509743544442,51.03764945958682 ) ;
  }

  @Test
  public void test2775() {
    coral.tests.JPFBenchmark.benchmark45(-542.8850722254324,-207.37577459650694,100.0 ) ;
  }

  @Test
  public void test2776() {
    coral.tests.JPFBenchmark.benchmark45(-542.9463832652328,-230.57512536037916,24.98500776447618 ) ;
  }

  @Test
  public void test2777() {
    coral.tests.JPFBenchmark.benchmark45(-543.2762837258589,-205.6672186069406,3.462391596589171 ) ;
  }

  @Test
  public void test2778() {
    coral.tests.JPFBenchmark.benchmark45(-543.422039033161,-203.57770790893423,2.230505417277257 ) ;
  }

  @Test
  public void test2779() {
    coral.tests.JPFBenchmark.benchmark45(-543.4492934578851,-210.1232479782688,73.59376084345669 ) ;
  }

  @Test
  public void test2780() {
    coral.tests.JPFBenchmark.benchmark45(-543.6163927893689,-211.7928146646605,100.0 ) ;
  }

  @Test
  public void test2781() {
    coral.tests.JPFBenchmark.benchmark45(-543.8004154397315,-207.73815791161104,58.79550673037119 ) ;
  }

  @Test
  public void test2782() {
    coral.tests.JPFBenchmark.benchmark45(-543.8170828713386,-233.20635946538331,76.76844248045117 ) ;
  }

  @Test
  public void test2783() {
    coral.tests.JPFBenchmark.benchmark45(-543.8798855016075,-260.7071049896348,99.62457061443618 ) ;
  }

  @Test
  public void test2784() {
    coral.tests.JPFBenchmark.benchmark45(-544.1305816810808,-227.39083615034718,35.642821050263024 ) ;
  }

  @Test
  public void test2785() {
    coral.tests.JPFBenchmark.benchmark45(-544.1419720777951,-206.50432499235444,61.96386526039143 ) ;
  }

  @Test
  public void test2786() {
    coral.tests.JPFBenchmark.benchmark45(-544.1896156830853,-213.33808565896118,37.12011213131231 ) ;
  }

  @Test
  public void test2787() {
    coral.tests.JPFBenchmark.benchmark45(-544.3943998631099,-227.7075686697418,39.86962775246667 ) ;
  }

  @Test
  public void test2788() {
    coral.tests.JPFBenchmark.benchmark45(-544.4394150242144,-264.7898206806657,80.43539754727826 ) ;
  }

  @Test
  public void test2789() {
    coral.tests.JPFBenchmark.benchmark45(-544.6669253351683,-211.71756553851628,21.505679892267054 ) ;
  }

  @Test
  public void test2790() {
    coral.tests.JPFBenchmark.benchmark45(-544.8249628442269,-203.5795366046821,26.907116476898878 ) ;
  }

  @Test
  public void test2791() {
    coral.tests.JPFBenchmark.benchmark45(-544.8605253509772,-210.67654368979893,47.518155869412226 ) ;
  }

  @Test
  public void test2792() {
    coral.tests.JPFBenchmark.benchmark45(-545.1260268610642,-231.30721884148156,53.07008372097868 ) ;
  }

  @Test
  public void test2793() {
    coral.tests.JPFBenchmark.benchmark45(-545.3511430681481,-241.2192421304102,16.765811146436533 ) ;
  }

  @Test
  public void test2794() {
    coral.tests.JPFBenchmark.benchmark45(-545.5608563356508,-210.09806649014743,23.77460558665318 ) ;
  }

  @Test
  public void test2795() {
    coral.tests.JPFBenchmark.benchmark45(-545.6376458102046,-202.73603786911758,37.6976751924895 ) ;
  }

  @Test
  public void test2796() {
    coral.tests.JPFBenchmark.benchmark45(-545.6531302401605,-211.42406349820502,87.04192860655579 ) ;
  }

  @Test
  public void test2797() {
    coral.tests.JPFBenchmark.benchmark45(-545.6799999596656,-217.2001851259111,95.73470953307805 ) ;
  }

  @Test
  public void test2798() {
    coral.tests.JPFBenchmark.benchmark45(-545.7778431731897,-225.65905754491712,23.68039114710838 ) ;
  }

  @Test
  public void test2799() {
    coral.tests.JPFBenchmark.benchmark45(-545.7995712301728,-241.64521706051468,87.13965780616013 ) ;
  }

  @Test
  public void test2800() {
    coral.tests.JPFBenchmark.benchmark45(-546.0919945508633,-204.24459293114012,92.62821156104494 ) ;
  }

  @Test
  public void test2801() {
    coral.tests.JPFBenchmark.benchmark45(-546.1649901536418,-220.3260097350418,45.25729983419777 ) ;
  }

  @Test
  public void test2802() {
    coral.tests.JPFBenchmark.benchmark45(-546.3693755236321,-200.32816570218952,46.118757047921775 ) ;
  }

  @Test
  public void test2803() {
    coral.tests.JPFBenchmark.benchmark45(-546.5669799001181,-276.9075039950758,45.82948504041542 ) ;
  }

  @Test
  public void test2804() {
    coral.tests.JPFBenchmark.benchmark45(-546.6335280109602,-222.27986109650263,100.0 ) ;
  }

  @Test
  public void test2805() {
    coral.tests.JPFBenchmark.benchmark45(-546.6700940489297,-217.38727886470065,20.54696345948983 ) ;
  }

  @Test
  public void test2806() {
    coral.tests.JPFBenchmark.benchmark45(-546.7960050549731,-201.63912348017746,100.0 ) ;
  }

  @Test
  public void test2807() {
    coral.tests.JPFBenchmark.benchmark45(-546.7989869898023,-224.61016527057103,51.389896840428065 ) ;
  }

  @Test
  public void test2808() {
    coral.tests.JPFBenchmark.benchmark45(-546.8039937106962,-211.98102950864538,41.983048506250526 ) ;
  }

  @Test
  public void test2809() {
    coral.tests.JPFBenchmark.benchmark45(-546.9827824480205,-226.10752857483644,5.991290872441539 ) ;
  }

  @Test
  public void test2810() {
    coral.tests.JPFBenchmark.benchmark45(-547.2372284706846,-220.64814229951227,11.541124518754316 ) ;
  }

  @Test
  public void test2811() {
    coral.tests.JPFBenchmark.benchmark45(-547.7085864132346,-204.68929106364888,13.101453293733798 ) ;
  }

  @Test
  public void test2812() {
    coral.tests.JPFBenchmark.benchmark45(-548.0862495286934,-206.19624591462104,1.177286754294741 ) ;
  }

  @Test
  public void test2813() {
    coral.tests.JPFBenchmark.benchmark45(-548.2996805728518,-211.21800890527396,55.90058593891118 ) ;
  }

  @Test
  public void test2814() {
    coral.tests.JPFBenchmark.benchmark45(-548.3977919023956,-214.84425016539208,15.40812313585755 ) ;
  }

  @Test
  public void test2815() {
    coral.tests.JPFBenchmark.benchmark45(-548.4885164604043,-218.2955587422143,28.212071622539014 ) ;
  }

  @Test
  public void test2816() {
    coral.tests.JPFBenchmark.benchmark45(-548.5553045960537,-217.897450030091,39.90858816748684 ) ;
  }

  @Test
  public void test2817() {
    coral.tests.JPFBenchmark.benchmark45(-548.863588578027,-206.88248013505043,9.314359739030564 ) ;
  }

  @Test
  public void test2818() {
    coral.tests.JPFBenchmark.benchmark45(-549.1514608735878,-225.86141393676255,66.4601858829634 ) ;
  }

  @Test
  public void test2819() {
    coral.tests.JPFBenchmark.benchmark45(-549.2423732797928,-212.14478130986234,34.34857770816285 ) ;
  }

  @Test
  public void test2820() {
    coral.tests.JPFBenchmark.benchmark45(-549.3694658576271,-326.7556992914701,94.52311920101303 ) ;
  }

  @Test
  public void test2821() {
    coral.tests.JPFBenchmark.benchmark45(-549.4046337710596,-231.19701927334975,25.639187339349306 ) ;
  }

  @Test
  public void test2822() {
    coral.tests.JPFBenchmark.benchmark45(-549.7231701346916,-202.64987722684103,67.66565857678665 ) ;
  }

  @Test
  public void test2823() {
    coral.tests.JPFBenchmark.benchmark45(-550.4286086333018,-206.65982369113146,100.0 ) ;
  }

  @Test
  public void test2824() {
    coral.tests.JPFBenchmark.benchmark45(-550.6466890015885,-219.33390305492028,100.0 ) ;
  }

  @Test
  public void test2825() {
    coral.tests.JPFBenchmark.benchmark45(-550.8381188932648,-227.44036041978862,1.5992988552952454 ) ;
  }

  @Test
  public void test2826() {
    coral.tests.JPFBenchmark.benchmark45(-550.9963208121699,-223.92065830294717,61.75092139966611 ) ;
  }

  @Test
  public void test2827() {
    coral.tests.JPFBenchmark.benchmark45(-551.0375004945132,-252.8957681124384,46.153011010549 ) ;
  }

  @Test
  public void test2828() {
    coral.tests.JPFBenchmark.benchmark45(-551.08396712482,-210.09947777400006,59.35598655688034 ) ;
  }

  @Test
  public void test2829() {
    coral.tests.JPFBenchmark.benchmark45(-551.1224612060616,-230.13971657370283,100.0 ) ;
  }

  @Test
  public void test2830() {
    coral.tests.JPFBenchmark.benchmark45(-551.245572785265,-198.12837695468366,53.803539977251546 ) ;
  }

  @Test
  public void test2831() {
    coral.tests.JPFBenchmark.benchmark45(-551.8680478127196,-201.57630041889428,100.0 ) ;
  }

  @Test
  public void test2832() {
    coral.tests.JPFBenchmark.benchmark45(-552.0587385977867,-243.45257253826338,49.70439084656738 ) ;
  }

  @Test
  public void test2833() {
    coral.tests.JPFBenchmark.benchmark45(-552.1919072689731,-268.19878304248857,14.88380074743074 ) ;
  }

  @Test
  public void test2834() {
    coral.tests.JPFBenchmark.benchmark45(-552.2887475655325,-217.4843404885732,16.445014307182433 ) ;
  }

  @Test
  public void test2835() {
    coral.tests.JPFBenchmark.benchmark45(-552.4849093480747,-203.1049132981694,57.086004264829285 ) ;
  }

  @Test
  public void test2836() {
    coral.tests.JPFBenchmark.benchmark45(-552.5653376445963,-213.32805140501625,100.0 ) ;
  }

  @Test
  public void test2837() {
    coral.tests.JPFBenchmark.benchmark45(-553.0702446113182,-273.9103291410129,59.87120568684304 ) ;
  }

  @Test
  public void test2838() {
    coral.tests.JPFBenchmark.benchmark45(-553.4458543107306,-233.51755829596914,75.71383309356773 ) ;
  }

  @Test
  public void test2839() {
    coral.tests.JPFBenchmark.benchmark45(-553.5296976726863,-197.00608913148906,67.69237878893236 ) ;
  }

  @Test
  public void test2840() {
    coral.tests.JPFBenchmark.benchmark45(-553.5871354440324,-223.48096728107356,36.938303647243515 ) ;
  }

  @Test
  public void test2841() {
    coral.tests.JPFBenchmark.benchmark45(-553.7197262451167,-192.91227544561264,100.0 ) ;
  }

  @Test
  public void test2842() {
    coral.tests.JPFBenchmark.benchmark45(-553.8842733260549,-199.38603377425613,100.0 ) ;
  }

  @Test
  public void test2843() {
    coral.tests.JPFBenchmark.benchmark45(-553.9343081462795,-205.90475848317342,61.917634461587454 ) ;
  }

  @Test
  public void test2844() {
    coral.tests.JPFBenchmark.benchmark45(-553.9398711579788,-196.53163680766977,31.48123304474052 ) ;
  }

  @Test
  public void test2845() {
    coral.tests.JPFBenchmark.benchmark45(-554.0365645717993,-247.71437061826472,0 ) ;
  }

  @Test
  public void test2846() {
    coral.tests.JPFBenchmark.benchmark45(-554.1270684252866,-265.4616507795364,100.0 ) ;
  }

  @Test
  public void test2847() {
    coral.tests.JPFBenchmark.benchmark45(-554.1359381857642,-206.8434713319626,100.0 ) ;
  }

  @Test
  public void test2848() {
    coral.tests.JPFBenchmark.benchmark45(-554.5070316987525,-208.33511452974903,100.0 ) ;
  }

  @Test
  public void test2849() {
    coral.tests.JPFBenchmark.benchmark45(-554.6051678210835,-193.0250326235186,100.0 ) ;
  }

  @Test
  public void test2850() {
    coral.tests.JPFBenchmark.benchmark45(-555.6697568360713,-212.36341205150234,1.2022826674916445 ) ;
  }

  @Test
  public void test2851() {
    coral.tests.JPFBenchmark.benchmark45(-556.4365097954238,-198.709033035493,1.6883641819639479 ) ;
  }

  @Test
  public void test2852() {
    coral.tests.JPFBenchmark.benchmark45(-556.5999541271389,-190.10421484368214,100.0 ) ;
  }

  @Test
  public void test2853() {
    coral.tests.JPFBenchmark.benchmark45(-556.6395915208116,-230.76277311721486,100.0 ) ;
  }

  @Test
  public void test2854() {
    coral.tests.JPFBenchmark.benchmark45(-556.9497076166756,-190.49767851739222,66.58128899991033 ) ;
  }

  @Test
  public void test2855() {
    coral.tests.JPFBenchmark.benchmark45(-557.284884874254,-203.60147625737815,89.93707651363994 ) ;
  }

  @Test
  public void test2856() {
    coral.tests.JPFBenchmark.benchmark45(-557.3463942169291,-326.7207325950726,100.0 ) ;
  }

  @Test
  public void test2857() {
    coral.tests.JPFBenchmark.benchmark45(-557.5612297455131,-201.11085719644595,17.884009001422683 ) ;
  }

  @Test
  public void test2858() {
    coral.tests.JPFBenchmark.benchmark45(-557.8728656036398,-262.78464183251964,29.16323383745252 ) ;
  }

  @Test
  public void test2859() {
    coral.tests.JPFBenchmark.benchmark45(-558.0902237285841,-212.4588602839051,15.958888018790063 ) ;
  }

  @Test
  public void test2860() {
    coral.tests.JPFBenchmark.benchmark45(-558.1122362359592,-199.27265610712686,100.0 ) ;
  }

  @Test
  public void test2861() {
    coral.tests.JPFBenchmark.benchmark45(-558.133259371407,-230.12244528825556,67.47295326682124 ) ;
  }

  @Test
  public void test2862() {
    coral.tests.JPFBenchmark.benchmark45(-558.2944531509246,-198.76801513661565,73.19558644036596 ) ;
  }

  @Test
  public void test2863() {
    coral.tests.JPFBenchmark.benchmark45(-558.3069665481405,-191.70221688906864,100.0 ) ;
  }

  @Test
  public void test2864() {
    coral.tests.JPFBenchmark.benchmark45(-558.5186226708093,-230.2370272757634,99.7625913671111 ) ;
  }

  @Test
  public void test2865() {
    coral.tests.JPFBenchmark.benchmark45(-558.6132498937221,-328.8237691682899,89.28186575274029 ) ;
  }

  @Test
  public void test2866() {
    coral.tests.JPFBenchmark.benchmark45(-558.8829780616599,-236.34965359126429,100.0 ) ;
  }

  @Test
  public void test2867() {
    coral.tests.JPFBenchmark.benchmark45(-559.313460787908,-198.53931761956838,39.737419143184155 ) ;
  }

  @Test
  public void test2868() {
    coral.tests.JPFBenchmark.benchmark45(-559.4100514679379,-198.94148006283893,13.81033722333629 ) ;
  }

  @Test
  public void test2869() {
    coral.tests.JPFBenchmark.benchmark45(-559.8338128839628,-194.95059665236678,79.57757887673424 ) ;
  }

  @Test
  public void test2870() {
    coral.tests.JPFBenchmark.benchmark45(-560.165535017793,-222.8386789495156,54.630476779164894 ) ;
  }

  @Test
  public void test2871() {
    coral.tests.JPFBenchmark.benchmark45(-560.2470439059662,-193.62611279444184,55.40887963703554 ) ;
  }

  @Test
  public void test2872() {
    coral.tests.JPFBenchmark.benchmark45(-560.2995850015592,-294.3785703550388,52.95585331372965 ) ;
  }

  @Test
  public void test2873() {
    coral.tests.JPFBenchmark.benchmark45(-561.2656143926791,-199.6030976859484,66.1164882198224 ) ;
  }

  @Test
  public void test2874() {
    coral.tests.JPFBenchmark.benchmark45(-561.6285809975285,-212.64552830128002,84.43780585920672 ) ;
  }

  @Test
  public void test2875() {
    coral.tests.JPFBenchmark.benchmark45(-561.7434297990181,-206.85132180821907,56.067143454905874 ) ;
  }

  @Test
  public void test2876() {
    coral.tests.JPFBenchmark.benchmark45(-561.7476918556747,-193.26032290523736,3.3075356630278776 ) ;
  }

  @Test
  public void test2877() {
    coral.tests.JPFBenchmark.benchmark45(-561.7497988338232,-197.18245852337367,91.392088002988 ) ;
  }

  @Test
  public void test2878() {
    coral.tests.JPFBenchmark.benchmark45(-561.8363323029346,-193.95054489156828,30.272717529204726 ) ;
  }

  @Test
  public void test2879() {
    coral.tests.JPFBenchmark.benchmark45(-561.8785103574123,-236.9066831187917,24.181504127908426 ) ;
  }

  @Test
  public void test2880() {
    coral.tests.JPFBenchmark.benchmark45(-561.943515947606,-291.62259556375784,97.02758360165075 ) ;
  }

  @Test
  public void test2881() {
    coral.tests.JPFBenchmark.benchmark45(-562.303092699948,-190.8657084081855,5.0209718414224085 ) ;
  }

  @Test
  public void test2882() {
    coral.tests.JPFBenchmark.benchmark45(-562.6216741780048,-209.32851872134896,34.27906134707234 ) ;
  }

  @Test
  public void test2883() {
    coral.tests.JPFBenchmark.benchmark45(-562.84943151493,-188.37614457549842,100.0 ) ;
  }

  @Test
  public void test2884() {
    coral.tests.JPFBenchmark.benchmark45(-562.9590271398683,-200.62818376285713,3.601274906090276 ) ;
  }

  @Test
  public void test2885() {
    coral.tests.JPFBenchmark.benchmark45(-563.0362887889958,-251.7575941129127,94.59381654410907 ) ;
  }

  @Test
  public void test2886() {
    coral.tests.JPFBenchmark.benchmark45(-563.0670064373934,-259.4688247031145,13.282668190427557 ) ;
  }

  @Test
  public void test2887() {
    coral.tests.JPFBenchmark.benchmark45(-563.3244113453437,-205.2565568300651,73.73622054329385 ) ;
  }

  @Test
  public void test2888() {
    coral.tests.JPFBenchmark.benchmark45(-563.4298596955001,-214.95040564613714,14.364097092851452 ) ;
  }

  @Test
  public void test2889() {
    coral.tests.JPFBenchmark.benchmark45(-564.1280121819727,-195.73960375829503,56.94741172866526 ) ;
  }

  @Test
  public void test2890() {
    coral.tests.JPFBenchmark.benchmark45(-564.2330291322721,-327.24765791922437,89.30230083077711 ) ;
  }

  @Test
  public void test2891() {
    coral.tests.JPFBenchmark.benchmark45(-564.3976430218341,-190.64508618027355,77.75264036545761 ) ;
  }

  @Test
  public void test2892() {
    coral.tests.JPFBenchmark.benchmark45(-564.8236325150095,-271.66896517190156,60.39250586203676 ) ;
  }

  @Test
  public void test2893() {
    coral.tests.JPFBenchmark.benchmark45(-564.9768132994827,-199.81875771811306,28.30372110792817 ) ;
  }

  @Test
  public void test2894() {
    coral.tests.JPFBenchmark.benchmark45(-565.0811454326335,-239.83180692543877,66.98489823213706 ) ;
  }

  @Test
  public void test2895() {
    coral.tests.JPFBenchmark.benchmark45(-565.1772331042274,-188.2148223125016,76.14137695599567 ) ;
  }

  @Test
  public void test2896() {
    coral.tests.JPFBenchmark.benchmark45(-565.3142121356979,-202.7137599689893,99.88654283862468 ) ;
  }

  @Test
  public void test2897() {
    coral.tests.JPFBenchmark.benchmark45(-565.6612521654658,-204.56885651370104,58.1383157674924 ) ;
  }

  @Test
  public void test2898() {
    coral.tests.JPFBenchmark.benchmark45(-565.969570152295,-238.7476353993374,79.80002891011085 ) ;
  }

  @Test
  public void test2899() {
    coral.tests.JPFBenchmark.benchmark45(-565.9728388998086,-268.34872392513654,100.0 ) ;
  }

  @Test
  public void test2900() {
    coral.tests.JPFBenchmark.benchmark45(-566.2268893742806,-218.58291494729593,74.25691704941033 ) ;
  }

  @Test
  public void test2901() {
    coral.tests.JPFBenchmark.benchmark45(-566.3826995070837,-245.71590533263299,100.0 ) ;
  }

  @Test
  public void test2902() {
    coral.tests.JPFBenchmark.benchmark45(-566.9184644831752,-195.68098638495061,32.12418738060646 ) ;
  }

  @Test
  public void test2903() {
    coral.tests.JPFBenchmark.benchmark45(-567.0507675813789,-183.50582883812174,8.714013600763973 ) ;
  }

  @Test
  public void test2904() {
    coral.tests.JPFBenchmark.benchmark45(-567.2585363077668,-179.06562988192354,100.0 ) ;
  }

  @Test
  public void test2905() {
    coral.tests.JPFBenchmark.benchmark45(-567.5286922421183,-186.20359311361713,64.11970983162817 ) ;
  }

  @Test
  public void test2906() {
    coral.tests.JPFBenchmark.benchmark45(-567.5698244560314,-212.21449246833356,100.0 ) ;
  }

  @Test
  public void test2907() {
    coral.tests.JPFBenchmark.benchmark45(-567.6240032801687,-192.17220249559813,54.0286396614849 ) ;
  }

  @Test
  public void test2908() {
    coral.tests.JPFBenchmark.benchmark45(-567.9157580796092,-245.43644893144864,100.0 ) ;
  }

  @Test
  public void test2909() {
    coral.tests.JPFBenchmark.benchmark45(-568.0999808186268,-195.18503096402554,35.56729270462887 ) ;
  }

  @Test
  public void test2910() {
    coral.tests.JPFBenchmark.benchmark45(-568.2285140215679,-216.5880162489799,15.62499050176065 ) ;
  }

  @Test
  public void test2911() {
    coral.tests.JPFBenchmark.benchmark45(-568.2991606458465,-178.45627779853976,74.9166085568057 ) ;
  }

  @Test
  public void test2912() {
    coral.tests.JPFBenchmark.benchmark45(-568.4397610901179,-187.65793192966143,53.11280615811461 ) ;
  }

  @Test
  public void test2913() {
    coral.tests.JPFBenchmark.benchmark45(-568.6192708039274,-199.701236568883,100.0 ) ;
  }

  @Test
  public void test2914() {
    coral.tests.JPFBenchmark.benchmark45(-568.8602631742976,-196.81670477426138,100.0 ) ;
  }

  @Test
  public void test2915() {
    coral.tests.JPFBenchmark.benchmark45(-569.1823620051499,-227.14876857464816,27.092942073486782 ) ;
  }

  @Test
  public void test2916() {
    coral.tests.JPFBenchmark.benchmark45(-569.3042575790605,-219.71201908525674,99.74544687408462 ) ;
  }

  @Test
  public void test2917() {
    coral.tests.JPFBenchmark.benchmark45(-569.6805354518393,-183.1926801529139,72.17722969754774 ) ;
  }

  @Test
  public void test2918() {
    coral.tests.JPFBenchmark.benchmark45(-569.6825464329414,-194.39958042370577,23.436048244231714 ) ;
  }

  @Test
  public void test2919() {
    coral.tests.JPFBenchmark.benchmark45(-569.9306924581894,-196.91272113262528,81.10485887153311 ) ;
  }

  @Test
  public void test2920() {
    coral.tests.JPFBenchmark.benchmark45(-570.0946100055946,-185.3210338608062,96.40638951797987 ) ;
  }

  @Test
  public void test2921() {
    coral.tests.JPFBenchmark.benchmark45(-570.1977072830433,-206.3911348678535,28.69413498825452 ) ;
  }

  @Test
  public void test2922() {
    coral.tests.JPFBenchmark.benchmark45(-570.3540624349057,-222.3820224043716,67.81157638629281 ) ;
  }

  @Test
  public void test2923() {
    coral.tests.JPFBenchmark.benchmark45(-570.4841087264475,-251.6749229613704,19.222496807374043 ) ;
  }

  @Test
  public void test2924() {
    coral.tests.JPFBenchmark.benchmark45(-570.7740922927273,-221.84600620029534,46.99681135471434 ) ;
  }

  @Test
  public void test2925() {
    coral.tests.JPFBenchmark.benchmark45(-570.8006081879561,-188.61353197787247,81.26296129388584 ) ;
  }

  @Test
  public void test2926() {
    coral.tests.JPFBenchmark.benchmark45(-570.9103886542944,-208.67918618520036,54.58511030460313 ) ;
  }

  @Test
  public void test2927() {
    coral.tests.JPFBenchmark.benchmark45(-571.910436302216,-275.6066222292822,77.04366986643001 ) ;
  }

  @Test
  public void test2928() {
    coral.tests.JPFBenchmark.benchmark45(-572.9586514172747,-218.86718704164554,22.0209856834043 ) ;
  }

  @Test
  public void test2929() {
    coral.tests.JPFBenchmark.benchmark45(-573.0434527576851,-188.15845130071372,59.25199605774358 ) ;
  }

  @Test
  public void test2930() {
    coral.tests.JPFBenchmark.benchmark45(-573.0710124415024,-191.86352457022625,100.0 ) ;
  }

  @Test
  public void test2931() {
    coral.tests.JPFBenchmark.benchmark45(-573.2366881033091,-197.5041182759062,41.70779296774381 ) ;
  }

  @Test
  public void test2932() {
    coral.tests.JPFBenchmark.benchmark45(-573.5867570865413,-177.68338408504383,95.97361333737803 ) ;
  }

  @Test
  public void test2933() {
    coral.tests.JPFBenchmark.benchmark45(-573.6701010107209,-195.84730629615197,2.679235407859835 ) ;
  }

  @Test
  public void test2934() {
    coral.tests.JPFBenchmark.benchmark45(-574.7082171739634,-180.04787639175098,100.0 ) ;
  }

  @Test
  public void test2935() {
    coral.tests.JPFBenchmark.benchmark45(-575.2500728572451,-202.57467716922332,0.7541980327386355 ) ;
  }

  @Test
  public void test2936() {
    coral.tests.JPFBenchmark.benchmark45(-575.3302408652874,-196.97410628631508,16.551558472919496 ) ;
  }

  @Test
  public void test2937() {
    coral.tests.JPFBenchmark.benchmark45(-575.3610835221783,-174.83954778038571,6.5827688681069105 ) ;
  }

  @Test
  public void test2938() {
    coral.tests.JPFBenchmark.benchmark45(-576.2881812343668,-277.3411096506429,24.84156408089406 ) ;
  }

  @Test
  public void test2939() {
    coral.tests.JPFBenchmark.benchmark45(-576.7387097418712,-172.02647057881222,32.0958876842993 ) ;
  }

  @Test
  public void test2940() {
    coral.tests.JPFBenchmark.benchmark45(-576.7786423053326,-193.4290117036111,100.0 ) ;
  }

  @Test
  public void test2941() {
    coral.tests.JPFBenchmark.benchmark45(-576.8059128075685,-180.52398518055142,67.59781943840181 ) ;
  }

  @Test
  public void test2942() {
    coral.tests.JPFBenchmark.benchmark45(-576.9017156457916,-170.24918615743758,13.042086402838436 ) ;
  }

  @Test
  public void test2943() {
    coral.tests.JPFBenchmark.benchmark45(-577.5771308994636,-200.27204334647843,18.687537359799066 ) ;
  }

  @Test
  public void test2944() {
    coral.tests.JPFBenchmark.benchmark45(-577.5997623272698,-281.3705177366954,100.0 ) ;
  }

  @Test
  public void test2945() {
    coral.tests.JPFBenchmark.benchmark45(-578.595855147276,-169.6553169558034,100.0 ) ;
  }

  @Test
  public void test2946() {
    coral.tests.JPFBenchmark.benchmark45(-578.6657722651669,-215.76273699140594,66.35001864924058 ) ;
  }

  @Test
  public void test2947() {
    coral.tests.JPFBenchmark.benchmark45(-578.7357967721014,-230.37253398583383,29.481002692877638 ) ;
  }

  @Test
  public void test2948() {
    coral.tests.JPFBenchmark.benchmark45(-578.7890174034062,-168.6657647217398,13.401108947235869 ) ;
  }

  @Test
  public void test2949() {
    coral.tests.JPFBenchmark.benchmark45(-578.8887604902976,-185.3769365332142,36.47385426708688 ) ;
  }

  @Test
  public void test2950() {
    coral.tests.JPFBenchmark.benchmark45(-578.9772560441141,-183.72495970087647,89.69894971479482 ) ;
  }

  @Test
  public void test2951() {
    coral.tests.JPFBenchmark.benchmark45(-579.0492423885357,-187.64251670909823,23.670041475521856 ) ;
  }

  @Test
  public void test2952() {
    coral.tests.JPFBenchmark.benchmark45(-579.0773381562075,-188.80493627526215,20.67419303252281 ) ;
  }

  @Test
  public void test2953() {
    coral.tests.JPFBenchmark.benchmark45(-579.8141847970697,-215.72533828106282,83.73795685771063 ) ;
  }

  @Test
  public void test2954() {
    coral.tests.JPFBenchmark.benchmark45(-579.861293739943,-247.71007989330525,13.882250268344237 ) ;
  }

  @Test
  public void test2955() {
    coral.tests.JPFBenchmark.benchmark45(-580.3531551981808,-243.7817272273814,48.26251500733113 ) ;
  }

  @Test
  public void test2956() {
    coral.tests.JPFBenchmark.benchmark45(-580.6529468767078,-174.04656470746403,49.9135586603434 ) ;
  }

  @Test
  public void test2957() {
    coral.tests.JPFBenchmark.benchmark45(-581.245558587825,-176.40182538052608,100.0 ) ;
  }

  @Test
  public void test2958() {
    coral.tests.JPFBenchmark.benchmark45(-581.4634951034419,-173.9109232755505,64.67874062261515 ) ;
  }

  @Test
  public void test2959() {
    coral.tests.JPFBenchmark.benchmark45(-581.7149049183507,-187.36227528868702,60.06817155165268 ) ;
  }

  @Test
  public void test2960() {
    coral.tests.JPFBenchmark.benchmark45(-581.872031170122,-199.1339704031725,64.84477053752016 ) ;
  }

  @Test
  public void test2961() {
    coral.tests.JPFBenchmark.benchmark45(-581.8827473168706,-255.6379684435369,100.0 ) ;
  }

  @Test
  public void test2962() {
    coral.tests.JPFBenchmark.benchmark45(-582.1598453667146,-186.19747633007012,78.36719803470388 ) ;
  }

  @Test
  public void test2963() {
    coral.tests.JPFBenchmark.benchmark45(-582.9692266546441,-200.04875717625185,23.382334097593386 ) ;
  }

  @Test
  public void test2964() {
    coral.tests.JPFBenchmark.benchmark45(-583.4487155123383,-163.04250486560167,48.91986748686378 ) ;
  }

  @Test
  public void test2965() {
    coral.tests.JPFBenchmark.benchmark45(-583.8297549954596,-167.09060801899167,37.611792319477644 ) ;
  }

  @Test
  public void test2966() {
    coral.tests.JPFBenchmark.benchmark45(-58.42412467911085,-42.68266533729215,0 ) ;
  }

  @Test
  public void test2967() {
    coral.tests.JPFBenchmark.benchmark45(-584.2639697296715,-171.02465279581995,33.440095383102545 ) ;
  }

  @Test
  public void test2968() {
    coral.tests.JPFBenchmark.benchmark45(-584.6173607043776,-173.3936053694113,100.0 ) ;
  }

  @Test
  public void test2969() {
    coral.tests.JPFBenchmark.benchmark45(-584.7014125112582,-173.5473298589095,94.82994371030381 ) ;
  }

  @Test
  public void test2970() {
    coral.tests.JPFBenchmark.benchmark45(-584.9969781795637,-162.62184484240234,48.13232278013457 ) ;
  }

  @Test
  public void test2971() {
    coral.tests.JPFBenchmark.benchmark45(-585.0918140244951,-173.637919295934,22.418232076560216 ) ;
  }

  @Test
  public void test2972() {
    coral.tests.JPFBenchmark.benchmark45(-585.250798425023,-177.53642047767545,3.8596718879608147 ) ;
  }

  @Test
  public void test2973() {
    coral.tests.JPFBenchmark.benchmark45(-585.263528603262,-237.97551191243116,60.86148220393076 ) ;
  }

  @Test
  public void test2974() {
    coral.tests.JPFBenchmark.benchmark45(-585.4535298537722,-172.16481716697484,31.226568408160034 ) ;
  }

  @Test
  public void test2975() {
    coral.tests.JPFBenchmark.benchmark45(-585.5019909358386,-165.58542528237967,23.42098609548671 ) ;
  }

  @Test
  public void test2976() {
    coral.tests.JPFBenchmark.benchmark45(-585.7417048210233,-170.24315565700198,4.247304035575027 ) ;
  }

  @Test
  public void test2977() {
    coral.tests.JPFBenchmark.benchmark45(-585.9607599006426,-185.91944833644393,100.0 ) ;
  }

  @Test
  public void test2978() {
    coral.tests.JPFBenchmark.benchmark45(-585.972541585801,-169.67005234994525,7.463848238323422 ) ;
  }

  @Test
  public void test2979() {
    coral.tests.JPFBenchmark.benchmark45(-586.2755705416721,-203.27122811950414,16.11316379566074 ) ;
  }

  @Test
  public void test2980() {
    coral.tests.JPFBenchmark.benchmark45(-587.5179164126329,-235.18867422672625,7.023627530210447 ) ;
  }

  @Test
  public void test2981() {
    coral.tests.JPFBenchmark.benchmark45(-587.9903518424384,-174.07950669942747,27.34208050349085 ) ;
  }

  @Test
  public void test2982() {
    coral.tests.JPFBenchmark.benchmark45(-588.2550163812351,-244.5635348166976,71.0599737068651 ) ;
  }

  @Test
  public void test2983() {
    coral.tests.JPFBenchmark.benchmark45(-589.019975878946,-229.99090870540772,74.90682294321061 ) ;
  }

  @Test
  public void test2984() {
    coral.tests.JPFBenchmark.benchmark45(-589.9620761076211,-191.19406013846603,100.0 ) ;
  }

  @Test
  public void test2985() {
    coral.tests.JPFBenchmark.benchmark45(-590.5196846709619,-193.50818168833987,8.33753569497486 ) ;
  }

  @Test
  public void test2986() {
    coral.tests.JPFBenchmark.benchmark45(-590.8479017925553,-223.3859814076587,85.37168184727625 ) ;
  }

  @Test
  public void test2987() {
    coral.tests.JPFBenchmark.benchmark45(-590.910363954433,-167.74870670679553,96.62613384251614 ) ;
  }

  @Test
  public void test2988() {
    coral.tests.JPFBenchmark.benchmark45(-591.3483372012064,-155.42307949249042,20.09396936918175 ) ;
  }

  @Test
  public void test2989() {
    coral.tests.JPFBenchmark.benchmark45(-591.4727924906583,-224.77776760120227,51.09628625040813 ) ;
  }

  @Test
  public void test2990() {
    coral.tests.JPFBenchmark.benchmark45(-591.6041418110046,-154.39585818899542,0 ) ;
  }

  @Test
  public void test2991() {
    coral.tests.JPFBenchmark.benchmark45(-592.1058056737695,-173.35827642460447,12.634588729284573 ) ;
  }

  @Test
  public void test2992() {
    coral.tests.JPFBenchmark.benchmark45(-592.3414742369318,-162.4990965953204,45.917600234698995 ) ;
  }

  @Test
  public void test2993() {
    coral.tests.JPFBenchmark.benchmark45(-592.7952572607384,-171.58139953034046,37.47376225534344 ) ;
  }

  @Test
  public void test2994() {
    coral.tests.JPFBenchmark.benchmark45(-592.8620447105656,-221.08214182298283,81.39766263156721 ) ;
  }

  @Test
  public void test2995() {
    coral.tests.JPFBenchmark.benchmark45(-593.6848171715825,-193.38664287836218,100.0 ) ;
  }

  @Test
  public void test2996() {
    coral.tests.JPFBenchmark.benchmark45(-593.8604937662029,-170.1328559174241,96.81698006837104 ) ;
  }

  @Test
  public void test2997() {
    coral.tests.JPFBenchmark.benchmark45(-593.9531706499904,-225.3675064345563,58.07819878055969 ) ;
  }

  @Test
  public void test2998() {
    coral.tests.JPFBenchmark.benchmark45(-594.0091913137087,-222.4578267665616,59.55680519920102 ) ;
  }

  @Test
  public void test2999() {
    coral.tests.JPFBenchmark.benchmark45(-594.0716073204698,-192.99039547207113,100.0 ) ;
  }

  @Test
  public void test3000() {
    coral.tests.JPFBenchmark.benchmark45(-594.1486047841873,-158.50603260040563,11.263292022183393 ) ;
  }

  @Test
  public void test3001() {
    coral.tests.JPFBenchmark.benchmark45(-594.2400982531675,-174.81941715146576,83.4271465940246 ) ;
  }

  @Test
  public void test3002() {
    coral.tests.JPFBenchmark.benchmark45(-594.3380432855937,-196.469308765544,0.06783372205016747 ) ;
  }

  @Test
  public void test3003() {
    coral.tests.JPFBenchmark.benchmark45(-594.5659320204314,-196.70463912755775,68.05020156296902 ) ;
  }

  @Test
  public void test3004() {
    coral.tests.JPFBenchmark.benchmark45(-595.6265362205678,-183.33557832157595,60.20651612548454 ) ;
  }

  @Test
  public void test3005() {
    coral.tests.JPFBenchmark.benchmark45(-595.733840444158,-166.49240859130387,4.2627035787254925 ) ;
  }

  @Test
  public void test3006() {
    coral.tests.JPFBenchmark.benchmark45(-595.9748640768047,-188.61411312384402,5.841671884294868 ) ;
  }

  @Test
  public void test3007() {
    coral.tests.JPFBenchmark.benchmark45(-596.9560956023467,-184.68350721266395,26.15538986426526 ) ;
  }

  @Test
  public void test3008() {
    coral.tests.JPFBenchmark.benchmark45(-597.6713497119617,-187.23785360594204,71.19265507423114 ) ;
  }

  @Test
  public void test3009() {
    coral.tests.JPFBenchmark.benchmark45(-597.8267653903634,-156.40208540709324,46.250232901923596 ) ;
  }

  @Test
  public void test3010() {
    coral.tests.JPFBenchmark.benchmark45(-597.9176064865696,-189.82400653903343,52.48196748087835 ) ;
  }

  @Test
  public void test3011() {
    coral.tests.JPFBenchmark.benchmark45(-599.0277627015998,-182.8722723365545,36.841013609905914 ) ;
  }

  @Test
  public void test3012() {
    coral.tests.JPFBenchmark.benchmark45(-599.4583107153896,-149.94075289566902,18.08499431092328 ) ;
  }

  @Test
  public void test3013() {
    coral.tests.JPFBenchmark.benchmark45(-601.6932410444464,-181.65144339654432,32.06191251227696 ) ;
  }

  @Test
  public void test3014() {
    coral.tests.JPFBenchmark.benchmark45(-601.8401300491969,-167.77694631958707,41.71653467044044 ) ;
  }

  @Test
  public void test3015() {
    coral.tests.JPFBenchmark.benchmark45(-601.9724553916573,-144.8695894558905,18.345504660217998 ) ;
  }

  @Test
  public void test3016() {
    coral.tests.JPFBenchmark.benchmark45(-602.2224373910066,-161.72741949606478,47.94252796218919 ) ;
  }

  @Test
  public void test3017() {
    coral.tests.JPFBenchmark.benchmark45(-602.752384612749,-223.86605382825365,79.62037732571133 ) ;
  }

  @Test
  public void test3018() {
    coral.tests.JPFBenchmark.benchmark45(-602.9176091578073,-164.8263579605864,31.28545246542072 ) ;
  }

  @Test
  public void test3019() {
    coral.tests.JPFBenchmark.benchmark45(-603.004418138357,-182.78281637967558,14.213561489598831 ) ;
  }

  @Test
  public void test3020() {
    coral.tests.JPFBenchmark.benchmark45(-603.020036754973,-153.37501746675304,52.5566194089495 ) ;
  }

  @Test
  public void test3021() {
    coral.tests.JPFBenchmark.benchmark45(-603.1659138668631,-210.59384038151336,53.05813146567948 ) ;
  }

  @Test
  public void test3022() {
    coral.tests.JPFBenchmark.benchmark45(-604.2596984999344,-141.89397777177143,87.4789607619964 ) ;
  }

  @Test
  public void test3023() {
    coral.tests.JPFBenchmark.benchmark45(-604.2886291931455,-148.18621635912638,15.401049619206788 ) ;
  }

  @Test
  public void test3024() {
    coral.tests.JPFBenchmark.benchmark45(-604.4340170384606,-141.96656222434981,37.8754733965755 ) ;
  }

  @Test
  public void test3025() {
    coral.tests.JPFBenchmark.benchmark45(-604.7180360885591,-145.60923296093614,96.23946408952014 ) ;
  }

  @Test
  public void test3026() {
    coral.tests.JPFBenchmark.benchmark45(-605.1571267004532,-163.432048644924,73.25803856141019 ) ;
  }

  @Test
  public void test3027() {
    coral.tests.JPFBenchmark.benchmark45(-605.2291301483855,-154.68095037645296,94.57352896287404 ) ;
  }

  @Test
  public void test3028() {
    coral.tests.JPFBenchmark.benchmark45(-605.4169314958707,-162.31464924761468,21.10416914635745 ) ;
  }

  @Test
  public void test3029() {
    coral.tests.JPFBenchmark.benchmark45(-605.460723037434,-211.8505548148381,12.417830787928395 ) ;
  }

  @Test
  public void test3030() {
    coral.tests.JPFBenchmark.benchmark45(-606.21867932831,-199.98211150893712,100.0 ) ;
  }

  @Test
  public void test3031() {
    coral.tests.JPFBenchmark.benchmark45(-606.8037113829384,-151.75257103163565,10.412993013404218 ) ;
  }

  @Test
  public void test3032() {
    coral.tests.JPFBenchmark.benchmark45(-606.8643896114538,-157.21094608492902,70.85265891908745 ) ;
  }

  @Test
  public void test3033() {
    coral.tests.JPFBenchmark.benchmark45(-607.0161464956415,-206.21534481487595,100.0 ) ;
  }

  @Test
  public void test3034() {
    coral.tests.JPFBenchmark.benchmark45(-607.1496976626992,-186.32819236344864,44.95355814538712 ) ;
  }

  @Test
  public void test3035() {
    coral.tests.JPFBenchmark.benchmark45(-607.1599786206825,-151.97234037767885,28.926859519579466 ) ;
  }

  @Test
  public void test3036() {
    coral.tests.JPFBenchmark.benchmark45(-607.2348302086241,-187.81492927139317,37.49901722050117 ) ;
  }

  @Test
  public void test3037() {
    coral.tests.JPFBenchmark.benchmark45(-607.5356159063363,-167.9729217904696,13.538259322156136 ) ;
  }

  @Test
  public void test3038() {
    coral.tests.JPFBenchmark.benchmark45(-607.5924302749206,-168.77559575273855,49.669658729150854 ) ;
  }

  @Test
  public void test3039() {
    coral.tests.JPFBenchmark.benchmark45(-607.6431062318806,-170.05412851210968,100.0 ) ;
  }

  @Test
  public void test3040() {
    coral.tests.JPFBenchmark.benchmark45(-607.8633830699408,-168.65941457904063,20.115651984305856 ) ;
  }

  @Test
  public void test3041() {
    coral.tests.JPFBenchmark.benchmark45(-607.9240574090194,-138.82275800458524,63.2005815142507 ) ;
  }

  @Test
  public void test3042() {
    coral.tests.JPFBenchmark.benchmark45(-608.1671812296273,-159.95797063414764,79.95177600142534 ) ;
  }

  @Test
  public void test3043() {
    coral.tests.JPFBenchmark.benchmark45(-608.3173226446987,-163.7363920855689,3.629059349904651 ) ;
  }

  @Test
  public void test3044() {
    coral.tests.JPFBenchmark.benchmark45(-608.4067346976492,-152.04091315997042,15.73205038437235 ) ;
  }

  @Test
  public void test3045() {
    coral.tests.JPFBenchmark.benchmark45(-608.4099730458319,-180.65763301027596,92.0932312184041 ) ;
  }

  @Test
  public void test3046() {
    coral.tests.JPFBenchmark.benchmark45(-608.4364590038226,-163.82791003768187,20.564287939019437 ) ;
  }

  @Test
  public void test3047() {
    coral.tests.JPFBenchmark.benchmark45(-608.4372965293747,-139.73401820293535,87.49081466149505 ) ;
  }

  @Test
  public void test3048() {
    coral.tests.JPFBenchmark.benchmark45(-609.2258269183521,-185.67540055381343,89.15273180042351 ) ;
  }

  @Test
  public void test3049() {
    coral.tests.JPFBenchmark.benchmark45(-609.2899557764484,-145.07334090404976,84.7696627457062 ) ;
  }

  @Test
  public void test3050() {
    coral.tests.JPFBenchmark.benchmark45(-609.6409357943134,-184.60592457193633,100.0 ) ;
  }

  @Test
  public void test3051() {
    coral.tests.JPFBenchmark.benchmark45(-609.6431708587851,-154.28738494815832,76.5270508802721 ) ;
  }

  @Test
  public void test3052() {
    coral.tests.JPFBenchmark.benchmark45(-609.8156122798883,-145.251145580609,50.571116168350045 ) ;
  }

  @Test
  public void test3053() {
    coral.tests.JPFBenchmark.benchmark45(-610.1511262062255,-168.8188324961786,23.735070320274573 ) ;
  }

  @Test
  public void test3054() {
    coral.tests.JPFBenchmark.benchmark45(-610.712494810586,-142.85860342439557,24.104327549048676 ) ;
  }

  @Test
  public void test3055() {
    coral.tests.JPFBenchmark.benchmark45(-611.3150445924111,-147.85738673023207,43.218287325529104 ) ;
  }

  @Test
  public void test3056() {
    coral.tests.JPFBenchmark.benchmark45(-611.5708558859703,-190.366888703842,56.622747137649846 ) ;
  }

  @Test
  public void test3057() {
    coral.tests.JPFBenchmark.benchmark45(-611.6806184264549,-207.1876006787557,12.208799186995762 ) ;
  }

  @Test
  public void test3058() {
    coral.tests.JPFBenchmark.benchmark45(-611.8034667072629,-165.2337645399823,49.11691843345366 ) ;
  }

  @Test
  public void test3059() {
    coral.tests.JPFBenchmark.benchmark45(-612.0388229661269,-166.80558053073878,100.0 ) ;
  }

  @Test
  public void test3060() {
    coral.tests.JPFBenchmark.benchmark45(-612.2606090013086,-174.14072922803655,55.70234332949951 ) ;
  }

  @Test
  public void test3061() {
    coral.tests.JPFBenchmark.benchmark45(-612.6413955986264,-181.11013366631624,100.0 ) ;
  }

  @Test
  public void test3062() {
    coral.tests.JPFBenchmark.benchmark45(-612.6657922590967,-150.53687267824762,100.0 ) ;
  }

  @Test
  public void test3063() {
    coral.tests.JPFBenchmark.benchmark45(-613.7513634388881,-152.5686302853177,22.165536738575838 ) ;
  }

  @Test
  public void test3064() {
    coral.tests.JPFBenchmark.benchmark45(-613.9338089475453,-196.98774074806727,90.71551242283576 ) ;
  }

  @Test
  public void test3065() {
    coral.tests.JPFBenchmark.benchmark45(-615.1328224744746,-135.68585919048533,26.09091888219288 ) ;
  }

  @Test
  public void test3066() {
    coral.tests.JPFBenchmark.benchmark45(-615.3893986303354,-135.21170264092683,100.0 ) ;
  }

  @Test
  public void test3067() {
    coral.tests.JPFBenchmark.benchmark45(-615.7437807617206,-159.09917467953284,63.88415018051472 ) ;
  }

  @Test
  public void test3068() {
    coral.tests.JPFBenchmark.benchmark45(-616.6843391146331,-141.58231027853026,78.06368921039402 ) ;
  }

  @Test
  public void test3069() {
    coral.tests.JPFBenchmark.benchmark45(-616.7015627956022,-131.48563879667694,56.0931417419844 ) ;
  }

  @Test
  public void test3070() {
    coral.tests.JPFBenchmark.benchmark45(-616.9911494583322,-218.97631311738212,86.61715490233911 ) ;
  }

  @Test
  public void test3071() {
    coral.tests.JPFBenchmark.benchmark45(-617.0781169499287,-177.02461109568387,59.01353217763429 ) ;
  }

  @Test
  public void test3072() {
    coral.tests.JPFBenchmark.benchmark45(-617.1602760317827,-169.24189197507258,100.0 ) ;
  }

  @Test
  public void test3073() {
    coral.tests.JPFBenchmark.benchmark45(-617.1895229048698,-130.38118729432392,16.87164980046522 ) ;
  }

  @Test
  public void test3074() {
    coral.tests.JPFBenchmark.benchmark45(-617.2346700228178,-154.7288115631582,57.47171841767522 ) ;
  }

  @Test
  public void test3075() {
    coral.tests.JPFBenchmark.benchmark45(-617.9773083161123,-143.36401054902097,18.352662780029917 ) ;
  }

  @Test
  public void test3076() {
    coral.tests.JPFBenchmark.benchmark45(-618.103328694678,-175.347761241535,24.818859825895913 ) ;
  }

  @Test
  public void test3077() {
    coral.tests.JPFBenchmark.benchmark45(-619.3743141199477,-162.81060267021394,99.4032437216348 ) ;
  }

  @Test
  public void test3078() {
    coral.tests.JPFBenchmark.benchmark45(-619.6398472121389,-177.88524413682742,20.790813943324565 ) ;
  }

  @Test
  public void test3079() {
    coral.tests.JPFBenchmark.benchmark45(-619.8862813133076,-168.81289176359255,20.64220979770397 ) ;
  }

  @Test
  public void test3080() {
    coral.tests.JPFBenchmark.benchmark45(-620.070875707512,-166.56495465928623,100.0 ) ;
  }

  @Test
  public void test3081() {
    coral.tests.JPFBenchmark.benchmark45(-621.2439391689315,-163.87239497250897,91.72819170380072 ) ;
  }

  @Test
  public void test3082() {
    coral.tests.JPFBenchmark.benchmark45(-621.381176448886,-157.55726384612046,100.0 ) ;
  }

  @Test
  public void test3083() {
    coral.tests.JPFBenchmark.benchmark45(-621.8170889891678,-162.6127660192401,67.56056802429106 ) ;
  }

  @Test
  public void test3084() {
    coral.tests.JPFBenchmark.benchmark45(-622.9258521161034,-168.37241237524174,70.19188238833217 ) ;
  }

  @Test
  public void test3085() {
    coral.tests.JPFBenchmark.benchmark45(-623.6849235966828,-185.90365010648335,100.0 ) ;
  }

  @Test
  public void test3086() {
    coral.tests.JPFBenchmark.benchmark45(-623.7315499347081,-166.19646189774065,5.013627863205826 ) ;
  }

  @Test
  public void test3087() {
    coral.tests.JPFBenchmark.benchmark45(-623.9424234551751,-140.94043703376133,66.36535409513283 ) ;
  }

  @Test
  public void test3088() {
    coral.tests.JPFBenchmark.benchmark45(-624.1249323447528,-168.0877279213269,32.49896603800971 ) ;
  }

  @Test
  public void test3089() {
    coral.tests.JPFBenchmark.benchmark45(-624.2138288129753,-195.0865753848894,82.32746360235393 ) ;
  }

  @Test
  public void test3090() {
    coral.tests.JPFBenchmark.benchmark45(-625.1981707062887,-179.47915973352266,36.06540449614607 ) ;
  }

  @Test
  public void test3091() {
    coral.tests.JPFBenchmark.benchmark45(-625.2781280466671,-195.57861432557058,4.852540144682507 ) ;
  }

  @Test
  public void test3092() {
    coral.tests.JPFBenchmark.benchmark45(-625.2899033308679,-120.80235938666782,68.01984078240886 ) ;
  }

  @Test
  public void test3093() {
    coral.tests.JPFBenchmark.benchmark45(-625.6666644052872,-159.36814469752636,34.18202923058317 ) ;
  }

  @Test
  public void test3094() {
    coral.tests.JPFBenchmark.benchmark45(-625.8691262495357,-124.67880434667717,57.042203544630354 ) ;
  }

  @Test
  public void test3095() {
    coral.tests.JPFBenchmark.benchmark45(-625.881697996502,-165.0686936803026,100.0 ) ;
  }

  @Test
  public void test3096() {
    coral.tests.JPFBenchmark.benchmark45(-626.2437967834035,-199.17124330587257,100.0 ) ;
  }

  @Test
  public void test3097() {
    coral.tests.JPFBenchmark.benchmark45(-626.7634023774863,-122.38463632236936,20.236211122587605 ) ;
  }

  @Test
  public void test3098() {
    coral.tests.JPFBenchmark.benchmark45(-626.8656188670009,-148.12177125923563,93.58579502368698 ) ;
  }

  @Test
  public void test3099() {
    coral.tests.JPFBenchmark.benchmark45(-627.3074276631801,-233.7983030575221,78.6660895742366 ) ;
  }

  @Test
  public void test3100() {
    coral.tests.JPFBenchmark.benchmark45(-627.6181528921311,-170.67657469950694,58.42939308081225 ) ;
  }

  @Test
  public void test3101() {
    coral.tests.JPFBenchmark.benchmark45(-627.8853614784609,-144.90424451548225,100.0 ) ;
  }

  @Test
  public void test3102() {
    coral.tests.JPFBenchmark.benchmark45(-629.5599899830094,-138.7558205777532,100.0 ) ;
  }

  @Test
  public void test3103() {
    coral.tests.JPFBenchmark.benchmark45(-629.6591422509799,-145.16020785385922,56.515522530334806 ) ;
  }

  @Test
  public void test3104() {
    coral.tests.JPFBenchmark.benchmark45(-629.7658549267828,-176.13444360525176,76.777499053441 ) ;
  }

  @Test
  public void test3105() {
    coral.tests.JPFBenchmark.benchmark45(-629.7883363202953,-143.16615681019218,100.0 ) ;
  }

  @Test
  public void test3106() {
    coral.tests.JPFBenchmark.benchmark45(-630.2395669937297,-172.4009221525566,46.75350693315979 ) ;
  }

  @Test
  public void test3107() {
    coral.tests.JPFBenchmark.benchmark45(-630.5484756210593,-138.3442728261722,92.43210565564524 ) ;
  }

  @Test
  public void test3108() {
    coral.tests.JPFBenchmark.benchmark45(-631.054064187667,-123.7995752640553,73.08043144024862 ) ;
  }

  @Test
  public void test3109() {
    coral.tests.JPFBenchmark.benchmark45(-631.8882696567251,-187.92310985618872,100.0 ) ;
  }

  @Test
  public void test3110() {
    coral.tests.JPFBenchmark.benchmark45(-632.3578387269508,-126.68844133776003,23.33318297076876 ) ;
  }

  @Test
  public void test3111() {
    coral.tests.JPFBenchmark.benchmark45(-632.5850607155053,-169.56125418362217,100.0 ) ;
  }

  @Test
  public void test3112() {
    coral.tests.JPFBenchmark.benchmark45(-632.6607649050081,-181.1936770440539,29.39091984233451 ) ;
  }

  @Test
  public void test3113() {
    coral.tests.JPFBenchmark.benchmark45(-633.7961549831683,-112.62580462064466,54.61924140458842 ) ;
  }

  @Test
  public void test3114() {
    coral.tests.JPFBenchmark.benchmark45(-634.431077301452,-170.34884539328164,92.57437562670603 ) ;
  }

  @Test
  public void test3115() {
    coral.tests.JPFBenchmark.benchmark45(-634.9981403320998,-155.9276097065392,52.914283212449675 ) ;
  }

  @Test
  public void test3116() {
    coral.tests.JPFBenchmark.benchmark45(-635.9082955095718,-129.86817378693277,100.0 ) ;
  }

  @Test
  public void test3117() {
    coral.tests.JPFBenchmark.benchmark45(-635.989038845184,-112.50028302588866,86.74500772568919 ) ;
  }

  @Test
  public void test3118() {
    coral.tests.JPFBenchmark.benchmark45(-636.8766235917924,-128.96206055885597,100.0 ) ;
  }

  @Test
  public void test3119() {
    coral.tests.JPFBenchmark.benchmark45(-636.915036962299,-158.34946255756648,100.0 ) ;
  }

  @Test
  public void test3120() {
    coral.tests.JPFBenchmark.benchmark45(-637.4711926979395,-134.45244456085305,100.0 ) ;
  }

  @Test
  public void test3121() {
    coral.tests.JPFBenchmark.benchmark45(-637.5442041594079,-152.5814362215894,55.123042687989226 ) ;
  }

  @Test
  public void test3122() {
    coral.tests.JPFBenchmark.benchmark45(-638.3956740181277,-165.4220781925032,55.76170790483397 ) ;
  }

  @Test
  public void test3123() {
    coral.tests.JPFBenchmark.benchmark45(-638.4119003046966,-155.62886292609875,8.162304336405725 ) ;
  }

  @Test
  public void test3124() {
    coral.tests.JPFBenchmark.benchmark45(-639.5617387562886,-148.93423502983015,94.53299967313052 ) ;
  }

  @Test
  public void test3125() {
    coral.tests.JPFBenchmark.benchmark45(-640.8404420684169,-119.40199187320589,96.20740876124455 ) ;
  }

  @Test
  public void test3126() {
    coral.tests.JPFBenchmark.benchmark45(-641.3365282606574,-150.4207310909269,14.477171868714137 ) ;
  }

  @Test
  public void test3127() {
    coral.tests.JPFBenchmark.benchmark45(-641.4454516533856,-158.3427852827848,31.547659018017754 ) ;
  }

  @Test
  public void test3128() {
    coral.tests.JPFBenchmark.benchmark45(-641.989955513244,-109.80683900101795,0.46294906505642075 ) ;
  }

  @Test
  public void test3129() {
    coral.tests.JPFBenchmark.benchmark45(-642.2839485518155,-115.23972730085666,50.33723087047005 ) ;
  }

  @Test
  public void test3130() {
    coral.tests.JPFBenchmark.benchmark45(-642.6866913352393,-130.7812176662734,80.42680885577096 ) ;
  }

  @Test
  public void test3131() {
    coral.tests.JPFBenchmark.benchmark45(-642.91414700869,-204.55468725584439,11.12553783749415 ) ;
  }

  @Test
  public void test3132() {
    coral.tests.JPFBenchmark.benchmark45(-645.1941860442045,-167.1990289724332,0.3075524535318692 ) ;
  }

  @Test
  public void test3133() {
    coral.tests.JPFBenchmark.benchmark45(-645.3776253684392,-116.52653948217277,21.543368794074084 ) ;
  }

  @Test
  public void test3134() {
    coral.tests.JPFBenchmark.benchmark45(-646.7840648713261,-100.0,92.64687538220727 ) ;
  }

  @Test
  public void test3135() {
    coral.tests.JPFBenchmark.benchmark45(-646.856232594867,-130.91673983470264,92.77641689670793 ) ;
  }

  @Test
  public void test3136() {
    coral.tests.JPFBenchmark.benchmark45(-647.0360275472084,-103.48744431301739,80.53132454673309 ) ;
  }

  @Test
  public void test3137() {
    coral.tests.JPFBenchmark.benchmark45(-647.0547075426998,-120.44067362649668,89.24627719134989 ) ;
  }

  @Test
  public void test3138() {
    coral.tests.JPFBenchmark.benchmark45(-647.3454909785386,-130.62236185293563,100.0 ) ;
  }

  @Test
  public void test3139() {
    coral.tests.JPFBenchmark.benchmark45(-647.6347005389727,-100.0,50.31497043802443 ) ;
  }

  @Test
  public void test3140() {
    coral.tests.JPFBenchmark.benchmark45(-648.7924630883141,-100.0,100.0 ) ;
  }

  @Test
  public void test3141() {
    coral.tests.JPFBenchmark.benchmark45(-649.4399717277684,-100.0,21.33356010669793 ) ;
  }

  @Test
  public void test3142() {
    coral.tests.JPFBenchmark.benchmark45(-649.6304140073669,-100.0,100.0 ) ;
  }

  @Test
  public void test3143() {
    coral.tests.JPFBenchmark.benchmark45(-649.852837278664,-140.0856368138345,95.39717190481204 ) ;
  }

  @Test
  public void test3144() {
    coral.tests.JPFBenchmark.benchmark45(-650.3246544129162,-156.27457449474875,98.74566448150907 ) ;
  }

  @Test
  public void test3145() {
    coral.tests.JPFBenchmark.benchmark45(-650.3645900855724,-98.07990445952987,98.75125664406676 ) ;
  }

  @Test
  public void test3146() {
    coral.tests.JPFBenchmark.benchmark45(-652.0474422694031,-100.0,100.0 ) ;
  }

  @Test
  public void test3147() {
    coral.tests.JPFBenchmark.benchmark45(-652.8449972973773,-100.0,30.019258878215368 ) ;
  }

  @Test
  public void test3148() {
    coral.tests.JPFBenchmark.benchmark45(-653.2157086179294,-101.78138580737811,48.76135676416098 ) ;
  }

  @Test
  public void test3149() {
    coral.tests.JPFBenchmark.benchmark45(-653.628922208619,-100.0,94.93526578193882 ) ;
  }

  @Test
  public void test3150() {
    coral.tests.JPFBenchmark.benchmark45(-654.3285541763981,-110.87835860807124,56.06075401144247 ) ;
  }

  @Test
  public void test3151() {
    coral.tests.JPFBenchmark.benchmark45(-654.8357715716933,-97.99401909211247,79.59621287854992 ) ;
  }

  @Test
  public void test3152() {
    coral.tests.JPFBenchmark.benchmark45(-654.892357370326,-142.35552443266988,100.0 ) ;
  }

  @Test
  public void test3153() {
    coral.tests.JPFBenchmark.benchmark45(-655.4563397380621,-146.7716139609186,38.954203527311705 ) ;
  }

  @Test
  public void test3154() {
    coral.tests.JPFBenchmark.benchmark45(-655.928239289015,-130.293828296987,100.0 ) ;
  }

  @Test
  public void test3155() {
    coral.tests.JPFBenchmark.benchmark45(-655.9806259929795,-91.56119303042365,69.27553710703503 ) ;
  }

  @Test
  public void test3156() {
    coral.tests.JPFBenchmark.benchmark45(-656.2173241758428,-90.74407572541239,30.739433055275725 ) ;
  }

  @Test
  public void test3157() {
    coral.tests.JPFBenchmark.benchmark45(-656.2679421000975,-100.0,49.856974085804296 ) ;
  }

  @Test
  public void test3158() {
    coral.tests.JPFBenchmark.benchmark45(-657.0288603803274,-100.0,100.0 ) ;
  }

  @Test
  public void test3159() {
    coral.tests.JPFBenchmark.benchmark45(-657.2374595832882,-101.5229569680316,88.00291654332219 ) ;
  }

  @Test
  public void test3160() {
    coral.tests.JPFBenchmark.benchmark45(-657.3934712066243,-157.98134117573687,39.381429338840746 ) ;
  }

  @Test
  public void test3161() {
    coral.tests.JPFBenchmark.benchmark45(-657.5012644783222,-92.18551423065865,60.813087775727524 ) ;
  }

  @Test
  public void test3162() {
    coral.tests.JPFBenchmark.benchmark45(-657.6271670922123,-89.31286049800833,80.63369863037673 ) ;
  }

  @Test
  public void test3163() {
    coral.tests.JPFBenchmark.benchmark45(-658.6507880548832,-89.33775789499083,26.109963994339736 ) ;
  }

  @Test
  public void test3164() {
    coral.tests.JPFBenchmark.benchmark45(-658.8146990809057,-118.38972807405028,100.0 ) ;
  }

  @Test
  public void test3165() {
    coral.tests.JPFBenchmark.benchmark45(-659.8405339807305,-100.0,100.0 ) ;
  }

  @Test
  public void test3166() {
    coral.tests.JPFBenchmark.benchmark45(-659.97491415243,-88.71206559222004,67.19647556908043 ) ;
  }

  @Test
  public void test3167() {
    coral.tests.JPFBenchmark.benchmark45(-660.81113004904,-95.13567718537611,42.594627300604714 ) ;
  }

  @Test
  public void test3168() {
    coral.tests.JPFBenchmark.benchmark45(-661.9729844059977,-90.2059123767005,3.0638316746712064 ) ;
  }

  @Test
  public void test3169() {
    coral.tests.JPFBenchmark.benchmark45(-662.4892018455927,-204.49473706064566,100.0 ) ;
  }

  @Test
  public void test3170() {
    coral.tests.JPFBenchmark.benchmark45(-663.1873476324866,-87.15689969606704,63.29822589074706 ) ;
  }

  @Test
  public void test3171() {
    coral.tests.JPFBenchmark.benchmark45(-663.2494505655496,-100.0,89.20400595033593 ) ;
  }

  @Test
  public void test3172() {
    coral.tests.JPFBenchmark.benchmark45(-663.7841793009787,-100.0,100.0 ) ;
  }

  @Test
  public void test3173() {
    coral.tests.JPFBenchmark.benchmark45(-664.2121499467529,-100.0,71.99767653084947 ) ;
  }

  @Test
  public void test3174() {
    coral.tests.JPFBenchmark.benchmark45(-664.4085668142582,-100.0,-100.0 ) ;
  }

  @Test
  public void test3175() {
    coral.tests.JPFBenchmark.benchmark45(-66.53683800151599,-714.2675679993238,89.91485101938645 ) ;
  }

  @Test
  public void test3176() {
    coral.tests.JPFBenchmark.benchmark45(-665.9097184776956,-103.18397986755765,81.34628932731064 ) ;
  }

  @Test
  public void test3177() {
    coral.tests.JPFBenchmark.benchmark45(-667.0030529710391,-79.14218128680099,86.14283745684284 ) ;
  }

  @Test
  public void test3178() {
    coral.tests.JPFBenchmark.benchmark45(-668.1250280419987,-100.0,100.0 ) ;
  }

  @Test
  public void test3179() {
    coral.tests.JPFBenchmark.benchmark45(-668.2189327609527,-100.0,31.683625209986033 ) ;
  }

  @Test
  public void test3180() {
    coral.tests.JPFBenchmark.benchmark45(-668.6485036223108,-100.0,35.92076725128379 ) ;
  }

  @Test
  public void test3181() {
    coral.tests.JPFBenchmark.benchmark45(-669.3650728072366,-94.73422170610736,0 ) ;
  }

  @Test
  public void test3182() {
    coral.tests.JPFBenchmark.benchmark45(-669.7343134036684,-81.30346368450523,95.15213634473639 ) ;
  }

  @Test
  public void test3183() {
    coral.tests.JPFBenchmark.benchmark45(-671.7197374251152,-146.15592262463844,29.485542921426656 ) ;
  }

  @Test
  public void test3184() {
    coral.tests.JPFBenchmark.benchmark45(-672.0006844675587,-100.0,100.0 ) ;
  }

  @Test
  public void test3185() {
    coral.tests.JPFBenchmark.benchmark45(-672.4299982913391,-88.1724907713079,57.08001802759401 ) ;
  }

  @Test
  public void test3186() {
    coral.tests.JPFBenchmark.benchmark45(-673.0107299014611,-100.0,0 ) ;
  }

  @Test
  public void test3187() {
    coral.tests.JPFBenchmark.benchmark45(-674.6776281164607,-100.0,100.0 ) ;
  }

  @Test
  public void test3188() {
    coral.tests.JPFBenchmark.benchmark45(-675.3502914736376,-100.0,100.0 ) ;
  }

  @Test
  public void test3189() {
    coral.tests.JPFBenchmark.benchmark45(-677.9516993288104,-78.66767788160143,38.46427714920455 ) ;
  }

  @Test
  public void test3190() {
    coral.tests.JPFBenchmark.benchmark45(-678.0348806905771,-95.47898189669954,19.575763917390375 ) ;
  }

  @Test
  public void test3191() {
    coral.tests.JPFBenchmark.benchmark45(-678.5521247055382,-100.0,98.21636540099766 ) ;
  }

  @Test
  public void test3192() {
    coral.tests.JPFBenchmark.benchmark45(-679.0351626005556,-88.09595987655268,4.697000514419258 ) ;
  }

  @Test
  public void test3193() {
    coral.tests.JPFBenchmark.benchmark45(-679.5187378027332,-82.14685885523379,27.218040200256 ) ;
  }

  @Test
  public void test3194() {
    coral.tests.JPFBenchmark.benchmark45(-68.07521485733838,-712.2521617142944,26.770918332117446 ) ;
  }

  @Test
  public void test3195() {
    coral.tests.JPFBenchmark.benchmark45(-681.0262987368044,-72.29937316379618,68.68153938193024 ) ;
  }

  @Test
  public void test3196() {
    coral.tests.JPFBenchmark.benchmark45(-683.8710461143856,-93.06098194799513,10.274917202574258 ) ;
  }

  @Test
  public void test3197() {
    coral.tests.JPFBenchmark.benchmark45(-685.78901054888,-77.86602152286775,35.38220846695853 ) ;
  }

  @Test
  public void test3198() {
    coral.tests.JPFBenchmark.benchmark45(-689.4294101200203,-83.93531855810497,23.185560246787546 ) ;
  }

  @Test
  public void test3199() {
    coral.tests.JPFBenchmark.benchmark45(-689.7397752612858,-72.51435821159286,99.34630292477468 ) ;
  }

  @Test
  public void test3200() {
    coral.tests.JPFBenchmark.benchmark45(-692.1651603857198,-74.16128015536891,52.92166959249846 ) ;
  }

  @Test
  public void test3201() {
    coral.tests.JPFBenchmark.benchmark45(-692.974523808776,-93.58148448855302,60.528164744633756 ) ;
  }

  @Test
  public void test3202() {
    coral.tests.JPFBenchmark.benchmark45(-693.1735389369591,-103.86577760117575,60.201933236568436 ) ;
  }

  @Test
  public void test3203() {
    coral.tests.JPFBenchmark.benchmark45(-698.547239265096,-100.0,48.6128184797459 ) ;
  }

  @Test
  public void test3204() {
    coral.tests.JPFBenchmark.benchmark45(-701.7085238012161,-82.11095127838058,32.57761167666243 ) ;
  }

  @Test
  public void test3205() {
    coral.tests.JPFBenchmark.benchmark45(-702.0499341628641,-90.31258513319112,7.452476216619914 ) ;
  }

  @Test
  public void test3206() {
    coral.tests.JPFBenchmark.benchmark45(-703.7299265121378,-56.77881591046694,48.771712033628035 ) ;
  }

  @Test
  public void test3207() {
    coral.tests.JPFBenchmark.benchmark45(-703.7364879382865,-120.8533039541908,91.83187104754688 ) ;
  }

  @Test
  public void test3208() {
    coral.tests.JPFBenchmark.benchmark45(-704.8872875140029,-103.06872721648747,60.99444261270659 ) ;
  }

  @Test
  public void test3209() {
    coral.tests.JPFBenchmark.benchmark45(-711.2033793280939,-44.77585925479779,30.753179650033815 ) ;
  }

  @Test
  public void test3210() {
    coral.tests.JPFBenchmark.benchmark45(-712.0500590265069,-64.24522944467915,19.08131499129749 ) ;
  }

  @Test
  public void test3211() {
    coral.tests.JPFBenchmark.benchmark45(-712.1775307160381,-37.43111605656393,66.33591176795184 ) ;
  }

  @Test
  public void test3212() {
    coral.tests.JPFBenchmark.benchmark45(-712.3251549391001,-98.74556280423731,19.82804278472379 ) ;
  }

  @Test
  public void test3213() {
    coral.tests.JPFBenchmark.benchmark45(-712.4961211685378,-60.47455227338065,44.144318595359934 ) ;
  }

  @Test
  public void test3214() {
    coral.tests.JPFBenchmark.benchmark45(-717.4494767629789,-43.674771694715275,40.004985704078734 ) ;
  }

  @Test
  public void test3215() {
    coral.tests.JPFBenchmark.benchmark45(-719.1006349056186,-143.518345838089,63.2563729929397 ) ;
  }

  @Test
  public void test3216() {
    coral.tests.JPFBenchmark.benchmark45(-72.81571021919888,-673.2868466351812,13.866089496988423 ) ;
  }

  @Test
  public void test3217() {
    coral.tests.JPFBenchmark.benchmark45(-730.7526566126496,-104.97626656848308,41.247242341291326 ) ;
  }

  @Test
  public void test3218() {
    coral.tests.JPFBenchmark.benchmark45(-731.0552462394779,-49.50043756183415,22.02021742649356 ) ;
  }

  @Test
  public void test3219() {
    coral.tests.JPFBenchmark.benchmark45(-73.82270611699262,-675.1528773864604,84.51894005512514 ) ;
  }

  @Test
  public void test3220() {
    coral.tests.JPFBenchmark.benchmark45(-75.01088301378876,-674.3144389343594,38.133106745233846 ) ;
  }

  @Test
  public void test3221() {
    coral.tests.JPFBenchmark.benchmark45(-77.78765235119482,-676.2884085844029,84.46133748451666 ) ;
  }

  @Test
  public void test3222() {
    coral.tests.JPFBenchmark.benchmark45(-78.70967679798729,-689.451537554131,41.060099038696194 ) ;
  }

  @Test
  public void test3223() {
    coral.tests.JPFBenchmark.benchmark45(-80.52649187477373,-677.1354979976121,96.61089839108067 ) ;
  }

  @Test
  public void test3224() {
    coral.tests.JPFBenchmark.benchmark45(-80.56316633925078,-668.3098083676721,23.73240571481061 ) ;
  }

  @Test
  public void test3225() {
    coral.tests.JPFBenchmark.benchmark45(-82.424254391835,-675.0631502849684,37.50494623093047 ) ;
  }

  @Test
  public void test3226() {
    coral.tests.JPFBenchmark.benchmark45(-85.55973962089638,-684.6429114349385,28.614719437249477 ) ;
  }

  @Test
  public void test3227() {
    coral.tests.JPFBenchmark.benchmark45(-86.14053902764763,-668.7529640058838,2.2794987138197405E-6 ) ;
  }

  @Test
  public void test3228() {
    coral.tests.JPFBenchmark.benchmark45(-86.42340856196853,-662.0694712219705,52.22458981308486 ) ;
  }

  @Test
  public void test3229() {
    coral.tests.JPFBenchmark.benchmark45(-87.18671000776118,-666.5122810609274,89.70509103939096 ) ;
  }

  @Test
  public void test3230() {
    coral.tests.JPFBenchmark.benchmark45(-87.98680290179155,-721.6760121590138,50.172932909005056 ) ;
  }

  @Test
  public void test3231() {
    coral.tests.JPFBenchmark.benchmark45(-88.21001734292007,-670.559083941213,19.35857859301278 ) ;
  }

  @Test
  public void test3232() {
    coral.tests.JPFBenchmark.benchmark45(-89.95063856675108,-664.7890364074929,0 ) ;
  }

  @Test
  public void test3233() {
    coral.tests.JPFBenchmark.benchmark45(-91.0495354511504,-725.8088372757701,95.48584514280992 ) ;
  }

  @Test
  public void test3234() {
    coral.tests.JPFBenchmark.benchmark45(91.52161527695074,-14.793027701876909,-30.63776491902783 ) ;
  }

  @Test
  public void test3235() {
    coral.tests.JPFBenchmark.benchmark45(-92.01249010342971,-695.7507326821407,44.24634820270964 ) ;
  }

  @Test
  public void test3236() {
    coral.tests.JPFBenchmark.benchmark45(-92.85230363222652,-656.3722531665409,3.2130682751595714 ) ;
  }

  @Test
  public void test3237() {
    coral.tests.JPFBenchmark.benchmark45(-94.65847476383153,-691.1611694280488,22.915503550895494 ) ;
  }

  @Test
  public void test3238() {
    coral.tests.JPFBenchmark.benchmark45(-95.10465345814187,28.92940076400191,0 ) ;
  }

  @Test
  public void test3239() {
    coral.tests.JPFBenchmark.benchmark45(-96.44878560682102,-706.502178001545,13.622597334964539 ) ;
  }

  @Test
  public void test3240() {
    coral.tests.JPFBenchmark.benchmark45(-96.55843884553627,-664.1868523987969,75.6860958609472 ) ;
  }

  @Test
  public void test3241() {
    coral.tests.JPFBenchmark.benchmark45(-97.05195452809099,-653.6876457661143,93.42198910024396 ) ;
  }

  @Test
  public void test3242() {
    coral.tests.JPFBenchmark.benchmark45(-97.30512205478746,-653.0803327321149,86.13774562302666 ) ;
  }

  @Test
  public void test3243() {
    coral.tests.JPFBenchmark.benchmark45(-98.08729560651221,-653.3753810168881,75.04791951754893 ) ;
  }

  @Test
  public void test3244() {
    coral.tests.JPFBenchmark.benchmark45(-98.24838142934968,-651.4290852235083,87.21867636954178 ) ;
  }

  @Test
  public void test3245() {
    coral.tests.JPFBenchmark.benchmark45(-98.29615824915133,-704.341099018733,82.44597434648429 ) ;
  }

  @Test
  public void test3246() {
    coral.tests.JPFBenchmark.benchmark45(-98.67144762406734,-695.5617080118324,8.371330772524573 ) ;
  }

  @Test
  public void test3247() {
    coral.tests.JPFBenchmark.benchmark45(-98.9034694897637,-648.6858148119057,93.77647558141211 ) ;
  }

  @Test
  public void test3248() {
//    sym_v1null;
  }

  @Test
  public void test3249() {
//    sym_v2_( doubleToRawLongBits (x_4_SYMREAL) & CONST_0);
  }

  @Test
  public void test3250() {
//    sym_v2( doubleToRawLongBits (x_4_SYMREAL) & CONST_0);
  }

  @Test
  public void test3251() {
//    sym_v2_( doubleToRawLongBits (z_6_SYMREAL) & CONST_0);
  }

  @Test
  public void test3252() {
//    sym_v2( doubleToRawLongBits (z_6_SYMREAL) & CONST_0);
  }

  @Test
  public void test3253() {
//    	UnSolved;
  }
}
