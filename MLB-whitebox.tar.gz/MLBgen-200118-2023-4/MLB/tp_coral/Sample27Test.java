import org.junit.Test;

public class Sample27Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark27(0.0,0.013731231629100124,-1.5707963267948966 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark27(0.0,0.02670449496180069,-1.5707963267948966 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark27(0.0,0.08299046795217048,-1.5707963267948966 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark27(0,0.0,-1.5707963267948966 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark27(0.0,0.22735820733780443,-1.5707963267948966 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark27(0.0,0.23485073375056081,-1.5707963267948966 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark27(0.0,0.3704219308489991,-1.5707963267948966 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark27(0.0,0.39641793280037485,-1.5707963267948966 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark27(0.0,0.4187151298609848,-1.5707963267948966 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark27(0.0,0.43690952070547906,-1.5707963267948966 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark27(0.0,0.4703493711485792,-1.5707963267948966 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark27(0.0,0.5407552639819162,-1.5707963267948966 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark27(0,0,12.320824215647903 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-1.5707963267948966 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-1.9721522630525295E-31 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark27(0,0,2.1125297453011456 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-22.92836799246001 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-23.677126579645005 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-2712.6992068246523 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-2716.778467660142 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-30.376569110673216 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark27(0.0,3.1119335460516595E-5,-1.5707963267948966 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-3.1297754808144163 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark27(0,0,33.48533913354879 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark27(0,0.34861264577469725,-1.5707963267948966 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark27(0.0,3.6145308968116296E-9,-1.5707963267948966 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-40.33466003875288 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-5.265235207750578 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-73.00788328128924 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-77.11192156864564 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-82.51635947978313 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-83.87270018332778 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-83.91446065645496 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark27(0.0,8.881784197001252E-16,-2.076328313526128 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark27(0,100.0,-1.5707963267948966 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark27(0,1.5707907940934618,-1.5707963267948966 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark27(0,1.5707907940935328,-1.5707963267948966 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark27(0,1.5707907940935348,-1.5707963267948966 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark27(0,17.740361141836615,-1.5707963267948966 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark27(0,2549.7797358365337,-1.5707963267948966 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark27(0,2590.8736004679204,-1.5707963267948966 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark27(0,33.98777403190647,51.55321389140178 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark27(0,35.14665250360207,-1.5707963267948966 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark27(0,-45.30118370725476,-1.5707963267948966 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark27(0,54.72901884067974,-1.5707963267948966 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark27(0,6.12321242831616E-17,-1.5707963267948966 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark27(0,73.87087100517425,-1.5707963267948966 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark27(0,86.11553944378237,-1.5707963267948966 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark27(0,-88.17864000895726,-68.27617056960713 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark27(0,88.81005501014847,-1.5707963267948966 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark27(-100.0,0.012228799706648474,-1.5707963250457488 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark27(100.0,0.022498645930061727,-1.5707963267948966 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark27(100.0,0.036870049121471765,-1.5707963267948966 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark27(-100.0,0.15922656880530411,-1.5707963267948957 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark27(100.0,0.358107311987033,-1.5707963267948968 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark27(-100.0,0.4597014648138951,2.551398599833582 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark27(100.0,-1.214306433183765E-16,-1.5707963267948966 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark27(100.0,1.7850304567801345E-14,-1.5707963267948966 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark27(100.0,2.8140156871359068E-11,-1.5707963267948966 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark27(-100.0,3.016631065229759E-7,-1.5707963267948966 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark27(100.0,4.756540051939902E-9,-1.5707963267948966 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark27(100.0,5.781486400735503E-14,-1.5707963267948968 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark27(10.130263328051306,-6.498476516399817,-1.5707963267948966 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark27(10.472445960645825,1.8761103781628208E-12,-1.5707963267948966 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark27(-11.105588431400786,2.8382453804277394E-16,-1.5707963267948966 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark27(1.1491393399729176E-187,0.10200926793046053,-1.5707963267948966 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark27(-1.2957484623871496E-58,0.08554841719610724,-1.5707963267948966 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark27(-137.54032766498483,0.38090256884068996,-1.5707963267948966 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark27(1.5707907940239139,5.399439114491655E-8,-1.5707963267948966 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark27(1.5707907940935328,3.140065985007823E-11,-1.5707963267948966 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark27(1.5707907940935348,1.004119211524928E-16,-1.5707963267948966 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark27(1.5707907940935348,1.6973228378347471E-13,-1.5707963267948966 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark27(1.5707907940935348,4.229801998570884E-14,-1.5707963267948966 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark27(1.5707907940935348,6.938893903907228E-17,-1.5707963267948966 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark27(1.5707907940935355,1.7415402453480056E-11,-1.5707963267948966 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark27(1.5707907940935424,2.027343047686246E-10,-1.5707963267948966 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark27(1.5707907941010055,6.921265929668481E-6,-0.02780389052241628 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark27(1.570790794104916,2.9254182651004576E-7,-1.5707963267948966 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark27(1.5800039914425974,0.10802650304857275,-1.5707963267948966 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark27(1.5830049146381737,0.1242867175382196,-1.5707963267948966 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark27(1.6145109352525182,0.2332361901637161,-1.5707963267948966 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark27(1.6150225206653246,0.23456585252022072,-1.5707963267948966 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark27(1.692199861674393,0.3810966443663835,-1.5707963267948966 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark27(1.7138312143667158,0.015820484962432758,-1.5707963267948966 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark27(2033.9311564101342,0.032229267356428594,-1.5707963267948966 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark27(2238.1176902847747,0.1368630455587011,-1.5707963267948966 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark27(-22.91062219270785,3.6632093777665758E-6,-1.5707963267948966 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark27(24.84690809561222,0.17721324570481414,-1.5707963267948966 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark27(-25.155487943900244,0.18072833921168496,-1.5707963267948966 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark27(30.883778328563526,0.02843685800882738,-1.570796326794895 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark27(31.077120652204,0.5441525457890309,-1.5707963267948966 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark27(-31.40469145709936,-78.99301428906564,67.59713606425095 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark27(3.320286521101656E-166,0.054965733995731764,-1.5707963267948966 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark27(-35.47188340154981,0.027332853951291185,-1.5707963267948966 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark27(3.552713678800501E-15,9.734860845424637E-16,-1.5707963267948961 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark27(-35.69675636691045,-61.056039664848385,60.93117637140426 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark27(35.7549431180226,33.09049473869751,-4.259817222767335E-16 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark27(3.712128717282468,0.0023956781043000144,-1.5707963267948966 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark27(-38.09884597987262,-0.06874520202008566,-1.5707963267948966 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark27(41.902994464834336,0.09389631293532415,-1.5707963267948966 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark27(-4.2395758619023847E-168,0.07764960910973877,-1.5707963267948966 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark27(-47.89774564495295,-16.506249894251667,68.72634929603473 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark27(-4.930380657631324E-32,0.1502555422095493,-1.5707963267948966 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark27(4.930380657631324E-32,0.1898061175842939,-1.5707963267948966 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark27(-49.68441765811038,-66.98883614022523,98.20627008058696 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark27(51.118501047913725,0.025637903275776086,-1.5707963267948966 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark27(51.175938851244354,-6.7629471946954E-12,-1.5707963267948966 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark27(-52.533960640755964,151.85442684296476,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark27(-53.6791397308812,0.5351698745127502,-1.5707963267948966 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark27(-54.46359774596479,52.0708680281179,76.3946013770128 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark27(57.27346636682103,0.004305904304252426,-1.5707963267948966 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark27(59.961455287289766,0.0012912472104892204,-1.5707963267948966 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark27(-6.000533403494046E-12,6.813996991912502E-9,-1.5707963267948966 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark27(60.52927977243828,0.019297675360251648,-1.5707963267948966 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark27(-61.47230332695051,-84.76121571196158,1.2937331841713444 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark27(-61.88689719995889,37.48588539744535,-0.015122691410429809 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark27(62.313878922344465,74.75267964671202,-3.1446072150317304 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark27(-63.05719115214048,0.003074694079471696,-1.5707963267948966 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark27(6.629970542987278,0.32114337142649196,-1.5707963267948966 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark27(-68.34256339896241,87.84942735772435,-67.08232067817195 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark27(69.82384839359676,-4.50688288708076E-4,-2.403338284933356 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark27(-72.08843926643357,-126.81676741969756,-1.570796326794897 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark27(-7.283252350753522,0.1093417515783286,-1.5707963267948968 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark27(73.03601817598735,0.08314162420971186,-1.5707963267948915 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark27(7.670458539527698E-93,2.7240210520751168E-9,-1.5707963267948966 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark27(-81.90251258598921,88.55008785751554,-63.19580648742749 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark27(-83.20429949557808,13.38479917267206,22.70794247194023 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark27(-83.70590004035658,0.5249279560917725,-1.5707963267948963 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark27(83.8972026993777,6.123212428316163E-17,-1.5707963267948966 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark27(86.48647234288963,90.55307142383614,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark27(95.03201485016535,10.606704726428703,-4.708975172723214 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark27(95.27288726402828,0.03394429127725257,-1.570796326794897 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark27(99.97707215581194,0.21339905561188163,-1.5707963267948966 ) ;
  }
}
