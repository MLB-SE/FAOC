import org.junit.Test;

public class Sample58Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.0012062569288935343,89.08691484811327,-4.960722835051487 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.002805594991360291,1.3877787807814457E-17,-8.645163535653227E-224 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.009353823313972567,0.3076997071604413,-100.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.015738183470770384,30.074055650060814,-76.56608153558938 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.022464368079997767,0.46773479027125997,-3.358305517286672 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.022851604380004165,3.376471881214645E-5,-2.8690732234616E-14 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.02754179382540746,-0.004984287276993843,0.7916685128933972 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.030232565374235465,-94.39401485972158,21.240813037205747 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.03645071446644146,97.34792355091821,-74.11928833210881 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.059621414209490735,32.014088236862655,-5.374310202135696 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.060555469060829925,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.5188371180864608,1172.3914859314311,-1273.9250392759993 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark58(0.0,0.7425921400723755,-1.3877787807814457E-17,-69.99842052016707,0.022440453871988897 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.7434139540603919,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark58(0.0,0.7545467572483294,-0.04384511884008101,-2.858019804034923,-1.2835802469661481 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.9214717315416339,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.9999999999999999,-1158.2858447298504,1225.9989227006715 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-1.0,0,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-100.00000000449201,-0.05484997408524635,-13.035137945051108,0.03127939422284243 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark58(0.0,100.0,-0.0018414056732691964,0.22461628903985467,-6.866175105655984 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark58(0.0,100.0,-0.0023562425037723395,-3.8265481344730072,0.08337549655968213 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark58(0.0,100.0,-0.006458983166156146,0.20812396673943107,-3.658850278497564 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark58(0.0,100.0,-0.007847196725709125,-10.304636506751347,0.011967037176742856 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark58(0.0,100.0,-0.007905720978528263,-1.2279122171915193,-1.9156843886767785 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-100.0,-0.009437858589514181,-9.724013471181962,3.2152306432531925E-14 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark58(0.0,100.0,-0.010845001647745467,-7.523640107864229,0.18952389701132505 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark58(0.0,100.0,-0.012256472099114832,-3.269425643605963,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark58(0.0,100.0,-0.018467015601503108,-63.73969119731839,0.020503987268979285 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark58(0.0,100.0,-0.025520942474277553,0.11110648151055336,-14.137756010622057 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-100.0,-0.028662749545138214,0.03382152230937315,-15.759687371342547 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark58(0.0,100.0,-0.03247141534936304,-22.211907866312558,0.022245158956992736 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark58(0.0,100.0,-0.03255634279562391,0.0017269530146819937,-32.34906778456734 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark58(0.0,100.0,-0.040202119747699855,0.010061797848244501,-3.9205890000781665 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark58(0.0,100.0,-0.04436302317672415,0.024435266592560907,-41.60014762736034 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark58(0.0,100.0,-0.0479570073943449,5.858240706053586E-5,-26.336689782850968 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark58(0.0,100.0,-0.04884615729121963,-53.45959993602939,0.029381302740838118 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark58(0.0,100.0,-0.05218157175440021,0.3201078921036188,-4.004905399590662 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark58(0.0,100.0,-0.0558214308396415,-10.068624166757917,8.579519159954165E-18 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark58(0.0,100.0,-0.056929127135635055,-1.345296426557365,-1.7962973904789303 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark58(0.0,100.0,-0.05786859091704498,0.062305818168134644,-9.570140149672284 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark58(0.0,100.0,-0.058113622711232826,-20.012850103911823,0.0022685651303772855 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark58(0.0,100.0,-0.05828083873219045,-0.2654977968644573,-2.8781333441909993 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark58(0.0,100.0,-0.058864000887783624,0.0592371979206332,-26.363160294750813 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark58(0.0,100.0,-1.1102230246251565E-16,-4.413222421439143,0.2920399894805882 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark58(0.0,100.0,-1.1102230246251565E-16,-7.098498491285611,0.22128571679253906 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark58(0.0,100.0,-2.7755575615628914E-17,-19.14767719242398,0.08184957662966141 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark58(0.0,100.0,-2.783137033190993E-17,0.04408774299412255,-35.62886689400959 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark58(0.0,100.0,-5.551115123125783E-17,0.20557480165420722,-7.640996436115206 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark58(0.0,100.24177842281388,-0.05173073076917032,0.09797772892216017,-16.032177353654983 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark58(0.0,10.06541050446911,-0.024561007124788148,2.7755575615628914E-17,-10.307497324006377 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark58(0.0,10.14847249722932,-7.105427357601002E-15,0.11199255678048448,-13.272002268742082 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark58(0.0,10.343520926187871,-0.02871162375382604,-64.21674504736714,4.834115864314471E-4 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-103.88255586953504,-0.028491993157368306,-28.953851937658094,0.020758419936687034 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark58(0.0,1.0842021724855044E-19,-2.913836034405269E-17,-0.6866386816763321,-2.793386230811656 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark58(0.0,10.927551767118828,-0.05223067843593576,9.081206599047163E-4,-47.40903103384046 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark58(0.0,1.1102230246251565E-16,-0.026637692844282523,-47.970216726762736,0.010560314013035386 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-1.1985091468012028E-94,-1.1102230246251565E-16,0.146684715148364,-10.708657171308655 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-1.232595164407831E-32,0,0 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark58(0.0,12.670346079568057,-0.03639642765838291,0.18537322019745495,-7.240071933337379 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark58(0.0,1.3069145636522679E-8,-0.18710446314570373,0.015700306360364773,-3.4407301110487367 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark58(0.0,13.917654274697865,-0.01602386144444412,-98.14643194100421,5.127308042912747E-15 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark58(0.0,166.18330867431132,-0.024037621634900502,0.2100525393327533,-7.1536365992628745 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark58(0.0,17.370043564957914,-0.9735577352337139,-5.130523868713452,1.2362652034667925 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-1.7763568394002505E-15,90.43237780061318,16.862871519542736 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-17.806854266278336,-1.0013348442692706E-15,-6.431161928829825,4.440892098500626E-16 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-1819.900051459274,0,0 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark58(0.0,189.8536304055413,-0.039466007212268055,-2.726126213601625,-0.4181328683805183 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-19.3892826858817,-0.06015858525965086,-2.08327411683308,-1.060751765998397 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark58(0.0,2.01093090436043,-1.3877787807814457E-17,-41.96558173766516,0.03743058625075335 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark58(0.0,20.28014832749942,-0.03722903737441467,0.23049380662428964,-6.795073043839455 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark58(0.0,20.770181219159756,-0.025251831055145668,0.018530870319291348,-9.5754028102422 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-21.433922163201075,0,0 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark58(0.0,21.459837652746437,-0.054307068068909815,0.00518770798329972,-19.95597263317299 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark58(0.0,21.92498955698406,-0.060384227650206734,0.061106736726604244,-6.719958232002204 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark58(0,0,2.2408097488110172,0,0 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark58(0.0,24.077771641085196,-4.067668056036904E-4,-3.747747472228193,5.551115123125783E-17 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark58(0.0,24.225490480239287,-0.046355575971286235,-13.561768960604947,0.1154874401278939 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark58(0.0,24.581786954435557,-0.035352020936008255,-0.4730743891618622,-2.6686354840430866 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark58(0.0,25.246028731652544,-0.041970625466338174,0.01770518513957603,-13.325166230775235 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark58(0.0,26.011922914933216,-1.7763568394002505E-15,0.02143948009612615,-73.26653070652979 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark58(0.0,27.362619112986366,-5.551115123125783E-17,5.780416520834781E-4,-69.85779191065926 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-2.7755575615628914E-17,0.0,-100.0 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-2.7755575615628914E-17,34.235912283570954,-5.680615430869433 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark58(0.0,28.10659072047197,-1.1102230246251565E-16,0.012463945974031044,-53.55570600982353 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-28.166967503573133,-0.01302932664514858,4.156004841243677E-6,-12.846858587326933 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark58(0.0,28.76016865755161,-0.06145692660063029,0.019281626594001844,-18.714221917990045 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark58(0.0,2.900770593138825,-0.0408694866283561,0.0457448761183884,-31.885016170962263 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark58(0.0,29.120717680582764,-0.01423028713243243,-38.91795758598162,0.040361735924205826 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark58(0.0,29.636722917165464,-5.551115123125783E-17,-63.074013755939994,0.024904017253015942 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark58(0.0,29.76518945055243,-0.02638090710343527,-47.653339826302904,0.03296079572135202 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark58(0.0,30.124451222436356,-0.028354147643744998,0.02269197893660531,-69.22253590941402 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark58(0.0,30.863596083911798,-0.023866943951734013,0.05900275521413833,-26.621805426340757 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark58(0.0,33.236864550762924,-0.004960046337764368,-1.032537100196235,-2.234693599407791 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark58(0.0,33.390165216232,-0.006157847869270136,-2.4848927383508674,-0.7983519586004928 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark58(0.0,33.610854710737264,-0.058165969589049515,-2.1739158451804115,-0.9696374412720783 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark58(0.0,3.4280716643204695E-4,-0.05478991199567125,-97.99671081428123,0.015840655756731322 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark58(0.0,35.18888954417269,-0.00453125385257247,-38.1761769387235,0.03728991672419035 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark58(0.0,36.706568587093614,-1.1102230246251565E-16,-4.051144430088245,0.3790714010018039 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark58(0.0,36.814875715471594,-1.3877787807814457E-17,-7.90133080346547,0.198801488744903 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark58(0.0,37.169055685977,-0.03343216454265643,-14.026186312020409,0.09096693911286041 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark58(0.0,37.66966668044094,-0.9718324276261989,0.611494312454828,-4.353468225080456 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark58(0,0,38.43571501184965,0,0 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark58(0.0,38.7339458911698,-0.41376695087153076,0.7161520133985076,-4.857732509582855 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark58(0.0,39.10486235574923,-0.023699092338903438,-18.97600583657502,2.3876469334183045E-7 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark58(0.0,39.856898163503104,-1.2498296783175073E-14,-10.060462524242098,0.033148914331070145 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark58(0.0,40.37037011253262,-0.005166570332285403,-35.82355388780994,4.0517333799938715E-4 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark58(0.0,40.773322705910736,-0.007227919437006458,-26.255487721255463,0.05982735279844853 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark58(0.0,40.91887100360024,-5.247884690902162E-4,0.014038312121921415,-3.1750903109148645 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-41.73139248353928,-0.05478018372971413,0.1433092645011138,-10.960884715047072 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark58(0.0,42.872498725540396,-1.1102230246251565E-16,-13.827798164524197,0.10319089130929895 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark58(0.0,43.70699029768642,-0.014977369826830617,8.881784197001252E-16,-4.10650606615215 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark58(0.0,44.20508223004019,-5.551115123125783E-17,-4.36694905037259,0.3597010884889684 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-4.440892098500626E-16,0,0 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-4.440892098500626E-16,-27.441167983253337,87.56889202686423 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark58(0.0,4.462940954725405,-1.3877787807814457E-17,0.02232298278385792,-70.36677589209816 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-44.77888327544441,-0.0015113135263288557,9.891298419938181E-5,-31.531276223851357 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark58(0.0,45.45207083863411,-0.056340868537973585,-32.30718715925808,0.001204362138504167 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-46.25488486257585,0,0 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark58(0.0,46.865187657945775,-0.044420226340954605,-6.805272405687802,0.23082049228213464 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-47.16856700879385,-0.010746886851454548,-73.57909394291434,0.012369029875664711 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark58(0.0,47.17153324918113,-3.552713678800501E-15,-16.20932813883848,0.09690693613827861 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark58(0.0,48.20045845353602,-0.011385970711615984,0.024205185369070268,-64.3234099389253 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark58(0.0,48.26559219175538,-0.03199885664740011,-4.17925283782496,0.09080146416646623 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark58(0.0,4.8322544516958885,-0.04018877388347464,0.034897454349980706,-44.610359055974854 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark58(0.0,48.58546559022154,-4.440892098500626E-16,-10.444202538867572,0.1503988764052835 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-4.930380657631324E-32,0,0 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark58(0.0,4.930380657631324E-32,-0.05245289364869327,-12.790518211411234,0.09947987867005714 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark58(0.0,5.002857105100219,-0.05901319902690427,-48.46813574399134,0.03240884557829584 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark58(0.0,50.70717506455354,-2.7755575615628914E-17,3.355235404773748E-5,-13.71098532503424 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark58(0.0,51.910698899396145,-0.02298690153839167,-2.349430685807793,-0.9172837517458416 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark58(0.0,5.201167937618262,-0.0465609317620362,-69.68222424999641,0.009071943160162466 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark58(0.0,52.99357319902053,-0.059391619671189375,0.041573426389182794,-6.669753446220121 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark58(0.0,53.24031487366494,-0.05528988671256874,-1.6772785573060962,-1.464314782058551 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark58(0.0,53.77890119376334,-1.1102230246251565E-16,0.028214011340370604,-37.73814773287912 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark58(0.0,54.31956541165672,-1.1102230246251565E-16,-6.567771979239259,0.23916730540587983 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark58(0.0,57.64780281214747,-0.062365264370809304,-4.464409690006866,0.35184860616868713 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark58(0.0,57.76446568421675,-1.3877787807814457E-17,0.003733095938643096,-3.3360188406851456 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark58(0.0,58.43101524063919,-0.009944375910129626,5.551115123125783E-17,-41.65535550510071 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark58(0.0,59.456935944892166,-0.02274259786953675,-63.99252902905719,7.885792638261807E-5 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark58(0.0,60.03481650701687,-0.0318966739138109,0.011756749204374542,-10.372938427410805 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-60.240647157396204,-0.019541705352676617,-2.2394864211832965,-0.9043055631597926 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-61.669284823269294,-0.009018424240140877,-41.10292634874725,0.008866977466584058 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark58(0.0,6.193786066719959,-4.679470423191416E-16,-38.32447289144165,0.01664494955903298 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-62.70278148417755,-0.012906652099179905,-4.61430263156147,8.897596209388445E-14 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark58(0.0,64.68610415901539,-1.3382014316400922E-16,-14.137834812344181,0.11110586222321217 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark58(0.0,65.12629868250865,-0.04932335182088415,0.005924510189218111,-51.498221532600994 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark58(0.0,66.3085993880023,-0.05986015605126038,0.04012545026220046,-26.44162616553183 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-6.681911775230489E-52,-0.015822601357334588,0.025861541815146927,-60.73869601521174 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark58(0.0,66.98786533189018,-0.018260857213270656,-14.1259266898012,0.11119952420034718 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark58(0.0,68.39136759004829,-0.0021637761598054805,8.872936947507597E-19,-3.8377734762006526 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark58(0.0,69.1342891116268,-0.035591868761307044,0.012129157722674345,-12.682815571635416 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark58(0.0,70.03092320675091,-0.2926901015974102,-62.94464278489811,0.022536587901508576 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark58(0.0,70.8799589844719,-0.03733661172920906,-64.33454636587099,0.024166828465561625 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark58(0.0,71.15405566499322,-0.03455626686293245,-15.98800188439618,0.09002079076658687 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark58(0.0,72.1247338646046,-9.047506693834674E-4,-6.878913353127509,0.12493041009569923 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark58(0.0,74.22659327945601,-0.017288626818544633,3.552713678800501E-15,-13.632683039198032 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-74.50833960814523,-0.015596325433204411,0.41740053132899557,-3.721525904272994 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark58(0.0,7.451968301089055,-2.7755575615628914E-17,4.440892098500626E-16,-7.529393451262916 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark58(0.0,75.72214718408418,-0.02787795841514296,0.016564694232734302,-94.54714161211922 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-76.21588959825239,0,0 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark58(0.0,77.27048836121836,-0.01822576606085459,0.0019477013267509007,-13.151937505614422 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-773.3601866390052,0,0 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-77.799243155429,0,0 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark58(0.0,78.12949568167278,-0.061208770030767246,-3.5069502901016136,8.284928298962768E-12 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark58(0.0,78.17706131726058,-2.1620928661553917E-14,3.552713678800501E-15,-23.327659005042207 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-78.6677990559352,-0.02213528722716961,-0.5863160724948044,-9.125599970889834 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark58(0.0,79.37104274207155,-0.04843743099463224,-41.55007610477756,0.0026848084258275784 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark58(0.0,81.26713227559502,-0.05059246476805185,0.0017127304753792316,-7.430586802992859 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark58(0.0,82.2497647721394,-2.7755575615628914E-17,3.552713678800501E-15,-3.677534095226587 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark58(0.0,85.47830833512364,-0.031656927329925214,0.09794451411199659,-15.870448682921193 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark58(0.0,86.32756534200621,-0.053420412458609456,0.029486799812391242,-38.54259169260981 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark58(0,-0.8791596430342743,-0.024525916672402476,0.016649951158806096,-68.40040208067336 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark58(0.0,89.45135347792723,-0.0071428729243326276,0.1608709802809254,-9.764323708675422 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark58(0.0,90.33070342190896,-2.236871877373532E-15,-6.562771521429601,0.22650640070587444 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark58(0.0,91.01117529201998,-0.046422491446912684,-32.076420882725806,0.004288823267421915 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark58(0.0,91.05457084862007,-0.022960180704898428,-7.5575979847484716,0.11102839311168289 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark58(0.0,9.161821166094063,-0.025908408132564453,-35.29977131271049,4.440892098500626E-16 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-9.234457994106531E-4,0,0 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark58(0.0,92.60418328490414,-0.06195491011100637,-10.245398549117539,0.0568349119062696 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark58(0.0,92.63217021607679,-0.005166231577096614,-1.8504232352373313,-1.2912727226490972 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark58(0.0,93.80998106274849,-9.2903857086446E-4,-70.58383522852981,0.022254335170497186 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark58(0.0,93.98317223568307,-0.007167125658955442,-63.92465878769509,0.02457261965231794 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark58(0.0,96.4127406149617,-0.0503133266197627,-0.11342089838050624,-3.032520457631024 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark58(0.0,9.653510813602646,-0.020389359830621623,0.2016129152192432,-7.791149317427109 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark58(0,0,96.81809715553939,74.24701046880779,1.8427998350909718 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark58(0.0,97.15648678322525,-0.057345010405060654,-6.816082415582008,0.00460601934189836 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-97.7885263049859,-0.3127634970076105,-1.085346690837754,-3.0592996997515396 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark58(0.0,98.42116906410143,-0.033305252729121715,-3.421191407502942,0.26483997075353277 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark58(0.0,98.59799006110715,-0.057455435129404986,-6.709872466191602,1.9171709449574474E-16 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark58(0.0,98.7342043079075,-0.037909959679416544,-82.746243948689,1.5977392411198075E-18 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark58(0,0,98.96282899600541,2.054719634529249,-88.47644475068124 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark58(0.0,99.37358584896312,-0.40135027081133534,-2.934251905607168,-0.21189629523188858 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark58(0.0,99.39827767822904,-0.014370872891292963,-7.902545865393579,0.1810647064320356 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark58(0.0,99.80790395269047,-1.1102230246251565E-16,-3.584484189054047,0.43822102259277446 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark58(0.0,99.9981882756147,-0.05471377601428587,0.09860867096420689,-14.16497928532338 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark58(0,-100.0,-0.014208671112729684,-30.78120161489353,1.00686773258539 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark58(0,100.0,-0.016448409986188486,-9.82155603940585,0.09067739503438793 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark58(0,-100.0,-0.026146699026876045,8.881784197001252E-16,-62.99861058685384 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark58(0,-100.0,-0.05685916684247459,1.0603018655522933,-1.0603018655522933 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark58(0,-100.0,-0.05846502233438483,-22.47542510934214,0.004405583751573843 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark58(0,-100.0,-0.05848356006190203,-9.7232095610415,0.1615512158751251 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark58(0,-100.0,-0.22019795265570286,0.6787047412824156,-2.2007209433913157 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark58(0,100.0,-0.2861246380056405,0.7274162284461266,-2.1090142230321236 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark58(0,-100.0,-2.7755575615628914E-17,-74.74676418779418,0.0010930853573746513 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark58(0,-10.317364448038337,-0.022486683819532727,-3.0035068304533055,0.250783891050095 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark58(0,127.13142973434758,-0.03186514830392323,-22.225358697363845,0.07067585941734222 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark58(0,-13.953475894623312,-0.004447902166993173,-2.153579911603691,-0.9880412421335885 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark58(0,-1.4110048740021366,-0.03463666095301274,6.938893903907228E-18,-33.12893749864674 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark58(0,1.4254067376013264,-0.021638284676464392,-8.449845898987236,0.09753581362908845 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark58(0,-1.550238907450868,-1.3877787807814457E-17,0.06586271717597061,-17.063166085043562 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark58(0,-165.65091687395173,-0.022697757687684932,-996.081934356381,6.938893903907228E-18 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark58(0,-17.431414052306483,-0.03462888120810595,1.0201689285089341,-2.5909652553038307 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark58(0,-17.57619242433131,-0.02356254707316252,0.005421005898387224,-1.5937929637922783 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark58(0,184.83280891650605,-0.048848251716502186,-3.2723169607648828,2.8421709430404007E-14 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark58(0,-18.845513825130865,-1.1102230246251565E-16,-64.03284486550116,0.0020405334212174 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark58(0,-18.938517258253565,-0.043343952364917726,-3.1621211683980124,0.4187467264935929 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark58(0,-19.737932721470713,-0.8577140646348066,-11.701062377867057,10.201062377867055 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark58(0,20.072483413518594,-0.040892651800701334,-1.7451962642770158,0.17439993748211938 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark58(0,2.061630281454047,-0.0022832997154312307,0.022862218718486815,-68.70708158888534 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark58(0,20.790258761624287,-0.0578435905568937,-29.021030118590502,0.05412613957450674 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark58(0,21.291749587877035,-0.03217806113419974,-0.2888087729416488,0.288808772941648 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark58(0,27.865696746711457,-0.030796027188195654,-28.53760212059014,0.334064565076896 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark58(0,31.504673270813484,-0.03816736056694402,-11.189122645996557,-68.83048418706733 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark58(0,33.27323666850156,-0.009999999999999556,-9.705369014184436,0.16028468522872075 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark58(0,-34.75027757365406,-3.552713678800501E-15,0.4219773599900094,-1.9927736867849148 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark58(0,35.953053217350245,-0.0036061785964800475,-137.62658144758313,0.011396779384738376 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark58(0,36.25133832118473,-0.018053759350565947,-3.391568197943485,0.46314749847795067 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark58(0,3.7789165957215722,-2.7755575615628914E-17,-1.800801621174739,0.3008016211747391 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark58(0,-38.150495729763136,-5.551115123125783E-17,-0.046670379318396016,33.657243625093614 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark58(0,44.17088130529555,-40.00563165621514,-34.100293301380134,-39.27509261297255 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark58(0,-47.05687515629507,-0.061988671351209654,-1.765881405100319,0.5063039559864247 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark58(0,-47.0707992642794,-3.552713678800501E-15,-24.254175115570845,0.06476395586758638 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark58(0,-5.2488639286019065,-1.4918009404806297E-30,2.2099501019990773E-31,-39.28394834060265 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark58(0,58.67213304132957,-5.551115123125783E-17,-4.493791506759942,2.9229951799650458 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark58(0,58.94447115093814,-0.04545913574020849,0.15133797957225426,-10.379392742218954 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark58(0,-59.17353845764708,-0.05249997604145919,-85.47205125819562,2.2906526091984425 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark58(0,-59.734487083864906,39.92888247830197,-5.791466362967213,13.734049572449976 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark58(0,-6.0603323769295825,-0.04113446441686974,0.05056811603475549,-29.824901998342895 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark58(0,-64.19501860511758,-0.05815023735565761,-11.194069901976514,0.140323969793823 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark58(0,7.455869690570014,-0.0390021889901222,0.3023959444840898,-5.194501961574886 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark58(0,-82.48150675296799,-0.016277483484316235,-30.41558794695554,1.2434497875801753E-13 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark58(0,-83.70125479406738,-0.06179256051547357,8.881784197001252E-16,-10.820027828091554 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark58(0,-83.91395748480123,-0.581717242789986,-9.979985014875107,9.979929695534404 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark58(0,-95.02518803996077,-0.061350564690056855,-3.398813344672802,3.398813353701371 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark58(0,99.65602544858369,-0.10308515414243057,7.549837926385366,-5.980127179998395 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark58(0,-99.86394935114606,-0.03639114986095554,1.2260414905540529E-11,-14.132459124075197 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark58(0,-99.99642086191186,-4.440892098500626E-16,0.6002657991531166,-2.1710621259480134 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark58(-100.0,100.0,-3.584175252890401E-33,0.18672758758323527,-2.962312257187754 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark58(100.0,-11.199928944052054,-0.04148500917945079,0.014955294701551602,-35.18948572230795 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark58(-100.0,-16.51650171921301,-8.275218782253235E-4,-13.875915000820925,0.11320308078432642 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark58(-100.0,-4.218249443926356,-0.027475849932604546,-0.6481365063173713,-2.172127641821706 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark58(100.0,-42.770792323012536,-0.010633858358269698,0.02493403721628671,-62.998074205517014 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark58(-100.0,-57.86821953375924,-0.010772816471275109,-2.0288953667859104,0.06878530292275392 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark58(-100.0,61.655104662549675,-1.138009278625841E-16,-1.1717249071812166,-0.39907141961368153 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark58(-100.0,-72.0298045381781,-1.1102230246251565E-16,-1.7771911455658862,0.012068967388693813 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark58(-100.0,-72.40436132370647,-0.06144521096123418,-2.3795393303704677,0.6403340428880557 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark58(100.0,7.274241817778482,-0.04263414637253041,-3.8858079617566212,0.3795764465898984 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark58(100.0,-74.78556549905768,-0.3084288695418846,-0.2489310557822328,-2.9095932760886134 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark58(-100.0,-76.70987273325233,-0.012696805470148734,0.7989265367633959,-5.440519190350062 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark58(-100.0,8.223978306101841,-0.3071575466797937,0.42233934444652643,-3.671551920207704 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark58(-100.0,-92.95181499697577,-0.01698448138676914,6.545585581914856E-4,-28.523667181387232 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark58(-104.91103152395002,-100.0,-3.71407250678144E-14,2.5273161101623897E-13,-20.856088778136648 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark58(-1.0542197943230523E-81,-99.71975118313898,-0.05483797969220075,0.0014281640205777647,-94.38641050926148 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark58(1.1102230246251565E-16,29.221586738341045,-0.058537455757020296,-47.573296315224994,0.03301844623897106 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark58(1.1102230246251565E-16,74.77224324074221,-0.05327369471858462,-51.399998934851425,0.030560240454204135 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark58(-12.330384484785645,88.31619925470139,-0.05303940441836199,-1.8066039160963285,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark58(12.973395530909938,-19.041334524109224,-0.046880226089903,-4.116036818694422,0.3062661711777661 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark58(-13.692701694944363,-33.60717929313681,-0.016763899438444037,-53.25458808613916,0.0015303308972861585 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark58(-13.835509161602952,99.54633257638424,-1.1102230246251565E-16,0.6001415659164495,-3.833516635510649 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark58(-1.6585324113029998,-19.93017472199944,-0.05911249639675234,0.4202442964195041,-2.4118217553846364 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark58(-17.610133266710882,-94.68689881682282,-0.05289769538269806,-15.512592743445687,0.027310806214362576 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark58(-18.725974883417493,25.086265630479176,-0.0591057130510651,7.105427357601002E-15,-56.77062041297432 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark58(-18.836371564388124,0.08494561462241323,-0.019256558320740358,0.014719149860456074,-100.0 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark58(1.926051279714691E-5,-100.0,-0.1255408316942395,-3.3553317896476997,0.46814932926791764 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark58(-19.616141657664116,-104.1143074238519,-0.03995351203616726,0.22736044505626932,-4.539279579351712 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark58(21.33596094959156,-15.759211053957243,-0.058340197262621046,-2.8448927969185998,-0.3809329043958913 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark58(2.220446049250313E-16,45.51779307208319,-0.025842015227940662,-19.850310777673723,4.440892098500626E-16 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark58(-22.31658314739137,-56.13307462646529,-0.04225449199294962,0.004490744841276345,-15.577341619048664 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark58(-22.76370678335225,-77.44080212144247,-0.0035858047543836785,-2.6946866829703047,0.0754863111976607 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark58(-23.377029016692166,-99.23392932730654,-0.048286662168664424,0.06300641438790339,-24.930736682276237 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark58(-23.54762769095587,-29.31183951378053,-0.022429426717486933,-19.4527996022765,0.029046843255127963 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark58(-23.87717233834671,73.91868946608643,-0.31609143865952155,-0.2155271777435765,-4.580730105854997 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark58(24.04724895545938,71.18657693684872,-1.1102230246251565E-16,0.008606480723281072,-3.3746090803511777 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark58(24.431155870463076,-70.02896340369607,-0.05941387610051313,-6.862811587937227,0.2288852472004148 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark58(-24.75479967231246,100.0,-0.0515882102460911,0.005032621119129475,-7.721039633286161 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark58(-25.45036615554037,-11.728605632808637,-0.027538070454478834,-59.22961266976443,1.3316965701044482E-16 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark58(-25.54597582867648,-70.40857376695071,-0.05564220298050997,0.02344235830192681,-6.9373712803904315 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark58(-2.710505431213761E-20,100.0,-0.015182383166520897,0.023792796142808825,-66.01982874844366 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark58(-2.7771230477961434E-39,100.0,-0.04418039756458567,0.06496538791975874,-15.702132329073828 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark58(-2.877484412233605,-100.0,-0.05069579545559437,0.06100470477180285,-6.937661559861876 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark58(-30.34561296884637,90.05384706771194,-0.04759790912291807,-17.099322055556723,0.0041564280522137 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark58(3.130826105990288E-11,78.32335279988379,-3.469446951953614E-18,-2.9833785704980555,-0.2923878168733898 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark58(-33.65344103845766,100.0,-0.04963143465198777,0.010528849104580448,-17.750195779619958 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark58(3.393603350540608,14.736553866260074,-0.043613727731698027,-2.2452121242271477,-1.0221412042404452 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark58(34.69920169039227,27.23790137610284,-0.04906602511194099,-1.9790094130678075,0.1034647870584493 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark58(-34.84138950542575,72.73476138125908,-0.02214260163675255,0.045054252391389264,-20.342041749512198 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark58(-35.22443762952172,-74.61522866931091,-0.028231218190356056,-0.4545378356148064,-2.6891915824050665 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark58(37.44661069553453,46.10325204424055,-0.00883414691608364,0.1523826503934363,-6.976409122207585 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark58(-37.90202753598533,-29.080997243705614,-0.00621473113456722,0.0483560971032343,-24.69498736091731 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark58(-3.944304526105059E-31,100.0,-0.056286756341942426,-66.39738097413438,0.02365022372856836 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark58(-39.53981344712257,75.50221171195996,-0.050091814440215335,0.526455190696129,-2.2260038178693504 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark58(-43.792765515018544,100.0,-5.551115123125783E-17,-20.903589934982122,0.07490848960185198 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark58(-4.5338776522100375,0.9729216288110818,-0.04655893115455897,0.021830609657587097,-15.428377726500706 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark58(-48.025656351196176,-76.48327669924493,-0.047102136253503124,0.2422475080415366,-4.202537027606866 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark58(-50.565695538592266,-1.1210543222192924,-0.02445698560888987,0.0035601791833115293,-28.84808410452676 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark58(5.110092178738995,-20.92132642776457,-58.06480965475007,-82.46560722379459,70.17322420005752 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark58(55.03487434882743,86.3550116361296,-0.1155632894988411,-1.1140431212469317,-2.0403099995305314 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark58(5.551115123125783E-17,63.94684448138647,-0.0018418281266329994,0.009538571121322621,-82.78516419456335 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark58(-56.20638781732501,100.0,-0.04648326951497761,-13.924209640954032,0.08342587817132376 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark58(5.8417968135217215,-60.19367199125809,-0.05865822552947259,-9.816798279477933,0.07479871579582455 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark58(-59.38691714490737,-39.40397729010165,-0.034442137291555486,-10.53742043124497,0.14906839269099056 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark58(-59.52059597215771,-58.921822247220604,10.1584017718871,34.200905769813176,71.79968773907379 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark58(-60.20492244147993,0.5556865226460603,-0.026640319616192287,-51.8790492435826,7.105427357601002E-15 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark58(61.894029332578015,-28.88988865517601,61.97956738684172,-25.11612284492793,-23.580919439485726 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark58(-61.98438084701821,-100.0,-0.00498056531888456,1.4210854715202004E-14,-17.322301425775528 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark58(-64.01816282976854,-28.3287274529225,-0.04655955314035248,0.1651917021384166,-2.8936332488679612 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark58(64.61866064995905,27.127633443915528,13.807100006499368,-44.351062963637425,-17.354962386464805 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark58(6.797449372081061,10.18575231043522,95.46523101083207,78.22255501139043,53.610701436821074 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark58(68.12717187124025,-99.11759685078731,-0.006762301856876235,-4.405567293420219,0.356548027115805 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark58(-6.908830339348384,-33.423529475949586,-0.044911382268327416,-8.25060283390129,0.1903856431363509 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark58(-69.66537281796865,-32.99910629712274,-0.0388442123017846,0.04707599627135131,-24.575847215599303 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark58(70.38703478179744,-14.233943574668984,95.46723396554407,14.285693303463631,64.2961896496044 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark58(-73.37425220495017,71.0598338662619,-0.015169467856965532,-41.714363096321684,0.037564119292384235 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark58(-73.52568620172525,-25.871832539958998,-0.002402948080127892,-51.36878689257821,0.01044107918464443 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark58(-75.4229003369685,-100.0,-0.05442605457157512,0.005081374476109901,-100.0 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark58(-76.51365002198004,-99.64174758595423,-5.551115123125783E-17,-4.206343321012329,0.36011157739276384 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark58(78.02850724021098,-20.739798913406176,-79.86542774707321,78.11381252217228,-22.063270712676754 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark58(-78.44335436203791,-34.35954286991087,-0.046608718263297225,0.07377200489366256,-20.890209717461005 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark58(78.9382057877952,82.98128964184744,-40.60233356141272,39.61390876927112,37.23810379934173 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark58(-81.75339442796286,9.702132527818065,-0.04325778467763486,0.5797805505599456,-2.150576877354844 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark58(-81.78661876537525,28.097004020735373,-0.011037654295568439,-0.6789500176312284,-0.8918463091636699 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark58(-8.276972358334277,-45.72291123803285,-0.03313284858473278,1.6375559496062287E-32,-4.747327369598918 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark58(-84.42338305490215,14.361171787126445,-0.014828783707838114,-50.57521480074367,3.469446951953614E-18 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark58(87.36820606861372,-9.088753062439084,-0.05465250268505747,0.019173745417061835,-72.64115577174097 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark58(-8.881784197001252E-16,33.25441744547998,-5.551115123125783E-17,3.0873519627551936E-4,-38.66894872587987 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark58(91.63597021063453,5.013037567166975,-11.080222571516842,-25.028566211517216,83.38833291526572 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark58(-92.48101022461164,-16.1293006532912,-0.006302382704588411,-1.0185656019535323,-2.1277841240565794 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark58(-94.34043111436834,-100.0,-1.3877787807814457E-17,-5.422334111223136,0.2896900660436745 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark58(-95.30427181410322,0.41312649456293116,-16.719481705609596,-48.80237850999054,48.24335813907473 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark58(-95.38115456267785,33.52731585739743,-0.049585757302687675,-7.0418736117889065,0.018905939212262857 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark58(-97.20295177350259,99.91179811611376,-0.01750186894531336,9.03818517390083E-8,-2.6849799454487444 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark58(-97.38302437453193,-107.26925876445505,-0.017317282368170817,0.019441087282754087,-77.04131347031858 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark58(-98.63525803496046,81.19854591377779,-0.0121298042535488,0.4066525576961734,-3.8627479332578103 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark58(-99.90973136246194,-5.065495912412757,-0.009418922088540992,0.02420304194039581,-64.89862890021607 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark58(-99.9587314733814,-4.127280707273703,-1.3877787807814457E-17,0.023080711385375804,-23.129600918366606 ) ;
  }
}
