import org.junit.Test;

public class Sample31Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark31(0.0870045480222359 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark31(0.2923347360790416 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark31(-0.44844617558296385 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark31(-0.49999999999999956 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark31(-0.4999999999999999 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark31(-0.5000000000000001 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark31(-0.5000000000000007 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark31(-0.5000000001938832 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark31(-0.5000000005137453 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark31(-0.6455730619844102 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark31(-0.7527739915370244 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark31(-0.8596067569576826 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark31(-1.0449966711536138 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark31(1.373213562069651 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark31(-18.5 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark31(-2.1571439849348337 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark31(-22.365833075276512 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark31(-2241.9875091223385 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark31(2638.7928666883995 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark31(-2728.145935746089 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark31(2737.562133275677 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark31(2.7793198862449175 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark31(3.036032702810253 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark31(-4.342390829854438 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark31(4.900741151535744 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark31(-49.74610886986681 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark31(49.80936623094496 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark31(50.449462984355705 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark31(-53.96313654353682 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark31(55.82219734457735 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark31(-60.5 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark31(-62.5 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark31(76.18305771182122 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark31(-77.38115234595048 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark31(-90.8560671114758 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark31(-9.209348876362355 ) ;
  }
}
