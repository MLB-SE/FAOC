import org.junit.Test;

public class Sample38Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark38(-0.33058616494654736,-41.038564827165594 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark38(0,-4.5188554788819175 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark38(0,-6.180946589280438 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark38(-0.6971002146258058,-26.534319066623894 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark38(-0.7058841006737424,-22.1558293716529 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark38(0,71.06211851930374 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark38(-100.0,-100.0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark38(-100.0,-5.832897615645118E-303 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark38(-100.0,-9.860761315262648E-32 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark38(-10.315891892239396,-164.91567453205332 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark38(-1.0E-323,-4.445517498970155E-162 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark38(-1.3380952362388014E-306,-60.13711549946152 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark38(-1.3552527156068805E-20,-96.21690520695428 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark38(-13.752496078721421,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark38(-14.558460694023182,-22.381706760122768 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark38(-1.7763568394002505E-15,-64.91727957543974 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark38(-1.7763568394002505E-15,-74.67517967176984 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark38(19.179951013226315,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark38(-1945.880758209,-0.0014294698164505019 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark38(-19.556667680589328,-69.63198478769739 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark38(-2.0691663382152847E-308,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark38(-21.43137581181523,-33.01359765296361 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark38(-21.6885684200721,-78.86416243417717 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark38(-2.2250738585072014E-306,-100.0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark38(-2.2250738585072017E-306,-100.0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark38(-2.2250738585072115E-306,-100.0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark38(-22.411805482172497,-73.8749327053023 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark38(-24.283343506402062,-27.82294267884204 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark38(-2.430022394527029,-75.36361044204507 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark38(-2.4868995751603507E-14,-98.3018353844025 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark38(-2.5243548967072378E-29,-49.946475214976175 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark38(-2.735950031295502,-34.44057367579873 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark38(-27.58511515915083,-92.20634615703977 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark38(-28.256793325863853,0.0 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark38(-28.574915769920707,-97.86209513543469 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark38(-28.698887221459984,78.09351588422211 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark38(-31.08692204826069,0 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark38(-3.147088996221356,-50.75209420530336 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark38(-32.040161235466314,-32.040161235466314 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark38(-3.226979133058009,-8.34539282440403 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark38(-3.2379E-319,-192.8281056751433 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark38(-34.893588282323336,0 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark38(-35.198371228372125,-48.8478422425245 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark38(-3.552713678800501E-15,-60.80736932438029 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark38(-35.721997250049924,-36.15765780670408 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark38(-38.517392822211185,-73.2175816378307 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark38(-40.02747712822963,-68.33406086099723 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark38(-40.36695447996861,-64.30852558219607 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark38(44.05025751021543,0 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark38(-4.457356715756639,-71.25782211453301 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark38(-45.55946801791666,-84.52029192921052 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark38(-48.447468567175946,-95.07799060404945 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark38(-4.973799150320701E-14,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark38(-5.2035000224907435,0 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark38(-53.21117496695227,-92.8088465915104 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark38(-53.78163190025524,-96.17009315624507 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark38(-54.17835006268048,86.0424519884744 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark38(5.80532984619299,0 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark38(59.60670947972807,2.7665326776929504 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark38(-62.06849105804126,-42.178449651600445 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark38(-6.25525252314378,-100.0 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark38(-64.06317002846227,0 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark38(-64.80455234999857,-64.80455234999857 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark38(65.10838761710784,0 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark38(-6.938893903907228E-17,-100.0 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark38(-69.8538065779077,-69.8538065779077 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark38(70.13589909097564,-4.694750543595674 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark38(-70.93193686660973,-72.30507760633668 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark38(-7.854019009141908,-2.2250738585072014E-308 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark38(7.888609052210118E-31,4.3790577010150533E-47 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark38(-79.06368573319847,-33.1315209644351 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark38(-80.2224323948389,-80.2224323948389 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark38(-8.881784197001252E-16,-100.0 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark38(-89.97358779125923,-76.60727656775757 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark38(92.02178988279417,0 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark38(-92.35918533806522,-16.344548515047606 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark38(-93.23751655302424,21.049692890081843 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark38(-93.37584024559689,-78.07211097417871 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark38(-95.1818158222078,-95.18181582220781 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark38(-96.28615604196824,0 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark38(9.691807666962845,0 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark38(-97.59599863005832,-97.59599863005832 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark38(-99.92698781241738,-1.3829372989223145 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark38(-99.99999999999997,-100.0 ) ;
  }
}
