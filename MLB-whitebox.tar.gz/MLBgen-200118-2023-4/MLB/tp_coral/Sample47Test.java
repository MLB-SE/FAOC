import org.junit.Test;

public class Sample47Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark47(0.5092678411911464,-39.67979538552433,-70.67869022965623 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,100.0,0.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark47(100.0,-100.0,0.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,100.0,-100.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,100.0,100.0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark47(100.0,-100.0,-100.0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark47(100.0,-100.0,100.0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,100.0,-1.494140625 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark47(100.0,100.0,-1.494140625 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,-100.0,-708.9734576799914 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark47(100.0,-100.0,-746.8965743067218 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,100.0,746.9783412943756 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark47(100.0,-100.0,-749.4184826819217 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,115.20154514954521,-730.2128139276467 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark47(100.0,-13.10007683178543,-709.8965174354836 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark47(-100.01702143005726,-645.9829785699415,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,-621.8402393431909,-100.0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,-633.4275822509074,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,-645.4753385937361,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,83.30645742953641,-709.8668204820074 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark47(-105.13540723772034,-78.559709237145,-746.0022091348827 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark47(-107.00529466496786,-640.9193436966293,88.25575543607462 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark47(-110.30745038618531,100.0,-40.19140625 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark47(-11.530487406399885,-62.16361212525354,6.7729130689656785 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark47(116.68811737102097,636.4373221878196,92.5818174740127 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark47(11.927424255342668,-77.15089561989602,0.0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark47(-11.944754445019129,-38.97901036310807,-709.0757343709221 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark47(-12.136973945838818,79.75110559989272,84.85195341688919 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark47(-1.310806107920044,13.347692699856267,55.688845787159636 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark47(13.23309279736165,-45.86232149106528,-729.5010849130285 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark47(-136.69019631435734,-572.7996147784864,-65.7704940428363 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark47(-13.670508206511627,13.670508206511627,-4.595833023886868E-17 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark47(-140.13067445114305,-569.1143037691137,-709.5799448514824 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark47(-145.38420450900182,-563.849862202016,-709.0840268358797 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark47(151.44295951670108,-100.0,-709.1407547241968 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark47(15.272728446308165,-99.14888650793503,12.80438845502168 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark47(153.19390081079052,-30.431463402543372,-745.7335569902323 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark47(-158.75753342042947,-564.4561173714019,-745.9035505384669 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark47(-162.38407134896917,-546.9232449560633,0 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark47(-16.501551588181698,22.192985561949797,47.589074629531694 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark47(-165.21368561044585,-544.1663133831137,-709.1774666905386 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark47(-16.548955507995124,-32.92329235857676,-709.5737997690128 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark47(-165.84076997079507,-580.1592300291919,-749.607652625208 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark47(-170.6877923574574,-575.3122076425426,-15.856197539452793 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark47(-17.14734279038265,100.0,-709.9586518507786 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark47(173.45764455951704,546.7004661397204,-40.19140625000001 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark47(-175.47118083670415,-534.1932183712358,0 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark47(175.78477630339515,552.8076179508898,722.4723040316924 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark47(-17.685631682234316,-37.44807012071062,-709.5807450649814 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark47(-178.1456265748792,-530.9214042241371,-1.027483026809513 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark47(-179.83032686990884,-529.760022048718,13.67406436820427 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark47(18.224068568248764,-23.93304827472943,0.0 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark47(-182.88595912144334,-563.1140408785567,-26.721242294731965 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark47(-184.1118728741642,-525.2418142013216,-40.165713280181755 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark47(-189.6759280847302,-556.9696248612051,-709.3320969230931 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark47(-19.00367036230783,-74.94867497019212,-709.7566147041279 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark47(-190.8130159941339,-555.1869840058661,0 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark47(-191.6425624144756,-517.7795590471641,-709.7719193438203 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark47(-192.1566392263052,-553.8433607737105,-710.8654575178113 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark47(-193.4910803686018,-516.1768724806927,0 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark47(-193.9210356489753,-556.1329412699369,-2.9259820693017957 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark47(-195.3947914668092,-550.6044305486674,-711.0121851563521 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark47(-19.69335337030165,19.69335337030165,0 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark47(-197.80213251470767,-511.3821922240145,-709.9592162623294 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark47(-198.84842241883348,-547.1515775811661,-0.3301663305936984 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark47(-19.894104055248235,-71.03215412627439,-745.5994017976271 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark47(198.96765993566675,520.8761694365485,-719.3742413090025 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark47(202.76411786148893,554.8793517913039,-3.0000265824684735 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark47(-20.746042351002544,82.09490998473024,-717.1326812643443 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark47(-210.55662313909724,-567.0324881212844,-745.7638574089575 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark47(-213.1059527136392,-532.8872312057243,-747.4893031179852 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark47(-2.135570214512029,93.37084421914705,-745.9999995292557 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark47(-217.76854678644682,-528.2314532138936,0 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark47(21.955634401074278,30.81959405614001,0.0 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark47(-220.66748374349913,-509.93358077650635,-745.6695774863614 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark47(-223.38698330194075,-519.3708832619106,1.4109192044531937 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark47(-224.33306795801983,-485.31432372846473,-3.594574304150435E-11 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark47(228.72182782200412,483.1045955595758,-709.0754334450112 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark47(22.92499020641121,-7.8035875242214985,-709.9805315766669 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark47(-229.34545641464825,-500.5619446383052,-93.6208585272654 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark47(-229.5998982982489,-542.9675706947909,-39.50842610394758 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark47(-230.82755685264914,-480.72785171204754,0 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark47(-232.89989045345672,-476.44913648220904,-709.965606728572 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark47(-237.64391609528283,-508.3560839047172,-0.8674184502266513 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark47(23.918184811826862,41.77153245599246,72.53741152455731 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark47(-243.63418922121687,-465.37195610968746,-744.19489561776 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark47(-243.9109872610968,-465.1291253880777,10.94051283604918 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark47(-245.4149456642632,-500.5850543357368,-75.45984285584419 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark47(-247.97152030204353,-461.0585013024861,18.89530691670491 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark47(25.067723359096927,41.09230736826418,0.0 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark47(-252.85612997624716,-540.9512276068853,32.87621320502135 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark47(-25.48611099893246,-18.535644523631476,-33.847437308643364 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark47(256.46227196224686,462.8123262360406,-741.1988407749262 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark47(-257.9200651063675,-488.0799348936326,-97.60099537832161 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark47(258.077579596297,474.2454637634931,-794.0535772406922 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark47(26.206332223409404,52.9644521855175,0.0 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark47(-262.32130400749026,-483.6786959925098,-1.4943423752305722 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark47(-263.076452305031,-455.70858521218247,-3.1403341362435373E-21 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark47(26.44992876078483,127.76041389890304,-745.7956823220642 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark47(265.85444954306433,447.18255423517587,-100.0 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark47(-266.56871866661606,-479.43128133338394,-100.0 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark47(-266.86049361513307,-479.13950638481816,-1.2790111029055E-6 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark47(-26.74165488053835,-24.968658790420832,-711.9999132313827 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark47(-272.8703628468651,-517.7605214360896,-1.4941528264347936 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark47(-275.69536483928937,-443.79440824658997,-745.3638680242243 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark47(278.81781125881747,436.12010227979897,-745.5586664577314 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark47(-280.52402799717584,-428.52405725315276,-709.9503041291057 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark47(-283.7385017563872,-425.71580974546265,-757.3775303952686 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark47(-286.1736177453644,-517.0889938050599,-1.0210029476294697 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark47(28.755299500937042,-57.09033825991423,0 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark47(-288.614412763357,-420.5933603661595,-710.7138138000515 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark47(-28.900628038148895,51.540638191933,-78.65425753084764 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark47(29.0002861085588,19.63423966587926,-40.19140625 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark47(-291.92616458039447,-418.02304330209586,0 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark47(-293.19174719117984,-452.8082528088201,0 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark47(-293.3127487426615,-416.64425128713356,-711.0884414714221 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark47(-29.35009590702097,-90.57277780736916,-2.94808536484976 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark47(294.97931624717387,475.87822058984807,-745.3455235245345 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark47(-295.26197538614036,-450.7380246138597,0 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark47(-295.3690810472266,-437.2360099089398,-745.5396292553561 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark47(-295.978883247824,-453.7469683038988,-709.6866721402055 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark47(-298.7859830789935,-410.8131672363631,-858.3088953822664 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark47(-303.75922930283156,-442.2407706971685,16.941442041231 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark47(-304.10480878555205,-503.74756557416254,-745.3659829425875 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark47(30.41677905309527,69.26802354408656,721.7654488156894 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark47(-30.73491745183364,-96.83485022291526,90.56151904249558 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark47(-307.5352267864176,-401.7606954644915,-5.10709923085314E-15 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark47(-307.89422190541234,-402.54001399923413,82.57935270447615 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark47(307.9232108538142,446.00600130676526,-717.2267595812375 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark47(-309.93178739375736,-399.7508959077115,-745.9692223381171 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark47(-311.1157265571197,-436.41158149114204,-709.1111128750636 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark47(-31.181669225291103,31.18166922529111,-797.1353555970701 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark47(-311.88621217228604,-397.2751914600567,-747.6261486819426 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark47(314.0199790394841,453.6004066453345,-709.5737899151837 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark47(31.428897136128768,-143.01509014285213,-709.3702966785271 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark47(-31.492913862281682,58.07817697043777,-741.2866689108419 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark47(-315.07266385857696,-430.927336141423,16.381312565355984 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark47(-321.47405429058625,-419.79898981069863,729.3887289498798 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark47(-321.65088943688767,-387.873394398869,-709.0609891946777 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark47(-32.18558394015882,86.64827061584924,58.34350941161307 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark47(-323.9988732149737,-448.65636343256193,-709.7022566513011 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark47(326.6298498446233,492.148142851899,-1.0838802730887331 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark47(-32.853877599851145,-7.337528650148856,0 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark47(-328.96039044905365,-421.8897218953237,1.4262080046296846E-18 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark47(33.05569018954654,-48.6772221396991,-710.5530177365705 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark47(33.13630797823379,98.45591645111594,-721.3611065320738 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark47(-331.58213895524284,-426.10717539639563,-100.0 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark47(-333.53318576901535,-437.6760420991371,-709.256533828905 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark47(-334.08427394960074,-395.9435176344949,-729.775311814031 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark47(-335.8533767625283,-379.04230475914386,-53.68087670645778 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark47(-338.8011613822872,-392.0488717649509,730.1801401640239 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark47(-339.31738932008216,-382.42313188743856,-716.879708091642 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark47(-339.992720639596,-369.12480632779545,-735.4853403665362 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark47(-340.8294258606952,-482.69944730211495,-717.8272229549109 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark47(341.25225322624544,427.7175767983179,-709.941216050734 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark47(-341.3137052939369,-435.7877867838863,100.0 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark47(341.5522622819136,411.906066532647,-94.88460135141699 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark47(-343.56353394008954,-366.0286732123691,-40.19140625 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark47(-344.34412409386204,-364.00003982593313,-8.590895668116567E-18 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark47(-347.4193128976193,-362.50572391463214,-765.4086869003277 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark47(34.89423737714752,-34.89423737714751,0.0 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark47(34.95730407423855,108.76224314349992,-744.441676640602 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark47(35.05441169055371,-35.05441169055371,55.21030445815717 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark47(-35.10852524158766,35.10852524158766,720.4370481789167 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark47(351.61232690967245,390.4848995010041,-100.0 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark47(351.6767765058376,373.3077286971218,-706.3121748198528 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark47(-352.2199320520465,-356.8010099308324,75.690784194548 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark47(353.0708754246849,392.31898831858996,-40.163668869503 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark47(-356.9893457380709,-456.7244374006705,-711.4192210654433 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark47(-357.6133825754806,-351.8574608364962,-13.146063705589967 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark47(358.15702993033074,354.76017669827996,-8.919318189508104 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark47(-358.75481414871916,-399.7314352378572,-723.5927023620713 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark47(-359.9042642954652,-349.2499635278474,-709.7661225945856 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark47(-360.8755688794824,-385.12443112051756,-100.0 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark47(-362.86624555906724,-377.56214005486595,-745.9999999999999 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark47(-362.90489451945285,-378.53362736595824,-40.06661041784436 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark47(-369.3661081549585,-344.82003195770005,-755.4874302554239 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark47(-369.6722524082894,-340.22735914833305,-714.9870756656674 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark47(372.3523038796566,394.0135211548575,-711.3409742318934 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark47(-373.059629127044,-336.1785873212408,747.4126827779414 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark47(-373.3866255230332,-342.8361944351367,0.8646865768731544 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark47(-373.60135559419314,-372.3986444058069,0 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark47(-375.62628851858767,-333.9218566625453,0 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark47(-377.22858229025115,-342.0405638835212,-1.5624166606875747 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark47(37.805565947180554,66.85013694899112,-750.5315514279803 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark47(-378.63382482173193,-339.9573313568253,20.558544972684302 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark47(37.898088823086425,-45.88395387683679,41.57915260721623 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark47(379.3231674605941,396.6325598899498,-1.4943255633547745 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark47(380.3173403866481,408.83334773278887,-709.493219520007 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark47(381.1690832337112,347.6928107870353,-31.68918857103216 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark47(-381.8166240123539,-364.1751041332437,-746.0000000007637 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark47(-386.07381549106,-323.30688445462863,-1.4941406250000036 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark47(-38.62646429752623,72.19991935652311,-53.968856560847314 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark47(-389.72245370733674,-394.6662186259233,-737.9681533576247 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark47(-391.28575180876345,-370.2140863138695,-40.19140625 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark47(-391.5604675394441,-354.43953246055486,-6.386630399229816 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark47(-392.0269150759911,-348.22604531556357,-757.5313624192939 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark47(393.1011736209698,365.21046301016025,-745.1762340560584 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark47(-393.12306881617945,-356.54181455761375,-711.9502725406801 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark47(397.2755343001653,379.7302182978151,-709.3701061591569 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark47(-39.80254537536101,82.0525477353547,-34.56686284918521 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark47(-399.9149489159589,-309.5205368484836,-746.0000004058517 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark47(-402.6082321826004,-344.42853384865003,-709.9750144224829 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark47(-404.18038681783935,-304.9707118772313,-713.3270979458455 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark47(-404.32013003007324,-304.7227833032539,-745.998007257774 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark47(-404.63283645075245,-304.4489972435373,-64.77846166475913 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark47(-40.46351728074009,40.46351728074009,-35.736139566125175 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark47(40.56263323825203,71.8670677688306,-39.78302557843192 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark47(-405.86958535097847,-305.4315527092059,-719.9565321030948 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark47(-406.00953390360763,-337.52036755109407,-729.1016718892197 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark47(40.683747973370956,-40.683747973370956,0.0 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark47(-4.07619252061609,-9.863949534355143,-94.6300967324929 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark47(408.4972957841988,308.56464028382186,-5.516115843644924E-4 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark47(-409.2025697373777,-320.7545797777179,-742.9418436682843 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark47(-409.61366905697736,-336.38633094302264,116.61134860375495 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark47(-411.3921266102953,-298.06552560635043,-17.28571972890292 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark47(-412.9416434054123,-341.1306905683614,-709.8132631985005 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark47(-413.549147727503,-351.48092805164663,-745.9987462592131 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark47(-414.1305626374773,-370.26723971746776,-12.488989004118494 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark47(-415.8867222822894,-293.3138453537529,-726.0805803424679 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark47(-415.91379859311843,-293.529275144226,-100.0 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark47(-417.6545695642767,-291.95520500537674,0.0 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark47(-41.80429536059857,-42.2683859610002,-5.3322871989458065 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark47(41.84085531463873,83.48052502217308,0 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark47(-420.8298315918555,-324.17807320375334,-711.2027262157004 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark47(-421.752393129832,-324.24760687016806,-17.229197424960546 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark47(-422.97599080619307,-286.7942344380541,-70.75838587509564 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark47(-42.509471510646335,42.509471510646335,-1.274450305978121 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark47(-426.0695750994458,-319.93042490055416,-61.73459653757054 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark47(-42.6129825876404,42.6129825876404,-709.9686524434866 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark47(-427.3590038411916,-287.14569500111224,0 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark47(42.921761141746885,-42.9217611417469,-746.1460317268886 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark47(-429.4772310640763,-357.4822328702353,-709.7524971700503 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark47(-430.5358174415125,-280.4620811163571,-57.92909362454244 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark47(-433.2837198675331,-371.73756308911237,-732.6090036572581 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark47(-433.56880552590616,-299.3569113085195,-45.90758833931608 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark47(-433.72026586788144,-295.1309200076457,86.44118147351841 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark47(-433.98829789427253,-427.243231249721,-708.5238386098117 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark47(43.45771718379672,-8.073891043262037,-709.1161369081034 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark47(-43.721936195139556,46.109729659364746,-67.83281352754906 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark47(437.79990899036443,289.1869901526422,-707.687035723079 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark47(-439.1487695492545,-306.85123045074545,100.0 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark47(-441.20763567499563,-281.2417617810043,-780.2042873045708 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark47(-441.7541584725997,-267.5954505722625,43.138136850852646 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark47(444.6504290725451,286.38564324383674,-745.9865338546659 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark47(-44.587317124299666,-43.26088543686917,0 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark47(-448.85467757640066,-319.520914792096,-709.260518082685 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark47(449.80626912185085,280.9697247645454,-709.9116247584919 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark47(-451.2839911708143,-274.51526190355384,-723.5166067997675 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark47(-452.1003569553897,-302.4925591684788,-745.2817377386319 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark47(-45.270863923885976,-30.248181991405758,-709.6879870583083 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark47(-45.618678169644426,-11.831796045312458,-709.5877395971347 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark47(-458.3047960676436,-287.6952039323564,-45.596733094416834 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark47(-459.5609245570802,-296.19407266269417,100.0 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark47(-460.9454351852614,-285.05456481473857,0 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark47(-461.890152958597,-264.6058158562021,-44.962103993333535 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark47(-462.3466704786257,-279.5358638685133,-809.758996482274 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark47(-462.6178965309587,-254.59275675100466,-716.6101164990325 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark47(-464.1705559819196,-271.84094152218756,-40.19140625 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark47(-46.55292779852189,-13.22867860267489,-750.8064385005961 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark47(-466.60073768805563,-314.6178588391466,58.53695345383093 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark47(-466.8842107374502,-279.3071955130804,0 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark47(-467.5001070159187,-278.4998929825329,-873.7606172767977 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark47(-471.6299061397328,-283.71874004790766,-709.1427700078617 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark47(47.38720996493717,59.26697586518159,-86.53376156627746 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark47(-474.3055104716172,-336.53273475858555,-717.1120178386901 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark47(-47.56290409698968,40.18322468057485,-1.494140625 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark47(-476.6909150678315,-269.30908493216845,-1.0008748993054866 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark47(-477.61538557604626,-232.67804423884493,-708.3021648418802 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark47(-47.83270111350242,7.67231236519639,60.74377128617573 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark47(-480.41512120719807,-229.58002930632045,-100.0 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark47(-48.1453704178336,84.91563312431492,-750.1216994706763 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark47(-484.29373218808473,-225.3787139744035,-709.8344696696934 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark47(48.53236601145816,-88.72377226145815,0 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark47(-486.4603627052024,-259.53963729479744,-0.16932918097595295 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark47(-488.00842072069145,-221.88310290933015,733.6313143861837 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark47(-488.53876504055455,-257.461234958503,-796.9735968674693 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark47(488.95056358637186,246.14381667914824,-708.6629309312348 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark47(-490.1086376020746,-255.89136239792535,-95.25126988672979 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark47(49.11142107203838,-49.11142107203838,0 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark47(-49.415528670469854,26.820431587670825,-13.29802557061845 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark47(-499.0233272399733,-269.2030177601498,-11.843405226620547 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark47(-50.004603481225644,50.004603481225644,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark47(50.173202882384004,84.70829739492919,-34.63299672365065 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark47(-504.8941216478693,-289.5670602236346,-746.0000820598381 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark47(-50.50772994027799,8.229182141030433,-40.17236231623988 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark47(-508.00560353689104,-360.2905083007041,-709.101773242569 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark47(508.6424191286502,347.6148169389264,-709.4547573552122 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark47(-512.5843550889184,-197.24516716761818,-722.2700178426443 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark47(-51.59700965921934,1.083423386245613,-52.18314513606863 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark47(-51.87324385616914,-88.70621063195773,-716.298091714199 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark47(-52.454273350592764,-26.179327812381132,52.75181044996529 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark47(526.6675553950723,198.68510002042615,-728.511802199413 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark47(52.83905103743584,15.611318602155833,91.66586109592544 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark47(536.9263064003536,176.9418825638224,-2.5992698268506107 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark47(-539.0371234994097,-170.84297754492587,-709.3245822217764 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark47(-541.7748373829617,-167.63037812872895,0 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark47(54.28802728525349,-18.536954250694365,62.91999709673513 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark47(-54.63350583408329,-99.17270463022724,-87.7174070370859 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark47(-547.1739437642306,-220.7572785045931,722.0563080615013 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark47(54.72618644956606,-46.546622739719304,-1.372848129781497 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark47(-547.4400298743294,-198.55997012507933,738.5369968249248 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark47(-54.74418343405547,-70.91609683984991,-709.968915152193 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark47(54.917014494203954,63.358511016673276,-709.2557263367008 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark47(-554.3063900437164,-155.01144485616237,-711.0801383971103 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark47(-55.55233480655517,51.954650228326784,-738.882963813148 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark47(55.99926241734035,-55.99926241734035,-1.4919189217087812 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark47(-56.3862564410827,56.3862564410827,-90.12782048527664 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark47(-564.298410570545,-146.52101938961857,0 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark47(-565.7726733136162,-180.09004329081858,0 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark47(-56.741396289542,-23.7158103875787,0 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark47(-567.6417987536421,-179.02088486227797,-717.3910917336625 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark47(572.5975467297044,165.1357630856223,-746.0000000008429 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark47(572.7646086311792,191.85079112759345,-709.8679716442025 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark47(5.752956076678785,77.64668542185237,-709.3812764242107 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark47(-58.922173336831584,97.98906743697773,-728.2406556568958 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark47(591.3620740892098,169.79526691371257,-708.9907559919221 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark47(-591.6369277173279,-154.36307227336692,0 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark47(593.0959997866863,154.81674399738947,-708.7238146835355 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark47(6.0034611328461125,16.675741003783102,0 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark47(6.048147579547077,-69.77442925054228,-1.4941406249999982 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark47(-605.0738065796105,-168.5221060153743,-2.585173022626819 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark47(605.1900390808105,116.40316591871706,1.862466966076397 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark47(-605.8170585751927,-140.18294142480724,77.68713305040066 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark47(-609.7642985331013,-100.0,-709.2491853600991 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark47(-609.9538825683906,-100.0458521081117,0 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark47(-61.12193448693854,88.89934876184509,-60.36455034961969 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark47(-6.1465667043168395,-49.09353716788048,-10.819864628950839 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark47(-615.0016196910343,-94.99838030670774,0 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark47(-61.93379321103232,59.49151787852506,-803.1407843867073 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark47(619.4548166274744,95.43457000658921,-745.9085332760595 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark47(623.5541384141957,100.0,0 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark47(-62.561011129741445,-647.0860924585951,-745.2617852719048 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark47(62.80083627249353,-62.80083627249352,-727.1455137122118 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark47(-630.0278439582688,-79.49823071646819,0 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark47(-637.289293306873,-138.07521829517867,-100.0 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark47(-638.8709327425961,-152.83219908229418,-780.0611008269817 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark47(-6.4110905017517865,-57.91063232845375,0 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark47(64.11705776291424,-22.042092513428102,-73.89333356981349 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark47(-645.9999999992664,-100.0,-709.1391532799881 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark47(65.09476803084985,-78.69102415348482,-708.6279921811563 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark47(-65.25717187579924,-14.159340824540223,-71.44504604581962 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark47(-65.41989757583221,-680.5801024241678,0 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark47(-657.2796156407148,-126.98334620514274,0 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark47(66.1531483092662,100.0,0.0 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark47(-663.7425011994709,-82.25749880052908,0 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark47(66.37458697408559,-93.14692853857866,-716.125586053414 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark47(-666.0497019483784,-80.1417043016216,0 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark47(-666.6882983300819,-51.95891065335216,0 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark47(6.6816675015813445,-28.807470102373614,53.94153566981271 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark47(67.07032282962604,-94.6711070586517,37.79656949957544 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark47(67.36370650817364,67.00329328872485,-741.6675179079307 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark47(-67.68059505105595,87.21689391851211,-745.7015626872726 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark47(-67.69695560660546,-14.062979463762716,-744.7800946734915 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark47(-68.77716768692271,-40.27309706562838,0.0 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark47(-68.83460513817097,68.83460513817097,69.82529962007806 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark47(-68.88488972048421,55.91689952739313,52.716952625850155 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark47(69.02286264401994,-21.83765215262632,75.31397631563135 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark47(-69.60464531200721,-63.21257984850168,-760.0341688873262 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark47(69.75364610195746,95.3594509194372,726.1874503666592 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark47(6.989897544548285,-47.181303794548285,0 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark47(70.40795571309405,-29.286379186575346,-709.1360644954339 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark47(-71.23809956785118,3.71008528880688,-40.036816563520205 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark47(71.37093560290083,-42.99050801280544,-44.93603419285171 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark47(-71.89728672605254,-10.098515463696913,0.0 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark47(-72.07209462590956,-18.350216339626204,-709.8394843107076 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark47(-730.6427059014559,-47.66563631871132,-2.65110054777999 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark47(73.1136943538688,-97.35487897058962,-708.1680962274133 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark47(-73.14829693406688,-13.689138976194258,-714.7992532964929 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark47(-73.8964020355502,100.0,-40.05917145311877 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark47(-75.01740863485055,75.01740863485055,-28.29964155600571 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark47(-75.69816167980287,-5.542774227160564,-709.9136792243318 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark47(-75.82550704645128,-73.68585790264544,0.0 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark47(-76.32739622471169,74.83325559971169,0 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark47(-76.79914177644082,69.7336011805921,0.0 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark47(77.10453110356764,78.08944386132,0.0 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark47(-78.49651790776788,68.09380235587662,730.1698922873411 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark47(-80.6256810736522,63.15370322522125,-35.851318786177984 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark47(80.72736479680381,52.50896514236129,-64.26858940556093 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark47(80.91869956281826,-80.91869956281826,0 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark47(-8.258929820086507,-44.54850795965113,-2.98828125 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark47(83.17370491912129,29.52455860734949,-73.38772799261895 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark47(83.73376637154993,-80.52252989721582,-708.2502138778782 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark47(-83.90654131698281,-15.4986688154261,-16.361515257698528 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark47(-83.93063007196986,-31.86678408421122,712.9922813045796 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark47(-84.89125879784004,84.89125879779994,-816.0923264486233 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark47(-85.40996595603873,-49.776127463764304,-708.6180255697237 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark47(-87.76549793949572,-622.2345019946164,0 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark47(89.84370112234384,60.78350096146863,-709.310598126401 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark47(-89.90451258339448,49.713106333394485,0 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark47(90.34209257669599,-71.63598625033461,-717.6126449444706 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark47(-94.0451864906692,-17.600692610569823,-708.4894691976307 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark47(-94.13740468729954,-23.58805780810249,10.63228507848855 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark47(94.1534597078975,97.65323503203948,-708.7625933687663 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark47(94.44637673690433,621.7752220853091,78.48976033811732 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark47(94.92110884326308,-91.43345097086197,-766.6599830604517 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark47(-95.22279995912002,-4.765620649084255,-768.1823784195086 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark47(95.67387958801979,-83.8349975792429,-713.9898316689421 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark47(-9.57135437896028,-44.555930535797295,-709.8805168681283 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark47(95.76009566329284,-71.42972360129276,99.19880975645091 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark47(95.86398272529287,-97.3291469389498,0 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark47(-95.99158252617373,-84.64149089411205,-707.4968568692775 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark47(96.44226983321649,-96.44226983320836,-709.1455857634005 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark47(9.65260572885516,-9.65260572885516,-750.1777124838901 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark47(96.54647621680792,-184.7121097174783,-745.463136818151 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark47(96.66587892831447,-73.25582149085662,-709.7992138840111 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark47(-9.716900508918663,-100.0,-744.6451351930232 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark47(97.22401287392796,40.19464663565005,0.0 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark47(97.71437317367777,-100.0,-709.604937295277 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark47(-98.06012026130928,-18.56940075485258,-728.3686949973096 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark47(98.19069333961107,12.142237604179854,62.51740959626795 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark47(-9.92924146861894,-84.79492284180084,-709.5640052927498 ) ;
  }
}
