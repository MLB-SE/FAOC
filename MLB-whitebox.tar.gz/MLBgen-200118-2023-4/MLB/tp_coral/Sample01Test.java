import org.junit.Test;

public class Sample01Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark01(0.0015995410986130885,6.2265757307144085 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark01(0.004968009745441265,69.21477628299556 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark01(0.0074132599032182825,-44.38775417391123 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark01(0.00845822876148361,-11.721925179852596 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark01(0.010275512454296847,-37.5556251802157 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark01(0.015300457030674643,87.7894372260246 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark01(-0.01692808119473041,16.34758315964872 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark01(0.03220275311028155,44.23674547061112 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark01(-0.040102935466643785,67.60159889722394 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark01(0.05693733279233226,-88.3058298040061 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark01(0.05938781694424483,0.3997945479993402 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark01(0.07138618314526102,0.379974040753024 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark01(-0.07190920560333612,1.5707963267948966 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark01(-0.09091577580949473,1.5707963267948948 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark01(-0.12214534909076141,68.59176439795164 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark01(0.1298479933001747,94.58880886119579 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark01(0.13302085974149946,-49.59715319938934 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark01(-0.16679358877358652,1.5707963267948961 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark01(-0.1959788681556507,-34.09376362729894 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark01(0.1995280784802702,-31.83412935626623 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark01(-0.20819524828423908,0.0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark01(-0.2082958517768361,94.3255269110039 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark01(0.21453273240964688,9.814517330565856E-7 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark01(0.2159560426385223,-89.75943718453479 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark01(0.281462227621541,1.5707963267948966 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark01(0.30565764059520006,-19.34109901375382 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark01(0.30852234762659236,-4.0610314506371084E-8 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark01(0.3093538502847903,-99.19274085514532 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark01(0.3115662417723699,-13.370900331836355 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark01(0.31474738382300416,-26.318091810202617 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark01(0.31939108170881525,-36.856190915944964 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark01(0.3231741737916844,-0.047456287983569885 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark01(0.3284816667444202,-70.18658813477295 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark01(-0.34510902328253545,12.575082877254019 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark01(0.34843397159067657,75.97741190411253 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark01(0.3525038337665548,1.5707963267948966 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark01(-0.3556817055698396,-16.83778666191766 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark01(0.3599390764191326,-17.278759594743864 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark01(-0.3609929040012451,41.50997653729115 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark01(-0.3620283867418266,-1.5707963267948968 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark01(0.3649922200744591,-0.07398957323905395 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark01(0.3652411960800208,-0.4052819824714007 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark01(-0.36735235360761603,1.5707963267948966 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark01(0.3865166331402148,37.71839486759448 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark01(-0.38668954498985886,48.69698625797447 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark01(0.3916237525185551,-68.97797049880799 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark01(0.40236766218846887,62.23612187057549 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark01(-0.4084189159880015,-67.4526131249199 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark01(-0.42556362539758497,1.5707963267948966 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark01(-0.4279420253690892,-1.5707963267948966 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark01(-0.44982809765599896,0.0 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark01(-0.47084194623251485,53.11825871823916 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark01(0.5075753739133186,-2.0746410862020455E-17 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark01(-0.5108780244651989,-62.4158580725692 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark01(0.5168206736596095,49.11791198726817 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark01(0.5210656937507743,0.0 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark01(0.5224633859495675,0.5407199258497989 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark01(0.5238576435124181,101.75913932434759 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark01(-0.5438426147976827,-89.78591823642986 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark01(-0.5558352099004003,45.634261188621466 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark01(-0.5628561100113288,18.619129765604725 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark01(0.5660482326378116,45.543225181452584 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark01(0.5710826488417521,0.0 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark01(-0.5726282218543028,-72.97614372373144 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark01(0.5744376544410583,17.108741336643575 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark01(-0.5837563983136074,-27.006828593480336 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark01(0.6005959055142787,-95.36868668690491 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark01(0.6159386309464756,-31.812892989038104 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark01(-0.6273130693540985,0 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark01(-0.6396494820836895,26.293114516116447 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark01(-0.6430108567283241,-0.2032389067978694 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark01(0.6508863669208704,-1.5707963267948966 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark01(-0.6561365575687361,-20.89947338960097 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark01(-0.6581911125807682,108.24222977113519 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark01(-0.6768503058568172,-79.59308775972482 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark01(0.6836721142557514,98.26901904966695 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark01(-0.7196627340798898,0 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark01(0.7214039692808907,-0.021341241021962196 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark01(0.7248319513055236,1.5707963267948966 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark01(0.7284180573888758,-136.0963252664041 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark01(-0.7340515290616185,9.573218050242684 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark01(0.7353926786953369,2625.1009401129195 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark01(-0.7473085191907103,-2.9223811295983437 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark01(0.75757931176553,37.29035465566136 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark01(0.7635730731711563,71.37916782280848 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark01(0.7854645357995659,1.6612818399233757E-5 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark01(-0.7901221735523338,63.10668923928377 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark01(-0.828223587815188,-2510.0715384191676 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark01(0.8433170954445401,35.05201494942125 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark01(-0.8978230988131131,-100.0 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark01(0.8979349231525049,13.265434230152962 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark01(0.9153492714742586,1.5707963267948961 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark01(0.9208924940745725,0.0 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark01(0.9230944135475967,1.5707963267948966 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark01(-0.9387387539011101,0.0 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark01(-0.9441468720798668,11.150980595556103 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark01(0.9618889730133784,0.0 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark01(0.9649738788871787,56.358249691279624 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark01(-0.9757010610842514,-1.5707963267948966 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark01(-0.9787367912047831,-1.5707963267948983 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark01(0.9832614946879943,1.5707963267948974 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,0.0 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,1.305405553409627E-16 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,-14.429674040540235 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,-1.470588518096549 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,1.5707963267948954 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,-1.5707963267948966 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,1.5707963267948983 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,1.5707963267949054 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,-2615.9272163276937 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,-30.55976637169274 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,31.507275132819316 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,-51.59544288723188 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,68.53594178621091 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,-74.343691190983 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,87.10385556409294 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark01(1.0009359540216085,-1.5707963267948966 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,-98.96255506869547 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark01(-1.0023676138356872,65.80252426980911 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark01(-10.030304901105403,1.570796326794897 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark01(-1.0035575465362827,0.0 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark01(-100.52844004282517,0.0 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark01(-100.92167137555727,-86.94756879650546 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark01(-10.131687776017003,-43.90880781418629 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark01(1.0180648283796576,-1.5707963267948966 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark01(10.193106214733277,-0.9111694631400529 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark01(102.00052760760931,-49.61007597356279 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark01(-10.232952437353077,0.0 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark01(102.96410997283826,-69.7435074783408 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark01(-104.61922814099745,0.0 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark01(-10.52086536543581,1.5707963267948966 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark01(-105.24335381639361,67.54423946591146 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark01(-105.43802650011213,47.65303636137787 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark01(-105.6930636940218,48.794277301515216 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark01(-1.065531164756776,-1.5707963267948966 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark01(-106.82311388907019,-45.55333761767863 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark01(-106.86873911855778,67.54424204828442 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark01(-106.92778426995372,0.0 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark01(107.44818349988897,1.5390670535232829 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark01(-1.077885504085754,-1.5707963267948966 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark01(-1.0842021724855044E-19,-36.12831551494597 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark01(-1.0842021724855044E-19,87.96196445987535 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark01(-10.889933375907884,-1.5707963267948966 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark01(-108.95300659943598,95.4666929301944 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark01(-10.912518719050738,75.80842699906034 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark01(-1.0916893412129696,85.10622898512571 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark01(1.0929690448722846,-43.75477821833318 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark01(-10.94750232856947,72.97999997448406 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark01(-10.96033137408931,-1.5707963267948966 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark01(-10.994348584429801,17.27875942789367 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark01(-10.995575280745994,4.712385458170148 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark01(-1.1067996728087566,9.725175217185452 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark01(-110.92112815088963,-53.73035969186526 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark01(-1.1102230246251565E-16,9.884245975953331E-4 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark01(-111.12136502115226,84.24486280908329 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark01(1.112391493250506E-16,-0.0026298406389106107 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark01(-111.35353358576359,121.85080004905828 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark01(-11.135646609422409,5.769369678516753 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark01(-111.37661899138915,2599.968536887488 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark01(-111.52652378452909,1.5708001414921637 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark01(-111.54172628708073,4.712388980376733 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark01(-111.54324075204855,-36.128315441403764 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark01(-111.72176582332173,1.5707963267948966 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark01(-111.73560977266963,1.6103557737017515E-16 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark01(-111.85984053965069,66.66725446078341 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark01(-111.93404560914625,-70.82331715476131 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark01(-111.94606728007533,-38.28153655590124 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark01(-112.53855913493872,-119.1750961465861 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark01(-113.15983553343008,-6.223580364798287 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark01(-11.367306696139082,-72.5885282316406 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark01(114.66729983350677,54.97786926085471 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark01(1.1522595044936161,42.19883336864878 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark01(-1.1648708524681177,0.0 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark01(-11.672686347983776,1.5707963267948966 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark01(-117.04295835868396,42.69513023837284 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark01(-117.80962691404932,45.55504660263869 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark01(-117.80972470713566,-259.182370557166 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark01(-117.83492349144554,19.411067236095878 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark01(-11.796090198981432,67.26863229807971 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark01(-11.808085213310946,-39.2303258500406 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark01(-118.22405812649814,-89.54277906979388 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark01(-118.32881860508262,70.60181575324489 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark01(-118.46731156790213,-97.89912896783291 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark01(-118.84816445998784,-36.183838904952616 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark01(-11.893472101072833,-0.47354649841744806 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark01(-118.94051863461806,-0.11094252059598375 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark01(-11.90590981915551,-20.792735835297975 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark01(-11.929206003612222,1.5707963267948966 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark01(-11.94537047600626,0.457410932668949 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark01(-1.1976132532424373,27.254023672313735 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark01(-11.996111880696303,-1.0926320275551076 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark01(-1.2050934703457415E-13,1.5707963267948968 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark01(1.2102844560298083,-42.48802393175944 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark01(-12.147134839321978,0 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark01(-12.16522015106584,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark01(-1.2191621570005076,-0.5414017430724899 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark01(-12.21934734113377,-52.32697796007617 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark01(-1.22201892860972,1.5707963267949054 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark01(122.43354739989906,-15.679270850171648 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark01(122.49727116562082,1.0214858524048123E-14 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark01(-123.22142061627014,1.5716915269599288 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark01(-123.35407836800664,-32.87881859131055 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark01(-123.70914845404022,5.212701248696934 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark01(1.238945554743764,0.3496962662010037 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark01(1.2392809685308075,-2557.251603024318 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark01(1.2395260310251062,0.29394773349950676 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark01(-12.406223682837652,-14.429228188620229 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark01(-12.408378536700129,0.56858378840741 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark01(1.2412189336040427E-4,6.429217141044625 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark01(-12.445677738392801,55.35104794824347 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark01(-1.2505357406755024,-60.83175373327889 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark01(-1.2522970516241227,14.429203827939887 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark01(-12.566370899802688,0.0 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark01(-12.56637156803349,-1.5707963267948966 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark01(-12.566407089417192,-10.995482021483921 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark01(-125.66651334433884,58.15321105720638 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark01(-1.2567394951765813E-12,130.3673547609273 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark01(-12.568323739359228,-119.37696390567194 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark01(-12.568323860597626,61.260762057774926 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark01(12.568333842683979,0.0 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark01(12.570836158045392,12.659187599886613 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark01(1.2575230206821857,-23.91392568609626 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark01(12.593692284445154,-1.5707963267948968 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark01(12.597620614363874,37.918700706759466 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark01(-126.010187418151,49.20892898871688 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark01(-1.261676327011074,0.19940058681841838 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark01(-1.2621774483536189E-29,-1.5707963267948977 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark01(-12.637489741441003,29.845117217332767 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark01(-1.2665244853221171,-1.5707963267948961 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark01(-12.720599854486792,-85.82688040413129 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark01(12.729914320221042,0 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark01(1.2751316097075336,0.0 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark01(12.762483213013269,30.840173484424042 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark01(-12.809728240929715,-1.5707963267948948 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark01(12.814996567555099,0.0 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark01(-12.860554509660417,-48.8853427990857 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark01(-129.02869024568653,83.04660585115673 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark01(-12.914309085391459,-33.183746941376505 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark01(-12.933268386376895,26.559491432070857 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark01(12.937024468017263,0.5707951688491743 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark01(-1.3053096368437176,-6.533533720997696 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark01(13.068963420470809,66.34930889045566 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark01(-13.103007144213237,14.137166941154069 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark01(13.109134661069533,0.0 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark01(13.124083818192261,-1.5707963267948912 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark01(13.133294702366854,-73.20784692481354 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark01(1.3154554124524527,0.0 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark01(-131.96251647412706,-43.98229713760617 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark01(-131.979602865151,92.67698328079982 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark01(13.234245143398283,1.5707963267948966 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark01(1.3270194083052047,91.77203826655224 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark01(-132.9401159631018,39.92720752266741 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark01(1.330000373364343,0.0 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark01(133.26142433857228,64.20292502770849 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark01(-133.90816870998356,79.46159039576828 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark01(-13.427611495842129,53.618964802169415 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark01(13.42815667781498,-0.5707929813531131 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark01(134.9791870754742,55.36462322585908 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark01(1.3507580047668775,-1.5707963267948966 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark01(-135.0871519266026,-48.6946860330164 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark01(-135.0884122099338,174.3583922741346 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark01(1.3525015502010758,-0.45068965006520323 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark01(13.525046752874959,47.919582834531525 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark01(13.550559917695264,-7.666185421939909 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark01(-135.7277581702815,-1.5707963267948966 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark01(1.3577035970596485,-73.8500470500232 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark01(-13.60875303134425,-1.5707963267948983 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark01(13.622398259228266,0.3855914439687732 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark01(1.3623654907476919,-2586.5189868466773 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark01(13.626561443230756,30.00193059004752 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark01(-13.75006403626898,0.0 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark01(-1.3752546086600272,-60.748076261951 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark01(-13.789877151647985,-0.2367831014073737 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark01(-13.808766741646275,-73.77388147736302 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark01(-1.384698124973524,-37.81387751457075 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark01(1.3848094972101475,67.52348489988154 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark01(1.3867518635791782,1.5707963267949054 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark01(1.386903610642917,-98.07491908411352 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark01(-1.3877787807814457E-17,-18.848277675587806 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark01(1.3905075129079927,33.95341856615764 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark01(13.914655398877025,96.9749225564687 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark01(13.934446192852867,19.35836472001153 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark01(139.4046085021523,93.7467131555536 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark01(13.970408851546495,-100.0 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark01(139.80087395016156,-39.270884733860726 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark01(139.80087690072477,51.8987787842348 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark01(1.4055894995619382,-1.5707963267948966 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark01(-14.071777742658128,2643.8476261196533 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark01(14.076714364419203,1.5707963267948968 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark01(14.08312519639182,0.0 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark01(14.091273028334841,-64.40159900095573 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark01(141.03534219725577,-71.64858224041235 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark01(14.134537169548393,-1.5707963269781118 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark01(14.135169610090617,45.55309495576146 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark01(14.136971898144074,89.53545166246536 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark01(-141.3702755199096,-73.82742727427474 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark01(-141.37166918326918,186.92476281799398 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark01(14.137166941154108,-73.82742383712065 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark01(14.139778662038449,4.712388932458087 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark01(14.202999210029759,-76.97972896562253 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark01(14.211194270651362,-2652.7419666856104 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark01(-14.221831210165575,-26.07534448547876 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark01(1.4237669720197914,1.5707963267948968 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark01(1.4287401430602609,0.0 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark01(-14.352400059460157,1.570796326794897 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark01(-14.374270716932187,0 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark01(-14.411620641814665,73.68703564050296 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark01(1.4435539491592173,1.5707963267948972 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark01(-14.439809887832526,40.11802790366184 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark01(-144.51523247676712,-1.5707963267948966 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark01(-14.464191262334964,-1.5707963267948966 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark01(-1.4466789574661274,-3.623913064098868 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark01(-14.485411755080534,4.71238898038469 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark01(1.4491700272768286,-31.610602130574634 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark01(1.4514953618902837,-67.01178060804479 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark01(-14.552404523386796,-19.413169092335423 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark01(-14.576321178498716,71.9725451323936 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark01(146.08406218346624,-186.92474588899574 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark01(1.4641655752586278,16.882924404608595 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark01(-146.52644073020855,0.49108862445620033 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark01(147.12897538554873,-74.30594841061664 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark01(147.5179618339588,0 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark01(1.4764629968581744,0.0 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark01(-1.4814955780241235,-82.52193112015307 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark01(14.912831761584794,-64.32838878531251 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark01(-149.2230212742269,-1.5707963267948966 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark01(-14.972282581189319,0.0 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark01(-1.497259482767845,-0.0011285574787731011 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark01(-150.218562005862,114.03078593969647 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark01(15.022793271294901,-83.61695790134766 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark01(1.5033104851558663,-89.68905300904643 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark01(-15.037544370489968,35.84208625225443 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark01(-1.5086634430987065,0.0 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark01(15.102596222219047,1.5707963267948972 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark01(151.2999630738671,36.99553538408554 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark01(-15.1314191740733,2667.0340652203236 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark01(-15.149422963971103,0.0 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark01(-15.236306276757155,-1.5707963267948966 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark01(152.36587596819885,1.5707963267949054 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark01(1.5268862352442358,100.0 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark01(15.272198448292599,-135.51089508408148 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark01(-1.5275656861531353,-1.018389630655679 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark01(-1.5288944703292606,0.0 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark01(-15.358252390647323,-95.83124779470876 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark01(15.361289815504946,8.010680491800244 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark01(15.37343408428191,0 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark01(1.5376568763523153,97.10402627045039 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark01(15.416961105254378,-1.5707963267948968 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark01(-15.435746973860866,-42.14628277695065 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark01(-154.39118832861706,-31.860350579884056 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark01(1.5467465885760097,1.5707963267948966 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark01(1.553918947543089,-83.92143453875703 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark01(-155.50620651205594,1.5707963267948966 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark01(15.6546314752294,0.0221684096857754 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark01(-1.56637056701767,-0.038688191639140675 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark01(1.5681031996032002,1.570796156826925 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark01(1.568166486155988,1.5707963267948966 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark01(1.5681664861559959,-1.5707963267948966 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark01(1.5681664861583013,-1.5707963267949028 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark01(1.5681664861593587,1.5707963267949054 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark01(1.5683942456116766,1.5707963267948983 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark01(-1.5689642977039948,6.429226332374154 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark01(1.5696520553549411,-1.5707963267949054 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark01(1.5696622817506194,-1.5707963267948966 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark01(1.5697281518559072,-23.561941976392934 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark01(1.5697768086637165,29.845127780107045 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark01(1.5698728605115935,-15.107069105616972 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark01(1.5706918664587621,10.99557077335381 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark01(1.5706952412977195,-73.82742384471779 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707694282209015,0.27406957055646197 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark01(1.570777436526942,1.5707963267948966 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark01(-15.707959745723029,-69.11503892331845 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark01(-15.707959786612241,0.0 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark01(1.5707962216184723,155.50883283045303 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark01(-1.570796324669731,-59.06673120302195 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963262176041,-12.633054665938472 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark01(-15.70796326782655,6.202915627366837 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267941878,0.9059627490449742 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267947278,-107.31842994969863 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948166,-63.80261042462132 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948446,1.2899592073881052 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948661,0.0 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948664,-10.603286417872937 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark01(-1.570796326794877,1.5707963267948966 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948841,1.5707963267948957 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948912,14.137168297798047 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948912,-14.899567234566717 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948912,27.817776617430432 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948912,32.92078352031996 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948912,-32.99062911269283 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948912,45.06966167192779 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948912,-48.733626153390254 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948912,70.7336138588985 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948912,-73.82742692318355 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948912,-94.33245691065892 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark01(1.570796326794893,42.18578210582427 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark01(-1.570796326794893,94.68141388358728 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948948,0.0 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948948,-0.06341432722892545 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948948,-100.0 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948948,-157.07963267948256 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948948,-1.5707963267948966 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948948,-1.570796326794897 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948948,-1.5707963267948974 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948948,-17.278759594908767 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948948,22.051347651169266 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948948,-24.49428994931459 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948948,2523.278537238851 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948948,2611.7069869227694 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948948,-32.98684493300533 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948948,-3.398047356453148 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948948,-41.74908666536825 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948948,42.031036036014996 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948948,-53.682126493092476 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948948,-66.4307851350772 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948948,-81.97422433850993 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark01(1.570796326794895,0.0 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948957,0.0 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948957,1.5707963267948948 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948957,1.5707963267948968 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948957,-24.8324994864172 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948957,-2597.197394512486 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948957,-58.24897570575713 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948961,0.0 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948961,0.01426627113822671 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948961,1.5707963267948966 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948961,19.70211310550501 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948961,2579.713011182506 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948961,31.802826559186066 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948961,-3.887232952612732E-15 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948961,4.712385458145202 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948961,-55.74032061529231 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948961,-6.601848549303716E-7 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948961,88.50072810371904 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948963,100.0 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948963,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948963,1.5707998490343842 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948963,-2550.2576040638573 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948963,-50.743113348820444 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948963,50.952588777457414 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948963,-61.26105382462124 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948963,61.26106095946207 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948963,62.75710932605713 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948963,74.97529550933893 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948963,-79.78240867161162 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948963,-88.9102216472339 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark01(15.707963267948964,0.0 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,0 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,0 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-0.0010396316078656396 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-0.00613585019923984 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-0.02701685208432531 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,0.0482948782309452 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,0.12876708307843804 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,0.13107271837466813 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-0.15230495839967528 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-0.22835245463107906 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-0.24597922576477782 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-0.26856938166515787 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-0.4999825354190229 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-0.508148767006663 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,0.5161928675674795 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-0.5327231053599125 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-0.5671666798792178 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-0.5700994704357037 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-0.5707561944366014 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,0.5707817308836552 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-0.5724757157382672 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,0.7668047956722575 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,0.8200959730435772 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,102.10176254200171 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-10.61185445508178 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,1.0842021724855044E-19 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-10.99557076532479 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-1.1798774732667734 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,12.12512108527936 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-12.566370614360332 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,1.3122973507368184E-16 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,135.26299900786526 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,136.65927690892238 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,13.868444640479872 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-1.3966887829491001 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-14.137166941154062 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,14.137166941154069 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,14.137166941163928 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-1.4421428065030568 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-14.4292043666929 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-14.42920574213025 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,14.429214840803738 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-14.967499458955512 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,15.017745127376294 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,1.5059755409809243 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-15.447783132027908 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,1.558824502660598 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,1.5707963267948888 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,1.5707963267948912 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-1.5707963267948963 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,1.5707963267948963 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,15.707963267948966 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-1.5707963267948968 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,1.5707963267948968 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-1.5707963267948968 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,1.570796326794897 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,1.570796326794897 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-1.5707963267948974 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,1.5707963267948974 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-1.5707963267948977 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,1.5707963267948977 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-1.5707963267948983 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,1.5707963267949026 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-1.5707963267950105 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-1.5708001414921624 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,1.5708001414921624 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-158.28999611656266 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,15.97537268036154 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-16.28005623420642 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-16.49298894584676 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-164.93361431331516 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,16.535532972849605 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,17.278759594743864 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-17.278759699981915 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,17.591019852664402 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,19.651917448882102 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-21.670529913651535 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-22.600038259425922 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-23.561944901923372 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,24.987292520617277 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-2503.904149922596 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-25.07589700805052 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,25.132741228714423 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-25.132741228718416 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-2575.9293929194764 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,2589.523772006312 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,2596.228782212724 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-25.98784331925128 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,2599.228083533596 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-2613.972447541768 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,2625.2568173513623 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-2.7532139956756234 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,27.79912597306202 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-28.533016966620366 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-29.09953200362007 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-29.845130209101825 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,29.845618490353036 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,30.120754017885474 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,30.345869477993688 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,30.854553541725977 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,31.61430789418975 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,3.2373287765433645 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,32.92321749009102 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,32.98672286269282 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-32.98672474237629 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,33.33376152816388 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-34.0854353321872 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,34.85193226680113 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-35.684705397672005 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,36.12831551628261 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-36.12831551628407 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-36.67506276383501 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-36.881477236919366 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-37.69912203597623 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,38.00182185884452 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,39.083260917819956 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-39.12237475410034 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,39.7355451536601 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,42.411500316821794 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,42.41150082346221 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,42.41174496408721 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-4.2926180050485385 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-43.518128769183775 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,43.98229715025871 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,43.9822972198663 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-44.21416203335793 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-44.36771177518011 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,44.41025171088762 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,45.118076558388715 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,45.553093477051995 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-45.55309538438939 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,4.606246489439407 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-46.11669582084103 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,46.862972852501265 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,4.712388980384686 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,4.712388980384689 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-4.80063049277825 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,48.211857146762604 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,48.29477843060798 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,48.69468612952676 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,48.694686147577634 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,49.23887134308974 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,49.86653864059464 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,49.891671349020186 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,50.265482457431276 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-5.053215498074303E-16 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,51.83627878430651 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,52.19217734830585 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,52.30018971291751 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-52.89912009939805 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,5.380158199628839E-4 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-53.97787143782138 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,54.97787143782141 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-54.978848000321385 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-56.09651269703026 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-56.548667764612965 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,56.54866776461814 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-5.661354076824514 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,57.255498464988975 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-58.106924570207674 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,58.11946761365066 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,58.13484417608984 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-5.860578171752398E-6 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,6.123233995736767E-17 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,6.123233995739057E-17 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-61.2610534080846 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,61.26105674500097 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,6.134830957128528 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,61.761055955411216 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,63.30207293900415 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-63.416441290942906 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-63.71481098764779 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-63.950155686418775 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,6.429374528072118 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-6.436706833741707 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-6.510541012639841 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-65.64405789029897 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-66.07654730262011 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-67.05774841844753 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,67.39998384563279 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,67.46295611737453 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,67.5442385301953 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,67.69153298008138 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,69.24090150800853 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-6.990450628589652 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-7.01764661625559 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,70.68583470577016 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,71.19318217035453 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-72.28181706003606 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-72.2969278265379 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-72.61823024450797 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-73.00489629720836 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,73.44756530494003 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-73.82742735936013 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,73.82742735936014 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,74.63507947978357 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-75.39819711328796 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,75.39822368615174 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,76.45459671075764 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,76.5081170815291 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-7.713502536106475 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-77.21232136808676 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-78.16828621356358 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-78.27704660105654 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,78.34957689001783 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,78.45144459074393 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,79.79097415333922 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,80.11061266653998 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,80.23561205496564 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-80.94693654772227 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-81.67494621171309 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,81.68140899333352 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-81.68140899333358 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,83.25220531947217 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-84.9481330310508 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-86.40942297371932 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,87.96459430051698 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-88.08959430051422 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,88.09228254359651 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-88.23912362044496 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-88.41311332884142 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,88.4501114927136 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-88.94727644972822 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-89.53539062730417 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-89.53545166246548 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-92.67697975865941 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-92.67710535121147 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-92.70823328089891 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,92.72961080749994 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-92.91006664866897 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-93.42815545957511 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-95.47614489984801 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-95.81855702637444 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,97.73697020638195 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,9.802161156441167 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,98.96016506583899 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,98.96016858807849 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,99.43682537770826 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark01(-1.570796326794896,79.73149992965398 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948968,0 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948977,-193.20793984150913 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948983,0.0 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,0.0 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948983,0.03612173324161733 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948983,-0.2437880270137235 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948983,100.0 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,100.0 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948983,-10.931115031153082 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,14.42920623304854 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948983,1.5707963267948966 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,-1.5707963267948966 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,-1.5707963267949054 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,23.827567604089026 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948983,24.173568691352678 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948983,-2602.8793025178506 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,2643.3828185351517 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948983,-36.34777073691672 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,38.744545256512936 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,-45.79679088553179 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,48.69468281882689 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948983,-50.845598752243795 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948983,-51.938965291190804 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948983,58.451589559116115 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,6.420843417038856E-6 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948983,-66.1721263784496 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,67.54423902849976 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,-77.13315688912947 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,82.18196126894998 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267949019,-67.32525817156397 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267949054,-100.0 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267949054,-10.995570765324839 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267949054,1.21758175228085 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267949054,1.5707963267948966 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267949054,-23.249127957245285 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267949054,23.56448913506829 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267949054,-44.3922834045826 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267949137,14.137169072183879 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark01(-1.570796326794916,73.2994964595772 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267949183,0.0 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267949197,-2634.324599054035 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267949197,42.582476038781415 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark01(1.570796326796085,-27.930460246438003 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963268396512,80.11060914430024 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963268666685,-67.54423852994107 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963268982255,1.5707963267949054 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963269161693,-36.12831199404314 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963867514096,-1.5707998490329063 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark01(1.5707964226733364,-161.79071910369314 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark01(-15.723588267948967,0.0 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark01(1.5726689769432278,32.98672458569076 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark01(1.5734261674330896,-1.5707963267948983 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark01(1.5734261674331151,1.5707963267948983 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark01(1.5734261674337289,-1.5707963267948966 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark01(1.5734261674338235,1.5707963267948966 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark01(1.5734261674357448,1.5707963267948915 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark01(1.5749127799230167,1.5707963267948966 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark01(-15.76099966185007,-12.656816534527024 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark01(158.40657097170774,89.30569626653201 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark01(-15.906576845197764,153.47091940333243 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark01(-15.939215092541291,0.0 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark01(-15.965662175483303,9.722612201581143 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark01(-159.74855164312572,68.87332303071989 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark01(-160.5126080850853,-20.925942457234527 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark01(-16.053083138282595,12.730208550609259 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark01(1.6061682406496587,40.004788492500126 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark01(-16.076325012061673,-29.4027573646664 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark01(-16.122096411390185,84.19075833354552 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark01(-16.17723664477003,-71.43353262697951 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark01(-16.21039935808025,49.842878637637895 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark01(16.21455419891653,0 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark01(-16.2386039883516,1.570796326794806 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark01(1.6338562666526987E-10,30.65095729755081 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark01(-16.34287958769614,0.759764634742196 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark01(-163.46770045717287,-69.28257290366622 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark01(-16.436230614216086,-28.742857758061646 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark01(-168.43723683757463,-11.06043974236683 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark01(-16.84987471189487,15.067237560757846 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark01(-168.56350742461794,0.4305579596833188 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark01(-16.90105014837951,12.95005207407679 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark01(-16.933433061682265,15.285221277523007 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark01(-17.07575166586616,-75.0907819478006 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark01(171.19140786220814,-4.712708388664723 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark01(-17.274878437798122,-85.73747578466211 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark01(-17.278331373314735,67.54423863215663 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark01(-172.7875037997826,256.0396010953764 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark01(-17.28057430356981,80.11061083530669 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark01(-17.281272288506116,1.570796326795013 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark01(1.734723475976807E-18,0.0 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark01(-17.38151422962398,-0.5033033125651701 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark01(-175.6386300581569,-44.086479120788596 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark01(-175.7275143019562,-0.26178823907051785 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark01(-17.668011701726044,0.0 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark01(-177.38751812800027,99.6228455883107 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark01(1.7763568394002505E-15,123.80177790599207 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark01(1.7763568394002505E-15,20.515079247326014 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark01(-1.7763568394002505E-15,25.135249565634833 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark01(-1.7763568394002505E-15,-31.41695508937106 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark01(-1.7763568394002505E-15,34.92022247003547 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark01(-1.7763568394002505E-15,62.83448291243404 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark01(-17.815209034711017,48.92791847627006 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark01(-179.03062013287004,-1.5752098017773331E-9 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark01(-180.03805472999142,-19.133259574518206 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark01(1.8030429160440953,0.4999863348976135 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark01(1.8058423475918006,122.87259712194475 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark01(-180.64159800721163,4.7476508632148455 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark01(-180.6803314240558,4.71434210540217 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark01(-18.18884155889404,1.534031690998063 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark01(-183.27030122031647,-168.69999341680332 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark01(183.78317023042482,-77.00027035507478 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark01(1.8397433831168197,-1.5410951089646396 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark01(18.404390863127333,-13.651111955098713 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark01(184.06183279563635,-66.60476804052809 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark01(-18.485555329408925,-25.09147542874682 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark01(-18.527225732804347,1.570796326794897 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark01(-185.353689258896,-18.849555921533156 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark01(-1.857574970010333,-2523.092056231663 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark01(-18.697542760496958,0.01917210126627162 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark01(-18.8495561599649,-92.67698277701993 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark01(-18.849557442244787,62.83185301601852 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark01(-18.849586439119125,4.3368086899420177E-19 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark01(18.85707075191107,30.99187817572954 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark01(-188.76821793529717,-32.631726139985375 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark01(-18.886756414597585,-43.34004956027142 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark01(18.89236503664601,1.5707963267948966 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark01(18.94995677724924,0.0 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark01(19.020907273647765,-6.429462507225208 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark01(19.03098588300645,20.97320973041938 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark01(-19.217999898312428,-24.035559030928653 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark01(-1.924101096847835,0 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark01(19.243952611359006,-1.5707963267948966 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark01(19.375189711328616,-1.5707963267948983 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark01(-19.40913995796079,-25.52304367899451 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark01(-19.42769222526017,-1.5707963267948966 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark01(-19.428925127526988,45.25672236484559 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark01(-19.433195388805505,2562.969133539352 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark01(-19.454124560631385,-0.7490321593185839 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark01(-194.7789981679782,43.98229715073116 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark01(19.49856590825874,25.82501276569356 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark01(-19.51598780394758,0 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark01(19.681964881674066,69.1876484497676 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark01(-19.684019360173494,95.83532845367873 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark01(19.754618253396853,0.019569251495380524 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark01(-19.782036392945308,1.5707963267948974 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark01(19.805823171562057,87.18425471203628 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark01(-198.19022554293457,-52.89544506076152 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark01(-19.898904935120967,1.139441584560129 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark01(1.9949495641713497,1.482067603754965 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark01(19.960507918733498,54.32233081256254 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark01(20.035004288413035,0 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark01(-20.03913341856172,-3.2469147548124973 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark01(20.10503747266752,-1.5707963267948966 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark01(-20.158577192226,-135.21845797935842 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark01(2.0227728684744672,-1.5707963267948966 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark01(20.236779126776298,16.68583552841058 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark01(-20.32332652842554,0.0 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark01(20.40390497044646,98.7625385111192 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark01(20.417722407695432,1.5707963267948983 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark01(20.41777928695083,73.8274272100171 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark01(20.41929525104413,-1.5707963267949019 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark01(20.420043314205127,-17.27875612782323 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark01(20.420350859994926,-193.2072053384923 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark01(20.42035157904871,54.9778680725374 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark01(20.42035224829508,-111.52488709164858 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark01(20.421180296349924,73.82742420028598 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark01(20.421667618235574,36.12831487911193 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark01(20.422911495527792,-42.41150070809959 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark01(20.422982088972528,1.5707963267948966 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark01(-20.430294434510884,32.75875426372946 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark01(-20.431944999520194,-96.56169012524961 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark01(-20.48980116919714,48.10637279200125 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark01(20.49082761644056,-9.286479916389666 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark01(20.505938849248412,1.5707963267948968 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark01(-20.511215142632263,-1.8937740481330927 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark01(20.518265412036143,-1.466672921157297 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark01(20.52255762341636,45.77073346054145 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark01(20.53126627539706,1.5707963267948966 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark01(20.547303490147957,-23.56196587842486 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark01(20.579604802340302,-1.4067755793701335 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark01(20.585450606090028,4.726311011855797 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark01(20.61165513123062,86.79031317932157 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark01(-20.64686614650113,1.5707963267948974 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark01(-20.65492583422322,-96.46181879843448 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark01(20.69045067319152,17.72783463127193 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark01(-20.723949456774186,42.77378801282046 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark01(-207.3491360298359,-6.203905597342217 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark01(-207.35197636920358,61.261056744999195 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark01(20.782160618180413,-67.1537372485563 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark01(20.79278011196522,0.0 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark01(-20.794666651434028,50.64117151471831 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark01(-20.79871364500896,1.5707963267948968 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark01(-20.813293487466424,-92.67698328161823 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark01(-20.862892198135015,98.44070920172334 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark01(-20.874701701334104,-87.30286262786464 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark01(2.0890675702400054,11.126503114528877 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark01(20.89273925140236,-37.80314429116632 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark01(-20.93139955522747,-2.0635457203700156 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark01(-2.0957365093146336,38.5693286780005 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark01(-20.983191275236763,-1.5707963267948966 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark01(20.98854366689197,-10.972246777186243 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark01(2.100969278372375,5.490914883568195 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark01(-21.084324462175346,0 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark01(21.095639113014535,-0.3907780919858404 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark01(21.242549620486386,0.0 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark01(21.245071540270715,-61.52987579744867 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark01(21.292943103376174,1.5707963267948974 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark01(-21.341424243601523,-0.4412667685108949 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark01(21.391830775548822,1.5707963267948966 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark01(21.422519046376827,-1.5707963267948966 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark01(21.433322627772647,0.9093956077227107 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark01(-21.507662501754776,1.5707963267948963 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark01(-21.51014988881542,1.5707963267949197 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark01(21.537023339706494,-79.47228245476417 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark01(-21.554917179219586,-23.56194490192345 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark01(21.559839275271525,-9.20581975223082 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark01(21.569758745832715,-135.6488435105852 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark01(21.602923868982558,-62.45704503566337 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark01(-21.64135896793508,66.1359910808907 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark01(21.661770457296754,28.47899056254508 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark01(-216.7615331154489,31.415926535457707 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark01(-2.1684043449710089E-19,0.0 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark01(-2.1684043449710089E-19,-69.11766821961432 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark01(21.716280587471346,-62.077303459353544 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark01(-21.839978142947018,13.02714177170867 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark01(21.844710658032042,-2520.6739982746944 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark01(21.84713132113405,79.91222623085667 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark01(-21.851050264610564,-1.5707963267948966 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark01(21.85466034168651,-1.5707963267948963 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark01(-21.88211598882357,-2631.2839491761542 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark01(-21.890340459865676,-69.92064338069197 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark01(-21.89763626994155,-50.757368283917636 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark01(21.9144784284081,-88.35853206896873 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark01(-21.932006474184423,1.5707963267948966 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark01(-21.93562627785748,4.712388980384672 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark01(21.96543108165438,-32.46496570924511 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark01(-21.991145052889067,-6.162975822039155E-33 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark01(-21.99114505288913,-12.566370611693339 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark01(-21.991145070196435,1.6302975294628898E-4 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark01(-21.99114507365412,6.283004644158392 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark01(-21.99114641355651,-12.567904948398816 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark01(-21.99114857135294,-163.36544709493296 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark01(-21.99114857505141,-83.25222195805492 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark01(-21.991148575113726,-6.2253945421671295 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark01(-21.991148575123436,-293.7384477613665 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark01(-21.991148575128022,1.5707963267948974 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark01(-21.99114857512855,1.5707963267948966 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark01(-21.991148590110665,0.0 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark01(-22.002769788210447,-1.5707963267948966 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark01(-22.0356199486041,50.56478307046462 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark01(-22.138371396551236,-56.14381406829088 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark01(-2.2141193274282784,52.18619427185004 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark01(22.18145508496474,0 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark01(-2.220446049250313E-16,-130.3760949743753 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark01(2.220446049250313E-16,-29.845130209931646 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark01(-2.220446049250313E-16,6.280612634062761 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark01(-2.220446049250313E-16,-67.54424205218054 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark01(2.220446049250313E-16,93.27480705221164 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark01(-2.220446049250313E-16,9.936191320749991 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark01(-22.254916105849787,42.54499369576704 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark01(-22.287401016767774,-10.688223690900335 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark01(-22.405065639428706,1.5707963267948966 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark01(-22.411917361338055,0.14870360399431976 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark01(-22.421561838496643,-65.2895986958189 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark01(22.424220499885067,-81.56759922787091 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark01(-22.519200868736572,76.62692880957948 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark01(-22.629398415789254,0.0 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark01(-22.648896298936464,1.5707963267948966 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark01(-2.2697531168490457,48.77166923498518 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark01(-22.702901069853425,-98.81248915435148 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark01(-22.712396451080323,-1.5707963267948966 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark01(2.2726796300697885,2647.012568825966 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark01(-22.95926610914045,0.0 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark01(-22.99138478675438,16.74641837585969 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark01(-23.009863452256113,-17.203238099852474 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark01(-23.159218922111137,-4.837388980384694 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark01(-23.24194360088056,-2626.1885412589927 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark01(-23.26379023596367,38.76529929483176 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark01(-23.324410240166742,0 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark01(2.3360309466740006,8.049800209965412 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark01(-23.56028477377753,-1.5707984303632387 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark01(-23.56108790314474,-1.5707963267948966 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark01(-23.56197502914339,-61.26105329521137 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark01(-23.564574742559014,1.5707963267949054 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark01(-23.631674964109365,-86.39379797371932 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark01(-2.3640413995791367,22.34582726021823 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark01(-23.887524431978,1.5707963267948948 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark01(-24.023501977040482,-95.41158387069211 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark01(-241.8820755686471,2.8399866880508417E-12 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark01(-24.35692032340411,0.0 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark01(-24.643255482348206,57.70839930025241 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark01(2.4648438509119917,-45.17005730959653 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark01(2.465190328815662E-32,0 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark01(-2.4809516340659457,0 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark01(-24.96317743761567,-14.831438296328898 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark01(-25.131254300519135,6.337768932805691 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark01(-25.132741481555055,0.0 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark01(-25.13274459300172,6.283723326379667 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark01(-25.132744736800458,-31.416071986503525 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark01(-25.132744750957833,1.0842021724855044E-19 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark01(-25.184034474998512,16.984552084848943 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark01(-25.271406714876903,-13.523280299400213 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark01(-25.28400857944608,-0.15860441972955358 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark01(-25.327362378607766,0.0 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark01(25.337967042356,-32.80053161648107 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark01(-25.35725985854743,0.0 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark01(-25.38552271547347,-90.36680537211899 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark01(-254.1330119917219,-6.4322679013446455 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark01(25.498296231485824,94.28229519106333 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark01(25.537770249497626,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark01(25.554447219373593,0.44160102908242926 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark01(25.57531995301892,31.686629273325096 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark01(-25.618585530490833,78.90494726590816 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark01(-25.710577445574458,95.31467244222014 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark01(-25.76365461018888,81.38278216398788 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark01(25.805380924329132,-74.2139254339148 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark01(-25.84931944037959,15.959131038050828 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark01(-25.849806303965124,-66.0650221096954 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark01(-25.883266613609962,-25.31545286580041 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark01(25.94532326708448,0.0 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark01(25.99901123542874,86.39379797371932 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark01(26.001420305388848,-0.5312281508653386 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark01(26.01288839678429,-4.962388980728142 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark01(2.6032011226951397,-13.792792263614231 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark01(-26.052557680294754,-12.023655454367386 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark01(26.057790804452324,0.0 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark01(-26.07535455158014,1.866599122240541 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark01(26.10803958785681,-1.5707963267948966 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark01(-26.18175741884398,-78.14685105219796 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark01(-26.201635169932416,0 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark01(26.239471032217182,1.5707963267948966 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark01(2625.3483599885485,0 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark01(26.26579558548643,52.04999960894767 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark01(26.267330189859294,65.6868872598493 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark01(26.289297721750643,-49.18083798688016 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark01(-26.338152903862834,30.498380266003352 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark01(26.516474094614786,-0.5271228607188175 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark01(26.559303706003192,-73.62930043273647 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark01(26.562258101991855,-1.5707963267948966 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark01(-26.569814775381047,-58.943769044117204 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark01(-26.5726399432048,-36.62084365512066 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark01(-26.57873847365269,191.34390990068965 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark01(26.62622310150138,49.568725318446255 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark01(-26.647740173893332,0.0 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark01(26.66640417569708,-88.5070774723148 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark01(26.70288657761571,-1.5707963267948974 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark01(26.70353755551114,136.6587502735384 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark01(26.70506362435611,4.712386659979376 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark01(26.706167396151535,1.570796326794898 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark01(26.716161288420068,89.60451783769284 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark01(-26.73153905331589,17.27875959489652 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark01(-26.73190593090193,0.31271882291780173 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark01(-26.735139635211922,81.5821642440495 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark01(26.753693437660726,119.73679597186413 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark01(26.784811106768892,-1.5707963267948966 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark01(26.796835327169553,-39.035789708357065 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark01(26.816919860533986,-0.7583385279612189 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark01(-2.681744017799372E-16,87.96422353903964 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark01(-26.853024532570345,0.0 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark01(26.86565811873261,14.429248487002575 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark01(26.942354873126305,-64.62804714961811 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark01(-26.951147523320913,-80.87607330601641 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark01(-26.962133890474007,-35.58345324972113 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark01(26.984204054954233,-1.5707963267948966 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark01(-27.00738536237051,-2.767402540277121 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark01(-27.019507809824518,30.901131379339294 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark01(-2702.6535955448626,0 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark01(-27.043506571963142,0.0 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark01(27.06090608265528,1.5707963267948983 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark01(-27.06201700128363,-91.42932318943768 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark01(27.086963678701736,0.31424398285473387 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark01(-2.710505431213761E-20,1.5707963267948977 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark01(27.105747488015936,39.09433885962209 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark01(27.131140922476,33.39885066672238 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark01(2.714378579801211,-17.904457521691313 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark01(2722.3724585789873,0 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark01(-2726.8728936433386,0 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark01(27.296727001268657,0.0 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark01(-27.330752280487374,13.429786072456992 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark01(27.422819752221315,0.0 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark01(27.70643930263141,90.61246626938873 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark01(27.753140796471158,49.80264339861866 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark01(-27.75834015930114,61.22906845522803 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark01(-27.770674350194952,0.5940912885949521 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark01(27.780039550697587,-44.42076885625795 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark01(-27.80795443333099,1.5707963267948968 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark01(-27.811773068216844,-65.69586437624633 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark01(27.814480983612253,66.45477346423708 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark01(-27.816217205391027,-1.5707963267948983 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark01(27.84814917680922,-57.49260959380505 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark01(-27.84956304349096,-1.5707963267948968 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark01(-27.86332600412928,-15.533183671107125 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark01(27.910735776076834,0.8706094625465679 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark01(27.987934284048073,88.73518450617398 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark01(27.991251443636145,67.12220911462717 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark01(27.993583973029875,0 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark01(28.034316516362058,0.0 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark01(28.03712680419494,-6.025871358825441 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark01(-28.037203686609573,9.662914499891249 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark01(28.05438716710136,0.0 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark01(28.098249222877115,0.0 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark01(-28.10265420809631,-0.24873941566050028 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark01(-28.113597146549388,-0.6113761076231249 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark01(-2.8123035014140975E-6,-138.22911936958488 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark01(28.135353544929615,1.5707963267949054 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark01(-28.163196554268936,0.0 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark01(28.194272764162708,1.5707963267948966 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark01(-28.202645731125337,-1.5707963267948974 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark01(-28.22851744647133,44.30485798139482 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark01(-28.274308670826674,-14.137180938040553 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark01(-28.274330361798107,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark01(-28.274330502432736,-69.11503431230607 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark01(-28.27433151702121,-94.24645437264154 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark01(-28.274332119653028,-87.96274267227281 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark01(-28.274333869250565,67.54423058769834 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark01(-28.274333879042896,-4.712388980347528 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark01(-28.274333881920793,-1.5707963267948966 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark01(-28.274333882109826,92.67694834673944 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark01(28.274333882308134,0.0 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark01(-28.274333882541494,0.0 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark01(-28.28595348882756,6.429231810645761 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark01(-28.478985685920936,23.963094629332762 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark01(-28.526580373277667,85.72529999729308 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark01(2.854862281981923,-67.55778041911783 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark01(2.8643765618278225,1.2671463593498299E-16 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark01(-28.679121389555633,-64.38216650134392 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark01(-28.693041626482426,-1.5707963267948966 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark01(-28.71191811523248,1.5707963267948966 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark01(-28.901106247646666,-61.97383705863321 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark01(-29.036662556373713,1.5707963267948966 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark01(-29.24194779290255,0 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark01(-29.358692884545647,45.232709655686875 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark01(-29.402247736622193,-64.30601933020395 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark01(-29.570525218143892,1.5707963267948974 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark01(-29.755244823430747,-0.047291829200424136 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark01(-29.819412301573628,0.0 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark01(-29.83679101458954,1.57076487818646 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark01(-30.122882421463103,-44.05675908264664 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark01(-30.20528799728808,4.99042677667309 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark01(-3.0814879110195774E-33,-58.15071409141118 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark01(-3.0903941884171218,0.0 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark01(-31.02499341789463,-1.5707963267948966 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark01(3.1050431271850063,-6.429203822389177 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark01(-31.166963541335193,-1.570796326794209 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark01(-31.19859707290922,32.70368779442421 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark01(-31.37639271944639,1.5707963267948966 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark01(-3.1415891313503055,0.0 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark01(-3.141589488274006,50.26548245677889 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark01(-3.141592263871508,-6.221078010009361 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark01(-3.1415926535540164,-131.94426161742146 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark01(-3.1415926535893357,6.224823563670901 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark01(-31.41593005813742,-12.566370614310639 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark01(-31.416903098397935,1.5707963267948966 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark01(-31.422565160494706,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark01(31.444037105728626,74.07204910164873 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark01(31.447176535897945,0.0 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark01(-31.44717653589798,0.0 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark01(-31.447176536094048,-4.8148248609680896E-35 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark01(-31.447176540773373,37.69911184307922 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark01(31.461836990688,-5.007592016286651 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark01(-31.476432657720395,-1.5707963267948968 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark01(31.52286704909102,-44.44854094062846 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark01(-31.582603715364847,-38.97898675415968 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark01(-31.59173152195298,19.36711692892953 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark01(-31.599145855831352,53.62244843808611 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark01(-3.1615061744539097,0.19989717283951702 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark01(-31.64978167235565,-0.004986884240232655 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark01(31.653127221303592,-49.476307246141474 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark01(31.76884258362383,1.5707963267948966 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark01(-31.85709167858765,-1.5707963267948966 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark01(31.859815176349798,3.552713678800501E-15 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark01(-31.871489073894395,61.82446107769948 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark01(31.944631393798034,-2.4598415061331664 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark01(32.0677457135391,-1.1665060222539438 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark01(-32.07409317486017,-29.519023064526834 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark01(-32.11307810012549,84.81666303293551 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark01(-32.250378237474166,6.430653706131197 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark01(-32.35798866635875,-10.487539644570461 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark01(32.37235360666919,118.18056392923052 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark01(32.49073815584637,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark01(-32.5334597274952,71.7874680584136 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark01(32.56561871641781,-38.640882140121114 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark01(-32.57187416135538,1.5707963267948966 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark01(-32.589126227447736,-0.5025710093550947 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark01(32.59858517900797,122.0800145047701 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark01(-32.60973333127765,-0.6590264041770033 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark01(-32.660402265624185,49.64071046624275 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark01(-32.68503992064503,0.7154391575241403 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark01(32.72611776291927,4.69571856263949 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark01(-32.78184737375767,-66.84686895031723 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark01(-3.279712478833295,100.0 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark01(-32.80039755444389,0.0 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark01(-32.86449804274298,1.570796326794905 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark01(-32.88170213969062,53.782540165927514 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark01(32.95699929476589,-68.94302507277456 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark01(32.98403680711675,0.14226949395641336 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark01(32.98669445769298,-4.712385459247911 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark01(32.98672274292633,-102.10177416121769 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark01(33.043253749235404,18.483939356624873 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark01(-33.09980911583057,0.0 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark01(-33.25700607767397,14.429262868756389 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark01(3.328602686704542,41.0928958671482 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark01(-33.29788403576734,82.68780892251476 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark01(33.33824161176716,-23.510171765734583 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark01(-33.341526997474546,-64.87198896030168 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark01(33.4186857114467,1.709501175982581 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark01(33.507804998585684,0.22843415226164251 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark01(33.552534053254135,1.2362085523017754 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark01(33.730392814722954,-1.5707963267948963 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark01(33.76049408730212,135.40914085317473 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark01(33.836540529492396,51.72307597584728 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark01(-33.843636868737015,0.28703402901851194 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark01(-33.89585020476835,46.70269320602159 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark01(33.990933780197224,58.024541868937405 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark01(-3.402093970316495E-18,45.555620313722315 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark01(-34.07401334643648,-1.5707963267948966 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark01(34.12020253143412,-32.87626228168146 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark01(-34.20292008259292,-1.5707963267948948 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark01(-34.206052289549376,0 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark01(34.35914318669431,0.0 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark01(34.4193993642441,99.99999999999976 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark01(34.488918595268565,-0.013089249033510325 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark01(-34.529915584665744,-44.54679059915421 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark01(34.53618666565845,24.508899776204316 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark01(-34.55751918948635,-1.5707963267948966 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark01(34.55751918948773,0 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark01(-34.56119113767852,0.0 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark01(-34.60160308622264,-0.2979849694438311 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark01(-3.4613161558817654E-16,-61.26105674500096 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark01(34.680674674954616,-1.5707963267948957 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark01(-34.73500129900897,30.486773474703398 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark01(-34.74900700601016,87.0618924569918 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark01(-34.80163926227094,-61.26862233382473 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark01(-3.4810684844053412,0.09400741799408596 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark01(-34.92328151495221,-79.6968564952447 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark01(-3.500411438059175,12.508289494061888 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark01(-3.5017118810822865,0 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark01(-35.06334713978093,0.3276944751817409 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark01(-3.5162552823662756E-6,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark01(-35.179420686119684,-73.39858720209263 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark01(-3.519955282494515E-6,157.07967999577477 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark01(-35.221080968454686,-26.398474424830283 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark01(-3.5222394875889243E-6,4.827191746851758E-13 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark01(-3.522239487595288E-6,0.0 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark01(-3.522239487617807E-6,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark01(35.399053893525235,-15.403599583893694 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark01(-35.42127848675338,28.965171299585137 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark01(-3.552713678800501E-15,-86.9957206710253 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark01(35.536433600462345,-1.564668536319786 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark01(-35.53672853362432,17.646857646551467 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark01(-35.61781249927648,0.0 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark01(-35.648470582807654,92.67698328095308 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark01(35.649913804637464,0 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark01(-35.65074580864267,-6.712388980384691 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark01(-35.666516036522495,-1.5293671040273644 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark01(-35.69518744913529,-82.60188812797666 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark01(3.5866352501595564,70.91610504782953 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark01(-35.92198613196183,53.13873241266148 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark01(-36.06914679380664,-1.3581793678101093 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark01(-36.12568567564437,-1.5707963267948983 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark01(-36.1277812498019,1.5707963267949054 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark01(-36.12824061410318,-98.96016584083193 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark01(-36.128252763750226,-1.5707963267948966 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark01(-36.12825587538478,1.5707998260633043 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark01(-36.128314303425874,23.56194137972621 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark01(36.395682637759194,52.77806563689714 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark01(-36.45618140066027,-73.41722304599742 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark01(-36.48628650149499,57.33654595902749 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark01(-36.56476173862369,0.17028833793199516 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark01(-36.725358417147,1.7567700635004115 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark01(-3.684869010994035,30.36901621653699 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark01(-37.07128791516359,2617.6919710680454 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark01(37.0880579331361,43.53228581906805 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark01(-37.09426745663517,87.7503253931844 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark01(37.18294220803898,34.76029588318542 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark01(-37.19010420946063,0.0 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark01(-37.53401681291822,143.82767630684083 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark01(-37.69906291532503,6.429210293455662 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark01(-37.69911375042616,-1.5707963267948966 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark01(37.762606549217026,100.0 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark01(37.77601849417603,-0.130074202950632 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark01(37.8511405006318,-70.88961614419604 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark01(37.86391068658256,-40.25510057260961 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark01(-37.91760412204684,-38.85314649148746 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark01(-37.94291121656425,-14.445486270032063 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark01(37.960815035739756,-14.429300038168478 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark01(-38.10856922677714,2645.4534652831812 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark01(-38.122254436529175,-92.73559541330116 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark01(38.1713881344491,-71.67647372188608 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark01(-38.28015970328517,-74.34777762629176 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark01(-38.28904551305739,0 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark01(-38.29289172384135,35.656292264283714 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark01(38.33217897021842,10.128321399159773 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark01(-38.336952222430654,-16.675933310220543 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark01(38.34674028221639,-2437.47080497753 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark01(38.52237021338604,36.62528299401421 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark01(-38.64832135349755,-1.5707963267948948 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark01(-38.65683403877272,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark01(38.70932043028476,-1.5707963267948966 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark01(-38.75799829383095,0.05885709647084469 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark01(38.80667892359586,-0.45400455753292995 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark01(38.80686999599527,7.748485706905195 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark01(38.84245335885513,4.837388980384691 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark01(-38.89603996780916,-1.5707963267948974 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark01(-39.06730188253753,50.276119860189226 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark01(-39.091647969145356,1.5707963267948968 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark01(-39.135278220847255,-43.028377058886406 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark01(39.18415251969824,-1.5707963267948966 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark01(39.19024243465097,0.47444956727667537 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark01(39.25995088486884,6.712388980384691 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark01(-39.264331895383215,-6.429205133307236 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark01(39.267278329233534,-1.5707963267948966 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark01(39.26776770050006,-1.5707963267948966 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark01(39.26982729379906,48.69468261366349 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark01(39.269908169633645,1.570800154763899 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark01(39.35109657893776,10.826070219822753 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark01(-39.36072479195871,57.236662018277684 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark01(-3.9460964730895056E-7,102.10566752583877 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark01(-39.789732498219735,22.09947883188086 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark01(-39.84089435515812,52.95999429845929 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark01(39.90143657173229,-88.02518652785434 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark01(40.14421095347244,98.96016858807849 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark01(-4.01576173184565,61.28018630418232 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark01(40.22275415870527,-56.445079171897646 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark01(-40.23625809859829,1.5707963267948966 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark01(40.26117795757881,137.12870385927044 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark01(-40.26880978987593,1.5707963267948966 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark01(40.394087493609845,-80.25386740616051 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark01(40.422037986789775,45.527715304772556 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark01(-40.42962714208797,-44.22889657347383 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark01(-40.497518535344,0.0 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark01(-40.515769406769444,0.0 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark01(-40.586331316095354,77.03394793207968 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark01(-40.77564435144958,74.20043465790519 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark01(-40.82908654879607,0 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark01(40.84070447723891,-0.002637150857624277 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark01(-40.840704615876625,0.0 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark01(-40.8407170427099,-0.009308959406048367 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark01(-40.93657365078296,-35.65977122146322 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark01(-40.963399520211354,0.0 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark01(-40.978496360553265,0.0 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark01(-41.0087766888827,1.5707963267948966 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark01(-41.05043309178589,67.33702598515562 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark01(-41.107414417725074,0.0 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark01(-41.17464167688145,83.52668986842912 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark01(-41.20777416017853,0.03380567156642844 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark01(41.208506956974134,0 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark01(-41.210911301335386,0.0 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark01(-41.23531853789504,72.2106233738495 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark01(-41.277936360552516,-1.5707963267948963 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark01(-4.135240895623932,-45.390398871461656 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark01(-41.40202198603351,-1.5707963267947953 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark01(-41.50761623130179,-82.66502293180544 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark01(-41.52213148494219,-18.527219067536848 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark01(41.63454588742215,-1.5707963267949197 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark01(-41.64814947468598,0 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark01(-4.166017034323762,8.996218643981017E-8 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark01(41.672040809720926,-7.960677875410255 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark01(-41.705111435492356,-61.427766947407946 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark01(41.94487356401284,0.0 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark01(-42.01578088285072,46.43147760973153 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark01(42.01882821849881,-30.583252121045575 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark01(-42.17480439547693,16.59051146747047 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark01(42.219372099621296,13.191690218114573 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark01(-42.368891212203906,-40.62266211663037 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark01(-4.238071684934866,-49.13327573826989 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark01(-42.40887098366997,-1.5707963267971436 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark01(-42.4102577015327,67.54423933310302 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark01(-42.41407570051318,-1.570796471160762 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark01(-42.41408394020905,-64.40313768338355 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark01(-42.43070906502944,97.51336869770827 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark01(-42.434633850854595,-6.2471574923160205 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark01(-42.53650082346221,1.5707963267948977 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark01(-42.53650082346221,-80.11060959452544 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark01(-42.53679502276457,58.119467613839475 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark01(-42.59779883793171,1.5707963267948983 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark01(-42.606466644586284,-100.0 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark01(-42.60832821378586,2589.5825263586416 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark01(-42.636834914986814,-47.377488445971274 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark01(-42.637825362151965,-1.5707963267948966 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark01(-42.64390913477036,-55.1059595415067 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark01(-42.65141548891263,31.911633250051548 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark01(-42.699997540743865,100.0 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark01(-42.71172889524528,61.26246419705545 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark01(-42.71471592655676,-18.45247905892631 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark01(-42.7664393917559,1.5707963267948966 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark01(-42.77969840842729,-0.38784203998210304 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark01(-42.84603233581869,0.0 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark01(-42.85696690061007,-1.5707963267948966 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark01(-42.85897044256768,-17.30563833007811 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark01(-4.286819552845094,-50.588910974539985 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark01(-42.92570510251195,-1.4861529484993234 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark01(-42.94853220662469,0.0 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark01(-42.9501060410432,61.39310639898255 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark01(-42.96851037372108,-1.5707963267948952 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark01(-42.971145641250324,1.4205986824787828 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark01(-42.97459567089625,6.123234139052113E-17 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark01(-42.98091389932615,0.49012349736536265 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark01(-43.07286579372687,-14.822534520854028 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark01(-43.13412657172289,-2612.95131369536 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark01(-43.189740436524545,0.0 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark01(-43.2796391337968,28.306998142284414 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark01(-4.3368086899420177E-19,4.712388980384689 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark01(43.464055591578216,-56.73441541932169 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark01(-43.51178472933488,40.616005443687385 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark01(-43.6659595097661,0.0 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark01(-43.71644522519479,49.52370464867145 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark01(-43.89113052870596,64.85660261657114 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark01(-43.98229735449429,-92.67696374634167 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark01(-43.98230021222846,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark01(43.987396677885165,-0.209368046045966 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark01(44.02703338037591,0 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark01(-44.04479715025711,6.938893903907228E-18 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark01(44.06538020718979,-0.5934895446136461 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark01(44.09158190977354,-93.77637784891247 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark01(44.098106992134205,0.0 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark01(-44.198814005287886,75.23790038310293 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark01(-44.207371639861016,1.5707963267948966 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark01(44.21331208740247,-56.393235524291406 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark01(-44.23562879710412,-1.5707963267948966 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark01(44.3240440483811,-1.5707963267948948 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark01(-44.32984662785772,0.49998270942634165 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark01(44.357694372494436,-6.429218445935214 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark01(-44.36838676850905,59.01076904402688 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark01(-44.398665507395584,0.0 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark01(-44.400572607153755,0 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark01(4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark01(4.440892098500626E-16,-0.08297112623401351 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark01(-4.440892098500626E-16,1.5707963267948966 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark01(-4.440892098500626E-16,-18.860197433874575 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark01(44.411387000938305,-9.778873366274254 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark01(44.418651606113855,-19.917478675737783 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark01(44.46041944947015,161.5230808996842 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark01(44.48112718633581,2609.726445065558 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark01(44.482051134786786,-1.5707963267948966 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark01(-44.549538965907374,-1.5707963267948966 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark01(44.62382254066469,54.9778714378247 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark01(44.71281837070219,-91.4764927821723 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark01(-44.73188240297204,0.0 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark01(-44.813916230358394,-45.433117420570014 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark01(44.83612390559735,1.5707963267948966 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark01(-44.83961778501846,0 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark01(-44.847114196660705,1.570796326794897 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark01(44.84711746267806,-1.585624886491459 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark01(-4.4864985026889235,19.6608867698114 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark01(-44.95820425813732,88.65466414200941 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark01(-44.96650123059079,9.592186782785134 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark01(45.07213506388288,44.22397180491363 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark01(-45.1739524777086,64.42854317106872 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark01(-45.17506864810055,-1.5707963267948983 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark01(45.242617152623204,1.5707963267948966 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark01(-45.27410894229145,-57.872727801647514 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark01(-45.33678212352421,0.0 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark01(-45.3563083306085,-79.69355906175636 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark01(45.45999739392716,1.5707963267948966 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark01(45.46724009169287,5.660150982800744 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark01(-45.47635575885735,32.24869653423565 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark01(-45.49327045756032,-89.25124425222961 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark01(-45.52355281905245,60.85855070792027 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark01(45.52848912242118,4.743638980384704 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark01(45.55040001080948,0.0 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark01(45.551420093390774,1.5707963267948966 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark01(45.55197207709919,-92.67698041609745 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark01(45.55307861845646,10.989017549073589 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark01(-45.69546730692544,0.0 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark01(45.79508047625188,14.173539275092466 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark01(-45.811884815495915,45.106342057515405 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark01(-4.585555141699999,1.5707963267948957 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark01(45.976557249557715,-93.26779959226788 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark01(-46.152029981129104,0.0 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark01(46.167607865057875,0.0 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark01(46.171046349952384,-42.597505305430026 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark01(-46.17477334115549,-1.5313544539099553 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark01(46.280933753488476,1.3468367916932011 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark01(-46.28407656044364,-1.5707963267948966 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark01(46.29382356097656,-45.13150106128738 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark01(46.31051775836826,95.83839049251247 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark01(46.36584319478087,0.2733803636785433 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark01(46.45464947180102,21.665058077178784 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark01(46.53418056809194,-89.07546595474952 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark01(46.64565471766776,-1.5707963267948966 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark01(-46.65997219341608,-135.18978779693066 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark01(-46.67424399065274,80.40439203452564 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark01(-46.98314031658148,-3.4457580510129446 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark01(-46.989736893321066,37.26171238800987 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark01(-4.709759139749107,1.5707963267949054 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark01(-47.11009572997791,-0.17046110453159713 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark01(47.112323395006776,-0.15224762619737697 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark01(-4.711267279945046,1.5707963336716233 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark01(-47.12388630773029,31.415721246754234 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark01(-47.12388739884821,0.001470513191009642 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark01(-47.12388979242076,67.5442420508603 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark01(-4.713989652079438,-67.54424005694209 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark01(-47.25042109374628,0.0 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark01(-47.378499407935415,-0.725553324181347 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark01(-47.42502324970206,0 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark01(-47.71065256225775,1.5707963267948983 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark01(-47.727198104961865,-93.30953019086279 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark01(-47.78442371348391,38.873404658973314 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark01(-47.78595847723583,80.50609162851865 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark01(-47.92603197141136,0 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark01(-47.937418029927116,-0.982759823269254 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark01(-47.95386394011345,-39.55635991850144 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark01(-48.00450293482956,1.5707963267948966 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark01(-48.068614898923826,-7.629804660829533 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark01(-48.086873598250406,1.5707963267948966 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark01(48.16608503239634,1.2141611729908856E-7 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark01(-48.23323241593229,1.241912150949433E-4 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark01(-48.25561416425632,1.5707963267948966 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark01(-48.27761961666797,0.0 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark01(-48.36166870218276,-100.0 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark01(-48.365135713541534,30.26479321699017 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark01(-48.3693949934469,-59.17613944606468 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark01(48.39861935905881,-89.31135000720698 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark01(48.43107041810919,0 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark01(-48.49454454433491,-93.38477347661616 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark01(-48.707395608946726,32.132163846805106 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark01(-48.71397123712535,7.679981612330593 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark01(-48.73288510658379,84.53947726212073 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark01(-48.74071703010736,-78.40132502848833 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark01(-48.79705556659022,88.2299880520084 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark01(-48.810709400817906,-0.011260762015900589 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark01(-49.126623765842645,-4.837388980384695 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark01(-4.930380657631324E-32,-1.5707963267948966 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark01(-49.316686162480565,28.115083502314754 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark01(-4.933243561233251E-13,131.93164142138292 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark01(-49.34952281206746,-53.515512332768544 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark01(-49.40592743017942,-2.6453747959424874 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark01(-49.474498597748244,0.1314778669229888 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark01(-49.48542282482208,-17.579971939965407 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark01(-49.704505297512526,0.0 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark01(-49.713741955761634,0.0 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark01(-49.72848728023238,-38.75960296721948 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark01(-49.743055047868076,-20.108980207004553 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark01(-49.797008763152455,-17.859298997525254 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark01(-49.86248529959569,0.0 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark01(-49.872577364485934,62.877035966821886 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark01(-49.873386600856215,0.0 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark01(-49.88270160453984,-1.5707963267948966 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark01(-49.90235414277382,1.5707963267948966 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark01(-49.942576308798685,77.3834195048803 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark01(-49.94345211729765,1.9804969541345987E-8 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark01(49.94999489565956,97.24281381251643 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark01(-49.95483561840075,68.42119153039795 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark01(-49.98967790793777,-67.33644184953451 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark01(-49.9913569200706,58.82172864475356 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark01(-49.999428235488665,-1.5707963267948966 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark01(-50.0057682178215,36.91801077700991 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark01(-50.0159791816739,0.7180693787753795 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark01(-50.03746482079785,0.0 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark01(-50.079567495195576,3.1128717769300147 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark01(-50.08605103732029,0.0 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark01(-50.10718257072539,-17.52014305607294 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark01(-50.108793274367855,1.5707963267948912 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark01(-50.11128962644615,-18.421517555124538 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark01(-50.14923028636493,-119.0781503403277 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark01(-50.152259680929845,100.0 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark01(-50.15437031138104,-6.758570972359166 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark01(-50.17555666747015,117.40766312525254 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark01(-50.2042631695419,-51.79328133081451 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark01(-50.21908300641199,0.38638613193855786 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark01(-50.227820949195745,-5.393184563714655 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark01(-50.254866315186966,0.10667917717630232 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark01(-50.26548245743628,0.0 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark01(-50.26548277103921,6.224105688957357 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark01(-50.2654862721447,-18.84944824029378 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark01(-50.26548645961012,-1.5707963267948966 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark01(50.26705777035612,-0.5131336362266935 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark01(-5.027064399598828,-43.7615711356354 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark01(-50.2967324607722,6.204053711775667 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark01(5.030172366537002,9.6451495873483 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark01(50.348369287412766,-5.766024690370768 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark01(50.41543357653292,-3.373183611311177 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark01(50.42539584928765,1.5707963267948968 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark01(-50.483542528285156,-0.005629336196668327 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark01(50.5049056437906,-42.72035501804068 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark01(50.527466112301326,0.0 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark01(-50.533079218467634,18.130954036955742 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark01(50.533634160008134,37.00640616503414 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark01(50.53643151567252,-1.5319273493741754 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark01(-50.59083339038084,-7.881607417000723 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark01(50.63682674825965,4.440892098500626E-16 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark01(50.6680783279225,-40.251176627532615 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark01(50.66969206309537,-25.11115828620831 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark01(-50.67047877453038,159.0716264443779 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark01(50.672301028165236,-69.42361925583583 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark01(-50.73152112056234,0.037121556016947395 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark01(50.768821708112625,-76.98493992334241 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark01(-50.831170035124444,0.0 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark01(-50.92939664070815,66.29902739746487 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark01(50.95134760516652,0.0 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark01(50.95405442179543,1.5707963267948983 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark01(50.988691183491156,38.92489785178048 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark01(51.04775716411072,-1.5707963267948966 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark01(51.17731580796322,37.78672219933614 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark01(-5.119963574767229E-7,-31.418355894371953 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark01(51.24655794233931,1.999870129600079E-10 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark01(-51.27607593227172,0.0 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark01(-51.32921374379741,0.0 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark01(51.33327306642881,-64.27846811068592 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark01(51.40645782651262,-2580.45551191442 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark01(-51.4716012630575,-53.72314942626369 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark01(51.47421833456765,-37.64889028671624 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark01(-51.6149490082672,-1.5707963267948966 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark01(51.633274212929706,-50.540002798098115 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark01(-5.16990136907603,-40.62574338904537 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark01(51.70042765078366,74.41848195576918 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark01(51.78825388098696,-49.95210055815882 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark01(-51.813421435318354,0.0 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark01(51.83364894359268,1.5707963267948966 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark01(-51.87657327721497,-79.24027409328103 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark01(52.06282454061321,1.5707963267948966 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark01(-52.12182937693099,-1.5707963267949125 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark01(5.215831736808339E-16,7.059171164936752 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark01(-52.15909397785339,-3.036683265949705 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark01(-52.17023612644505,38.90335861018909 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark01(-52.213262420311054,1.8335762668708355 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark01(-52.29843568393162,-16.131869999508467 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark01(52.39222962112234,-74.76611365928494 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark01(52.41931048250561,54.55107622836482 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark01(-52.53326024627913,1.5707963267948966 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark01(52.62451097944623,0 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark01(52.63745306875376,-23.569903869500905 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark01(-52.65026600273457,1.5707963267948966 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark01(52.654203922929156,-61.4445405734585 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark01(-5.268006173568196,79.90811379060119 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark01(52.723557259131354,30.056270812844303 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark01(52.73814150620221,-1.5707963267948966 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark01(52.95204820575569,81.8818850042392 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark01(-52.960340459036274,-13.07853291156852 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark01(53.00338074548452,0.09920841656813871 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark01(53.04129495203185,0 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark01(53.1908848463932,-1.5707963267948966 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark01(53.21748392166484,-1.048858119673623 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark01(-5.321948841861101,98.14345317750494 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark01(-53.40706709119761,89.53545568895218 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark01(-53.40707246568896,50.264182437062715 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark01(-53.40707337474191,31.416896656780644 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark01(-53.40707367264417,-1.5710404841031702 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark01(-53.40707418467293,100.53307744449812 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark01(-53.40707511089164,-4.71238888185686 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark01(-53.43903311732265,-65.06967992934014 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark01(53.440915496089275,-60.02749097011326 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark01(-53.45001474624915,98.7881824167728 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark01(-53.64599233776242,-1.5707963267948968 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark01(-53.83504101819898,53.91489758708284 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark01(-53.98518083713273,-31.543744415722166 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark01(-54.10038713348606,32.61747731871528 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark01(-54.16262763690223,-14.309043732414999 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark01(-54.2506795895318,-91.81636453483652 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark01(-54.296886483467,-18.174237953381045 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark01(-54.35361909690594,-12.805542819810398 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark01(-54.40146278591925,-17.441045585459907 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark01(-54.413197674882866,-2724.0255153978555 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark01(-54.613696372606114,-17.27876130023124 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark01(-54.69345655761805,-61.30124116756439 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark01(-54.97633329728437,-4.712386678768794 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark01(-54.977871443361956,4.712386060127548 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark01(-54.977871455771236,-4.712385458146798 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark01(-54.97824635013116,-164.9648646014567 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark01(-54.979619835740536,1.5707963267948966 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark01(-54.979755992351606,-1.5707963267948966 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark01(-54.98050127846032,1.5707963267948966 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark01(-54.99209962670218,-1.5707963267948966 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark01(-55.0843222002238,-82.28432756401602 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark01(-55.08893594201791,-3.226806192557787E-15 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark01(-55.13684648968831,-59.5403056621901 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark01(-55.15069320667051,-1.5559002051271915 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark01(-55.20069696930778,-7.835748696454086 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark01(-55.23089816495115,63.23662683267855 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark01(-55.24485562144248,69.56180297056542 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark01(-55.28096201520124,1.5707963267948966 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark01(-55.28097706374835,44.22157021681997 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark01(-55.36704853634884,-73.75681262563091 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark01(-55.38143161390254,5.08409997486518 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark01(-55.387071828031075,2.4256051039172446 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark01(-55.3942997547052,0.0 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark01(-55.39863983726209,2.220446049250313E-16 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark01(-55.408990321176105,43.11420523896161 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark01(-55.41537974075579,1.5707963267948974 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark01(-55.424034587601845,11.581494715943109 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark01(-55.44605886967497,0.0 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark01(-55.465899330445836,-73.45423171390728 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark01(-55.47863881119289,-99.14586729216988 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark01(-55.48491216707273,1.5707963267948968 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark01(-55.492394796258154,45.544128150828875 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark01(-5.551115123125783E-17,-1.5707963267950105 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark01(-5.551115123125783E-17,31.416117126888167 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark01(5.551115123125783E-17,-97.61011724970064 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark01(-55.5330064493302,-10.960623824510082 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark01(-55.54484861064775,1.5707963267985094 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark01(-55.70670479405281,-32.729859474573225 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark01(-55.73377066104241,0 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark01(-56.03026567318955,-38.82355732243536 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark01(-56.05127318502772,-5.262594651454786 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark01(-56.07899316633482,-107.74775066380732 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark01(-56.110578393066376,83.79451977530056 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark01(-56.120601668934,51.60823787514488 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark01(-56.12587712241765,-84.05972505948083 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark01(-56.179766550166796,-51.59625420377724 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark01(-56.24029449212016,-29.38205515321834 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark01(-56.255137754822876,-88.08344624665185 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark01(-56.274009356719205,-0.6018107710854455 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark01(-56.28120116892316,-2531.9242579409524 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark01(-56.32273113072477,-88.23671648400324 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark01(-56.33083113299633,2573.5553826165074 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark01(-56.34975358198025,17.006380814292015 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark01(-56.35667966987494,0 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark01(-56.35911956436046,-2631.1275131613934 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark01(-56.39927459836866,44.05991330221808 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark01(-56.44144425032201,1.5707963267948966 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark01(-56.453600871167566,-1.5707963267949872 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark01(-56.474177823877206,-58.76678150618759 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark01(-56.50615406677151,-81.38881447186095 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark01(-56.541228770799194,90.53403705890062 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark01(-56.54306473059645,0.10592340638435556 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark01(-56.54474471642021,-1.5707963267948983 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark01(-56.54866776461627,0.0 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark01(-56.54866776467765,144.50988489105785 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark01(-56.548669973243705,4.2156241339882776E-4 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark01(-56.548671286855765,0.0 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark01(-56.548671286855765,-5.1347763822266375E-11 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark01(-56.55257401461634,-32.986722925010916 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark01(-56.56429276461628,-6.225166841162672 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark01(-56.60921315927392,2.257296608323488E-7 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark01(56.63115616569213,0.0 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark01(-56.76537064973137,-88.32145886938333 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark01(56.77447874120739,-0.42019799873634855 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark01(56.77978430584066,2.5939267885560326 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark01(56.794846076101706,49.552326151935134 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark01(56.81026991537271,48.69804107753085 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark01(-56.814596360086036,42.85079246539284 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark01(-56.8210757839694,17.667910060186962 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark01(-56.828583086934124,-72.68922969924881 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark01(-56.89135614519496,3.7768077019895827 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark01(56.925094985905645,-28.274333882308138 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark01(-56.94148864505622,10.857689728329344 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark01(56.96531765754104,-56.00953812622635 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark01(57.03756858623282,1.0117897688337774 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark01(-57.08461615152014,0.0 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark01(57.11580063651547,95.65374096387364 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark01(57.252934820163915,-9.654480789393855 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark01(57.28596192479176,97.36904267516405 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark01(-57.43465195506508,2524.776397702215 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark01(-57.43814684081505,85.59812875868332 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark01(57.498209173635104,-17.564745669369742 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark01(-57.51996090699771,-2617.795618751055 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark01(-57.54926158710527,1.1035557242317537 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark01(57.55260944538874,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark01(-57.58597611765832,-0.041827401376462854 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark01(-57.593147788765506,-79.66631401221986 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark01(57.60435384920125,67.67437053129262 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark01(-57.649017834042425,59.3101770917102 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark01(57.65941972032276,-1.5707963267948972 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark01(57.76692669481155,1.5707963267948972 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark01(-57.83837940724003,44.54072814264844 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark01(-57.83959254502357,-21.85884659441851 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark01(57.84419764600824,-28.523111108042002 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark01(-57.85263473556039,-14.289884938543622 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark01(57.85497230221479,24.197569177237582 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark01(57.85755163399887,45.317059302208136 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark01(57.874987519234764,33.02936766074208 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark01(-57.960933012767306,-44.33224120535084 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark01(58.117178707567376,-80.11061181164999 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark01(58.11726397065568,-67.54424101439781 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark01(58.11940540863747,67.5442414652448 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark01(-58.11948663740188,-16.333414156456556 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark01(-58.13735930169217,28.99308831613726 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark01(58.15329473823911,-100.0 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark01(-58.207971165795236,60.885972591177364 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark01(-58.24169696197698,-99.8939074272446 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark01(-5.825874790636212,6.4293557483512425 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark01(58.37885823994915,-19.497905124567367 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark01(58.46642323451866,3.585429321090089 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark01(58.47451935459708,30.508973107670386 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark01(58.536392134289706,1.9010310243312364E-9 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark01(58.5543401037487,-61.26157695492915 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark01(58.58878437396666,-17.876811699726105 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark01(58.802933336591614,0.0 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark01(-58.993720059878086,0 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark01(-59.051943550247294,37.70516840755656 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark01(-59.13278520333627,3.4490458015041128 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark01(59.20185719858003,-129.7553734968928 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark01(-59.2619049561281,0.36161142373098054 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark01(59.386446032101404,-9.683778978471025 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark01(-59.46787841567399,-100.0 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark01(-5.955023770876593,0 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark01(-59.69025689597177,-43.98229736004852 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark01(-59.690256932269364,-69.11528435244244 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark01(-59.69025905587693,0.002054101375170433 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark01(-59.69026028353794,-48.694686128913084 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark01(59.72167996067776,-40.946462481244005 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark01(-59.723193684067866,-16.344988933486682 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark01(59.72892545793974,0 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark01(-59.79786480701908,-5.8154753355558695 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark01(-59.927750545441945,2529.1486522617806 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark01(-59.966018323521496,-1.570796326794897 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark01(-60.008703357135865,58.00611414846176 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark01(-60.128562313733646,-4.5075125600259724 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark01(-6.026720300852897,0.0 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark01(-60.2950648660326,4.468881715169034 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark01(-6.035429446407698E-8,-182.18941122893554 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark01(-60.3840461552567,-47.949351397270526 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark01(-60.55731349831065,33.98450162494414 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark01(-60.73264623166486,-0.018034437372922103 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark01(-60.89036807949557,7.625263100511859 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark01(-60.8972142960442,2534.918091684756 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark01(-60.953829197247636,-94.77803815489916 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark01(-61.129776571897956,0.0 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark01(-61.15602796325239,0.14833548737392763 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark01(-61.24140649839399,4.714342105386292 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark01(-61.259639503978875,1.5707963267948966 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark01(-61.25969697630124,-23.561942337503545 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark01(-61.26105534881163,-10.995570765709163 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark01(-61.26134119075868,86.39379632517414 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark01(-61.261516093488154,10.995570882118395 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark01(-61.26157374063897,1.5707963267948966 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark01(-61.26368658563988,-1.5707963267948966 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark01(-61.395531265740935,-40.53777972925208 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark01(-6.145863414778091,-0.22520873973985545 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark01(-61.46123870364624,-0.016789345814899548 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark01(-61.626729757290974,44.37985256429537 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark01(-6.1712432181541885,17.8663426540231 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark01(-61.73570441737994,89.53405163481213 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark01(-61.8712985253846,-86.39379797548335 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark01(-61.97375885970746,-67.04405742937153 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark01(-62.193630675644044,-1.5707963267948966 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark01(-6.222568035473948,-31.35284137723974 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark01(-62.3226271587044,0 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark01(-62.36765159053517,-82.19526438854167 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark01(-62.52817624085083,-91.2725164293807 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark01(-62.537393046373644,-8.778526796790423 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark01(-62.56879903454377,2643.8153289889515 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark01(-62.7267131483682,-27.45623033437201 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark01(-6.283185307179585,0.0 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark01(-6.2831857666403135,-69.1174890565002 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark01(-6.283200947120302,67.54424200103456 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark01(6.283222565317419,-37.70811907580562 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark01(-6.283246358950498,12.566370539980076 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark01(6.283507646020716,-62.85735990120115 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark01(-6.283689643813821,108.38592318133215 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark01(-62.85698420271422,-17.222326023101502 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark01(62.86122805336183,-80.55677061495273 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark01(-62.89435307179587,1.5707963267948966 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark01(-62.894353071833166,-6.776263578034403E-21 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark01(-62.89435307886461,56.54866776456493 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark01(62.911899795864656,79.88282605454441 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark01(62.954843711067895,-1.5707963267948966 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark01(6.298810307179587,-88.10220894829831 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark01(6.298810307179588,43.863014291911675 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark01(63.08006360174895,-45.31487592608107 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark01(-63.08671721638572,8.94554561203229 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark01(-63.11705683436153,-50.3638351096179 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark01(-63.13786309335987,-2558.7033559703345 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark01(63.14533414281739,-57.488291957444915 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark01(63.22732700307232,43.07357538283842 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark01(-63.254276283069515,1.5707963267948628 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark01(63.28961845050744,-17.870800022148902 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark01(63.3145784048545,0.13587836557889094 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark01(-63.381379901598365,82.78329927989839 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark01(6.345685307179588,49.9851306653332 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark01(6.345842215087978,-14.429203862590626 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark01(6.348340759951498,101.35440495892199 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark01(-6.355828442516062E-8,-81.67880320936148 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark01(-63.65279947793328,0.0 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark01(-63.73321273241316,0.49950478752860056 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark01(63.79263410502348,1.2775846828789443 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark01(63.82506621048106,0.5572665897154986 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark01(63.8300797571448,-1.1819873417082818 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark01(63.86110156488728,19.544585535358266 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark01(63.979004840172536,2616.7087137211493 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark01(-63.99354969823878,71.60107961329433 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark01(64.00243622402806,-66.03466852083007 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark01(64.05708775302267,-2.7920275328468245E-4 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark01(-64.05903228532156,-2613.7056177436657 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark01(-64.06531596900133,-2.478123898395926 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark01(-64.1010518051355,-77.16972602884277 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark01(-64.12296378406448,48.15019773795214 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark01(6.413886723003046,63.378185794395336 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark01(64.1806059942364,123.79834751630122 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark01(-64.20697617329924,0.570763345148762 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark01(-6.436607184806078,-157.3135076496889 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark01(64.40036017525097,1.5707963267948966 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark01(64.4020196525387,-1.5707963267948966 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark01(6.4424167657123474,130.57729667528008 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark01(-6.448825320839575,-45.553093477052 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark01(6.459523905929608,21.909371011857104 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark01(6.460848069884322,-0.6036478931434134 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark01(64.67134859012951,1.5707963267948963 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark01(64.6727194504374,0.0 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark01(6.473854457037172,-3.975716164044176 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark01(64.91890310595309,-63.337153144193145 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark01(64.93255348678574,4.849966984538727 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark01(-64.95864733581351,-72.49848775570102 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark01(64.96826295092846,44.39301884925702 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark01(-64.97162407428517,-21.055460469332438 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark01(65.03125429393998,-43.556997330997895 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark01(65.2287891687929,-13.67935137187473 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark01(-65.23460373176667,-59.18033805035843 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark01(65.3070497731675,-0.8335640549988739 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark01(6.533185307179825,-100.0 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark01(6.533185307180258,43.88145914407838 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark01(6.533185308747548,6.7013549483268475 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark01(6.535992078555111,1.5707963267948983 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark01(65.43890789810831,45.04036509466001 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark01(65.48814156478852,95.76064474767804 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark01(-65.49902718022385,-54.156680612637075 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark01(-65.62224288435542,-10.99567132325105 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark01(-65.64120719031767,1.5707963267948983 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark01(-65.74770688403274,0.9739855829096961 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark01(65.78467347344724,-1.5707963267948966 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark01(6.582370171392029,5.495176851236935 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark01(-65.85082549447232,2630.0241441577837 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark01(-65.95783845171711,-22.37458731765261 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark01(-65.9734422141239,-43.98242272727129 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark01(-65.97344399541747,0.0018634101665838325 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark01(-65.97344463023168,-81.67923008997403 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark01(-65.97344557457342,42.4115008234622 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark01(-6.60660620077158,-12.257874865463975 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark01(-66.06782959535872,-95.19558090332762 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark01(-66.09681924798397,81.89390677199822 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark01(-66.13239715288833,-88.53493507121408 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark01(-66.17833046415561,26.977646923859382 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark01(-66.190063607447,0.43841777946965943 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark01(-6.623551377040203,71.97496576549275 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark01(-66.26588020187228,75.00537205137971 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark01(-66.30419989583214,1.5707963267948966 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark01(-66.34394985921877,-19.728564970373757 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark01(-66.388385602245,-61.689870204539886 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark01(-66.39396708519206,-100.0 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark01(-66.42665910192505,-2630.90062668744 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark01(-66.4316069060059,-1.5707963267948948 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark01(-66.52033288775918,73.68015777428405 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark01(-66.59669856679227,-0.19391839079152418 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark01(-66.6387980719556,-64.63584716627604 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark01(-66.74304916569314,1.5707963267948957 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark01(-6.674424427379436E-17,17.278759594742954 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark01(66.94817494360336,-2610.8419575503526 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark01(-66.96631173576787,75.09195851651876 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark01(-67.03104499854686,-31.75064145243647 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark01(-67.05849400236143,-0.38599557092954784 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark01(6.7380779484226325,-38.70529577595784 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark01(-67.42362113861559,32.770275803150696 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark01(-67.47522458909295,-17.077519448650065 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark01(6.748024137298401,-14.383366380629042 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark01(-67.54161221154169,1.5707963267948966 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark01(-67.63263804078383,70.35601176265521 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark01(-67.69646918129088,4.8373889867984365 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark01(-6.776263578034403E-21,-1.5707963267948966 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark01(6.7817555862265495,37.82594682149355 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark01(6.784192193838927,-45.00660415109617 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark01(6.800024847328204,32.699576674639076 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark01(-68.34364678312983,1.263097451048555 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark01(68.4005736087467,-0.9489359668339432 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark01(-6.849604639001129,21.300335797100672 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark01(-68.50076234406262,-32.73371959757978 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark01(-68.60133561072081,1.5707963267948966 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark01(-68.6133182833757,98.85213345065254 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark01(68.8713991616633,0 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark01(6.889475002931405,21.679595530400817 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark01(-68.94845110628123,72.05803790834057 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark01(-69.1150213462551,-0.008051616332123446 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark01(-69.1150393063915,-62.831420552470405 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark01(-69.11699150399637,-113.09774464653992 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark01(69.11896004925075,0.032374663123211196 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark01(-6.918639184991562,-78.40243619434715 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark01(-69.18939333884427,0.0 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark01(-69.26155842905399,9.022174403620895 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark01(-69.27417655047753,-0.022479492943641925 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark01(-69.28101504424231,1.3547778861343431 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark01(-69.3293694172674,-66.7893767717029 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark01(-69.36835832377412,-69.45010946792357 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark01(-69.36899522905563,95.96439839630443 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark01(69.38728275698296,-0.019830411176210587 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark01(-6.938893903907228E-18,1.5707963267948966 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark01(-6.938893903907228E-18,1.5707963267948977 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark01(-6.938893903907228E-18,-81.68229401778956 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark01(69.45949187521597,-34.65243335587007 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark01(69.4701765573991,-57.20917012805469 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark01(69.4996502192914,1.570188507081362 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark01(-69.53431781243766,91.56122546879277 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark01(-69.55096989473752,-31.292419171866854 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark01(-69.55345394090547,56.69847036730886 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark01(69.64800045963591,1.056510508763321 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark01(6.9716732230748875,-34.417184735342744 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark01(-69.73758801719245,0.0 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark01(69.73894079108945,41.659017150494996 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark01(-69.76434346027506,1.5707963267948966 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark01(69.84131404985818,94.3254859687149 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark01(69.967346547087,50.875354750759186 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark01(69.97987477368714,0.0 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark01(70.01443911443084,-89.45089471566175 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark01(70.05666684365889,92.04460906527896 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark01(-70.09959673879163,-1.5707963267948968 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark01(7.01191468473904,-6.491750473466444 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark01(-70.123948215426,95.09457618743886 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark01(70.13559884019114,0.04966147184045321 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark01(-70.25347701403385,-0.5195744390964165 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark01(-70.2859070060905,1.5707963267948968 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark01(70.43348460992244,-36.30299012519957 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark01(70.46050040628475,-6.223443349216467 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark01(-70.58387725394184,-87.01214980542036 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark01(-70.60574414505957,0.009778088964988168 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark01(70.6081069033865,0.0 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark01(-70.63695091176069,-98.96016892420242 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark01(70.68320486513146,-1.5707963267948966 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark01(70.68583456367139,-1.570800145895275 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark01(-70.86539732545634,2.220446049250313E-16 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark01(7.103959917044711,-23.83643308778293 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark01(7.105427357601002E-15,-65.46771432441483 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark01(-7.105427357601002E-15,96.74112860473068 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark01(7.111296772236415,0.0 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark01(71.13595650050812,95.9393330262977 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark01(71.13875435614983,57.4461171904677 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark01(71.22858994199629,9.692203575654027 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark01(71.28764513950455,-0.7077706792984182 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark01(-71.36782881235774,-96.60783948447424 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark01(-7.158967224445258E-17,1.5707963267948968 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark01(71.59835685751636,3.5021033232564065 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark01(71.64337700605522,-6.430225215418308 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark01(71.65822087285184,1.5707963267948966 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark01(-71.67568320993624,-43.35891599221122 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark01(71.99384429012555,97.9788353396346 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark01(72.02854983835695,0.0 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark01(72.05908430509504,77.8882962442247 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark01(-72.0729884012722,54.977871439251615 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark01(-7.2127283980662895,-8.660757287180118 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark01(-72.12744283157487,-7.6162125610913165 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark01(-72.14651655285061,-1.5707963267948968 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark01(72.18770888428551,101.77122511902573 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark01(-72.2566236236946,-6.203719518434692 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark01(-72.25663102462438,120.95133761074008 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark01(-72.25663103256522,1.5707963267948966 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark01(-72.27789671836427,5.007850996982246E-15 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark01(-72.36550571393568,-31.5055324104338 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark01(-72.40524136883192,27.748533712217167 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark01(-72.42645498140972,1.5707963267948966 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark01(-72.44647722728993,-27.65684661566621 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark01(-72.55649157222652,-73.82742735936014 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark01(-72.71896789866439,-1.5707963267949054 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark01(-72.84855085331824,1.5707963267948968 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark01(-72.85998394441272,44.29973300795044 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark01(-72.90042301390149,-1.5707963267948972 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark01(-73.03400268254099,0.0 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark01(73.09759926173928,-2721.2928417096723 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark01(-7.318426031034207,168.07526485460795 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark01(-73.19157046890709,-67.60666233938124 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark01(-73.20110046992978,-0.5804574908154198 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark01(-73.30435475984554,-1.5707963267948966 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark01(-73.37719022221972,67.39059992681354 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark01(-73.43494314346593,0.0 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark01(7.351628817426495,47.045194740266304 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark01(-73.57173822910055,0.0 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark01(-73.73988357487961,82.0042544788923 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark01(-73.81111016220285,42.41153555916129 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark01(-73.82479751872194,-1.5707963267948983 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark01(-73.8274273513864,-136.65521584564405 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark01(-73.82791360850898,-4.712385588317629 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark01(-74.39432763434777,-0.03388552696619878 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark01(-74.52246845021975,26.06688018206929 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark01(-74.58829022742532,-79.36018643397287 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark01(-74.60606046219179,-76.67675093839067 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark01(-74.70365679158589,0.0 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark01(-74.84315394592029,0 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark01(-74.84949705795387,-20.235476093041314 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark01(-74.90058754972544,-131.32460351365745 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark01(7.502524029665409,-2516.6136717950762 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark01(7.505863465006865,-1.5707963267948983 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark01(-75.35246097467336,1.5707963267948966 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark01(-75.35802779975238,88.24904999972486 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark01(-75.38920096525254,-2.258317153603599 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark01(-75.39822368615503,0 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark01(-75.39822577395785,81.67973953180844 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark01(-75.43134199044331,78.53247538134295 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark01(75.43664232657977,-138.59635652939085 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark01(75.43833554514896,53.65372936303251 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark01(-75.45991438121233,-1.5707963267948966 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark01(-75.58570438163335,22.611637504408534 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark01(-75.60818302031412,-2609.292522306127 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark01(-75.6404188475472,81.65209130791476 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark01(75.66926220173775,0.0 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark01(-75.70535433819288,1.5707963267948966 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark01(-75.72257761889058,0.028103489318033255 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark01(75.76852293948272,-2.601127019808943E-9 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark01(-75.79082286688677,-1.5707963267948966 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark01(-7.579105312308414,-1.5707963267948966 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark01(-75.79194291619038,3.086180979113421 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark01(75.82495400920084,54.15454915345305 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark01(75.92097052659412,-8.595913425084078 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark01(-75.9983281816975,-1.5707963267948912 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark01(76.00619592080321,101.658601882203 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark01(76.03671231636477,-50.38369830634748 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark01(7.603696350502798,-4.74406000274309 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark01(76.15887134467434,-1.5707963267949054 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark01(-7.627418372415718,-1.5707963267948966 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark01(-76.3341068250669,88.8342550778359 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark01(-76.39644433904789,7.656689176959304 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark01(-76.4305543390115,-72.75432965435682 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark01(76.50445641395368,0.5767799638857225 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark01(76.53731765941771,-47.41097605598886 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark01(76.5580280896265,-135.24862200118326 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark01(-7.658418098304651,1.5707963267948966 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark01(76.62752583773718,8.881784197001252E-16 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark01(-76.70069258800928,-37.13543754854571 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark01(7.676540242808347,-58.98532008915814 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark01(-76.90195488318929,80.33098979549055 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark01(-76.90917293199199,-0.5668084637365346 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark01(76.96902002594332,17.278756072504695 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark01(76.96933254500854,-4.712386179379594 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark01(76.97091940919174,0.0 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark01(-76.98106731734742,146.1751064072299 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark01(-7.703719777548943E-34,1.5707963267948966 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark01(-77.07095583249985,-79.33193353884988 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark01(77.08337893308095,0.0 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark01(77.08848958540351,0.0 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark01(77.08924124684668,-64.96100182486137 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark01(-77.11515375725021,2531.377562664775 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark01(-77.14693655175554,1.5707963267948966 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark01(-77.15031759087954,0.0 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark01(77.16639536522624,-27.136850036045885 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark01(-77.17718754085514,-32.90938528570911 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark01(-77.18245932048536,63.582563073363 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark01(-77.19969275123265,1.5707963267948912 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark01(77.21035958190373,49.27096779557011 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark01(77.22778172233001,1.868903257194523 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark01(-77.27011312747632,30.2842884360783 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark01(-77.27978544453154,-2.4384079493519266 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark01(77.30403512363611,0.2715479639078385 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark01(-77.38817500727436,0.0 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark01(-77.39170624160651,79.93670713877015 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark01(77.41709735156832,175.17117130844832 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark01(-77.42212024184153,2653.7489113102265 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark01(77.44206487338505,1.5707963267948966 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark01(-77.47335947232047,-26.380425971703136 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark01(77.4755340942114,-0.5707068855463638 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark01(77.50653613645218,45.41160499291302 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark01(77.5555679551666,-100.0 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark01(-77.5857946470758,-5.717379902021506 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark01(-77.64369001780078,71.42536370611217 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark01(-77.6859269442393,22.61047313252118 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark01(-77.69056373017906,16.07987724579256 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark01(7.774607839156717,130.37597024548467 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark01(7.7749285051364305,-98.96016858807847 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark01(7.7749569463952355,-10.995574287183961 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark01(7.7751447162609,-183.7841467822429 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark01(-77.7940119033364,-87.79471217711396 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark01(-77.83030432678966,-9.710395135817322 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark01(-7.783705841536105,0.0 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark01(-77.86312312070332,0.17996786928936764 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark01(-77.86623155826999,23.03507799762032 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark01(-77.90627413349446,-5.444566108967464 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark01(-77.93203376131746,-68.67933678509677 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark01(7.793827411893901,-1.5710405923466895 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark01(7.794871918998891,83.2522053203305 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark01(7.795018586746339,-111.52618721692413 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark01(7.79580011587779,-4.7123768459668565 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark01(7.79919494480725,-1.5707963267948977 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark01(-78.01058535746326,0.0 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark01(7.801919207313865,124.0929053911559 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark01(-78.0288611961136,0.0 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark01(78.04022403293979,-24.16722538521799 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark01(78.09963842018601,48.58194371891284 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark01(-78.18750030333791,1.5707963267948966 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark01(78.2306143095013,89.31536822819375 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark01(78.23294349316778,38.1054939475128 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark01(-78.2823862391722,27.759048157452668 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark01(-78.29736582791661,-84.99763584600365 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark01(78.3325186479926,2585.5866547410246 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark01(-78.3612291857913,25.6084617334664 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark01(78.38468936235687,-0.5633059295252599 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark01(-78.39575232298128,90.10078048384588 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark01(7.840221748938962,-1.570800141497852 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark01(78.4036662646342,-1.5707963267948966 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark01(78.41884840840402,-55.18847358039807 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark01(78.42714519456464,-81.46547844337991 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark01(78.42938546596761,95.79193593539628 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark01(78.43957164510464,31.577164215278387 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark01(-78.45892343648632,-0.8528205008484293 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark01(-78.51639207602138,-49.94088274852122 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark01(78.5279718400157,37.545041627500176 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark01(-78.52840915958996,67.91222043863613 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark01(7.853801165195993,-10.995570786049994 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark01(-78.53981281750535,0.0 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark01(-78.53981281750535,2.1684043449710089E-19 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark01(-78.53981281750924,87.96459414267753 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark01(-78.53981282656437,-81.68139524252317 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark01(-78.53981301797647,43.98224156559924 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark01(-78.5398139022223,-31.41636981038265 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark01(-78.53981559475149,-2.4376911063169913E-4 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark01(-78.53981633959256,-1.5707963267949288 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark01(-78.57309514473698,63.09053945510146 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark01(-78.58435961230776,74.67814472946316 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark01(-78.60245993133586,0 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark01(-78.60480714334574,44.41138119253725 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark01(-78.61082899291192,-14.171190240502284 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark01(-78.75105388279603,-7.7430064958954725 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark01(-78.84451435661771,-74.60080100720481 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark01(-78.93283611417829,-86.81153408271798 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark01(-79.30810836746245,2585.2516980449136 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark01(-79.40638786548917,-11.030823667055252 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark01(-79.97457126091612,0.9907713215651223 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark01(-80.11054167477447,-83.25220567852834 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark01(-80.1106263366319,127.250138491934 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark01(-80.39335845768616,73.952920843474 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark01(-80.77941134281798,0.0 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark01(8.103981667929217,89.53545166552007 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark01(-81.16933010529574,94.83734160814953 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark01(-81.23004600387887,123.60381109139708 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark01(8.129388372322268,-6.452442868804273 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark01(-81.41313337499615,-72.12495594984006 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark01(-8.14433035110649,-226.6404479226386 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark01(8.150444260993009,15.598042545536966 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark01(-81.550692995594,145.1155459653641 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark01(8.157709719034386,0.0 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark01(8.162212702200378,1.5707963267948948 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark01(81.67559863179258,0 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark01(-81.68141204897631,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark01(-81.68143951091275,1.5707963267948966 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark01(-81.68143951263167,81.68140899370353 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark01(81.68546587044563,0 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark01(-81.68930212678292,-0.014263137185708371 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark01(81.69652253172148,-0.1740813508079767 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark01(-8.173888689888601,-15.868822730885284 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark01(81.740025733874,1.5707963267948983 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark01(-81.76964947838925,31.709264998916098 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark01(81.7939978121243,45.477386782389914 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark01(8.18032575228617,-4.837388980384691 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark01(-8.1846242736231,0.0 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark01(-81.85276282613128,-35.65932068299942 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark01(81.85447425285847,-0.3821174008709375 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark01(-81.86071469750019,-15.545300183865663 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark01(-81.95341868633173,42.861088733088934 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark01(8.196362011074516,-81.55147768939474 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark01(81.96765155802902,0.0 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark01(8.214073657583874,2521.561949305114 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark01(82.14223784654502,90.41360181933734 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark01(82.1714916135721,-100.0 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark01(-82.23173432565719,1.5707963267948912 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark01(82.3088833587804,-45.410506753895916 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark01(82.39247991184834,-2645.0095727192383 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark01(82.40013007875856,-60.45465784923392 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark01(82.4352189024161,117.79654683581174 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark01(-82.45495757573475,0.0 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark01(-8.24755359859157,-0.01014302859438449 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark01(-82.47670590313108,-81.69084274393987 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark01(82.51808253750852,-21.87440744735207 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark01(-82.54223947539592,1.5707963267948966 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark01(82.65766520378797,-136.19512858483267 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark01(-82.66605068400084,0.029381487231143866 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark01(-82.72949327765606,10.860598653367674 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark01(82.94248707250799,-41.90772896131245 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark01(82.95321350215858,-1.5707963267948966 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark01(8.295372041274913,25.839122560249645 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark01(-83.00252706356832,107.56062312466207 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark01(83.01986908018442,-11.066945741981904 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark01(-8.304375145705718E-22,-7.861794148442062 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark01(83.09546752725981,1.5707963267948966 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark01(-83.12341222213695,0 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark01(83.13054621632132,1.5707963453972924 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark01(83.18853398167555,0.0 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark01(-8.319163198187622,78.75196413760335 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark01(83.24965933283111,42.411500604426365 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark01(8.325227567372744,-2558.8595014607663 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark01(83.25427922857018,-48.69468480967581 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark01(83.25466516040075,1.5707963267948966 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark01(-8.328844467813596,-169.45354622146658 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark01(-83.29212145480003,-84.24380088343572 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark01(-8.333000739545458,-7.737843645755121 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark01(83.3393511491443,-68.18769829984569 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark01(83.34452752050572,4.6824927159873795 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark01(-83.34478938403754,-148.74752893544928 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark01(83.37816827587915,-0.058447663516216934 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark01(83.39323571058003,-1.5707963267948983 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark01(-83.40662559252482,-1.5707963267948966 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark01(83.40694916401989,-67.871874427371 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark01(83.45163188909041,1.5628880998197667 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark01(8.347551277422681,1.5707963267948966 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark01(83.5252801282671,-44.158505461376436 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark01(8.358154434620744,-73.3807011236367 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark01(83.7091722511402,-0.5693904642504185 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark01(8.37917512257891,-53.39309624788065 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark01(-83.82130574168784,41.340486891227755 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark01(8.386059852433725,99.99652247125945 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark01(83.89015942845687,20.259841975220354 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark01(83.96982041372135,-89.19782578300983 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark01(-8.408646411705496,-0.004762684889921674 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark01(84.10252317146274,-1.5710320983109818 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark01(-84.1207714347905,3.552713678800501E-15 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark01(84.12639110659202,11.688886348692478 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark01(-84.20773959051154,1.570796326794897 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark01(-84.25509239097813,7.4459424932430505 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark01(84.29274247594924,-1.5707963267948972 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark01(84.5107070703809,-4.7154974294989636 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark01(-84.53671241784906,-1.5707963267948966 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark01(84.54299287999747,1.5707963267948966 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark01(-84.5744838471689,-0.1122934644504695 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark01(84.58136541352577,-81.71599761485129 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark01(-84.58966383062682,-136.1503376605093 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark01(-84.59833995638823,54.504705782469784 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark01(-84.62751062420597,0 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark01(84.66434355757752,82.50584918989281 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark01(-84.67147167758924,-9.54296751360487 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark01(-8.470329472543003E-22,-0.008457552741775683 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark01(-84.7218787658621,0.003125660858753876 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark01(84.79892192477186,1.5707963267948968 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark01(-84.80175453554921,1.5707963267948966 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark01(84.8215797425547,-12.740444577183283 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark01(-84.82299572392564,88.08959430051553 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark01(-84.82299813149842,-69.11494369093869 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark01(-84.82299816480844,-3.110964078053124E-4 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark01(-84.8229985668076,50.266398571879925 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark01(-84.82299994841216,163.36470350092867 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark01(-84.82300087184217,12.566370439012378 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark01(-84.82300164654818,-1.570796326794898 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark01(-84.8230016466543,-1.5707963267948966 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark01(84.8230016469244,0.0 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark01(-84.8230016469244,54.977853898762575 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark01(-84.87629937078367,36.76933296303261 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark01(-84.87819798566838,-44.687878329482956 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark01(-84.88747568563878,-63.59732881650941 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark01(-84.89515078181171,47.742870379858175 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark01(-84.94582968051242,-0.5778368984740843 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark01(-84.98339091351474,-44.09233149096296 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark01(-85.12383889753917,4.552980073047176 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark01(8.528616042664154,0.0 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark01(-85.41454596012292,-226.580792630093 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark01(85.44135396754385,50.93043118065256 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark01(-85.67482461371867,62.48966911882067 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark01(-86.02038821258189,20.895609759638376 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark01(-86.0598503913827,-42.4115008234623 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark01(-86.07372998751698,-1.1107493509534048 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark01(86.15863523153817,0 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark01(-86.23448957473616,-2588.275155405432 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark01(-86.31825271249534,84.02689826481722 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark01(-86.3937816399638,-4.712385458680726 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark01(-86.39379797371441,-155.50876030253465 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark01(-86.3964278143582,1.5707963267948966 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark01(-86.43617918732507,0.0 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark01(-86.47787404629813,165.5388113701753 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark01(8.673617379884035E-19,0.0 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark01(8.67607714409511,96.89057526893069 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark01(-87.0068502108108,17.08984146142326 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark01(-87.14993459053954,-82.07585019159865 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark01(-87.52463854232798,94.27776609462079 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark01(8.757836565797394,-15.14522755099577 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark01(8.758115402030107E-47,32.51315902109635 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark01(-87.59845011767995,-1.5707964113133672 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark01(-87.85295852032222,-125.18097954277734 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark01(-87.96459679686333,-94.2475884994538 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark01(87.96462481809235,0.0 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark01(-87.96846335465767,2.0224971531576394 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark01(-87.96894148450141,-6.204607349868583 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark01(-87.99162552934072,-75.6276901756714 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark01(88.03266831712605,-0.5459684461778298 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark01(-88.0394492892683,0.0 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark01(-88.04645207333665,2.5574674155770936 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark01(-88.05160270215737,24.477393016696098 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark01(88.09019092899138,-0.5059111987965338 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark01(88.09664555473552,0.0 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark01(88.13228338863527,-41.797114293653294 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark01(88.22292579096538,0 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark01(88.24150829249567,66.07906785856636 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark01(-88.27790110842568,0.0 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark01(8.833852942183043,-25.771444403763894 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark01(8.837604176526128,-65.14364631858452 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark01(88.38316358819286,1.5707963267948983 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark01(88.38572081378805,11.094886247008011 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark01(88.48714555777556,1.5707963267948966 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark01(88.53340706466346,-90.33145025297038 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark01(88.53462743314583,0 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark01(8.853981633974534,-1.5707963267948983 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark01(-88.62780448043341,61.16928402148932 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark01(88.63547064582909,36.516304189239186 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark01(88.63782084503245,-50.33463301118146 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark01(88.67680235540887,-92.6547706732616 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark01(-88.70743018617759,0.0 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark01(88.75491152480751,-2.9175608629592773 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark01(88.78823667009588,-24.963099981842717 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark01(-8.881784197001252E-16,-100.0 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark01(-8.881784197001252E-16,10.138952281175492 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark01(-8.881784197001252E-16,25.122580665478452 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark01(-88.86609084523134,80.11062386751377 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark01(88.94947430134022,-110.50764123723843 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark01(-89.03743281760596,1.5707963267948966 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark01(89.04498817943548,-16.702729876705042 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark01(89.13390479368047,76.49828609415445 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark01(-89.22564657463566,7.042500757628602 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark01(-89.2278217115385,79.58235279057806 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark01(89.37351050028249,2618.293938376785 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark01(89.46864011589271,-72.96379998886142 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark01(89.5033957811924,1.5707963267948966 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark01(89.53276078667024,1.5707963267948966 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark01(89.53765702539214,-1.5707963267948966 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark01(89.53802046794733,-1.5707963267948983 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark01(89.53802046794802,-1.5707963267948966 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark01(89.5477608415832,42.366711773998844 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark01(89.55390783465992,-1.5707963267948966 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark01(89.5926140234535,-6.431508733927076 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark01(-89.60972019571743,65.98524509957332 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark01(-89.67068231685596,-1.5707963267948966 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark01(-89.67471690572162,1.5707963267948948 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark01(-89.68224487418392,0.0 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark01(89.68548105373296,-11.006815794795186 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark01(-89.77343354532128,-25.132741228718345 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark01(-89.80163786165504,0.0 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark01(89.85770809940024,23.56196749764409 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark01(89.8584613026454,-0.08872006237459651 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark01(89.87228563067629,0.0 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark01(89.87258375706514,-96.7634264154471 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark01(89.89196867977472,-83.44482813787553 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark01(-89.91288641590445,-43.04907331412882 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark01(-89.98162428360091,-99.20413173808984 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark01(89.99701214389785,-38.405050154171846 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark01(-90.01794762482467,-2644.2721632430926 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark01(90.04448401084618,3.655370362699152E-6 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark01(-90.05888385226149,1.5707963267948966 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark01(-90.11245249922699,0.0 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark01(-90.17755270622565,0.2680097661822155 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark01(-90.21302189849541,-36.43654745428613 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark01(90.24947426587076,0.0 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark01(-90.26318488263736,-41.77163093555567 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark01(90.37767795281911,38.23352909585208 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark01(-90.57124218993691,-0.281178276592023 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark01(-90.59943806910078,142.59505590113173 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark01(90.67800023874227,0.0 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark01(90.68749992489239,99.1916027149773 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark01(90.70426807661856,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark01(-90.70496127643547,0.0 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark01(-90.71627341102462,84.5053111085403 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark01(-90.7165451599918,26.80207034420043 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark01(-90.74837355996908,36.60751684300115 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark01(-90.77010495513575,36.807346792593194 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark01(90.7945480142572,1.2559687575350298E-15 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark01(90.82396575404735,-3.9969901146306057 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark01(-90.8388155987951,0.0 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark01(9.084169469262935,36.85441548267828 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark01(90.85682299355064,67.245719236455 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark01(-90.87525030400418,46.77692321352944 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark01(-90.8794582214706,0.015132267749002509 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark01(90.883304039609,-1.5707963267948968 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark01(90.88782439482546,47.70655430961091 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark01(-90.88783284092356,-2.6571032322623296 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark01(90.92689657362624,55.09998909772668 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark01(90.93220971493218,106.61554422353652 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark01(90.93284105341526,49.055018349141676 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark01(-90.9385877736867,-38.955349767128894 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark01(91.00222971787376,-31.75875518843239 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark01(-91.020111755496,6.287336505235964E-4 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark01(91.08963178573212,55.82590238994541 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark01(-91.1061254981574,51.83627879191148 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark01(-91.1061834504968,-50.26565245245592 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark01(-91.10618410084345,6.284317734897442 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark01(-91.10618420891691,0.0 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark01(-91.10618569807464,-42.41150082345796 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark01(-91.10618695410398,-6.204210860609816 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark01(-91.12667077157575,0.2027484544953205 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark01(-91.12723709173832,-8.339573196552541 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark01(-91.13556047894953,0.13995468578517448 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark01(-91.13639272298173,0.0 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark01(-91.2596646582695,1.5707963267948968 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark01(-91.3163984884836,92.48748020416812 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark01(-91.43391578486451,95.77031619274337 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark01(-91.50547798025366,-47.831710717848864 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark01(-91.73029962083672,-0.03452840369038628 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark01(-91.8066914846836,0.0 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark01(-91.82986270654156,-1.2261579543393384 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark01(91.9560748136378,1.9069050470331632 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark01(-91.98791131477846,76.030267856382 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark01(-92.03432572999124,48.98083148143514 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark01(-92.05959260236259,0.0 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark01(-92.37998701920228,-10.620539299527014 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark01(-92.39511798761515,64.42082732600007 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark01(-92.4581366377824,-0.5540920632489895 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark01(-9.254367877305858E-9,155.50883633223435 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark01(92.55079637965673,0 ) ;
  }

  @Test
  public void test2476() {
    coral.tests.JPFBenchmark.benchmark01(-92.64026697717303,-15.807367886850052 ) ;
  }

  @Test
  public void test2477() {
    coral.tests.JPFBenchmark.benchmark01(-92.67454984410337,1.5707963267948966 ) ;
  }

  @Test
  public void test2478() {
    coral.tests.JPFBenchmark.benchmark01(-92.67578315235195,-61.261056534357294 ) ;
  }

  @Test
  public void test2479() {
    coral.tests.JPFBenchmark.benchmark01(-92.67580003294887,10.995571830095829 ) ;
  }

  @Test
  public void test2480() {
    coral.tests.JPFBenchmark.benchmark01(-92.67623549675022,36.128312292000984 ) ;
  }

  @Test
  public void test2481() {
    coral.tests.JPFBenchmark.benchmark01(-92.6769829421858,32.99062911308804 ) ;
  }

  @Test
  public void test2482() {
    coral.tests.JPFBenchmark.benchmark01(-92.67959009547772,-1.5707963267948966 ) ;
  }

  @Test
  public void test2483() {
    coral.tests.JPFBenchmark.benchmark01(-92.7456308746857,-158.39182863009097 ) ;
  }

  @Test
  public void test2484() {
    coral.tests.JPFBenchmark.benchmark01(-92.92133104634812,-1.5707963267948966 ) ;
  }

  @Test
  public void test2485() {
    coral.tests.JPFBenchmark.benchmark01(-93.03074087060786,80.18041533236237 ) ;
  }

  @Test
  public void test2486() {
    coral.tests.JPFBenchmark.benchmark01(-93.13273490655816,11.606581986887349 ) ;
  }

  @Test
  public void test2487() {
    coral.tests.JPFBenchmark.benchmark01(9.321331302987057,30.94673617108266 ) ;
  }

  @Test
  public void test2488() {
    coral.tests.JPFBenchmark.benchmark01(93.36426935339082,70.67493969407289 ) ;
  }

  @Test
  public void test2489() {
    coral.tests.JPFBenchmark.benchmark01(-93.67017039328493,-13.587050192419838 ) ;
  }

  @Test
  public void test2490() {
    coral.tests.JPFBenchmark.benchmark01(-93.82087654382549,10.207173360354147 ) ;
  }

  @Test
  public void test2491() {
    coral.tests.JPFBenchmark.benchmark01(9.389760795407184,-75.2652198491486 ) ;
  }

  @Test
  public void test2492() {
    coral.tests.JPFBenchmark.benchmark01(-94.01181634199318,0 ) ;
  }

  @Test
  public void test2493() {
    coral.tests.JPFBenchmark.benchmark01(-94.02184495555926,-93.1424184955564 ) ;
  }

  @Test
  public void test2494() {
    coral.tests.JPFBenchmark.benchmark01(-9.424771116218313,-10.995574287564274 ) ;
  }

  @Test
  public void test2495() {
    coral.tests.JPFBenchmark.benchmark01(-9.424774438529893,8.673617379884035E-19 ) ;
  }

  @Test
  public void test2496() {
    coral.tests.JPFBenchmark.benchmark01(-9.424776274863646,-0.0018921037182430664 ) ;
  }

  @Test
  public void test2497() {
    coral.tests.JPFBenchmark.benchmark01(-9.42477791722996,5.212388980384497 ) ;
  }

  @Test
  public void test2498() {
    coral.tests.JPFBenchmark.benchmark01(-9.424777950662778,81.68403502324618 ) ;
  }

  @Test
  public void test2499() {
    coral.tests.JPFBenchmark.benchmark01(-9.42477795776804,-12.564099840550572 ) ;
  }

  @Test
  public void test2500() {
    coral.tests.JPFBenchmark.benchmark01(-94.24778151504243,1.5707963267948966 ) ;
  }

  @Test
  public void test2501() {
    coral.tests.JPFBenchmark.benchmark01(-94.24778269943484,-69.11503838068566 ) ;
  }

  @Test
  public void test2502() {
    coral.tests.JPFBenchmark.benchmark01(-9.424882360875895,0 ) ;
  }

  @Test
  public void test2503() {
    coral.tests.JPFBenchmark.benchmark01(94.26397260859886,0.0 ) ;
  }

  @Test
  public void test2504() {
    coral.tests.JPFBenchmark.benchmark01(94.2790296076938,0.0 ) ;
  }

  @Test
  public void test2505() {
    coral.tests.JPFBenchmark.benchmark01(-94.27902983355364,-67.5442418483515 ) ;
  }

  @Test
  public void test2506() {
    coral.tests.JPFBenchmark.benchmark01(-9.431218576324543,57.13432956716329 ) ;
  }

  @Test
  public void test2507() {
    coral.tests.JPFBenchmark.benchmark01(94.3398962383514,74.77704894692945 ) ;
  }

  @Test
  public void test2508() {
    coral.tests.JPFBenchmark.benchmark01(94.36301170861182,87.62104371585409 ) ;
  }

  @Test
  public void test2509() {
    coral.tests.JPFBenchmark.benchmark01(94.36756994124895,-42.41162542024701 ) ;
  }

  @Test
  public void test2510() {
    coral.tests.JPFBenchmark.benchmark01(94.5000964861133,94.96998174703528 ) ;
  }

  @Test
  public void test2511() {
    coral.tests.JPFBenchmark.benchmark01(-94.53289918838297,-74.00324759828023 ) ;
  }

  @Test
  public void test2512() {
    coral.tests.JPFBenchmark.benchmark01(94.74141160426649,-75.87617179082497 ) ;
  }

  @Test
  public void test2513() {
    coral.tests.JPFBenchmark.benchmark01(94.77813500702774,-0.5090924400321591 ) ;
  }

  @Test
  public void test2514() {
    coral.tests.JPFBenchmark.benchmark01(94.87891107868315,29.589229892531733 ) ;
  }

  @Test
  public void test2515() {
    coral.tests.JPFBenchmark.benchmark01(-94.88654014879039,1.5707963267948966 ) ;
  }

  @Test
  public void test2516() {
    coral.tests.JPFBenchmark.benchmark01(-9.490691750643297,-3.932191618448482E-6 ) ;
  }

  @Test
  public void test2517() {
    coral.tests.JPFBenchmark.benchmark01(94.92488258627029,-74.85151264771858 ) ;
  }

  @Test
  public void test2518() {
    coral.tests.JPFBenchmark.benchmark01(-9.494812778945288,56.569090134739895 ) ;
  }

  @Test
  public void test2519() {
    coral.tests.JPFBenchmark.benchmark01(-95.00739054797617,-64.18698372950374 ) ;
  }

  @Test
  public void test2520() {
    coral.tests.JPFBenchmark.benchmark01(95.13042253515587,20.394560153148856 ) ;
  }

  @Test
  public void test2521() {
    coral.tests.JPFBenchmark.benchmark01(-95.16172011657443,-52.821359870774856 ) ;
  }

  @Test
  public void test2522() {
    coral.tests.JPFBenchmark.benchmark01(95.16982549645566,55.5289849898129 ) ;
  }

  @Test
  public void test2523() {
    coral.tests.JPFBenchmark.benchmark01(95.17272726848893,-17.278760595582543 ) ;
  }

  @Test
  public void test2524() {
    coral.tests.JPFBenchmark.benchmark01(95.17642124316832,1.5707963267948912 ) ;
  }

  @Test
  public void test2525() {
    coral.tests.JPFBenchmark.benchmark01(95.19210276824634,0.0 ) ;
  }

  @Test
  public void test2526() {
    coral.tests.JPFBenchmark.benchmark01(-95.19903077215194,-49.881806574008735 ) ;
  }

  @Test
  public void test2527() {
    coral.tests.JPFBenchmark.benchmark01(95.22248584651993,-74.0007569290813 ) ;
  }

  @Test
  public void test2528() {
    coral.tests.JPFBenchmark.benchmark01(-95.22351348437333,-1.5707963267948966 ) ;
  }

  @Test
  public void test2529() {
    coral.tests.JPFBenchmark.benchmark01(-9.523358910553668,-1.5707963267948948 ) ;
  }

  @Test
  public void test2530() {
    coral.tests.JPFBenchmark.benchmark01(-95.35194588605685,-64.62824501174313 ) ;
  }

  @Test
  public void test2531() {
    coral.tests.JPFBenchmark.benchmark01(95.42293906216705,-97.00617799134417 ) ;
  }

  @Test
  public void test2532() {
    coral.tests.JPFBenchmark.benchmark01(95.43128990768207,136.1936224733655 ) ;
  }

  @Test
  public void test2533() {
    coral.tests.JPFBenchmark.benchmark01(-95.50462708878325,-2.804863864673917 ) ;
  }

  @Test
  public void test2534() {
    coral.tests.JPFBenchmark.benchmark01(-95.53181619000874,99.6494078591229 ) ;
  }

  @Test
  public void test2535() {
    coral.tests.JPFBenchmark.benchmark01(95.55881623303614,-0.9821092012260468 ) ;
  }

  @Test
  public void test2536() {
    coral.tests.JPFBenchmark.benchmark01(-95.63740239811025,-81.54274653371243 ) ;
  }

  @Test
  public void test2537() {
    coral.tests.JPFBenchmark.benchmark01(95.63908968212183,2633.893199867878 ) ;
  }

  @Test
  public void test2538() {
    coral.tests.JPFBenchmark.benchmark01(-95.77007758667116,0.0 ) ;
  }

  @Test
  public void test2539() {
    coral.tests.JPFBenchmark.benchmark01(-95.77721558019655,-5.269661213700786 ) ;
  }

  @Test
  public void test2540() {
    coral.tests.JPFBenchmark.benchmark01(95.81662280105785,45.5530950441366 ) ;
  }

  @Test
  public void test2541() {
    coral.tests.JPFBenchmark.benchmark01(95.81857596449274,-146.08407366789191 ) ;
  }

  @Test
  public void test2542() {
    coral.tests.JPFBenchmark.benchmark01(-95.84436559655593,33.38310773592693 ) ;
  }

  @Test
  public void test2543() {
    coral.tests.JPFBenchmark.benchmark01(95.92814303368557,37.707672034013 ) ;
  }

  @Test
  public void test2544() {
    coral.tests.JPFBenchmark.benchmark01(95.94172100629658,-12.44450753406754 ) ;
  }

  @Test
  public void test2545() {
    coral.tests.JPFBenchmark.benchmark01(95.94644325132808,-92.85305303772004 ) ;
  }

  @Test
  public void test2546() {
    coral.tests.JPFBenchmark.benchmark01(95.97422270895231,85.83320331808696 ) ;
  }

  @Test
  public void test2547() {
    coral.tests.JPFBenchmark.benchmark01(-95.990496785341,-1.5707963267948966 ) ;
  }

  @Test
  public void test2548() {
    coral.tests.JPFBenchmark.benchmark01(-96.32065177211605,-0.7583077926619374 ) ;
  }

  @Test
  public void test2549() {
    coral.tests.JPFBenchmark.benchmark01(-96.45724844379178,-71.02352570935312 ) ;
  }

  @Test
  public void test2550() {
    coral.tests.JPFBenchmark.benchmark01(96.4588440476405,7.105427357601002E-15 ) ;
  }

  @Test
  public void test2551() {
    coral.tests.JPFBenchmark.benchmark01(-96.48379500385127,-8.219100692686833 ) ;
  }

  @Test
  public void test2552() {
    coral.tests.JPFBenchmark.benchmark01(-96.53996388865849,91.20863898672644 ) ;
  }

  @Test
  public void test2553() {
    coral.tests.JPFBenchmark.benchmark01(96.68968501331915,-28.981392040063156 ) ;
  }

  @Test
  public void test2554() {
    coral.tests.JPFBenchmark.benchmark01(-96.85315447095437,-78.4579115151609 ) ;
  }

  @Test
  public void test2555() {
    coral.tests.JPFBenchmark.benchmark01(-9.701126572364018,0.4179218115042121 ) ;
  }

  @Test
  public void test2556() {
    coral.tests.JPFBenchmark.benchmark01(-97.07851549739387,-32.867874339773735 ) ;
  }

  @Test
  public void test2557() {
    coral.tests.JPFBenchmark.benchmark01(97.1737288694916,7.722928072903092E-16 ) ;
  }

  @Test
  public void test2558() {
    coral.tests.JPFBenchmark.benchmark01(-97.2315653888229,43.59855877068881 ) ;
  }

  @Test
  public void test2559() {
    coral.tests.JPFBenchmark.benchmark01(-97.38937226128357,-1.5707963267948966 ) ;
  }

  @Test
  public void test2560() {
    coral.tests.JPFBenchmark.benchmark01(-97.38937226128357,1.5707963267948966 ) ;
  }

  @Test
  public void test2561() {
    coral.tests.JPFBenchmark.benchmark01(-97.3893722612836,0 ) ;
  }

  @Test
  public void test2562() {
    coral.tests.JPFBenchmark.benchmark01(-97.40452819642435,-23.160910124317084 ) ;
  }

  @Test
  public void test2563() {
    coral.tests.JPFBenchmark.benchmark01(-97.42646439329695,97.08188961058102 ) ;
  }

  @Test
  public void test2564() {
    coral.tests.JPFBenchmark.benchmark01(-97.62866418962027,30.03481189976523 ) ;
  }

  @Test
  public void test2565() {
    coral.tests.JPFBenchmark.benchmark01(-97.721956055304,-11.734526355371838 ) ;
  }

  @Test
  public void test2566() {
    coral.tests.JPFBenchmark.benchmark01(-97.74549168765303,93.3863590168797 ) ;
  }

  @Test
  public void test2567() {
    coral.tests.JPFBenchmark.benchmark01(-97.79422309611721,-75.41630777352636 ) ;
  }

  @Test
  public void test2568() {
    coral.tests.JPFBenchmark.benchmark01(97.90257212587687,-1.5707963267948963 ) ;
  }

  @Test
  public void test2569() {
    coral.tests.JPFBenchmark.benchmark01(-97.93931554794221,-23.663115481727303 ) ;
  }

  @Test
  public void test2570() {
    coral.tests.JPFBenchmark.benchmark01(-97.94702801802015,48.8286666238088 ) ;
  }

  @Test
  public void test2571() {
    coral.tests.JPFBenchmark.benchmark01(-98.07474338096779,-32.71100819896013 ) ;
  }

  @Test
  public void test2572() {
    coral.tests.JPFBenchmark.benchmark01(98.13249798682652,-1.5707963267948966 ) ;
  }

  @Test
  public void test2573() {
    coral.tests.JPFBenchmark.benchmark01(-98.17149830069611,0.7865261954357656 ) ;
  }

  @Test
  public void test2574() {
    coral.tests.JPFBenchmark.benchmark01(-98.23261165132084,100.0 ) ;
  }

  @Test
  public void test2575() {
    coral.tests.JPFBenchmark.benchmark01(-98.23442691546573,-1.5707963267948966 ) ;
  }

  @Test
  public void test2576() {
    coral.tests.JPFBenchmark.benchmark01(-98.2440967243025,-10.934671157476009 ) ;
  }

  @Test
  public void test2577() {
    coral.tests.JPFBenchmark.benchmark01(-98.2782515370274,0.0 ) ;
  }

  @Test
  public void test2578() {
    coral.tests.JPFBenchmark.benchmark01(-98.34399519377766,1.3858394964273097 ) ;
  }

  @Test
  public void test2579() {
    coral.tests.JPFBenchmark.benchmark01(-98.41790702434339,44.21535032495072 ) ;
  }

  @Test
  public void test2580() {
    coral.tests.JPFBenchmark.benchmark01(-98.55009977120888,54.959598412430466 ) ;
  }

  @Test
  public void test2581() {
    coral.tests.JPFBenchmark.benchmark01(98.55892711713796,-33.12382261445913 ) ;
  }

  @Test
  public void test2582() {
    coral.tests.JPFBenchmark.benchmark01(-98.58744086870276,0.0 ) ;
  }

  @Test
  public void test2583() {
    coral.tests.JPFBenchmark.benchmark01(-9.860761315262648E-32,0 ) ;
  }

  @Test
  public void test2584() {
    coral.tests.JPFBenchmark.benchmark01(-9.867263446066024,-1.5707963266518428 ) ;
  }

  @Test
  public void test2585() {
    coral.tests.JPFBenchmark.benchmark01(-98.78360036825106,-26.787438790987117 ) ;
  }

  @Test
  public void test2586() {
    coral.tests.JPFBenchmark.benchmark01(-98.87470269219443,-1.5707963267948966 ) ;
  }

  @Test
  public void test2587() {
    coral.tests.JPFBenchmark.benchmark01(-98.87750630032339,26.637005121118463 ) ;
  }

  @Test
  public void test2588() {
    coral.tests.JPFBenchmark.benchmark01(-98.89705160116004,0.5479126657174143 ) ;
  }

  @Test
  public void test2589() {
    coral.tests.JPFBenchmark.benchmark01(-98.95753874743963,-1.5707963267948966 ) ;
  }

  @Test
  public void test2590() {
    coral.tests.JPFBenchmark.benchmark01(-98.95770992849017,61.261056305327024 ) ;
  }

  @Test
  public void test2591() {
    coral.tests.JPFBenchmark.benchmark01(-98.95961043462746,-1.5707963267968914 ) ;
  }

  @Test
  public void test2592() {
    coral.tests.JPFBenchmark.benchmark01(-98.96016858819164,-42.411497301222724 ) ;
  }

  @Test
  public void test2593() {
    coral.tests.JPFBenchmark.benchmark01(-98.96111504735197,25.93336054238881 ) ;
  }

  @Test
  public void test2594() {
    coral.tests.JPFBenchmark.benchmark01(-99.00646677658892,4.743638980385046 ) ;
  }

  @Test
  public void test2595() {
    coral.tests.JPFBenchmark.benchmark01(-99.47839370248263,64.11525804367642 ) ;
  }

  @Test
  public void test2596() {
    coral.tests.JPFBenchmark.benchmark01(-99.47975569683314,-5.461171801966914 ) ;
  }

  @Test
  public void test2597() {
    coral.tests.JPFBenchmark.benchmark01(-99.48620462435214,-1.5707963267948974 ) ;
  }

  @Test
  public void test2598() {
    coral.tests.JPFBenchmark.benchmark01(-99.49635064211162,0.0 ) ;
  }

  @Test
  public void test2599() {
    coral.tests.JPFBenchmark.benchmark01(-99.50670495991781,47.77621010820191 ) ;
  }

  @Test
  public void test2600() {
    coral.tests.JPFBenchmark.benchmark01(-99.51517749197032,0.25759119318071033 ) ;
  }

  @Test
  public void test2601() {
    coral.tests.JPFBenchmark.benchmark01(-99.53087825226538,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test2602() {
    coral.tests.JPFBenchmark.benchmark01(-99.53098049727592,-56.54733689294227 ) ;
  }

  @Test
  public void test2603() {
    coral.tests.JPFBenchmark.benchmark01(-9.992933286656589,-1.5707963267948966 ) ;
  }

  @Test
  public void test2604() {
    coral.tests.JPFBenchmark.benchmark01(-99.98991831343169,1.5707963267948968 ) ;
  }
}
