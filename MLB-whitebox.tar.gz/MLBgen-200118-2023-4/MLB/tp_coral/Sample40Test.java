import org.junit.Test;

public class Sample40Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark40(0.4255643531368918,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark40(1.0254957250723557E-8,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark40(1.2765413704612314,0.3530165000378074 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark40(-1.4531818291428285E-10,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark40(-1.6387828749649E-10,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark40(-2.9894692613830216,75.27845022095309 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark40(3.302482154165072E-37,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark40(5.276492443482498E-5,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark40(-57.41895579060174,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark40(-6.093588830307976E-37,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark40(77.040209205069,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark40(-89.12703159451134,62.60837489735093 ) ;
  }
}
