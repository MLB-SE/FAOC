import org.junit.Test;

public class Sample57Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark57(0,0,0.3620892720600544,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-0.4620407766940673,-89.89363015635968,25.04150755886485 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-0.9408028754824613,-71.94333434585387,76.84799480660624 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-100.0,-15.328830284493634,-26.369717778345958,0.059568188783728715 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark57(0.0,100.0,-5.980925630779842,-2.6666755534810207,-0.4749268604977762 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark57(0.0,100.0,-66.30048686919916,-2.0874544205348133,-1.054146213664067 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark57(0.0,100.0,-76.89367495377607,0.49949986306046945,-3.7572416201098093 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark57(0.0,100.0,-78.40566178999379,-4.384828528343675,0.28171717424868503 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark57(0.0,100.0,-85.30161644959861,0.025859173711534567,-60.7442582781194 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark57(0.0,100.0,-95.28710220527113,-3.0787394245982145,-0.06286131229587079 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark57(0.0,100.0,-97.76928277899509,0.001231076729673467,-40.99335195229588 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark57(0.0,100.0,-99.75426216049318,0.1129981122612358,-13.901084676206231 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark57(0.0,1.14170683612647,-7.488014927821126,-9.708364245170273,0.1389933023993652 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark57(0,0,11.609829669183142,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-1.232595164407831E-32,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark57(0.0,13.092518373771071,-96.11345730886265,-7.591065528833319,0.20692698815844723 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark57(0.0,14.343380371054192,-90.97816056509274,0.01529089613220995,-4.1680518631637575 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark57(0.0,15.062644791840665,-66.1466283042075,-34.716307921411854,0.04524664115638899 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-18.883067792397384,59.774303618038005,-46.769099373450906 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-1936.9168794831735,0,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark57(0.0,2.039157646249539E-56,-93.31076467351494,-92.06685254965141,8.673617379884035E-19 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark57(0.0,20.48252012900862,-85.56027190103327,1.3877787807814457E-17,-4.209369287801207 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark57(0.0,2.0679515313825692E-25,-30.375672162486882,-13.91443395394351,0.11288970374175378 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-21.01171468410008,-41.416997394197416,0.013124425522555327,-78.76911479114418 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-21.50115723037574,0,0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-23.136381489126283,2.8507130779357056E-15,-0.035015585027927135 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-2625.840942830766,0,0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark57(0.0,26.53903390876138,-100.0,7.535798135118249E-16,-31.821221479736877 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark57(0.0,28.131759459919813,-4.555091020830702,0.1238835590612739,-4.402378436657825 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-2.8324089926062896,10.368561304888388,-0.15149607362154516 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-28.8407623995476,-22.657783931962967,-66.4315989660605 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-3.128541834315257,0,0 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-3.3757901572756452,0,0 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-34.89621108719875,1304.3980799735184,-1273.5861871249174 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark57(0.0,36.47381991865267,-28.94147242356326,1.7274784369497587E-6,-16.474790382624036 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-38.58955090324609,80.59859278189103,-92.46649754134013 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-39.26852553904334,-42.69274213194449,0.036793053066028314 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-4.048977763072159,0,0 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-4.05955780496177,-43.277623164417456,15.983135696976774 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-4.109452224043636,0,0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-4.2441997137516125,-2.9880407308883576,0.018305535033612763,-85.80991071337627 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-43.482852062082934,0,0 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark57(0.044308591598203655,17.99925406428073,-50.3150515012956,2.077007635154566E-4,-22.323024687983196 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-45.77841035087118,0,0 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-46.03422759916389,0.0,12.69721554771148 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark57(0.0,46.77211910136629,-13.639123509207671,0.0181466340237741,-12.802875951069144 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark57(0.0,47.65594656503643,-0.7470885501423066,-41.045443307650274,0.038269688427959636 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark57(0.0,48.5582842061741,-70.77122328379046,0.12348411087579292,-12.720635194716577 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-51.03951570834233,0,0 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark57(0.0,5.147557589468029E-85,-100.0,0.3757800173300705,-3.8398230269818745 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-52.83674691918891,0,0 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-53.54458669372073,0,0 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark57(0,0,5.378541142937763,0,0 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-54.42040678590534,-49.30109587056134,-73.03731856552858,0.00843064185457953 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-58.90642787199458,-100.0,0.3678807698642625,-4.269851689650632 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-60.36714497612014,-35.52261205753547,0.026297616578516234,-10.847210855595737 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-60.5608785530298,-34.25070053590858,0.24557698357805863,-3.787499359862597 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark57(0.0,61.37984009403667,-32.373916360174434,-54.8249687789095,3.347450215271361E-14 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark57(-0.06551031578139388,-76.67612807053149,-22.32119650610648,-59.84186561695822,0.002403566475030372 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-68.62895867305163,-37.6527077515692,0.015700770085449452,-14.040392374264734 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark57(0.0,68.84392576846753,-100.0,0.15960883613090354,-7.730703636253379 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark57(0.0,69.51061845617426,-5.5650412054650595E-15,1.704696241297482E-12,-60.599243202841976 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-7.030817347361087,-20.07077761344814,5.551115123125783E-17,-13.079324022661577 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-7.164820456407469,14.268402753914657,-71.93066548217814 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark57(0.0,72.40327645758722,-20.864084986581414,-66.43742298236623,6.938893903907228E-18 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark57(0.0,73.33237339518303,-47.63869605765927,-3.4094460980785324,0.005528031188873314 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-75.12273774905299,0,0 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-75.84994379262768,65.73578414237124,-25.58722117539662 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-7.644974357450067,0,0 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-78.65177486533511,1310.9176447391753,-1388.1263279766806 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark57(0.0,78.79057402592187,-22.984701399777435,0.017628969448334253,-23.508777544576887 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-78.90556478452531,75.33443558656379,-41.343783373808975 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-78.94415389724334,-1.232887417084953,80.03117974186145 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-81.71584783920774,-21.192766402569756,-28.641741573209853,6.938893903907228E-18 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark57(0.0,82.98661602767629,-44.902020051882225,-4.305594963872133,0.002195109863591398 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-83.88009368399184,61.91791683765598,-86.87377690697645 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-84.30447246080284,-1.9196119217864076E-239,1.329965862081752E-48 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark57(0.0,85.52979139733023,-42.72255935403483,0.034211202829203535,-16.20509300283891 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark57(0.0,87.31403471118762,-64.47521836421758,0.057368929097785244,-20.363506290090545 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-88.3919841683024,0,0 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-88.5301870997127,-1.505643425646252,0.2234178257727789,-7.03075648221746 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark57(0.0,89.06608517638556,-27.948420608686146,0.37710703641902676,-4.165385885426673 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-89.24765207248116,0,0 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark57(0,0.9015563273492688,-23.152668466595472,-7.194148405747185,0.21834360902809635 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark57(0.0,92.22466450735759,-23.747244865774498,-3.915273256389864,0.35527429676111544 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark57(0.0,95.18648693542552,-5.753798210872985,1.9022264532295535E-15,-41.6794462168849 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-95.26429133832349,0,0 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark57(0.0,9.6488949433941,-26.955035754822745,0.11598338414230043,-13.543287587364068 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark57(0.0,98.4949011735413,-100.0,0.23012296340577354,-6.825899960383905 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark57(0.0,99.99585013090461,-90.1762744079823,-17.10611567025645,0.04252235132611373 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-99.9998570205892,-4.493682761778036,-1.0189684944812807,-3.1234305312180775 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark57(0.0,99.99991364973101,-81.91866310828836,4.509771074056178E-4,-28.287415107326552 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark57(0,100.0,-100.0,1.0410819876196937,-2.6118783144145903 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark57(0,100.0,-100.0,-2.1887667766759815,0.6179704498810851 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark57(0,100.0,-100.0,-9.378718025694516,0.006717827799498949 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark57(0,-10.003045390005916,-99.95808774332865,0.02546979022197532,-6.9415654617874685 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark57(0,-100.0,-32.96039233005186,0.020659966033041738,-70.34770421544687 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark57(0,100.0,-37.912303880198316,-1.8989840228014154,0.8271772210477207 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark57(0,100.0,-99.11723148380125,0.2614544816538067,-1.7614544816538065 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark57(0,-10.435683028473733,-95.15318099567367,-0.7131056999136112,0.7131056999065173 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark57(0,-110.18016159029878,-60.45307397992423,-6.224999442571641,6.225005367481083 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark57(0,186.7230391591598,-66.61210994468897,2.7755575615628914E-17,-1933.7949479814629 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark57(0,20.317301816381246,-6.269275389390401,17.253100292681694,-53.208516894112456 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark57(0,-21.21166335069903,-72.4295040318618,-57.75692514107262,0.027196675081960997 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark57(0,2.5792477915210363,-94.52733453390191,-1.8234682262855042,0.25267189949060764 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark57(0,2.9799929109867778,-15.834203661887816,2.7755575615628914E-17,-13.219347804828324 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark57(0,32.35553408588046,-27.874888747610022,-12.516550021548083,0.020975733983807227 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark57(0,-34.73121121615684,-93.90338332508324,-3.5098819735957165,3.483801287189019 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark57(0,-35.446251759087204,-37.9031505020341,-46.917196601718906,0.03137390083528535 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark57(0,-35.76654813213956,-16.069256196954132,0.04183884191964382,-0.04183884191964182 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark57(0,-36.45844908608578,-37.69925622530073,3.9041509165977004,-5.4041509165977 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark57(0,-37.14268907001531,-85.30563501273092,-2.1544278877534397,0.6544278877534397 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark57(0,-38.41411434364523,-53.698064453171206,-73.86703953714525,0.021265185888558413 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark57(0,41.39607234198846,-1.1300284407932395,0.0015419879339472597,-1018.5137600602665 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark57(0,-41.79817486345232,-68.10754066695819,0.06006667349085504,-21.053258091222588 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark57(0,-4.486821314246949,-100.0,2.4435508849548206,-4.01298334575559 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark57(0,-47.06107533898487,-96.69149867072144,-19.225053759934212,0.08170569229139701 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark57(0,50.44481485388721,-84.45221284695928,0.9662534680564845,-2.5370497948513813 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark57(0,-51.08974419961962,-74.06255503362642,-5.300924933967522,4.440892098500626E-16 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark57(0,54.81035198396046,-9.47504842415573,-8.093210063243378,0.043694952330018744 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark57(0,58.713385992393455,-42.24749095199886,3.8281981964135863,-5.398994523208483 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark57(0,59.283810902899376,-47.98113838411879,0.07184750353843339,-12.148617647449983 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark57(0,6.52549790517779,-59.715927909189205,0.0927981430293272,-8.827060772599 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark57(0,67.61673858560636,-58.127768365344274,1.780706736511325,-3.2806951798924837 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark57(-0.7232514193522831,-95.37914976850777,-60.192105356253904,0.24990828108172897,-4.001284932093676 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark57(0,73.99196864822402,-20.28242823349504,0.07986516566560148,-19.652080637042673 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark57(0,-74.37758845388149,-49.51282590745365,-3.599140818331989,0.4364364736144566 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark57(0,-77.60328280879409,-49.44692869895211,-9.239168399195076,0.1617324480659498 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark57(0,82.791261318836,-100.0,0.02500942798798861,-57.8346878895013 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark57(0,8.321513259083865,-60.819270500267734,0.00954610450353613,-58.07331960124866 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark57(0,84.81021318894412,-74.3155668500608,-61.36946973723778,3.552713678800501E-15 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark57(0,88.94377802547871,-55.31594795508563,-3.945084622339211,0.3341513494781694 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark57(0.9400054932929152,-54.5125953892982,-99.31834080871032,-38.09711581661739,8.952838470577262E-13 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark57(0,95.10749402188227,-48.28101406903564,1.3170295236981389,61.09730410966873 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark57(0,99.99999999999999,-100.0,-2.0841683682504435,0.513372041455547 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark57(0,-99.99999999999999,-58.33371069326935,0.15318712772626258,-0.15318712772626258 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark57(100.0,-100.0,-0.28760907983265227,-2.712456414002909,-0.4448594199210434 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark57(-100.0,-100.0,-100.0,0.20562531040116297,-7.639119540927931 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark57(100.0,100.0,-100.0,-3.3937639923001983,0.07714050679374201 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark57(100.0,-100.0,-100.0,-6.68875276517701,0.038030710871921836 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark57(100.0,-100.0,-13.89943302088388,0.0560083906869131,-22.72151534131466 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark57(-100.0,100.0,-2.0341784108735466,-4.655320798618091,0.3072346878264936 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark57(-100.0,100.0,-29.66466634939458,0.39457169595957,-3.9810162332471037 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark57(-100.0,100.0,-37.60705944059569,0.43441213095766107,-3.615912666462784 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark57(100.0,120.56724468167192,-47.0965703843448,-82.19486860852726,0.019110637359563754 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark57(100.0,18.89760649813034,-100.0,-0.2833796681639981,-2.8855380289122943 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark57(100.0,21.74189589881191,-100.0,-3.7326463432615986,4.440892098500626E-16 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark57(100.0,72.10819781089333,-12.173129942362156,-3.272640091526519,0.005484340891434246 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark57(100.0,78.09836686998578,-17.426386628724913,0.02826065897178287,-10.400518605966003 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark57(-100.0,89.15096805603453,-99.69084359366744,-10.648767268866244,0.147509687002685 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark57(-100.0,98.49036310071723,-100.0,0.0599861554234672,-4.253890655139964 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark57(10.263232480241584,30.150890405330898,1.2054426136393914,9.422314368845306,-4.984237382653589 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark57(11.01473598163816,-51.5465460526764,-10.787232506868559,-66.65053321701627,0.020088434873079014 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark57(-1.1102230246251565E-16,31.272139725481118,-7.619040086878524,-15.818880279109884,0.026816247434371943 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark57(-1.131959884853339E-72,100.0,-100.0,0.03228585395290451,-48.31690136038685 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark57(-11.55636842827773,85.71338222315455,-69.1179833070276,0.14976664145462526,-10.488292396346484 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark57(13.144896647787153,-2.1234431558033124,-16.70937010580046,4.440892098500626E-16,-16.33802935686116 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark57(-14.319673364145768,24.789222168660924,-2.278582501851414,0.03634289202486851,-26.44472530176765 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark57(1.463023860841312E-98,33.53151606375777,-20.74779230308726,-13.619693705566903,7.875744112854217E-14 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark57(-14.873499465283134,1.8972228128040927,-92.86858905149558,0.018329976947200954,-85.69548839508565 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark57(15.311677652022148,-1.7829753167127187,-13.952446727507212,0.34339424290508047,-3.575989123722394 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark57(-16.15117713639531,15.023089132826865,-81.21855272569434,-61.193474041205704,0.006518616845172424 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark57(-1.7191326550947068,85.47995494112567,-94.38642678409818,0.021054216511702566,-19.284825913557828 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark57(1.734723475976807E-18,1.4210854715202004E-14,-21.554918362700597,-0.13187391671523346,-4.010266673901482 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark57(-1.7763568394002505E-15,48.11748691894462,-75.78208097922926,-56.7604444534457,0.027674137190437875 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark57(1.7853169950756238E-17,100.0,-53.82402339290957,0.09701406879771675,-7.6526849848167595 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark57(-19.706225583024146,-96.39965615765773,-5.171934186856845,-0.8771791346905052,-2.2644857518101484 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark57(-19.862501096888423,-74.43859781596127,-16.533973377984566,0.030819885255141344,-50.96697517822446 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark57(20.61557720379342,-6.412933784467761,-100.0,0.02425843321781454,-3.4105282039494837 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark57(2.220446049250313E-16,-72.22268613627058,-100.0,-73.73570340739474,0.021303062888220037 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark57(-22.535311628151987,-38.62382037646468,27.221185343822782,-82.09492327767171,-21.500270763798568 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark57(-2.3006207928696147,-71.3449136059356,-19.52981022550378,0.07960813781924808,-10.691086578024802 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark57(24.24326912445922,-17.52356469732871,-47.87702102138968,0.18448200035718662,-7.939847268972793 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark57(-24.567249761457273,15.650452335901097,-72.49551565086121,0.025951729022461296,-16.861799792241985 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark57(26.243421120038406,9.691109270240668,-14.257444275718619,0.01922394039072426,-10.095266716207407 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark57(28.081422241041025,8.568812434608805,-62.2024287139294,-19.209758738755074,0.08177074726221623 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark57(28.398614648667287,30.52447398498857,-88.40803235673361,0.02269206476572136,-3.5013630468701438 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark57(30.185878315288917,35.25054544439497,-22.53329381613059,0.29281469702094776,-4.390453890236487 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark57(30.41530416537974,-4.595096990884514,-30.68545896950738,1.7763568394002505E-15,-54.422722202565424 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark57(-32.74901295886648,100.0,-100.0,0.6588923334197418,-3.9251308972103445 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark57(3.335097903469982,-31.552991039863407,-50.875211939094605,-10.112750474486923,0.02561165486174355 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark57(34.99314352222895,-49.37384199498618,-16.29103517505349,-34.9505439067426,0.044943401481424755 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark57(35.29579138008336,-87.63184663826989,-41.785532113349234,0.0955909813719712,-3.7962930286060583 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark57(-36.107707657709604,-100.0,-3.152174312842654,0.019905813393064554,-32.65335860654211 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark57(37.07532603763691,-100.0,-80.40260721464058,-64.27046499966951,5.551115123125783E-17 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark57(38.060706336564245,-4.785912907449628,-34.50612505768269,0.11082680449500171,-14.173433349021078 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark57(38.314929994540094,-26.9528034893807,-42.585962383300036,0.010265081780836266,-9.504917112966197 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark57(-39.66218697098688,63.52330436431919,-49.37475933699301,8.355319684815073E-4,-44.01028250879245 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark57(41.565458283234186,-98.23661871427568,-84.86638143653683,-7.924224959785061,0.1982271243896515 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark57(-42.486050224930864,-83.51241544674131,-0.44212387868751346,-0.20476117862034932,-2.9727705122160044 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark57(-4.26435165308034E-115,-2.8853058180580424E-129,-14.751798788178183,-4.185582907151613,0.37528735223735055 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark57(4.271368066401683,55.54050504944376,-14.309599853968582,0.0027890376404911543,-31.810918433898326 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark57(43.61166369948947,-100.0,-0.618926449232347,-0.7579240446562212,-2.3889117083653777 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark57(-44.229092271524586,32.62915364654165,37.80436671988713,85.6896630149096,41.83637890217622 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark57(-4.444081308732059,-16.176664827044767,-66.93217915683357,0.23702607542495963,-3.6041816267225357 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark57(46.78421957966129,-24.522633960003514,-83.7603606778832,-35.33232183810241,3.295641501621649E-5 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark57(47.300536768972805,-100.0,-64.98077856189755,-3.7159055963109466,0.42272234481799753 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark57(-4.9129875022926456E-11,-84.08573957620487,-62.03875775946983,-4.06990226916807,0.07835663210684607 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark57(49.966075840626715,70.06235944258009,-6.924512877008436,0.018129984832896323,-50.595175544944624 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark57(-50.91672413104648,-97.4424597997446,-100.0,-72.55785179849006,4.973799150320701E-14 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark57(52.1133774263422,44.21064678596338,-98.87909398469776,-93.11710979039024,-19.12090034800333 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark57(52.63338155448045,-89.10306246280096,-27.53523427035577,-3.6813214109911083,0.42669354923919706 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark57(-5.293955920339377E-23,-31.610068804580933,-100.0,2.220446049250313E-16,-9.53631373084091 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark57(5.420895421531668,-99.81057968092873,-92.85383681584715,-7.455712610368127,0.031190874459153584 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark57(-5.421010862427522E-20,-99.99909865421218,-34.509371231246405,0.7953768742871968,-7.325574623252358 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark57(5.660490254870367,-100.0,-92.55806479967832,5.551115123125783E-17,-7.075526151775321 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark57(58.17690003533224,38.906625631596825,36.4754237664323,-67.9731386231921,-39.19175391520484 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark57(61.54093581192718,100.0,-100.0,-57.71587726971108,0.0013512888056487204 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark57(-62.27619495357509,-100.0,-25.401764088236114,-7.546385137790912,0.07026045070390197 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark57(62.55899676723127,28.51313520312386,-4.961219340736748,-7.94102956976077,0.1978076282876662 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark57(64.1510721314026,53.28055270594564,-71.12770448212518,-7.839825667237656,0.2003611296306227 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark57(-64.58039324434148,14.268254676838126,-46.066495582330155,3.552713678800501E-15,-83.06894281241522 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark57(-66.45568388928793,91.64999807969375,-4.459280670087444E-8,-2.414309720436731,-0.7272945534420354 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark57(-66.49525015254093,-79.24978523663319,-1.243877728345403,4.2637703136588483E-16,-16.035895741924833 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark57(-69.35254363211764,-40.852267221520265,-18.711891765197123,-77.41730898337269,-31.88063161261647 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark57(7.105427357601002E-15,100.0,-2.5968385616050536,-4.640685948614943,3.286692990910978E-5 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark57(-72.40306490349123,-140.66955044627434,-100.0,0.0049361182171265006,-15.884903181486504 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark57(-73.25582992197982,60.18620428940244,22.792406248261614,98.08874266919446,47.84498099611196 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark57(74.28053716559825,100.0,-27.475876738265853,0.040746780418152724,-38.55019490313167 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark57(74.34229616912404,-27.520470663833862,-49.59217280024875,0.06914774078721886,-19.136685310094464 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark57(75.58178908436389,43.82628905735473,76.02633410054551,-75.33643014543219,-9.59020049594261 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark57(-75.90832085121946,-58.408148025523275,-26.530259517787,-39.114173866173815,3.552713678800501E-15 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark57(-76.85531993225152,82.0944205674366,-77.60425255297784,-20.10609635057854,0.07812537547845011 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark57(-78.60772171530937,-87.07194314084559,-100.0,0.015423910175646594,-9.946521183281813 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark57(-7.983926626512796,-100.0,-74.92532246116897,-14.116526784334338,0.07881146319242693 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark57(81.76460112678119,172.76810156149384,-27.816702422847598,0.041697676128519774,-3.616211158883316 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark57(-83.21183213857461,-100.0,-100.0,1.3877787807814457E-17,-57.36078157844325 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark57(83.69060318129173,100.0,-13.792164549579201,-7.157738843925752,0.09475142779148293 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark57(-87.82632719333463,84.46996927387988,4.826810537143956,62.559819578212085,-0.4121521925415834 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark57(-92.17953742457141,-100.0,-73.7632994408179,-3.7446282521056915,-0.5395814758865969 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark57(92.81521847927804,46.31168569222269,-16.688919226613628,0.1380628526999429,-10.446784499787729 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark57(92.90553629778697,0.5643312271888448,31.225385157338536,38.45022672279748,76.80485986672659 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark57(93.4379680571545,-73.44777711769922,-73.23445869954219,-14.630008384774953,71.24130745309878 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark57(-96.95801495634434,97.69657499696311,-35.461994879822406,0.0024143539625226113,-26.017793172744536 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark57(97.52675388241866,-36.823379299626865,-7.865963327533434,-14.015406711945026,0.06793419777117499 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark57(-98.02750505255507,99.61047533597869,-100.0,-3.6746620872217277,0.41669391805786665 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark57(-99.18218416708507,100.0,-60.640819512952376,-4.2785247852482335,0.023453403707228593 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark57(9.940666515392744,-40.307817800442436,-17.34327297645295,-4.15076932435027,0.3784349849508385 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark57(99.4823999532947,42.83555694385234,14.841077786560206,-38.13017646106969,-5.601586620709313 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark57(-9.996714704110405,26.157315883387493,-62.66589117347915,0.04089155721933499,-38.413707709134826 ) ;
  }
}
