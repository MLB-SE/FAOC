import org.junit.Test;

public class Sample80Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark80(13.548660593137612,0.8892879491896233 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark80(18.644357533803003,-61.95469409791061 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark80(-46.72151797980628,-23.857072412996857 ) ;
  }
}
