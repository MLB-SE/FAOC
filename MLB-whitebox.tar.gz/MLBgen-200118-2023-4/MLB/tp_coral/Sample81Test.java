import org.junit.Test;

public class Sample81Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark81(23.923587082288375,2.2295747909485897 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark81(41.555484237815875,-70.4857390343553 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark81(-6.695014445550221,-1.9431807881720147 ) ;
  }
}
