import org.junit.Test;

public class Sample11Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark11(0.6603823678212368,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark11(-1.0,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark11(-1.0000000000000018,-1.4275232333736518,-100.0,-1.0000006257210228 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark11(-1.0000000000000036,-1.2637030928382442,-1.5707963267948966,-1.0000000000000018 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark11(-1.0000000000000042,-1.4513300092201438,-62.36323626704278,-1.0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark11(-1.000000000000007,-0.11047304017026416,-88.53355461266507,24.85492325007821 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark11(-1.000000000000007,-0.17806873939231482,-64.52190862965169,100.0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark11(-1.000000000000007,-0.7641684085970543,-100.0,0.06256259861247364 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark11(-1.0000000000000187,-0.8543637014721099,-49.84476700447189,-1.000000000000007 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark11(-1.000000000000063,-0.7931989063873657,-66.07699295038923,-0.8103854479419533 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark11(-1.0000000053686957,-0.06276686326724935,-90.5273447801897,5.0978941156238473E-57 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.0011511333577300699,-66.24456874937975,1.0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.00307663759723888,-44.29789699666116,0.055302700660328316 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.0033545356801733817,-51.49030005147625,-1.0000000551270392 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.0035200083167355838,35.966358742798995,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.00516452062765127,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.005762346882434406,-88.68073767467504,-1.0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.008236331162596743,-1.5707963267948966,12.723137456809965 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.00862778894280794,-31.95959020156579,1.0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.011271628055166148,-34.886316070196436,-0.7267216695803436 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.015290827537125407,77.10844566657488,0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.015565021878912734,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.018032467410518765,-31.867840331880444,13.038312877416988 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.023918998091627546,28.268445385547622,100.0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.032900885887713116,-3.1856411740844655,-35.29075868719875 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.033780173783405025,19.394143391206555,-0.061504088205317234 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.036715676131106934,-22.994253879804674,1.0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.044830312886898,-1.5707963267948966,-0.7235158651215997 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.047828915185076704,26.698923131988835,3.469446951953614E-18 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.05422872294110827,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.05430420457238381,-36.40072352805434,-1.0 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.056157570870456586,31.438734755625617,-1.1459013643066564E-33 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.056621089712181716,-1.5707963267948966,-0.9781041489255571 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.07238064055914523,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.08148027558083104,-20.13013019826532,-0.23745179456507493 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,0.09415194537550986,1.5707963267948966,-2.5486461755852923E-18 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.1024870806562281,-56.491103124344676,0.06259494747351066 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.11774417289847439,26.204916486368212,-0.9589896648804314 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.12071790221024081,78.93007262593005,-8.323328709735025 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.1469210307518516,-9.292421614655769,-0.6849140361399311 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.1479736413727589,1.5707963267948966,-0.9263760231603815 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.15200266962906417,-4.8206912588585675,-0.9999999999999999 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.1616083031110628,-98.95932084233579,-1.0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.16669097866982893,-16.486042239640106,0.541546841149599 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.1682791304916923,63.46217978344723,-0.0011372576091909267 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.17533777061399153,-22.32480857420317,21.050371262094632 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.18312939438182152,-3.7608690894314094,-5.302472116155272 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.2008937883068863,31.858768170227567,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.20708426376743905,-91.93441382324647,-0.07774677557542109 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.2127082293941288,50.50840448632377,-50.95823058433768 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.24064159549497693,-37.15787478838231,8.719964268712957 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.2577150003123216,-179.71492631652248,0.46714502625324983 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,0.2688426030477896,1.5707963267948966,-0.9985271986652701 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.2692922441198804,-66.47411626527199,1.0 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.2927248324493632,-31.688269988351887,-0.2971999272315346 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.29854532367228526,-1.182838787109448,-0.4963603105772264 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.3010281327004559,-0.04825702354642293,-57.45803535610689 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.3067065537381711,-40.19898833318059,1.0 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.3168930875202047,-66.14785892685217,0.36633264423421963 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.32139536779770295,1.5707963267948966,0 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.3357226503904589,-37.741017470161964,-0.9469395071965635 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.3438102695672233,-0.026657427834424628,-63.93144546489269 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.3465833660299642,-1.8914818285066204,1.000000201039214 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.3756613539404172,-0.8566661971954866,-1.0339757656912846E-25 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.3978880101559605,-53.812978923741085,-0.9999999999999999 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.3990792018410211,-1.5707963267948983,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.407625301513384,-8.723376947419347,-1.0 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,0.43864232718607155,73.09434399503803,0.0 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.4466455037739422,-0.09635994123564201,1.0000002003595494 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.47947420245554717,-2.5074775265611056,0.6368527848664873 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.4803295148953165,47.97709349471398,-49.636818307795224 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.5016515338250881,22.372438463873618,-1.2994262207056124E-113 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.5243658034627835,0.0,0 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.5326913394689714,-58.35876052345669,-17.244857356060535 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.5336314609442783,-62.81739179690685,0.004767563809619957 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.5496066831713468,-72.60135139093299,-1.4836824602749686E-67 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.5543395821064053,-27.260121384211345,0.9396164497416756 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.586614766398828,-44.30784093584115,-86.57371967301859 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.6393697968328547,-74.73974845484254,0.7518717013838838 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.6459639124699046,-1.0877335950187894,1.0 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.6593258052358776,-46.66521292219527,1.0 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.6635882640307902,-1.570796326795051,0.06258798651221671 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,0.6795478857866557,1.57079632679489,0.0 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.7033811324618964,-38.8579431854516,0.033760399210740644 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.7082926829657794,-77.90131719792446,4.313694477514066E-8 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.708476152907521,-56.90493944461292,-1.0000121226588745 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.7101717137479222,-1.559566245763444,0.06255546245487302 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.7449542896585325,-27.84063553282634,-1.4836824602749686E-67 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.7922768827985605,-66.34488645845461,8.673617379884035E-19 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.8213533447053862,-0.5665069139424439,-1.0 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.8342844193238163,-28.51398993781014,1.0000000735091388 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.837342724892744,-59.22518900194308,0.99913826205524 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.8868565574533472,-79.44544560443657,1.0 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.9150944114198848,-1.5707963267948895,0.6528995501110941 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.9155378935119829,-44.06858732089052,1.0000002132025263 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.9337724118944362,-20.933339442052798,0.4012822400489345 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.9546282532739434,-1.5707963267948966,26.917513109141858 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.9695089488473587,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.996594398201826,-90.91209025669039,-1.0000000126324433 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.0141308701837106,-99.1144091733585,1.0 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.029340369909932,-36.009663347920466,-0.38450739635925957 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.0294204431356269,-4.182066647314045,100.0 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.0449591139584342,-98.40869177437756,0.0 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.0513183722777293,-1.5449757923699416,8.236092143148846E-84 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.0568360333153728,-74.52167743454277,0.2725269128845047 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.0590324328945724,-100.0,100.0 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.0593894284190173,-100.0,-9.86956729583576 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.0674806508745727,-1.5575533543852493,1.0 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.1039506237309107,-37.25399475745072,-27.37185834037887 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.1102230246251565E-16,1.5707963267948966,-40.018135662349245 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.1102230246251565E-16,95.17560475783228,-83.82910024054574 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.1185394091433787,-9.66182079942622,8.673617379884035E-19 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.1503455414894115,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.1697269153963024,-67.12801133648324,0.8782379991609495 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.1734914293751886,-93.41491870688598,-4.3368086899420177E-19 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.1850219608496104,-17.178046378844734,1.0 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.186096804826932,-1.5707963267948983,25.7125934363928 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.2053670195552768,-95.6244650308355,1.0 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.2551388779281172,-94.27999311649491,0.13916378488119063 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.2656294083747297,-62.5392149631423,0.7685942157915946 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.2865707486392408,-1.5707963267948966,-9.456656820031796 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.2930276111429668,-2.220446049250313E-16,-0.8422104618911416 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.29859785999078,-87.545365385508,-30.334056048785413 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.328207268189121,-34.808977614300666,1.0000001822511388 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.3339737962440128,-17.237537900188958,-58.2736397273808 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.337396257808978,-1.5707963267948966,-0.8607202600652561 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.3499487630404425,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.3563929212323185,-1.5570638090050566,9.748476742543644 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.3595221496190224,-45.39145927338819,0.036072726616636214 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.3624588291764204,-48.74550856143928,0.0 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.370997989928259,-71.19084902959085,-1.0 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.4127256773718113,-49.851074135361706,0.3621242816137263 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.4169507025261763,-31.147980599521492,0.026211643249400476 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,14.429203933736005,1.570796326794896,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,14.429205671967175,45.04810722843652,0 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,14.429285525579694,44.0600900929999,-0.713093022678156 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,14.43218311927766,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.4641965695611632,-80.36822075626736,1.0000002848333671 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.469520796224316,-84.78726724923835,-1.5507056926168901E-15 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.486413198533199,-1.3840800845289318,1.0 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.4905958905137484,-1.5707963267948966,6.69276983807661E-8 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.503095271171369,-1.5707963267948966,-1.000003602632277 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5080070247158315,-51.62165550131842,-0.06255252794668657 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5086154920250587,-32.49043191853116,-0.05222491600157633 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5176021426102417,-58.769874534239584,-1.0 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5198644116959488,-49.783606729879516,0.9404054367486899 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.527894571398053,-73.64059486282864,1.734723475976807E-18 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5305461325329826,-75.87096145305219,27.443493669378043 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5313831635968504,-32.534725141375375,-1.0 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5478117821862396,-57.357813620840226,-90.89767027660969 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5491074711400883,-38.908869846923494,-1.0000000734130812 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5564324752505547,-4.577771002006255,1.0 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267936833,-38.70730496053861,-78.50882339009641 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.570796326794626,-95.71135101313767,1.0 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267947775,-82.90844139622308,-0.517863955630421 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948415,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.570796326794855,-84.78265243824956,0.0 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948912,-1.5707963267948966,33.324368454611175 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948912,-45.309316820024506,24.224161750104514 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948912,-67.56385525379864,0.017316353497029324 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948912,-86.59887891156109,-1.0 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948912,-92.89776180980138,1.0 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.570796326794893,-1.212360257873823,-2329.8680457113664 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948948,-12.19125154962802,-42.85886812504635 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948948,-1.5707963267948983,0.06323840374017063 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948948,-19.355475835937952,-0.3934725650525882 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948948,-4.235757225289958,0.024068913637339737 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948948,-60.74175789619418,-100.0 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948957,-1.5707963267948966,-46.63163154559065 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948961,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948961,-29.725193180416657,-0.5149149298094886 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948961,-31.626472819668322,0.36210694248780695 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948961,-9.517873855305748,-0.030626702017597984 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948963,-39.149010715856186,1.0 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948963,-44.284774041716055,-100.0 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948963,-46.32605640813514,0.44393901054079254 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948963,-8.167289039710099,-1.0 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948963,-9.94684813419659,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.7763568394002505E-15,-98.99325976729192,-75.16601994808468 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,1.889565235186098,1.5707963267948974,0 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-2.0301579391809432E-4,-16.802691218722487,0.7796541924520819 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-2.220446049250313E-16,-29.685528402635,100.0 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-2.222024404457605E-14,-63.35216792147006,1.0 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-3.117921496517763E-16,38.60103014843945,0.0 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-3.552713678800501E-15,-1.5707963267948966,12.229372168457658 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-3.552713678800501E-15,-1.5707963267948966,31.971919302773216 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,6.457459200035978,19.350773507169833,-1.0007371361442365 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,6.666563601762399,0.18140012689054236,0 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-7.105427357601002E-15,-100.0,41.4304957291467 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-7.105427357601002E-15,-12.499050471833442,-64.69219660967394 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-7.105427357601002E-15,-55.9649961521623,1.0 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-9.409688661896035E-8,-84.27734102748867,-0.44318610063337305 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-9.88984425501843E-16,69.48005930999065,-88.85024502132445 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark11(-1.001272327149968,-0.281408422716505,-48.466108920330896,-0.912153007827566 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark11(-10.016471944296498,-1.5199846446552199,-10.842456849790842,66.47102478383711 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark11(-10.032555415781822,-0.8422740422814035,-93.59051514463168,0.034171307732171696 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark11(-1.005317538994703,-0.37903075097012007,-26.025128148217387,-94.8731367517815 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark11(-10.062639808338515,-1.046084087691355,-77.48672202167113,-16.28198182796723 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark11(-10.072316249347537,-1.0821862629908574,-37.89686361554307,-40.23592247963917 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark11(-10.086130055421167,-0.6643308059501001,-34.142348974556214,-0.0601446788651408 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark11(-1.0096085832390558,-1.0104963312315463,-66.0366205132589,-1.0 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark11(-10.131698630167326,-1.5707080249630048,-7.887575741336732E-15,-2.2694806917965775 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark11(-101.51440105414838,-0.8794855858965391,-153.12185952997154,1.0 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark11(-1.017519112042269,-0.297697644949639,69.22513808852125,1.000350223945855 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark11(-101.81802988141227,-1.5707963267948912,-3.192690133800369,2285.075653422086 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark11(-102.04516356049865,-0.28911815521594164,-9.53121576967979,0.3620910064920234 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark11(-102.66936610970619,-0.5033147422394322,-1.5502783910266844,-0.7966662827218223 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark11(-103.18892486659155,-0.2632446071543213,-11.62051574661745,-0.7345121028732251 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark11(-103.48372771766184,-0.3982443716645445,-6.530417890147531,0.8336986456913893 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark11(-103.53550415263888,-0.3425784881636883,13.424385347008865,0 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark11(-10.449496096591194,-1.2754499547313127,-38.04847523284103,-44.829585217657055 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark11(-104.49848877541736,-1.2207010936724476,-32.91193617693524,-0.7632265742972368 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark11(-10.520428873629742,-0.4475529527979093,-0.5428947579519292,60.621403433510565 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark11(-10.52809363833146,-1.5707963267948957,-33.519004804590644,1.0000173176640168 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark11(-10.528259618694614,-0.7183658414103705,-46.06283106620206,-2277.5455801131957 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark11(-10.568745588369708,-0.12919449651858725,28.840641811225158,0.0 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark11(-1.0588771586039623,-0.6156639764950744,-53.54110712565161,0.06030067473028056 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark11(-10.607461144761892,-0.23593839489659182,-69.14470940892855,0.994046474835576 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark11(-10.643844837381252,-0.9272088581540602,-33.436613683647494,-0.538252992387553 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark11(-10.851975370191852,-0.3634237706827861,-72.01559003779617,-1.0 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark11(-10.855172194477618,-1.4350970523801794,-1.3077086536307458,1.2493741320811145 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark11(-109.39027137056573,-1.5707963267948912,-32.831955320067436,-1.0 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark11(-11.01176243811565,-1.5707963267948912,-0.5189573165314022,-1.0 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark11(-11.035213692231512,-0.666798410871626,-34.519805934002235,0.7361820184294264 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark11(-11.07154895291886,-1.5707963267948717,-99.53963652523905,-99.17739066115206 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark11(-11.095051548296397,-1.5707963267948948,-1.5707963267948841,-0.3058355129159066 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark11(-11.096672003111186,-1.5204424129856893,-31.632468679420313,1.0 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark11(-11.174554614251818,-0.6941606353202319,-65.50743142489448,1.0 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark11(-112.45299964102709,-0.8236332516128614,-46.762309478958684,0.0 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark11(-11.308247911832789,-0.002104838684403764,-41.935399824325394,-27.699757720842783 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark11(-1.1348197690172344,-1.5707963267948963,-1.56577920364195,-54.90942215394741 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark11(-11.373685124194699,-1.5659345730406837,-75.47036677226664,75.21890787078792 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark11(-11.400073245737604,-0.005518596949655882,-4.376419449784683,0.9999999999999972 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark11(-114.28698037436024,-0.14809301633876248,-69.31535062221042,1.636530723580783E-7 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark11(-11.539094766671809,-1.5707963267948877,-84.72127048165933,-1.7124210121911858 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark11(-115.89512737469035,2.8282858100154686,122.2910076729825,-1.4108002265357349E-4 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark11(-1.1638163762657106,-1.2342498910388477,-33.044122577429704,-0.03381205310826292 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark11(11.648566863758532,6.759550451714318,0,0 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark11(-1.1649749298641066,-0.827231869284332,-11.935241507168657,-1.0000000049233422 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark11(-116.81977697291826,-1.2151672079180418,-10.514240494355386,0.46899361553824126 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark11(-1.1697196017748777,-0.32315512385570133,-0.03524397214961842,1.0 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark11(-11.703046595075596,-1.5707963267948095,-64.3756204541438,-1.0 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark11(-117.31302827868436,-0.7216997465615123,-77.046560051466,-89.9854912452401 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark11(-118.04115406647179,-0.5724889458428275,-88.65840447686423,2093.43379855262 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark11(-118.23917615765195,-0.504256382469129,-2.7616663828958075,0.9346743677694915 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark11(-11.867985787107402,-1.1102230246251565E-16,12.706708538538791,0.13284213735969838 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark11(-119.06237210218933,-0.08512296500543694,-1.5707963267948983,0.10270866896055963 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark11(-1.198187229065462,6.429446807575542,63.53212517066804,-0.011115106623708031 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark11(-120.62050852920689,-0.7681511661304565,-55.88890546107395,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark11(-12.119503615024955,-0.27832567693905347,-45.4468503206369,-2119.5992230550237 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark11(-12.156437027421383,-0.714082224950311,-65.21476070581727,-0.031589638180291923 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark11(-121.71452995634118,-0.40137101888965354,-93.62361767221384,-0.7096050845175768 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark11(-1.2175848189979774,-0.43152603410443346,1.5707963267949019,0 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark11(-1.2244411264673247,-0.2842016699832476,44.03109337912338,-85.00230324410158 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark11(-122.70650701616105,-1.526531999349785,-1.570796326794894,1.0 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark11(-123.08830776909541,-1.5658919105935498,-3.261972809528828,0.7444589227352149 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark11(-12.313215402227337,-0.00126855551021113,-1.5428298232035256,0.8052675583560489 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark11(-12.330600284436066,-0.654773503001047,-67.17697545569749,1.0 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark11(-123.83269717486972,-1.4343881181698424,-80.32442205345778,1842.8235705602142 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark11(-12.472053231428347,-0.17026026737243272,-4.521521492927022,-2041.512823599644 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark11(-12.490358457514802,-1.5707963267941203,-23.67990063029402,-0.5445509693534499 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark11(-12.541034555169738,-1.1288807068998408,-4.232413021912066,-65.19424844305124 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark11(-12.616889980620227,-0.8082130537351871,-1.7511813995283994,-0.06255253639416605 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark11(-12.625149945561105,-1.5707963267948957,-95.00950931828652,12.883965768543614 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark11(-12.628666338081498,-0.01650946751839375,64.31938217994318,-0.28337636625886065 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark11(-12.700161507166616,-0.8475517611169581,-40.81453918443154,0.0 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark11(-1.2703255084362148,-0.8584454306342169,-5.307669100353741,1.0 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark11(-12.721401444430336,-1.0114014308413395,-51.875098267633675,-1.0 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark11(-12.731873424809677,-1.5707963267948912,-19.69873829062078,-83.94205801113009 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark11(-12.745050995867544,-1.7763568394002505E-15,-1.5707963267948983,-7.245524650342524 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark11(-128.11592791840414,-0.17030042211304425,-45.0207511835791,1.0 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark11(-12.811627046653044,-0.3670621962423468,-1.0776541929678103,-11.683619332170217 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark11(-12.813843543819074,-0.05518806504048612,-38.13406279596482,-1.0666896946820494 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark11(-12.820389671556114,-1.7763568394002505E-15,-14.716512857089342,-1.0 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark11(-12.820975733011547,-1.5707963267948961,-13.342026399606722,0.9335301041195536 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark11(-1.282471447766617,-1.4904099307835883,-8.067123863806941,-2.1382117680737565E-50 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark11(-1.283376003367168,-0.17074489683993238,-39.02177923064248,-1.0 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark11(-12.8351441032584,-1.1475520960360925,-39.18728373010014,1.0 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark11(-12.848619389995022,-1.5707963267948912,-46.48220040406358,1.0 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark11(-12.90926001645689,-0.3583910886575285,-1.5707963267948966,-42.2480581926677 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark11(-12.92884998566885,-0.42537251297061207,-81.22112247159731,1.0 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark11(-12.945803131782023,-1.1574365966206415,-10.522728576621446,59.99674478149153 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark11(-12.998694382594115,-1.4763615526156877,-54.53300060163535,0.0 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark11(1.3157250650756964,0,0,0 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark11(-13.184221067292146,-1.4154107251814851,-53.803316713873016,0.037687819134132494 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark11(-13.204747319661863,-1.0117455938011468,-0.6856238896348827,-1.0 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark11(-1.32208244027046,-0.9670052384244143,-17.832077864558116,-0.022725742000061243 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark11(-13.224790731236748,-0.10536228237066847,-92.68342291957848,0.9999999999999999 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark11(-13.322407671907865,-0.13232858223412122,76.46910083061147,-1.0 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark11(-133.9223541766046,-1.1567990986783865,-37.85351797496349,82.32720400938274 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark11(-13.4482851605311,-0.26839055882376694,-96.63193166775703,-0.9999999999999991 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark11(-13.452964377423989,-1.2224797567857149,-80.54349803475128,0.15953697914175713 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark11(-136.27099238472323,-0.2943424562481064,120.88710930771506,0.0 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark11(-13.63606975361007,-3.552713678800501E-15,-25.727733111617347,1.0 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark11(-13.658156340828796,-2.220446049250313E-16,-85.42760500168637,98.58462728917647 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark11(-137.1980957660333,8.823762594637463E-4,-82.87762968782113,0 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark11(-13.72011265071208,-0.988738683934249,-1.5707963267948966,-0.7257995256495241 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark11(-13.764854804500851,-1.2213349212459714,-0.21448246654617398,-0.7388637681437586 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark11(-13.770652538378172,-0.21352444780222157,-27.194473578674287,-0.003258917853623533 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark11(-13.785189708078974,-1.5707963267948961,0,0 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark11(-13.794117407044542,-1.4829739706968939,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark11(-1.3795527712490319,-1.6692256881660359E-6,-26.333524333903476,-0.08054951762537672 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark11(-13.887683791561662,-1.2915785527857888,-45.57230304371322,1.0 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark11(-13.887965309984743,-1.198998480127691,-18.97523320925357,-0.04393149351561043 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark11(-13.904029483700839,-1.5707963267948961,-1.5707963267948966,0.7310824480364886 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark11(-14.04234294803777,-0.2504691653586701,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark11(-14.060233584815155,-0.027707687006528238,-39.67175172485952,1.0 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark11(-14.06043824841872,-0.28477207147090833,-80.19855065577259,0.8244820528610474 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark11(-14.093909772728772,-1.3802857293472357,-13.695407374002883,-59.24689308017894 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark11(-14.097738533387357,-0.5442995534974102,-14.529011765114767,-31.0657994521015 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark11(-14.102702654375209,-0.04041328531996903,-59.780598085476655,0.7991613850749204 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark11(-14.105222215360339,-1.386273688266153,-1.5707963267948966,-2105.9765970242875 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark11(-1.414259460369418,-1.448150611614102,-46.34169214775329,-1.0 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark11(-1.4230150814023261,-0.19291050835424142,-21.71384972213866,-0.6602028578884581 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark11(-14.282435683728513,-0.3854113799286794,-60.68131616227133,-100.0 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark11(-14.299636966758124,-0.7291096661710181,-1.5707963267948966,2.9203394795075887E-6 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark11(-14.339288199676986,-0.13989514057083596,-72.5385198963763,7.105427357601002E-15 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark11(-14.351405493473479,-0.9783366907748162,-0.5396407635109272,-1.0000000008414998 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark11(-14.426754133604547,-1.5476694326344216,-45.318717334564425,-67.19203736136667 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark11(-14.43994635192263,0.16011605367784154,46.556258665752296,40.72396511798732 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark11(-14.446634946013159,-1.570796326794877,-31.706967627156274,-0.053712398400503736 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark11(-144.82419964632456,-0.11758630680319268,95.45717564589825,-62.13859982049645 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark11(-145.10018874485445,6.504638387700603,53.5630922889645,-45.3314218643902 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark11(-145.165259439291,6.463325193266393,20.117879725279238,-23.88208077945076 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark11(-14.68554093911316,-1.0670151352128083,-35.05281066279329,-100.0 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark11(-14.71301404120968,-0.015035734727391538,-49.59799255816451,-0.9999999999999991 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark11(-14.763168220133108,-0.050196881840304686,-95.44421548429845,0.010445217785280564 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark11(-148.03705254066276,-0.8677041803150785,-192.7133269828962,2065.2303581248207 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark11(-14.812144219630312,-0.11868635710860076,-29.19551747466282,-1.0 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark11(-14.834653825164883,-0.1599229317089339,-1.5707963267948961,-2095.548491303404 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark11(-14.949188671861915,-1.117911759060779,-70.83063050643815,35.16516913078743 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark11(-14.95473633803329,-0.862811755128964,-88.14075549215998,-0.9712896824309397 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark11(-1.4977651931536542,-2.220446049250313E-16,-23.8373966213333,0.4573961293129789 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark11(-149.78975945261186,0.2698882091963618,26.61382694963778,0.9408210634430607 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark11(-15.097577947136308,0.6735470059344377,31.887817222274492,-32.68671015337276 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark11(-15.109916726003707,-1.5348698691645097,-4.175523836626866,4.8757453574319385 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark11(-15.120839887865438,-6.938893903907228E-18,-2.5605360322285113,-1.3552527156068805E-20 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark11(-1.5147384154425039,-0.36995373919314267,-1.5707963267948948,-0.028188754407607264 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark11(-15.14840657785556,-1.5707963267948948,-74.38458040087616,0.5422938772869657 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark11(-15.149564440861491,-8.881784197001252E-16,-45.92847756560782,5.2014105087120244E-18 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark11(-151.50466219016383,-0.46741373034444555,6.971164119705307,1562.0907394305561 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark11(-151.7097294920667,-1.2815080365552343,-50.68266524397813,2150.3871451761106 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark11(-151.98513627708405,-0.2890689600220621,-17.939871104855555,2098.9696705534234 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark11(-15.210947533716565,-0.1577953390613921,1.5707963267948966,-0.12716014515614393 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark11(-15.235328882048442,-1.2848494710680747,-136.58696612824068,0.01344686561584462 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark11(-15.253263463136378,-0.2962620334823145,-56.4453634775075,-35.83840453339634 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark11(-1.525762864839571,-0.8489633175388716,-95.73882153679918,2059.023956221657 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark11(-1.5273534644548903,-1.1135252223760186,-40.657811151093725,20.10867682451469 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark11(-15.297686019640937,-2.220446049250313E-16,-55.65498403164423,56.18855380983049 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark11(-154.543168126836,-1.2316220882440598,-62.52769971455212,2294.9922996071455 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark11(-15.463672767550625,-0.1844680561281754,12.606926033997823,-0.13862669501748404 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark11(-15.515350699688177,-0.8582934884098535,-37.11716576552689,0.05288012627369014 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark11(-15.544555190151826,-0.4849803740701628,-31.08176941079705,62.30224982758435 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark11(-15.558629744647865,-1.565907198037154,-1.4989890077951387,-1.0 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark11(-15.579943499791215,-1.5215614513604407,-0.6277359434083134,0.12677964635061345 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark11(-1.562823510010747,-1.540368624808737,-71.25204843637019,14.760953334288928 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark11(-15.630805314578,-1.0372074753670537,-13.327780336502226,1.0230809898179138 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark11(-15.680965149434249,-1.0873823545231296,-1.5707963267948966,2.1684043449710089E-19 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark11(-15.690667993070809,-1.5707963267948957,-67.86348523655478,2.7616402929621557 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark11(-15.70770367558481,-1.5133005995782802,-64.49815962309604,-1.0 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark11(-15.710701232185729,-1.5707927273280025,-100.0,-4.2351647362715017E-22 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark11(-15.744804256637778,-1.4227322846649992,-1.5707963267948966,17.272447385204586 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark11(-157.81573651175702,-1.35031287334258,-88.18802339224582,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark11(-15.863157315043422,-0.41902846930020105,-0.7856038653594695,1.0 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark11(-159.17134544804196,-0.8678760136870949,100.0,0 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark11(-1.5934027891055746,-0.8965105262169296,-45.07905115397883,-0.9999999999999977 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark11(-15.96016773226832,-0.7665182365334822,-70.17688402951532,-0.05551191278242973 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark11(-15.978339522882095,-0.025306405945538655,25.66625791144949,-1963.8973119933296 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark11(-16.171905977487874,-0.9553916511604229,-67.2293464000117,0.9440535349379209 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark11(-161.72077454130516,-1.5707963267947633,-88.31108182150233,-1.0 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark11(-16.180414441442096,-0.21564947064395226,-72.77372046622578,1.0542197943230523E-81 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark11(-16.191815877460186,-0.005720122295915495,-45.51307358525669,-1.0 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark11(-16.1947712540233,-1.5707963267948963,-9.792180957778868,-0.7783524987957766 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark11(-16.220538483831945,-1.054074744327636,-34.27426914878709,10.206369374841067 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark11(-16.250152468898634,-1.1427379462274654,-45.29957705212551,47.064288522252184 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark11(-16.282908672983222,-1.5499702626083955,-45.3924312588188,-2.710505431213761E-20 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark11(-1.6283359061756066,-0.7799426450180675,-71.41904527377228,-59.64370676001672 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark11(-163.3174807128126,-1.8669732748177736E-4,-31.669678106563097,-76.01290836081347 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark11(-16.377906485198537,-1.000390632903077,-66.24597036344409,-0.837298697945239 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark11(-163.80864746408648,-1.5707963267948912,-66.53216754149913,-2298.768592334426 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark11(-16.389736030441686,-0.49166805241715383,-69.254027383357,0.05434314959403342 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark11(-16.406423604879937,-1.1608317926253524,-65.25336079561714,-52.22421797937595 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark11(-16.522592827610836,-1.1102230246251565E-16,94.41800032995468,1.0 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark11(-16.653720036764206,-0.9030356937073554,-9.937180214405922,-0.057694455646199835 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark11(-16.66510438657319,-0.050401755068057635,31.94761842862774,-0.05570667132547835 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark11(-1.66684033631478,-0.6797298838078092,-90.46952450746595,47.86531819503986 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark11(-16.753148626635028,-0.15934841208663963,123.26720335600359,7.765989213875507E-6 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark11(-16.791960785276093,-0.021825521235608603,-1.568726187645111,0.0 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark11(-16.809886135930576,-1.0021400983165414,-37.70292454332314,-100.0 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark11(-16.90913577686635,-1.1325339623248465,-123.76749217014633,-1.0000307170530953 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark11(-16.909682896976566,-0.6826019771046258,-15.738590004436183,-5.934729841099874E-67 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark11(-17.070909662238968,-1.5707963267948912,-45.53415805561386,-1.0 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark11(-17.074227258381192,-0.8811082367676374,-43.84539108979376,-0.6886924305782488 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark11(-170.82611750897567,-1.5707963267948784,-19.361626263332994,0.4997931443334096 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark11(-17.12627731727249,-0.5318535120410939,-18.377557286663727,0.3241978092228711 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark11(-17.157099334423933,-0.14096476259719382,-50.14568272964689,0 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark11(-17.20019219192401,-1.1589591997151227,-20.996844967654813,-0.9905429764087651 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark11(-17.208689084062698,-0.05022155139892372,-88.43793287335764,-1.0 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark11(-17.21201005971039,-0.4973419038426955,-41.848695670815445,0 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark11(-17.31707733280321,-1.0699631310873814,-46.17693675443083,-63.38584844874568 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark11(-1.7360507663768627,-1.1675295592180297,-75.92129101998538,0.0 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark11(-17.371874992734885,-1.5707963267948963,-1.5707963267948966,-3.2033329522929615E-145 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark11(-17.540720595298037,-0.8023403886081825,-76.04139876545065,-1.0842021724855044E-19 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark11(-17.60118506601804,-1.5068685855613477,-33.52932373227642,-1.0 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark11(-17.607497004323978,-0.2595666017346172,-1.5707963267948966,1.0000419870402353 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark11(-17.695512181688187,-0.9404990785362344,-35.478937811099236,-0.8928549405161025 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark11(-17.69562736039154,7.697355837252869,44.67611115883774,0.03508724190913956 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark11(-1.7773064926758408,-0.4255433073213406,-10.78451429291421,-0.7392994008951341 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark11(-17.80684633776255,-1.570796326794877,-66.00906898927545,-1.0 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark11(-17.82370775597644,-0.5611533840688381,-1.323532907324151,86.20008148296431 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark11(-17.826848192552788,-1.5707963267948957,-74.79440550613464,-1.0 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark11(-17.834700812287046,-0.9031604757194884,-88.31584751146245,61.449775220837836 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark11(-17.893035826644237,-1.3545927768417605,-75.51732829123492,-0.05664564900520076 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark11(-17.898257088565735,-0.7244551812277352,-47.33344598332184,11.63497010885714 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark11(-17.93693994894326,-0.30322058622069004,-72.51035258150338,-1.0 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark11(-1.7941618293845563,-0.08413739540131099,-80.92300184257584,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark11(-17.964073947246163,-0.8423206402994569,-86.66395478673647,-1.9160063088188E-9 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark11(-18.048001648665284,-0.7817997818425407,-26.28107635236998,0.7029500423621213 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark11(-18.070996494522976,-1.5707963267948948,-60.66496021383598,7.105427357601002E-15 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark11(-18.09711775529444,-1.5707963267948912,-0.11407558454346826,-27.631399396054306 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark11(-18.142074853992703,-0.9099071372875269,-14.784988938464675,1.0 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark11(-18.301858595724998,0.5946413428486623,198.91777549344891,-1374.9837921406968 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark11(-18.303937015910464,-0.2283959341979478,-90.63176545671296,-0.04749623361877131 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark11(-18.351729569356618,-0.7346735295753888,-37.959988832207365,45.853446370570246 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark11(-18.411593398750824,-1.5707963267948948,-84.0199686641115,15.8140201422775 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark11(-184.5592322299386,-0.525626970229053,-66.93127456729826,42.35042826666492 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark11(-18.461812241178688,-1.3799371338315278,-88.44111697574634,88.33679722075341 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark11(-18.60522448504998,-1.541961021320006,-42.44666025948337,-1.0 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark11(-1.865901084005607,-0.15689045160154555,82.69024980500167,0.0 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark11(-18.745779028929057,-0.4733918973236262,-12.75873426165242,0.6311663982540381 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark11(-18.776464249556074,-0.39625183062860647,-0.2753188660518598,91.03267881877403 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark11(-18.791297824826536,-0.25914733942851786,57.24514867347813,0.03904117685203905 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark11(-18.79358291816998,-0.987296963810599,-46.922597718357714,1.0 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark11(-18.808038875605025,-1.5707963267948948,-8.815275915562605,-2234.56032968493 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark11(-18.828968318513326,-1.5707963267948948,-52.47236676132207,0.656258931637155 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark11(-18.837172592784633,-0.24290280813055642,-5.338028172294372,0.0 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark11(-18.882070243194942,-1.1037555201614107,-6.660577163585188,0.9988929783488385 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark11(-18.883183219840294,-4.646868618253782E-15,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark11(-1.8958107455335234,-0.10796272497681425,-72.3003164985268,30.421393826399637 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark11(-19.02140164593485,-1.1923557883005933,-39.68475168080945,25.432873312101535 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark11(-190.43112340795832,-0.3284116952253481,79.39263866505101,0 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark11(-19.053300926597203,-0.012048001266516927,-16.489454504651718,2246.6447461901394 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark11(-19.108201423468614,-0.0551241362761029,45.33023221829456,-1.0 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark11(-19.115341026638518,-1.5707963267948912,-65.99076917256193,0.014211952172920261 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark11(-19.134847269687008,-1.2758803376355559,-6.670026574149674,81.9130693405099 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark11(-19.156757778879676,-1.4761733446669112,-1.5707963267948983,1.0 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark11(-19.189149149033135,-1.0714212618046535,-71.35770168517715,-0.407065105548412 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark11(-19.192464876372384,-3.552713678800501E-15,-37.85957163368805,81.11264195112057 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark11(-19.267397940253694,-0.04770650559732659,1.5707963267948966,0 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark11(-1.9612060296416534,-1.4154704797379658,-13.542704037191616,-17.689481319932074 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark11(-19.738992916618443,-1.5707963267948957,-0.3928128931753012,-13.772549842019629 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark11(-19.77360749518185,-1.5707963267948912,-30.5587532534783,-95.24772347145709 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark11(-19.851286513089054,-1.181870155232179,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark11(-19.89663204845481,-0.699821597222507,-4.698953760755714,-1.0 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark11(-19.914927886163305,-2.220446049250313E-16,-100.0,0.30819953094322416 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark11(-19.959531774120332,-1.1640790560977925,-0.3057471425329532,93.8489112145423 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark11(-20.045716712897235,-0.8131976566129354,-77.31413427443287,-2121.018654493205 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark11(-20.06295724911976,-0.5917015998456979,-2.220446049250313E-16,-0.7852993195014517 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark11(-20.064572180076425,-1.2550892454814968E-16,-32.60688998105854,1.00000005497943 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark11(-20.120336375257324,-1.4245286542359878,-0.8326745178908832,-0.03555920739380536 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark11(-20.15910232288192,-1.5707963267948912,-78.81821912084446,-0.7105688350364687 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark11(-20.16604010964311,-0.5050368642012641,-23.330971598526183,-50.27429734428569 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark11(-20.195178829773788,-1.5707963267948948,-25.667646165433332,-2051.586464772434 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark11(-20.227778468677183,-0.46825499423132777,-25.335509719779857,-4.6365076883592767E-69 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark11(-20.240596304068262,-1.2707366670242273,-85.27528408852166,0.9999999999999998 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark11(-20.247932466125285,-1.4956416886691681,-48.82514136083274,-1.0 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark11(-20.250547115549352,-0.8441855418282405,-90.33836746768753,1.9919904143059988 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark11(-20.2616099306656,-0.07950956372593398,-51.40836698851123,0.4004410878691118 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark11(-20.28309408222453,-0.5860116382239102,-16.75357558036978,0 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark11(-20.29419253000304,-0.07246344093450782,94.31418868228329,-9.538824957231487 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark11(-20.430923547237413,-1.5707963267948912,-56.877053233013115,0.9011892880779442 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark11(-2.0453244784377613,-1.5707963267948948,-1.5707963267948966,-69.64142721485565 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark11(-20.66473724951277,-1.1180245564727898,-135.45934437680768,0.051321974438215845 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark11(-20.740219691520455,-1.2402845392402106,-22.38651850251925,-0.018062673328189005 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark11(-20.804835349143787,-1.3654145476322603,-32.94731406204339,13.470937678733364 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark11(-20.814658887354973,-1.5707963267948954,-7.3863936573849704,1.0000004784210494 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark11(-20.85164174974466,-1.082089414205313,-44.404625774975734,0 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark11(-20.86581278714782,-1.4964353341474825,-31.69035175953195,0.36208930429630176 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark11(-20.87792544152463,-1.4840599013191527,-55.4664428175438,-1.0000000003655136 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark11(-20.969445541309803,-1.5707963267948912,-0.5731237788267062,-1.0 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark11(-20.971473921075813,-1.5707963267948963,-38.810845520466316,32.944815241120644 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark11(-20.986694027201697,-0.2958795006094722,-18.814934776957784,0.04202831965038081 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark11(-2.1191099381286858,-1.1721461937381323,-90.94393243973681,0.04012566400162147 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark11(-21.357351932737057,-9.985259592499002E-5,-68.31005272215828,-1.0842021724855044E-19 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark11(-21.544717508813868,-1.5707963267948963,-48.1416897924554,-78.39126930448194 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark11(-21.554628980434693,-1.4988920505202616,-51.15830902009464,0.04648926604570763 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark11(-21.55613585346846,-4.440892098500626E-16,-88.78372238734802,-0.057827394097060586 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark11(-2.15988317535316,-0.40347956843328525,-1.4628196798169093,-0.03661043822334434 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark11(-21.602115276963502,-0.4528920811680708,-19.49133293070726,-0.536314393135024 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark11(-21.651972494187827,-1.5707963267948961,-71.58123856697628,-42.60888683543172 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark11(-21.674283252402226,-0.5396615460063264,-37.6982532249214,-90.94622390824523 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark11(-21.726658565296148,-0.7832826932189265,-0.19636073902316298,-1.0 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark11(-2.1781287962938793,-1.5707963267948912,-35.111132274535755,-52.83685218384526 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark11(-21.840616078280192,0.07104068863708415,76.73320761141794,1.0023585777316777 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark11(-21.902746837695915,-0.6425317764390903,-101.59982858415398,-0.2965942357930633 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark11(-21.939986183744786,-0.03145511631889697,-45.46170811509528,-1.0 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark11(-22.01736582979508,-0.7669308810926282,-29.836052343998773,1.0 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark11(-22.186620169285476,-1.339558176005298,-29.08092569620696,1.0 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark11(-22.316506277102064,-0.24169122675453825,2269.221608416113,0 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark11(-22.353189780764577,-0.3704701453603804,-1.2026895606473857,1.0 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark11(-22.405139254962492,-1.4199072439798452,-33.540881321548156,-0.3605262364062033 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark11(-22.40948958911086,-1.0620488056156792,-72.4087538231213,-28.533471600284514 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark11(-22.41587052330094,-0.3100666179162346,-9.484559474128574,0.4742537316584545 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark11(-22.42107572401028,-0.7069240169716497,-66.83723597170803,-1.0000000000000002 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark11(-22.424893914886784,-0.47000033822498827,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark11(-22.528331816328162,-1.5707963267948912,-48.64900350579879,-1.0 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark11(-22.581218960590846,-0.9240937145007226,-16.037301736384606,0.9740021005909585 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark11(-22.58891191185377,-0.8710235520885347,-53.439159422281946,-0.38366974211517 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark11(-22.590908658213237,-0.3085117380247959,-4.57562101391693,-0.06265799864256616 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark11(-22.628518775764945,-1.1984652105967128,-15.386301578544277,1.0 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark11(-22.8150618852373,-0.22831105237757754,-2573.6862017427584,0 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark11(-22.930290078263234,-0.9697577794874207,-5.8947977753409475,-0.03673638223017406 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark11(-22.99986869137834,-1.1102230246251565E-16,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark11(-2.300390746847829,-0.17443469726109256,-90.26787523408558,-0.391434993403117 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark11(-23.03697919420622,-4.440892098500626E-16,-57.64979971112885,-1.0 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark11(-23.072964747765994,-1.5707963267948912,-45.17655677231127,95.52193293571273 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark11(-23.124144663904964,-0.33333053075532126,14.048157654339368,0 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark11(-23.205606085940975,14.704620050239292,20.318769331797533,33.10940726768679 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark11(-232.10878824028043,-0.3815878803011472,-100.83558479337353,69.85941869570786 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark11(-23.23526968530795,-0.362986117317623,-62.73163605078073,-0.8668059174226967 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark11(-23.276956427912072,-1.2241884632591968,-53.868149710592824,-72.25428795382749 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark11(-23.371913630782753,-0.01218804040445692,-39.17805633549178,-1.0 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark11(-23.40476943424234,-7.105427357601002E-15,-27.074065720581302,-0.3096010299329519 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark11(-23.609489453088322,-0.9687068389480014,-52.26036169084332,-1.0 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark11(-23.622961627313195,-1.570796326794896,-7.675052982777572,-1.0 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark11(-23.689305854530033,-1.5573308517982414,-0.4422134007904246,0 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark11(-23.755689407248155,-1.5169083855080727,-38.85893990927167,-1.0 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark11(-23.76116884386366,-0.38638181312344405,-84.4845687958752,0.3334060782386814 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark11(-23.794005658302268,-0.9901887722185072,-3.5945150435244244,0.970858338935792 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark11(-2.382390037229129,-1.2593774413663965,-127.76836530492321,0.8980507326377631 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark11(-23.831739578450453,-1.5707963267948963,-8.050759970408814,-1.0 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark11(-23.95759019166182,-4.440892098500626E-16,-66.10362205658143,1.0 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark11(-24.063088641915332,-0.21827744315098185,23.129445793133044,4.2168791772922093E-81 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark11(-24.120769277248037,-0.22367453962647393,-36.90684153234275,0 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark11(-24.12199150548245,-1.4520782210631602,-100.0,0 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark11(-2.4182684108233055,-0.2863549027174628,-32.97369837246025,1.0 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark11(-2.4386096213989816,-1.5707963267948957,-94.87791977873282,-1.0 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark11(-24.4471904270659,-0.8886113815249246,-1.5707963267948966,-1.000000000000007 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark11(-24.46302866624238,-0.24641188720546614,-21.330879744762576,-65.32817465240518 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark11(-24.51864671009557,-0.6459756427650436,-26.501804008832256,-0.5811215830822225 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark11(-24.585008109036234,-0.022587192040457983,29.37804163285111,0 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark11(-24.754305280465317,-0.3920879096219979,84.66087614813875,0.0 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark11(-24.77698855778105,-0.8319815929669138,-44.18265582232294,-0.012245807545086418 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark11(-24.846449578180412,-0.7587304486970794,-31.83433830136441,-6.776263578034403E-21 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark11(-24.852723662801242,-0.13342065802101796,-1.5707963267948961,0.11597839954843003 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark11(-24.97371436396209,-1.169535984702782,-1.5707963267948966,-84.92626092907037 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark11(-25.31302192954022,-0.04909666922197742,-1.5707963267948966,0.9999999999999998 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark11(-25.32173145317389,-0.5340394932406343,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark11(-2.53870713842241,-0.03114438543557735,-44.10992862332489,-1.0 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark11(-25.446248253461434,0.14645184532381986,19.95750676336511,-0.7948271399679752 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark11(-25.50751380737654,-1.5707963267948841,-113.78086064802099,23.48347979630833 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark11(-25.554680395691882,-1.5707963267948906,-0.11825412649364207,1.0 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark11(-25.562124698554612,-1.0786818224142691,-86.73525811602285,-0.40629204070329483 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark11(-25.64840036947963,-0.6402792184957651,-23.672775057926756,17.446591584633257 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark11(-25.767764772258147,-1.349726142171292,-100.0,-1.0 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark11(-25.851147707767907,-1.4037146233100868,-55.18299505565473,-1.142987391282275E-100 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark11(-25.855216650734587,-0.5326890658336545,-0.6008901771030443,0.606421727500694 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark11(-25.992843890294438,-0.6936191438010082,-8.049689943340653,45.50698747552903 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark11(-26.043186529625782,0.4139301572324968,1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark11(-26.11019158305885,-1.5707963267948957,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark11(-26.130357534540295,-1.5707963267948912,-47.36829362047437,0.004006381676466997 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark11(-26.225238198009833,-0.8588434326220096,-4.487777228995739,5.195378196998888 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark11(-26.381881147637785,-1.5116988867176568,-85.69351446532664,-89.96100715895635 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark11(-26.42678244307912,-0.005156092660501954,38.830489563458826,-13.28108793625503 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark11(-26.444126722976964,-1.5707963267948948,-4.692983848416472,-0.9820961929104965 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark11(2.644438420115037,20.95912234184827,0,0 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark11(-26.45045563569299,-1.5707963267948961,-44.757326855950254,-63.675430780146236 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark11(-26.4799025399667,-0.5075828643980033,63.92643886863135,71.83199948840056 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark11(-26.509941906833134,-0.18539265347973624,-15.63207936355912,-57.84904171494127 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark11(-26.57766859342553,-2.220446049250313E-16,-1.1803945142420507,1.0 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark11(-26.601620356129203,-1.5166266197311735,-85.3211962158731,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark11(-26.659360568172506,-0.9083818004231228,-1.2903105167751352,-0.06256940533274834 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark11(-26.74246550854835,-0.6030366253196572,-85.81900275437671,51.47010266746716 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark11(-26.85157036629002,-0.48554063322562035,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark11(-26.899962401991175,-0.5015791264591551,-30.79744465836548,0.015452849119546978 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark11(-2.6972247866248082,-1.5707963267948948,-62.16777594335714,88.52660092403426 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark11(-26.993843936549148,-0.00939650920063376,-86.66129752484952,-0.27650733872729294 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark11(-27.00974605725225,-0.2604889443535183,-1.5707963267948966,0.04474288693684114 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark11(-27.103974620371673,-0.6475041664333728,-100.0,0.0337968347640511 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark11(-27.131430523557093,-0.5445264506658625,-95.79406053191418,0.5218122828382581 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark11(-27.15090924115625,-1.2816719860091272,-40.093482776717096,1.0 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark11(-27.176428783796556,-1.5707963267948912,-76.27711796231031,-18.498424890223433 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark11(-27.198789777186676,-0.6338124416743648,-0.41387342389457943,1.0 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark11(-27.283170541913343,-0.24971153177033412,1.5707963267948966,-0.05614131930043109 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark11(-27.295697959347027,-2.220446049250313E-16,-37.66105837954984,0.9903558691391954 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark11(-27.29672948411119,14.46274259592083,31.541065353111776,-100.0 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark11(-27.66604390134721,-0.5659991543412877,-14.207162910821623,-3.7368118440007674 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark11(-27.689291111537372,-0.6338525155813172,-2.6974324085661365,1.0 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark11(-27.700543505085584,-0.3983892776049358,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark11(-27.792535748484767,-0.02661085456688117,45.1568083318936,2.1684043449710089E-19 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark11(-27.82524928063671,-1.3012150227254078,-39.7631187559774,0.010160423463728602 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark11(-2.788304795806872,-1.4253261337628533,0,0 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark11(-27.916902536826157,-0.2207818079057416,-31.644267305565506,-1.0 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark11(-27.94783838107779,-0.5257542300982604,-1.5707963267948966,0.9495778545505004 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark11(-28.004204271573535,-0.5890359085377416,-50.931564405405375,-1.0 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark11(-28.091267303279643,-1.2760553495889488,-34.21712671805971,0.018075764870047695 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark11(-28.10375572084085,-0.339267282503652,-8.930935143369158,27.271566933443253 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark11(-28.141542157226155,-0.18241689545576856,-0.902512329562513,-1.0 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark11(-28.34046514526278,-1.5707963267948948,-71.23999643742269,-9.747919949846718 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark11(-28.344772860258857,-1.5707963267948912,-55.47638387928346,-0.35789122175451626 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark11(-28.347041160501348,-0.25073114048872924,1.5707963267948966,-5.939047612164803E-4 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark11(-2.8384470491922604,-1.1859684771908634,-16.02086190584178,0.6272059194942834 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark11(-28.546582120154895,-0.001813719000778148,-61.725790873419804,1.0 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark11(-28.550275167696896,-0.7383077581548072,-1.5707963267948954,-0.7582440975767268 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark11(-2.855151821827633,-0.5200701887414727,-27.689057180529183,-37.86868858634466 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark11(-28.656396286643712,-1.5707963267948912,-87.30160402689835,0 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark11(-28.6766748206294,-0.007849916878470226,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark11(-28.702171004323613,-1.1475370178853928,-99.139960073154,1.8726705418768793E-96 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark11(-28.755070356896226,-1.5707963267948952,-4.451217833412272,-0.8240315082574349 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark11(-28.893704130287478,6.429496655189621,32.781716159473575,-1.0694981413364388 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark11(-28.950676209418233,-0.8999837451853478,-16.49843798096532,2135.6391847452937 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark11(-2.89647586715874,-0.13764439057294092,-25.06219630751464,0.9999999999999998 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark11(-29.145393535802075,-0.048602637252539216,-31.00566609105769,-24.80514619276476 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark11(-29.33746335374328,-0.09638885853892099,-46.90442861179527,1.0 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark11(-29.346375528324003,-1.0458576588417912,-33.83254872727785,100.0 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark11(-29.370035794428915,-0.04829137287497036,-42.91020081893875,-1.0 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark11(-29.37263852033753,-1.5707963267948948,-93.77280113157933,-1.9749104606016399 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark11(-29.378735931461677,-0.13643379242000353,-1.5707963267948966,-57.35830694015111 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark11(-29.49311080923505,-3.552713678800501E-15,-45.01966920474898,-25.92675689841917 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark11(-29.50425639013594,-0.16061891710334092,-1.5707963267948966,4.306727232630028 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark11(-29.612054947490776,-1.056119726902752,-94.67549797047504,0.09000966295859492 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark11(-29.6408436063193,-0.3807419236980777,6.400045739476414,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark11(-29.66682896127532,-0.01575113560495607,1551.2078243651924,0 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark11(-2.9675028119951046,-0.6346070460560828,-1.3556098513103652,40.78116040670518 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark11(-29.692007335123634,-1.4390695778501,-1.5707963267948966,-49.23833015672534 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark11(-29.726505191192288,-1.1850569763259386,-38.225103495610036,-94.1461345969955 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark11(-29.736109130321495,-1.1102230246251565E-16,21.624469954672463,-61.2980347974448 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark11(-29.746748802604557,2.9078352065997968,1.5707963267948966,-67.63204758034473 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark11(-2.9748696093356415,-1.517675455381603,-96.21882396740321,-0.00820346644696153 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark11(-29.82677356771535,-0.7853981633974474,-60.81495063127613,2.5883975994488595 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark11(-2.9840941359236735,-0.2743114852810007,-67.40462501754857,0.0 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark11(-29.903626736044803,-0.13244488279647565,-40.62767387567277,52.09541198729171 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark11(-29.95216544166985,-0.3068222592335801,-155.51312610816706,0 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark11(-30.088230622188615,-0.5809950929276164,-1.5707963267948983,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark11(-30.12011645163945,-0.21859096530325572,-34.16469984464019,-1.0 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark11(-30.166879456963095,-4.440892098500626E-16,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark11(-30.25946954244317,-1.1012885893759168E-14,-5.184754123642739,-1.0 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark11(-30.27558182374814,-1.5195453327924544,-1.2516485597605624,-1.0 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark11(-30.284463221905614,-1.4863820470548137,-48.8379911727049,-0.8509856580908397 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark11(-30.441708425753184,-0.0013535322611680101,-88.25244696291313,0.28383725840741625 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark11(-30.460156299310995,-1.1249642139868761E-5,-71.76334694448762,-0.48261653010813965 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark11(-30.487285008792924,-0.4161376471129359,-29.74873862607169,8.881784197001252E-16 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark11(-30.605575531512113,-1.400432468063732,-1.5707963267948983,1.0 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark11(-30.63976334347923,-1.5202828024938528,-77.41854378649045,-72.2325905033443 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark11(-30.65789757570291,-0.6717000478285671,-34.30227339529611,6.606217291683944 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark11(-30.710083384834938,-0.18475215374502807,-24.999722643501794,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark11(-30.72637153942394,-1.5707963267948963,-15.508601354711734,0.9999999999999996 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark11(-30.818802736552684,-1.3267014125233374,-1.5707963267948983,21.120600640081058 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark11(-30.826600263973077,-0.9609364289106818,-1.5707963267948963,2008.5849900232179 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark11(-30.861566615269574,-0.006741165039287775,38.79817222416059,-0.049872642818989676 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark11(-31.11359448955309,-0.3896235538860241,32.51138615968675,41.22200620179023 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark11(-31.12986519717076,0,0,0 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark11(-31.139321934944096,-0.32570040483657825,-61.445446716290135,-1.0000015178443131 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark11(-31.17027684034796,-0.79811516858056,-25.282088841489582,-1.0 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark11(-31.20413499508455,-0.1233786782139097,-9.227535749878129,-0.8392334861454718 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark11(-31.278274837353194,-1.2925888686640346,-5.049764175481725,-0.8266217911268006 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark11(-31.320712895859952,-0.006140131862536256,-5.551115123125783E-17,-0.038872287103456304 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark11(-31.362581299511692,-1.409705049831196,-89.14174938218994,1.0000000000000002 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark11(-31.37555100097009,-1.3019563919952466,-37.87311619732989,0.6436812535050365 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark11(-31.447678847902992,-1.5707963267948948,-60.05961115776,-1.0 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark11(-31.448815511651276,-1.5707963267948912,-17.952150823989115,19.65448976235355 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark11(-31.455335930234007,-0.025296114067489554,-1.7348637936392963,-2.465190328815662E-32 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark11(-31.470112613869123,-1.289336339610519,-0.1779121927419366,-1.0 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark11(-31.71660426587445,-1.2445609261195327,-35.01783730412981,99.53496662025289 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark11(-31.78673040835607,-1.5707963267948963,-0.6011071011370369,1.0 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark11(-31.824190384056543,-0.2998158945211423,89.29423403376242,-3.2311816509177735E-9 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark11(-31.86002021906473,-0.8557583516767119,-46.49524776236535,0.05266620380310251 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark11(-31.875779289277837,-0.27140984828507586,1.5707963267948966,6.462319648500937 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark11(-31.92908812311046,-0.25275686522565854,7.478282127952545,40.73636458313664 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark11(-31.940995568104885,-0.6922146487942394,-9.865009505345455,72.30655501108393 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark11(-31.970218010913783,-1.422224166335781,-39.150059126409914,1.0 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark11(-32.01125643367013,-0.3208740562589254,-1.5707963267948961,18.179770920933265 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark11(-32.02507580152954,14.42924099127891,6.302592937284572,5.436645633193496E-4 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark11(-32.06521979394453,-1.304958098819866,-39.01930624779075,85.2637130919775 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark11(-32.08063553927005,-1.5707963267948521,-82.12011402147633,0.0 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark11(-32.11112517894475,-0.6510271549747327,-26.30075405086376,0.8502073829778283 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark11(-32.15632541150738,-0.2053257649178289,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark11(-32.23111710404189,-1.5461643635388835,-37.19321636198532,-1.0 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark11(-32.24094640635639,-0.6957976079462349,-66.97708603544123,29.73429202893424 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark11(-32.278068962443825,-0.7342900325907333,-16.705269007910456,-24.397466176702565 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark11(-32.33480818836239,-1.3193513898037839,-27.833276405506282,-38.60739479349387 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark11(-32.357788318251124,-0.838623672729184,-34.38419634167952,0.9769652865232876 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark11(-32.3710024145805,-1.4317377501948485,-66.34869572620795,-25.769176560719462 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark11(-32.383497805960225,-1.2220223973866902,-35.121333214629345,-0.38390303174325313 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark11(-32.437048979727024,-0.9295153495635202,-16.64621512734169,1.0 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark11(-32.440967337624315,0.4082883862976562,16.659403988545037,0 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark11(-32.459411266907296,-1.5707963267948273,-20.465644212390004,6.500190787202541 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark11(-32.473053872258035,-1.5707963267948273,-24.25915884563434,0.0058117848461679 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark11(-32.93695061921459,-1.1511519910619539,-39.00133064164095,-0.011261038222203531 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark11(-32.95229942031665,-1.468108307345981,-50.233537017011,0.0 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark11(-32.96315052940999,-0.6450680939528181,-42.671564686657604,-0.06259962561702666 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark11(-32.97415603379537,-0.8310843337490321,-18.06247602974271,93.53626530639141 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark11(-33.16168976345857,-0.3278271858894715,-0.09255861638685438,1.0 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark11(-33.28098540664891,-0.039245174329797905,-16.475101604367737,-65.99936485363258 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark11(-33.30093236319723,6.448701736920854,20.21263124511509,100.0 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark11(-33.318097639460824,-0.050203298000645644,-64.78858718790264,-0.8670064539401843 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark11(-334.8969856192438,14.42923640117408,32.57151483449096,0.0 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark11(-33.58325494593454,-2.220446049250313E-16,-6.250151265037172,-0.8356107248480602 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark11(-33.66044813414996,-1.5707963267948957,-1.5707963267949125,-1.0 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark11(-33.83378734856845,-87.8240569108693,0,0 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark11(-33.83946069551854,-0.8179938995463165,-30.577561350442643,0.0 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark11(-33.86296744765164,-0.4331941840008475,-45.54173240220417,1.9060672070778586E-7 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark11(-33.98480558324856,-0.8039324953054496,-63.420793049139235,0.0032379514885404344 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark11(-34.08534556227401,-0.0012601540949158663,44.322858639441264,-1.0 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark11(-34.088132773625375,-0.17022966708443943,-15.271240971446167,-1.0 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark11(-3.4114205592392737,-0.8220941940880198,-1.5707963267948961,-0.022839754458026357 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark11(-34.183880175119036,-1.3709426119182209,-1.5707963267949,7.68620990318405E-16 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark11(-34.3853991490649,-0.3568480720393685,-38.98060598876359,-1.0 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark11(-34.389884623087866,-0.5307825572344514,65.00959420513215,1.3552527156068805E-20 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark11(-34.399599518807904,-0.05673009023185326,-69.52511728269448,1.0 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark11(-34.511721899847416,-1.4983718682221152,-41.614264749388894,-1.0 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark11(-34.55375197251155,-0.2665917097040491,-95.39922622024031,-0.8251645030078915 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark11(-34.55555648931865,14.914803796106234,-70.48294738701303,0 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark11(-34.579966008035655,-0.33181551294667344,7.782425283731154,65.22998327550638 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark11(-34.62679894628067,-0.015139246196627733,-5.968316104648025,1.0 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark11(-34.66172723158532,-3.552713678800501E-15,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark11(-34.70716454482569,-0.6961963177316456,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark11(-34.73501205828421,-1.297414598968825,-40.36376649928675,-5.964186585262155 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark11(-34.76940666063104,-0.15055200658011214,-1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark11(-34.812965635132336,-1.5707963267948948,-88.30706032232955,11.851768502768081 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark11(-34.85611312124981,-1.5692096430996278,-73.25896809645805,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark11(-34.96506228632152,-0.3398603950986949,-78.98060371243561,1.0 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark11(-35.1854028668193,-1.5707963267948912,-65.7179995216036,-1.0 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark11(-35.197862245983444,-1.0232715213656869,-27.14190231411777,1.000080938099556 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark11(-35.20097424081057,-1.5707963267948912,-81.8701070367001,1.0 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark11(-35.26398509831038,-1.5707963267943725,-38.46803373524323,-0.9945403479118011 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark11(-35.33698691057395,-1.5707963267948948,-13.2722842755294,-4.880826839734558 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark11(-35.37464583601771,-1.045840654834301,-38.09240560321019,0.01673440688762319 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark11(-35.37874444418833,-1.7763568394002505E-15,-77.06605462176444,-58.26610824304159 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark11(-35.407558612584914,-0.38619777096587515,-85.37566274524299,-0.057655727046032224 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark11(-35.40793230496742,-1.5707963267948961,-30.597250713806574,0.8432890108575463 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark11(-35.49000268786289,-0.6842898790634391,-1.5707963267948966,-0.04601771820762156 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark11(-35.53367378009026,-0.11047302870349329,78.58400614408401,2110.096350789777 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark11(-35.581599163176804,-0.3809097423374135,-16.53536040502418,18.868364231728506 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark11(-35.68606821747617,-0.027789011871425726,-32.32559665688041,1.0 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark11(-35.809012340789046,-1.5707963267948948,-45.32941243771865,38.97714563896037 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark11(-35.89919134119402,-1.109226521262407,-39.698980673961834,0.4625903096126034 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark11(-35.92611865963991,-0.31088379029047797,-34.400096343836694,1.0 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark11(-36.05253028253081,-1.371850568003515,-72.10691471373592,-1.0 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark11(-36.11233778943315,-0.4178432535622668,61.04179763225898,0.0 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark11(-36.11581123024126,-1.5703607609829024,-14.31241549615628,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark11(-36.21572589136008,-1.5367956716133953,-1.5707963267948983,-2181.932835989894 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark11(-36.27146515912243,-0.7788873307118216,-30.851932606881793,1.0 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark11(-36.32903586402542,-0.007508946003911679,-31.599942705819807,0.004158961074064826 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark11(-36.449651697542315,-1.433445192020021,-17.668594002974245,0.9061851849352417 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark11(-36.45064247664402,-0.9882623974078869,-0.6298533892589857,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark11(-36.50381252431556,-0.15613045008026916,-55.475318484664626,-1.0 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark11(-36.57621227214068,-0.6793672553993233,-32.2166346684906,-17.055458073523212 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark11(-36.62459744315876,-0.499566854411998,-0.09132899447480305,3.552713678800501E-15 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark11(-36.77889694022953,-0.039122281695679106,-109.33058814064059,0.038353408762535145 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark11(-36.81611273800002,-0.0763442327253489,-100.0,0.8846852409912553 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark11(-36.8457412150906,-1.5707963267948963,-51.996941223178695,0 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark11(-36.92064255375891,-0.6780569337972242,-42.41180491580947,0.011854596176392099 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark11(-36.95825594390789,-1.4570468570930852,-73.33776965602932,-0.23899091448075888 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark11(-36.96622952489414,-1.2202549375457457,-52.891346816327335,2121.7157559926086 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark11(-37.05008656366924,-1.5707963267948963,-3.9819389570102874,-82.67771058717219 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark11(-37.20163343958103,-1.1500174725028494,-90.39884977399943,-66.38341688350408 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark11(-37.23002004188333,-1.505796926190804,-90.17866786202003,-0.751957683597775 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark11(-37.233413337229265,-0.05472933811621531,-88.51669873196985,-3.4246618180052195 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark11(-37.23569841939299,-1.4949888332448809,-18.585743314315792,0.5260316486140013 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark11(-37.30091922313458,-0.5883206761041094,-54.65558450581717,-1.0 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark11(-37.37417423787936,-0.006395178707385384,-44.24705838703646,-0.8956577910932075 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark11(-37.673020123162516,-1.234358214577298,-95.6811314793559,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark11(-37.6773779893041,-1.3119051295104691,-100.0,-99.84262579957353 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark11(-37.77691278371525,-1.2012531411251857,-39.90192409331892,2330.762371483447 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark11(-37.81762326807438,-0.6062890550669988,-24.49543523635518,-8.583749432481174 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark11(-37.85257646970268,-1.5707963267948912,-0.9122527742432655,-60.353039987798574 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark11(-37.85306880740708,-0.6674026905785382,-89.02828767229937,-1.0842021724855044E-19 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark11(-37.88159252850255,-0.1284341644655943,-72.35076055380203,-1.0 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark11(-37.93176822443222,-0.46222287928331696,-1.5707963267948966,-76.00484015717794 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark11(-38.01626799837963,-1.5231359313216482,-5.627650904943102,-27.174359446620368 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark11(-38.0893735441883,-1.5213245435016736,-67.3400926859546,1.0000000000000036 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark11(-38.10738290446727,-0.6779028954259705,-95.67126283037632,1.0000000000000022 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark11(-38.139392544972,-0.42120600284016874,-2.092641868934521,0.02679117658971747 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark11(-38.16915877533864,6.431273750103924,75.65396655331004,-682.9524904804833 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark11(-38.33542449578167,-0.4351483833964217,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark11(-3.8343378209996644,-1.1798820496971412,-52.945378505551766,1.0 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark11(-38.376422137533154,-1.33782319218004,-53.670355379600146,-4.185697892680654E-4 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark11(-38.401163014641384,-1.5583227112414342,-12.351335153553414,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark11(-38.40291112219189,-0.5336688990318013,-58.385952003268756,1.00296143252182 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark11(-38.406021435098886,-0.015576434294125086,-0.6309315321991444,0.043373020482265115 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark11(-38.419717487087844,-1.4038736659207576,-39.07117707635115,1.0 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark11(-38.62798388813797,-1.471900789959141,-66.37333677641612,-0.02674950521148073 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark11(-38.72058603006835,-1.4739547199585195,-43.470149028054685,67.88800148973135 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark11(-38.751049370439404,-0.7551498157952933,-1.5707963267948966,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark11(-38.80707369841897,-1.1256001730802234,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark11(-3.881474364225223,-0.6348654355258212,-48.71384515558508,-0.14367523982680175 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark11(-38.82337817509357,-1.0769380492721858,-0.49724288120489374,0 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark11(-38.90746250544869,-0.9840828467593066,-1.5707963267948974,-1.0 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark11(-38.96865168854617,-1.5700572299544349,-56.31143667107195,0.9067380401732228 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark11(-38.96901128092706,-1.0010373972857436,-1.5707963267948966,-2.4409295762914205 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark11(-39.015266753268016,-1.570796326794893,-90.40249989852991,1.0 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark11(-39.05230578497859,-0.2810127715216725,50.4367389172084,0.0 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark11(-3.9082506566085127,-1.0924505866902579,-1.5707963267949125,-0.36209968471805215 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark11(-39.082748610241524,-0.055879851096847594,-32.015039503792266,-33.42816650829141 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark11(-39.093539376480244,-0.8781978650131368,-123.05160561986467,12.831371416045243 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark11(-39.133770656027245,-2.2204460492503114E-16,-1.5707963267948966,54.617926113518315 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark11(-39.18343185952147,-0.1673670566135754,-98.20153001119178,61.343195678350945 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark11(-39.2525814123678,-0.4338711434447995,-15.001289676060894,0.9764469060454998 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark11(-39.304637997657295,-1.5707963267948841,-70.50006828054936,0.0 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark11(-39.591700485468174,-1.5704860288770877,-12.55726868096122,0.9866071090725642 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark11(-39.667814739980166,-8.881784197001252E-16,-92.25867941886732,78.06213936524097 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark11(-39.76169561888012,-1.268111368472146,-44.673495782964615,76.20271426129202 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark11(-39.762241384659355,-1.112496973492299,-100.0,-2168.3255691972017 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark11(-3.9853786619550107,-1.4510926056057585,-80.3884108833104,-34.04354168336506 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark11(-39.85692996026185,-0.5359520024067537,-95.42652896593215,0.0 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark11(-39.95295382529436,-1.3956645607090434,-89.15164945404165,1.0 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark11(-40.094251081093304,-1.1224782360314243,-77.50908894910958,0.0 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark11(-40.15571259730194,-0.5637841054087562,-40.22940691844845,4.6365076883592767E-69 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark11(-40.18649737493932,-1.343693399461,-44.41787961061175,-0.10047841878621 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark11(-4.018697332749326,-1.5554221920677365,-88.5263753539445,-0.49822443611158806 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark11(-40.19168213595141,-0.9714287341469391,-1.5707963267948966,1.0000004043448834 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark11(-40.22409946342349,-1.1555848024017557,-79.75130984782348,0.015889993624294982 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark11(-40.23898266686382,-2.220446049250313E-16,-59.54947760523929,0.90942793683932 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark11(-40.34036628199338,-1.5707963267948948,-0.049781362496356986,-1.0 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark11(-40.35848043912714,-0.22794321538899365,31.91178032170015,-1.0 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark11(-40.39281048022012,-0.39487593426686246,-27.542553466411746,-1.0 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark11(-4.04495832772498,-0.12617716298624623,-44.42358544694976,-79.07654777065042 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark11(-40.468122545479694,-1.5707963267948912,-35.41995460896199,83.62854754950155 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark11(-40.53749835821509,-0.9948150809632699,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark11(-40.547813881922835,-0.27796595314511724,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark11(-40.55003921965219,-1.4913528445931978,-10.701839719408314,-82.40088999098617 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark11(-40.58849537382695,-1.5707963267948024,-5.282137468516211,1.0 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark11(-40.60725033169319,-1.4163719969070412,-71.74071246647702,2130.4391296884996 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark11(-40.63947347613252,-1.500395619769598,-1.5707597555942154,0.028608346209040292 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark11(-40.772417253859956,-0.9143445320183613,-62.21459101332748,-0.041819266721494344 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark11(-40.96686367907761,-0.1267666340975129,-38.84900214560084,2093.773012864464 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark11(-40.971673822058506,-1.570796326794408,-91.65489921812112,-0.3013109051354306 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark11(-40.972258115467426,-1.5707963267948948,-4.592569214126497,-7.741147500619277 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark11(-41.06411872361962,-0.3193437630415775,1.8265250707393221,0.0 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark11(-41.09495080513061,-0.03709245975333664,-21.516039341869526,-100.0 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark11(-41.10805482380723,-1.5584375806398338,-0.7976287245561393,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark11(-41.20828048701841,-1.5707963267948308,-39.51931533540352,-33.80738340386959 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark11(-41.24630004425841,-1.020897043898438,-14.999867441683605,0.0 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark11(-41.296969029649524,-0.6239416719755573,-13.133508997495836,1.0 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark11(-41.29801786591601,-0.403682381768931,-159.59214380464678,-1.0001158350362949 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark11(-4.133366739970786,-0.2440282119751257,32.844623264967765,-65.75830212473957 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark11(-41.36157157924374,-0.2904899974262546,1.5707963267948966,-5.90877401234025E-17 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark11(-41.413406601000304,-0.1081835526618562,-100.0,40.67863994679195 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark11(-41.444968791642694,-1.5707963267948963,-100.0,1.0587911840678754E-22 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark11(-41.47187795721437,-0.25945760543193974,-20.081768804693496,-1.0 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark11(-41.54382583769526,-0.07861976812666009,-11.622159059612216,0.9942302147780769 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark11(-41.558804285074736,-1.5707963267948912,-26.93660849959892,-1.000000000000003 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark11(-41.62601007509595,-0.4085985326749472,-99.80222238720474,1.0 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark11(-41.63815772969946,-1.7763568394002505E-15,-46.77644046794125,16.564491884571368 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark11(-41.64536581001783,6.429257633740414,0.0,0 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark11(-41.76656156517484,-0.30196955874047055,-32.53475590943856,-1.0 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark11(-41.76868583627961,-0.7295385658652472,6.7123895210023035,-100.0 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark11(-4.182737302289423,-0.8712372688390833,-52.512657450436635,-1.0 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark11(41.83517539223834,3.485567664790821,-79.46541648518243,0 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark11(-42.03224271693434,-0.27376615391190506,-70.88630146767444,0.9123481044894461 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark11(-42.05045695423374,-1.431857734489219,-1.5707963267948966,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark11(-42.1865020235169,-0.06711695055311835,-98.68940564821192,-0.6964772375041324 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark11(-42.20644336764591,-0.004266783310862388,60.80678696477076,0.0 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark11(-42.260452594597574,-0.9920732087884143,-44.63130550511826,22.640736408394517 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark11(-42.277955139941945,-0.3814544031289373,-2.8971540665830497,-0.058009983582007006 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark11(-42.31026104978595,-2705.4935903195073,0,0 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark11(-42.49329411336335,-0.2808644182127966,-1.5707963267948983,0.010990071847694792 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark11(-42.54990280138065,-0.40430415555370675,-31.58561160955354,-0.9999999999999998 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark11(-42.80253526428971,-1.0989694673818118,-24.536321480328517,-0.36209491063480187 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark11(-4.284368591470084,-1.5707963267948912,-61.85189677253773,-1.0 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark11(-42.89165769111742,-1.080542959686859,-27.84572761410689,62.060088284844525 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark11(-42.90668738659766,-0.07684625398047469,95.51509326248643,-74.04144705192371 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark11(-42.965736388391015,-0.28130463066529476,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark11(-43.08626036754133,-0.6947128250244555,-21.362331965567723,0.027926666913451026 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark11(-43.10530214396425,-0.9826638624994768,-88.2929300625557,-0.06255814994971817 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark11(-4.31117115187008,-1.0803958205560493,-57.5055938265129,0.03098715234903482 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark11(-43.28907559497009,-1.4259801159897048,-32.48444075490336,2.6355494858076308E-82 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark11(-43.32458884518281,-0.004061549326955633,0,0 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark11(-43.435082589170555,-1.137256393844056,-1.5707963267948966,-0.0286108834733389 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark11(-43.474235402399685,-0.1909265850738969,83.67316819550095,0 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark11(-43.474799995687334,-0.032945651539446084,-34.950874529099465,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark11(-43.47690454014156,-0.07183570845940726,-44.51751776637676,1.0 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark11(-4.34954396298555,-1.2697962612214901,-9.581484563795058,-27.2761548473148 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark11(-4.350381529781317,-1.2809213033922173,-7.281413203245114,-0.36277529122215046 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark11(-43.533040580731964,-1.168291719911828,-10.825139867167525,-48.563312768830514 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark11(-43.555308649398896,-1.2183120237069547,-54.89303929404562,1.0 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark11(-43.56103082694753,-1.3036431174952472,-1.5707963267948983,0.271194630159605 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark11(-43.594698834137546,0.0,0,0 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark11(-4.360677687380555,-0.0568905658634975,-81.28111054718745,-0.899624643853195 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark11(-43.60693465364539,-1.3260093001132596,-196.01549977338306,0.9999636673671952 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark11(-43.62893523500702,-0.306105051220506,-4.634024525188595,-37.78525422788717 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark11(-43.69641994181903,-0.041060612547655695,44.64884224741069,-0.39386517741759425 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark11(-43.72786005777984,-0.29028874984257924,-123.7763335894115,0.610785654761461 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark11(-43.79461012963878,-1.3152945190495653,-0.22739554257072797,0.993520973596059 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark11(-43.81289031199574,-0.3199920505347441,7.493196024279854,0.9999999999997108 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark11(-4.384340697773808,-3.552713678800501E-15,-1.5707963267948966,-0.32693339539230637 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark11(-43.84758208240438,-0.027947459090297777,-135.17871959780558,-1.0000577678873641 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark11(-43.903783193697215,-1.0372201845124738,0.0,0 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark11(-43.91424283653958,-1.8125098140522274E-16,-1.3092720201648425,1.0 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark11(-43.98303463954119,-0.8044492494040583,-77.51039770986822,-0.3455092193667111 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark11(-44.04231797838202,-0.10559251908498975,-37.0334356502455,-1.0 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark11(-44.069209523294795,-1.311826438365932,-88.28100327713892,-0.31249262014125767 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark11(-44.140092616531376,-0.253423734129208,-28.275588281092197,-1.0680650954828779 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark11(-44.150378405465204,-0.9525891594932993,-100.0,-100.0 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark11(-44.1546709314554,-0.259079462497275,-115.11362625540983,-0.9644470112831698 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark11(-44.16945878106164,-0.9366720873160861,-100.0,0.3621410403195801 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark11(-44.18843153536075,-0.5708233533316669,-1.5707963267948966,-0.9854487183871309 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark11(-44.202738574481565,-2.220446049250313E-16,-11.525146202144327,0.6757570954969853 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark11(-44.29060948323252,-1.5707963267948912,-33.599778259196086,-1.0012774371003896 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark11(-44.296420659494046,-0.07274551849833193,-78.46723425295401,1.0 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark11(-44.32757848680872,-1.5683807379679446,-1.5707963267948957,-62.040297283483824 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark11(-44.34133006904069,-1.5707963267948846,-52.70143958227286,1.0000000000000036 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark11(-44.4548850301518,-4.440892098500626E-16,-30.373028453290463,0.0 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark11(-4.445905156514748,-1.5707963267948948,-58.84965646635895,0.014336926328320114 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark11(-4.4466430377088235,-1.5707963267948963,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark11(-44.469420931533804,-0.09979984953966614,-45.77096669576713,16.338854922911377 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark11(-44.52318913221713,6.457816027550714,0.561767086485549,0 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark11(-44.604182712962135,-0.4085927729473728,-1.3953201089333973,5.421010862427522E-20 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark11(-44.66772371427425,-1.0189707700223536,-52.626230618005124,-1.0 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark11(-44.76168419818008,-0.5026452630624227,-0.830154605014334,2102.430720724938 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark11(-44.86562493370014,-0.37069541150322094,32.42288792539648,-0.8344917279187579 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark11(-44.889418855991835,-1.5707963267948948,-11.771724585901016,-1.93533095388905 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark11(-44.98750266597162,-0.15092796169465972,-1.5707963267948963,45.02416101289979 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark11(-45.00021237233258,-0.6216620318732176,-1.5707963267948966,-76.39240539237937 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark11(-45.11366056602349,-0.7144308894883935,-0.3465242071092973,34.72505926978667 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark11(-4.516846693359305,-0.7772835119815331,-1.4357822208322335,-0.9999999999999991 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark11(-45.28828642630079,-1.570796326794896,-35.624947593666704,-0.022159231963505416 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark11(-45.309562189398235,-1.0081606758700647,-77.77271706039551,51.12868678591503 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark11(-45.389754191943105,-1.1221165397366684,-52.198894349573344,-1.0 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark11(-45.49929390758672,-1.5707963267948948,-37.00631783842979,-2339.265833600795 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark11(-45.55074134803333,-0.777796650822216,-46.216344478716685,0.9311711563164551 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark11(-45.568018278175856,-0.054729338726649125,-0.7412608316903649,0.09327652337167436 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark11(-45.599507389391356,-0.6783068048871392,-72.54452539882325,-26.35941788826834 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark11(-45.69193722868292,-1.1298153758229452,-1.5707963267948966,0.19970104491037255 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark11(-45.73449010604064,-0.5132099245322338,52.70606807582747,0 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark11(-45.74438919472618,-0.888803775237367,-0.48836326464295965,-0.9999999999999968 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark11(-45.922990635348015,-1.5674262387901354,-10.85738732240928,22.624903720605175 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark11(-45.93807749427362,-1.5137502989367118,-39.957030198773,1.0 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark11(-4.601156137951523,-1.449210990531187,-71.79995723835562,1.0000085943512849 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark11(-4.603369795589309,1.2314913254750335,83.16373102632443,-0.18681813182451193 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark11(-46.03879003954545,-0.02815834536216316,-1.5707963267948966,0.9991717152593981 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark11(-46.05765528408625,-1.5567367479420375,-79.33738299786259,-52.77025243141764 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark11(-46.07749121049519,-0.21270868403573473,-28.47398740958584,1.0 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark11(-46.13279247208155,-1.2480780568468408,-59.923039920194356,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark11(-46.148853289760964,-0.5210083897561053,-22.00799043290327,-2082.8749554687115 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark11(-46.16355016804078,-0.7620961557033539,-47.614994113835444,-1.0 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark11(-46.20873311796723,-0.6664338050409713,-58.72612787272937,12.797337188118703 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark11(-46.23603907456537,-0.12580605429336397,44.93357737234676,0.30147347681741343 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark11(-46.24653301799802,-1.5707963267948912,-48.16885713002629,56.02059415254018 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark11(-46.25351532659763,-0.09161017945819444,-1.5707963267948966,0.009364724757136844 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark11(-46.30174191291016,-0.3527807512019091,-1.5707963267948966,-20.704653594913403 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark11(-46.39268072530041,-1.5687077567754093,-39.238736143933394,-0.4037024602586671 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark11(-46.40482541833205,-0.019198791922048875,-4.1622715230801655,-4.3368086899420177E-19 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark11(-46.47194906722745,-0.032388986420405885,-0.46316143122272324,-0.6383715572666069 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark11(-46.62736594638881,-0.1947541058485469,-157.10221685868757,-0.0030385236365510493 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark11(-4.663415212919444,-0.01599670291935532,-26.663818806223844,-1.0 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark11(-4.669386339704908,-0.22387225482676598,-101.80262756568005,-70.07566068855722 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark11(-4.672634102089077,-0.7175348995876765,-32.46175361505922,1.0 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark11(-46.79219659787219,-0.34884631719886267,-32.80805614197703,1.0 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark11(-4.679613796873356,-1.5707963267948957,-1.5202839329913047,14.747867195296118 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark11(-46.80417693826248,-0.25779931211320806,-53.78712994413847,-1.0 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark11(-46.80553638005076,-0.5761822117919226,-1.5707963267948966,0.993765599995115 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark11(-46.8804889163737,-0.25653669394784784,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark11(-4.713966954434554,-0.7777671143990886,-100.0,1.0 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark11(-47.31962525427565,-0.997422428197928,-1.5464431393476126,-35.10367300700677 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark11(-47.33347472909308,-1.4546127662522967,-90.70072910756818,-11.92853149540348 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark11(-47.34868247019848,-0.8320925272009457,-92.26245201457891,-0.3862475172276887 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark11(-47.433870360925745,-1.2756563550898437,-26.273845500215913,28.165420952308267 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark11(-47.44717937532586,6.43320990882975,1.5707963267949054,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark11(-47.55352225985506,-0.006177496666495217,31.566247448298896,-0.8796552308805926 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark11(-47.58641302328304,-1.1178808691658784,-41.59725215656101,-89.51490649875687 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark11(-4.7710950321284855,-0.05655367230872299,-89.99743961674112,1.0 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark11(-47.72985287944571,-0.06278808848643058,20.622980004651037,0.0 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark11(-47.74606589456922,-0.9129651363632217,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark11(-47.74739467263032,-1.1102230246251565E-16,0,0 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark11(-47.81066807908443,-0.43472472395477335,-30.05337917159723,-1.0 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark11(-47.87780873211625,-1.212743928368662,-39.03533871200606,-20.16274143968273 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark11(-47.98136357165557,6.442702262927356,77.31562008632429,3.340476943479139E-5 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark11(-48.143645446707175,-0.0904830075525387,-23.40342230164301,1.0 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark11(-48.26069552253287,-0.43571947748084316,90.91662572563934,0 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark11(-48.27930235930011,-0.28647951131763794,-0.2471886628733415,-79.22736151026355 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark11(-48.40295291460255,-1.5707963267948912,-95.4084670180001,-1.0587911840678754E-22 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark11(-48.409109094235404,-0.33827764613896716,-65.89873046678161,-1.0 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark11(-48.429982036255,6.908792866887858,13.120473675310109,49.916044747406595 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark11(-48.50888629859299,-1.1102230246251565E-16,6.953851059723304,4.1076475839524577E-16 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark11(-48.64749991346109,-0.28833200866754766,-2.1327769098892375,3.3881317890172014E-21 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark11(-48.670996198550775,-0.4926580906513536,-98.8804955052266,0.01376233248123937 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark11(-48.67753540485781,-1.4210854715202004E-14,-73.44680150117487,-1.232595164407831E-32 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark11(-48.70435555391627,-0.9031607954273524,-65.8218862381341,-78.89536498824643 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark11(-48.77948135667689,-0.23918007200430552,-0.06764311429467829,-0.5554051463185539 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark11(-48.879134407765434,-0.5678543689162285,-11.362808946654965,-1.0 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark11(-49.083702884857814,-0.9704782527101646,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark11(-49.11516313045741,-1.387769220915703,-89.63636885272646,-0.5334850490873464 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark11(-49.17165940436385,-0.4378971701402768,-0.049056319139788994,1.0 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark11(-4.918007097603342,-1.11504590820298,-1.570796326794922,-1.3552527156068805E-20 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark11(-49.327782955606914,-0.3966490437749268,-79.46525155462665,-0.9916634227982946 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark11(-49.369349164891645,-0.34879433054994013,-1.5707963267948948,-52.37720771901405 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark11(-49.79966021800963,-0.00852838051802218,18.15608187622486,0 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark11(-4.988553493170387,-1.0225801896094697,-91.04540449007138,-0.0621975753204945 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark11(-4.995402737792913,-0.2732086298898171,-25.84502894628885,-0.9999999999999999 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark11(-50.02539827802397,-1.1917694234989906,-26.323922369161867,1.0 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark11(-50.141778379504075,-0.10780976266159213,-59.04667744889367,-0.3642249519535188 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark11(-50.19175217596457,-1.327179649609315,-54.75838926469403,-0.9484144019340687 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark11(-5.028166563715956,-0.855164555913305,-8.386193241349616,0 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark11(-50.34600187188243,-0.5787746902865537,-1.5707963267949054,0.4163459695157211 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark11(-50.36894154435078,-0.11635183935957627,-76.72153871286753,-0.03170552029034561 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark11(-50.385827611719456,14.43695487862604,31.78342115481746,-4.3653862183535094E-5 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark11(-50.406266256384185,-1.2329193423373348,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark11(-50.42331318914044,-0.002210601993965134,-1.5707963267949019,0.015337219578824429 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark11(-5.0510168601792556,-0.33881580133808287,-100.0,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark11(-50.65924131506759,-0.7938089106599981,-52.74696451070365,-0.27567647043666954 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark11(-50.67398195086243,-1.4714584429112287,-64.3691485258552,16.349879854998257 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark11(50.75716515772589,0,0,0 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark11(-50.84278036861303,-1.5707963267948912,-0.6216555146802665,1.0 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark11(-50.85348348716366,-1.5707963267948963,-40.20691818100203,1.0 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark11(-50.87852086351388,-1.3142998490404478,-1.5707963267948966,0.02391707542880321 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark11(-51.06799525782456,-2.592635389532378E-14,-3.197994299390407,-0.3178011123060571 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark11(-51.10424327007059,-0.14486013594866162,-1.5707963267948966,-0.431824767178142 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark11(-5.113412344317665,-0.15130022810290808,-12.138790888496255,-1.6940658945086007E-21 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark11(-51.259011038794526,-0.28436504293022713,-1.5707963267948966,2256.6610866390374 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark11(-51.37025074724551,-0.4733192982635701,-14.200680701973106,68.80499204510284 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark11(-51.41674196419912,-1.5512337911155267,-4.293856729626517,23.748119685920727 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark11(-51.441333691029484,-0.6031874896978844,-86.53309513871412,-34.78380717409257 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark11(-51.55080693294987,-1.5707963267948948,-1.1430434931415663,-0.5586784461339727 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark11(-5.1563998782213325,-0.4075480505841705,-64.71574324318499,1.0038525499711413 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark11(-51.626319262656175,-1.1668032336650942,-37.786252626031704,0.04111524211141242 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark11(-51.65468908497069,-9.185800167408331E-4,-95.68753138635823,1.0 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark11(-51.67872524220451,-1.4673686942863984,-0.5442851017044952,0.02419898034809212 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark11(-51.70420829842994,-1.1855578300061316,-119.99422332241528,-1.0011857349704716 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark11(-51.889042422282124,-1.0067753496202911,-100.0,-0.9999999999999996 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark11(-51.928745409546806,-1.5707963267948948,-19.378576658474707,18.629986525509928 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark11(-51.93199558988602,-1.0122630767901124,-34.252335616482256,-1.0 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark11(-51.942915817211485,-0.8023578737931232,-93.20656097440916,-0.05652445563865027 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark11(-51.94537996093199,-1.2192477990159274,-1.0679601687105775,3.599676536482969 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark11(-51.99745351711021,-0.46115655035870545,-31.911187511546256,-0.05813658833192378 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark11(-52.01338366449981,-1.5706947997257048,-1.0127203172609864,-0.9999999999999997 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark11(-52.29297977232142,-1.4554123720294605,-24.942291186538014,-1.0 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark11(-52.37672647729226,-0.11493260292723895,0.4000451490370449,0 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark11(-52.51301737372059,-1.4845338984808996,-79.89074007051553,-0.773727164072642 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark11(-52.51742692047591,-1.378427019262663,-71.41542647914984,-0.05510710873675856 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark11(-5.25685563445721,-0.7030784336004834,-0.20901204255925165,-0.03755435234397368 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark11(-52.57542247153472,-0.9462124584693379,-0.008040541672326932,0.9242782574649098 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark11(-52.75252087778183,-0.24993367078427653,-22.82948961531146,-1.0 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark11(-52.76300957095859,-0.6248333372314777,-12.27413320041508,-0.9457293341499448 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark11(-52.78141992729884,-0.7798671085038131,-72.51121354263364,0.0 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark11(-52.79271340172763,-1.2818937597023103,-55.86560369761815,-1.9721522630525295E-31 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark11(-52.838780451625105,-0.19449954492403823,-99.76600612322717,-0.05845927345008034 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark11(-52.87684920258891,-0.7801503233409623,-1.885650124014183,-1.0 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark11(-5.289360079437927,-0.7567516152649887,-57.82390190038791,-34.18920117540465 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark11(-5.291052660839189,-0.0981004303614043,-25.785182904975546,1.0 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark11(-52.960669741092396,-1.517798512384185,-0.4444089639505262,1.0 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark11(-5.301330400252786,-0.2339117874664152,-100.0,-100.0 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark11(-5.30554952975551,-0.8759816945181873,-1.3153564503464528,-1.0 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark11(-53.05916904850247,-0.8470917997307602,-11.596198151887094,-100.0 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark11(-53.07578586071621,-1.082783890702394,-82.98738663249048,-1.0 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark11(-53.081213052346804,-1.5695126068121723,-98.61599659468115,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark11(-53.08608624007902,-2.220446049250313E-16,-73.78405991254932,-1.0 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark11(-53.18448764684222,-0.5997638065040208,-1.5707963267948966,68.9258037126853 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark11(-53.208135068285294,-3.5388563038365653E-4,-63.4512485327392,0.039104424158899975 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark11(-53.29448330834137,-1.5707963267948912,-84.33580604469948,-1.0 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark11(-5.330589208098859,-0.39137600442279213,-1.5707963267949054,-1.0 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark11(-53.331388419223714,-2.855350507466803E-4,-1.5707963267948966,-39.537518565025515 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark11(-53.45459470388713,-1.5707963267947633,-66.14702930606165,3.622271631530685E-71 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark11(-53.508776520847874,-0.12000925267188478,-1.5707963267948966,-0.22207250646458043 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark11(-53.762794173656204,-1.5400181941855262,-21.20905855498725,-0.017955160951996854 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark11(-5.399002099621562,-0.8735788177504541,-36.607697897471006,0.924794503264297 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark11(-5.400527254152692,-0.017988742701191995,-93.84054344250517,1.0 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark11(-5.402186105351404,-1.5146236964599462,-67.00564439985688,0.0 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark11(-54.08909539246427,-0.4704175462415263,-1.5707963267948966,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark11(-54.10643620421483,-1.5504432454317838,-1.5707963267948966,-0.8444947917898861 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark11(-54.17229000601738,-1.322851374501573,-53.83914885825277,0.47912903731329237 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark11(-54.17877792882353,-1.170102907018574,-42.922884194759774,15.008652516530475 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark11(-54.18225524616667,-95.4739895382971,0,0 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark11(-54.24195053394003,-1.4914243430184444,-1.2783897903595363,-1.0 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark11(-5.427441979633046,-0.8191928069693347,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark11(-54.41171949577119,-1.4135870068164516,-33.34340819514682,22.808993629959275 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark11(-5.441445785457885,-0.3195824946269296,-1.4551082675780034,0.9638852905618944 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark11(-54.43403825014552,-1.4526599668735758,-0.6174857860108016,-61.46815697705052 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark11(-54.46894900036555,-0.3612642211376894,-14.432942484104771,0 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark11(-54.53107693660693,-2.220446049250313E-16,-0.04985232550894538,79.0761657980189 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark11(-54.56204007121788,-0.6916383858128099,-33.12793411965072,0.018337806461375467 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark11(-54.58646155816695,-0.8994222578293607,-21.355928489104997,-88.53652094465852 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark11(-5.459943870162016,-0.005375482785523944,-25.741121935418377,-0.5917223043623068 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark11(-54.60005862360805,-1.5707963267948957,-76.68078533644106,1.0 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark11(-54.64218925660486,-0.04976815567361115,-50.20889107546785,-1.0 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark11(-54.69931327330841,-1.5707963267948912,-10.521625725458563,-1.0 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark11(-54.76078964275421,-7.105427357601002E-15,-28.065044395607597,1.0 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark11(-54.857473457657534,-0.17860220010102762,-32.59181690425441,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark11(-55.04674097667174,-1.2749172016294978,-7.475637121651545,0.9226990737365793 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark11(-55.1400407522753,-1.3739982424137156,-59.01297203239973,0.0 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark11(-55.14894623876548,-0.7071524207302378,-47.93215664851932,1.0 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark11(-5.515925124703704,-1.2626180540038128,-94.27697835929553,-1590.029637341654 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark11(-55.280068961844705,-0.7629021413908671,-0.2986822569396404,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark11(-55.31625683908222,-1.413455466299311,-43.95810861334878,0.07315904381108063 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark11(-55.40727319851631,-1.3987466361817553,-48.37142932257426,-0.04301898265551144 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark11(-55.43899692457808,-1.5707963267948912,-30.436153339545967,1.0 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark11(-55.56701613854695,-3.9998283003240235E-15,-19.007944215269337,-31.222626838451262 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark11(-55.56900520478549,0,0,0 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark11(-55.61024411526698,-0.7233117920114847,-82.6888918634637,4.2168791772922093E-81 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark11(-55.66842855182814,-1.1446797722367787,-0.14570532475756728,-0.9666060255289168 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark11(-5.576486989830821,-0.004483592312041174,-63.827337207341,-0.8932609611639302 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark11(-55.78315272337283,-0.5212265387282103,-48.540309558053664,-0.03132609966884717 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark11(5.589064575694607,0,0,0 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark11(-55.99607292415678,-0.7534935604220405,-1.5488300593306596,-68.80449157629981 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark11(-56.0220850530363,-1.3082670491781303,-21.30797554650217,90.55873400626197 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark11(-56.15304675481347,-0.6147139130724903,-49.01867003103889,38.21506997071416 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark11(-56.33764841180978,-0.005016780672745691,-4.149039835764839,-0.9227197020680761 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark11(-56.358405770875954,-1.3550508357815951,-1.5707963267948963,-0.32356579851324935 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark11(-56.36665707170716,-0.29236215853143793,-0.33168567500401225,0.38324389927262625 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark11(-56.45258147780914,-1.570796326794896,-0.3397521625331734,-0.2855778105046669 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark11(-56.53142554553349,-1.5707963267948957,-63.86482793177842,1.0 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark11(-56.57112587991616,-0.5261712542532113,-0.4296556565316749,2067.1154339155123 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark11(-56.58267597371897,-1.085231229144314,-1.896102537219197,0 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark11(-56.59619333296856,-3.552713678800501E-15,-26.34586842730647,-0.5402622352297266 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark11(-5.664815595826813,-0.25328928434683695,60.63182800172004,0 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark11(-5.674988475154436,-1.1453552746755247,-56.10729794562491,-0.9414836672361504 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark11(-56.75951954335446,-0.021554785084251904,-15.925639098607993,67.52819397367425 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark11(-56.82481411297421,-1.3247415582546131,-59.829332807594255,-30.707853478908596 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark11(-5.688708560613364,-1.5466362978718706,-59.047342659601156,-81.06142814078888 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark11(-56.90673264348488,-0.5130259647421421,157.48860612158202,-1.0 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark11(-56.94422978067936,-1.5707963267948961,-53.207555817796724,-1.0 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark11(-5.703443092922161,-1.3271598195117233,-18.754466922162777,0.0 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark11(-57.06629369425692,-0.0013865380575666109,-64.2635579921907,-2276.194318800871 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark11(-57.11905174421081,-0.34116871745793376,157.48620965418002,-32.7992202414964 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark11(-57.23289297013601,-1.4741409033889354,-62.80275282208949,0.0 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark11(-57.29528875886733,-5.95835119327973E-14,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark11(-57.31412653828812,-1.2424047321362586,-100.0,-0.06255735537995724 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark11(-57.34927784838716,-1.5707963267948963,-0.5699231058767673,1.0 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark11(-57.38608774629954,-0.06176415574819536,-33.57612761221634,45.1141262259157 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark11(-57.412473588611796,-0.9325113206170704,-36.05481214312402,0.8565501854805508 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark11(-57.5347740973769,-1.5707963267948912,-2.8121284907157644,0 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark11(-57.56143015675575,-0.5324296872277892,-8.955534173067973,1.0 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark11(-57.6949896717633,-1.3953396857970546,-73.01410286508965,1.0364358836828456 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark11(-57.71977586555206,-0.3016266215178325,-96.7914253298535,48.52455851833068 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark11(-57.828538801971575,-0.06432839825742329,1.5707963267948912,-0.5972297081013027 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark11(-57.91379900222463,-0.4660895255673473,122.58475036047561,0.041961929277617216 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark11(57.92027294050979,79.05344515612668,-60.50426130306721,0 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark11(-57.98240366928144,-1.7763568394002505E-15,-37.89610180964448,1.0 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark11(-57.99739478849614,-0.7220732048229088,-35.725671128914755,1.0 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark11(-58.00369613760201,-1.5632338451933483,-0.7462750110367153,2.0588911849367645E-16 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark11(-58.02303358646379,-0.5832386513697827,-30.734475294140324,54.04020301375856 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark11(-58.08845582790345,-0.9936849724367942,-79.36503777675354,0.9756884850335316 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark11(-5.817066409998174,-1.5707963267948963,-82.1115835337008,53.903623479914145 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark11(-58.18966873795587,-0.34105101089142165,-37.17004189210964,-46.55420146147866 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark11(-58.23574929706201,-0.012793754035523318,-14.808184783892482,-0.7008019004890311 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark11(-58.267163773029296,-1.2425191790321155,-49.920214597309034,-0.9992777361825321 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark11(-5.827527132853064,-0.9486318132386377,-11.321612982336028,-1.0000000000000027 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark11(-58.39810493697978,14.477598047916047,31.80406466338576,100.0 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark11(-58.448818496807405,-0.7755454296162103,-0.22116024156608205,0.5512228170008016 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark11(-58.69944905790378,-1.5707963267945217,-1.5190899317645208,-12.033674424512872 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark11(-58.80287516907426,-1.255955027551651,-0.150023235392787,0.0 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark11(-58.8130122270241,-0.12704550249322707,-70.94180248564949,1.0 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark11(-58.83252688362984,-1.5707963267948963,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark11(-58.841455066327065,-0.6857433594495779,-24.754946181627346,-77.49664438508339 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark11(-5.890710885164211,-0.27073738216135534,-24.70637195118377,0.7983951778208951 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark11(-58.946355559473645,-1.1444064067899666,-73.59888054819326,0.9536895351515807 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark11(-59.19283468955466,-0.012395315176714976,56.3134877995599,0 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark11(-5.920322213554243,-0.583133191393194,-1.5707963267948966,-0.11823144218736559 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark11(-59.32995039912794,-1.1825157825361612,-73.81212309729833,-2.178476932300015 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark11(-59.35788183116448,-1.4609502819988656,-1.5707963267948983,26.88433546104848 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark11(-59.36508400663686,-0.7867709370898055,-27.664903243651224,44.37007594719628 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark11(-5.938962502245403,-0.8525660513724916,-72.71499682755098,-68.51756870020394 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark11(-59.44238584914535,-0.09928145782763553,-1.5707963267948961,-0.023556732578954215 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark11(-59.468178714229914,-1.5707963267948912,-32.81877976299736,0.2590334765551898 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark11(-59.526846589096664,-1.5707963267948957,-100.0,0.0 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark11(-59.54007987365027,-1.4675386536309272,-1.3540027831596482,1.0000009901453835 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark11(-59.5439247764278,-1.542544027594052,-1.5707963267948966,-1.232595164407831E-32 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark11(-59.58847093642503,-1.5502036118794622,-30.263241629704854,-0.8590360214244397 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark11(-59.64309835829185,-1.5029003257362064,-20.48401784337233,1.0 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark11(-5.970833977689921,-1.5707963267948963,-39.780359610797376,15.72058453029095 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark11(-59.80268994663496,0.15171637202605318,1.5707963267948966,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark11(-59.89126874547007,-1.2940580721999044,-25.445808529532584,80.79474304978862 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark11(-59.91073096553432,-1.9962732765931206E-14,-99.64668547808675,1.0 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark11(-60.15584445235237,-1.1159304454283567,-63.73199684001536,-0.016211018101070868 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark11(-60.216716838360306,-0.38666122378588125,-1.3322212926165655,-1.0 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark11(-60.21972576579709,-1.3511586199272094,-20.41715471548966,80.02314857516305 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark11(-6.021977082855614,-0.23810043800681457,-33.840775554441294,-0.23789636859821695 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark11(-60.22205150439157,-0.5757375845797761,-4.373141380306123,-1.0 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark11(-60.222771705798415,-1.2193117921107612,-51.81933406173761,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark11(-60.33001677272898,-0.9096061819467921,-66.62393529320957,-1.0000000000000036 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark11(-60.428396741304404,-1.565618851369548,-13.811465652770076,-1.0 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark11(-60.56073416223427,-0.36365693720555625,-3.4516156747878046,92.85269516208622 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark11(-60.577436486363226,-0.07298061336742628,-1.5707963267948961,85.5538915671315 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark11(-60.607144520481725,-10.345302758320372,0,0 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark11(-6.066284097113076,-1.8961707530630207E-7,-1.245643905530996,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark11(-60.74138242058811,-1.5707963267947918,-44.44964258837198,-86.24164991544629 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark11(-6.0769918418748095,-1.1102230246251565E-16,1.5707963267948966,0 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark11(-60.80560604513463,-0.01151165202380254,-36.16117602937066,0.7163915322142371 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark11(-60.80792634504937,0.055294431004933815,44.6736017565111,-0.9999999999999991 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark11(-6.0818142608324735,-1.5707963267948912,-12.519261269251459,-5.365246967198772 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark11(-60.837315416150936,-0.9126070272526613,-1.5707963267948966,-0.06259393859019846 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark11(-61.00145389023441,-0.07066514334450824,-1.5707963267948966,-79.7456550825084 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark11(-61.05088353046637,-0.0408547774193069,-15.930384819740812,4.3368086899420177E-19 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark11(-61.15822910143588,-1.2843419680679062,-67.4447376265553,86.51077928992805 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark11(-6.1207143388808944,-0.11473953248544855,-15.954694613715205,0.6373046166064558 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark11(-61.237629198999265,-1.570350560691217,-49.70311001056794,0.9059636476758351 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark11(-61.371696793146185,-0.5751223331451373,-9.203459922172389,-0.9999999999999964 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark11(-61.45869137553631,-0.3385337917937732,-1.5707963267948966,0.6142508426687281 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark11(-61.618386337877865,-1.3208991277405735,-62.00144814429742,-92.91545440050947 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark11(-61.64684655091245,-1.5707963267948692,-1.5515780237209436,0.6946183818767373 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark11(-61.71698824347553,-1.3689760949230811,-1.8824004521784867,-63.468117238125984 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark11(-61.73430694145602,-0.8863639949469394,-44.29201780753537,0.19903826406308212 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark11(-61.87394505917976,-0.9018455614855596,-1.5707963267948966,-88.84822077486277 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark11(-61.99018556624345,-1.5707963267948948,-54.65735655530287,77.15487135160271 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark11(-62.008521036566876,-1.4376733299162534,-36.78660722462265,0.02472120990050422 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark11(-62.06952375866811,-1.5707963267948957,-26.58765169043526,-89.56094302106092 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark11(-62.10139947926507,-1.4845072702604227,-1.7763568394002505E-15,-37.03017448985134 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark11(-62.244298909555916,-1.5707963267948912,-66.49475965844584,0.437322698307956 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark11(-62.32566498713869,-1.5707963267948948,-18.597601106132913,-0.924014280767153 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark11(-62.39871050886144,-1.5346515906753815,-23.89627731757693,0.6823526132931779 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark11(-62.43941749449094,-0.6765921492442749,-1.5707963267948966,0.3621537904933227 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark11(-62.55461936988561,-1.5707963267948957,-88.21409697157712,1.0 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark11(-62.61086610139335,-1.5707963267948912,-13.902296847925413,53.03231029260519 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark11(-62.64806265890943,-0.0013413136582383631,-32.78969272701356,0.034715777214952157 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark11(-6.2739096705725,-1.1073581208635233,-15.661471493330598,92.62308712801948 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark11(-62.75412449738613,-0.043840501044214886,-0.7613045091445585,100.0 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark11(-62.797657752849794,-1.0357328164592199,-0.8324361063071026,-1.0000000454112519 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark11(-62.80473484434798,-0.07445618547416852,-98.02914326137773,-1.0 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark11(-62.886433031143426,-7.105427357601002E-15,-61.731886150554494,9.629649721936179E-35 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark11(-62.887741767238325,-0.9481751506412925,-23.30465985094229,0 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark11(-62.896587935534804,-1.0338267039725886,-54.2157457911147,-1.0 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark11(-62.896678719835464,-0.3675137705853757,-1.5707963267948983,95.17245750218731 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark11(-62.96758723450291,-0.5836675290657012,-1.1623082824754831,1.0 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark11(-63.043006820993455,-0.2734129176045944,-1.5707963267948983,0.9999999999999996 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark11(-63.12603874936098,-0.34558017590361567,-22.875447383463886,-28.78868219072885 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark11(-63.156066934324436,-0.22010956149041894,-76.11700004827217,0.06255369310565202 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark11(-63.182255136846145,-1.2575382874660002,-11.07329198789636,0.044467354740563736 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark11(-63.19201588204707,-0.8662660993399811,-28.321710575908725,1.0 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark11(-63.34395783316923,-1.4283184034884318,-38.83435821410839,-1.0 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark11(-6.3371729770271825,-1.5526647725466085,-90.22196142778229,-34.600835476470465 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark11(-63.374159209733016,-0.919788776937466,-56.26319844713665,-5.5359591679709155 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark11(-6.3421120360295475,-4.440892098500626E-16,-1.5707963267948961,-0.9999999999999998 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark11(-63.46402112735938,-1.2754634839206616,-53.199353172843345,-98.63964733275972 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark11(-63.46912663910224,-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark11(-63.57054722781888,-1.2265446362917265,-5.983499819748886,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark11(-63.61630500078503,-1.5707963267948912,-3.256207551890057,1.0 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark11(-63.68321765110391,-1.3403209501682478,-35.38163169723019,-1.0 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark11(-64.0056992204553,-1.0204715144242393,-1.0552967232023898,51.12992724956665 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark11(-6.405003437175571,-0.41598559994917617,-13.561790134868652,-0.5442407575385211 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark11(-64.08295672249021,-0.006434619737682112,-67.08267677599295,1.0 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark11(-64.13047865032009,-0.10972152061429728,31.41748917096747,-23.402888753332252 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark11(-64.1603423440346,-1.4923429723722457,-49.17219486994345,-1.0 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark11(-64.35269500978046,-0.012030823939455438,-11.407806400491395,9.233983263910375 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark11(-64.36640359813914,-33.10391340524559,25.81515923773236,0 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark11(-64.38352713547891,-1.5174745357388295,-34.734699569072575,16.30071891656605 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark11(-64.41991295772083,-0.631474718184311,-48.78532070206898,-1.0 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark11(-64.48557010335479,-0.0010392208396361208,-4.049764079225113,-0.234011212384174 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark11(-64.55516008991609,-1.5518693799190628,-93.94628994411462,-1.0 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark11(-64.70255356090212,-1.3168267823363973,-50.29116298530124,-37.84317280412 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark11(-64.70472738160528,-1.5707963267948963,-0.7689215582163885,-1.0 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark11(-6.474532525101086,-1.5707963267948912,-93.77461128438216,2254.478967140807 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark11(-6.475292847183019,-1.417498118819294,-0.7538369835623508,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark11(-64.80535215087498,-0.46054019687800957,-56.176554060414844,-1.0 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark11(-6.488741737825772,-1.4234386724928556,-57.97920624432309,30.56299922523516 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark11(-64.9579820558648,-1.1232380326309046,-44.43375271952039,0.996295419015692 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark11(-64.96644494786237,-1.5351600960912666,-0.19939386639824994,1.0 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark11(-65.09347625595578,-0.048779907135342804,-39.540993668767605,0.8873050005809344 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark11(-65.25353859407592,-0.246207547363105,19.502002128974198,2146.2094070059525 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark11(-65.26239975888305,-1.4272663296656796,-0.3031709634813362,-1.0 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark11(-65.29673472977532,-1.0320513009564767,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark11(-65.30124039833076,-1.5707963267948948,-76.53039790143026,28.19233231879084 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark11(-65.33412763430287,-4.193199395093992E-16,-0.6520766523049479,82.49108979927871 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark11(-65.33892486891953,-1.1102230246251565E-16,95.45098584044987,85.5342213457271 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark11(-65.34504638940558,-1.166474905514832,-192.9559781383016,0.9062650807324211 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark11(-65.35724343672116,-1.5707963267948912,-1.5707963267949003,42.62707599404426 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark11(-65.39848135438658,-1.2575799678413029,-1.5707963267948877,37.72337933120835 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark11(-65.45155717221662,-0.711403515374489,-4.245914365578637,113.8745877868385 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark11(-6.545756716129379,-0.6613630667307788,-38.43254873647693,1.0 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark11(-65.48007893448911,-0.43113828508563623,-67.02899624934902,-60.5704224891228 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark11(-65.51752569694341,-0.02158905980448811,-30.443455724860584,-0.6649969977282022 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark11(-65.66648815405361,-8.881784197001252E-16,-25.771794718566944,0 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark11(-65.9063922601197,14.432000121564286,37.77081741405853,-1.0 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark11(-65.93865242294252,-1.5707963267948912,-88.46294594349284,77.19621864484384 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark11(-65.99579920949073,-0.12069095131741693,-17.477718131728764,1.0 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark11(-66.0269704029918,-1.3537571114983924,-30.396362642693376,-1.0 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark11(-66.23280190325065,-0.054542782484830216,60.39397423468557,100.0 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark11(-66.25245294788095,0,0,0 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark11(-66.25758829333529,-1.0020522874265634,-15.158424574075408,0.9752931381222225 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark11(-66.26076270103584,-1.5479463761113812,-10.559575142162233,-52.1360217099089 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark11(-66.2891380783058,-0.7355930626318812,-134.62571966358286,1.0000017358860291 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark11(-66.4236824983225,-0.5502154840649718,-1.5707963267948983,-19.456088933761706 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark11(-66.42447353277363,-0.14644732594248755,6.557595294189952,5.421010862427522E-20 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark11(-66.45327152849242,-1.5707963267948912,-32.67051462590483,1.232595164407831E-32 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark11(-66.5034953934277,-0.6081170933362383,-4.5277780862239005,77.68452933409442 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark11(-66.58040089993341,6.45169001621725,34.751252793149945,2.1901058733956167 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark11(-66.61429996965714,-0.25737469486173836,-1.5707963267948966,-0.18012806806097514 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark11(-66.69683670755055,-0.39870965985145723,-1.5707963267948966,-1.3234889800848443E-23 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark11(-66.99457447697195,-1.5707963267948961,-43.29079506731021,0 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark11(-67.05191295029258,-1.0026754541701237,-67.5259132429486,1.0 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark11(-67.1154966276459,-0.7853981633974492,-59.26767659882505,1.0 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark11(-67.27888395875493,-1.5707963267948912,-17.24413373241986,1.0 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark11(-67.37130223867376,-0.07678865579237526,63.606582431536076,-0.03469977843257245 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark11(-67.40256033187046,-1.145512530036539,-65.20927163031658,-0.07088798687449849 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark11(-67.4342303408549,-1.5701835356959601,-94.39172296334202,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark11(-67.44873306421431,14.429437391156313,67.54261781299225,30.4080268556107 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark11(-67.73193761794418,-0.019362451069909525,-1.5707963267948966,-98.16569458679894 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark11(-67.74698621857272,-1.8940640365262146E-15,-71.35388622344675,0.09484764753170594 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark11(-67.78698840397577,1.9496633369653844,102.87239734211761,0.0 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark11(-67.81164721334073,-0.2202344219481401,63.91492552343766,83.61013731921082 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark11(-67.86188945382841,-1.1230959543403773,-25.6987405450816,1.0 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark11(-67.87446250620269,-1.4933377033903596,-1.5707963267949,0.04726984437625603 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark11(-68.0678068779477,-0.2953792392011209,-69.0717590970787,3.469446951953614E-18 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark11(-68.09622804785046,-1.5707963267948963,-43.94070065992098,-1.0 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark11(-68.13984927019007,-0.8331672040296496,-96.44750421976082,-0.3758658452219117 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark11(-6.816506169575699,-1.368552233495985,-10.463437124384583,1.000014358433461 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark11(-68.18951582663298,-0.5266434170306455,-78.44650309416241,-1.0 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark11(-68.21004311405304,-1.5707963267948948,-24.58281214706509,48.20744366305131 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark11(-68.23022922568306,-0.039951587035209846,-39.84072645710778,-1.0 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark11(-68.35372124164131,-0.05304812491796862,-46.99672755219053,0.513964518163908 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark11(-68.43464143571309,-4.440892098500626E-16,-1.2258802711846264,0.0 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark11(-68.55712113234678,-1.0641903861191633,-73.35703857245089,-1.0000047708546036 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark11(-6.8607326771665385,-0.8582567898343606,-49.0466351170389,-1.0 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark11(-68.71366485328002,-0.8787745540195451,-6.152897827954959,-1.0 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark11(-68.9447315916068,-0.13909875210323602,-50.34280792141981,8.673617379884035E-19 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark11(-68.94926972434664,-1.5707963267948948,-1.2811271940756908,-1.0 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark11(-68.9620265212442,-1.1649917235321423,-24.58898239303629,-16.57877313329618 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark11(-68.9997834115367,-1.3396971909543645,-21.658039532874746,0.12454893521506838 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark11(-69.02930672578725,-1.5707963267948735,-1.5707963267948966,39.58890066955885 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark11(-69.11559305954206,-0.3987526390690307,31.72487756455461,0 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark11(-69.2625660101386,-1.5707963267948963,-53.68427382449574,0.0 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark11(-69.27076600391678,-79.62214243733484,0,0 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark11(-69.2779513629628,-0.13135554570762564,-1.5707963267948966,32.979697989772006 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark11(-69.3512830454013,-1.257537890908264,-37.85337247916142,-46.57895844950009 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark11(-69.4294761479895,-1.5707963267948957,-92.88786755770839,1.0 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark11(-69.52849515394252,-1.4941227040740857,-82.69132653757649,0.9369845086407518 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark11(-69.68953723112968,-1.3925974222484683,-71.37149218606746,-1.0000000000000009 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark11(-6.973489701091209,-1.5707963267948961,-72.59237479484966,99.01332023950224 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark11(-69.77291930607375,-0.2288853456816921,-1.5707963267948966,49.28486953854275 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark11(-69.87508917795657,-4.440892098500626E-16,-80.41265006419012,-0.13433608614288595 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark11(-69.90793742749709,-0.0167118390202603,-65.58416546688308,55.10386487031761 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark11(-70.00975427649541,-1.5707963267948963,-3.1699703958693988,1.0 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark11(-70.03287377872327,-0.2957483572975081,-68.92425387804218,1.0 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark11(-7.00752619896506,-0.6488145386794422,-30.517895069550946,0 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark11(-70.18168630799246,-1.005874230034471,-1.5707963267948966,0.3360736764922366 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark11(-7.0238188084369,87.34806705792516,0,0 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark11(-70.55782592110114,-1.5359172327836157,-1.4059384511596968,9.849428891848936 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark11(-70.5655201248934,-1.5650366248155634,-1.5707963267949019,0.0957104100728543 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark11(-70.57304076291187,6.965390139140774,163.63900667817546,-0.04719603593075189 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark11(-70.65177637531988,-0.6221834821223683,-126.16310418412928,0.0 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark11(-70.70746992925422,-0.5226751483750095,-55.8853072346192,0.9999999999999982 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark11(-70.71745490974925,6.436500622021229,8.159210631176007,8.673617379884035E-19 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark11(-70.75054230144762,14.432304544141019,25.85398452126369,1.0 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark11(-70.82164319243239,-1.5707963267948961,-66.73888110679194,-1.0 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark11(-70.82285435852972,-0.020880135542044376,50.86342036251352,0.7654480340092131 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark11(-70.85819162132634,-1.4802546470802649,-9.929020432563266,-0.11446520306019448 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark11(-70.87555842855349,-1.4348042534383831,-5.633920370721918,-1.0 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark11(-71.02174614965926,-1.0910672958494345,-10.802854660401536,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark11(-71.07847038015038,-1.017212802169219,-88.3436712444903,0.9758683122189569 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark11(-71.0838799152439,-0.22387003963712537,-26.599717171050557,0.0010025793356091967 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark11(-7.11164408765316,-0.0013113233040354096,-44.26023415632593,0.0 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark11(-71.1796399846703,-1.5707963267948948,-88.47123581555353,0.9064880307146641 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark11(-71.21813789152121,-0.14566401427238063,-84.73535414251845,-14.78962833836701 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark11(-71.23040605263319,-1.5528097043116134,-87.71846080296324,1.0 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark11(-7.124814894529472,-1.3456646784167425,-45.25426125732843,-1.0 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark11(-71.25728055435215,-1.5707963267948948,-100.0,-1.0 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark11(-71.33567239012476,-1.407439580854803,-66.23395480635747,-0.9804332752229583 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark11(-71.73268973288529,-0.656791712650564,-54.027023469715274,-0.1150580817009661 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark11(-71.77996057317311,-0.6932813339884889,-36.25366342476585,-2157.054842582002 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark11(-7.1780545008487415,-0.257564594928823,-0.6580044436796786,-193.96417535728662 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark11(-7.179550577747662,-1.1363256772130474,-6.146075212676891,-0.7464366054877057 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark11(-71.81857627633391,-0.8606783430027717,-67.49417138613478,98.27764731188793 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark11(-71.88212416501219,-0.0717374803862058,-66.7355204348581,-0.045015104447782894 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark11(-71.93176155525799,-0.3309566417141161,-33.58916659666239,0.4596777050486516 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark11(-71.95965190360951,-1.5707963267948912,-55.64201183718558,1.0 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark11(-71.99316462723309,-0.001943537103543321,76.77410714814884,-1.3177747429038154E-82 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark11(-71.99982362280737,-0.16607642126016495,95.83460947204378,0.0 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark11(-72.1347297931567,-0.23310952150610656,-100.0,1.0 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark11(-7.220027867780445,-1.4162101421300333,-61.535791037746144,-0.12804630074223966 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark11(-72.2203619555008,-0.903889862664645,-45.654546955941726,-19.543037076216258 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark11(-72.26841609686505,-1.5707963267948963,-1.5707963267948966,0.3167542946819023 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark11(-7.228901649838887,-0.20537095338842798,-1.5707963267948961,-1.0 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark11(-72.33931162813248,-1.5707963267948877,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark11(-72.35990582227906,-1.0875793571663903,-7.047522788500428,-42.67987752802493 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark11(-72.45801469005471,-0.37040659642455864,-61.90289277129564,-1.0 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark11(-72.71385070167455,-1.096177141476641,-32.62762008481599,60.833177656688335 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark11(-72.88432844163357,-0.5018090762654595,-1.5707963267948966,0.6240285408819304 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark11(-72.96732720157219,-0.002432615377826318,19.419541112192857,-0.8839680716315043 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark11(-7.302574726593822,-1.5707963267948963,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark11(-73.07955945927733,-0.05384928377343201,0.0,0 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark11(-73.19496061186591,-0.960270990338569,-39.837052053887824,1.0 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark11(-73.30318324619724,14.429234169390313,0.0,0 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark11(-73.61175335111838,-1.3452294510102831,-26.821466182707184,0.07094002156480705 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark11(-73.62456917728629,-1.5707963267948963,-1.5707963267948966,0.06255290587316316 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark11(-73.6602999545353,-0.03386152995183611,-20.834101009341754,-42.077839590179444 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark11(-73.70088719061371,-0.5016338362083862,69.3639635700107,-2.710505431213761E-20 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark11(-73.73932360905411,-1.4036672768363185E-14,-1.5707963267948966,54.84545630953542 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark11(-73.83048676246167,-0.03827167372405582,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark11(-74.04647194923874,-0.25587617503525895,-10.874121181325588,-1.0 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark11(-74.05930528396107,-1.2107771898226343,-55.11548974438986,45.04264129641965 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark11(-74.09305205990606,-1.0514450089739766,-30.776140172678993,-28.213509008864165 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark11(-7.412125754291253,-1.1700017570302388,-59.32967120580731,0.0 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark11(-74.13922426696136,-1.35333139879412,-227.41626450618492,1.3638863523955282 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark11(-7.420426110917246,-0.9600950038784558,-1.5707963267948992,-0.8026828948780107 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark11(-74.30493731262762,-0.7154004374861369,-87.30939903529087,29.180004960695754 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark11(7.443706716267286,0,0,0 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark11(-74.44451195764947,2.5212299017444635,1.5707963267948966,-4.016372130885797E-16 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark11(-74.52674240477943,-0.8993567823538047,-1.5707963267948983,23.722559951409764 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark11(-74.71913796270728,-0.6837641086627627,-1.5707963267948966,-0.02980027333735713 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark11(-7.478334512222034,-1.5707963267948948,-22.054342193064613,-1.0000046560262421 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark11(-74.91392490723229,-0.2988440431949846,-85.11890622832547,-78.983573537173 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark11(-74.93981854196272,-0.19732959754610135,-1.5707963267948966,18.776360507879474 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark11(-74.96342423782941,-1.46458598939571,-44.025702156753944,-0.6260249200481863 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark11(-7.498861774394456,-1.231638690455532,-7.750849300135499,0.7910884194959804 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark11(-75.00625703283532,-4.134212338247664E-4,-49.081942997756656,-1.0 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark11(-75.03926410946222,-1.5315005134733528,-4.1424038473743945,0.06256561440758529 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark11(-75.18188629190922,-0.7086140205171972,-1.4222635151343983,0 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark11(-75.21385432332737,-0.8965725918950742,-58.76605467825378,-2151.198430883017 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark11(-75.22811957216322,0.20302642202579413,2.4411429300865475,-100.0 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark11(-7.52412031757558,-0.32270922669726315,-100.0,100.0 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark11(-75.39833360855468,-1.297909807871056,-65.79840251004188,-1.0000000000000018 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark11(-75.52077166474496,-0.8560278197062225,-85.03813346811542,0.7098090335022338 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark11(-75.59101885122037,-0.679124903712484,-18.41434056737547,-0.044622095870927345 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark11(-7.561091645858127,-0.936412684624097,-93.40566387100243,1.0 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark11(-75.69367432442372,-0.26572072045789147,-24.499637974792872,1.0 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark11(-75.82133940188604,-1.03149122592793,-0.0010224837471334634,83.98202175372833 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark11(-75.90431165699836,-0.0013674343232492059,-46.16312123431143,-0.5675121896571071 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark11(-7.597925053964803,-1.220920123673154,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark11(-76.03009531554575,-1.4947571353406441,-1.5707963267948966,48.32057902245035 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark11(-76.0391349501872,-0.09078261782836214,-10.916352199643448,-2.622655278549061 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark11(-76.09297714558475,6.4292182497183505,1.5707963267948966,0 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark11(-76.11378505281732,-0.21060790672836713,7.4607634539556456,0 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark11(-76.26007401218243,-0.4302310111275812,30.97368837618638,0 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark11(-76.29845414335263,-1.5571741347597168,-9.656182886597026,-1.0 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark11(-76.44726926533035,-1.5707963267948963,-9.565379526390394,36.32044179077007 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark11(-76.46063445530524,-0.17455307144666307,1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark11(-76.54671164791061,-1.5400156675117302,-6.293276379636364,-1.0 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark11(-76.60252063573076,-1.4512415556127738,-7.933026402381966,-0.04754436126945831 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark11(-76.82080304860946,-0.4978767518314139,0.0,0 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark11(-77.07475637196092,-0.9627221294471909,-60.38557008885801,0.8939910008028062 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark11(-77.18028154820014,-0.3762125045312878,-9.565827654716813,1.0 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark11(-77.20104455714717,-0.9561641302864579,-1.5707963267948966,79.37997530042969 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark11(-77.283347760065,-1.475562566041247,-83.34253627755518,1.0 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark11(-77.30085837440146,-0.00812521333661003,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark11(-77.41124198528131,-0.09365244985112658,-1.5707963267948966,-0.9993659011270624 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark11(-77.48105155761564,-0.10530643706458939,31.429656630436227,-75.44415183200985 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark11(-77.54922090425741,-6.938893903907228E-18,-4.246017093322791,1.6940658945086007E-21 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark11(-77.5696343363992,-0.30480223577078003,-1.570796326794893,-1.0268690690621591 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark11(-77.62895379519586,-0.461593265595012,94.27925268941385,9.629649721936179E-35 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark11(-77.66688192360755,-1.5707963267948912,-29.27165255476192,1.0 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark11(-77.71590370614092,-1.009574983388036,-23.99603820052112,0.6149861377052162 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark11(-77.9003285952761,-0.9432579238912009,-119.9395927749107,-0.9998561053194565 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark11(-77.98734327010406,-2.792380611567765,0,0 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark11(-78.0380286613593,-1.420026193657402,-53.9402945449768,-1.0 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark11(-78.05049779496024,-1.2436946300699783,-76.35078320000116,-57.807213917462846 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark11(-78.1021305946364,-0.5299301751875731,-9.61076860303406,-0.9540997653215344 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark11(-78.13583920998127,-1.1102230246251565E-16,88.69825012759549,-0.03236706566474473 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark11(-78.20831639398804,-1.5707963267948744,-65.49647768078441,-1.0000004183861373 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark11(-78.28726811154002,-1.5707963267948957,-1.5126685765419232,0.0 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark11(-78.29817258222236,-0.15684903729039734,78.83148620936862,1644.9772299828553 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark11(-78.33470493600596,-0.04786524693611154,-87.71216895624207,-0.9999999999999991 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark11(-7.834891656992601,-8.881784197001252E-16,-30.68579141794101,0 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark11(-78.47951837631936,-1.5707963267948963,-95.21045909252804,-1.0 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark11(-78.56543880250865,-0.049955282008081525,-45.829405355992115,6.221917003927437 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark11(-78.63379420265353,-0.27656914080324535,-55.88075370669399,-24.509849967583396 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark11(-78.73087051037372,-1.4475860742607685,-84.62520962206152,-100.0 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark11(-78.74887750757719,-1.5114347815459641,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark11(-78.77125224022674,-1.5707963267948912,-67.9769070760182,-1.0 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark11(-78.84088410978379,-0.0992510375685167,-74.57104123335839,-44.16961355252236 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark11(-78.85487810581611,-0.20813913496690123,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark11(-78.92619242177244,-0.023165293867511257,-86.74007127569779,-69.7719739464975 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark11(-78.93713479328218,-1.5707963267948948,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark11(-79.30241973219604,-1.5707963267948963,-40.185400059062474,0.34818784015447557 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark11(-7.930793511181086,-1.5504249198604994,-9.73254388125693,-1.0 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark11(-79.35992224957585,-1.5707963267948912,-74.88900585888601,-23.237229091298644 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark11(-7.936103793038622,-0.03119717783874865,-67.10746189767396,0.3955466316098327 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark11(-79.36132468796559,-0.6073692469812528,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark11(-79.45315251956224,-0.08111957488642318,58.08236211643717,-0.030598985580872068 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark11(-79.49132089271025,-0.8043708321194682,-1.5707963267948948,-0.6319861523641768 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark11(-79.50783684564021,-1.5707963267948912,6.464753710741221,0 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark11(-79.51339679888811,-0.4816761250148329,-2.765501923401189,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark11(-7.952675125100572,-0.15540776882835594,-65.19302816252957,1.0 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark11(-79.5354136765098,-0.4831678152670327,-38.72317030715817,0.0 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark11(-79.5506545964367,-0.796570052662301,-17.456983428935892,0.8362795334246726 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark11(-79.72058726303825,-1.570796326794886,-90.75491417191907,-0.7419310560947352 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark11(-79.84632503599299,-1.546643037101678,-48.53679288681374,-1.0 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark11(-80.05872878905078,-0.4258920704410546,1.5707963267948983,2.502532119886844E-16 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark11(-80.07473494620935,-0.10242758330390296,-100.0,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark11(-80.086216094315,-0.028540628900435294,-84.42598547134891,-0.06255262290482982 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark11(-80.15534305453262,-1.570796326794894,-1.5707963267948966,-0.018307899168593166 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark11(-80.18499775077011,-0.14742749763410423,1.5707963267948988,-1920.7890893088222 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark11(-80.21916869046093,-1.5707963267948957,-44.35169129827163,-47.16900864205022 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark11(-80.34382041283904,-0.7915106771538649,-16.989006364555635,-1.0 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark11(-80.35592576224167,-1.0782716527238352,-10.22986538982738,0.0 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark11(-80.58676406450324,-1.367233398768047,-61.177499790748165,0.7731742636023977 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark11(-80.60556850141612,-1.1905972235342817,-46.63022401471619,-0.4873863850388225 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark11(-8.069440749298622,-0.3018965864939525,-100.0,1.0 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark11(-80.77467814404585,-0.5564017107425142,-67.07322304938465,-93.5348341721504 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark11(-80.88824412419483,-0.08063300217669145,-0.5574361932686407,39.05286291574561 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark11(-80.94061766756917,-0.04254736010766984,-26.273298577555806,-4.841668919623942 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark11(-80.98874609115812,-1.2815917548302878,-11.779205696609653,-1.0 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark11(-81.00311115629111,-0.5078487867337724,-4.716302853358886,0 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark11(-81.05125062763997,-1.4180521766518084,-72.6301631098143,1.0 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark11(-81.23310261348306,-0.5509896562395601,69.15859344015541,91.14853479687531 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark11(-81.57519307394658,-0.5568062106761857,-50.57179206952587,23.947043023567915 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark11(-81.58132441983447,-1.4160589689096994,-9.647703529233297,84.9055631605373 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark11(-81.64075388170887,-0.008447500018360928,-100.0,0.021169424756428443 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark11(-81.64370709979036,-1.5707963267948963,-94.54314988893195,0.004726778666825193 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark11(-81.68491635232265,-1.1472261657551581,-40.30430273778552,-0.9458207974820929 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark11(-81.69049803215108,-7.874480316361345E-4,-31.71846946858801,0.21623917480275434 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark11(-81.71448379223436,-0.26418606681281176,-8.211112120715185,-1.0 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark11(-81.8017810871892,-91.00462165753615,0,0 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark11(-81.80773148651271,-0.6361990310191995,-98.95317095706677,1.0 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark11(-82.0272308849371,-0.12320012719457729,-93.60898207071114,0.6229802895361689 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark11(-82.13265503880868,-0.017877364151087316,-7.398701025458337,0.36213974616970424 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark11(-82.23064875958102,-1.0705321787861222,-0.048590016851799096,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark11(-8.23196484330898,-0.38732792405677463,-0.7838333804546926,0.8311978977441695 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark11(-82.40258601357097,-0.4056373216136434,50.458307800651255,91.68959511264147 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark11(-82.67039192373771,-0.07402205157584216,58.02483344355821,0.2837265728129057 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark11(-82.68611166422325,-0.6414495720142951,-0.5288494120844942,-62.58770083820033 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark11(-82.68780679295935,-4.364550722058937E-16,-72.01907583764253,-0.2026696870932354 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark11(-82.71727975222475,-1.2780373876803652,-13.931324644712515,0.20169626882544534 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark11(-82.8346446182268,-2697.820080115155,0,0 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark11(-82.83734402609475,-0.01800656605345019,1.5707963267948983,-1006.9583260868728 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark11(-82.88098213292231,-0.017825476094051496,-22.75060852455417,-1.0 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark11(-83.03309231800688,-0.17918013327552007,-122.5661337014263,-0.4246721082115954 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark11(-83.04589342251079,-8.881784197001252E-16,-26.77905855178057,0.9591067882905264 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark11(-83.15121497649885,-1.5707963267948957,-32.290072823264865,1.0 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark11(-83.35329408369768,-0.8732313864269692,-99.46175962970122,1.0 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark11(-83.39811995986526,-1.5707963267948948,-4.617256583467051E-15,0 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark11(-83.55949282008402,-0.2858672163799147,-33.04347303038891,0.0 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark11(-83.70988210465863,-1.5707963267948948,-5.711044323327947,-36.585893416378624 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark11(-83.73814639728245,-1.7763568394002505E-15,-56.12953389265205,-39.14414904202632 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark11(-83.78603635121793,-1.1067384625169723,-55.63449008561787,61.97958287355118 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark11(-83.82938811569295,14.78396655256757,163.63047265659594,1608.9314402203431 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark11(-83.90601278478577,-1.486038095167726,-46.82917464674775,-1.0 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark11(-8.400862068864967,-1.2491051177705628,-23.75503924487103,-65.62523231147347 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark11(-84.13050073580243,-0.25834150464374217,44.13917193147509,-1.0 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark11(-84.20907783918204,-0.5845955513629845,-6.156569394756886,-0.5512848998172442 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark11(-84.37021512318942,6.4293951948757,57.443080568480525,-1.0 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark11(-84.47561382793249,-1.0423588543972007,-54.58006945789036,-75.03816301816894 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark11(-84.74596622769707,-1.0495097318083728,-9.439385459605063,-98.16228863988513 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark11(-84.85426979833483,-0.19307568873244452,-89.74427880719784,2.8644926667000858E-9 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark11(-85.13926761208006,-0.9887905107980836,-66.67658892514416,63.032104441019484 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark11(-8.51495512445063,-0.05278430753028207,-65.55464464961274,0.79441725875284 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark11(-85.27431758218673,-0.30186399035386496,-2.4483687497768177E-15,0.9999999999999944 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark11(-85.31269711317887,-1.2814996421581166,-1.5707963267948966,99.45884792684161 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark11(-85.39368274722723,-0.35722312500275905,-84.2714079770141,0.028456927283327826 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark11(-85.44886693357401,-0.27866880225065893,-1.5707963267948966,0.05104298557767545 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark11(-85.45147692371788,14.429212642093646,2.057264285355071,-52.84301874983774 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark11(-8.547648853069063,-0.05315033976906726,-32.567351847511176,0.0 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark11(-85.4849952996385,-0.41885079759090615,-57.43069619661519,45.74743444919051 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark11(-85.59174302665242,-1.3654569257831035,-115.13726613482814,-1.0000054609572449 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark11(-85.78624519238305,-0.023449155166188625,-32.8663408147217,-1.0000509487459501 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark11(-85.86784714990681,-1.3924335964574175,-81.26391853749205,1.0 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark11(-8.596288502607786,-0.1366632179007965,-44.01976605080974,-0.48531222458136414 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark11(-8.60353834545633,-1.5707963267948957,-1.5707963267948983,-0.19419619498088836 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark11(-8.61143659168214,-0.014274342855280175,1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark11(-86.11988482803652,-0.057100428554099344,45.19836812979822,-1347.2483576538284 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark11(-86.29016561290132,-0.20607844592808355,-0.6460532647145326,0.15642036066913434 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark11(-86.31545228286718,-1.5707963267948948,-0.34489928432165484,-1.0 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark11(-86.44445316421616,-0.440018760790406,-73.36041659569683,2.342072046333911 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark11(-86.66976485673077,-0.07343056084078414,-30.68720241807464,-1.0 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark11(-86.7050946318906,-0.3172438764415634,184.7398926866934,-40.70635857268427 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark11(-86.7132780798369,-0.7394815929611025,-12.048193867416945,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark11(-86.74557749745811,-1.7522010842216108E-15,-4.0006180518542024E-4,1.0 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark11(-8.690080137972375,-0.6566604369999489,-5.639460562825455,-74.85408318008695 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark11(-86.90665562249666,-0.325945911009228,-19.9037046180633,19.245471062523634 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark11(-8.698224311044312,-0.2711313670699805,-2.096851463468468,1.0 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark11(-87.03240312297318,-0.0632774987421101,-1.5707963267948966,-99.32762783513616 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark11(-87.23845705587291,-0.26751056752539537,1.5707963267948966,-27.65262229804707 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark11(-87.35769421702257,-0.4272496211814758,-0.6391453830859746,42.04288470779784 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark11(-87.51022932680772,-0.021884042475012702,26.717880990436598,0.0 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark11(-87.59322671757708,0.30040868464045933,67.09712255173812,-42.24029819162695 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark11(-87.60243855458782,-1.3045784350408054,-55.751743757556895,-0.9952369808487218 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark11(-8.760391081161178,-0.8374764205989111,-1.5707963267948966,-0.0511939682821721 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark11(-8.770788793114097,-1.2570403574794942,-123.7351490606689,-1.0 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark11(-87.8403647904231,-1.0512051186064402,-85.4402549094098,0.8730155761694669 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark11(-87.90905824436682,-0.5473474274005387,-31.607453655009284,-9.860761315262648E-32 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark11(-8.805965553780297,-1.4713587177197192,-83.37336767872316,-13.809657894509073 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark11(-88.19887241651463,-0.048017513000145166,-66.35522657761287,-1.0 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark11(-8.820581606037763,-0.20907989249070758,-123.5891724095971,-12.728808468923631 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark11(-88.2725582556422,-0.09616526999509735,-20.15001752713657,-5.094065110142072 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark11(-88.30536581263229,-1.2981051490659974,-61.252395245956784,-0.011285818778317414 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark11(-88.33698639272842,-0.26075887743250037,-43.35065216590811,-0.9801121802846483 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark11(-88.3993052647413,-1.5707963267948841,-86.20750655307894,0.775792381842402 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark11(-88.42095766617777,-1.5707963267948948,-73.4924969515227,0.5050309372800864 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark11(-88.49322856781755,-0.8554469529428061,-46.36140447927819,2183.268527008932 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark11(-88.78601979273934,-0.5140290000407908,-45.296087857711726,5.768127315074076 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark11(-88.80101654286085,-1.5624987719098975,-59.79590626301521,1.0 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark11(-89.00421367197768,-0.5865663368553861,-22.480999681753183,-0.06255347633948094 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark11(-89.27535044843236,2.866199506610259,45.10883754783236,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark11(-89.28446943641197,-0.264322617316747,-30.929370052915587,91.39806751518435 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark11(-89.39240158672672,-0.6622374554031438,-46.29793193769741,68.72150997559697 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark11(-89.45467524227453,-0.005527274190174243,52.28477569952352,35.793511052976704 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark11(-8.956498236963498,-1.5707963267948024,-66.19373010645836,0.9999999999999929 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark11(-89.60760657439869,-0.10223999562726085,-31.59192579625544,0.5462148263555902 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark11(-8.990640658105578,-1.0550670118298378,-1.5707963267948966,0.34508677905265384 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark11(-89.97547190057062,-1.3384700715478806,-70.83324109236831,-0.8780902539508308 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark11(-90.03475189199187,62.82354104965805,0.7667503980639339,0 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark11(-90.04200173684677,-0.005879856225156133,-43.245171636803484,0.8493109479575383 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark11(-90.0547712422933,-1.1833760484156695,-64.60650511698472,-46.90734141798134 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark11(-90.06083056464365,-0.9635496779351066,-42.93377551441635,-0.17197365651634378 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark11(-90.10794590029451,-1.5707963267948963,-95.58744393732698,-7.683331173224175 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark11(-90.29412172177308,-1.1633890598582144,-2.1270085109526846,-1.0 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark11(-90.3018227494971,-0.10567037205947793,68.35611068504211,0 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark11(-90.31344696226589,14.43745339692866,1.5707963267948966,94.62732127109389 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark11(-90.3916260495235,-0.9771324395006253,-8.194561891269885,0.18727345150125452 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark11(-90.44304845471146,-1.2056781395856635,-50.28261791971709,0 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark11(-90.50623890612775,-1.5707963267948948,-72.3168011209045,-0.0706987130707204 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark11(-90.51652295913928,-0.010191963155370486,44.4826512027121,-0.005056160275472621 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark11(-90.52402499633814,-0.8730330614326329,-67.3559543581511,1.0 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark11(-90.60066234035752,-1.7763568394002505E-15,-73.46683304281423,0 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark11(-90.63268392999801,-0.9119695894160884,-1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark11(-90.71886255314375,-1.337395705974579,-67.16654303251163,0.8733599522556457 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark11(-9.073071037886884,-0.16776052218838816,-68.66016717602852,-0.36209685401879466 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark11(-90.7945500420021,-1.5707963267948957,-6.3489753762516585,46.532338868133735 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark11(-90.91609246490594,-0.8264575815188756,-50.60628329585921,-1.0 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark11(-90.96354509536555,-0.6506676026280681,-74.35595874769565,-0.1158049815463208 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark11(-91.02476890897621,-0.2922307592977209,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark11(-91.03955362107621,-0.2944469465943696,-21.868443225712653,-65.43526239898225 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark11(-91.25526957519018,-0.08668484475869742,-16.295088780482548,100.0 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark11(-91.42041696620574,-1.4425398590340066,-24.728306738076043,1.0000000000000009 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark11(-91.4917472557331,-25.659290991173435,0,0 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark11(-91.5432635429868,-1.1452318320648134,-19.06817812960568,3.3087224502121107E-24 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark11(-91.62224902122485,-85.68450690450437,-62.85787828257785,0 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark11(-91.6436354350795,-1.5707963267948948,-98.48142070258187,0 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark11(-9.192786716220496,-0.6689625847980644,-91.12888932891417,-1.0 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark11(-91.9416877140048,-1.5659374402968727,-22.663728035439348,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark11(-91.95203533612127,-0.01040882950101718,-73.82036172204351,-0.016271119909684918 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark11(-9.200672054426894,-1.357216410608721,-72.49212487425972,69.78673809641712 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark11(-92.02067039969191,-0.01446593109446132,-4.377613040570208,1.0 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark11(-92.0207378482797,-1.0323232017846808,-31.163889578723385,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark11(-92.09610872980204,-1.312014465193437,-0.40280377427898223,0.2358258059663465 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark11(-92.32619804137197,-1.5707963267948961,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark11(-92.37874991237362,-0.5437735431097064,-15.007575608661952,-0.8246568801897263 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark11(-92.3957255563675,-1.5707963267948948,-76.74735056782913,0.7390675273789 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark11(-92.43553008393683,-1.5662198161781027,-1.5707963267948966,97.32985198349134 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark11(-9.244378204284384,14.429765537288901,68.47377951348835,0 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark11(-92.51897918905767,-1.5707963267948912,-100.0,57.81786851959609 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark11(-92.62047367369654,-1.5212562373666891,-1.5707963267948966,0.6252052589668644 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark11(-92.7077673289702,-0.9184621069837384,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark11(-93.14006818773468,-0.29158225660595505,-98.02356582352547,0.06295913107853653 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark11(-93.15893143630717,-1.1102230246251565E-16,67.14918629653828,0 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark11(-93.17357359118391,-0.6151608961270787,-35.934901071550414,-2214.441716581375 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark11(-93.42831504935631,-0.11934055154020351,-18.893423112064564,1.0 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark11(-93.52063858563744,-0.14256376449398586,-48.32691869100636,0.36208951165742864 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark11(-9.361131021967257,-0.11435414762336304,6.6358652614873925,-0.9016158511859744 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark11(-93.8259861998013,-0.9801549453012153,-31.975228657513966,-0.189441842745614 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark11(-93.9299501019226,-0.04821463218681457,-53.71496036672706,-0.7881012719609006 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark11(-93.97197135346464,-1.560937143986179,-1.5707963267948966,-1.0000091035919476 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark11(-94.00120078580542,-0.34666453997445246,95.30769425796191,2221.8856301344194 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark11(-94.04034359338795,-0.1985744259978528,-78.66893974301917,0.0 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark11(-9.41673679857309,-1.5707963267948957,-59.88394039387026,55.98952002087577 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark11(-9.431230849457624,-0.8392698954474609,-42.804758382064435,-23.98238641804275 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark11(-94.37382689566289,-7.105427357601002E-15,-44.594183924785135,-1.0 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark11(-94.44448090513504,-0.18835813161713233,-98.50749602108243,-96.74816832224606 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark11(-9.44966111338835,-0.3981498401567346,44.38398801053441,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark11(-94.53896293437869,-1.5707902052697846,-98.06274099754877,0.18657709809292408 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark11(-94.60296561893888,-1.3943130660746374E-14,-156.68484428330402,1.0 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark11(-95.27450243913079,-1.1404626585316677,-71.34628216167691,-9.799773267293517 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark11(-95.33571780816223,-1.4971494476950689,-62.56054422824799,-27.214004464001746 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark11(-95.41741959087206,6.514349742871485,84.10357826357716,71.80814257329425 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark11(-95.6183500942968,-1.2768101769179907,-6.3177244734926745,-0.9578919469197884 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark11(-95.6850146375996,-1.4461814480290107,-80.6101084012363,-1.0 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark11(-95.7462047871081,-0.16361951549889409,1.5707963267948966,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark11(-95.80222107520387,-0.07252373511641705,92.62016990639488,58.654300003040255 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark11(-95.89692360921545,-1.0390833706493374,-30.03333576707281,0.37399380295343176 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark11(-95.9158655866524,-1.2844209860829245,-6.275497560778561,-1.0 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark11(-95.94818540083307,-1.373047255909519,-81.2474240168261,-2272.7887664008367 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark11(-96.05307341611666,-0.11827867028427796,-1.646886269054539,3.5556509557904263 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark11(-9.617864474243191,-0.09879478560342536,96.53844532651378,-1335.5250626719162 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark11(-9.632044760528498,-1.5105308716932673,-71.58623982330784,-1.0 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark11(-96.34272602615775,-0.21435272902385655,-58.146957713762994,-1.0 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark11(-96.38888694944696,-0.5982079404231178,-39.00059586437541,0.240662443854178 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark11(-96.44572495080249,-1.5707963267945964,-89.19321767196601,0 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark11(-96.48872359558264,-0.12534699663507468,-95.7969672247613,0.0625535445553409 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark11(-96.6130335708921,-0.4631200928692904,-44.36667817628352,-71.93948172370179 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark11(96.76166116751986,74.48148669464868,6.796924147962997,0 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark11(-96.78867907597372,-1.2192527846537098,-62.55853884745318,-1.0 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark11(-96.80849730904652,-0.13925185867027992,-4.814918382973346,-0.9972511032852606 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark11(-96.82119675488167,-1.1102230246251565E-16,14.034994610555792,0.7740594024914255 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark11(-96.8664091385272,-1.163147392426545,-184.71424892774507,0.051705250954442714 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark11(-9.68748428497805,-0.11516764389413636,16.096286499397653,-556.4461240351737 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark11(-96.89549805872666,-1.5433818271396276,-32.67570213671794,0.8067275379828487 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark11(-96.92206704884202,-0.0725149574265451,-65.84544951541602,0.02265955544227398 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark11(-96.93192440724954,-1.5707963267948963,-25.37379846998045,-0.4564385700670949 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark11(-96.96983551150176,-0.7297313138078912,-1.5707963267948966,0.9785633370244069 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark11(-97.12153284383893,-1.5405902783204044,-66.82088940962016,1.0 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark11(-97.14953544135612,-0.5022604915860039,-32.812858911987064,1.0 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark11(-97.21215505628675,-0.29387725499427364,-59.45471694465277,-92.27918779495755 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark11(-97.23527627243863,6.44108097365146,2.4546255993965467,-39.1257517792443 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark11(-97.28333704069622,-1.5707963267948912,-128.616278899828,-24.97774691571277 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark11(-97.29306866089078,-0.12727950210125202,-1.5707963267948948,-27.200237050921434 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark11(-97.32177013512349,-0.7682987904138088,-136.90229857733158,-19.26178145636276 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark11(-97.36445022842193,-0.8081356064210974,-1.5707963267948966,-0.6067054831098949 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark11(-97.37689469652265,-1.5510614389949835,-1.0539555552235371,-46.32074828001745 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark11(-97.41589032188091,-0.08039083941352444,-31.56424345956539,0 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark11(-97.46233989991968,-0.03465979260450705,-66.06968618876817,-85.71620250927224 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark11(-97.79118212000904,-1.1086915581539043,-1.5707963267948983,0.5519991754787402 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark11(-97.8143934770157,6.517129583522636,34.98732386865057,1.7715819865143706E-4 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark11(-97.86427204254484,-0.003183490861957385,-28.77372531636358,-1.0 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark11(-97.95479995294022,14.429250610937487,31.658243661844992,-0.0466235190235392 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark11(-97.9566125198029,-0.6259069540566238,-10.530592144560018,1.0430830008925263 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark11(-97.95757484467353,-1.5707963267948963,-34.38059261773189,85.42062865238903 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark11(-97.96629848922063,0.8971099280208141,81.73379534669999,-0.19462093975390668 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark11(-97.99537542595856,14.48540188101888,1.5707963267948963,-9.848012277430026E-16 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark11(-98.12023338178457,-0.07394077486952252,64.16008418750732,67.01502125760932 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark11(-98.25032292958335,0.4228583352372891,67.54424205218055,0 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark11(-98.30748187166624,-1.5624972968785162,-1.562331214781394,-1.4225655996704496E-160 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark11(-9.830829808853622,-1.514730723166093E-15,-0.7064612626151573,0.8858698399118111 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark11(-98.31247187863433,-0.14040405814005652,-87.92756243605109,0.3597252598719507 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark11(-98.3985180933264,-1.5707963267948912,-95.6847170203748,1.0 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark11(-98.43446990233359,-7.105427357601002E-15,-94.49956939166107,-1.0 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark11(-98.45442798643923,-1.7763568394002505E-15,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark11(-98.50613189452709,-1.3671266571949268,-9.48400503438594,1.0 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark11(-98.52473636644002,-1.5707963267948957,-1.5707963267948966,2.9387358770557188E-39 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark11(-98.56370035691539,-0.9436918511102149,-0.017464138060732905,-74.1560347097223 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark11(-98.71501301662528,-0.6109531948515725,-1.126000784322784,-0.8363168225237284 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark11(-98.76774898850303,-0.024672423084792866,33.5139194156213,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark11(-98.81873593955525,-0.9067534740424259,-100.0,-0.9912820631928491 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark11(-98.9322223286873,-0.39777294414562736,-6.429299096806607,0 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark11(-98.95989744025408,-1.464060033115345,-2473.3644250765187,0 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark11(-98.96083174665793,-0.8927797142253618,-27.275416652875712,-1.0716814323946282 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark11(-98.973874639159,-1.6130733527307723E-16,-7.06620888704101,1.0842021724855044E-19 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark11(-99.09733578921163,-0.8797046585297007,-68.28757407466115,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark11(-99.18282686172586,-0.1609861652158861,-48.79156490027772,1.0 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark11(-99.1997537767516,-1.3933304584400734,-95.4678329027117,-14.973244966976514 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark11(-9.929144728966733,-0.9949272340218869,-24.07933158220459,-8.700165697272482 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark11(-99.31474501227548,-1.1219329040561976,-44.320960820442,-20.348808071498908 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark11(-99.33848876645291,-0.23942337822673493,-2.214722121545492,15.166494735458613 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark11(-99.35423922202489,-0.793481709880675,-135.461830012485,1.0148214647684235 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark11(-99.36962796731616,-0.5251855213925833,-88.29627309943406,97.27522512850383 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark11(-99.40938445636384,-1.5707963267948948,-65.12477568950635,-0.9048825759142511 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark11(-99.54086078318771,-0.006321250343356344,-13.31610617097473,-0.9675762305986086 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark11(-99.59231917391546,0.27617409321348985,57.12498154471231,0.004827668254115188 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark11(-99.71505862434564,-1.2364315075596606,-1.5707963267948966,-0.8937177672037929 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark11(-99.7317337869616,-1.552283352230125,-1.5707963267948966,-0.362157696395749 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark11(-99.74206467015597,0.4526258717520609,58.42969549298279,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark11(-99.78980049325997,-0.027751485550574242,-0.3217820409971389,0 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark11(-99.83437809841271,14.42983172022258,82.56636704303153,39.66330674926421 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark11(-99.94812868344813,-0.6276175936218663,-37.93550870724905,-1.0 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark11(-99.961023339308,-0.08216657603807383,-37.830633778544566,0.8982312452649808 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark11(-99.97193655917447,-0.3893480123404785,-1.5707963267948966,1.0700316338295992 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark11(-99.9900884854526,-0.5137422813704785,-61.32514355946928,1.0 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark11(-99.99971927391587,-0.25319075363056304,-1.8879073882133433,-1.8969470158121393E-4 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark11(-99.99999999999994,-2.705203926325719E-15,-20.45292380325315,1.0 ) ;
  }
}
